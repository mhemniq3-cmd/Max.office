from __future__ import annotations

import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from db.database_core import Database, password_hash, now_text, validate_password_strength, initial_admin_password_file

DEFAULT_PASSWORD = 'Admin12345!'


def main() -> int:
    password = (sys.argv[1] if len(sys.argv) > 1 else os.environ.get('MAX_SALES_RESET_ADMIN_PASSWORD') or DEFAULT_PASSWORD).strip()
    try:
        validate_password_strength(password, 'admin')
    except Exception as exc:
        print(f'كلمة المرور غير مقبولة: {exc}')
        return 2

    with Database() as db:
        row = db.one("SELECT id FROM users WHERE username='admin'")
        if row:
            db.execute(
                "UPDATE users SET password_hash=?, active=1, role='مدير', can_dashboard=1, can_sales=1, can_products=1, can_customers=1, can_returns=1, can_reports=1, can_users=1, can_tools=1, must_change_password=1 WHERE id=?",
                (password_hash(password), row['id']),
            )
        else:
            db.execute(
                """
                INSERT INTO users
                (username, password_hash, full_name, role, can_dashboard, can_sales, can_products,
                 can_customers, can_returns, can_reports, can_users, can_tools, active, created_at, must_change_password)
                VALUES (?, ?, ?, ?, 1, 1, 1, 1, 1, 1, 1, 1, 1, ?, 1)
                """,
                ('admin', password_hash(password), 'مدير النظام', 'مدير', now_text()),
            )

    try:
        handoff = initial_admin_password_file()
        handoff.parent.mkdir(parents=True, exist_ok=True)
        handoff.write_text(
            'كلمة مرور المدير بعد إعادة التعيين:\n'
            f'{password}\n\n'
            'ادخل بالمستخدم admin ثم غيّر كلمة المرور فوراً.\n',
            encoding='utf-8',
        )
    except Exception:
        pass

    print('تمت إعادة تعيين كلمة مرور admin بنجاح.')
    print('اسم المستخدم: admin')
    print(f'كلمة المرور: {password}')
    print('سيطلب النظام تغيير كلمة المرور بعد الدخول.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
