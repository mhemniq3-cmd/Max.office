from __future__ import annotations

from pathlib import Path
import re
import sys

PROJECT_ROOT = Path(__file__).resolve().parent
path = PROJECT_ROOT / 'settings' / 'initial_admin_password.txt'
if not path.exists():
    print('ملف كلمة المرور غير موجود. استخدم reset_admin_password.bat لإعادة تعيين كلمة مرور admin.')
    sys.exit(1)
text = path.read_text(encoding='utf-8', errors='ignore')
for line in text.splitlines():
    line = line.strip()
    if line and 'كلمة مرور' not in line and 'ادخل' not in line and 'يمكن حذف' not in line:
        print(line)
        sys.exit(0)
print('لم أجد كلمة مرور داخل الملف. استخدم reset_admin_password.bat لإعادة التعيين.')
sys.exit(1)
