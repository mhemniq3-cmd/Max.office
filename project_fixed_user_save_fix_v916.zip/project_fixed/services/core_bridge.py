"""Core bridge for the v1.0.0 native Domain architecture.

The final runtime is intentionally one-way:

- ``services.domain`` owns active business logic, calculations and read models.
- ``services.domain.persistence`` owns all sales/finance writes.
- ``services.data`` owns safe SQLite connections, migrations and query helpers.
- ``services.service_patches`` is only a feature-extension loader for older
  AppService methods; it is not a storage engine and must not contain fallback
  persistence paths.
"""
from __future__ import annotations

from typing import Any

from services.domain.domain_bridge import domain_migration_status, install_domain_bridge
from services.service_patches import apply_all_patches
from services.data import run_migrations


def initialize_service_layers() -> None:
    """Load feature patches and publish Domain wrappers.

    Persistence remains native-only; patch modules may add UI/business helper
    methods, but sales/finance writes are routed through
    ``services.domain.persistence``.
    """
    apply_all_patches()


def architecture_status() -> dict[str, Any]:
    """Return a compact status snapshot for admin/help screens."""
    status = domain_migration_status()
    return {
        "active_logic_layer": "services.domain",
        "persistence_layer": "services.domain.persistence",
        "data_layer": "services.data",
        "event_system": "services.domain.events",
        "storage_engine": "removed",
        "compatibility_shim": "services.service_patches",
        "domain_status": status,
    }


def run_data_migrations(conn) -> list[str]:
    """Apply Stage 13 data-layer migrations for a supplied SQLite connection."""
    return run_migrations(conn)




class CoreBridge:
    """Small safe facade for new modular UI screens.

    The production MainWindow still receives an AppService instance.  This
    facade exists for the new ui/screens package and for standalone UI demos;
    it keeps reads parameterized and delegates writes to AppService native
    methods instead of any removed legacy storage engine.
    """

    @staticmethod
    def _safe_identifier(name: str) -> str:
        raw = str(name)
        if not raw.replace("_", "").isalnum():
            raise ValueError(f"اسم الحقل أو الجدول غير آمن: {raw!r}")
        return raw

    @staticmethod
    def get_records(table: str, filters: dict[str, Any] | None = None, order_by: str | None = None) -> list[dict[str, Any]]:
        from services.data.queries import fetch_all

        safe_table = CoreBridge._safe_identifier(table)
        sql = f"SELECT * FROM {safe_table}"
        params: list[Any] = []
        if filters:
            clauses = []
            for key, value in filters.items():
                safe_key = CoreBridge._safe_identifier(key)
                clauses.append(f"{safe_key} = ?")
                params.append(value)
            sql += " WHERE " + " AND ".join(clauses)
        if order_by:
            # Allow simple comma-separated identifiers with optional ASC/DESC.
            order_parts = []
            for part in str(order_by).split(','):
                tokens = part.strip().split()
                if not tokens:
                    continue
                col = CoreBridge._safe_identifier(tokens[0])
                direction = tokens[1].upper() if len(tokens) > 1 else ""
                if direction and direction not in {"ASC", "DESC"}:
                    raise ValueError(f"اتجاه الترتيب غير آمن: {direction!r}")
                order_parts.append(f"{col} {direction}".strip())
            if order_parts:
                sql += " ORDER BY " + ", ".join(order_parts)
        return fetch_all(sql, tuple(params))

    @staticmethod
    def execute_sale_process(sale_data: dict[str, Any]):
        """Execute a sale through AppService native public API.

        This is a compatibility helper for the new standalone screen.  Regular
        application windows should keep passing their AppService instance to the
        screen directly.
        """
        from database import Database
        from services.app_core import AppService

        db = Database()
        service = AppService(db)
        cart = sale_data.get("items") or []
        employee_id = sale_data.get("employee_id")
        if not employee_id:
            employee = db.one("SELECT id FROM employees WHERE active=1 ORDER BY id LIMIT 1")
            employee_id = employee["id"] if employee else None
        invoice = service.complete_sale(
            cart,
            employee_id,
            sale_data.get("customer_id"),
            sale_data.get("payment_method") or sale_data.get("payment_type") or "نقدي",
            sale_data.get("discount_amount") or 0,
            sale_data.get("note") or "",
            sale_data.get("user_id"),
            "amount",
        )

        class Result:
            success = True
            error_message = ""
            invoice_number = invoice
            result = invoice

        return Result()


__all__ = ["initialize_service_layers", "architecture_status", "install_domain_bridge", "run_data_migrations", "CoreBridge"]


def native_persistence_status() -> dict:
    """Return Stage 14 persistence status."""
    import os
    return {
        "stage": 16,
        "persistence_layer": "services.domain.persistence",
        "native_persistence_mode": os.environ.get("MAX_SALES_NATIVE_PERSISTENCE", "on"),
        "storage_engine": "native-only",
    }
