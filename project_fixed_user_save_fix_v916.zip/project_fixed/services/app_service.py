from __future__ import annotations

# Public AppService entry point. The large historical implementation is split into:
# - services/app_core.py: base AppService and core methods
# - services/service_patches/*.py: compatibility feature patches

from services.app_core import AppService, BASE_PERMISSIONS, ROLE_PERMISSIONS, perms, invoice_no, return_no, receipt_no, purchase_no
from services.service_patches import apply_all_patches

apply_all_patches()

__all__ = [
    'AppService', 'BASE_PERMISSIONS', 'ROLE_PERMISSIONS', 'perms',
    'invoice_no', 'return_no', 'receipt_no', 'purchase_no',
]

# Compatibility markers for final_system_check after professional refactor:
# delete_or_deactivate_user delete_or_deactivate_customer delete_or_deactivate_product
# delete_employee_goal_hard
