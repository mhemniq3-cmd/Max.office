from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from typing import Any

CENT = Decimal('0.01')
ZERO = Decimal('0.00')


def _D(value: Any) -> Decimal:
    try:
        if value is None:
            return ZERO
        text = str(value).strip().replace(',', '')
        if not text:
            return ZERO
        return Decimal(text)
    except (InvalidOperation, ValueError, TypeError):
        return ZERO


def _Q(value: Any) -> Decimal:
    return _D(value).quantize(CENT, rounding=ROUND_HALF_UP)


def apply_promotion_to_price(promo, base_price: float, quantity: int) -> dict:
    """Pure pricing helper for promotions and invoices using Decimal internally.

    Return floats for UI/backward compatibility, but all money arithmetic is done with Decimal.
    """
    quantity = max(int(quantity or 0), 1)
    promo_type = (promo or {}).get('promo_type') if hasattr(promo, 'get') else promo['promo_type']
    original_unit = _Q(base_price)
    unit = original_unit
    free_units = 0
    if promo_type == 'percent':
        pct = max(_D((promo or {}).get('discount_value', 0)), ZERO)
        unit = max((original_unit * (Decimal('100') - pct) / Decimal('100')).quantize(CENT, rounding=ROUND_HALF_UP), ZERO)
    elif promo_type == 'amount':
        unit = max((original_unit - _Q((promo or {}).get('discount_value', 0))).quantize(CENT, rounding=ROUND_HALF_UP), ZERO)
    elif promo_type == 'fixed_price':
        unit = max(_Q((promo or {}).get('discount_value', 0)), ZERO)
    elif promo_type == 'buy_x_get_y':
        buy_qty = max(int((promo or {}).get('buy_qty') or 0), 0)
        free_qty = max(int((promo or {}).get('free_qty') or 0), 0)
        group_size = buy_qty + free_qty
        if buy_qty > 0 and free_qty > 0 and group_size > 0 and quantity >= group_size:
            free_units = (quantity // group_size) * free_qty
            paid_units = max(quantity - free_units, 0)
            unit = (original_unit * Decimal(paid_units) / Decimal(quantity)).quantize(CENT, rounding=ROUND_HALF_UP) if quantity else original_unit
    discount_amount = max(((original_unit - unit) * Decimal(quantity)).quantize(CENT, rounding=ROUND_HALF_UP), ZERO)
    return {'unit_price': float(unit), 'discount_amount': float(discount_amount), 'free_quantity': free_units}


def format_buy_get_note(quantity: int, free_quantity: int) -> str:
    free_quantity = max(int(free_quantity or 0), 0)
    quantity = max(int(quantity or 0), 0)
    if free_quantity <= 0:
        return ''
    paid = max(quantity - free_quantity, 0)
    return f'مدفوع: {paid} | مجاني: {free_quantity}'
