from services.core_common import *
from services.domain.auth_service import AuthServiceMixin
from services.domain.catalog_service import CatalogServiceMixin
from services.domain.people_service import PeopleServiceMixin
from services.domain.sales_service import SalesServiceMixin
from services.domain.report_service import ReportServiceMixin
from services.domain.print_backup_service import PrintBackupServiceMixin
from services.domain.inventory_purchase_service import InventoryPurchaseServiceMixin
from services.domain.goals_audit_service import GoalsAuditServiceMixin


class AppService(AuthServiceMixin, CatalogServiceMixin, PeopleServiceMixin, SalesServiceMixin, ReportServiceMixin, PrintBackupServiceMixin, InventoryPurchaseServiceMixin, GoalsAuditServiceMixin):
    """Commercial service facade assembled from domain mixins.

    Public API remains unchanged; domain logic lives in services/domain/*.
    """
    pass
