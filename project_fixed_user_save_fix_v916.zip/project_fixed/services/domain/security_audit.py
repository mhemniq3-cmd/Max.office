from __future__ import annotations

"""Read-only security, permissions, audit, coupon, and fraud domain services.

This stage intentionally migrates only safe read/validation operations.  User,
permission, coupon, fraud-rule, and archive mutations remain in service_patches
until the final sensitive-operation phase.
"""

from datetime import datetime
from typing import Any, Final, Iterable

DOMAIN: Final[str] = "security_audit"
READ_ONLY_METHODS: Final[tuple[str, ...]] = (
    "list_users",
    "get_user_details",
    "list_active_users",
    "list_inactive_users",
    "get_user_permissions",
    "check_permission",
    "list_audit_logs",
    "filter_audit_logs",
    "get_user_activity",
    "list_login_attempts",
    "get_security_events",
    "list_coupons",
    "get_coupon_details",
    "verify_coupon",
    "validate_coupon",
    "apply_coupon_preview",
    "list_fraud_alerts",
    "get_suspicious_transactions",
    "audit_rows",
    "audit_v2_rows",
    "security_alert_rows",
)
METHODS: Final[tuple[str, ...]] = (
    "add_fraud_alert", "apply_coupon_preview", "audit", "audit_event", "audit_rows",
    "audit_v2_rows", "authenticate", "barcode_security_health", "change_password",
    "coupon_performance_report", "decide_approval_request", "delete_or_deactivate_user",
    "export_audit_legal_csv", "export_coupon_performance_csv", "fraud_report_fast",
    "fraud_rules", "fraud_scan_now", "list_approval_requests", "list_coupons",
    "list_fraud_alerts", "list_users", "log_security_alert", "mark_coupon_used",
    "record_audit", "record_audit_v2", "refresh_coupon_performance_cache",
    "refresh_fraud_monthly_summary", "reload_fraud_rules_cache", "request_manager_approval",
    "resolve_fraud_alert", "resolve_security_alert", "role_permissions", "roles",
    "save_coupon", "save_fraud_rule", "save_user", "security_alert_rows",
    "security_health", "security_health_v45171", "security_health_v45173",
    "security_health_v45174", "user_has", "user_message", "validate_coupon",
    "validate_coupon_batch", "verify_audit_chain", *READ_ONLY_METHODS,
)
SENSITIVE_USER_FIELDS: Final[set[str]] = {
    "password", "password_hash", "password_salt", "token", "api_key", "secret",
}
PERMISSION_PREFIXES: Final[tuple[str, ...]] = ("can_", "is_", "must_")


def _domain(fn):
    setattr(fn, "_domain_implementation", True)
    return fn


def _table_exists(self: Any, table: str) -> bool:
    return bool(self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)))


def _columns(self: Any, table: str) -> set[str]:
    try:
        return {str(row[1]) for row in self.db.conn.execute(f"PRAGMA table_info({table})")}
    except Exception:
        return set()


def _select_columns(self: Any, table: str, requested: Iterable[str]) -> list[str]:
    available = _columns(self, table)
    return [col for col in requested if col in available]


def _row_dict(row: Any) -> dict[str, Any] | None:
    if row is None:
        return None
    if isinstance(row, dict):
        return dict(row)
    try:
        return {str(key): row[key] for key in row.keys()}
    except Exception:
        try:
            return dict(row)
        except Exception:
            return {"value": row}


def _rows(rows: Iterable[Any]) -> list[dict[str, Any]]:
    return [item for item in (_safe_output(_row_dict(row) or {}) for row in rows) if item]


def _clean(self: Any, value: Any, max_len: int = 2000) -> str:
    # Use the read-only operations_core normalizer without relying on the
    # AppService-bound wrapper, because clean_text is intentionally stateless.
    try:
        from services.domain.operations_core import clean_text as operations_clean_text

        return str(operations_clean_text(value, max_len))[:max_len]
    except Exception:
        return " ".join(str(value or "").replace("\x00", " ").split())[:max_len]


def _normalize_date(self: Any, value: Any) -> str:
    if not value:
        return ""
    try:
        from services.domain.operations_core import normalize_search_date, normalize_iso_date

        for fn in (normalize_search_date, normalize_iso_date):
            try:
                text = str(fn(value) or "")[:10]
                if text:
                    return text
            except Exception:
                pass
    except Exception:
        pass
    text = str(value).strip()[:10]
    try:
        datetime.strptime(text, "%Y-%m-%d")
        return text
    except Exception:
        return ""


def _limit(value: Any, default: int = 100, maximum: int = 2000) -> int:
    try:
        return max(1, min(int(value or default), maximum))
    except Exception:
        return default


def _offset(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except Exception:
        return 0


def _safe_output(row: dict[str, Any]) -> dict[str, Any]:
    clean = {str(k): v for k, v in row.items() if str(k).lower() not in SENSITIVE_USER_FIELDS}
    return clean


def _permission_columns(self: Any) -> list[str]:
    cols = _columns(self, "users")
    return sorted(col for col in cols if col.startswith("can_") or col in {"must_change_password", "active"})


def _is_admin_row(row: dict[str, Any] | None) -> bool:
    if not row:
        return False
    role = str(row.get("role") or "").strip().lower()
    username = str(row.get("username") or "").strip().lower()
    return username == "admin" or role in {"مدير", "مدير النظام", "admin", "administrator"}


def _where_date(self: Any, column: str, date_from: Any = "", date_to: Any = "") -> tuple[list[str], list[Any]]:
    clauses: list[str] = []
    params: list[Any] = []
    start = _normalize_date(self, date_from)
    end = _normalize_date(self, date_to)
    if start:
        clauses.append(f"date({column}) >= date(?)")
        params.append(start)
    if end:
        clauses.append(f"date({column}) <= date(?)")
        params.append(end)
    return clauses, params


@_domain
def list_users(self: Any, include_inactive: bool = True, term: str = "", limit: int = 500, offset: int = 0) -> list[dict[str, Any]]:
    """Return users without password_hash, with optional search and pagination."""
    if not _table_exists(self, "users"):
        return []
    cols = _select_columns(
        self,
        "users",
        (
            "id", "username", "full_name", "role", "active", "must_change_password",
            "last_login_at", "created_at", *_permission_columns(self),
        ),
    )
    safe_cols = [col for col in dict.fromkeys(cols) if col.lower() not in SENSITIVE_USER_FIELDS]
    where: list[str] = []
    params: list[Any] = []
    if not include_inactive and "active" in safe_cols:
        where.append("active=1")
    text = _clean(self, term, 200)
    if text:
        like = f"%{text}%"
        searchable = [col for col in ("username", "full_name", "role") if col in safe_cols]
        if searchable:
            where.append("(" + " OR ".join(f"{col} LIKE ?" for col in searchable) + ")")
            params.extend([like] * len(searchable))
    sql = f"SELECT {', '.join(safe_cols or ['id'])} FROM users"
    if where:
        sql += " WHERE " + " AND ".join(where)
    order_col = "active DESC," if "active" in safe_cols else ""
    sql += f" ORDER BY {order_col} id DESC LIMIT ? OFFSET ?"
    params.extend([_limit(limit, 500, 5000), _offset(offset)])
    return _rows(self.db.all(sql, params))


@_domain
def list_active_users(self: Any, term: str = "", limit: int = 500, offset: int = 0) -> list[dict[str, Any]]:
    return list_users(self, include_inactive=False, term=term, limit=limit, offset=offset)


@_domain
def list_inactive_users(self: Any, term: str = "", limit: int = 500, offset: int = 0) -> list[dict[str, Any]]:
    rows = list_users(self, include_inactive=True, term=term, limit=limit, offset=offset)
    return [row for row in rows if int(row.get("active", 1) or 0) == 0]


@_domain
def get_user_details(self: Any, user_id: int) -> dict[str, Any] | None:
    rows = list_users(self, include_inactive=True, limit=1, offset=0)
    # Use a direct query rather than relying on list pagination order.
    cols = _select_columns(self, "users", ("id", "username", "full_name", "role", "active", "must_change_password", "last_login_at", "created_at", *_permission_columns(self)))
    safe_cols = [col for col in dict.fromkeys(cols) if col.lower() not in SENSITIVE_USER_FIELDS]
    row = self.db.one(f"SELECT {', '.join(safe_cols or ['id'])} FROM users WHERE id=?", (int(user_id),)) if _table_exists(self, "users") else None
    return _safe_output(_row_dict(row) or {}) if row else None


@_domain
def get_user_permissions(self: Any, user_id: int) -> dict[str, bool]:
    row = get_user_details(self, int(user_id))
    if not row:
        return {}
    if _is_admin_row(row):
        return {col: True for col in _permission_columns(self) if col.startswith("can_")}
    return {col: bool(row.get(col, 0)) for col in _permission_columns(self) if col.startswith("can_")}


@_domain
def check_permission(self: Any, user_id: int | None, permission: str) -> bool:
    permission = _clean(self, permission, 80)
    if not permission or permission.lower() in SENSITIVE_USER_FIELDS:
        return False
    if user_id is None:
        user_id = getattr(self, "current_user_id", None)
    if user_id is None:
        return False
    row = get_user_details(self, int(user_id))
    if not row or int(row.get("active", 1) or 0) != 1:
        return False
    if _is_admin_row(row):
        return True
    if permission in row:
        return bool(row.get(permission, 0))
    alias_map = {"can_view_activity_logs": "can_audit", "can_delete_records": "can_tools"}
    alias = alias_map.get(permission)
    return bool(alias and row.get(alias, 0))


@_domain
def list_audit_logs(
    self: Any,
    limit: int = 100,
    offset: int = 0,
    term: str = "",
    user_id: int | None = None,
    action: str = "",
    table_name: str = "",
    date_from: str = "",
    date_to: str = "",
) -> list[dict[str, Any]]:
    return filter_audit_logs(self, user_id=user_id, term=term, action=action, table_name=table_name, date_from=date_from, date_to=date_to, limit=limit, offset=offset)


@_domain
def filter_audit_logs(
    self: Any,
    user_id: int | None = None,
    term: str = "",
    action: str = "",
    table_name: str = "",
    date_from: str = "",
    date_to: str = "",
    limit: int = 100,
    offset: int = 0,
) -> list[dict[str, Any]]:
    """Read audit rows from the newest audit table available, with pagination."""
    candidates = [
        ("audit_logs", "timestamp", "table_name"),
        ("audit_trail", "created_at", "entity_type"),
        ("activity_logs", "created_at", ""),
    ]
    for table, date_col, entity_col in candidates:
        if not _table_exists(self, table):
            continue
        cols = _columns(self, table)
        where, params = _where_date(self, date_col, date_from, date_to)
        if user_id is not None and "user_id" in cols:
            where.append("user_id=?")
            params.append(int(user_id))
        cleaned_action = _clean(self, action, 120)
        if cleaned_action and "action" in cols:
            where.append("action LIKE ?")
            params.append(f"%{cleaned_action}%")
        cleaned_table = _clean(self, table_name, 120)
        if cleaned_table and entity_col and entity_col in cols:
            where.append(f"{entity_col} LIKE ?")
            params.append(f"%{cleaned_table}%")
        cleaned_term = _clean(self, term, 200)
        if cleaned_term:
            searchable = [col for col in ("username", "action", "details", "reason", "table_name", "entity_type", "ip") if col in cols]
            if searchable:
                where.append("(" + " OR ".join(f"{col} LIKE ?" for col in searchable) + ")")
                params.extend([f"%{cleaned_term}%"] * len(searchable))
        sql = f"SELECT * FROM {table}"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += f" ORDER BY {date_col} DESC, id DESC LIMIT ? OFFSET ?"
        params.extend([_limit(limit, 100, 2000), _offset(offset)])
        result = _rows(self.db.all(sql, params))
        if not result:
            continue
        for row in result:
            row.setdefault("source", table)
        return result
    return []


@_domain
def audit_rows(self: Any, table_name: str = "", limit: int = 300) -> list[dict[str, Any]]:
    return filter_audit_logs(self, table_name=table_name, limit=limit)


@_domain
def audit_v2_rows(self: Any, table_name: str = "", limit: int = 300) -> list[dict[str, Any]]:
    return filter_audit_logs(self, table_name=table_name, limit=limit)


@_domain
def get_user_activity(self: Any, user_id: int, limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
    return filter_audit_logs(self, user_id=int(user_id), limit=limit, offset=offset)


@_domain
def list_login_attempts(self: Any, limit: int = 100, offset: int = 0, include_unlocked: bool = True) -> list[dict[str, Any]]:
    if not _table_exists(self, "login_attempts"):
        return []
    where = "" if include_unlocked else "WHERE locked_until IS NOT NULL AND locked_until<>''"
    return _rows(self.db.all(f"SELECT username, failed_count, locked_until, last_failed_at FROM login_attempts {where} ORDER BY last_failed_at DESC LIMIT ? OFFSET ?", (_limit(limit), _offset(offset))))


@_domain
def security_alert_rows(self: Any, status: str = "", limit: int = 100) -> list[dict[str, Any]]:
    if not _table_exists(self, "security_alerts"):
        return []
    cols = _columns(self, "security_alerts")
    where: list[str] = []
    params: list[Any] = []
    if status and "status" in cols:
        where.append("status=?")
        params.append(_clean(self, status, 80))
    sql = "SELECT * FROM security_alerts"
    if where:
        sql += " WHERE " + " AND ".join(where)
    order_col = "created_at" if "created_at" in cols else "id"
    sql += f" ORDER BY {order_col} DESC LIMIT ?"
    params.append(_limit(limit, 100, 2000))
    return _rows(self.db.all(sql, params))


@_domain
def get_security_events(self: Any, limit: int = 100, severity: str = "", event_type: str = "") -> list[dict[str, Any]]:
    sources: list[dict[str, Any]] = []
    if _table_exists(self, "security_alerts"):
        sources.extend(security_alert_rows(self, limit=limit))
    if _table_exists(self, "system_events"):
        clauses: list[str] = []
        params: list[Any] = []
        cols = _columns(self, "system_events")
        if severity and "severity" in cols:
            clauses.append("severity=?")
            params.append(_clean(self, severity, 80))
        if event_type and "event_type" in cols:
            clauses.append("event_type=?")
            params.append(_clean(self, event_type, 80))
        sql = "SELECT * FROM system_events"
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY created_at DESC, id DESC LIMIT ?"
        params.append(_limit(limit, 100, 2000))
        sources.extend(_rows(self.db.all(sql, params)))
    return sources[:_limit(limit, 100, 2000)]


@_domain
def list_coupons(self: Any, include_inactive: bool = True, limit: int = 500, offset: int = 0) -> list[dict[str, Any]]:
    if not _table_exists(self, "coupons"):
        return []
    cols = _columns(self, "coupons")
    public_cols = [col for col in (
        "id", "code_mask", "code", "type", "coupon_type", "value", "min_purchase", "max_uses",
        "used_count", "expiry_date", "starts_at", "product_id", "category", "customer_id",
        "max_uses_per_customer", "requires_manager", "active", "created_at", "last_used_at",
    ) if col in cols]
    select_exprs = []
    for col in public_cols:
        if col == "code" and "code_mask" in cols:
            select_exprs.append("COALESCE(code_mask, code) AS code")
        elif col != "code_mask":
            select_exprs.append(col)
    if not select_exprs:
        select_exprs = ["id"]
    sql = f"SELECT {', '.join(dict.fromkeys(select_exprs))} FROM coupons"
    params: list[Any] = []
    if not include_inactive and "active" in cols:
        sql += " WHERE active=1"
    sql += " ORDER BY active DESC, expiry_date IS NULL, expiry_date, id DESC LIMIT ? OFFSET ?"
    params.extend([_limit(limit, 500, 5000), _offset(offset)])
    return _rows(self.db.all(sql, params))


@_domain
def get_coupon_details(self: Any, coupon_id_or_code: int | str) -> dict[str, Any] | None:
    if not _table_exists(self, "coupons"):
        return None
    cols = _columns(self, "coupons")
    if str(coupon_id_or_code).strip().isdigit():
        row = self.db.one("SELECT * FROM coupons WHERE id=?", (int(coupon_id_or_code),))
    else:
        code = _clean(self, str(coupon_id_or_code).upper(), 120)
        if "code_hash" in cols:
            # Avoid importing hash internals here; use plain code for old DBs and masked details otherwise.
            row = self.db.one("SELECT * FROM coupons WHERE code=? OR code_mask=?", (code, code)) if "code_mask" in cols else self.db.one("SELECT * FROM coupons WHERE code=?", (code,))
        else:
            row = self.db.one("SELECT * FROM coupons WHERE code=?", (code,)) if "code" in cols else None
    data = _safe_output(_row_dict(row) or {}) if row else None
    if data and "code_mask" in data and data.get("code_mask"):
        data["code"] = data["code_mask"]
    return data


@_domain
def verify_coupon(self: Any, code: str, purchase_total: float = 0, customer_id: int | None = None, product_ids: list[int] | None = None, categories: list[str] | None = None, sale_id: int | None = None) -> dict[str, Any]:
    return validate_coupon(self, code, purchase_total, customer_id, product_ids, categories, sale_id)


@_domain
def validate_coupon(self: Any, code: str, purchase_total: float, customer_id: int | None = None, product_ids: list[int] | None = None, categories: list[str] | None = None, sale_id: int | None = None) -> dict[str, Any]:
    raw = _clean(self, str(code or "").upper(), 120)
    if not raw or not _table_exists(self, "coupons"):
        raise ValueError("الكوبون غير موجود أو غير نشط")
    cols = _columns(self, "coupons")
    row = self.db.one("SELECT * FROM coupons WHERE code=? AND active=1", (raw,)) if "code" in cols and "active" in cols else None
    if not row:
        raise ValueError("الكوبون غير موجود أو غير نشط")
    data = _row_dict(row) or {}
    today = datetime.now().strftime("%Y-%m-%d")
    if str(data.get("starts_at") or "")[:10] > today:
        raise ValueError("الكوبون لم يبدأ بعد")
    if str(data.get("expiry_date") or "")[:10] and str(data.get("expiry_date") or "")[:10] < today:
        raise ValueError("الكوبون منتهي الصلاحية")
    if float(purchase_total or 0) < float(data.get("min_purchase") or 0):
        raise ValueError("قيمة الفاتورة أقل من الحد الأدنى للكوبون")
    max_uses = int(data.get("max_uses") or 0)
    used_count = int(data.get("used_count") or 0)
    if max_uses and used_count >= max_uses:
        raise ValueError("تم استهلاك عدد مرات استخدام الكوبون")
    ctype = str(data.get("type") or data.get("coupon_type") or "percent").lower()
    value = float(data.get("value") or 0)
    discount = (float(purchase_total or 0) * value / 100.0) if ctype in {"percent", "percentage", "نسبة"} else value
    discount = max(0.0, min(discount, float(purchase_total or 0)))
    return {"valid": True, "code": data.get("code_mask") or raw, "type": ctype, "value": value, "discount": discount, "message": "الكوبون صالح"}


@_domain
def apply_coupon_preview(self: Any, code: str, purchase_total: float, customer_id: int | None = None, product_ids: list[int] | None = None, categories: list[str] | None = None) -> dict[str, Any]:
    return validate_coupon(self, code, purchase_total, customer_id, product_ids, categories, None)


@_domain
def list_fraud_alerts(self: Any, status: str = "", limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
    if not _table_exists(self, "fraud_alerts"):
        return []
    cols = _columns(self, "fraud_alerts")
    where: list[str] = []
    params: list[Any] = []
    if status and "status" in cols:
        where.append("status=?")
        params.append(_clean(self, status, 80))
    sql = "SELECT id, rule_code, severity, title, details, entity_type, entity_id, user_id, user_name, status, created_at, resolved_at, resolved_by, resolution_note FROM fraud_alerts"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY id DESC LIMIT ? OFFSET ?"
    params.extend([_limit(limit, 100, 2000), _offset(offset)])
    return _rows(self.db.all(sql, params))


@_domain
def get_suspicious_transactions(self: Any, limit: int = 100) -> list[dict[str, Any]]:
    alerts = list_fraud_alerts(self, status="", limit=limit)
    return [row for row in alerts if str(row.get("status") or "").strip() not in {"مغلق", "closed", "resolved"}]
