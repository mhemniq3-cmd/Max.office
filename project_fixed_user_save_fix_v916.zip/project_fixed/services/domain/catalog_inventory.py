from __future__ import annotations

"""Read-only catalog and inventory domain services.

This module is the first real migration step for catalog_inventory.  It keeps
write operations in legacy service_patches, but moves product lookup, stock
visibility, and inventory history reads into a typed, parameterized domain
module that can be reused by Qt screens and future API layers.
"""

from typing import Any, Final, Iterable

from services.app_core import AppService
from services.shared import search, validation

DOMAIN: Final[str] = "catalog_inventory"
READ_ONLY_METHODS: Final[tuple[str, ...]] = (
    "list_products",
    "list_products_public",
    "list_products_for_sale",
    "search_product_by_barcode",
    "search_product_by_name",
    "get_product_details",
    "get_product_by_barcode",
    "product_by_barcode",
    "barcode_scan_lookup",
    "get_product_for_pos",
    "list_categories",
    "list_brands",
    "list_units",
    "product_categories",
    "get_current_stock",
    "get_low_stock_products",
    "low_stock_details",
    "low_stock_rows",
    "get_stock_movement_history",
    "inventory_movements",
    "check_product_availability",
)
METHODS: Final[tuple[str, ...]] = (
    "adjust_inventory",
    "ai_price_suggestions",
    "ai_purchase_suggestions",
    "ai_stale_products",
    "ai_stock_forecast",
    "barcode_label_rows",
    "barcode_labels_html",
    "barcode_scan_lookup",
    "create_purchase",
    "deactivate_price_level",
    "deactivate_product",
    "deactivate_promotion",
    "delete_or_deactivate_product",
    "delete_product_price_level",
    "export_products_csv",
    "export_products_template_xlsx",
    "export_products_xlsx",
    "generate_barcode_value",
    "get_product_by_barcode",
    "get_product_for_pos",
    "get_product_details",
    "get_current_stock",
    "get_low_stock_products",
    "get_stock_movement_history",
    "check_product_availability",
    "import_products_csv",
    "import_products_xlsx",
    "inventory_movements",
    "list_advanced_offers",
    "list_brands",
    "list_categories",
    "list_price_levels",
    "list_product_price_levels",
    "list_products",
    "list_products_for_sale",
    "list_products_public",
    "list_promotions",
    "list_purchases",
    "list_suppliers",
    "list_units",
    "low_stock_details",
    "low_stock_rows",
    "print_barcode_labels_direct",
    "print_barcode_labels_html",
    "print_purchase_html",
    "product_by_barcode",
    "product_categories",
    "promotion_usage_stats",
    "promotions_by_status",
    "rename_product_category",
    "reorder_suggestions",
    "save_advanced_offer",
    "save_expense_category",
    "save_price_level",
    "save_product",
    "save_promotion",
    "search_product_by_barcode",
    "search_product_by_name",
    "set_product_price_level",
)


def _domain(fn):
    setattr(fn, "_domain_implementation", True)
    return fn


def _row_dict(row: Any) -> dict[str, Any] | None:
    if row is None:
        return None
    if isinstance(row, dict):
        return dict(row)
    try:
        return {str(key): row[key] for key in row.keys()}
    except Exception:
        try:
            return dict(row)
        except Exception:
            return {"value": row}


def _rows_dict(rows: Iterable[Any]) -> list[dict[str, Any]]:
    return [item for item in (_row_dict(row) for row in (rows or [])) if item is not None]


def _clean(value: Any, max_len: int = 120) -> str:
    return validation.clean_text(value, max_len)


def _product_columns(self: AppService) -> set[str]:
    try:
        return {str(row["name"]) for row in self.db.all("PRAGMA table_info(products)")}
    except Exception:
        return set()


def _select_products_sql(self: AppService) -> str:
    columns = _product_columns(self)
    base = [
        "id",
        "barcode",
        "name",
        "category",
        "cost_price",
        "sale_price",
        "quantity",
        "min_quantity",
        "commission_percent",
        "active",
        "created_at",
    ]
    optional = [
        "expiry_date",
        "customs_no",
        "country_origin",
        "unit_name",
        "items_per_unit",
        "reorder_point",
        "branch_id",
        "warehouse_id",
        "brand",
        "brand_name",
        "unit",
    ]
    selected = [column for column in base if column in columns]
    selected.extend(column for column in optional if column in columns and column not in selected)
    if not selected:
        selected = ["*"]
    selected.append(
        "CASE "
        "WHEN COALESCE(quantity,0) <= 0 THEN 'نافد' "
        "WHEN COALESCE(quantity,0) <= COALESCE(min_quantity,0) THEN 'منخفض' "
        "ELSE 'متوفر' END AS stock_status"
    )
    return ", ".join(selected)


def _product_sort_sql() -> str:
    return (
        "ORDER BY COALESCE(active,1) DESC, "
        "CASE "
        "WHEN COALESCE(quantity,0) <= 0 THEN 0 "
        "WHEN COALESCE(quantity,0) <= COALESCE(min_quantity,0) THEN 1 "
        "ELSE 2 END, name COLLATE NOCASE"
    )


def _hide_cost_when_needed(self: AppService, product: dict[str, Any] | None) -> dict[str, Any] | None:
    if product is None:
        return None
    try:
        user = self.current_user()
        if user and not self.user_has(user, "can_view_cost"):
            product = dict(product)
            product["cost_price"] = 0
    except Exception:
        pass
    return product


@_domain
def list_products(self: AppService, term: str = "", category: str = "", state: str = "active") -> list[dict[str, Any]]:
    """Return product rows for management screens without mutating inventory."""
    term = _clean(term)
    category = _clean(category)
    state = (_clean(state, 30) or "active").lower()
    where: list[str] = []
    params: list[Any] = []

    if state == "all":
        pass
    elif state in {"inactive", "disabled", "stopped"}:
        where.append("COALESCE(active,1)=0")
    elif state in {"out", "out_of_stock"}:
        where.append("COALESCE(active,1)=1 AND COALESCE(quantity,0) <= 0")
    elif state in {"low", "low_stock"}:
        where.append("COALESCE(active,1)=1 AND COALESCE(quantity,0) > 0 AND COALESCE(quantity,0) <= COALESCE(min_quantity,0)")
    else:
        where.append("COALESCE(active,1)=1")

    clause, like_params = search.build_like_filter(["name", "barcode", "category"], term)
    if clause:
        where.append(clause)
        params.extend(like_params)
    if category:
        where.append("category=?")
        params.append(category)

    sql = f"SELECT {_select_products_sql(self)} FROM products"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += f" {_product_sort_sql()} LIMIT ?"
    params.append(500)
    return _rows_dict(self.db.all(sql, params))


@_domain
def list_products_public(self: AppService, term: str = "") -> list[dict[str, Any]]:
    """Return active products for read-only public/POS selectors."""
    return list_products_for_sale(self, term)


@_domain
def list_products_for_sale(self: AppService, term: str = "") -> list[dict[str, Any]]:
    """Return active, in-stock products suitable for POS selection."""
    term = _clean(term)
    where = ["COALESCE(active,1)=1", "COALESCE(quantity,0) > 0"]
    params: list[Any] = []
    clause, like_params = search.build_like_filter(["name", "barcode", "category"], term)
    if clause:
        where.append(clause)
        params.extend(like_params)
    sql = f"SELECT {_select_products_sql(self)} FROM products WHERE {' AND '.join(where)} ORDER BY name COLLATE NOCASE LIMIT 500"
    return _rows_dict(self.db.all(sql, params))


@_domain
def get_product_by_barcode(self: AppService, barcode: str) -> dict[str, Any] | None:
    """Find one active product by barcode using a parameterized lookup."""
    try:
        self.require_any_permission(("can_scan_barcode", "can_sales", "can_touch_pos", "can_products", "can_purchases"), action="البحث بالباركود")
    except PermissionError:
        raise
    except Exception:
        # Some smoke tests and service scripts run without a current user.
        pass
    code = _clean(barcode, 120)
    if not code:
        return None
    row = self.db.one(f"SELECT {_select_products_sql(self)} FROM products WHERE COALESCE(active,1)=1 AND barcode=? LIMIT 1", (code,))
    product = _row_dict(row)
    if product is None:
        cleaned = "".join(ch for ch in code if ch.isdigit()) or code
        if cleaned != code:
            row = self.db.one(f"SELECT {_select_products_sql(self)} FROM products WHERE COALESCE(active,1)=1 AND barcode=? LIMIT 1", (cleaned,))
            product = _row_dict(row)
    return _hide_cost_when_needed(self, product)


@_domain
def search_product_by_barcode(self: AppService, barcode: str) -> dict[str, Any] | None:
    """Explicit barcode search alias for scanners and API callers."""
    return get_product_by_barcode(self, barcode)


@_domain
def product_by_barcode(self: AppService, barcode: str) -> dict[str, Any] | None:
    """Backward-compatible secure barcode alias."""
    return get_product_by_barcode(self, barcode)


@_domain
def barcode_scan_lookup(self: AppService, barcode: str) -> dict[str, Any] | None:
    """Return compact product data for barcode scan workflows."""
    product = get_product_by_barcode(self, barcode)
    if not product:
        return None
    return dict(product)


@_domain
def search_product_by_name(self: AppService, name: str, *, limit: int = 50) -> list[dict[str, Any]]:
    """Search active products by name, barcode, or category."""
    term = _clean(name, 120)
    max_rows = search.clamp_limit(limit, default=50, maximum=500)
    if not term:
        return []
    clause, params = search.build_like_filter(["name", "barcode", "category"], term)
    sql = f"SELECT {_select_products_sql(self)} FROM products WHERE COALESCE(active,1)=1 AND {clause} ORDER BY name COLLATE NOCASE LIMIT ?"
    params.append(max_rows)
    return _rows_dict(self.db.all(sql, params))


@_domain
def get_product_details(self: AppService, product_id: int) -> dict[str, Any] | None:
    """Return one product by id for details dialogs."""
    row = self.db.one(f"SELECT {_select_products_sql(self)} FROM products WHERE id=? LIMIT 1", (int(product_id),))
    return _hide_cost_when_needed(self, _row_dict(row))


@_domain
def get_product_for_pos(self: AppService, product_id: int) -> dict[str, Any] | None:
    """Return one active product by id for POS screens."""
    row = self.db.one(f"SELECT {_select_products_sql(self)} FROM products WHERE id=? AND COALESCE(active,1)=1 LIMIT 1", (int(product_id),))
    return _hide_cost_when_needed(self, _row_dict(row))


def _distinct_product_values(self: AppService, *columns: str) -> list[str]:
    available = _product_columns(self)
    selected = [column for column in columns if column in available]
    if not selected:
        return []
    values: set[str] = set()
    for column in selected:
        rows = self.db.all(
            f"SELECT DISTINCT {column} AS value FROM products WHERE COALESCE(active,1)=1 AND TRIM(COALESCE({column},''))<>'' ORDER BY {column} COLLATE NOCASE"
        )
        values.update(str(row["value"]).strip() for row in rows if str(row["value"] or "").strip())
    return sorted(values, key=str.casefold)


@_domain
def list_categories(self: AppService) -> list[str]:
    """Return active product categories."""
    return _distinct_product_values(self, "category")


@_domain
def product_categories(self: AppService) -> list[str]:
    """Backward-compatible category alias."""
    return list_categories(self)


@_domain
def list_brands(self: AppService) -> list[str]:
    """Return brand values when the database has brand columns."""
    return _distinct_product_values(self, "brand", "brand_name")


@_domain
def list_units(self: AppService) -> list[str]:
    """Return unit values when the database has unit columns."""
    return _distinct_product_values(self, "unit", "unit_name")


@_domain
def get_current_stock(self: AppService, product_id: int) -> int:
    """Return current quantity for one product."""
    row = self.db.one("SELECT COALESCE(quantity,0) AS quantity FROM products WHERE id=? LIMIT 1", (int(product_id),))
    return int(row["quantity"] if row else 0)


@_domain
def get_low_stock_products(self: AppService) -> list[dict[str, Any]]:
    """Return active products whose quantity is at or below min_quantity."""
    return low_stock_details(self)


@_domain
def low_stock_details(self: AppService) -> list[dict[str, Any]]:
    """Return low/out-of-stock products for alerts and reports."""
    rows = self.db.all(
        """
        SELECT id, barcode, name, category, quantity, min_quantity, active,
               CASE WHEN COALESCE(quantity,0) <= 0 THEN 'نافد' ELSE 'منخفض' END AS stock_status
        FROM products
        WHERE COALESCE(active,1)=1
          AND COALESCE(quantity,0) <= COALESCE(min_quantity,0)
        ORDER BY COALESCE(quantity,0) ASC, name COLLATE NOCASE
        """
    )
    return _rows_dict(rows)


@_domain
def low_stock_rows(self: AppService) -> list[dict[str, Any]]:
    """Backward-compatible low-stock alias."""
    return low_stock_details(self)


@_domain
def check_product_availability(self: AppService, product_id: int, required_quantity: int = 1) -> dict[str, Any]:
    """Check whether an active product has enough stock for a requested quantity."""
    required = max(0, int(required_quantity or 0))
    row = self.db.one(
        "SELECT id, name, COALESCE(quantity,0) AS quantity, COALESCE(active,1) AS active FROM products WHERE id=? LIMIT 1",
        (int(product_id),),
    )
    product = _row_dict(row)
    quantity = int(product.get("quantity", 0)) if product else 0
    active = bool(product.get("active", 0)) if product else False
    return {
        "product_id": int(product_id),
        "product_name": product.get("name", "") if product else "",
        "available": bool(product and active and quantity >= required),
        "quantity": quantity,
        "required_quantity": required,
        "shortage": max(required - quantity, 0),
    }


@_domain
def get_stock_movement_history(self: AppService, product_id: int, limit: int = 300) -> list[dict[str, Any]]:
    """Return read-only movement history for one product."""
    max_rows = search.clamp_limit(limit, default=300, maximum=1000)
    rows = self.db.all(
        """
        SELECT m.id, m.product_id, p.name AS product_name, m.movement_type,
               m.quantity_change, m.old_quantity, m.new_quantity, m.ref_type,
               m.ref_no, m.note, m.user_id, m.created_at
        FROM inventory_movements m
        LEFT JOIN products p ON p.id = m.product_id
        WHERE m.product_id=?
        ORDER BY m.id DESC
        LIMIT ?
        """,
        (int(product_id), max_rows),
    )
    return _rows_dict(rows)


@_domain
def inventory_movements(self: AppService, limit: int = 300) -> list[dict[str, Any]]:
    """Return latest inventory movements across products."""
    max_rows = search.clamp_limit(limit, default=300, maximum=1000)
    rows = self.db.all(
        """
        SELECT m.id, m.product_id, p.name AS product_name, m.movement_type,
               m.quantity_change, m.old_quantity, m.new_quantity, m.ref_type,
               m.ref_no, m.note, m.user_id, m.created_at
        FROM inventory_movements m
        LEFT JOIN products p ON p.id = m.product_id
        ORDER BY m.id DESC
        LIMIT ?
        """,
        (max_rows,),
    )
    return _rows_dict(rows)
