from __future__ import annotations

"""Pure calculation helpers shared by the domain layer and UI.

This module intentionally contains no database or UI dependencies.
"""

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any

CENT = Decimal("0.01")


def to_decimal(value: Any, default: str = "0") -> Decimal:
    """Convert a value to Decimal safely for financial display/calculation."""
    try:
        if isinstance(value, Decimal):
            amount = value
        else:
            amount = Decimal(str(value if value not in (None, "") else default))
    except (InvalidOperation, ValueError, TypeError):
        amount = Decimal(default)
    return amount


def money(value: Any) -> Decimal:
    """Quantize a monetary value to two decimal places."""
    return to_decimal(value).quantize(CENT, rounding=ROUND_HALF_UP)


def format_currency(amount: Any) -> str:
    """Format money with thousands separators for readable tables.

    Examples:
        100000 -> '100,000.00'
        Decimal('1234.5') -> '1,234.50'
    """
    return f"{money(amount):,.2f}"
