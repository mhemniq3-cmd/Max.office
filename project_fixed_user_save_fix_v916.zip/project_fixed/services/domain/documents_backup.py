from __future__ import annotations

"""Documents, exports, archives, and safe backup domain services.

This stage migrates output-oriented operations from service_patches into a
real domain module. Destructive recovery and deletion operations remain in the
legacy layer until the final hardening phase.
"""

import csv
import hashlib
import html
import json
import os
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Final, Iterable, Sequence

from services.app_core import AppService

DOMAIN: Final[str] = "documents_backup"
SAFE_METHODS: Final[tuple[str, ...]] = (
    "export_dir",
    "backup_dir",
    "_html_page",
    "export_rows_csv",
    "export_movements_csv",
    "export_to_csv",
    "export_to_excel",
    "export_to_pdf",
    "format_document_for_print",
    "print_report",
    "print_invoice",
    "print_receipt",
    "archive_document",
    "list_archived_documents",
    "search_archive",
    "search_archives",
    "search_document_archive",
    "get_archived_document",
    "get_document_content",
    "next_document_no",
    "generate_document_number",
    "backup_database",
    "create_backup",
    "list_backups",
    "test_backup_integrity",
    "verify_backup",
    "auto_backup_if_due",
    "backup_on_close_if_enabled",
)
METHODS: Final[tuple[str, ...]] = (
    "_gdrive_config_file",
    "_html_page",
    "_read_gdrive_json",
    "_v22_gdrive_settings_file",
    "_write_gdrive_json",
    "archive_document",
    "auto_backup_if_due",
    "backup_database",
    "backup_dir",
    "backup_on_close_if_enabled",
    "create_backup",
    "export_dir",
    "export_movements_csv",
    "export_rows_csv",
    "export_to_csv",
    "export_to_excel",
    "export_to_pdf",
    "format_document_for_print",
    "generate_document_number",
    "get_archived_document",
    "get_document_content",
    "google_drive_backup_target_dir",
    "list_archived_documents",
    "list_backups",
    "load_google_drive_backup_settings",
    "next_document_no",
    "print_invoice",
    "print_receipt",
    "print_report",
    "restore_database",
    "restore_database_safe",
    "save_google_drive_backup_settings",
    "search_archive",
    "search_archives",
    "search_document_archive",
    "test_backup_integrity",
    "test_google_drive_backup",
    "test_google_drive_backup_path",
    "verify_backup",
)

PROJECT_ROOT: Final[Path] = Path(__file__).resolve().parents[2]
DANGEROUS_PATHS: Final[set[Path]] = {
    Path("/"),
    Path("/bin"),
    Path("/boot"),
    Path("/dev"),
    Path("/etc"),
    Path("/lib"),
    Path("/proc"),
    Path("/root"),
    Path("/sbin"),
    Path("/sys"),
    Path("/usr"),
    Path("/var"),
}


def _domain(fn):
    setattr(fn, "_domain_implementation", True)
    return fn


def _now_stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _today() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def _clean(value: Any, limit: int = 160) -> str:
    text = str(value or "").replace("\x00", "").strip()
    return text[:limit]


def _slug(value: Any, fallback: str = "document") -> str:
    text = _clean(value, 80)
    safe = "".join(ch if ch.isalnum() or ch in ("-", "_", ".") else "_" for ch in text)
    safe = safe.strip("._")
    return safe or fallback


def _row_dict(row: Any) -> dict[str, Any] | None:
    if row is None:
        return None
    if isinstance(row, dict):
        return dict(row)
    try:
        return {str(key): row[key] for key in row.keys()}
    except Exception:
        try:
            return dict(row)
        except Exception:
            return {"value": row}


def _rows_dict(rows: Iterable[Any]) -> list[dict[str, Any]]:
    return [item for item in (_row_dict(row) for row in rows or []) if item is not None]


def _setting(self: AppService, key: str, default: str = "") -> str:
    try:
        row = self.db.one("SELECT value FROM app_settings WHERE key=?", (key,))
        if row is not None:
            return str(row["value"] or default)
    except Exception:
        pass
    return default


def _env_path(name: str, default: str) -> Path:
    value = os.environ.get(name, default)
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = (PROJECT_ROOT / path).resolve()
    return path


def _ensure_safe_directory(path: Path) -> Path:
    resolved = path.expanduser().resolve()
    if resolved in DANGEROUS_PATHS:
        raise ValueError(f"مسار غير آمن لحفظ الملفات: {resolved}")
    if any(parent in DANGEROUS_PATHS for parent in resolved.parents[:2]):
        # Allows project-local paths while refusing immediate writes under root/system folders.
        if PROJECT_ROOT not in resolved.parents and resolved != PROJECT_ROOT:
            raise ValueError(f"المسار خارج نطاق العمل الآمن: {resolved}")
    resolved.mkdir(parents=True, exist_ok=True)
    return resolved


def _resolve_output_file(directory: Path, filename: str | Path, suffix: str) -> Path:
    base = _ensure_safe_directory(directory)
    name = _slug(Path(str(filename)).name, "export")
    if suffix and not name.lower().endswith(suffix.lower()):
        name += suffix
    target = (base / name).resolve()
    if base not in target.parents and target != base:
        raise ValueError("اسم الملف يؤدي إلى مسار خارج مجلد التصدير")
    return target


def _require_permission_if_available(self: AppService, permissions: Sequence[str], action: str) -> None:
    try:
        if hasattr(self, "require_any_permission"):
            self.require_any_permission(tuple(permissions), action=action)
            return
        if hasattr(self, "require_permission") and permissions:
            self.require_permission(permissions[0], action=action)
    except TypeError:
        try:
            self.require_permission(permissions[0])
        except Exception:
            raise


def _table_exists(self: AppService, table: str) -> bool:
    try:
        row = self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
        return row is not None
    except Exception:
        return False


def _ensure_document_archive_schema(self: AppService) -> None:
    self.db.execute(
        """
        CREATE TABLE IF NOT EXISTS document_archive (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            doc_type TEXT NOT NULL,
            ref_type TEXT,
            ref_id INTEGER,
            doc_no TEXT,
            party_name TEXT,
            phone TEXT,
            amount REAL NOT NULL DEFAULT 0,
            file_path TEXT,
            content_text TEXT,
            created_by INTEGER,
            created_at TEXT NOT NULL
        )
        """
    )
    required_columns = {
        "doc_type": "TEXT NOT NULL DEFAULT 'document'",
        "ref_type": "TEXT",
        "ref_id": "INTEGER",
        "doc_no": "TEXT",
        "party_name": "TEXT",
        "phone": "TEXT",
        "amount": "REAL NOT NULL DEFAULT 0",
        "file_path": "TEXT",
        "content_text": "TEXT",
        "created_by": "INTEGER",
        "created_at": "TEXT",
    }
    try:
        existing = {str(row["name"]) for row in self.db.all("PRAGMA table_info(document_archive)")}
        for column, definition in required_columns.items():
            if column not in existing:
                self.db.execute(f"ALTER TABLE document_archive ADD COLUMN {column} {definition}")
    except Exception:
        pass
    try:
        self.db.execute("CREATE INDEX IF NOT EXISTS idx_document_archive_type_date ON document_archive(doc_type, created_at)")
        self.db.execute("CREATE INDEX IF NOT EXISTS idx_document_archive_doc_no ON document_archive(doc_no)")
    except Exception:
        pass


@_domain
def export_dir(self: AppService) -> Path:
    """Return the safe export directory, configurable via MAX_SALES_EXPORT_PATH."""
    return _ensure_safe_directory(_env_path("MAX_SALES_EXPORT_PATH", "exports"))


@_domain
def backup_dir(self: AppService) -> Path:
    """Return the safe backup directory, configurable via MAX_SALES_BACKUP_PATH."""
    return _ensure_safe_directory(_env_path("MAX_SALES_BACKUP_PATH", "backups"))


@_domain
def _html_page(self: AppService, title: str, body: str) -> Path:
    safe_title = _slug(title, "document")
    target = _resolve_output_file(export_dir(self), f"{safe_title}_{_now_stamp()}", ".html")
    company_name = html.escape(_setting(self, "company_name", "ماكس للمبيعات"))
    company_phone = html.escape(_setting(self, "company_phone", ""))
    company_address = html.escape(_setting(self, "company_address", ""))
    footer = html.escape(_setting(self, "invoice_footer", "شكراً لتعاملكم معنا"))
    html_doc = f"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>{html.escape(title)}</title>
<style>
body{{font-family:Tahoma,Arial,sans-serif;margin:28px;color:#111;line-height:1.7}}
.head{{text-align:center;border-bottom:2px solid #0f4c81;padding-bottom:12px;margin-bottom:18px}}
table{{width:100%;border-collapse:collapse;margin-top:16px}}
td,th{{border:1px solid #ddd;padding:8px;text-align:center}}
th{{background:#eef6ff}}
.total{{font-size:20px;font-weight:bold}}
.muted{{color:#666}}
@media print{{button{{display:none}} body{{margin:10mm}}}}
</style>
</head>
<body>
<div class="head"><h2>{company_name}</h2><div>{company_phone} - {company_address}</div></div>
{body}
<p class="muted">{footer}</p>
<script>window.print()</script>
</body>
</html>"""
    target.write_text(html_doc, encoding="utf-8")
    return target


@_domain
def format_document_for_print(self: AppService, title: str, rows: Sequence[dict[str, Any]] | Sequence[Sequence[Any]], fields: Sequence[str] | None = None) -> str:
    """Build a reusable RTL HTML fragment for report-like documents."""
    safe_title = html.escape(_clean(title, 120))
    if not rows:
        return f"<h3>{safe_title}</h3><p>لا توجد بيانات للعرض.</p>"
    first = rows[0]
    if fields is None:
        if isinstance(first, dict):
            fields = list(first.keys())
        else:
            fields = [str(i + 1) for i in range(len(first))]
    header = "".join(f"<th>{html.escape(str(field))}</th>" for field in fields)
    body_rows: list[str] = []
    for row in rows:
        cells: list[str] = []
        for idx, field in enumerate(fields):
            if isinstance(row, dict):
                value = row.get(field, "")
            else:
                value = row[idx] if idx < len(row) else ""
            cells.append(f"<td>{html.escape(str(value if value is not None else ''))}</td>")
        body_rows.append("<tr>" + "".join(cells) + "</tr>")
    return f"<h3>{safe_title}</h3><table><tr>{header}</tr>{''.join(body_rows)}</table>"


@_domain
def print_report(self: AppService, title: str, rows: Sequence[dict[str, Any]] | Sequence[Sequence[Any]], fields: Sequence[str] | None = None) -> Path:
    return _html_page(self, title, format_document_for_print(self, title, rows, fields))


@_domain
def export_rows_csv(self: AppService, filename: str, headers: list[str], rows: list[list[Any]]) -> Path:
    """Export rows to UTF-8-SIG CSV for Excel compatibility."""
    target = _resolve_output_file(export_dir(self), filename, ".csv")
    with target.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow([str(header) for header in headers])
        writer.writerows(rows)
    return target


@_domain
def export_to_csv(self: AppService, filename: str, rows: Sequence[dict[str, Any]] | Sequence[Sequence[Any]], fields: Sequence[str] | None = None) -> Path:
    if not rows:
        return export_rows_csv(self, filename, list(fields or []), [])
    first = rows[0]
    if fields is None:
        fields = list(first.keys()) if isinstance(first, dict) else [str(i + 1) for i in range(len(first))]
    csv_rows: list[list[Any]] = []
    for row in rows:
        if isinstance(row, dict):
            csv_rows.append([row.get(field, "") for field in fields])
        else:
            csv_rows.append([row[idx] if idx < len(row) else "" for idx, _ in enumerate(fields)])
    return export_rows_csv(self, filename, list(fields), csv_rows)


@_domain
def export_to_excel(self: AppService, filename: str, rows: Sequence[dict[str, Any]] | Sequence[Sequence[Any]], fields: Sequence[str] | None = None) -> Path:
    """Export to .xlsx when openpyxl exists, otherwise fall back to CSV."""
    try:
        from openpyxl import Workbook  # type: ignore
    except Exception:
        return export_to_csv(self, filename, rows, fields)
    if not rows:
        fields = list(fields or [])
    elif fields is None:
        first = rows[0]
        fields = list(first.keys()) if isinstance(first, dict) else [str(i + 1) for i in range(len(first))]
    target = _resolve_output_file(export_dir(self), filename, ".xlsx")
    wb = Workbook()
    ws = wb.active
    ws.title = "Export"
    ws.append(list(fields or []))
    for row in rows:
        if isinstance(row, dict):
            ws.append([row.get(field, "") for field in fields or []])
        else:
            ws.append([row[idx] if idx < len(row) else "" for idx, _ in enumerate(fields or [])])
    wb.save(target)
    return target


@_domain
def export_to_pdf(self: AppService, filename: str, title: str, rows: Sequence[dict[str, Any]] | Sequence[Sequence[Any]], fields: Sequence[str] | None = None) -> Path:
    """Create a print-ready HTML document as a PDF-safe fallback.

    The project has no mandatory PDF renderer dependency. The generated HTML is
    browser-printable to PDF and keeps the API side-effect safe.
    """
    body = format_document_for_print(self, title, rows, fields)
    path = _html_page(self, _slug(filename, "report"), body)
    return path


@_domain
def export_movements_csv(self: AppService, **filters: Any) -> str:
    rows = []
    if hasattr(self, "list_unified_movements"):
        try:
            rows = self.list_unified_movements(**filters)
        except TypeError:
            rows = self.list_unified_movements()
    rows_dict = _rows_dict(rows)
    fields = list(rows_dict[0].keys()) if rows_dict else ["created_at", "kind", "title", "amount", "note"]
    return str(export_to_csv(self, f"movements_{_now_stamp()}", rows_dict, fields))


@_domain
def archive_document(
    self: AppService,
    doc_type: str,
    ref_type: str = "",
    ref_id: int | None = None,
    doc_no: str = "",
    party_name: str = "",
    phone: str = "",
    amount: float = 0,
    file_path: str = "",
    content_text: str = "",
    user_id: int | None = None,
) -> int:
    """Archive document metadata/content without touching source transactions."""
    _ensure_document_archive_schema(self)
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    doc_type_clean = _clean(doc_type, 40) or "document"
    doc_no_clean = _clean(doc_no, 80) or next_document_no(self, doc_type_clean, "DOC")
    party_clean = _clean(party_name, 160)
    phone_clean = _clean(phone, 60)
    columns = {str(row["name"]) for row in self.db.all("PRAGMA table_info(document_archive)")}
    values: dict[str, Any] = {
        "doc_type": doc_type_clean,
        "ref_type": _clean(ref_type, 40),
        "ref_id": ref_id,
        "doc_no": doc_no_clean,
        "ref_no": doc_no_clean,
        "title": f"{doc_type_clean} {doc_no_clean}".strip(),
        "party_name": party_clean,
        "customer_name": party_clean,
        "phone": phone_clean,
        "customer_phone": phone_clean,
        "amount": float(amount or 0),
        "file_path": str(file_path or ""),
        "content_text": str(content_text or ""),
        "content_json": json.dumps({"doc_no": doc_no_clean, "ref_type": ref_type, "ref_id": ref_id}, ensure_ascii=False),
        "created_by": user_id,
        "created_by_user_id": user_id,
        "created_at": created_at,
        "doc_date": created_at[:10],
    }
    insert_columns = [column for column in values if column in columns]
    placeholders = ", ".join("?" for _ in insert_columns)
    sql = f"INSERT INTO document_archive ({', '.join(insert_columns)}) VALUES ({placeholders})"
    cur = self.db.execute(sql, [values[column] for column in insert_columns])
    return int(cur.lastrowid)

@_domain
def search_archive(self: AppService, query: str = "", doc_type: str = "", date_from: str = "", date_to: str = "", limit: int = 300) -> list[dict[str, Any]]:
    _ensure_document_archive_schema(self)
    where: list[str] = []
    params: list[Any] = []
    term = _clean(query, 120)
    if term:
        like = f"%{term}%"
        columns = {str(row["name"]) for row in self.db.all("PRAGMA table_info(document_archive)")}
        candidates = [column for column in ("doc_no", "ref_no", "title", "party_name", "customer_name", "phone", "customer_phone", "content_text", "ref_type") if column in columns]
        where.append("(" + " OR ".join(f"{column} LIKE ?" for column in candidates) + ")")
        params.extend([like] * len(candidates))
    if doc_type:
        where.append("doc_type=?")
        params.append(_clean(doc_type, 40))
    if date_from:
        where.append("date(created_at) >= date(?)")
        params.append(_clean(date_from, 20))
    if date_to:
        where.append("date(created_at) <= date(?)")
        params.append(_clean(date_to, 20))
    sql = "SELECT * FROM document_archive"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY id DESC LIMIT ?"
    params.append(max(1, min(int(limit or 300), 2000)))
    return _rows_dict(self.db.all(sql, params))


@_domain
def search_document_archive(self: AppService, term: str = "", doc_type: str = "", date_from: str = "", date_to: str = "") -> list[dict[str, Any]]:
    return search_archive(self, term, doc_type, date_from, date_to)


@_domain
def search_archives(self: AppService, query: str = "", doc_type: str = "", date_from: str = "", date_to: str = "", limit: int = 300) -> list[dict[str, Any]]:
    return search_archive(self, query, doc_type, date_from, date_to, limit)


@_domain
def list_archived_documents(self: AppService, doc_type: str = "", limit: int = 300) -> list[dict[str, Any]]:
    return search_archive(self, "", doc_type, "", "", limit)


@_domain
def get_archived_document(self: AppService, archive_id: int) -> dict[str, Any] | None:
    _ensure_document_archive_schema(self)
    return _row_dict(self.db.one("SELECT * FROM document_archive WHERE id=?", (int(archive_id),)))


@_domain
def get_document_content(self: AppService, archive_id: int) -> str:
    row = get_archived_document(self, archive_id)
    if not row:
        raise ValueError("المستند المؤرشف غير موجود")
    content = str(row.get("content_text") or "")
    if content:
        return content
    file_path = str(row.get("file_path") or "")
    if file_path:
        path = Path(file_path).expanduser()
        if path.exists() and path.is_file():
            try:
                return path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                return path.read_text(encoding="utf-8", errors="replace")
    return ""


@_domain
def next_document_no(self: AppService, kind: str = "sale", prefix: str = "MAX") -> str:
    """Generate a display-safe document number from current DB state."""
    kind = _clean(kind, 30).lower() or "sale"
    prefix = _slug(prefix, "MAX").upper()
    today = datetime.now().strftime("%Y%m%d")
    table_map = {
        "sale": ("sales", "invoice_no"),
        "invoice": ("sales", "invoice_no"),
        "return": ("returns", "return_no"),
        "purchase": ("purchases", "purchase_no"),
        "receipt": ("customer_payments", "receipt_no"),
    }
    table, column = table_map.get(kind, ("document_archive", "doc_no"))
    seq = 1
    if _table_exists(self, table):
        try:
            pattern = f"{prefix}-{today}-%"
            row = self.db.one(f"SELECT COUNT(*) AS c FROM {table} WHERE {column} LIKE ?", (pattern,))
            seq = int(row["c"] or 0) + 1 if row else 1
        except Exception:
            seq = 1
    return f"{prefix}-{today}-{seq:04d}"


@_domain
def generate_document_number(self: AppService, kind: str = "sale", prefix: str = "MAX") -> str:
    return next_document_no(self, kind, prefix)


@_domain
def backup_database(self: AppService, user_id: int | None = None, system: bool = False) -> Path:
    """Create a consistent SQLite backup file using the sqlite backup API."""
    if not system:
        _require_permission_if_available(self, ("can_backup", "can_tools"), "إنشاء نسخة احتياطية")
    backups = backup_dir(self)
    db_path = Path(getattr(self.db, "path", "database/max_sales.db")).expanduser().resolve()
    if not db_path.exists():
        raise ValueError("ملف قاعدة البيانات غير موجود")
    target = backups / f"max_sales_qt_backup_{_now_stamp()}.db"
    conn = getattr(self.db, "conn", None)
    if isinstance(conn, sqlite3.Connection):
        dest = sqlite3.connect(target)
        try:
            conn.backup(dest)
        finally:
            dest.close()
    else:
        shutil.copy2(db_path, target)
    try:
        if hasattr(self, "log"):
            self.log("نسخة احتياطية", str(target), user_id)
    except Exception:
        pass
    return target


@_domain
def create_backup(self: AppService, user_id: int | None = None, system: bool = False) -> Path:
    return backup_database(self, user_id=user_id, system=system)


@_domain
def list_backups(self: AppService, limit: int = 200) -> list[dict[str, Any]]:
    backups = backup_dir(self)
    rows: list[dict[str, Any]] = []
    for path in sorted(backups.glob("*.db"), key=lambda item: item.stat().st_mtime, reverse=True)[: max(1, limit)]:
        stat = path.stat()
        rows.append(
            {
                "name": path.name,
                "path": str(path),
                "size_bytes": stat.st_size,
                "modified_at": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                "sha256": _sha256_file(path),
            }
        )
    return rows


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


@_domain
def test_backup_integrity(self: AppService, path: str | Path | None = None) -> tuple[bool, str]:
    target = Path(path).expanduser() if path else None
    if target is None:
        backups = list_backups(self, 1)
        if not backups:
            return False, "لا توجد نسخ احتياطية لفحصها"
        target = Path(backups[0]["path"])
    if not target.exists():
        return False, "ملف النسخة الاحتياطية غير موجود"
    try:
        conn = sqlite3.connect(target)
        try:
            row = conn.execute("PRAGMA integrity_check").fetchone()
            result = str(row[0]) if row else "unknown"
        finally:
            conn.close()
        if result.lower() == "ok":
            return True, "النسخة الاحتياطية سليمة"
        return False, f"فحص SQLite لم ينجح: {result}"
    except Exception as exc:
        return False, f"تعذر فحص النسخة: {exc}"


@_domain
def verify_backup(self: AppService, path: str | Path | None = None) -> tuple[bool, str]:
    return test_backup_integrity(self, path)


@_domain
def auto_backup_if_due(self: AppService) -> tuple[bool, str]:
    enabled = _setting(self, "auto_backup_enabled", "1").lower()
    if enabled not in {"1", "true", "yes", "نعم"}:
        return False, "النسخ الاحتياطي التلقائي غير مفعل"
    today = _today()
    if _setting(self, "last_auto_backup_date", "") == today:
        return False, "تم إنشاء نسخة اليوم مسبقاً"
    try:
        path = backup_database(self, system=True)
        try:
            if hasattr(self, "save_settings"):
                self.save_settings({"last_auto_backup_date": today})
        except Exception:
            pass
        return True, str(path)
    except Exception as exc:
        return False, f"فشل النسخ الاحتياطي: {exc}"


@_domain
def backup_on_close_if_enabled(self: AppService) -> tuple[bool, str]:
    enabled = _setting(self, "auto_backup_on_close", "0").lower()
    if enabled not in {"1", "true", "yes", "نعم"}:
        return False, "النسخ الاحتياطي عند الإغلاق غير مفعل"
    try:
        path = backup_database(self, system=True)
        return True, str(path)
    except Exception as exc:
        return False, f"فشل النسخ الاحتياطي عند الإغلاق: {exc}"


@_domain
def print_invoice(self: AppService, invoice_no: str) -> Path:
    if hasattr(self, "print_invoice_html"):
        return self.print_invoice_html(invoice_no)
    raise AttributeError("print_invoice_html غير متوفرة في الخدمة الحالية")


@_domain
def print_receipt(self: AppService, receipt_id: int | str) -> Path:
    if hasattr(self, "print_payment_receipt_html"):
        return self.print_payment_receipt_html(int(receipt_id))
    raise AttributeError("print_payment_receipt_html غير متوفرة في الخدمة الحالية")
