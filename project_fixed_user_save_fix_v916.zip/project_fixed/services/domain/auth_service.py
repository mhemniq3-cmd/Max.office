from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength
from services.error_logger import log_exception
from services.core_common import ROLE_PERMISSIONS


class AuthServiceMixin:
        def __init__(self, db: Database):
            self.db = db
            self.current_user_id: int | None = None

        def roles(self) -> list[str]:
            return list(ROLE_PERMISSIONS.keys())

        def role_permissions(self, role: str) -> dict[str, int]:
            return dict(ROLE_PERMISSIONS.get(role, ROLE_PERMISSIONS['كاشير']))

        def log(self, action: str, details: str = '', user_id: int | None = None, username: str = '') -> None:
            try:
                if user_id and not username:
                    row = self.db.one('SELECT username FROM users WHERE id=?', (user_id,))
                    username = row['username'] if row else ''
                self.db.execute(
                    'INSERT INTO activity_logs (user_id, username, action, details, created_at) VALUES (?, ?, ?, ?, ?)',
                    (user_id, username, action, details, now_text()),
                )
            except Exception as exc:
                log_exception(exc)

        def user_has(self, user, permission: str) -> bool:
            if not user:
                return False
            if self.is_admin_user(user):
                return True
            try:
                return bool(user[permission])
            except Exception:
                return False

        def _user_value(self, user, key: str, default=None):
            if not user:
                return default
            try:
                return user[key]
            except Exception:
                try:
                    return user.get(key, default)
                except Exception:
                    return default

        def set_current_user(self, user_or_id) -> None:
            """Bind service calls to the logged-in user for permission checks."""
            if user_or_id is None:
                self.current_user_id = None
                return
            try:
                self.current_user_id = int(user_or_id['id'])
            except Exception:
                self.current_user_id = int(user_or_id)

        def current_user(self):
            if not self.current_user_id:
                return None
            return self.db.one('SELECT * FROM users WHERE id=? AND active=1', (self.current_user_id,))

        def _effective_user(self, user_id: int | None = None):
            uid = user_id if user_id is not None else self.current_user_id
            if not uid:
                return None
            return self.db.one('SELECT * FROM users WHERE id=? AND active=1', (uid,))

        def is_admin_user(self, user) -> bool:
            """Return True only when the user's role is explicitly an admin role.

            Previously this also returned True for any user holding both
            can_users + can_goals, which allowed privilege escalation when those
            permissions were granted independently.
            """
            if not user:
                return False
            role = str(self._user_value(user, 'role', '') or '').strip().lower()
            return role in ('مدير', 'مدير النظام', 'admin', 'administrator')

        def require_permission(self, permission: str, user_id: int | None = None, action: str = 'تنفيذ العملية'):
            user = self._effective_user(user_id)
            if not user:
                raise PermissionError('لا توجد جلسة مستخدم صالحة')
            if bool(self._user_value(user, 'must_change_password', 0)):
                raise PermissionError('يجب تغيير كلمة المرور قبل استخدام النظام')
            if self.user_has(user, permission):
                return user
            raise PermissionError(f'لا تملك صلاحية {action}')

        def require_any_permission(self, permissions: tuple[str, ...] | list[str], user_id: int | None = None, action: str = 'تنفيذ العملية'):
            user = self._effective_user(user_id)
            if not user:
                raise PermissionError('لا توجد جلسة مستخدم صالحة')
            if bool(self._user_value(user, 'must_change_password', 0)):
                raise PermissionError('يجب تغيير كلمة المرور قبل استخدام النظام')
            if self.is_admin_user(user) or any(self.user_has(user, p) for p in permissions):
                return user
            raise PermissionError(f'لا تملك صلاحية {action}')

        def employee_for_user(self, user):
            """Return the employee row linked to the current login by full name or username.
    
            The current schema does not yet have employees.user_id, so this safe matcher
            keeps goals private by matching the employee name to the user's full name,
            then username as a fallback.
            """
            if not user:
                return None
            names = []
            for key in ('full_name', 'username'):
                value = str(self._user_value(user, key, '') or '').strip()
                if value and value not in names:
                    names.append(value)
            if not names:
                return None
            employees = self.list_employees()
            def norm(text):
                return ' '.join(str(text or '').strip().lower().split())
            wanted = {norm(x) for x in names}
            for emp in employees:
                if norm(emp['name']) in wanted:
                    return emp
            return None

        def employee_id_for_user(self, user):
            emp = self.employee_for_user(user)
            return emp['id'] if emp else None

        def authenticate(self, username: str, password: str):
            username = (username or '').strip()
            if not username or not password:
                self.log('فشل دخول', 'بيانات ناقصة', username=username)
                return None
            user = self.db.one('SELECT * FROM users WHERE username=? AND active=1', (username,))
            if user and verify_password(password, user['password_hash']):
                updates = ['last_login_at=?']
                params: list[object] = [now_text()]
                # Seamlessly migrate legacy SHA-256 hashes to salted PBKDF2 after a successful login.
                if password_needs_rehash(user['password_hash']):
                    updates.append('password_hash=?')
                    params.append(password_hash(password))
                params.append(user['id'])
                self.db.execute(f'UPDATE users SET {", ".join(updates)} WHERE id=?', params)
                self.current_user_id = int(user['id'])
                self.log('تسجيل دخول', 'دخول ناجح للنظام', user['id'], user['username'])
                return self.db.one('SELECT * FROM users WHERE id=?', (user['id'],))
            self.log('فشل دخول', 'اسم مستخدم أو كلمة مرور غير صحيحة', username=username)
            return None

        def must_change_password(self, user) -> bool:
            return bool(user and 'must_change_password' in user.keys() and user['must_change_password'])

        def change_password(self, user_id: int, old_password: str, new_password: str) -> None:
            row = self.db.one('SELECT username, password_hash FROM users WHERE id=? AND active=1', (user_id,))
            if not row or not verify_password(old_password, row['password_hash']):
                raise ValueError('كلمة المرور الحالية غير صحيحة')
            validate_password_strength(new_password, row['username'])
            if str(new_password) == str(old_password):
                raise ValueError('كلمة المرور الجديدة يجب أن تختلف عن الحالية')
            self.db.execute('UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?', (password_hash(new_password), user_id))
            self.log('تغيير كلمة مرور', 'تم تغيير كلمة المرور', user_id)

        def list_users(self, include_inactive: bool = True):
            self.require_permission('can_users', action='عرض المستخدمين')
            if include_inactive:
                return self.db.all('SELECT * FROM users ORDER BY active DESC, username')
            return self.db.all('SELECT * FROM users WHERE active=1 ORDER BY username')

        def save_user(self, data: dict, user_id: int | None = None) -> None:
            self.require_permission('can_users', action='حفظ المستخدمين')
            username = (data.get('username') or '').strip()
            full_name = (data.get('full_name') or '').strip()
            password = (data.get('password') or '').strip()
            role = (data.get('role') or 'كاشير').strip()
            if not username:
                raise ValueError('اسم المستخدم مطلوب')
            if not user_id and not password:
                raise ValueError('كلمة المرور مطلوبة للمستخدم الجديد')
            if password:
                validate_password_strength(password, username)
            perms_data = self.role_permissions(role)
            for key in perms_data:
                if key in data:
                    perms_data[key] = 1 if data.get(key) else 0
            core_cols = ['can_dashboard', 'can_sales', 'can_products', 'can_customers', 'can_returns', 'can_reports', 'can_users', 'can_tools']
            params = (username, full_name, role, *[perms_data[k] for k in core_cols])
            if user_id:
                if password:
                    self.db.execute('''UPDATE users SET username=?, full_name=?, role=?, can_dashboard=?, can_sales=?, can_products=?, can_customers=?, can_returns=?, can_reports=?, can_users=?, can_tools=?, password_hash=?, must_change_password=1 WHERE id=?''', (*params, password_hash(password), user_id))
                else:
                    self.db.execute('''UPDATE users SET username=?, full_name=?, role=?, can_dashboard=?, can_sales=?, can_products=?, can_customers=?, can_returns=?, can_reports=?, can_users=?, can_tools=? WHERE id=?''', (*params, user_id))
                target_id = user_id
            else:
                self.db.execute('''INSERT INTO users (username, password_hash, full_name, role, can_dashboard, can_sales, can_products, can_customers, can_returns, can_reports, can_users, can_tools, must_change_password, active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, ?)''', (username, password_hash(password), full_name, role, *[perms_data[k] for k in core_cols], now_text()))
                target_id = self.db.one('SELECT id FROM users WHERE username=?', (username,))['id']
            for key, val in perms_data.items():
                try:
                    self.db.execute(f'UPDATE users SET {key}=? WHERE id=?', (1 if val else 0, target_id))
                except Exception as exc:
                    log_exception(exc)
            self.log('حفظ مستخدم', username)

        def deactivate_user(self, user_id: int) -> None:
            self.require_permission('can_users', action='تعطيل المستخدمين')
            admin_count = self.db.one('SELECT COUNT(*) c FROM users WHERE active=1 AND can_users=1')
            user = self.db.one('SELECT can_users FROM users WHERE id=?', (user_id,))
            if user and user['can_users'] and admin_count and admin_count['c'] <= 1:
                raise ValueError('لا يمكن تعطيل آخر مستخدم لديه صلاحية إدارة المستخدمين')
            self.db.execute('UPDATE users SET active=0 WHERE id=?', (user_id,))
            self.log('تعطيل مستخدم', str(user_id))
