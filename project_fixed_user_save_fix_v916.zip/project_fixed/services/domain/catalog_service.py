from services.core_common import *


class CatalogServiceMixin:
        def list_products(self, term: str = ''):
            term = term.strip()
            if term:
                like = f'%{term}%'
                return self.db.all('''SELECT * FROM products WHERE active=1 AND (name LIKE ? OR barcode LIKE ? OR category LIKE ?) ORDER BY name LIMIT 500''', (like, like, like))
            return self.db.all('SELECT * FROM products WHERE active=1 ORDER BY name LIMIT 500')

        def get_product_by_barcode(self, barcode: str):
            barcode = (barcode or '').strip()
            if not barcode:
                return None
            return self.db.one('SELECT * FROM products WHERE active=1 AND barcode=?', (barcode,))

        def lookup_barcode_online(self, barcode: str) -> dict | None:
            """Try to fetch product name/category from a public barcode database.
    
            This is optional and best-effort. It works for many packaged grocery items,
            but prices and local stock must still be entered manually.
            """
            barcode = (barcode or '').strip()
            if not barcode:
                return None
            url = f'https://world.openfoodfacts.org/api/v2/product/{barcode}.json'
            try:
                req = urllib.request.Request(url, headers={'User-Agent': 'MaxSalesQt/1.0'})
                with urllib.request.urlopen(req, timeout=6) as resp:
                    payload = json.loads(resp.read().decode('utf-8', errors='ignore'))
            except Exception:
                return None
            if not payload or payload.get('status') != 1:
                return None
            prod = payload.get('product') or {}
            name = (prod.get('product_name_ar') or prod.get('product_name') or prod.get('generic_name_ar') or prod.get('generic_name') or '').strip()
            category = (prod.get('categories') or prod.get('categories_tags', [''])[0] if prod.get('categories_tags') else '').strip()
            if category and ',' in category:
                category = category.split(',')[0].strip()
            if not name:
                return None
            return {'barcode': barcode, 'name': name, 'category': category}

        def save_product(self, data: dict, product_id: int | None = None) -> None:
            self.require_permission('can_product_edit' if product_id else 'can_product_add', action='حفظ المنتجات')
            barcode = (data.get('barcode') or '').strip() or None
            name = (data.get('name') or '').strip()
            if not name:
                raise ValueError('اسم المنتج مطلوب')
            category = (data.get('category') or '').strip()
            cost = to_float(data.get('cost_price'))
            price = to_float(data.get('sale_price'))
            qty = to_int(data.get('quantity'))
            min_qty = to_int(data.get('min_quantity'), 5)
            commission = to_float(data.get('commission_percent'))
            if min(cost, price, qty, min_qty, commission) < 0:
                raise ValueError('القيم لا يمكن أن تكون سالبة')
            if commission > 100:
                raise ValueError('نسبة العمولة لا يمكن أن تتجاوز 100%')
            if barcode:
                other = self.db.one('SELECT id FROM products WHERE barcode=? AND (? IS NULL OR id<>?)', (barcode, product_id, product_id))
                if other:
                    raise ValueError('هذا الباركود مستخدم مسبقاً لمنتج آخر')
            if product_id:
                oldp = self.db.one('SELECT * FROM products WHERE id=?', (product_id,))
                if oldp:
                    if (float(oldp['sale_price']) != float(price) or float(oldp['cost_price']) != float(cost)):
                        self.require_permission('can_price_edit', action='تعديل أسعار المنتجات')
                    if int(oldp['quantity']) != int(qty):
                        self.require_permission('can_quantity_edit', action='تعديل كمية المنتجات')
                self.db.execute('''UPDATE products SET barcode=?, name=?, category=?, cost_price=?, sale_price=?, quantity=?, min_quantity=?, commission_percent=? WHERE id=?''', (barcode, name, category, cost, price, qty, min_qty, commission, product_id))
                if oldp:
                    changes=[]
                    if float(oldp['sale_price']) != float(price): changes.append(f"سعر البيع {oldp['sale_price']} -> {price}")
                    if float(oldp['cost_price']) != float(cost): changes.append(f"سعر الشراء {oldp['cost_price']} -> {cost}")
                    if int(oldp['quantity']) != int(qty): changes.append(f"الكمية {oldp['quantity']} -> {qty}")
                    if changes: self.log('تدقيق تعديل منتج', name + ': ' + ' | '.join(changes))
            else:
                self.db.execute('''INSERT INTO products (barcode, name, category, cost_price, sale_price, quantity, min_quantity, commission_percent, active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)''', (barcode, name, category, cost, price, qty, min_qty, commission, now_text()))
            self.log('حفظ منتج', name)

        def deactivate_product(self, product_id: int) -> None:
            self.require_permission('can_product_delete', action='حذف المنتجات')
            self.db.execute('UPDATE products SET active=0 WHERE id=?', (product_id,))
            self.log('تعطيل منتج', str(product_id))

        def generate_barcode_value(self, product_id: int) -> str:
            self.require_permission('can_product_edit', action='توليد باركود للمنتجات')
            row = self.db.one('SELECT barcode FROM products WHERE id=?', (product_id,))
            if not row:
                raise ValueError('المنتج غير موجود')
            code = row['barcode'] or f'MAX{product_id:08d}'
            self.db.execute('UPDATE products SET barcode=? WHERE id=?', (code, product_id))
            return code

        def adjust_inventory(self, product_id: int, new_quantity: int, note: str = '', user_id: int | None = None) -> None:
            user = self.require_any_permission(('can_quantity_edit', 'can_inventory'), user_id, 'تعديل المخزون')
            user_id = user['id']
            if new_quantity < 0:
                raise ValueError('الكمية لا يمكن أن تكون سالبة')
            row = self.db.one('SELECT quantity FROM products WHERE id=?', (product_id,))
            if not row:
                raise ValueError('المنتج غير موجود')
            old = int(row['quantity'])
            change = int(new_quantity) - old
            with self.db.conn:
                self.db.conn.execute('UPDATE products SET quantity=? WHERE id=?', (new_quantity, product_id))
                self.db.conn.execute('''INSERT INTO inventory_movements (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (product_id, 'تعديل يدوي', change, old, new_quantity, 'manual', '', note.strip(), user_id, now_text()))
            self.log('تعديل مخزون', f'منتج {product_id}: {old} -> {new_quantity}', user_id)

        def inventory_movements(self, limit: int = 300):
            return self.db.all('''SELECT m.*, p.name product_name FROM inventory_movements m JOIN products p ON p.id=m.product_id ORDER BY m.id DESC LIMIT ?''', (limit,))

        def low_stock_rows(self):
            return self.db.all('SELECT * FROM products WHERE active=1 AND quantity <= min_quantity ORDER BY quantity ASC, name')

        def low_stock_details(self):
            return self.db.all('SELECT id, barcode, name, category, quantity, min_quantity FROM products WHERE active=1 AND quantity <= min_quantity ORDER BY quantity ASC, name')
