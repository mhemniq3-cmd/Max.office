from services.core_common import *


class GoalsAuditServiceMixin:
        def save_employee_goal(
            self,
            employee_id: int,
            period_type: str,
            period_start: str,
            target_sales: float,
            bonus_amount: float = 0,
            note: str = '',
            goal_type: str = 'مبيعات',
            scope_type: str = 'موظف',
            target_product_id=None,
            reward_type: str = 'مبلغ ثابت',
            reward_rate: float = 0,
            bonus_120: float = 0,
            bonus_150: float = 0,
        ) -> None:
            self.require_permission('can_goals', action='حفظ أهداف الموظفين')
            if not employee_id:
                raise ValueError('اختر الموظف')
            if target_sales <= 0:
                raise ValueError('الهدف يجب أن يكون أكبر من صفر')
            goal_type = goal_type or 'مبيعات'
            if goal_type == 'بيع منتج معين' and not target_product_id:
                raise ValueError('اختر المنتج الخاص بهذا الهدف')
            if period_type not in ('يومي', 'أسبوعي', 'شهري', 'ربع سنوي', 'سنوي'):
                period_type = 'شهري'
            if reward_type not in ('مبلغ ثابت', 'نسبة من المبيعات', 'نسبة من الأرباح', 'مكافأة متدرجة'):
                reward_type = 'مبلغ ثابت'
            self.db.execute('''
                INSERT INTO employee_goals
                (employee_id, period_type, period_start, target_sales, bonus_amount, note, active, created_at,
                 goal_type, scope_type, target_product_id, reward_type, reward_rate, bonus_100, bonus_120, bonus_150)
                VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                employee_id, period_type, period_start.strip(), float(target_sales), float(bonus_amount), note.strip(), now_text(),
                goal_type, scope_type or 'موظف', target_product_id, reward_type, float(reward_rate or 0),
                float(bonus_amount or 0), float(bonus_120 or 0), float(bonus_150 or 0)
            ))
            self.log('حفظ هدف ومكافأة', f'{employee_id} - {goal_type} - {target_sales:,.0f}')
            try:
                self.audit('حفظ هدف موظف', f'الموظف={employee_id}, النوع={goal_type}, الفترة={period_type}, الهدف={target_sales:,.0f}')
            except Exception as exc:
                log_exception(exc)

        def _goal_period_bounds(self, period_type: str, period_start: str):
            from datetime import datetime, timedelta
            text = (period_start or '').strip()
            try:
                if period_type == 'يومي':
                    start = datetime.strptime(text[:10], '%Y-%m-%d')
                    end = start + timedelta(days=1)
                elif period_type == 'أسبوعي':
                    start = datetime.strptime(text[:10], '%Y-%m-%d')
                    end = start + timedelta(days=7)
                elif period_type == 'ربع سنوي':
                    if '-Q' in text:
                        year, q = text.split('-Q', 1)
                        month = (int(q[:1]) - 1) * 3 + 1
                        start = datetime(int(year), month, 1)
                    else:
                        dt = datetime.strptime(text[:7], '%Y-%m')
                        month = ((dt.month - 1) // 3) * 3 + 1
                        start = datetime(dt.year, month, 1)
                    month = start.month + 3
                    year = start.year + (month - 1) // 12
                    month = ((month - 1) % 12) + 1
                    end = datetime(year, month, 1)
                elif period_type == 'سنوي':
                    year = int(text[:4])
                    start = datetime(year, 1, 1)
                    end = datetime(year + 1, 1, 1)
                else:
                    start = datetime.strptime(text[:7], '%Y-%m')
                    month = start.month + 1
                    year = start.year + (month - 1) // 12
                    month = ((month - 1) % 12) + 1
                    end = datetime(year, month, 1)
            except Exception:
                now = datetime.now()
                start = datetime(now.year, now.month, 1)
                end = datetime(now.year + (now.month // 12), (now.month % 12) + 1, 1)
            return start.strftime('%Y-%m-%d %H:%M:%S'), end.strftime('%Y-%m-%d %H:%M:%S')

        def _goal_achievement(self, goal) -> float:
            start, end = self._goal_period_bounds(goal['period_type'], goal['period_start'])
            employee_id = goal['employee_id']
            goal_type = goal['goal_type'] or 'مبيعات'
            params = [employee_id, start, end]
            if goal_type == 'أرباح':
                row = self.db.one('SELECT COALESCE(SUM(total_profit),0) v FROM sales WHERE employee_id=? AND created_at>=? AND created_at<? AND status="completed"', tuple(params))
                ret = self.db.one('SELECT COALESCE(SUM(profit_amount),0) v FROM returns WHERE employee_id=? AND created_at>=? AND created_at<?', tuple(params))
                return float((row['v'] if row else 0) or 0) - float((ret['v'] if ret else 0) or 0)
            if goal_type == 'عدد فواتير':
                row = self.db.one('SELECT COUNT(*) v FROM sales WHERE employee_id=? AND created_at>=? AND created_at<? AND status="completed"', tuple(params))
                return float((row['v'] if row else 0) or 0)
            if goal_type == 'عدد منتجات مباعة':
                sold = self.db.one('''SELECT COALESCE(SUM(si.quantity),0) v
                    FROM sale_items si
                    JOIN sales s ON s.id=si.sale_id
                    WHERE s.employee_id=? AND s.created_at>=? AND s.created_at<? AND s.status="completed"''', tuple(params))
                returned = self.db.one('''SELECT COALESCE(SUM(quantity),0) v
                    FROM returns
                    WHERE employee_id=? AND created_at>=? AND created_at<?''', tuple(params))
                return max(float((sold['v'] if sold else 0) or 0) - float((returned['v'] if returned else 0) or 0), 0.0)
            if goal_type == 'تحصيل ديون':
                row = self.db.one('SELECT COALESCE(SUM(amount),0) v FROM customer_payments WHERE created_at>=? AND created_at<? AND status="completed"', (start, end))
                return float((row['v'] if row else 0) or 0)
            if goal_type == 'بيع منتج معين':
                product_id = goal['target_product_id']
                sold = self.db.one('''SELECT COALESCE(SUM(si.quantity),0) v
                    FROM sale_items si
                    JOIN sales s ON s.id=si.sale_id
                    WHERE s.employee_id=? AND s.created_at>=? AND s.created_at<? AND s.status="completed" AND si.product_id=?''', (employee_id, start, end, product_id))
                returned = self.db.one('''SELECT COALESCE(SUM(quantity),0) v
                    FROM returns
                    WHERE employee_id=? AND created_at>=? AND created_at<? AND product_id=?''', (employee_id, start, end, product_id))
                return max(float((sold['v'] if sold else 0) or 0) - float((returned['v'] if returned else 0) or 0), 0.0)
            if goal_type == 'تقليل المرتجعات':
                row = self.db.one('SELECT COALESCE(SUM(amount),0) v FROM returns WHERE employee_id=? AND created_at>=? AND created_at<?', tuple(params))
                returns_total = float((row['v'] if row else 0) or 0)
                limit = float(goal['target_sales'] or 0)
                return max(limit - returns_total, 0)
            row = self.db.one('SELECT COALESCE(SUM(total),0) v FROM sales WHERE employee_id=? AND created_at>=? AND created_at<? AND status="completed"', tuple(params))
            ret = self.db.one('SELECT COALESCE(SUM(amount),0) v FROM returns WHERE employee_id=? AND created_at>=? AND created_at<?', tuple(params))
            return float((row['v'] if row else 0) or 0) - float((ret['v'] if ret else 0) or 0)

        def _goal_reward(self, goal, achieved: float, ratio: float) -> float:
            if ratio < 100:
                return 0.0
            reward_type = goal['reward_type'] or 'مبلغ ثابت'
            if reward_type == 'مكافأة متدرجة':
                if ratio >= 150 and float(goal['bonus_150'] or 0) > 0:
                    return float(goal['bonus_150'] or 0)
                if ratio >= 120 and float(goal['bonus_120'] or 0) > 0:
                    return float(goal['bonus_120'] or 0)
                return float((goal['bonus_100'] or goal['bonus_amount'] or 0))
            if reward_type in ('نسبة من المبيعات', 'نسبة من الأرباح'):
                return max(achieved, 0) * float(goal['reward_rate'] or 0) / 100.0
            return float((goal['bonus_100'] or goal['bonus_amount'] or 0))

        def employee_goal_rows(self, user=None):
            params = []
            where = 'g.active=1'
            if user is not None and not self.is_admin_user(user):
                employee_id = self.employee_id_for_user(user)
                if not employee_id:
                    return []
                where += ' AND g.employee_id=?'
                params.append(employee_id)
            rows = self.db.all(f'''
                SELECT g.*, e.name employee, p.name product_name
                FROM employee_goals g
                JOIN employees e ON e.id=g.employee_id
                LEFT JOIN products p ON p.id=g.target_product_id
                WHERE {where}
                ORDER BY g.id DESC
            ''', params)
            result = []
            for row in rows:
                d = dict(row)
                achieved = self._goal_achievement(row)
                target = float(row['target_sales'] or 0)
                ratio = (achieved / target * 100) if target > 0 else 0
                remaining = max(target - achieved, 0)
                reward = self._goal_reward(row, achieved, ratio)
                d['achieved'] = achieved
                d['ratio'] = ratio
                d['remaining'] = remaining
                d['reward_amount'] = reward
                d['status_text'] = '✅ مكتمل' if ratio >= 100 else ('🔥 قريب جداً' if ratio >= 80 else ('⚠️ متأخر' if ratio < 50 else 'قيد المتابعة'))
                result.append(d)
            return result

        def delete_employee_goal(self, goal_id: int) -> None:
            self.require_permission('can_goals', action='تعطيل أهداف الموظفين')
            if not goal_id:
                raise ValueError('اختر الهدف المراد تعطيله')
            row = self.db.one('SELECT g.*, e.name employee FROM employee_goals g LEFT JOIN employees e ON e.id=g.employee_id WHERE g.id=? AND g.active=1', (goal_id,))
            if not row:
                raise ValueError('الهدف غير موجود أو تم تعطيله مسبقاً')
            self.db.execute('UPDATE employee_goals SET active=0 WHERE id=?', (goal_id,))
            self.log('تعطيل هدف موظف', f"{row['employee'] or row['employee_id']} - {row['goal_type']} - {row['target_sales']:,.0f}")
            try:
                self.audit('تعطيل هدف موظف', f"id={goal_id}, الموظف={row['employee'] or row['employee_id']}, النوع={row['goal_type']}")
            except Exception as exc:
                log_exception(exc)

        def audit_rows(self, limit: int = 500):
            self.require_permission('can_audit', action='عرض سجل التدقيق')
            return self.db.all('SELECT * FROM activity_logs ORDER BY id DESC LIMIT ?', (limit,))
