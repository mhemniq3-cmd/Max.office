from services.core_common import *


class PrintBackupServiceMixin:
        def get_settings(self) -> dict:
            return {row['key']: row['value'] for row in self.db.all('SELECT key, value FROM app_settings')}

        def save_settings(self, data: dict, user_id: int | None = None) -> None:
            backup_keys = {
                'max_backup_keep', 'auto_backup_on_open', 'auto_backup_on_close',
                'auto_backup_enabled', 'last_auto_backup_date', 'last_google_drive_backup_status',
                'last_google_drive_backup_at', 'google_drive_backup_enabled', 'google_drive_backup_path',
            }
            keys = {str(k) for k in data.keys()}
            if keys and keys.issubset(backup_keys):
                user = self.require_any_permission(('can_backup', 'can_settings', 'can_tools'), user_id, 'تعديل إعدادات النسخ الاحتياطي')
            else:
                user = self.require_any_permission(('can_settings', 'can_tools'), user_id, 'تعديل الإعدادات')
            user_id = user['id']
            for key, value in data.items():
                self.db.execute('INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (str(key), str(value)))
            self.log('تعديل إعدادات الشركة', ', '.join(data.keys()), user_id)

        def list_activity_logs(self, limit: int = 300):
            return self.db.all('SELECT * FROM activity_logs ORDER BY id DESC LIMIT ?', (limit,))

        def export_dir(self) -> Path:
            path = Path('exports')
            path.mkdir(exist_ok=True)
            return path

        def _html_page(self, title: str, body: str) -> Path:
            fn = self.export_dir() / f'{title}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.html'
            settings = self.get_settings()
            html_doc = f"""<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'><title>{html.escape(title)}</title><style>body{{font-family:Tahoma,Arial;margin:28px;color:#111}}.head{{text-align:center;border-bottom:2px solid #0f4c81;padding-bottom:12px}}table{{width:100%;border-collapse:collapse;margin-top:16px}}td,th{{border:1px solid #ddd;padding:8px;text-align:center}}th{{background:#eef6ff}}.total{{font-size:20px;font-weight:bold}}.muted{{color:#666}}</style></head><body><div class='head'><h2>{html.escape(settings.get('company_name','ماكس للمبيعات'))}</h2><div>{html.escape(settings.get('company_phone',''))} - {html.escape(settings.get('company_address',''))}</div></div>{body}<p class='muted'>{html.escape(settings.get('invoice_footer','شكراً لتعاملكم معنا'))}</p><script>window.print()</script></body></html>"""
            fn.write_text(html_doc, encoding='utf-8')
            return fn

        def invoice_details(self, invoice_no: str):
            sale = self.db.one('''SELECT s.*, e.name employee, COALESCE(c.name,'زبون عام') customer, COALESCE(NULLIF(u.full_name,''), u.username, '-') user_name FROM sales s JOIN employees e ON e.id=s.employee_id LEFT JOIN customers c ON c.id=s.customer_id LEFT JOIN users u ON u.id=s.user_id WHERE s.invoice_no=?''', (invoice_no,))
            if not sale:
                raise ValueError('الفاتورة غير موجودة')
            items = self.db.all('SELECT * FROM sale_items WHERE sale_id=? ORDER BY id', (sale['id'],))
            return sale, items

        def print_invoice_html(self, invoice_no: str) -> Path:
            sale, items = self.invoice_details(invoice_no)
            rows = ''.join(f"<tr><td>{html.escape(i['product_name'])}</td><td>{i['quantity']}</td><td>{money(i['unit_price'])}</td><td>{money(i['line_total'])}</td></tr>" for i in items)
            body = f"<h3>فاتورة بيع: {html.escape(sale['invoice_no'])}</h3><p>التاريخ: {sale['created_at']}<br>المستخدم: {html.escape(sale['user_name'])}<br>موظف العمولة: {html.escape(sale['employee'])}<br>الزبون: {html.escape(sale['customer'])}<br>الدفع: {html.escape(sale['payment_method'])}</p><table><tr><th>المادة</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr>{rows}</table><p class='total'>الصافي: {money(sale['total'])}</p>"
            return self._html_page('invoice_'+sale['invoice_no'].replace('/','_'), body)

        def print_return_html(self, return_no_value: str) -> Path:
            rows = self.db.all('''SELECT r.*, s.invoice_no FROM returns r JOIN sales s ON s.id=r.sale_id WHERE r.return_no=?''', (return_no_value,))
            if not rows:
                raise ValueError('وصل المرتجع غير موجود')
            rows_html = ''.join(f"<tr><td>{html.escape(r['product_name'])}</td><td>{r['quantity']}</td><td>{money(r['amount'])}</td><td>{html.escape(r['reason'] or '')}</td></tr>" for r in rows)
            total = sum(float(r['amount']) for r in rows)
            body = f"<h3>وصل مرتجع: {html.escape(return_no_value)}</h3><p>فاتورة أصلية: {html.escape(rows[0]['invoice_no'])}</p><table><tr><th>المادة</th><th>الكمية</th><th>المبلغ</th><th>السبب</th></tr>{rows_html}</table><p class='total'>إجمالي المرتجع: {money(total)}</p>"
            return self._html_page('return_'+return_no_value.replace('/','_'), body)

        def print_payment_receipt_html(self, payment_id: int) -> Path:
            row = self.db.one('''SELECT p.*, c.name customer FROM customer_payments p JOIN customers c ON c.id=p.customer_id WHERE p.id=?''', (payment_id,))
            if not row:
                raise ValueError('وصل القبض غير موجود')
            body = f"<h3>وصل قبض: {html.escape(row['receipt_no'] or str(row['id']))}</h3><p>الزبون: {html.escape(row['customer'])}<br>التاريخ: {row['created_at']}<br>الملاحظة: {html.escape(row['note'] or '')}</p><p class='total'>المبلغ: {money(row['amount'])}</p>"
            return self._html_page('payment_'+str(row['id']), body)

        def print_barcode_labels_html(self) -> Path:
            rows = self.list_products('')
            labels = ''.join(f"<div style='display:inline-block;border:1px dashed #aaa;margin:6px;padding:10px;width:180px;text-align:center'><b>{html.escape(p['name'])}</b><br><span style='font-size:20px;letter-spacing:2px'>{html.escape(p['barcode'] or ('MAX%08d'%p['id']))}</span><br>{money(p['sale_price'])}</div>" for p in rows)
            return self._html_page('barcode_labels', labels)

        def print_customer_statement_html(self, customer_id: int) -> Path:
            customer = self.db.one('SELECT * FROM customers WHERE id=?', (customer_id,))
            if not customer:
                raise ValueError('الزبون غير موجود')
            rows = self.customer_statement(customer_id)
            bal = 0.0; trs = ''
            for row in rows:
                bal += float(row['debit']) - float(row['credit'])
                trs += f"<tr><td>{html.escape(row['created_at'])}</td><td>{html.escape(row['kind'])}</td><td>{html.escape(row['ref'])}</td><td>{money(row['debit'])}</td><td>{money(row['credit'])}</td><td>{money(bal)}</td><td>{html.escape(str(row['note']))}</td></tr>"
            body = f"<h3>كشف حساب: {html.escape(customer['name'])}</h3><table><tr><th>التاريخ</th><th>النوع</th><th>المرجع</th><th>مدين</th><th>دائن</th><th>الرصيد</th><th>ملاحظة</th></tr>{trs}</table><p class='total'>الرصيد الحالي: {money(bal)}</p>"
            return self._html_page('statement_'+str(customer_id), body)

        def backup_database(self) -> Path:
            self.require_permission('can_backup', action='إنشاء نسخة احتياطية')
            backups = Path('backups')
            backups.mkdir(exist_ok=True)
            target = backups / f'max_sales_qt_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.db'
            shutil.copy2(self.db.path, target)
            self.log('نسخة احتياطية', str(target))
            return target

        def backup_dir(self) -> Path:
            path = Path('backups')
            path.mkdir(exist_ok=True)
            return path

        def auto_backup_if_due(self) -> tuple[bool, str]:
            settings = self.get_settings()
            if str(settings.get('auto_backup_enabled', '1')) not in ('1', 'true', 'True', 'نعم'):
                return False, 'النسخ الاحتياطي التلقائي غير مفعل'
            today = datetime.now().strftime('%Y-%m-%d')
            if settings.get('last_auto_backup_date') == today:
                return False, 'تم إنشاء نسخة اليوم مسبقاً'
            try:
                path = self.backup_database()
                self.save_settings({'last_auto_backup_date': today})
                return True, str(path)
            except Exception as exc:
                self.log('فشل النسخ الاحتياطي التلقائي', str(exc))
                return False, f'فشل النسخ الاحتياطي: {exc}'

        def restore_database(self, source: Path | str) -> None:
            self.require_permission('can_restore', action='استرجاع نسخة احتياطية')
            src = Path(source)
            if not src.exists():
                raise ValueError('ملف النسخة الاحتياطية غير موجود')
            self.db.close()
            shutil.copy2(src, self.db.path)
