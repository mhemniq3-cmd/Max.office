from __future__ import annotations

"""Safe system settings manager for Max Sales.

Stage 12 adds this module so administrators can manage runtime settings through
Domain code instead of editing ``.env`` manually.  The functions are designed to
be UI/API friendly and safe: values are validated, the .env file is backed up
before writes, and optional SQLite connections can mirror settings into the
``system_settings`` table and audit changes.
"""

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, InvalidOperation
import os
from pathlib import Path
import re
import shutil
from typing import Any

_ALLOWED_KEYS: dict[str, dict[str, Any]] = {
    "MAX_SALES_DOMAIN_STRICT_COMPARE": {"type": "bool", "default": "1", "restart_required": False},
    "MAX_SALES_DOMAIN_COMPARE_TOLERANCE": {"type": "decimal", "default": "0.01", "restart_required": False},
    "MAX_SALES_DOMAIN_COMPARE_LOG_PATH": {"type": "path", "default": "./logs", "restart_required": False},
    "MAX_SALES_BACKUP_PATH": {"type": "path", "default": "./backups", "restart_required": False},
    "MAX_SALES_EXPORT_PATH": {"type": "path", "default": "./exports", "restart_required": False},
    "MAX_SALES_ARCHIVE_PATH": {"type": "path", "default": "./archives", "restart_required": False},
    "MAX_SALES_DB_PATH": {"type": "path", "default": "", "restart_required": True},
    "MAX_SALES_LOG_PATH": {"type": "path", "default": "./logs/max_sales.log", "restart_required": False},
    "MAX_SALES_PRINTER_NAME": {"type": "str", "default": "", "restart_required": False},
    "MAX_SALES_PRINTER_PORT": {"type": "str", "default": "", "restart_required": False},
    "MAX_SALES_SQLITE_TIMEOUT": {"type": "decimal", "default": "10", "restart_required": True},
    "MAX_SALES_SQLITE_CACHE_KIB": {"type": "int", "default": "20000", "restart_required": True},
}

_KEY_RE = re.compile(r"^[A-Z][A-Z0-9_]{2,80}$")


@dataclass(frozen=True)
class ConfigEntry:
    key: str
    value: str
    source: str
    value_type: str = "str"
    restart_required: bool = False


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def default_env_path() -> Path:
    return Path(os.environ.get("MAX_SALES_ENV_PATH", project_root() / ".env")).resolve()


def known_settings() -> dict[str, dict[str, Any]]:
    return {key: dict(meta) for key, meta in _ALLOWED_KEYS.items()}


def _normalize_key(key: str) -> str:
    key = str(key or "").strip().upper()
    if not _KEY_RE.match(key):
        raise ValueError(f"Invalid settings key: {key!r}")
    if key not in _ALLOWED_KEYS:
        raise KeyError(f"Unsupported setting key: {key}")
    return key


def _parse_bool(value: str) -> str:
    value = str(value).strip().lower()
    if value in {"1", "true", "yes", "on", "enabled"}:
        return "1"
    if value in {"0", "false", "no", "off", "disabled"}:
        return "0"
    raise ValueError("Boolean settings must be 1/0, true/false, yes/no, or on/off")


def _safe_relative_path(value: str) -> str:
    raw = str(value).strip()
    if not raw:
        return ""
    path = Path(raw).expanduser()
    if path.is_absolute():
        # Absolute paths are allowed only when they are outside system roots that
        # are dangerous for accidental writes.  This is a guardrail, not a full
        # OS sandbox.
        forbidden = {Path("/"), Path("/bin"), Path("/sbin"), Path("/usr"), Path("/etc"), Path("/var"), Path("/root")}
        resolved = path.resolve()
        if resolved in forbidden:
            raise ValueError(f"Refusing sensitive system path: {resolved}")
        return str(resolved)
    return raw.replace("\\", "/")


def validate_config_value(key: str, value: Any) -> str:
    key = _normalize_key(key)
    value_type = _ALLOWED_KEYS[key]["type"]
    raw = "" if value is None else str(value).strip()
    if value_type == "bool":
        return _parse_bool(raw)
    if value_type == "decimal":
        try:
            parsed = Decimal(raw)
        except (InvalidOperation, ValueError) as exc:
            raise ValueError(f"{key} must be a decimal number") from exc
        if parsed < 0:
            raise ValueError(f"{key} cannot be negative")
        return format(parsed.normalize(), "f") if parsed != 0 else "0"
    if value_type == "int":
        try:
            parsed_int = int(raw)
        except ValueError as exc:
            raise ValueError(f"{key} must be an integer") from exc
        if parsed_int < 0:
            raise ValueError(f"{key} cannot be negative")
        return str(parsed_int)
    if value_type == "path":
        return _safe_relative_path(raw)
    return raw


def read_env_file(env_path: str | Path | None = None) -> dict[str, str]:
    path = Path(env_path or default_env_path())
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        key = key.strip()
        if key:
            values[key] = value.strip().strip('"').strip("'")
    return values


def ensure_system_settings_schema(db: Any) -> None:
    if db is None:
        return
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS system_settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_by INTEGER,
            updated_at TEXT NOT NULL
        )
        """
    )
    if hasattr(db, "commit"):
        db.commit()


def load_db_settings(db: Any) -> dict[str, str]:
    if db is None:
        return {}
    ensure_system_settings_schema(db)
    try:
        rows = db.execute("SELECT key, value FROM system_settings").fetchall()
    except Exception:
        return {}
    output: dict[str, str] = {}
    for row in rows:
        key = row[0] if not isinstance(row, dict) else row.get("key")
        value = row[1] if not isinstance(row, dict) else row.get("value")
        if key in _ALLOWED_KEYS:
            output[str(key)] = str(value)
    return output


def get_config(key: str, default: Any = None, *, db: Any = None, env_path: str | Path | None = None) -> str | Any:
    key = _normalize_key(key)
    if key in os.environ:
        return validate_config_value(key, os.environ[key])
    db_values = load_db_settings(db) if db is not None else {}
    if key in db_values:
        return validate_config_value(key, db_values[key])
    env_values = read_env_file(env_path)
    if key in env_values:
        return validate_config_value(key, env_values[key])
    if default is not None:
        return validate_config_value(key, default)
    return _ALLOWED_KEYS[key]["default"]


def list_config(*, db: Any = None, env_path: str | Path | None = None) -> list[ConfigEntry]:
    db_values = load_db_settings(db) if db is not None else {}
    env_values = read_env_file(env_path)
    entries: list[ConfigEntry] = []
    for key, meta in _ALLOWED_KEYS.items():
        if key in os.environ:
            value, source = os.environ[key], "environment"
        elif key in db_values:
            value, source = db_values[key], "database"
        elif key in env_values:
            value, source = env_values[key], "env_file"
        else:
            value, source = meta["default"], "default"
        entries.append(
            ConfigEntry(
                key=key,
                value=validate_config_value(key, value),
                source=source,
                value_type=meta["type"],
                restart_required=bool(meta.get("restart_required")),
            )
        )
    return entries


def _backup_env_file(path: Path) -> Path | None:
    if not path.exists():
        return None
    backup_dir = path.parent / ".env_backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = backup_dir / f"{path.name}.{stamp}.bak"
    shutil.copy2(path, target)
    return target


def _write_env_value(path: Path, key: str, value: str) -> Path | None:
    path.parent.mkdir(parents=True, exist_ok=True)
    backup = _backup_env_file(path)
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    updated = False
    out: list[str] = []
    for line in lines:
        if line.strip().startswith(f"{key}="):
            out.append(f"{key}={value}")
            updated = True
        else:
            out.append(line)
    if not updated:
        if out and out[-1].strip():
            out.append("")
        out.append(f"{key}={value}")
    path.write_text("\n".join(out) + "\n", encoding="utf-8")
    return backup


def _write_db_setting(db: Any, key: str, value: str, user_id: int | None) -> None:
    if db is None:
        return
    ensure_system_settings_schema(db)
    now = datetime.now().isoformat(timespec="seconds")
    db.execute(
        """
        INSERT INTO system_settings(key, value, updated_by, updated_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET
            value = excluded.value,
            updated_by = excluded.updated_by,
            updated_at = excluded.updated_at
        """,
        (key, value, user_id, now),
    )
    try:
        db.execute(
            """
            INSERT INTO audit_logs(user_id, action, entity, details, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (user_id, "update_config", "system_settings", f"{key}={value}", now),
        )
    except Exception:
        pass
    if hasattr(db, "commit"):
        db.commit()


def update_config(
    key: str,
    value: Any,
    user_id: int | None = None,
    *,
    db: Any = None,
    env_path: str | Path | None = None,
    write_env: bool = True,
    write_db: bool = True,
) -> dict[str, Any]:
    key = _normalize_key(key)
    normalized = validate_config_value(key, value)
    env_file = Path(env_path or default_env_path())
    backup: Path | None = None
    if write_env:
        backup = _write_env_value(env_file, key, normalized)
    if write_db and db is not None:
        _write_db_setting(db, key, normalized, user_id)
    os.environ[key] = normalized
    return {
        "key": key,
        "value": normalized,
        "env_path": str(env_file),
        "backup_path": str(backup) if backup else None,
        "restart_required": bool(_ALLOWED_KEYS[key].get("restart_required")),
    }


def export_settings_snapshot(*, db: Any = None, env_path: str | Path | None = None) -> dict[str, Any]:
    return {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "settings": [entry.__dict__ for entry in list_config(db=db, env_path=env_path)],
    }


READ_ONLY_METHODS = (
    "known_settings",
    "read_env_file",
    "get_config",
    "list_config",
    "validate_config_value",
    "export_settings_snapshot",
)

for _name in READ_ONLY_METHODS + ("update_config", "ensure_system_settings_schema", "load_db_settings"):
    _fn = globals().get(_name)
    if callable(_fn):
        setattr(_fn, "_domain_implementation", True)
