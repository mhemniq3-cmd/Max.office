from __future__ import annotations

from datetime import datetime
from typing import Any, Final, Iterable

DOMAIN: Final[str] = 'operations_core'
METHODS: Final[tuple[str, ...]] = (
    '__init__', '_v22_read_json_config', '_v22_root', '_v22_settings_folder', '_v22_write_json_config',
    'add_movement_manager_note', 'assert_fiscal_open', 'clean_text', 'cleanup_legacy_artifacts',
    'close_day', 'close_fiscal_period', 'complete_first_run_setup', 'db_transaction',
    'dedupe_existing_unified_movements', 'delete_or_deactivate_customer', 'ensure_unified_movement_schema',
    'ensure_v23_local_business_schema', 'filtered_operations', 'google_drive_status',
    'insert_unified_movement', 'is_fiscal_period_closed', 'list_activity_logs', 'list_customers',
    'list_fiscal_periods', 'list_system_movements', 'list_unified_movements', 'log',
    'log_system_movement', 'mark_movements_read', 'needs_first_run_setup', 'next_doc_no',
    'normalize_iso_date', 'normalize_search_date', 'notify_event', 'open_fiscal_period',
    'save_settings', 'sync_unified_movements', 'sync_unified_movements_stats', 'update_cost_average',
    'vacuum_and_compress_old_data', 'validate_common',
)

READ_ONLY_METHODS: Final[tuple[str, ...]] = (
    'normalize_date_format',
    'normalize_record_dates',
    'normalize_records_dates',
)


def domain_function(fn):
    setattr(fn, '_domain_implementation', True)
    return fn


def _rowdict(row: Any) -> dict[str, Any]:
    if row is None:
        return {}
    try:
        return dict(row)
    except Exception:
        return {}


def _rows(rows: Iterable[Any]) -> list[dict[str, Any]]:
    return [_rowdict(row) for row in rows]


def _table_exists(self: Any, table: str) -> bool:
    return bool(self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)))


def _columns(self: Any, table: str) -> set[str]:
    try:
        return {str(row[1]) for row in self.db.conn.execute(f'PRAGMA table_info({table})')}
    except Exception:
        return set()


def _limit(value: Any, default: int = 500, maximum: int = 5000) -> int:
    try:
        return max(1, min(int(value or default), maximum))
    except Exception:
        return default


@domain_function
def clean_text(value: Any, max_length: int = 500) -> str:
    text = str(value or '').replace('\x00', '').strip()
    text = ' '.join(text.split())
    return text[:max(1, int(max_length or 500))]


@domain_function
def normalize_iso_date(self: Any, value: Any) -> str:
    text = str(value or '').strip()[:10]
    if not text:
        return ''
    for fmt in ('%Y-%m-%d', '%Y/%m/%d', '%d-%m-%Y', '%d/%m/%Y'):
        try:
            return datetime.strptime(text, fmt).strftime('%Y-%m-%d')
        except Exception:
            pass
    return text if len(text) == 10 else ''


@domain_function
def normalize_search_date(self: Any, value: Any) -> str:
    return normalize_iso_date(self, value)

@domain_function
def normalize_date_format(self: Any, value: Any, output_format: str = '%Y-%m-%d') -> str:
    """Normalize legacy date values into one display/search format.

    Supports common legacy formats such as DD/MM/YYYY, DD-MM-YYYY, YYYY/MM/DD,
    ISO datetimes, and Unix timestamps. Invalid or empty values return ''.
    """
    if value in (None, ''):
        return ''
    text = str(value).replace('\x00', '').strip()
    if not text:
        return ''
    if text.isdigit() and len(text) in {10, 13}:
        try:
            stamp = int(text[:10])
            return datetime.fromtimestamp(stamp).strftime(output_format)
        except Exception:
            pass
    # Strip time and timezone fragments before trying date-only formats.
    compact = text.replace('T', ' ').split('+', 1)[0].split('Z', 1)[0].strip()
    date_part = compact.split(' ', 1)[0]
    candidates = (compact, date_part)
    formats = (
        '%Y-%m-%d %H:%M:%S', '%Y/%m/%d %H:%M:%S', '%d/%m/%Y %H:%M:%S', '%d-%m-%Y %H:%M:%S',
        '%Y-%m-%d', '%Y/%m/%d', '%d-%m-%Y', '%d/%m/%Y', '%m/%d/%Y', '%m-%d-%Y',
    )
    for candidate in candidates:
        for fmt in formats:
            try:
                return datetime.strptime(candidate[:19], fmt).strftime(output_format)
            except Exception:
                pass
    return date_part[:10] if len(date_part) >= 10 else ''


_DATE_FIELD_NAMES: Final[tuple[str, ...]] = (
    'date', 'created_at', 'updated_at', 'invoice_date', 'payment_date', 'return_date',
    'opened_at', 'closed_at', 'due_date', 'doc_date', 'event_time', 'login_time', 'last_login',
)


@domain_function
def normalize_record_dates(self: Any, record: dict[str, Any] | None, output_format: str = '%Y-%m-%d') -> dict[str, Any]:
    """Return a copy of one record with known date fields normalized."""
    data = dict(record or {})
    for key in list(data.keys()):
        if key in _DATE_FIELD_NAMES or key.endswith('_date') or key.endswith('_at'):
            normalized = normalize_date_format(self, data.get(key), output_format=output_format)
            if normalized:
                data[key] = normalized
    return data


@domain_function
def normalize_records_dates(self: Any, records: Iterable[dict[str, Any]] | None, output_format: str = '%Y-%m-%d') -> list[dict[str, Any]]:
    """Normalize date fields in a list of dictionaries."""
    return [normalize_record_dates(self, row, output_format=output_format) for row in (records or [])]


@domain_function
def list_activity_logs(self: Any, limit: int = 300, term: str = '') -> list[dict[str, Any]]:
    if not _table_exists(self, 'activity_logs'):
        return []
    params: list[Any] = []
    where = ''
    q = clean_text(term, 200)
    if q:
        where = 'WHERE action LIKE ? OR details LIKE ? OR username LIKE ?'
        like = f'%{q}%'
        params.extend([like, like, like])
    params.append(_limit(limit, 300, 3000))
    return _rows(self.db.all(f'SELECT * FROM activity_logs {where} ORDER BY datetime(created_at) DESC, id DESC LIMIT ?', params))


@domain_function
def list_customers(self: Any, active_only: bool = True) -> list[dict[str, Any]]:
    if not _table_exists(self, 'customers'):
        return []
    where = 'WHERE COALESCE(active,1)=1' if active_only else ''
    return _rows(self.db.all(f'SELECT * FROM customers {where} ORDER BY name'))


@domain_function
def list_system_movements(self: Any, limit: int = 500, term: str = '', source: str = '') -> list[dict[str, Any]]:
    if not _table_exists(self, 'system_movements'):
        return []
    clauses: list[str] = []
    params: list[Any] = []
    q = clean_text(term, 200)
    if q:
        like = f'%{q}%'
        clauses.append('(action LIKE ? OR details LIKE ? OR username LIKE ? OR table_name LIKE ? OR CAST(record_id AS TEXT) LIKE ?)')
        params.extend([like, like, like, like, like])
    src = clean_text(source, 80)
    if src:
        clauses.append('source=?')
        params.append(src)
    where = 'WHERE ' + ' AND '.join(clauses) if clauses else ''
    params.append(_limit(limit, 500, 3000))
    return _rows(self.db.all(f'SELECT * FROM system_movements {where} ORDER BY datetime(event_time) DESC, id DESC LIMIT ?', params))


@domain_function
def list_unified_movements(self: Any, limit: int = 500, **filters: Any) -> list[dict[str, Any]]:
    if not _table_exists(self, 'unified_movement_log'):
        return []
    clauses: list[str] = []
    params: list[Any] = []
    term = clean_text(filters.get('term', ''), 200)
    if term:
        like = f'%{term}%'
        clauses.append('(action LIKE ? OR description LIKE ? OR user_name LIKE ? OR module LIKE ? OR record_type LIKE ? OR CAST(record_id AS TEXT) LIKE ?)')
        params.extend([like, like, like, like, like, like])
    mode = str(filters.get('mode') or 'all')
    if mode == 'daily':
        clauses.append("date(event_time)=date('now','localtime')")
    elif mode == 'sensitive':
        clauses.append('(is_sensitive=1 OR severity IN (?,?))')
        params.extend(['حساس', 'خطر'])
    elif mode == 'fraud':
        clauses.append("(source_table='fraud_alerts' OR action LIKE ? OR module LIKE ?)")
        params.extend(['%احتيال%', '%احتيال%'])
    severity = clean_text(filters.get('severity', ''), 30)
    if severity and severity != 'الكل':
        clauses.append('severity=?')
        params.append(severity)
    module = clean_text(filters.get('module', ''), 80)
    if module and module != 'كل الأقسام':
        clauses.append('module=?')
        params.append(module)
    where = 'WHERE ' + ' AND '.join(clauses) if clauses else ''
    params.append(_limit(limit, 500, 5000))
    return _rows(self.db.all(f'''
        SELECT id, event_key, event_time, user_id, user_name, module, action, record_type, record_id,
               description, old_values, new_values, severity, source_table, source_id, is_sensitive, is_read, manager_note
          FROM unified_movement_log {where}
         ORDER BY datetime(event_time) DESC, id DESC LIMIT ?
    ''', params))


@domain_function
def filtered_operations(self: Any, date_from: str = '', date_to: str = '', employee: str = '', customer: str = '', product: str = '', payment_method: str = '', category: str = '', operation_type: str = '', limit: int = 1000) -> list[dict[str, Any]]:
    clauses: list[str] = []
    params: list[Any] = []
    if date_from:
        clauses.append('date(s.created_at) >= date(?)')
        params.append(normalize_search_date(self, date_from))
    if date_to:
        clauses.append('date(s.created_at) <= date(?)')
        params.append(normalize_search_date(self, date_to))
    if employee:
        clauses.append('e.name LIKE ?')
        params.append(f'%{clean_text(employee, 100)}%')
    if customer:
        clauses.append('c.name LIKE ?')
        params.append(f'%{clean_text(customer, 100)}%')
    if payment_method:
        clauses.append('s.payment_method=?')
        params.append(clean_text(payment_method, 50))
    where = 'WHERE ' + ' AND '.join(clauses) if clauses else ''
    rows = _rows(self.db.all(f'''
        SELECT 'بيع' operation_type, s.invoice_no ref_no, s.created_at, s.total amount,
               s.payment_method, COALESCE(e.name,'') employee, COALESCE(c.name,'') customer,
               '' product, '' category
          FROM sales s
          LEFT JOIN employees e ON e.id=s.employee_id
          LEFT JOIN customers c ON c.id=s.customer_id
          {where}
         ORDER BY datetime(s.created_at) DESC LIMIT ?
    ''', (*params, _limit(limit, 1000, 5000))))
    # Optional in-memory filters for item-specific fields to keep the read query simple and safe.
    p = clean_text(product, 100)
    cat = clean_text(category, 100)
    op = clean_text(operation_type, 50)
    if op:
        rows = [row for row in rows if op in str(row.get('operation_type', ''))]
    if p or cat:
        # Defer detailed item filtering to existing reports; this keeps no-write behavior predictable.
        return rows
    return rows


@domain_function
def list_fiscal_periods(self: Any) -> list[dict[str, Any]]:
    if not _table_exists(self, 'fiscal_periods'):
        return []
    cols = _columns(self, 'fiscal_periods')
    if {'year', 'month'}.issubset(cols):
        return _rows(self.db.all('SELECT * FROM fiscal_periods ORDER BY year DESC, month DESC, id DESC'))
    if 'start_date' in cols:
        return _rows(self.db.all('SELECT * FROM fiscal_periods ORDER BY date(start_date) DESC, id DESC'))
    return _rows(self.db.all('SELECT * FROM fiscal_periods ORDER BY id DESC'))


@domain_function
def is_fiscal_period_closed(self: Any, date_value: str | None = None) -> bool:
    if not _table_exists(self, 'fiscal_periods'):
        return False
    day = normalize_search_date(self, date_value or datetime.now().strftime('%Y-%m-%d'))
    cols = _columns(self, 'fiscal_periods')
    if {'year', 'month', 'is_closed'}.issubset(cols):
        try:
            year, month, _day = [int(part) for part in day.split('-')]
        except Exception:
            return False
        row = self.db.one('SELECT id FROM fiscal_periods WHERE year=? AND month=? AND is_closed=1 LIMIT 1', (year, month))
        return bool(row)
    if {'status', 'start_date'}.issubset(cols):
        row = self.db.one('''
            SELECT id FROM fiscal_periods
             WHERE status='closed' AND date(?) BETWEEN date(start_date) AND date(COALESCE(end_date,start_date))
             LIMIT 1
        ''', (day,))
        return bool(row)
    return False
