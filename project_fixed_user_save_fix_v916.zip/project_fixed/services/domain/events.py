from __future__ import annotations

"""Stage 13 in-process Domain event system.

The event bus allows future features to react to business events without
changing the write/read methods themselves.  The default bus is intentionally
small, synchronous and fail-safe: subscribers cannot break the main operation.
"""

from dataclasses import dataclass, field
from datetime import datetime
import json
from pathlib import Path
from typing import Any, Callable, DefaultDict
from collections import defaultdict


ON_SALE_COMPLETE = "ON_SALE_COMPLETE"
ON_RETURN_COMPLETE = "ON_RETURN_COMPLETE"
ON_PAYMENT_ADDED = "ON_PAYMENT_ADDED"
ON_SHIFT_OPENED = "ON_SHIFT_OPENED"
ON_SHIFT_CLOSED = "ON_SHIFT_CLOSED"
ON_STOCK_LOW = "ON_STOCK_LOW"
ON_STOCK_CHANGED = "ON_STOCK_CHANGED"
ON_DUE_DATE = "ON_DUE_DATE"
ON_SETTING_CHANGED = "ON_SETTING_CHANGED"


@dataclass(frozen=True)
class DomainEvent:
    name: str
    payload: dict[str, Any] = field(default_factory=dict)
    source: str = "domain"
    occurred_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "payload": self.payload,
            "source": self.source,
            "occurred_at": self.occurred_at,
        }


Subscriber = Callable[[DomainEvent], None]


class EventBus:
    def __init__(self) -> None:
        self._subscribers: DefaultDict[str, list[Subscriber]] = defaultdict(list)
        self.history: list[DomainEvent] = []
        self.errors: list[str] = []

    def subscribe(self, event_name: str, handler: Subscriber) -> None:
        if handler not in self._subscribers[event_name]:
            self._subscribers[event_name].append(handler)

    def unsubscribe(self, event_name: str, handler: Subscriber) -> None:
        if handler in self._subscribers[event_name]:
            self._subscribers[event_name].remove(handler)

    def emit(self, event_name: str, payload: dict[str, Any] | None = None, source: str = "domain") -> DomainEvent:
        event = DomainEvent(event_name, payload or {}, source=source)
        self.history.append(event)
        if len(self.history) > 200:
            del self.history[:-200]
        for handler in list(self._subscribers.get(event_name, [])) + list(self._subscribers.get("*", [])):
            try:
                handler(event)
            except Exception as exc:
                self.errors.append(f"{event_name}: {type(exc).__name__}: {exc}")
                if len(self.errors) > 100:
                    del self.errors[:-100]
        return event


_default_bus = EventBus()


def subscribe(event_name: str, handler: Subscriber) -> None:
    _default_bus.subscribe(event_name, handler)


def unsubscribe(event_name: str, handler: Subscriber) -> None:
    _default_bus.unsubscribe(event_name, handler)


def emit(event_name: str, payload: dict[str, Any] | None = None, source: str = "domain") -> DomainEvent:
    return _default_bus.emit(event_name, payload, source)


def recent_events() -> list[dict[str, Any]]:
    return [event.as_dict() for event in _default_bus.history]


def event_errors() -> list[str]:
    return list(_default_bus.errors)


def make_jsonl_logger(path: str | Path) -> Subscriber:
    """Return a subscriber that writes events to a JSONL audit trail."""
    target = Path(path).expanduser()

    def _handler(event: DomainEvent) -> None:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(event.as_dict(), ensure_ascii=False, default=str) + "\n")

    return _handler


__all__ = [
    "DomainEvent",
    "EventBus",
    "ON_SALE_COMPLETE",
    "ON_RETURN_COMPLETE",
    "ON_PAYMENT_ADDED",
    "ON_SHIFT_OPENED",
    "ON_SHIFT_CLOSED",
    "ON_STOCK_LOW",
    "ON_STOCK_CHANGED",
    "ON_DUE_DATE",
    "ON_SETTING_CHANGED",
    "subscribe",
    "unsubscribe",
    "emit",
    "recent_events",
    "event_errors",
    "make_jsonl_logger",
]
