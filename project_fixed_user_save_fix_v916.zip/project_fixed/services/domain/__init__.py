"""Domain services for Max Sales Qt.

The project exposes business DOMAIN modules while service_patches only load
feature implementations that have not been moved into standalone domain files.
The stable domain_bridge republishes AppService methods by business domain.

Do not import domain_bridge here: services.app_core imports domain mixins during
AppService construction, so eager bridge imports would create a circular import.
"""

__all__: list[str] = ["events"]
