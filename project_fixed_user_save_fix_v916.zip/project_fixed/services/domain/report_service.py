from services.core_common import *


class ReportServiceMixin:
        def dashboard(self) -> dict:
            today = datetime.now().strftime('%Y-%m-%d')
            stats = self.db.one('''SELECT COALESCE(SUM(total),0) sales, COALESCE(SUM(total_profit),0) profit, COALESCE(SUM(total_commission),0) commission, COUNT(*) invoices FROM sales WHERE date(created_at)=date(?)''', (today,))
            returns = self.db.one('''SELECT COALESCE(SUM(amount),0) amount, COUNT(*) count FROM returns WHERE date(created_at)=date(?)''', (today,))
            best_product = self.db.one('''SELECT product_name, SUM(quantity) qty FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE date(s.created_at)=date(?) GROUP BY product_id ORDER BY qty DESC LIMIT 1''', (today,))
            low_stock = self.db.one('SELECT COUNT(*) c FROM products WHERE active=1 AND quantity <= min_quantity')
            debt = self.db.one('''WITH credit AS (SELECT customer_id, SUM(CASE WHEN (subtotal-discount_amount+tax_amount) < 0 THEN 0 ELSE (subtotal-discount_amount+tax_amount) END) amount FROM sales WHERE payment_method='آجل' GROUP BY customer_id), payments AS (SELECT customer_id, SUM(amount) amount FROM customer_payments GROUP BY customer_id), returned AS (SELECT s.customer_id, SUM(r.amount) amount FROM returns r JOIN sales s ON s.id=r.sale_id GROUP BY s.customer_id) SELECT COALESCE(SUM(COALESCE(credit.amount,0)-COALESCE(returned.amount,0)-COALESCE(payments.amount,0)),0) total_debt FROM customers c LEFT JOIN credit ON credit.customer_id=c.id LEFT JOIN payments ON payments.customer_id=c.id LEFT JOIN returned ON returned.customer_id=c.id WHERE c.active=1''')
            return {'sales': stats['sales'] if stats else 0, 'profit': stats['profit'] if stats else 0, 'commission': stats['commission'] if stats else 0, 'invoices': stats['invoices'] if stats else 0, 'returns_amount': returns['amount'] if returns else 0, 'returns_count': returns['count'] if returns else 0, 'best_product': best_product['product_name'] if best_product else '-', 'low_stock': low_stock['c'] if low_stock else 0, 'total_debt': debt['total_debt'] if debt else 0}

        def dashboard_chart_sales_trend(self) -> list[dict]:
            return self.db.all("SELECT date(created_at) as date, COALESCE(SUM(total),0) as sales, COALESCE(SUM(total_profit),0) as profit FROM sales WHERE date(created_at) >= date('now', '-7 days') GROUP BY date(created_at) ORDER BY date(created_at) ASC")

        def dashboard_chart_top_products(self) -> list[dict]:
            return self.db.all("SELECT product_name, SUM(quantity) qty FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE date(s.created_at) >= date('now', '-30 days') GROUP BY product_id, product_name ORDER BY qty DESC LIMIT 5")

        def low_inventory_details(self) -> list[dict]:
            return self.db.all('SELECT id, barcode, name, category, quantity, min_quantity, cost_price FROM products WHERE active=1 AND quantity <= min_quantity ORDER BY quantity ASC')

        def smart_alerts(self) -> list[str]:
            alerts: list[str] = []
            out_count = self.db.one('SELECT COUNT(*) c FROM products WHERE active=1 AND quantity <= 0')
            low_count = self.db.one('SELECT COUNT(*) c FROM products WHERE active=1 AND quantity > 0 AND quantity <= min_quantity')
            for row in self.debt_rows()[:3]:
                if row['balance'] > 0 and row['credit_limit'] and row['balance'] > row['credit_limit']:
                    alerts.append(f"زبون تجاوز حد الدين: {row['name']} - {money(row['balance'])}")
            if out_count and out_count['c']:
                alerts.append(f"يوجد {out_count['c']} منتج نافد من المخزون")
            if low_count and low_count['c']:
                alerts.append(f"يوجد {low_count['c']} منتج وصل إلى حد التنبيه")
            today = datetime.now().strftime('%Y-%m-%d')
            employee = self.db.one('''SELECT e.name, COALESCE(SUM(s.total),0) sales FROM sales s JOIN employees e ON e.id=s.employee_id WHERE date(s.created_at)=date(?) GROUP BY e.id ORDER BY sales DESC LIMIT 1''', (today,))
            if employee and employee['sales'] > 0:
                alerts.append(f"أفضل موظف اليوم: {employee['name']} بمبيعات {money(employee['sales'])}")
            return alerts

        def commission_report(self):
            return self.db.all('''SELECT e.name employee, COALESCE(SUM(s.total),0) sales, COALESCE(SUM(s.total_commission),0) commission, COALESCE((SELECT SUM(r.commission_amount) FROM returns r WHERE r.employee_id=e.id),0) returned_commission FROM employees e LEFT JOIN sales s ON s.employee_id=e.id GROUP BY e.id ORDER BY commission DESC''')

        def management_report(self, kind: str):
            if kind == 'daily_sales':
                return self.db.all("SELECT date(created_at) period, COUNT(*) invoices, SUM(total) total, SUM(total_profit) profit FROM sales GROUP BY date(created_at) ORDER BY period DESC LIMIT 90")
            if kind == 'monthly_sales':
                return self.db.all("SELECT substr(created_at,1,7) period, COUNT(*) invoices, SUM(total) total, SUM(total_profit) profit FROM sales GROUP BY substr(created_at,1,7) ORDER BY period DESC LIMIT 36")
            if kind == 'top_products':
                return self.db.all("SELECT product_name, SUM(quantity) qty, SUM(line_total) total FROM sale_items GROUP BY product_id, product_name ORDER BY qty DESC LIMIT 50")
            if kind == 'best_employees':
                return self.db.all("SELECT e.name employee, COUNT(s.id) invoices, SUM(s.total) total, SUM(s.total_commission) commission FROM sales s JOIN employees e ON e.id=s.employee_id GROUP BY e.id ORDER BY total DESC LIMIT 50")
            if kind == 'overdue_debts':
                return self.debt_rows()
            if kind == 'returns_reason':
                return self.db.all("SELECT COALESCE(NULLIF(reason,''),'بدون سبب') reason, COUNT(*) count, SUM(amount) total FROM returns GROUP BY COALESCE(NULLIF(reason,''),'بدون سبب') ORDER BY total DESC")
            if kind == 'inventory_movements':
                return self.inventory_movements(500)
            if kind == 'stale_products':
                return self.db.all("SELECT p.name, p.quantity, p.sale_price, COALESCE(MAX(s.created_at),'لم يباع') last_sale FROM products p LEFT JOIN sale_items si ON si.product_id=p.id LEFT JOIN sales s ON s.id=si.sale_id WHERE p.active=1 GROUP BY p.id ORDER BY CASE WHEN last_sale='لم يباع' THEN 0 ELSE 1 END, last_sale LIMIT 100")
            return []
