from __future__ import annotations

"""v1.0.0 Stable Domain persistence facades.

Sales and finance writes are native-only. This package centralises
transactions, events, validation, and typed write results in one place.
"""

from .sales_finance_writes import run_write_operation, emit_sales_event

__all__ = ["run_write_operation", "emit_sales_event"]
