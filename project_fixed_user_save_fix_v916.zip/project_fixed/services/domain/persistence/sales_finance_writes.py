from __future__ import annotations

"""Sales/finance write orchestration.

v1.0.0 Stable cutover: sales and finance writes are native-only.  The former
``auto/off`` fallback modes are intentionally ignored; ``MAX_SALES_NATIVE_PERSISTENCE``
defaults to ``on`` and any native write error is raised immediately instead of
being retried through the historical saver.
"""

from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
import json
import os
from pathlib import Path
from typing import Any, Callable

from services.core_common import invoice_no, now_text, receipt_no, return_no
from services.data.connections import transaction
from services.data.models import PersistResult, to_money
from services.data.queries import execute_write, fetch_one_dict, fetch_all_dicts, require_columns, table_exists
from services.domain import events

CENT = Decimal("0.01")
PROJECT_ROOT = Path(__file__).resolve().parents[3]
PERSISTENCE_LOG_PATH = PROJECT_ROOT / "logs" / "persistence_paths.log"


class NativePersistenceUnavailable(RuntimeError):
    """Raised when the active database schema cannot support native writes yet."""


def _native_mode() -> str:
    """Return the stable release persistence mode.

    Environment values are accepted for backward compatibility with old launch
    scripts, but persistence is now forced to native-only.
    """
    return "on"


def _D(value: Any) -> Decimal:
    return to_money(value)


def _q(value: Any) -> Decimal:
    return _D(value).quantize(CENT, rounding=ROUND_HALF_UP)


def _f(value: Any) -> float:
    return float(_q(value))


def _positive_decimal(value: Any, field_name: str) -> Decimal:
    amount = _D(value)
    if amount <= 0:
        raise ValueError(f"{field_name} يجب أن يكون أكبر من صفر")
    return amount


def _non_negative_decimal(value: Any, field_name: str) -> Decimal:
    amount = _D(value)
    if amount < 0:
        raise ValueError(f"{field_name} لا يمكن أن يكون أقل من صفر")
    return amount


def _item_value(item: dict[str, Any] | Any, *keys: str, default: Any = 0) -> Any:
    for key in keys:
        try:
            if key in item and item[key] is not None:
                return item[key]
        except Exception:
            pass
        try:
            value = item[key]
            if value is not None:
                return value
        except Exception:
            pass
        try:
            value = item.get(key, None)
            if value is not None:
                return value
        except Exception:
            pass
    return default


def _stock_column(conn: Any) -> str:
    try:
        cols = {str(row[1]) for row in conn.execute("PRAGMA table_info(products)")}
    except Exception:
        cols = set()
    if "quantity" in cols:
        return "quantity"
    if "stock_quantity" in cols:
        return "stock_quantity"
    if "current_stock" in cols:
        return "current_stock"
    return "quantity"


def _sale_item_optional_columns(conn: Any) -> set[str]:
    try:
        return {str(row[1]) for row in conn.execute("PRAGMA table_info(sale_items)")}
    except Exception:
        return set()


def _normalize_sale_cart(service: Any, cart: list[dict[str, Any]], user_id: int | None = None) -> list[dict[str, Any]]:
    conn = service.db.conn
    stock_col = _stock_column(conn)
    normalized: list[dict[str, Any]] = []
    for item in cart:
        product_id = int(_item_value(item, "product_id", "id"))
        qty = _positive_decimal(_item_value(item, "quantity", "qty", default=0), "الكمية")
        product = fetch_one_dict(
            conn,
            f"SELECT id, name, {stock_col} AS quantity, min_quantity, cost_price, sale_price, commission_percent FROM products WHERE id=?",
            (product_id,),
        )
        if not product or _D(product["quantity"]) < qty:
            raise ValueError(f"المخزون غير كاف للمنتج: {_item_value(item, 'product_name', 'name', default=product['name'] if product else product_id)}")
        unit_price = _non_negative_decimal(_item_value(item, "unit_price", "price", "sale_price", default=product.get("sale_price", 0)), "سعر البيع")
        
        if _q(unit_price) != _q(product.get("sale_price", 0)):
            service.require_permission("can_price_edit", user_id, "تعديل سعر البيع للمنتج")

        item_discount = _non_negative_decimal(_item_value(item, "item_discount", "discount", "discount_amount", default=0), "خصم الصنف")
        
        if _q(item_discount) > 0:
            service.require_permission("can_discount", user_id, "إعطاء خصم على الصنف")

        line_gross = _q(qty * unit_price)
        if item_discount > line_gross:
            raise ValueError("خصم الصنف لا يمكن أن يكون أكبر من إجمالي الصنف")
        row = {
            "product_id": product_id,
            "product_name": str(_item_value(item, "product_name", "name", default=product["name"])),
            "quantity": qty,
            "cost_price": _non_negative_decimal(_item_value(item, "cost_price", "cost", default=product.get("cost_price", 0)), "سعر الكلفة"),
            "unit_price": unit_price,
            "item_discount": _q(item_discount),
            "commission_percent": _non_negative_decimal(_item_value(item, "commission_percent", default=product.get("commission_percent", 0)), "نسبة العمولة"),
        }
        if row["commission_percent"] > 100:
            raise ValueError("نسبة العمولة لا يمكن أن تكون أكبر من 100%")
        normalized.append(row)
    return normalized



def _table_columns(conn: Any, table_name: str) -> set[str]:
    try:
        return {str(row[1]) for row in conn.execute(f"PRAGMA table_info({table_name})")}
    except Exception:
        return set()


def _role_discount_defaults(role: str) -> tuple[Decimal, bool]:
    role_text = str(role or "").strip().lower()
    if role_text in ("مدير", "مدير النظام", "admin", "administrator"):
        return Decimal("100"), True
    if "موظف" in role_text and "مبيعات" in role_text:
        return Decimal("15"), False
    return Decimal("10"), False


def _as_bool(value: Any) -> bool:
    try:
        return bool(int(value or 0))
    except Exception:
        return bool(value)


def _get_discount_policy(service: Any, user_id: int | None) -> dict[str, Any]:
    user = None
    if hasattr(service, "_effective_user"):
        user = service._effective_user(user_id)
    if user is None and user_id:
        try:
            user = fetch_one_dict(service.db.conn, "SELECT * FROM users WHERE id=?", (int(user_id),))
        except Exception:
            user = None
    role = ""
    if user is not None:
        try:
            role = str(user["role"] or "")
        except Exception:
            try:
                role = str(user.get("role", "") or "")
            except Exception:
                role = ""
    # Unit tests and legacy in-memory fixtures may not include a users table.
    # In the real application complete_sale_native already passed require_* permission checks.
    if user is None:
        try:
            has_users_table = bool(service.db.conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='users'").fetchone())
        except Exception:
            has_users_table = False
        if not has_users_table:
            return {
                "can_discount": True,
                "can_discount_limit": True,
                "max_discount_percent": Decimal("100"),
                "can_discount_below_cost": True,
                "role": role,
            }
    default_max, default_below_cost = _role_discount_defaults(role)
    can_discount = _as_bool(_item_value(user or {}, "can_discount", default=0))
    can_discount_limit = _as_bool(_item_value(user or {}, "can_discount_limit", default=0))

    # Newer databases may include explicit fields; older databases safely fall back to role defaults.
    max_discount = default_max
    if user is not None:
        try:
            raw_max = _item_value(user, "max_discount_percent", default=None)
            if raw_max is not None:
                max_discount = _D(raw_max)
        except Exception:
            max_discount = default_max
    if can_discount_limit and max_discount < Decimal("100"):
        max_discount = Decimal("100")

    can_below_cost = default_below_cost or can_discount_limit
    if user is not None:
        try:
            if _item_value(user, "can_discount_below_cost", default=None) is not None:
                can_below_cost = _as_bool(_item_value(user, "can_discount_below_cost", default=0))
        except Exception:
            pass
    return {
        "can_discount": can_discount,
        "can_discount_limit": can_discount_limit,
        "max_discount_percent": max_discount,
        "can_discount_below_cost": can_below_cost,
        "role": role,
    }


def _validate_sale_discount_policy(service: Any, user_id: int | None, normalized: list[dict[str, Any]], amounts: dict[str, Decimal]) -> None:
    gross = _q(amounts.get("gross_subtotal", 0))
    total_discount = _q(amounts.get("discount_total", 0))
    if total_discount <= 0 or gross <= 0:
        return

    policy = _get_discount_policy(service, user_id)
    if not policy["can_discount"]:
        raise PermissionError("لا تملك صلاحية تطبيق الخصم")

    total_cost = _q(sum((row["quantity"] * row["cost_price"] for row in normalized), Decimal("0")))
    net_before_tax = _q(amounts.get("taxable_base", 0))
    if net_before_tax < total_cost and not policy["can_discount_below_cost"]:
        raise PermissionError("لا يمكن إتمام العملية: السعر النهائي أقل من تكلفة الشراء، ولا تملك الصلاحية المطلوبة")

    discount_percent = _q(total_discount * Decimal("100") / gross)
    max_percent = _q(policy["max_discount_percent"])
    if discount_percent > max_percent:
        raise PermissionError(f"نسبة الخصم {discount_percent}% أكبر من الحد المسموح لك ({max_percent}%)")

def _calculate_sale_amounts(service: Any, normalized: list[dict[str, Any]], discount_amount: Any = 0, discount_type: str = "amount") -> dict[str, Decimal]:
    gross_subtotal = _q(sum((row["quantity"] * row["unit_price"] for row in normalized), Decimal("0")))
    item_discount_total = _q(sum((row.get("item_discount", Decimal("0")) for row in normalized), Decimal("0")))
    net_after_item_discount = max(gross_subtotal - item_discount_total, Decimal("0"))
    discount_value = max(_D(discount_amount or 0), Decimal("0"))
    if discount_type == "percent":
        if discount_value > 100:
            raise ValueError("نسبة الخصم لا يمكن أن تكون أكبر من 100%")
        global_discount = _q(net_after_item_discount * discount_value / Decimal("100"))
    else:
        if discount_value > net_after_item_discount:
            raise ValueError("قيمة الخصم لا يمكن أن تكون أكبر من إجمالي الفاتورة بعد خصومات الأصناف")
        global_discount = _q(discount_value)
    if global_discount >= net_after_item_discount and net_after_item_discount > 0:
        raise ValueError("الخصم لا يمكن أن يساوي أو يتجاوز قيمة الفاتورة")
    taxable_base = max(net_after_item_discount - global_discount, Decimal("0"))
    tax_percent = _D((service.get_settings() if hasattr(service, "get_settings") else {}).get("tax_percent", 0))
    tax_amount = _q(taxable_base * tax_percent / Decimal("100"))
    total = _q(taxable_base + tax_amount)
    commission = Decimal("0")
    profit = Decimal("0")
    for row in normalized:
        line_gross = _q(row["quantity"] * row["unit_price"])
        line_after_item = _q(line_gross - row.get("item_discount", Decimal("0")))
        global_share = _q(global_discount * line_after_item / net_after_item_discount) if net_after_item_discount else Decimal("0")
        line_net = _q(line_after_item - global_share)
        commission += _q(line_net * row["commission_percent"] / Decimal("100"))
        # الربح = صافي السطر (بعد كل الخصومات) ناقص التكلفة الإجمالية
        profit += _q(line_net - _q(row["quantity"] * row["cost_price"]))
    return {
        "gross_subtotal": gross_subtotal,
        "item_discount_total": item_discount_total,
        "global_discount": global_discount,
        "discount_total": _q(item_discount_total + global_discount),
        "taxable_base": taxable_base,
        "tax_amount": tax_amount,
        "total": total,
        "commission": _q(commission),
        "profit": _q(profit),
    }


def _insert_sale_items_and_update_stock(conn: Any, sale_id: int, invoice_no_value: str, normalized: list[dict[str, Any]], amounts: dict[str, Decimal], user_id: int | None) -> None:
    stock_col = _stock_column(conn)
    optional = _sale_item_optional_columns(conn)
    net_after_item = max(amounts["gross_subtotal"] - amounts["item_discount_total"], Decimal("0"))
    allocated_global = Decimal("0")
    allocated_tax = Decimal("0")
    for _idx, row in enumerate(normalized):
        _is_last = (_idx == len(normalized) - 1)
        line_gross = _q(row["quantity"] * row["unit_price"])
        line_after_item = _q(line_gross - row.get("item_discount", Decimal("0")))
        if _is_last:
            # تصحيح التقريب: الصنف الأخير يحصل على الباقي لضمان مجموع دقيق
            global_share = amounts["global_discount"] - allocated_global
            line_tax = amounts["tax_amount"] - allocated_tax
        else:
            global_share = _q(amounts["global_discount"] * line_after_item / net_after_item) if net_after_item else Decimal("0")
            line_taxable_pre = _q(line_after_item - global_share)
            line_tax = _q(amounts["tax_amount"] * line_taxable_pre / amounts["taxable_base"]) if amounts["taxable_base"] else Decimal("0")
        allocated_global += global_share
        allocated_tax += line_tax
        line_taxable = _q(line_after_item - global_share)
        item_commission = _q(line_taxable * row["commission_percent"] / Decimal("100"))
        # الربح الصحيح = صافي السطر (بعد كل الخصومات) - التكلفة الإجمالية
        item_profit = _q(line_taxable - _q(row["quantity"] * row["cost_price"]))
        columns = ["sale_id", "product_id", "product_name", "quantity", "cost_price", "unit_price", "line_total", "commission_percent", "commission_amount", "profit_amount"]
        values: list[Any] = [sale_id, row["product_id"], row["product_name"], int(row["quantity"]), _f(row["cost_price"]), _f(row["unit_price"]), _f(line_gross), _f(row["commission_percent"]), _f(item_commission), _f(item_profit)]
        if "discount_amount" in optional:
            columns.append("discount_amount"); values.append(_f(row.get("item_discount", 0) + global_share))
        if "tax_amount" in optional:
            columns.append("tax_amount"); values.append(_f(line_tax))
        placeholders = ", ".join("?" for _ in columns)
        execute_write(conn, f"INSERT INTO sale_items ({', '.join(columns)}) VALUES ({placeholders})", tuple(values))
        product = fetch_one_dict(conn, f"SELECT {stock_col} AS quantity, min_quantity FROM products WHERE id=?", (row["product_id"],))
        oldq = int(product["quantity"] if product else 0)
        newq = oldq - int(row["quantity"])
        # تحديث مشروط ذري: يرفض العملية إن أصبح المخزون سالباً
        cur = conn.execute(
            f"UPDATE products SET {stock_col} = {stock_col} - ? WHERE id=? AND {stock_col} >= ?",
            (int(row["quantity"]), row["product_id"], int(row["quantity"]))
        )
        if cur.rowcount == 0:
            raise ValueError(f"المخزون غير كافٍ للمنتج: {row['product_name']} (المتوفر: {oldq})")
        execute_write(
            conn,
            """
            INSERT INTO inventory_movements (
                product_id, movement_type, quantity_change, old_quantity, new_quantity,
                ref_type, ref_no, note, user_id, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (row["product_id"], "بيع", -int(row["quantity"]), oldq, newq, "sale", invoice_no_value, "", user_id, now_text()),
        )
        min_quantity = int(product.get("min_quantity", 0) if product else 0)
        if newq <= min_quantity:
            events.emit(events.ON_STOCK_LOW, {"product_id": row["product_id"], "product_name": row["product_name"], "old_quantity": oldq, "new_quantity": newq, "min_quantity": min_quantity, "invoice_no": invoice_no_value}, source="services.domain.persistence.sales_finance_writes")


def _restore_sale_stock(conn: Any, sale_id: int, user_id: int | None, reason: str, ref_no: str | None = None) -> list[dict[str, Any]]:
    items = fetch_all_dicts(conn, "SELECT product_id, product_name, quantity FROM sale_items WHERE sale_id=?", (sale_id,))
    stock_col = _stock_column(conn)
    for item in items:
        product = fetch_one_dict(conn, f"SELECT {stock_col} AS quantity FROM products WHERE id=?", (item["product_id"],))
        oldq = int(product["quantity"] if product else 0)
        qty = int(item["quantity"] or 0)
        newq = oldq + qty
        execute_write(conn, f"UPDATE products SET {stock_col}=? WHERE id=?", (newq, item["product_id"]))
        execute_write(
            conn,
            """
            INSERT INTO inventory_movements (
                product_id, movement_type, quantity_change, old_quantity, new_quantity,
                ref_type, ref_no, note, user_id, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (item["product_id"], "استرجاع مخزون", qty, oldq, newq, "sale_adjustment", ref_no or str(sale_id), reason, user_id, now_text()),
        )
    events.emit("ON_STOCK_CHANGED", {"reason": reason, "sale_id": sale_id, "restored_items": items}, source="services.domain.persistence.sales_finance_writes")
    return items


def _ensure_app_schema(conn: Any) -> None:
    required = {
        "sales": {"invoice_no", "employee_id", "subtotal", "discount_amount", "total", "payment_method", "tax_amount", "created_at"},
        "sale_items": {"sale_id", "product_id", "product_name", "quantity", "unit_price", "line_total"},
        "products": {"id", "quantity"},
        "inventory_movements": {"product_id", "movement_type", "quantity_change", "old_quantity", "new_quantity", "ref_type", "ref_no", "created_at"},
    }
    for table, columns in required.items():
        if not table_exists(conn, table) or not require_columns(conn, table, columns):
            raise NativePersistenceUnavailable(f"schema_missing:{table}")


def _record_persistence_path(
    *,
    operation: str,
    path: str,
    engine: str,
    native_attempted: bool,
    native_used: bool,
    reason: str = "",
    errors: list[str] | None = None,
) -> None:
    """Append one JSON-lines monitoring entry for Stage 15 analytics."""
    try:
        PERSISTENCE_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "operation": operation,
            "path": path,
            "engine": engine,
            "native_attempted": native_attempted,
            "native_used": native_used,
            "reason": reason,
            "errors": errors or [],
        }
        with PERSISTENCE_LOG_PATH.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
    except Exception:
        # Monitoring must never stop a sale, return, or payment write.
        pass


def emit_sales_event(operation: str, result: Any = None, preview: dict[str, Any] | None = None, comparison: dict[str, Any] | None = None) -> None:
    event_name = {
        "complete_sale": events.ON_SALE_COMPLETE,
        "return_item": events.ON_RETURN_COMPLETE,
        "return_full_sale": events.ON_RETURN_COMPLETE,
        "add_payment": events.ON_PAYMENT_ADDED,
        "open_cashier_shift": events.ON_SHIFT_OPENED,
        "close_cashier_shift": events.ON_SHIFT_CLOSED,
    }.get(operation, operation)
    events.emit(
        event_name,
        {
            "operation": operation,
            "result": result,
            "preview": preview or {},
            "comparison": comparison or {},
        },
        source="services.domain.persistence.sales_finance_writes",
    )


def run_write_operation(
    *,
    operation: str,
    compat_call: Callable[[], Any] | None = None,
    preview: dict[str, Any] | None = None,
    comparison_factory: Callable[[Any], dict[str, Any]] | None = None,
    native_call: Callable[[], Any] | None = None,
) -> PersistResult:
    """Run a write operation through the final native persistence seam.

    v1.0.0 Stable deliberately removes fallback. When a native implementation
    is supplied it is the only write path. Operations that are not
    sales/finance persistence writes, such as cashier-shift helpers, may pass a
    compatibility callable; those calls are recorded as ``COMPAT`` and never as
    ``FALLBACK``.
    """
    errors: list[str] = []
    comparison: dict[str, Any] = {}
    result: Any = None
    engine = "domain_native"
    native_attempted = native_call is not None
    native_used = False

    try:
        if native_call is not None:
            result = native_call()
            native_used = True
        elif compat_call is not None:
            # Compatibility-only path for non-persistence helpers that still
            # enter this seam, such as cashier shift wrappers. It is not a
            # fallback from a failed native write.
            engine = "domain_compat"
            result = compat_call()
        else:
            raise NativePersistenceUnavailable(f"native_missing:{operation}")

        if comparison_factory is not None:
            try:
                comparison = comparison_factory(result) or {}
            except Exception as exc:
                comparison = {"comparison": "error", "error": f"{type(exc).__name__}: {exc}"}
    except Exception as exc:
        errors.append(f"write:{type(exc).__name__}: {exc}")
        raise
    finally:
        path = "NATIVE" if native_used else "COMPAT"
        reason = errors[-1] if errors else ""
        _record_persistence_path(
            operation=operation,
            path=path,
            engine=engine,
            native_attempted=native_attempted,
            native_used=native_used,
            reason=reason,
            errors=errors,
        )
        emit_sales_event(operation, result=result, preview=preview, comparison=comparison)
    return PersistResult(
        operation=operation,
        result=result,
        preview=preview or {},
        comparison=comparison,
        errors=errors,
        engine=engine,
        native_attempted=native_attempted,
        native_used=native_used,
    )


# ---------------------------------------------------------------------------
# Native Domain persistence implementations for the current Max Sales schema.
# These functions intentionally preserve the public return values expected by Qt screens.
# ---------------------------------------------------------------------------


def complete_sale_native(
    service: Any,
    cart: list[dict[str, Any]],
    employee_id: int,
    customer_id: int | None,
    payment_method: str,
    discount_amount: Any = 0,
    note: str = "",
    user_id: int | None = None,
    discount_type: str = "amount",
) -> str:
    user = service.require_any_permission(("can_sales", "can_touch_pos"), user_id, "إتمام البيع")
    user_id = int(user["id"])

    if _q(discount_amount) > 0:
        service.require_permission("can_discount", user_id, "إعطاء خصم")

    if not cart:
        raise ValueError("السلة فارغة")
    if not employee_id:
        raise ValueError("اختر الموظف الذي يستحق العمولة")

    conn = service.db.conn
    _ensure_app_schema(conn)
    employee = fetch_one_dict(conn, "SELECT id, active FROM employees WHERE id=? AND active=1", (employee_id,))
    if not employee:
        raise ValueError("الموظف المختار غير موجود أو معطل. العمولات تُسجل للموظفين فقط.")

    normalized = _normalize_sale_cart(service, cart, user_id)
    amounts = _calculate_sale_amounts(service, normalized, discount_amount, discount_type)
    _validate_sale_discount_policy(service, user_id, normalized, amounts)
    inv = invoice_no()
    with transaction(conn):
        sale_id = execute_write(
            conn,
            """
            INSERT INTO sales (
                invoice_no, user_id, employee_id, customer_id, subtotal, discount_amount,
                total, total_commission, total_profit, payment_method, discount_type,
                tax_amount, note, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                inv,
                user_id,
                employee_id,
                customer_id,
                _f(amounts["gross_subtotal"]),
                _f(amounts["discount_total"]),
                _f(amounts["total"]),
                _f(amounts["commission"]),
                _f(amounts["profit"]),
                payment_method,
                discount_type,
                _f(amounts["tax_amount"]),
                str(note or "").strip(),
                now_text(),
            ),
        )
        _insert_sale_items_and_update_stock(conn, sale_id, inv, normalized, amounts, user_id)
    if hasattr(service, "log"):
        service.log("بيع", inv, user_id)
    events.emit(
        events.ON_SALE_COMPLETE,
        {"invoice_no": inv, "sale_id": sale_id, "items": normalized, "totals": {k: str(v) for k, v in amounts.items()}},
        source="services.domain.persistence.sales_finance_writes",
    )
    return inv


def return_item_native(
    service: Any,
    sale_item_id: int,
    quantity: int,
    reason: str = "",
    user_id: int | None = None,
    refund_method: str = "نقدي",
) -> str:
    user = service.require_permission("can_returns", user_id, "تسجيل المرتجعات")
    user_id = int(user["id"])
    if quantity <= 0:
        raise ValueError("كمية الإرجاع يجب أن تكون أكبر من صفر")
    if not str(reason or "").strip():
        raise ValueError("سبب الإرجاع مطلوب")

    conn = service.db.conn
    _ensure_app_schema(conn)
    row = fetch_one_dict(
        conn,
        """
        SELECT si.*, s.employee_id, s.customer_id, s.id sale_id,
               COALESCE(SUM(r.quantity),0) returned_qty,
               si.quantity - COALESCE(SUM(r.quantity),0) remaining_qty
        FROM sale_items si
        JOIN sales s ON s.id=si.sale_id
        LEFT JOIN returns r ON r.sale_item_id=si.id
        WHERE si.id=?
        GROUP BY si.id
        """,
        (sale_item_id,),
    )
    if not row:
        raise ValueError("المادة غير موجودة في الفاتورة")
    if int(quantity) > int(row["remaining_qty"]):
        raise ValueError("كمية الإرجاع أكبر من الكمية المتبقية")

    gross_amount = _q(_D(quantity) * _D(row["unit_price"]))
    subtotal_row = fetch_one_dict(conn, "SELECT COALESCE(SUM(line_total),0) v FROM sale_items WHERE sale_id=?", (row["sale_id"],))
    sale_row = fetch_one_dict(conn, "SELECT discount_amount, tax_amount FROM sales WHERE id=?", (row["sale_id"],)) or {}
    original_subtotal = _D(subtotal_row["v"] if subtotal_row else 0)
    original_discount = _D(sale_row.get("discount_amount", 0))
    original_tax = _D(sale_row.get("tax_amount", 0))
    discount_share = _q(original_discount * gross_amount / original_subtotal) if original_subtotal else Decimal("0")
    net_before_tax = max(gross_amount - discount_share, Decimal("0"))
    taxable_base = max(original_subtotal - original_discount, Decimal("0"))
    tax_share = _q(original_tax * net_before_tax / taxable_base) if taxable_base else Decimal("0")
    amount = _q(net_before_tax + tax_share)
    commission = _q(net_before_tax * _D(row["commission_percent"]) / Decimal("100"))
    profit = _q(_D(quantity) * (_D(row["unit_price"]) - _D(row["cost_price"])) - discount_share)
    ret = return_no()

    with transaction(conn):
        execute_write(
            conn,
            """
            INSERT INTO returns (
                return_no, sale_id, sale_item_id, product_id, product_name, employee_id,
                customer_id, quantity, unit_price, amount, commission_amount, profit_amount,
                reason, refund_method, created_by_user_id, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                ret,
                row["sale_id"],
                row["id"],
                row["product_id"],
                row["product_name"],
                row["employee_id"],
                row["customer_id"],
                int(quantity),
                _f(row["unit_price"]),
                _f(amount),
                _f(commission),
                _f(profit),
                str(reason or "").strip(),
                refund_method,
                user_id,
                now_text(),
            ),
        )
        product = fetch_one_dict(conn, "SELECT quantity FROM products WHERE id=?", (row["product_id"],))
        oldq = int(product["quantity"] if product else 0)
        newq = oldq + int(quantity)
        execute_write(conn, "UPDATE products SET quantity=? WHERE id=?", (newq, row["product_id"]))
        execute_write(
            conn,
            """
            INSERT INTO inventory_movements (
                product_id, movement_type, quantity_change, old_quantity, new_quantity,
                ref_type, ref_no, note, user_id, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (row["product_id"], "مرتجع", int(quantity), oldq, newq, "return", ret, str(reason or "").strip(), user_id, now_text()),
        )
        execute_write(
            conn,
            """
            UPDATE sales
            SET total=CASE WHEN (total-?) < 0 THEN 0 ELSE (total-?) END,
                total_commission=CASE WHEN (total_commission-?) < 0 THEN 0 ELSE (total_commission-?) END,
                total_profit=CASE WHEN (total_profit-?) < 0 THEN 0 ELSE (total_profit-?) END
            WHERE id=?
            """,
            (_f(amount), _f(amount), _f(commission), _f(commission), _f(profit), _f(profit), row["sale_id"]),
        )
    if hasattr(service, "log"):
        service.log("مرتجع", ret, user_id)
    return ret


def return_full_sale_native(
    service: Any,
    sale_id: int,
    reason: str = "",
    user_id: int | None = None,
    refund_method: str = "نقدي",
) -> list[str]:
    service.require_permission("can_returns", user_id, "إرجاع الفواتير")
    conn = service.db.conn
    items = conn.execute(
        """
        SELECT si.id, si.quantity - COALESCE(SUM(r.quantity),0) remaining_qty
        FROM sale_items si
        LEFT JOIN returns r ON r.sale_item_id=si.id
        WHERE si.sale_id=?
        GROUP BY si.id
        """,
        (sale_id,),
    ).fetchall()
    numbers: list[str] = []
    for item in items:
        if int(item["remaining_qty"]) > 0:
            numbers.append(return_item_native(service, int(item["id"]), int(item["remaining_qty"]), reason, user_id, refund_method))
    if not numbers:
        raise ValueError("لا توجد مواد متبقية للإرجاع في هذه الفاتورة")
    return numbers


def update_sale_native(
    service: Any,
    sale_id: int,
    cart: list[dict[str, Any]],
    employee_id: int,
    customer_id: int | None,
    payment_method: str,
    discount_amount: Any = 0,
    note: str = "",
    user_id: int | None = None,
    discount_type: str = "amount",
    reason: str = "",
) -> str:
    if not str(reason or "").strip():
        raise ValueError("سبب تعديل الفاتورة مطلوب")
    user = service.require_any_permission(("can_sales", "can_touch_pos"), user_id, "تعديل فاتورة")
    user_id = int(user["id"])

    if _q(discount_amount) > 0:
        service.require_permission("can_discount", user_id, "إعطاء خصم")

    if not cart:
        raise ValueError("السلة فارغة")
    conn = service.db.conn
    _ensure_app_schema(conn)
    sale = fetch_one_dict(conn, "SELECT id, invoice_no FROM sales WHERE id=?", (sale_id,))
    if not sale:
        raise ValueError("الفاتورة غير موجودة")
    employee = fetch_one_dict(conn, "SELECT id, active FROM employees WHERE id=? AND active=1", (employee_id,))
    if not employee:
        raise ValueError("الموظف المختار غير موجود أو معطل")
    inv = str(sale["invoice_no"] or sale_id)
    with transaction(conn):
        _restore_sale_stock(conn, sale_id, user_id, f"تعديل فاتورة: {reason.strip()}", inv)
        normalized = _normalize_sale_cart(service, cart, user_id)
        amounts = _calculate_sale_amounts(service, normalized, discount_amount, discount_type)
        _validate_sale_discount_policy(service, user_id, normalized, amounts)
        execute_write(conn, "DELETE FROM sale_items WHERE sale_id=?", (sale_id,))
        execute_write(
            conn,
            """
            UPDATE sales
            SET employee_id=?, customer_id=?, subtotal=?, discount_amount=?, total=?,
                total_commission=?, total_profit=?, payment_method=?, discount_type=?,
                tax_amount=?, note=?
            WHERE id=?
            """,
            (
                employee_id,
                customer_id,
                _f(amounts["gross_subtotal"]),
                _f(amounts["discount_total"]),
                _f(amounts["total"]),
                _f(amounts["commission"]),
                _f(amounts["profit"]),
                payment_method,
                discount_type,
                _f(amounts["tax_amount"]),
                str(note or "").strip(),
                sale_id,
            ),
        )
        _insert_sale_items_and_update_stock(conn, sale_id, inv, normalized, amounts, user_id)
    events.emit("ON_STOCK_CHANGED", {"reason": f"تعديل فاتورة: {reason.strip()}", "sale_id": sale_id, "items": normalized}, source="services.domain.persistence.sales_finance_writes")
    if hasattr(service, "log"):
        service.log("تعديل فاتورة", f"{inv} - السبب: {reason.strip()}", user_id)
    return inv


def delete_sale_native(service: Any, sale_id: int, reason: str = "", user_id: int | None = None) -> bool:
    if not str(reason or "").strip():
        raise ValueError("سبب حذف الفاتورة مطلوب")
    user = service.require_any_permission(("can_returns", "can_audit", "can_users"), user_id, "حذف فاتورة")
    user_id = int(user["id"])
    conn = service.db.conn
    _ensure_app_schema(conn)
    sale = fetch_one_dict(conn, "SELECT id, invoice_no FROM sales WHERE id=?", (sale_id,))
    if not sale:
        raise ValueError("الفاتورة غير موجودة")
    inv = str(sale["invoice_no"] or sale_id)
    with transaction(conn):
        restored_items = _restore_sale_stock(conn, sale_id, user_id, f"حذف فاتورة: {reason.strip()}", inv)
        execute_write(conn, "DELETE FROM sale_items WHERE sale_id=?", (sale_id,))
        if table_exists(conn, "payments"):
            execute_write(conn, "DELETE FROM payments WHERE related_type='فاتورة' AND related_id=?", (sale_id,))
        execute_write(conn, "DELETE FROM sales WHERE id=?", (sale_id,))
    events.emit("ON_STOCK_CHANGED", {"reason": f"حذف فاتورة: {reason.strip()}", "sale_id": sale_id, "restored_items": restored_items}, source="services.domain.persistence.sales_finance_writes")
    if hasattr(service, "log"):
        service.log("حذف فاتورة", f"{inv} - السبب: {reason.strip()}", user_id)
    return True


def add_payment_native(service: Any, customer_id: int, amount: Any, note: str = "") -> int:
    service.require_permission("can_customers", action="تسجيل دفعات الزبائن")
    amount_dec = _positive_decimal(amount, "مبلغ الدفعة")
    conn = service.db.conn
    if not table_exists(conn, "customer_payments") or not require_columns(conn, "customer_payments", {"customer_id", "amount", "receipt_no", "note", "created_at"}):
        raise NativePersistenceUnavailable("schema_missing:customer_payments")
    receipt = receipt_no()
    clean_note = str(note or "").strip()
    created_at = now_text()
    user_id = None
    user_name = ""
    try:
        user = service.require_permission("can_customers", action="تسجيل دفعات الزبائن")
        user_id = int(user.get("id")) if isinstance(user, dict) and user.get("id") is not None else None
        user_name = str(user.get("username") or user.get("full_name") or "") if isinstance(user, dict) else ""
    except Exception:
        # Permission was already checked above; keep audit fields optional.
        pass

    with transaction(conn):
        payment_id = execute_write(
            conn,
            "INSERT INTO customer_payments (customer_id, amount, receipt_no, note, created_at) VALUES (?, ?, ?, ?, ?)",
            (customer_id, _f(amount_dec), receipt, clean_note, created_at),
        )
        if table_exists(conn, "payments") and require_columns(
            conn,
            "payments",
            {"payment_date", "payment_type", "amount", "payment_method", "related_type", "related_id", "customer_id", "description", "note", "source_table", "source_id", "created_at"},
        ):
            execute_write(
                conn,
                """
                INSERT OR IGNORE INTO payments (
                    payment_date, payment_type, amount, payment_method, related_type, related_id,
                    customer_id, description, note, user_id, user_name, source_table, source_id, created_at
                ) VALUES (?, 'قبض', ?, 'نقدي', 'عميل', ?, ?, ?, ?, ?, ?, 'customer_payments', ?, ?)
                """,
                (
                    created_at,
                    _f(amount_dec),
                    int(customer_id),
                    int(customer_id),
                    f"تسديد دين زبون #{customer_id}",
                    clean_note,
                    user_id,
                    user_name,
                    int(payment_id),
                    created_at,
                ),
            )
    if hasattr(service, "log"):
        service.log("تسجيل دفعة زبون", f"{customer_id} - {_f(amount_dec):,.0f}")
    return payment_id

