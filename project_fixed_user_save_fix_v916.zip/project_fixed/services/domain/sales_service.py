from services.core_common import *


class SalesServiceMixin:
        def complete_sale(self, cart: list[dict], employee_id: int, customer_id: int | None, payment_method: str, discount_amount: float = 0, note: str = '', user_id: int | None = None, discount_type: str = 'amount') -> str:
            user = self.require_any_permission(('can_sales', 'can_touch_pos'), user_id, 'إتمام البيع')
            user_id = user['id']
            if not cart:
                raise ValueError('السلة فارغة')
            if not employee_id:
                raise ValueError('اختر الموظف الذي يستحق العمولة')
            employee = self.db.one('SELECT id, active FROM employees WHERE id=? AND active=1', (employee_id,))
            if not employee:
                raise ValueError('الموظف المختار غير موجود أو معطل. العمولات تُسجل للموظفين فقط.')
            for item in cart:
                product = self.db.one('SELECT quantity FROM products WHERE id=?', (item['product_id'],))
                if not product or product['quantity'] < item['quantity']:
                    raise ValueError(f"المخزون غير كاف للمنتج: {item['product_name']}")
            subtotal = sum(item['quantity'] * item['unit_price'] for item in cart)
            discount_value = max(float(discount_amount or 0), 0.0)
            if discount_type == 'percent':
                if discount_value > 100:
                    raise ValueError('نسبة الخصم لا يمكن أن تكون أكبر من 100%')
                discount_amount = subtotal * discount_value / 100
            else:
                if discount_value > subtotal:
                    raise ValueError(f'قيمة الخصم لا يمكن أن تكون أكبر من إجمالي الفاتورة. إجمالي الفاتورة: {money(subtotal)}')
                discount_amount = discount_value
            if discount_amount >= subtotal and subtotal > 0:
                raise ValueError('الخصم لا يمكن أن يساوي أو يتجاوز قيمة الفاتورة')
            taxable_base = max(subtotal - discount_amount, 0)
            tax_percent = to_float(self.get_settings().get('tax_percent', 0))
            tax_amount = taxable_base * tax_percent / 100
            total = taxable_base + tax_amount
    
            # Important accounting rule:
            # Discounts reduce the real sale value, so commission and profit must be
            # calculated on the net line value before tax, not the gross line total.
            commission = 0.0
            profit = 0.0
            for item in cart:
                line_total = item['quantity'] * item['unit_price']
                line_discount = (discount_amount * line_total / subtotal) if subtotal else 0.0
                line_net = line_total - line_discount
                commission += line_net * item['commission_percent'] / 100
                profit += item['quantity'] * (item['unit_price'] - item['cost_price']) - line_discount
            inv = invoice_no()
            with self.db.conn:
                cur = self.db.conn.execute('''INSERT INTO sales (invoice_no, user_id, employee_id, customer_id, subtotal, discount_amount, total, total_commission, total_profit, payment_method, discount_type, tax_amount, note, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (inv, user_id, employee_id, customer_id, subtotal, discount_amount, total, commission, profit, payment_method, discount_type, tax_amount, note.strip(), now_text()))
                sale_id = cur.lastrowid
                for item in cart:
                    line_total = item['quantity'] * item['unit_price']
                    line_discount = (discount_amount * line_total / subtotal) if subtotal else 0.0
                    line_net = line_total - line_discount
                    item_commission = line_net * item['commission_percent'] / 100
                    item_profit = item['quantity'] * (item['unit_price'] - item['cost_price']) - line_discount
                    self.db.conn.execute('''INSERT INTO sale_items (sale_id, product_id, product_name, quantity, cost_price, unit_price, line_total, commission_percent, commission_amount, profit_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (sale_id, item['product_id'], item['product_name'], item['quantity'], item['cost_price'], item['unit_price'], line_total, item['commission_percent'], item_commission, item_profit))
                    oldq = self.db.conn.execute('SELECT quantity FROM products WHERE id=?', (item['product_id'],)).fetchone()['quantity']
                    newq = oldq - item['quantity']
                    self.db.conn.execute('UPDATE products SET quantity=? WHERE id=?', (newq, item['product_id']))
                    self.db.conn.execute('''INSERT INTO inventory_movements (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (item['product_id'], 'بيع', -item['quantity'], oldq, newq, 'sale', inv, '', user_id, now_text()))
            self.log('بيع', inv, user_id)
            return inv

        def suspend_sale(self, cart: list[dict], employee_id: int | None, customer_id: int | None, payment_method: str, discount_amount: float, note: str = '', user_id: int | None = None) -> str:
            user = self.require_any_permission(('can_sales', 'can_touch_pos'), user_id, 'تعليق فاتورة')
            user_id = user['id']
            if not cart:
                raise ValueError('السلة فارغة')
            subtotal = sum(item['quantity'] * item['unit_price'] for item in cart)
            discount_amount = max(float(discount_amount or 0), 0.0)
            if discount_amount > subtotal:
                raise ValueError(f'قيمة الخصم لا يمكن أن تكون أكبر من إجمالي الفاتورة. إجمالي الفاتورة: {money(subtotal)}')
            if discount_amount >= subtotal and subtotal > 0:
                raise ValueError('الخصم لا يمكن أن يساوي أو يتجاوز قيمة الفاتورة')
            hold = 'HOLD-' + datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]
            self.db.execute('''INSERT INTO suspended_sales (hold_no, user_id, employee_id, customer_id, payment_method, discount_amount, note, cart_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''', (hold, user_id, employee_id, customer_id, payment_method, discount_amount, note.strip(), json.dumps(cart, ensure_ascii=False), now_text()))
            self.log('تعليق فاتورة', hold, user_id)
            return hold

        def list_suspended_sales(self):
            return self.db.all('''SELECT h.*, COALESCE(u.username,'-') username, COALESCE(c.name,'زبون عام') customer FROM suspended_sales h LEFT JOIN users u ON u.id=h.user_id LEFT JOIN customers c ON c.id=h.customer_id ORDER BY h.id DESC''')

        def load_suspended_sale(self, hold_id: int):
            row = self.db.one('SELECT * FROM suspended_sales WHERE id=?', (hold_id,))
            if not row:
                raise ValueError('الفاتورة المعلقة غير موجودة')
            return row, json.loads(row['cart_json'])

        def delete_suspended_sale(self, hold_id: int) -> None:
            self.db.execute('DELETE FROM suspended_sales WHERE id=?', (hold_id,))

        def find_sale_for_return(self, invoice: str):
            invoice = invoice.strip()
            if not invoice:
                raise ValueError('اكتب رقم الفاتورة')
            sale = self.db.one('''SELECT s.*, e.name employee, COALESCE(c.name,'زبون عام') customer FROM sales s JOIN employees e ON e.id=s.employee_id LEFT JOIN customers c ON c.id=s.customer_id WHERE s.invoice_no=?''', (invoice,))
            if not sale:
                raise ValueError('لم يتم العثور على الفاتورة')
            items = self.db.all('''SELECT si.*, COALESCE(SUM(r.quantity),0) returned_qty, si.quantity - COALESCE(SUM(r.quantity),0) remaining_qty FROM sale_items si LEFT JOIN returns r ON r.sale_item_id=si.id WHERE si.sale_id=? GROUP BY si.id ORDER BY si.id''', (sale['id'],))
            return sale, items

        def return_item(self, sale_item_id: int, quantity: int, reason: str = '', user_id: int | None = None, refund_method: str = 'نقدي') -> str:
            user = self.require_permission('can_returns', user_id, 'تسجيل المرتجعات')
            user_id = user['id']
            if quantity <= 0:
                raise ValueError('كمية الإرجاع يجب أن تكون أكبر من صفر')
            if not reason.strip():
                raise ValueError('سبب الإرجاع مطلوب')
            row = self.db.one('''SELECT si.*, s.employee_id, s.customer_id, s.id sale_id, COALESCE(SUM(r.quantity),0) returned_qty, si.quantity - COALESCE(SUM(r.quantity),0) remaining_qty FROM sale_items si JOIN sales s ON s.id=si.sale_id LEFT JOIN returns r ON r.sale_item_id=si.id WHERE si.id=? GROUP BY si.id''', (sale_item_id,))
            if not row:
                raise ValueError('المادة غير موجودة في الفاتورة')
            if quantity > row['remaining_qty']:
                raise ValueError('كمية الإرجاع أكبر من الكمية المتبقية')
            gross_amount = quantity * row['unit_price']
            original_subtotal_row = self.db.one('SELECT COALESCE(SUM(line_total),0) v FROM sale_items WHERE sale_id=?', (row['sale_id'],))
            sale_row = self.db.one('SELECT discount_amount, tax_amount FROM sales WHERE id=?', (row['sale_id'],))
            original_subtotal = float(original_subtotal_row['v'] or 0) if original_subtotal_row else 0.0
            original_discount = float(sale_row['discount_amount'] or 0) if sale_row else 0.0
            original_tax = float(sale_row['tax_amount'] or 0) if sale_row else 0.0
            discount_share = (original_discount * gross_amount / original_subtotal) if original_subtotal else 0.0
            net_before_tax = max(gross_amount - discount_share, 0.0)
            taxable_base = max(original_subtotal - original_discount, 0.0)
            tax_share = (original_tax * net_before_tax / taxable_base) if taxable_base else 0.0
            amount = net_before_tax + tax_share
            commission = net_before_tax * row['commission_percent'] / 100
            profit = quantity * (row['unit_price'] - row['cost_price']) - discount_share
            ret = return_no()
            with self.db.conn:
                self.db.conn.execute('''INSERT INTO returns (return_no, sale_id, sale_item_id, product_id, product_name, employee_id, customer_id, quantity, unit_price, amount, commission_amount, profit_amount, reason, refund_method, created_by_user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (ret, row['sale_id'], row['id'], row['product_id'], row['product_name'], row['employee_id'], row['customer_id'], quantity, row['unit_price'], amount, commission, profit, reason.strip(), refund_method, user_id, now_text()))
                oldq = self.db.conn.execute('SELECT quantity FROM products WHERE id=?', (row['product_id'],)).fetchone()['quantity']
                newq = oldq + quantity
                self.db.conn.execute('UPDATE products SET quantity=? WHERE id=?', (newq, row['product_id']))
                self.db.conn.execute('''INSERT INTO inventory_movements (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (row['product_id'], 'مرتجع', quantity, oldq, newq, 'return', ret, reason.strip(), user_id, now_text()))
                # Keep original subtotal/discount/tax as the invoice basis for future
                # proportional returns. Adjust only the remaining financial totals.
                self.db.conn.execute('''UPDATE sales SET total=CASE WHEN (total-?) < 0 THEN 0 ELSE (total-?) END, total_commission=CASE WHEN (total_commission-?) < 0 THEN 0 ELSE (total_commission-?) END, total_profit=CASE WHEN (total_profit-?) < 0 THEN 0 ELSE (total_profit-?) END WHERE id=?''', (amount, commission, profit, row['sale_id']))
            self.log('مرتجع', ret, user_id)
            return ret

        def return_full_sale(self, sale_id: int, reason: str = '', user_id: int | None = None, refund_method: str = 'نقدي') -> list[str]:
            user = self.require_permission('can_returns', user_id, 'إرجاع الفواتير')
            user_id = user['id']
            items = self.db.all('''SELECT si.id, si.quantity - COALESCE(SUM(r.quantity),0) remaining_qty FROM sale_items si LEFT JOIN returns r ON r.sale_item_id=si.id WHERE si.sale_id=? GROUP BY si.id''', (sale_id,))
            numbers = []
            for item in items:
                if item['remaining_qty'] > 0:
                    numbers.append(self.return_item(item['id'], int(item['remaining_qty']), reason, user_id, refund_method))
            if not numbers:
                raise ValueError('لا توجد مواد متبقية للإرجاع في هذه الفاتورة')
            return numbers

        def list_returns(self, limit: int = 200):
            return self.db.all('''SELECT r.*, s.invoice_no, e.name employee, COALESCE(c.name,'زبون عام') customer, COALESCE(u.username,'-') created_by FROM returns r JOIN sales s ON s.id=r.sale_id JOIN employees e ON e.id=r.employee_id LEFT JOIN customers c ON c.id=r.customer_id LEFT JOIN users u ON u.id=r.created_by_user_id ORDER BY r.id DESC LIMIT ?''', (limit,))

        def list_sales(self, limit: int = 200):
            return self.db.all('''SELECT s.*, e.name employee, COALESCE(c.name,'زبون عام') customer, COALESCE(NULLIF(u.full_name,''), u.username, '-') user_name FROM sales s JOIN employees e ON e.id=s.employee_id LEFT JOIN customers c ON c.id=s.customer_id LEFT JOIN users u ON u.id=s.user_id ORDER BY s.id DESC LIMIT ?''', (limit,))
