from __future__ import annotations

"""Native-only persistence monitoring analytics for v1.0.0 Stable."""

import json
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[2]
LOG_PATH = PROJECT_ROOT / "logs" / "persistence_paths.log"
OLD_LOG_PATH = PROJECT_ROOT / "logs" / "persistence_fallback.log"


def _parse_timestamp(value: Any) -> datetime | None:
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(text)
    except ValueError:
        return None


def read_log_data(log_path: str | Path | None = None) -> list[dict[str, Any]]:
    """Read JSON-lines persistence monitoring data.

    Invalid or old plain-text lines are ignored so archived monitoring logs never break the
    dashboard.
    """
    paths = [Path(log_path)] if log_path else [LOG_PATH, OLD_LOG_PATH]
    data: list[dict[str, Any]] = []
    for path in paths:
        if not path.exists():
            continue
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(entry, dict):
                    data.append(entry)
    return data


def get_migration_stats(log_path: str | Path | None = None, *, days: int = 7) -> dict[str, Any]:
    """Return dashboard-ready Native/Fallback migration statistics."""
    data = read_log_data(log_path)
    total = len(data)
    if total == 0:
        return {
            "status": "EMPTY",
            "message": "لا توجد بيانات مراقبة حتى الآن",
            "completion_percent": 0.0,
            "recent_completion_percent": 0.0,
            "total_ops": 0,
            "native_ops": 0,
            "fallback_ops": 0,
            "legacy_ops": 0,
            "reasons_summary": {},
            "operations_summary": {},
            "last_event_at": None,
            "last_check": datetime.now().isoformat(timespec="seconds"),
        }

    native = [row for row in data if row.get("path") == "NATIVE"]
    fallback = [row for row in data if row.get("path") == "FALLBACK"]
    legacy = [row for row in data if row.get("path") == "LEGACY"]

    reasons = Counter(str(row.get("reason") or "غير معروف") for row in fallback)
    operations = Counter(str(row.get("operation") or "unknown") for row in data)

    cutoff = datetime.now() - timedelta(days=days)
    recent: list[dict[str, Any]] = []
    for row in data:
        ts = _parse_timestamp(row.get("timestamp"))
        if ts and ts.replace(tzinfo=None) >= cutoff:
            recent.append(row)
    recent_native = [row for row in recent if row.get("path") == "NATIVE"]

    timestamps = [_parse_timestamp(row.get("timestamp")) for row in data]
    valid_timestamps = [ts for ts in timestamps if ts is not None]

    return {
        "status": "ANALYZED",
        "completion_percent": round((len(native) / total) * 100, 2) if total else 0.0,
        "recent_completion_percent": round((len(recent_native) / len(recent)) * 100, 2) if recent else 0.0,
        "total_ops": total,
        "native_ops": len(native),
        "fallback_ops": len(fallback),
        "legacy_ops": len(legacy),
        "reasons_summary": dict(reasons.most_common()),
        "operations_summary": dict(operations.most_common()),
        "last_event_at": max(valid_timestamps).isoformat(timespec="seconds") if valid_timestamps else None,
        "last_check": datetime.now().isoformat(timespec="seconds"),
    }


def get_monitoring_health(log_path: str | Path | None = None) -> dict[str, Any]:
    """Small health summary for UI cards or admin diagnostics."""
    stats = get_migration_stats(log_path)
    if stats["status"] == "EMPTY":
        level = "INFO"
    elif stats["fallback_ops"] == 0:
        level = "OK"
    elif stats["completion_percent"] >= 90:
        level = "WARN"
    else:
        level = "ACTION_REQUIRED"
    return {**stats, "health_level": level}
