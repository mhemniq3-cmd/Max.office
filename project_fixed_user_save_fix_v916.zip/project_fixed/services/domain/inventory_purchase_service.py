from services.core_common import *


class InventoryPurchaseServiceMixin:
        def list_branches(self):
            return self.db.all('SELECT * FROM branches WHERE active=1 ORDER BY name')

        def list_warehouses(self):
            return self.db.all("""SELECT w.*, COALESCE(b.name,'-') branch_name FROM warehouses w LEFT JOIN branches b ON b.id=w.branch_id WHERE w.active=1 ORDER BY branch_name, w.name""")

        def save_branch(self, name: str, address: str = '', phone: str = '') -> None:
            self.require_permission('can_inventory', action='حفظ الفروع')
            name = (name or '').strip()
            if not name:
                raise ValueError('اسم الفرع مطلوب')
            self.db.execute('INSERT INTO branches (name, address, phone, active, created_at) VALUES (?, ?, ?, 1, ?) ON CONFLICT(name) DO UPDATE SET address=excluded.address, phone=excluded.phone, active=1', (name, address.strip(), phone.strip(), now_text()))
            self.log('حفظ فرع', name)

        def save_warehouse(self, name: str, branch_id: int | None = None, address: str = '') -> None:
            self.require_permission('can_inventory', action='حفظ المخازن')
            name = (name or '').strip()
            if not name:
                raise ValueError('اسم المخزن مطلوب')
            self.db.execute('INSERT INTO warehouses (branch_id, name, address, active, created_at) VALUES (?, ?, ?, 1, ?)', (branch_id, name, address.strip(), now_text()))
            self.log('حفظ مخزن', name)

        def record_inventory_count(self, product_id: int, counted_quantity: int, damaged_quantity: int = 0, branch_id: int | None = None, warehouse_id: int | None = None, note: str = '', user_id: int | None = None) -> None:
            user = self.require_any_permission(('can_inventory', 'can_quantity_edit'), user_id, 'تسجيل الجرد')
            user_id = user['id']
            if counted_quantity < 0 or damaged_quantity < 0:
                raise ValueError('الكميات لا يمكن أن تكون سالبة')
            row = self.db.one('SELECT quantity FROM products WHERE id=?', (product_id,))
            if not row:
                raise ValueError('المنتج غير موجود')
            system_qty = int(row['quantity'])
            usable_qty = max(0, int(counted_quantity) - int(damaged_quantity))
            diff = usable_qty - system_qty
            with self.db.conn:
                self.db.conn.execute('UPDATE products SET quantity=?, branch_id=?, warehouse_id=? WHERE id=?', (usable_qty, branch_id, warehouse_id, product_id))
                self.db.conn.execute("""INSERT INTO inventory_counts (product_id, branch_id, warehouse_id, system_quantity, counted_quantity, difference, damaged_quantity, note, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", (product_id, branch_id, warehouse_id, system_qty, counted_quantity, diff, damaged_quantity, note.strip(), user_id, now_text()))
                self.db.conn.execute("""INSERT INTO inventory_movements (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", (product_id, 'جرد متقدم', diff, system_qty, usable_qty, 'inventory_count', '', f'تالف: {damaged_quantity} | {note}'.strip(), user_id, now_text()))
            self.log('جرد متقدم', f'منتج {product_id}: النظام {system_qty}, المعدود {counted_quantity}, التالف {damaged_quantity}, الفرق {diff}', user_id)

        def inventory_count_rows(self, limit: int = 300):
            return self.db.all("""SELECT ic.*, p.name product_name, COALESCE(b.name,'-') branch_name, COALESCE(w.name,'-') warehouse_name FROM inventory_counts ic JOIN products p ON p.id=ic.product_id LEFT JOIN branches b ON b.id=ic.branch_id LEFT JOIN warehouses w ON w.id=ic.warehouse_id ORDER BY ic.id DESC LIMIT ?""", (limit,))

        def list_suppliers(self, active_only: bool = True):
            if active_only:
                return self.db.all('SELECT * FROM suppliers WHERE active=1 ORDER BY name')
            return self.db.all('SELECT * FROM suppliers ORDER BY active DESC, name')

        def save_supplier(self, name: str, phone: str = '', address: str = '', note: str = '', supplier_id: int | None = None) -> None:
            self.require_permission('can_suppliers', action='حفظ الموردين')
            name = (name or '').strip()
            if not name:
                raise ValueError('اسم المورد مطلوب')
            if supplier_id:
                self.db.execute('UPDATE suppliers SET name=?, phone=?, address=?, note=? WHERE id=?', (name, phone.strip(), address.strip(), note.strip(), supplier_id))
            else:
                self.db.execute('INSERT INTO suppliers (name, phone, address, note, active, created_at) VALUES (?, ?, ?, ?, 1, ?)', (name, phone.strip(), address.strip(), note.strip(), now_text()))
            self.log('حفظ مورد', name)

        def create_purchase(self, supplier_id: int, items: list[dict], paid_amount: float = 0, payment_method: str = 'نقدي', discount_amount: float = 0, note: str = '', user_id: int | None = None) -> str:
            user = self.require_permission('can_purchases', user_id, 'إنشاء فاتورة شراء')
            user_id = user['id']
            if not supplier_id:
                raise ValueError('اختر المورد')
            if not items:
                raise ValueError('فاتورة الشراء فارغة')
            subtotal = sum(int(i['quantity']) * float(i['unit_cost']) for i in items)
            discount_amount = min(max(float(discount_amount or 0), 0), subtotal)
            total = subtotal - discount_amount
            paid_amount = min(max(float(paid_amount or 0), 0), total)
            pno = purchase_no()
            with self.db.conn:
                cur = self.db.conn.execute('''INSERT INTO purchases (purchase_no, supplier_id, user_id, subtotal, discount_amount, total, paid_amount, payment_method, note, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (pno, supplier_id, user_id, subtotal, discount_amount, total, paid_amount, payment_method, note.strip(), now_text()))
                purchase_id = cur.lastrowid
                for item in items:
                    pid = int(item['product_id']); qty = int(item['quantity']); cost = float(item['unit_cost']); gross_line = qty * cost
                    product = self.db.conn.execute('SELECT name, quantity, cost_price FROM products WHERE id=?', (pid,)).fetchone()
                    if not product:
                        raise ValueError('منتج الشراء غير موجود')
                    line_discount = (discount_amount * gross_line / subtotal) if subtotal else 0.0
                    net_line = gross_line - line_discount
                    net_unit_cost = (net_line / qty) if qty else cost
                    oldq = int(product['quantity']); newq = oldq + qty
                    old_cost = float(product['cost_price'] or 0)
                    avg_cost = ((oldq * old_cost) + net_line) / newq if newq else net_unit_cost
                    self.db.conn.execute('''INSERT INTO purchase_items (purchase_id, product_id, product_name, quantity, unit_cost, line_total) VALUES (?, ?, ?, ?, ?, ?)''', (purchase_id, pid, product['name'], qty, net_unit_cost, net_line))
                    self.db.conn.execute('UPDATE products SET quantity=?, cost_price=? WHERE id=?', (newq, avg_cost, pid))
                    self.db.conn.execute('''INSERT INTO inventory_movements (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (pid, 'شراء', qty, oldq, newq, 'purchase', pno, 'إدخال بضاعة من المورد', user_id, now_text()))
                if paid_amount > 0:
                    self.db.conn.execute('INSERT INTO supplier_payments (supplier_id, amount, receipt_no, note, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?)', (supplier_id, paid_amount, receipt_no(), f'دفعة على فاتورة {pno}', user_id, now_text()))
            self.log('فاتورة شراء', f'{pno} - {total:,.0f}', user_id)
            return pno

        def list_purchases(self, limit: int = 300):
            return self.db.all("SELECT p.*, s.name supplier, COALESCE(NULLIF(u.full_name,''), u.username, '-') user_name FROM purchases p JOIN suppliers s ON s.id=p.supplier_id LEFT JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT ?", (limit,))

        def add_supplier_payment(self, supplier_id: int, amount: float, note: str = '', user_id: int | None = None) -> int:
            user = self.require_any_permission(('can_purchases', 'can_suppliers'), user_id, 'تسديد الموردين')
            user_id = user['id']
            if amount <= 0:
                raise ValueError('مبلغ الدفعة يجب أن يكون أكبر من صفر')
            cur = self.db.execute('INSERT INTO supplier_payments (supplier_id, amount, receipt_no, note, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?)', (supplier_id, amount, receipt_no(), note.strip(), user_id, now_text()))
            self.log('تسديد مورد', f'{supplier_id} - {amount:,.0f}', user_id)
            return cur.lastrowid

        def supplier_debt_rows(self):
            return self.db.all('''WITH ps AS (SELECT supplier_id, SUM(total) total_purchase FROM purchases GROUP BY supplier_id), py AS (SELECT supplier_id, SUM(amount) payments FROM supplier_payments GROUP BY supplier_id) SELECT s.id, s.name, s.phone, s.address, COALESCE(ps.total_purchase,0) total_purchase, COALESCE(py.payments,0) payments, COALESCE(ps.total_purchase,0)-COALESCE(py.payments,0) balance FROM suppliers s LEFT JOIN ps ON ps.supplier_id=s.id LEFT JOIN py ON py.supplier_id=s.id WHERE s.active=1 ORDER BY balance DESC, s.name''')

        def supplier_statement(self, supplier_id: int):
            rows=[]
            for p in self.db.all('SELECT purchase_no ref, created_at, total amount, note FROM purchases WHERE supplier_id=? ORDER BY created_at', (supplier_id,)):
                rows.append(dict(kind='شراء', ref=p['ref'], created_at=p['created_at'], debit=float(p['amount']), credit=0, note=p['note'] or 'فاتورة شراء'))
            for pay in self.db.all('SELECT COALESCE(receipt_no,id) ref, created_at, amount, note FROM supplier_payments WHERE supplier_id=? ORDER BY created_at', (supplier_id,)):
                rows.append(dict(kind='تسديد', ref=str(pay['ref']), created_at=pay['created_at'], debit=0, credit=float(pay['amount']), note=pay['note'] or 'دفعة مورد'))
            return sorted(rows, key=lambda x:x['created_at'])
