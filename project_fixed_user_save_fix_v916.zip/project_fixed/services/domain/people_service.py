from services.core_common import *


class PeopleServiceMixin:
        def ensure_employee_for_user(self, user) -> tuple[int | None, str]:
            """Return an employee id that matches the logged-in user display name.
    
            Commission in sales is linked to employees, while login uses users.
            This method creates a matching active employee row when needed so the
            commission employee can show the same full name as the system user.
            """
            if not user:
                return None, ''
            try:
                display = (user['full_name'] or user['username'] or '').strip()
            except Exception:
                display = ''
            if not display:
                return None, ''
            row = self.db.one('SELECT id, name FROM employees WHERE active=1 AND name=?', (display,))
            if row:
                return row['id'], row['name']
            self.db.execute('INSERT INTO employees (name, phone, active, created_at) VALUES (?, ?, 1, ?)', (display, '', now_text()))
            row = self.db.one('SELECT id, name FROM employees WHERE active=1 AND name=? ORDER BY id DESC LIMIT 1', (display,))
            self.log('إنشاء موظف عمولة تلقائي', display, user['id'] if 'id' in user.keys() else None, user['username'] if 'username' in user.keys() else '')
            return (row['id'], row['name']) if row else (None, display)

        def list_employees(self):
            return self.db.all('SELECT * FROM employees WHERE active=1 ORDER BY name')

        def list_customers(self, active_only: bool = True):
            if active_only:
                return self.db.all('SELECT * FROM customers WHERE active=1 ORDER BY name')
            return self.db.all('SELECT * FROM customers ORDER BY active DESC, name')

        def save_customer(self, name: str, phone: str = '', address: str = '', customer_id: int | None = None, credit_limit: float = 0, due_days: int = 0) -> None:
            self.require_permission('can_customers', action='حفظ الزبائن')
            name = name.strip()
            if not name:
                raise ValueError('اسم الزبون مطلوب')
            if customer_id:
                self.db.execute('UPDATE customers SET name=?, phone=?, address=?, credit_limit=?, due_days=? WHERE id=?', (name, phone.strip(), address.strip(), credit_limit, due_days, customer_id))
            else:
                self.db.execute('INSERT INTO customers (name, phone, address, credit_limit, due_days, active, created_at) VALUES (?, ?, ?, ?, ?, 1, ?)', (name, phone.strip(), address.strip(), credit_limit, due_days, now_text()))
            self.log('حفظ زبون', name)

        def add_payment(self, customer_id: int, amount: float, note: str = '') -> int:
            self.require_permission('can_customers', action='تسجيل دفعات الزبائن')
            if amount <= 0:
                raise ValueError('مبلغ الدفعة يجب أن يكون أكبر من صفر')
            receipt = receipt_no()
            cur = self.db.execute('INSERT INTO customer_payments (customer_id, amount, receipt_no, note, created_at) VALUES (?, ?, ?, ?, ?)', (customer_id, amount, receipt, note.strip(), now_text()))
            self.log('تسجيل دفعة زبون', f'{customer_id} - {amount:,.0f}')
            return cur.lastrowid

        def debt_rows(self):
            return self.db.all('''
                WITH credit AS (
                    SELECT customer_id, SUM(CASE WHEN (subtotal-discount_amount+tax_amount) < 0 THEN 0 ELSE (subtotal-discount_amount+tax_amount) END) credit_sales FROM sales WHERE payment_method='آجل' GROUP BY customer_id
                ), returned AS (
                    SELECT s.customer_id, SUM(r.amount) returns_amount FROM returns r JOIN sales s ON s.id=r.sale_id GROUP BY s.customer_id
                ), payments AS (
                    SELECT customer_id, SUM(amount) payments FROM customer_payments GROUP BY customer_id
                )
                SELECT c.id, c.name, c.phone, c.credit_limit, c.due_days,
                       COALESCE(credit.credit_sales,0) credit_sales,
                       COALESCE(returned.returns_amount,0) returns_amount,
                       COALESCE(payments.payments,0) payments,
                       COALESCE(credit.credit_sales,0) - COALESCE(returned.returns_amount,0) - COALESCE(payments.payments,0) balance
                FROM customers c
                LEFT JOIN credit ON credit.customer_id=c.id
                LEFT JOIN returned ON returned.customer_id=c.id
                LEFT JOIN payments ON payments.customer_id=c.id
                WHERE c.active=1
                ORDER BY balance DESC, c.name
            ''')

        def customer_statement(self, customer_id: int):
            rows = []
            for sale in self.db.all('SELECT invoice_no ref, created_at, CASE WHEN (subtotal-discount_amount+tax_amount) < 0 THEN 0 ELSE (subtotal-discount_amount+tax_amount) END amount, payment_method note FROM sales WHERE customer_id=? ORDER BY created_at LIMIT 2000', (customer_id,)):
                rows.append(dict(kind='بيع', ref=sale['ref'], created_at=sale['created_at'], debit=sale['amount'] if sale['note'] == 'آجل' else 0, credit=0, note=sale['note']))
            for ret in self.db.all('''SELECT r.return_no ref, r.created_at, r.amount FROM returns r JOIN sales s ON s.id=r.sale_id WHERE s.customer_id=? ORDER BY r.created_at LIMIT 2000''', (customer_id,)):
                rows.append(dict(kind='مرتجع', ref=ret['ref'], created_at=ret['created_at'], debit=0, credit=ret['amount'], note='مرتجع'))
            for pay in self.db.all('SELECT COALESCE(receipt_no,id) ref, created_at, amount, note FROM customer_payments WHERE customer_id=? ORDER BY created_at LIMIT 2000', (customer_id,)):
                rows.append(dict(kind='دفعة', ref=str(pay['ref']), created_at=pay['created_at'], debit=0, credit=pay['amount'], note=pay['note'] or 'دفعة'))
            return sorted(rows, key=lambda x: x['created_at'])
