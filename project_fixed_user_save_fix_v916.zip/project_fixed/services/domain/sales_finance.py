from __future__ import annotations

"""Read-only sales, invoices, customers, debts, cash, and finance domain services.

Stage 7 intentionally migrates only query/report methods.  Mutations such as
complete_sale, return_item, add_payment, open/close shift, deposits,
withdrawals, settlements, and any update/post/save operation remain in
service_patches until the final sensitive-operation phase.
"""

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any, Final, Iterable, Sequence

DOMAIN: Final[str] = "sales_finance"
READ_ONLY_METHODS: Final[tuple[str, ...]] = (
    "list_invoices",
    "list_sales",
    "get_invoice_details",
    "invoice_details",
    "search_invoice",
    "get_invoice_totals",
    "list_receipts",
    "list_returns",
    "list_returned_items",
    "get_customer_statement",
    "customer_statement",
    "customer_statement_detailed",
    "get_customer_balance",
    "customer_balance",
    "customer_balance_for_pos",
    "list_customer_transactions",
    "list_debts",
    "debt_rows",
    "customer_debt_summary",
    "get_overdue_amounts",
    "list_payments_received",
    "list_cash_shifts",
    "list_cashier_shifts",
    "get_shift_details",
    "get_shift_summary",
    "shift_financial_summary",
    "list_cash_movements",
    "get_cash_balance",
    "get_sales_totals_by_period",
    "get_profit_details",
    "get_tax_totals",
    # Stage 8: pure calculation helpers. These methods never touch the DB.
    "calculate_item_total",
    "calculate_tax_amount",
    "calculate_discount",
    "calculate_invoice_totals",
    "calculate_invoice_totals_decimal",
    "calculate_profit",
    "calculate_invoice_profit",
    "calculate_remaining_amount",
    "calculate_credit_impact",
    "calculate_return_values",
    "prepare_invoice_payload",
    "sale_preview_payload",
    "normalize_finance_output_dates",
)
METHODS: Final[tuple[str, ...]] = (
    "add_payment", "add_quick_sale_product", "add_supplier_payment", "ai_sales_forecast",
    "archive_sale_invoice", "calculate_invoice_totals", "calculate_invoice_totals_decimal",
    "cancel_sale", "cashier_report", "cashier_shift_report_html", "close_cashier_shift",
    "complete_sale", "create_purchase_return", "current_cashier_shift", "customer_balance",
    "customer_balance_for_pos", "customer_debt_summary", "customer_statement",
    "customer_statement_detailed", "debt_rows", "delete_suspended_sale", "ensure_v40_pos_schema",
    "ensure_v41_shift_schema", "favorite_customers_for_pos", "find_sale_for_return",
    "get_product_for_pos", "invoice_details", "invoice_qr_data_uri", "invoice_qr_payload",
    "invoice_template_html", "list_cashier_shifts", "list_products_for_sale",
    "list_purchase_returns", "list_quick_sale_products", "list_returns", "list_sales",
    "list_suspended_sales", "load_suspended_sale", "move_quick_sale_product",
    "open_cashier_shift", "print_customer_statement_html", "print_invoice_html",
    "print_payment_receipt_html", "print_return_html", "quick_sale_summary",
    "remove_quick_sale_product", "resolve_sale_line", "resolve_sale_line_advanced",
    "return_full_sale", "return_item", "sale_preview_payload", "sales_forecast",
    "sales_report_by_category", "save_invoice_pdf_auto", "shift_financial_summary",
    "supplier_debt_rows", "suspend_sale", *READ_ONLY_METHODS,
)

MUTATION_METHOD_DENYLIST: Final[set[str]] = {
    "complete_sale", "save_invoice", "return_item", "return_full_sale", "add_payment",
    "open_shift", "close_shift", "open_cashier_shift", "close_cashier_shift",
    "deposit_cash", "withdraw_cash", "settle_debt",
}


def _domain(fn):
    setattr(fn, "_domain_implementation", True)
    return fn


def _table_exists(self: Any, table: str) -> bool:
    return bool(self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)))


def _columns(self: Any, table: str) -> set[str]:
    try:
        return {str(row[1]) for row in self.db.conn.execute(f"PRAGMA table_info({table})")}
    except Exception:
        return set()


def _has_col(self: Any, table: str, column: str) -> bool:
    return column in _columns(self, table)


def _row_dict(row: Any) -> dict[str, Any] | None:
    if row is None:
        return None
    if isinstance(row, dict):
        return dict(row)
    try:
        return {str(key): row[key] for key in row.keys()}
    except Exception:
        try:
            return dict(row)
        except Exception:
            return {"value": row}


def _rows(rows: Iterable[Any]) -> list[dict[str, Any]]:
    return [item for item in (_row_dict(row) for row in (rows or [])) if item is not None]


def _clean(value: Any, max_len: int = 250) -> str:
    try:
        from services.domain.operations_core import clean_text

        return str(clean_text(value, max_len) or "")[:max_len]
    except Exception:
        return " ".join(str(value or "").replace("\x00", " ").split())[:max_len]


def _normalize_date(value: Any) -> str:
    if not value:
        return ""
    try:
        from services.domain.operations_core import normalize_date_format

        text = str(normalize_date_format(None, value) or "")[:10]
        if text:
            return text
    except Exception:
        pass
    return str(value).strip()[:10]


def _limit(value: Any, default: int = 200, maximum: int = 5000) -> int:
    try:
        return max(1, min(int(value or default), maximum))
    except Exception:
        return default


def _offset(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except Exception:
        return 0


def _D(value: Any) -> Decimal:
    try:
        text = str(value if value is not None else "0").replace(",", "").strip()
        return Decimal(text or "0")
    except (InvalidOperation, ValueError, TypeError):
        return Decimal("0")


def _F(value: Any) -> float:
    return float(_D(value).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def _I(value: Any) -> int | None:
    try:
        if value in (None, ""):
            return None
        return int(value)
    except Exception:
        return None


def _sales_total_expr(alias: str = "s") -> str:
    prefix = f"{alias}." if alias else ""
    return f"CASE WHEN COALESCE({prefix}total, {prefix}subtotal - {prefix}discount_amount + {prefix}tax_amount, 0) < 0 THEN 0 ELSE COALESCE({prefix}total, {prefix}subtotal - {prefix}discount_amount + {prefix}tax_amount, 0) END"


def _date_clauses(column: str, date_from: Any = "", date_to: Any = "") -> tuple[list[str], list[Any]]:
    clauses: list[str] = []
    params: list[Any] = []
    start = _normalize_date(date_from)
    end = _normalize_date(date_to)
    if start:
        clauses.append(f"date({column}) >= date(?)")
        params.append(start)
    if end:
        clauses.append(f"date({column}) <= date(?)")
        params.append(end)
    return clauses, params


def _order_date_col(self: Any, table: str) -> str:
    for col in ("created_at", "invoice_date", "date", "payment_date"):
        if _has_col(self, table, col):
            return col
    return "id"


def _sale_select_sql(self: Any) -> str:
    joins = []
    cols = [
        "s.*",
        "COALESCE(c.name, 'زبون عام') AS customer_name",
        "COALESCE(c.name, 'زبون عام') AS customer",
    ]
    if _table_exists(self, "employees"):
        joins.append("LEFT JOIN employees e ON e.id=s.employee_id")
        cols.append("COALESCE(e.name, '') AS employee_name")
        cols.append("COALESCE(e.name, '') AS employee")
    if _table_exists(self, "users"):
        joins.append("LEFT JOIN users u ON u.id=s.user_id")
        cols.append("COALESCE(NULLIF(u.full_name,''), u.username, '') AS user_name")
    if _table_exists(self, "customers"):
        joins.append("LEFT JOIN customers c ON c.id=s.customer_id")
    else:
        cols = [c for c in cols if "customer_name" not in c and " AS customer" not in c]
    return f"SELECT {', '.join(cols)} FROM sales s {' '.join(joins)}"


def _sale_lookup_clause(identifier: Any) -> tuple[str, list[Any]]:
    if isinstance(identifier, int) or (isinstance(identifier, str) and identifier.isdigit()):
        return "s.id=?", [int(identifier)]
    return "s.invoice_no=?", [str(identifier)]


def _safe_status(status: Any) -> str:
    return _clean(status, 50)


@_domain
def list_invoices(
    self: Any,
    status: str = "",
    customer_id: int | None = None,
    date_from: str = "",
    date_to: str = "",
    payment_method: str = "",
    term: str = "",
    limit: int = 200,
    offset: int = 0,
) -> list[dict[str, Any]]:
    """List sales invoices with safe filters and pagination."""
    if not _table_exists(self, "sales"):
        return []
    where: list[str] = []
    params: list[Any] = []
    status_text = _safe_status(status)
    if status_text:
        where.append("COALESCE(s.status,'completed')=?")
        params.append(status_text)
    cid = _I(customer_id)
    if cid is not None:
        where.append("s.customer_id=?")
        params.append(cid)
    method = _clean(payment_method, 50)
    if method:
        where.append("s.payment_method=?")
        params.append(method)
    date_parts, date_params = _date_clauses("s.created_at", date_from, date_to)
    where.extend(date_parts)
    params.extend(date_params)
    text = _clean(term, 120)
    if text:
        like = f"%{text}%"
        clauses = ["s.invoice_no LIKE ?", "s.receipt_no LIKE ?", "s.note LIKE ?"]
        params.extend([like, like, like])
        if _table_exists(self, "customers"):
            clauses.append("c.name LIKE ?")
            params.append(like)
        where.append("(" + " OR ".join(clauses) + ")")
    sql = _sale_select_sql(self)
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY s.created_at DESC, s.id DESC LIMIT ? OFFSET ?"
    params.extend([_limit(limit, 200, 5000), _offset(offset)])
    return _rows(self.db.all(sql, params))


@_domain
def list_sales(self: Any, limit: int = 200, *args: Any, **kwargs: Any) -> list[dict[str, Any]]:
    return list_invoices(self, limit=limit, *args, **kwargs)


@_domain
def search_invoice(self: Any, query: Any = "", limit: int = 50, offset: int = 0) -> list[dict[str, Any]]:
    return list_invoices(self, term=_clean(query, 120), limit=limit, offset=offset)


def _invoice_items(self: Any, sale_id: int) -> list[dict[str, Any]]:
    if not _table_exists(self, "sale_items"):
        return []
    return _rows(self.db.all("SELECT * FROM sale_items WHERE sale_id=? ORDER BY id", (int(sale_id),)))


@_domain
def invoice_details(self: Any, invoice_no: Any):
    """Legacy-compatible invoice lookup: returns (sale, items)."""
    if not _table_exists(self, "sales"):
        return None, []
    clause, params = _sale_lookup_clause(invoice_no)
    sale = _row_dict(self.db.one(_sale_select_sql(self) + f" WHERE {clause} LIMIT 1", params))
    if not sale:
        return None, []
    return sale, _invoice_items(self, int(sale.get("id") or 0))


@_domain
def get_invoice_details(self: Any, invoice_no: Any) -> dict[str, Any] | None:
    sale, items = invoice_details(self, invoice_no)
    if not sale:
        return None
    return {"invoice": sale, "items": items, "totals": get_invoice_totals(self, sale.get("id") or sale.get("invoice_no"))}


@_domain
def get_invoice_totals(self: Any, invoice_no: Any) -> dict[str, float]:
    sale, items = invoice_details(self, invoice_no)
    if not sale:
        return {"subtotal": 0.0, "discount_amount": 0.0, "tax_amount": 0.0, "total": 0.0, "paid": 0.0, "balance": 0.0}
    subtotal = _D(sale.get("subtotal"))
    if subtotal == 0:
        subtotal = sum((_D(i.get("line_total")) for i in items), Decimal("0"))
    discount = _D(sale.get("discount_amount"))
    tax = _D(sale.get("tax_amount"))
    total = _D(sale.get("total")) or (subtotal - discount + tax)
    paid = Decimal("0") if str(sale.get("payment_method") or "") == "آجل" else total
    balance = max(total - paid, Decimal("0"))
    return {
        "subtotal": _F(subtotal),
        "discount_amount": _F(discount),
        "tax_amount": _F(tax),
        "total": _F(total),
        "paid": _F(paid),
        "balance": _F(balance),
        "items_count": float(len(items)),
    }


@_domain
def list_receipts(self: Any, customer_id: int | None = None, limit: int = 200, offset: int = 0) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    cid = _I(customer_id)
    if _table_exists(self, "customer_payments"):
        where = []
        params: list[Any] = []
        if cid is not None:
            where.append("cp.customer_id=?")
            params.append(cid)
        sql = "SELECT cp.*, COALESCE(c.name,'') customer_name FROM customer_payments cp LEFT JOIN customers c ON c.id=cp.customer_id"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY cp.created_at DESC, cp.id DESC LIMIT ? OFFSET ?"
        params.extend([_limit(limit), _offset(offset)])
        rows.extend(_rows(self.db.all(sql, params)))
    elif _table_exists(self, "payments"):
        where = ["payment_type IN ('قبض','receipt','customer_payment')"]
        params = []
        if cid is not None:
            where.append("p.customer_id=?")
            params.append(cid)
        sql = "SELECT p.*, COALESCE(c.name,'') customer_name FROM payments p LEFT JOIN customers c ON c.id=p.customer_id WHERE " + " AND ".join(where)
        sql += " ORDER BY COALESCE(p.payment_date,p.created_at) DESC, p.id DESC LIMIT ? OFFSET ?"
        params.extend([_limit(limit), _offset(offset)])
        rows.extend(_rows(self.db.all(sql, params)))
    return rows


@_domain
def list_returns(self: Any, limit: int = 200, offset: int = 0, customer_id: int | None = None) -> list[dict[str, Any]]:
    if not _table_exists(self, "returns"):
        return []
    where: list[str] = []
    params: list[Any] = []
    cid = _I(customer_id)
    if cid is not None:
        where.append("r.customer_id=?")
        params.append(cid)
    sql = """
        SELECT r.*, s.invoice_no, COALESCE(c.name,'') customer_name
        FROM returns r
        LEFT JOIN sales s ON s.id=r.sale_id
        LEFT JOIN customers c ON c.id=COALESCE(r.customer_id, s.customer_id)
    """
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY r.created_at DESC, r.id DESC LIMIT ? OFFSET ?"
    params.extend([_limit(limit), _offset(offset)])
    return _rows(self.db.all(sql, params))


@_domain
def list_returned_items(self: Any, *args: Any, **kwargs: Any) -> list[dict[str, Any]]:
    return list_returns(self, *args, **kwargs)


@_domain
def customer_statement(self: Any, customer_id: int) -> list[dict[str, Any]]:
    return list_customer_transactions(self, customer_id)


@_domain
def customer_statement_detailed(self: Any, customer_id: int) -> list[dict[str, Any]]:
    return list_customer_transactions(self, customer_id)


@_domain
def get_customer_statement(self: Any, customer_id: int) -> dict[str, Any]:
    transactions = list_customer_transactions(self, customer_id)
    return {"customer_id": int(customer_id), "transactions": transactions, "balance": get_customer_balance(self, customer_id)}


@_domain
def list_customer_transactions(self: Any, customer_id: int, limit: int = 2000, offset: int = 0) -> list[dict[str, Any]]:
    cid = int(customer_id)
    rows: list[dict[str, Any]] = []
    if _table_exists(self, "sales"):
        total_expr = _sales_total_expr("")
        for sale in self.db.all(f"SELECT invoice_no ref, created_at, {total_expr} amount, payment_method note FROM sales WHERE customer_id=? ORDER BY created_at", (cid,)):
            d = _row_dict(sale) or {}
            amount = _D(d.get("amount")) if str(d.get("note") or "") == "آجل" else Decimal("0")
            rows.append({"kind": "بيع", "type": "فاتورة", "ref": d.get("ref"), "created_at": d.get("created_at"), "debit": _F(amount), "credit": 0.0, "amount": _F(amount), "note": d.get("note")})
    if _table_exists(self, "returns"):
        for ret in self.db.all("""
            SELECT r.return_no ref, r.created_at, r.amount
            FROM returns r LEFT JOIN sales s ON s.id=r.sale_id
            WHERE COALESCE(r.customer_id, s.customer_id)=? ORDER BY r.created_at
        """, (cid,)):
            d = _row_dict(ret) or {}
            credit = _D(d.get("amount"))
            rows.append({"kind": "مرتجع", "type": "مرتجع", "ref": d.get("ref"), "created_at": d.get("created_at"), "debit": 0.0, "credit": _F(credit), "amount": _F(-credit), "note": "مرتجع"})
    if _table_exists(self, "customer_payments"):
        for pay in self.db.all("SELECT COALESCE(receipt_no,id) ref, created_at, amount, note FROM customer_payments WHERE customer_id=? ORDER BY created_at", (cid,)):
            d = _row_dict(pay) or {}
            credit = _D(d.get("amount"))
            rows.append({"kind": "دفعة", "type": "دفعة", "ref": str(d.get("ref") or ""), "created_at": d.get("created_at"), "debit": 0.0, "credit": _F(credit), "amount": _F(-credit), "note": d.get("note") or "دفعة"})
    rows.sort(key=lambda item: str(item.get("created_at") or ""))
    balance = Decimal("0")
    output: list[dict[str, Any]] = []
    for row in rows:
        balance = max(balance + _D(row.get("debit")) - _D(row.get("credit")), Decimal("0"))
        item = dict(row)
        item["balance"] = _F(balance)
        output.append(item)
    start = _offset(offset)
    end = start + _limit(limit, 2000, 10000)
    return output[start:end]


@_domain
def get_customer_balance(self: Any, customer_id: int | None) -> float:
    if not customer_id:
        return 0.0
    cid = int(customer_id)
    total = Decimal("0")
    if _table_exists(self, "sales"):
        expr = _sales_total_expr("")
        row = self.db.one(f"SELECT COALESCE(SUM({expr}),0) total FROM sales WHERE customer_id=? AND payment_method='آجل' AND COALESCE(status,'completed')!='cancelled'", (cid,))
        total += _D((_row_dict(row) or {}).get("total"))
    if _table_exists(self, "customer_payments"):
        row = self.db.one("SELECT COALESCE(SUM(amount),0) total FROM customer_payments WHERE customer_id=?", (cid,))
        total -= _D((_row_dict(row) or {}).get("total"))
    if _table_exists(self, "returns"):
        row = self.db.one("""
            SELECT COALESCE(SUM(r.amount),0) total
            FROM returns r LEFT JOIN sales s ON s.id=r.sale_id
            WHERE COALESCE(r.customer_id, s.customer_id)=?
        """, (cid,))
        total -= _D((_row_dict(row) or {}).get("total"))
    return _F(max(total, Decimal("0")))


@_domain
def customer_balance(self: Any, customer_id: int | None) -> float:
    return get_customer_balance(self, customer_id)


@_domain
def customer_balance_for_pos(self: Any, customer_id: int | None) -> float:
    return get_customer_balance(self, customer_id)


@_domain
def debt_rows(self: Any) -> list[dict[str, Any]]:
    """Return customer rows with credit, returns, payments and balance columns."""
    if not _table_exists(self, "customers"):
        return []
    if not _table_exists(self, "sales"):
        rows = _rows(self.db.all("""
            SELECT c.id, c.name, c.phone, c.address, c.credit_limit, c.due_days,
                   0 credit_sales, 0 returns_amount,
                   COALESCE((SELECT SUM(amount) FROM customer_payments p WHERE p.customer_id=c.id),0) payments,
                   0 balance
              FROM customers c
             WHERE COALESCE(c.active,1)=1
             ORDER BY c.name
        """))
    else:
        rows = _rows(self.db.all("""
            WITH credit AS (
                SELECT customer_id,
                       SUM(CASE WHEN COALESCE(total, subtotal - discount_amount + tax_amount) < 0 THEN 0 ELSE COALESCE(total, subtotal - discount_amount + tax_amount) END) credit_sales
                  FROM sales
                 WHERE payment_method='آجل' AND COALESCE(status,'completed')!='cancelled'
                 GROUP BY customer_id
            ), returned AS (
                SELECT COALESCE(r.customer_id, s.customer_id) customer_id,
                       SUM(COALESCE(r.amount,0)) returns_amount
                  FROM returns r LEFT JOIN sales s ON s.id=r.sale_id
                 GROUP BY COALESCE(r.customer_id, s.customer_id)
            ), payments AS (
                SELECT customer_id, SUM(COALESCE(amount,0)) payments
                  FROM customer_payments
                 GROUP BY customer_id
            )
            SELECT c.id, c.name, c.phone, c.address, c.credit_limit, c.due_days,
                   COALESCE(credit.credit_sales,0) credit_sales,
                   COALESCE(returned.returns_amount,0) returns_amount,
                   COALESCE(payments.payments,0) payments,
                   MAX(COALESCE(credit.credit_sales,0) - COALESCE(returned.returns_amount,0) - COALESCE(payments.payments,0), 0) balance
              FROM customers c
              LEFT JOIN credit ON credit.customer_id=c.id
              LEFT JOIN returned ON returned.customer_id=c.id
              LEFT JOIN payments ON payments.customer_id=c.id
             WHERE COALESCE(c.active,1)=1
             ORDER BY balance DESC, c.name
        """))
    for row in rows:
        row["last_credit_sale"] = _last_credit_sale(self, int(row.get("id") or 0))
    return rows


@_domain
def list_debts(self: Any) -> list[dict[str, Any]]:
    return debt_rows(self)


def _last_credit_sale(self: Any, customer_id: int) -> str:
    if not _table_exists(self, "sales"):
        return ""
    row = self.db.one("SELECT MAX(created_at) created_at FROM sales WHERE customer_id=? AND payment_method='آجل'", (int(customer_id),))
    return str((_row_dict(row) or {}).get("created_at") or "")


@_domain
def customer_debt_summary(self: Any) -> dict[str, Any]:
    rows = debt_rows(self)
    total = sum((_D(row.get("balance")) for row in rows), Decimal("0"))
    return {"customers": len(rows), "total_balance": _F(total), "rows": rows[:10]}


@_domain
def get_overdue_amounts(self: Any, as_of: str = "") -> list[dict[str, Any]]:
    today = _normalize_date(as_of) or "now"
    rows = []
    for row in debt_rows(self):
        due = str(row.get("debt_due_date") or "")[:10]
        if due and (today == "now" or due <= today):
            rows.append(row)
    return rows


@_domain
def list_payments_received(self: Any, customer_id: int | None = None, limit: int = 200, offset: int = 0) -> list[dict[str, Any]]:
    return list_receipts(self, customer_id=customer_id, limit=limit, offset=offset)


@_domain
def list_cashier_shifts(self: Any, status: str = "", limit: int = 300, offset: int = 0) -> list[dict[str, Any]]:
    if not _table_exists(self, "cashier_shifts"):
        return []
    where = ["1=1"]
    params: list[Any] = []
    if status:
        where.append("cs.status=?")
        params.append(_clean(status, 50))
    user_join = "LEFT JOIN users u ON u.id=cs.user_id" if _table_exists(self, "users") else ""
    closed_col = "cs.closed_by_user_id" if _has_col(self, "cashier_shifts", "closed_by_user_id") else "NULL"
    sql = f"""
        SELECT cs.*, COALESCE(NULLIF(u.full_name,''), u.username, '-') username, {closed_col} closed_by_user_id
        FROM cashier_shifts cs {user_join}
        WHERE {' AND '.join(where)}
        ORDER BY cs.id DESC LIMIT ? OFFSET ?
    """
    params.extend([_limit(limit, 300, 5000), _offset(offset)])
    return _rows(self.db.all(sql, params))


@_domain
def list_cash_shifts(self: Any, *args: Any, **kwargs: Any) -> list[dict[str, Any]]:
    return list_cashier_shifts(self, *args, **kwargs)


def _shift_row(self: Any, shift_id: int | None = None, user_id: int | None = None) -> dict[str, Any] | None:
    if not _table_exists(self, "cashier_shifts"):
        return None
    if shift_id:
        return _row_dict(self.db.one("SELECT * FROM cashier_shifts WHERE id=?", (int(shift_id),)))
    if user_id:
        return _row_dict(self.db.one("SELECT * FROM cashier_shifts WHERE user_id=? AND status='open' ORDER BY id DESC LIMIT 1", (int(user_id),)))
    return _row_dict(self.db.one("SELECT * FROM cashier_shifts WHERE status='open' ORDER BY id DESC LIMIT 1"))


@_domain
def get_shift_summary(self: Any, shift_id: int | None = None, user_id: int | None = None) -> dict[str, Any]:
    shift = _shift_row(self, shift_id, user_id)
    if not shift:
        return {"open": False, "message": "لا يوجد شفت مفتوح", "opening_cash": 0.0, "cash_sales": 0.0, "credit_sales": 0.0, "customer_payments": 0.0, "returns_amount": 0.0, "expenses_amount": 0.0, "expected_cash": 0.0, "counted_cash": 0.0, "cash_difference": 0.0, "invoice_count": 0, "opened_at": ""}
    opened = str(shift.get("opened_at") or "")
    closed = str(shift.get("closed_at") or "") or "9999-12-31 23:59:59"
    uid = _I(shift.get("user_id"))
    cash_sales, cash_count = _sales_sum_between(self, opened, closed, uid, credit=False)
    credit_sales, credit_count = _sales_sum_between(self, opened, closed, uid, credit=True)
    payments = _payments_sum_between(self, opened, closed)
    returns = _returns_sum_between(self, opened, closed, uid)
    expenses = _expenses_sum_between(self, opened, closed, uid)
    opening = _D(shift.get("opening_cash"))
    expected = opening + _D(cash_sales) + _D(payments) - _D(returns) - _D(expenses)
    counted = _D(shift.get("counted_cash")) if shift.get("counted_cash") is not None else Decimal("0")
    return {
        "open": str(shift.get("status") or "") == "open",
        "shift_id": shift.get("id"),
        "user_id": uid,
        "username": shift.get("username", ""),
        "opened_at": opened,
        "closed_at": str(shift.get("closed_at") or ""),
        "status": shift.get("status", ""),
        "opening_cash": _F(opening),
        "cash_sales": _F(cash_sales),
        "credit_sales": _F(credit_sales),
        "customer_payments": _F(payments),
        "returns_amount": _F(returns),
        "expenses_amount": _F(expenses),
        "invoice_count": int(cash_count + credit_count),
        "expected_cash": _F(expected),
        "counted_cash": _F(counted),
        "cash_difference": _F(counted - expected) if shift.get("counted_cash") is not None else 0.0,
        "note": shift.get("note") or "",
    }


@_domain
def shift_financial_summary(self: Any, shift_id: int | None = None, user_id: int | None = None) -> dict[str, Any]:
    return get_shift_summary(self, shift_id, user_id)


@_domain
def get_shift_details(self: Any, shift_id: int) -> dict[str, Any]:
    return {"shift": _shift_row(self, shift_id), "summary": get_shift_summary(self, shift_id), "movements": list_cash_movements(self, shift_id=shift_id)}


def _sales_sum_between(self: Any, opened: str, closed: str, user_id: int | None, credit: bool) -> tuple[float, int]:
    if not _table_exists(self, "sales"):
        return 0.0, 0
    method_op = "=" if credit else "!="
    params: list[Any] = [opened, closed]
    user_filter = ""
    if user_id and _has_col(self, "sales", "user_id"):
        user_filter = " AND user_id=?"
        params.append(user_id)
    row = self.db.one(f"""
        SELECT COALESCE(SUM(total),0) total, COUNT(*) cnt FROM sales
        WHERE COALESCE(status,'completed')='completed' AND payment_method {method_op} 'آجل'
          AND created_at>=? AND created_at<=? {user_filter}
    """, params)
    d = _row_dict(row) or {}
    return _F(d.get("total")), int(d.get("cnt") or 0)


def _payments_sum_between(self: Any, opened: str, closed: str) -> float:
    if not _table_exists(self, "customer_payments"):
        return 0.0
    row = self.db.one("SELECT COALESCE(SUM(amount),0) total FROM customer_payments WHERE created_at>=? AND created_at<=?", (opened, closed))
    return _F((_row_dict(row) or {}).get("total"))


def _returns_sum_between(self: Any, opened: str, closed: str, user_id: int | None) -> float:
    if not _table_exists(self, "returns"):
        return 0.0
    params: list[Any] = [opened, closed]
    user_filter = ""
    if user_id and _has_col(self, "returns", "created_by_user_id"):
        user_filter = " AND created_by_user_id=?"
        params.append(user_id)
    row = self.db.one(f"SELECT COALESCE(SUM(amount),0) total FROM returns WHERE refund_method='نقدي' AND created_at>=? AND created_at<=? {user_filter}", params)
    return _F((_row_dict(row) or {}).get("total"))


def _expenses_sum_between(self: Any, opened: str, closed: str, user_id: int | None) -> float:
    if not _table_exists(self, "expenses"):
        return 0.0
    params: list[Any] = [opened, closed]
    user_filter = ""
    if user_id and _has_col(self, "expenses", "user_id"):
        user_filter = " AND user_id=?"
        params.append(user_id)
    row = self.db.one(f"SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE created_at>=? AND created_at<=? {user_filter}", params)
    return _F((_row_dict(row) or {}).get("total"))


@_domain
def list_cash_movements(self: Any, shift_id: int | None = None, limit: int = 300, offset: int = 0) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    shift = _shift_row(self, shift_id) if shift_id else None
    date_from = str(shift.get("opened_at") or "") if shift else ""
    date_to = str(shift.get("closed_at") or "9999-12-31 23:59:59") if shift else ""
    if _table_exists(self, "payments"):
        where = []
        params: list[Any] = []
        if date_from:
            where.append("COALESCE(payment_date,created_at)>=?"); params.append(date_from)
        if date_to:
            where.append("COALESCE(payment_date,created_at)<=?"); params.append(date_to)
        sql = "SELECT id, COALESCE(payment_date,created_at) created_at, payment_type type, amount, payment_method, description, note FROM payments"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?"
        params.extend([_limit(limit, 300, 5000), _offset(offset)])
        rows.extend(_rows(self.db.all(sql, params)))
    return rows


@_domain
def get_cash_balance(self: Any) -> float:
    total = Decimal("0")
    if _table_exists(self, "sales"):
        row = self.db.one("SELECT COALESCE(SUM(total),0) total FROM sales WHERE COALESCE(status,'completed')='completed' AND payment_method!='آجل'")
        total += _D((_row_dict(row) or {}).get("total"))
    if _table_exists(self, "customer_payments"):
        row = self.db.one("SELECT COALESCE(SUM(amount),0) total FROM customer_payments")
        total += _D((_row_dict(row) or {}).get("total"))
    if _table_exists(self, "returns"):
        row = self.db.one("SELECT COALESCE(SUM(amount),0) total FROM returns WHERE refund_method='نقدي'")
        total -= _D((_row_dict(row) or {}).get("total"))
    if _table_exists(self, "expenses"):
        row = self.db.one("SELECT COALESCE(SUM(amount),0) total FROM expenses")
        total -= _D((_row_dict(row) or {}).get("total"))
    return _F(total)


@_domain
def get_sales_totals_by_period(self: Any, date_from: str = "", date_to: str = "") -> dict[str, Any]:
    if not _table_exists(self, "sales"):
        return {"invoices": 0, "sales": 0.0, "profit": 0.0, "tax": 0.0, "discount": 0.0}
    clauses, params = _date_clauses("created_at", date_from, date_to)
    where = "WHERE " + " AND ".join(clauses) if clauses else ""
    row = self.db.one(f"""
        SELECT COUNT(*) invoices, COALESCE(SUM(total),0) sales,
               COALESCE(SUM(total_profit),0) profit, COALESCE(SUM(tax_amount),0) tax,
               COALESCE(SUM(discount_amount),0) discount
        FROM sales {where}
    """, params)
    d = _row_dict(row) or {}
    return {"invoices": int(d.get("invoices") or 0), "sales": _F(d.get("sales")), "profit": _F(d.get("profit")), "tax": _F(d.get("tax")), "discount": _F(d.get("discount"))}


@_domain
def get_profit_details(self: Any, date_from: str = "", date_to: str = "", limit: int = 500, offset: int = 0) -> list[dict[str, Any]]:
    if not _table_exists(self, "sales"):
        return []
    clauses, params = _date_clauses("s.created_at", date_from, date_to)
    sql = _sale_select_sql(self)
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY s.created_at DESC, s.id DESC LIMIT ? OFFSET ?"
    params.extend([_limit(limit, 500, 5000), _offset(offset)])
    rows = list(_rows(self.db.all(sql, params)))
    for row in rows:
        row["gross_profit"] = _F(row.get("total_profit"))
        row["profit_margin_percent"] = _F((_D(row.get("total_profit")) / _D(row.get("total")) * Decimal("100")) if _D(row.get("total")) else 0)
    return rows


@_domain
def get_tax_totals(self: Any, date_from: str = "", date_to: str = "") -> dict[str, float]:
    totals = get_sales_totals_by_period(self, date_from, date_to)
    return {"tax_amount": _F(totals.get("tax")), "sales": _F(totals.get("sales")), "invoices": float(totals.get("invoices") or 0)}


@_domain
def normalize_finance_output_dates(self: Any, data: Any, output_format: str = '%Y-%m-%d') -> Any:
    """Normalize financial output date fields without changing amounts or keys."""
    try:
        from services.domain.operations_core import normalize_record_dates, normalize_records_dates

        if isinstance(data, list):
            return normalize_records_dates(self, data, output_format=output_format)
        if isinstance(data, dict):
            normalized = normalize_record_dates(self, data, output_format=output_format)
            for key, value in list(normalized.items()):
                if isinstance(value, list):
                    normalized[key] = normalize_records_dates(self, value, output_format=output_format)
                elif isinstance(value, dict):
                    normalized[key] = normalize_record_dates(self, value, output_format=output_format)
            return normalized
    except Exception:
        pass
    return data


# ---------------------------------------------------------------------------
# PURE CALCULATIONS - Stage 8
# READ-ONLY / PURE LOGIC - NO DB READ OR WRITE.
# These helpers accept plain values and return plain dictionaries/numbers. They
# intentionally do not access self.db, transactions, cursors, or any external IO.
# ---------------------------------------------------------------------------

MONEY_QUANT: Final[Decimal] = Decimal("0.01")


def _money(value: Any) -> Decimal:
    return _D(value).quantize(MONEY_QUANT, rounding=ROUND_HALF_UP)


def _percent(value: Any) -> Decimal:
    return _D(value) / Decimal("100")


def _money_float(value: Any) -> float:
    return float(_money(value))


def _reject_db_like(*values: Any) -> None:
    """Keep pure calculation inputs free from DB connection/cursor objects."""
    for value in values:
        if value is None:
            continue
        type_name = type(value).__name__.lower()
        module_name = getattr(type(value), "__module__", "").lower()
        if any(token in type_name for token in ("connection", "cursor", "database")):
            raise TypeError("Pure sales_finance calculations must not receive DB objects")
        if "sqlite" in module_name and any(token in type_name for token in ("connection", "cursor")):
            raise TypeError("Pure sales_finance calculations must not receive DB objects")


def _item_get(item: Any, *keys: str, default: Any = 0) -> Any:
    if isinstance(item, dict):
        for key in keys:
            if key in item:
                return item.get(key)
    else:
        for key in keys:
            if hasattr(item, key):
                return getattr(item, key)
    return default


def _as_list(items: Any) -> list[Any]:
    _reject_db_like(items)
    if items is None:
        return []
    if isinstance(items, list):
        return items
    if isinstance(items, tuple):
        return list(items)
    return list(items)


def _rounding_delta(value: Decimal, rounding_to: Any = "0.01") -> Decimal:
    step = _D(rounding_to)
    if step <= 0:
        step = MONEY_QUANT
    rounded_units = (value / step).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    rounded = (rounded_units * step).quantize(MONEY_QUANT, rounding=ROUND_HALF_UP)
    return _money(rounded - value)


@_domain
def calculate_tax_amount(
    self: Any,
    amount: Any,
    tax_percent: Any = 0,
    tax_included: bool = False,
) -> float:
    """READ-ONLY / PURE LOGIC - NO DB WRITE.

    Return the tax value for a net amount. When tax_included is True, amount is
    treated as gross and the embedded tax portion is extracted.
    """
    _reject_db_like(amount, tax_percent)
    base = _money(amount)
    rate = _percent(tax_percent)
    if base <= 0 or rate <= 0:
        return 0.0
    if tax_included:
        return _money_float(base - (base / (Decimal("1") + rate)))
    return _money_float(base * rate)


@_domain
def calculate_discount(
    self: Any,
    amount: Any,
    discount_value: Any = 0,
    discount_type: str = "percent",
) -> float:
    """READ-ONLY / PURE LOGIC - NO DB WRITE. Calculate a capped discount."""
    _reject_db_like(amount, discount_value)
    base = _money(amount)
    if base <= 0:
        return 0.0
    dtype = str(discount_type or "percent").strip().lower()
    value = _D(discount_value)
    if value <= 0:
        return 0.0
    if dtype in {"percent", "%", "percentage", "نسبة"}:
        discount = base * (value / Decimal("100"))
    else:
        discount = value
    if discount > base:
        discount = base
    return _money_float(discount)


@_domain
def calculate_item_total(
    self: Any,
    quantity: Any,
    price: Any,
    tax_percent: Any = 0,
    discount: Any = 0,
    discount_type: str = "amount",
    tax_included: bool = False,
) -> dict[str, float]:
    """READ-ONLY / PURE LOGIC - NO DB WRITE. Calculate one invoice line."""
    _reject_db_like(quantity, price, tax_percent, discount)
    qty = _D(quantity)
    unit_price = _money(price)
    if qty < 0:
        qty = Decimal("0")
    gross = _money(qty * unit_price)
    discount_amount = _D(calculate_discount(self, gross, discount, discount_type))
    taxable_base = _money(gross - discount_amount)
    tax_amount = _D(calculate_tax_amount(self, taxable_base, tax_percent, tax_included=tax_included))
    net_total = taxable_base if tax_included else _money(taxable_base + tax_amount)
    return {
        "quantity": float(qty),
        "unit_price": _money_float(unit_price),
        "gross_total": _money_float(gross),
        "discount_amount": _money_float(discount_amount),
        "tax_amount": _money_float(tax_amount),
        "net_total": _money_float(net_total),
    }


@_domain
def calculate_invoice_totals(
    self: Any,
    items: Sequence[dict[str, Any]] | None = None,
    global_discount: Any = 0,
    global_discount_type: str = "percent",
    additional_tax: Any = 0,
    shipping: Any = 0,
    rounding_to: Any = "0.01",
) -> dict[str, Any]:
    """READ-ONLY / PURE LOGIC - NO DB WRITE.

    Preview invoice totals using Decimal-based arithmetic. Each item may expose
    quantity/qty, price/unit_price/selling_price, tax_percent/tax_rate, discount,
    discount_type, and tax_included.
    """
    rows = _as_list(items or [])
    line_results: list[dict[str, Any]] = []
    sub_total = Decimal("0")
    item_discount = Decimal("0")
    item_tax = Decimal("0")

    for index, item in enumerate(rows, start=1):
        qty = _item_get(item, "quantity", "qty", default=0)
        price = _item_get(item, "price", "unit_price", "selling_price", "sale_price", default=0)
        tax_percent = _item_get(item, "tax_percent", "tax_rate", "vat_percent", default=0)
        discount = _item_get(item, "discount", "discount_amount", "line_discount", default=0)
        discount_type = str(_item_get(item, "discount_type", default="amount") or "amount")
        tax_included = bool(_item_get(item, "tax_included", "price_includes_tax", default=False))
        calculated = calculate_item_total(
            self,
            qty,
            price,
            tax_percent=tax_percent,
            discount=discount,
            discount_type=discount_type,
            tax_included=tax_included,
        )
        calculated["line_no"] = index
        product_id = _item_get(item, "product_id", "id", default=None)
        if product_id is not None:
            calculated["product_id"] = product_id
        name = _item_get(item, "name", "product_name", default="")
        if name:
            calculated["name"] = _clean(name, 180)
        line_results.append(calculated)
        sub_total += _D(calculated["gross_total"])
        item_discount += _D(calculated["discount_amount"])
        item_tax += _D(calculated["tax_amount"])

    after_item_discount = _money(sub_total - item_discount)
    global_discount_amount = _D(calculate_discount(self, after_item_discount, global_discount, global_discount_type))
    additional_tax_amount = _D(calculate_tax_amount(self, after_item_discount - global_discount_amount, additional_tax, False))
    shipping_amount = _money(shipping)
    total_discount = _money(item_discount + global_discount_amount)
    total_tax = _money(item_tax + additional_tax_amount)
    before_rounding = _money(sub_total - total_discount + total_tax + shipping_amount)
    rounding_amount = _rounding_delta(before_rounding, rounding_to)
    net_total = _money(before_rounding + rounding_amount)

    return {
        "items": line_results,
        "sub_total": _money_float(sub_total),
        "subtotal": _money_float(sub_total),
        "item_discount": _money_float(item_discount),
        "global_discount": _money_float(global_discount_amount),
        "total_discount": _money_float(total_discount),
        "item_tax": _money_float(item_tax),
        "additional_tax": _money_float(additional_tax_amount),
        "total_tax": _money_float(total_tax),
        "shipping": _money_float(shipping_amount),
        "rounding_amount": _money_float(rounding_amount),
        "net_total": _money_float(net_total),
        "total": _money_float(net_total),
        "grand_total": _money_float(net_total),
    }


@_domain
def calculate_invoice_totals_decimal(
    self: Any,
    items: Sequence[dict[str, Any]] | None = None,
    **kwargs: Any,
) -> dict[str, Decimal | list[dict[str, Any]]]:
    """READ-ONLY / PURE LOGIC - NO DB WRITE. Decimal-preserving totals."""
    totals = calculate_invoice_totals(self, items, **kwargs)
    converted: dict[str, Any] = {}
    for key, value in totals.items():
        if key == "items":
            converted[key] = value
        elif isinstance(value, (int, float, str, Decimal)):
            converted[key] = _money(value)
        else:
            converted[key] = value
    return converted


@_domain
def calculate_profit(self: Any, selling_price: Any, cost_price: Any, quantity: Any = 1) -> dict[str, float]:
    """READ-ONLY / PURE LOGIC - NO DB WRITE. Calculate profit for one item."""
    _reject_db_like(selling_price, cost_price, quantity)
    qty = _D(quantity)
    sell_total = _money(_D(selling_price) * qty)
    cost_total = _money(_D(cost_price) * qty)
    profit = _money(sell_total - cost_total)
    margin = Decimal("0") if sell_total == 0 else _money((profit / sell_total) * Decimal("100"))
    return {
        "selling_total": _money_float(sell_total),
        "cost_total": _money_float(cost_total),
        "profit": _money_float(profit),
        "margin_percent": _money_float(margin),
    }


@_domain
def calculate_invoice_profit(
    self: Any,
    items_with_cost: Sequence[dict[str, Any]] | None = None,
    can_view_cost: bool = True,
) -> dict[str, Any]:
    """READ-ONLY / PURE LOGIC - NO DB WRITE. Calculate invoice profit summary."""
    rows = _as_list(items_with_cost or [])
    total_selling = Decimal("0")
    total_cost = Decimal("0")
    details: list[dict[str, Any]] = []
    for item in rows:
        qty = _item_get(item, "quantity", "qty", default=1)
        selling = _item_get(item, "selling_price", "price", "unit_price", default=0)
        cost = _item_get(item, "cost_price", "cost", "purchase_price", default=0)
        profit = calculate_profit(self, selling, cost, qty)
        total_selling += _D(profit["selling_total"])
        total_cost += _D(profit["cost_total"])
        if can_view_cost:
            details.append({**profit, "product_id": _item_get(item, "product_id", "id", default=None)})
    gross_profit = _money(total_selling - total_cost)
    margin = Decimal("0") if total_selling == 0 else _money((gross_profit / total_selling) * Decimal("100"))
    result: dict[str, Any] = {
        "selling_total": _money_float(total_selling),
        "gross_profit": _money_float(gross_profit),
        "profit": _money_float(gross_profit),
        "margin_percent": _money_float(margin),
    }
    if can_view_cost:
        result["cost_total"] = _money_float(total_cost)
        result["items"] = details
    return result


@_domain
def calculate_remaining_amount(self: Any, total_amount: Any, paid_amount: Any = 0) -> dict[str, float | str]:
    """READ-ONLY / PURE LOGIC - NO DB WRITE. Compute remaining/credit state."""
    _reject_db_like(total_amount, paid_amount)
    total = _money(total_amount)
    paid = _money(paid_amount)
    remaining = _money(total - paid)
    status = "paid" if remaining == 0 else ("debt" if remaining > 0 else "credit")
    return {
        "total_amount": _money_float(total),
        "paid_amount": _money_float(paid),
        "remaining_amount": _money_float(remaining),
        "status": status,
    }


@_domain
def calculate_credit_impact(
    self: Any,
    current_balance: Any,
    invoice_total: Any = 0,
    payment_amount: Any = 0,
) -> dict[str, float]:
    """READ-ONLY / PURE LOGIC - NO DB WRITE. Preview customer balance impact."""
    _reject_db_like(current_balance, invoice_total, payment_amount)
    before = _money(current_balance)
    invoice = _money(invoice_total)
    payment = _money(payment_amount)
    after = _money(before + invoice - payment)
    return {
        "balance_before": _money_float(before),
        "invoice_total": _money_float(invoice),
        "payment_amount": _money_float(payment),
        "balance_after": _money_float(after),
        "impact": _money_float(after - before),
    }


@_domain
def calculate_return_values(
    self: Any,
    original_item_price: Any,
    return_quantity: Any,
    original_tax: Any = 0,
    original_discount: Any = 0,
    discount_type: str = "amount",
    tax_included: bool = False,
) -> dict[str, float]:
    """READ-ONLY / PURE LOGIC - NO DB WRITE. Preview a return without saving it."""
    return calculate_item_total(
        self,
        return_quantity,
        original_item_price,
        tax_percent=original_tax,
        discount=original_discount,
        discount_type=discount_type,
        tax_included=tax_included,
    )


@_domain
def prepare_invoice_payload(
    self: Any,
    calculated_totals: dict[str, Any],
    items_data: Sequence[dict[str, Any]] | None = None,
    customer_data: dict[str, Any] | None = None,
    user_id: int | None = None,
) -> dict[str, Any]:
    """READ-ONLY / PURE LOGIC - NO DB WRITE. Normalize data before old saver."""
    _reject_db_like(calculated_totals, items_data, customer_data)
    totals = dict(calculated_totals or {})
    customer = dict(customer_data or {})
    return {
        "customer_id": customer.get("id") or customer.get("customer_id"),
        "customer_name": _clean(customer.get("name") or customer.get("customer_name") or "زبون عام", 180),
        "user_id": user_id,
        "items": list(items_data or totals.get("items") or []),
        "sub_total": _money_float(totals.get("sub_total", totals.get("subtotal", 0))),
        "discount_amount": _money_float(totals.get("total_discount", 0)),
        "tax_amount": _money_float(totals.get("total_tax", 0)),
        "shipping": _money_float(totals.get("shipping", 0)),
        "rounding_amount": _money_float(totals.get("rounding_amount", 0)),
        "total": _money_float(totals.get("net_total", totals.get("total", 0))),
        "grand_total": _money_float(totals.get("grand_total", totals.get("net_total", totals.get("total", 0)))),
        "status": "preview",
    }


@_domain
def sale_preview_payload(
    self: Any,
    items: Sequence[dict[str, Any]] | None = None,
    customer_data: dict[str, Any] | None = None,
    user_id: int | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """READ-ONLY / PURE LOGIC - NO DB WRITE. Full sale preview for Qt/PHP."""
    paid_amount = kwargs.pop("paid_amount", 0)
    totals = calculate_invoice_totals(self, items or [], **kwargs)
    remaining = calculate_remaining_amount(self, totals["net_total"], paid_amount)
    payload = prepare_invoice_payload(self, totals, items, customer_data, user_id)
    payload["payment_preview"] = remaining
    return payload
