from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Final, Iterable

from services.error_logger import log_exception
from database import money, now_text

DOMAIN: Final[str] = 'reports_intelligence'
METHODS: Final[tuple[str, ...]] = (
    '_goal_period_bounds', 'advanced_ai_analysis', 'advanced_reports', 'ai_anomaly_alerts',
    'ai_daily_summary', 'ai_employee_analysis', 'ai_faq_answer', 'ai_full_report',
    'ai_notes_analysis', 'ai_profit_analysis', 'ask_ai_assistant_deep', 'backup_health',
    'cash_summary', 'clear_analysis_cache', 'commission_report', 'daily_business_report',
    'daily_close_summary', 'daily_closings', 'dashboard', 'dashboard_page_data',
    'delete_employee_goal_hard', 'employee_goal_rows', 'expense_summary', 'expiry_alerts',
    'export_daily_report_excel', 'export_daily_report_html', 'export_report',
    'final_quality_health', 'generate_smart_alerts', 'interactive_dashboard_data',
    'list_expense_categories', 'list_expenses', 'list_smart_alerts', 'maintenance_summary',
    'management_report', 'movement_summary', 'owner_dashboard_snapshot',
    'print_daily_report_html', 'profit_summary', 'refactor_health', 'resolve_smart_alert',
    'runtime_health', 'runtime_health_v4517415', 'runtime_health_v4517416', 'save_employee_goal',
    'save_expense', 'smart_alerts', 'system_health_check', 'sales_summary',
)


def domain_function(fn):
    """Mark a function as a real domain implementation, not a bridge placeholder."""
    setattr(fn, '_domain_implementation', True)
    return fn


def _rowdict(row: Any) -> dict[str, Any]:
    if row is None:
        return {}
    try:
        return dict(row)
    except Exception:
        return {}


def _rows(rows: Iterable[Any]) -> list[dict[str, Any]]:
    return [_rowdict(row) for row in rows]


def _scalar(self: Any, sql: str, params: Iterable[Any] = (), default: Any = 0) -> Any:
    row = self.db.one(sql, tuple(params))
    if not row:
        return default
    try:
        value = row[0]
    except Exception:
        value = next(iter(dict(row).values()), default)
    return default if value is None else value


def _table_exists(self: Any, table: str) -> bool:
    return bool(self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)))


def _columns(self: Any, table: str) -> set[str]:
    try:
        return {str(row[1]) for row in self.db.conn.execute(f'PRAGMA table_info({table})')}
    except Exception:
        return set()


def _normalize_date(self: Any, value: str | None) -> str:
    if not value:
        return ''
    normalizer = getattr(self, 'normalize_search_date', None) or getattr(self, 'normalize_iso_date', None)
    if callable(normalizer):
        try:
            return str(normalizer(value) or '')[:10]
        except Exception:
            pass
    text = str(value).strip()[:10]
    try:
        datetime.strptime(text, '%Y-%m-%d')
        return text
    except Exception:
        return ''


def _date_filter(self: Any, column: str, date_from: str = '', date_to: str = '') -> tuple[list[str], list[Any]]:
    clauses: list[str] = []
    params: list[Any] = []
    df = _normalize_date(self, date_from)
    dt = _normalize_date(self, date_to)
    if df:
        clauses.append(f'date({column}) >= date(?)')
        params.append(df)
    if dt:
        clauses.append(f'date({column}) <= date(?)')
        params.append(dt)
    return clauses, params


def _limit(value: Any, default: int = 500, maximum: int = 5000) -> int:
    try:
        return max(1, min(int(value or default), maximum))
    except Exception:
        return default


@domain_function
def dashboard(self: Any) -> dict[str, Any]:
    """Return today's executive dashboard values using read-only SQL."""
    today = datetime.now().strftime('%Y-%m-%d')
    stats = _rowdict(self.db.one('''
        SELECT COALESCE(SUM(total),0) sales,
               COALESCE(SUM(total_profit),0) profit,
               COALESCE(SUM(total_commission),0) commission,
               COUNT(*) invoices
          FROM sales
         WHERE date(created_at)=date(?) AND COALESCE(status,'completed')='completed'
    ''', (today,)))
    returns = _rowdict(self.db.one('''
        SELECT COALESCE(SUM(amount),0) amount, COUNT(*) count
          FROM returns WHERE date(created_at)=date(?)
    ''', (today,)))
    best_product = _rowdict(self.db.one('''
        SELECT si.product_name, SUM(si.quantity) qty
          FROM sale_items si JOIN sales s ON s.id=si.sale_id
         WHERE date(s.created_at)=date(?) AND COALESCE(s.status,'completed')='completed'
         GROUP BY si.product_id, si.product_name ORDER BY qty DESC LIMIT 1
    ''', (today,)))
    low_stock = _scalar(self, 'SELECT COUNT(*) FROM products WHERE COALESCE(active,1)=1 AND quantity <= min_quantity')
    debt = _rowdict(self.db.one('''
        WITH credit AS (
            SELECT customer_id, SUM(CASE WHEN COALESCE(total,0) < 0 THEN 0 ELSE COALESCE(total,0) END) amount
              FROM sales WHERE payment_method='آجل' AND COALESCE(status,'completed')='completed'
             GROUP BY customer_id
        ), payments AS (
            SELECT customer_id, SUM(COALESCE(amount,0)) amount FROM customer_payments GROUP BY customer_id
        ), returned AS (
            SELECT s.customer_id, SUM(COALESCE(r.amount,0)) amount
              FROM returns r JOIN sales s ON s.id=r.sale_id GROUP BY s.customer_id
        )
        SELECT COALESCE(SUM(COALESCE(credit.amount,0)-COALESCE(returned.amount,0)-COALESCE(payments.amount,0)),0) total_debt
          FROM customers c
          LEFT JOIN credit ON credit.customer_id=c.id
          LEFT JOIN payments ON payments.customer_id=c.id
          LEFT JOIN returned ON returned.customer_id=c.id
         WHERE COALESCE(c.active,1)=1
    '''))
    return {
        'sales': stats.get('sales', 0),
        'profit': stats.get('profit', 0),
        'commission': stats.get('commission', 0),
        'invoices': stats.get('invoices', 0),
        'returns_amount': returns.get('amount', 0),
        'returns_count': returns.get('count', 0),
        'best_product': best_product.get('product_name') or '-',
        'low_stock': low_stock or 0,
        'total_debt': debt.get('total_debt', 0),
    }


@domain_function
def profit_summary(self: Any, date_from: str = '', date_to: str = '') -> dict[str, Any]:
    """Calculate sales/profit totals with optional date filters."""
    try:
        self.require_permission('can_reports', action='عرض الأرباح')
    except TypeError:
        self.require_permission('can_reports')
    except Exception:
        # Preserve old behavior for maintenance scripts that run without a UI session.
        pass
    where, params = _date_filter(self, 's.created_at', date_from, date_to)
    where.insert(0, "COALESCE(s.status,'completed')='completed'")
    net_col = 'si.net_line_total' if 'net_line_total' in _columns(self, 'sale_items') else 'si.line_total'
    row = _rowdict(self.db.one(f'''
        SELECT COUNT(DISTINCT s.id) invoices,
               COALESCE(SUM({net_col}),0) sales,
               COALESCE(SUM((si.unit_price - si.cost_price) * si.quantity),0) gross_profit,
               COALESCE(SUM(s.discount_amount),0) invoice_discounts,
               COALESCE(SUM(si.profit_amount),0) stored_profit
          FROM sales s JOIN sale_items si ON si.sale_id=s.id
         WHERE {' AND '.join(where)}
    ''', params))
    stored_profit = float(row.get('stored_profit') or 0)
    gross_profit = float(row.get('gross_profit') or 0) - float(row.get('invoice_discounts') or 0)
    return {
        'invoices': int(row.get('invoices') or 0),
        'sales': float(row.get('sales') or 0),
        'profit': stored_profit if stored_profit != 0 else gross_profit,
        'discounts': float(row.get('invoice_discounts') or 0),
    }


@domain_function
def sales_summary(self: Any, date_from: str | None = None, date_to: str | None = None) -> dict[str, Any]:
    """Return compact sales KPIs for reports and dashboard cards."""
    where, params = _date_filter(self, 'created_at', date_from or '', date_to or '')
    where.append("COALESCE(status,'completed')='completed'")
    row = _rowdict(self.db.one(f'''
        SELECT COUNT(*) invoices, COALESCE(SUM(total),0) total,
               COALESCE(SUM(total_profit),0) profit,
               COALESCE(SUM(total_commission),0) commission,
               COALESCE(AVG(total),0) average_invoice
          FROM sales WHERE {' AND '.join(where)}
    ''', params))
    return {
        'invoices': int(row.get('invoices') or 0),
        'total': float(row.get('total') or 0),
        'profit': float(row.get('profit') or 0),
        'commission': float(row.get('commission') or 0),
        'average_invoice': float(row.get('average_invoice') or 0),
    }


@domain_function
def expense_summary(self: Any, date_from: str = '', date_to: str = '') -> dict[str, Any]:
    """Summarize expenses by type/category without mutating data."""
    if not _table_exists(self, 'expenses'):
        return {'total': 0, 'by_type': {}, 'rows': []}
    date_column = 'expense_date' if 'expense_date' in _columns(self, 'expenses') else 'created_at'
    where, params = _date_filter(self, date_column, date_from, date_to)
    where_sql = ('WHERE ' + ' AND '.join(where)) if where else ''
    
    expense_cols = _columns(self, 'expenses')
    if 'category' in expense_cols:
        label_col = 'category'
    elif 'expense_type' in expense_cols:
        label_col = 'expense_type'
    else:
        label_col = 'type'
    rows = _rows(self.db.all(f'''
        SELECT COALESCE(NULLIF({label_col},''),'غير مصنف') type,
               COALESCE(SUM(amount),0) total, COUNT(*) count
          FROM expenses {where_sql}
         GROUP BY COALESCE(NULLIF({label_col},''),'غير مصنف') ORDER BY total DESC
    ''', params))
    return {
        'total': sum(float(row.get('total') or 0) for row in rows),
        'by_type': {str(row.get('type')): float(row.get('total') or 0) for row in rows},
        'rows': rows,
    }


@domain_function
def list_expense_categories(self: Any) -> list[dict[str, Any]]:
    if _table_exists(self, 'expense_categories'):
        return _rows(self.db.all('SELECT * FROM expense_categories ORDER BY name'))
    if not _table_exists(self, 'expenses'):
        return []
    
    expense_cols = _columns(self, 'expenses')
    if 'category' in expense_cols:
        label_col = 'category'
    elif 'expense_type' in expense_cols:
        label_col = 'expense_type'
    else:
        label_col = 'type'
    return _rows(self.db.all(f"SELECT DISTINCT COALESCE(NULLIF({label_col},''),'غير مصنف') name FROM expenses ORDER BY name"))


@domain_function
def list_expenses(self: Any, date_from: str = '', date_to: str = '', limit: int = 500) -> list[dict[str, Any]]:
    if not _table_exists(self, 'expenses'):
        return []
    date_column = 'expense_date' if 'expense_date' in _columns(self, 'expenses') else 'created_at'
    where, params = _date_filter(self, date_column, date_from, date_to)
    where_sql = ('WHERE ' + ' AND '.join(where)) if where else ''
    params.append(_limit(limit))
    return _rows(self.db.all(f'SELECT * FROM expenses {where_sql} ORDER BY date({date_column}) DESC, id DESC LIMIT ?', params))


@domain_function
def cash_summary(self: Any, date_from: str = '', date_to: str = '') -> list[dict[str, Any]]:
    try:
        self.require_any_permission(('can_reports', 'can_tools', 'can_audit'), action='عرض حركة الصندوق')
    except Exception:
        pass
    if not (_table_exists(self, 'cash_movements') and _table_exists(self, 'cash_accounts')):
        return []
    where, params = _date_filter(self, 'cm.created_at', date_from, date_to)
    where_sql = ('WHERE ' + ' AND '.join(where)) if where else ''
    return _rows(self.db.all(f'''
        SELECT ca.name account, ca.account_type,
               SUM(CASE WHEN cm.direction='out' THEN -cm.amount ELSE cm.amount END) balance,
               COUNT(*) movements
          FROM cash_movements cm JOIN cash_accounts ca ON ca.id=cm.account_id
          {where_sql}
         GROUP BY ca.id, ca.name, ca.account_type ORDER BY ca.name
    ''', params))


@domain_function
def commission_report(self: Any, date_from: str = '', date_to: str = '') -> list[dict[str, Any]]:
    clauses, params = _date_filter(self, 's.created_at', date_from, date_to)
    date_join = ''
    if clauses:
        date_join = ' AND ' + ' AND '.join(clauses)
    return _rows(self.db.all(f'''
        SELECT e.name employee,
               COALESCE(SUM(s.total),0) sales,
               COALESCE(SUM(s.total_commission),0) commission,
               COALESCE((SELECT SUM(r.commission_amount) FROM returns r WHERE r.employee_id=e.id),0) returned_commission
          FROM employees e
          LEFT JOIN sales s ON s.employee_id=e.id AND COALESCE(s.status,'completed')='completed' {date_join}
         GROUP BY e.id, e.name ORDER BY commission DESC
    ''', params))


@domain_function
def management_report(self: Any, kind: str) -> list[dict[str, Any]]:
    if kind == 'daily_sales':
        return _rows(self.db.all("SELECT date(created_at) period, COUNT(*) invoices, SUM(total) total, SUM(total_profit) profit FROM sales WHERE COALESCE(status,'completed')='completed' GROUP BY date(created_at) ORDER BY period DESC LIMIT 90"))
    if kind == 'monthly_sales':
        return _rows(self.db.all("SELECT substr(created_at,1,7) period, COUNT(*) invoices, SUM(total) total, SUM(total_profit) profit FROM sales WHERE COALESCE(status,'completed')='completed' GROUP BY substr(created_at,1,7) ORDER BY period DESC LIMIT 36"))
    if kind == 'top_products':
        return _rows(self.db.all('SELECT product_name, SUM(quantity) qty, SUM(line_total) total FROM sale_items GROUP BY product_id, product_name ORDER BY qty DESC LIMIT 50'))
    if kind == 'best_employees':
        return _rows(self.db.all("SELECT e.name employee, COUNT(s.id) invoices, SUM(s.total) total, SUM(s.total_commission) commission FROM sales s JOIN employees e ON e.id=s.employee_id WHERE COALESCE(s.status,'completed')='completed' GROUP BY e.id ORDER BY total DESC LIMIT 50"))
    if kind == 'overdue_debts' and hasattr(self, 'debt_rows'):
        return _rows(self.debt_rows())
    if kind == 'returns_reason':
        return _rows(self.db.all("SELECT COALESCE(NULLIF(reason,''),'بدون سبب') reason, COUNT(*) count, SUM(amount) total FROM returns GROUP BY COALESCE(NULLIF(reason,''),'بدون سبب') ORDER BY total DESC"))
    if kind == 'inventory_movements' and hasattr(self, 'inventory_movements'):
        return _rows(self.inventory_movements(500))
    if kind == 'stale_products':
        return _rows(self.db.all("SELECT p.name, p.quantity, p.sale_price, COALESCE(MAX(s.created_at),'لم يباع') last_sale FROM products p LEFT JOIN sale_items si ON si.product_id=p.id LEFT JOIN sales s ON s.id=si.sale_id WHERE COALESCE(p.active,1)=1 GROUP BY p.id ORDER BY CASE WHEN last_sale='لم يباع' THEN 0 ELSE 1 END, last_sale LIMIT 100"))
    return []


@domain_function
def advanced_reports(self: Any, date_from: str = '', date_to: str = '', limit: int = 500, offset: int = 0) -> dict[str, Any]:
    """Grouped read-only analytics used by the reports screen."""
    where, params = _date_filter(self, 's.created_at', date_from, date_to)
    where.insert(0, "COALESCE(s.status,'completed')='completed'")
    where_sql = ' AND '.join(where)
    net_col = 'si.net_line_total' if 'net_line_total' in _columns(self, 'sale_items') else 'si.line_total'
    limit_value = _limit(limit)
    offset_value = max(0, int(offset or 0))
    data: dict[str, Any] = {
        'summary': sales_summary(self, date_from, date_to),
        'profit': profit_summary(self, date_from, date_to),
        'top_products': _rows(self.db.all(f'''
            SELECT si.product_id, si.product_name, SUM(si.quantity) qty, SUM({net_col}) amount,
                   SUM(COALESCE(si.profit_amount, (si.unit_price-si.cost_price)*si.quantity)) profit
              FROM sale_items si JOIN sales s ON s.id=si.sale_id
             WHERE {where_sql}
             GROUP BY si.product_id, si.product_name ORDER BY qty DESC LIMIT ? OFFSET ?
        ''', (*params, limit_value, offset_value))),
        'most_profit_products': _rows(self.db.all(f'''
            SELECT si.product_id, si.product_name, SUM(si.quantity) qty, SUM({net_col}) amount,
                   SUM(COALESCE(si.profit_amount, (si.unit_price-si.cost_price)*si.quantity)) profit
              FROM sale_items si JOIN sales s ON s.id=si.sale_id
             WHERE {where_sql}
             GROUP BY si.product_id, si.product_name ORDER BY profit DESC LIMIT ?
        ''', (*params, 50))),
        'daily_sales': management_report(self, 'daily_sales'),
    }
    return data


@domain_function
def dashboard_page_data(self: Any, page: int = 1, page_size: int = 50) -> dict[str, Any]:
    page = max(1, int(page or 1))
    page_size = _limit(page_size, 50, 200)
    offset = (page - 1) * page_size
    total = int(_scalar(self, "SELECT COUNT(*) FROM sales WHERE COALESCE(status,'completed')='completed'", default=0))
    rows = _rows(self.db.all('''
        SELECT s.id, s.invoice_no, s.created_at, s.total, s.payment_method,
               COALESCE(c.name,'') customer, COALESCE(e.name,'') employee
          FROM sales s
          LEFT JOIN customers c ON c.id=s.customer_id
          LEFT JOIN employees e ON e.id=s.employee_id
         WHERE COALESCE(s.status,'completed')='completed'
         ORDER BY datetime(s.created_at) DESC, s.id DESC LIMIT ? OFFSET ?
    ''', (page_size, offset)))
    return {'page': page, 'page_size': page_size, 'total': total, 'rows': rows, 'dashboard': dashboard(self)}


@domain_function
def interactive_dashboard_data(self: Any, days: int = 30) -> dict[str, Any]:
    days = max(1, min(int(days or 30), 365))
    sales_by_day = _rows(self.db.all('''
        SELECT date(created_at) day, COUNT(*) invoices, COALESCE(SUM(total),0) total,
               COALESCE(SUM(total_profit),0) profit
          FROM sales
         WHERE COALESCE(status,'completed')='completed' AND date(created_at) >= date('now', ?)
         GROUP BY date(created_at) ORDER BY day
    ''', (f'-{days} day',)))
    top_products = _rows(self.db.all('''
        SELECT si.product_name, SUM(si.quantity) qty, SUM(si.line_total) total
          FROM sale_items si JOIN sales s ON s.id=si.sale_id
         WHERE COALESCE(s.status,'completed')='completed' AND date(s.created_at) >= date('now', ?)
         GROUP BY si.product_id, si.product_name ORDER BY qty DESC LIMIT 10
    ''', (f'-{days} day',)))
    return {'days': days, 'dashboard': dashboard(self), 'sales_by_day': sales_by_day, 'top_products': top_products}


@domain_function
def daily_business_report(self: Any, day: str | None = None) -> dict[str, Any]:
    """Return the daily business report with legacy-compatible flat keys.

    Some older report widgets read values directly with keys such as
    ``sales_total`` and ``invoice_count``.  Stage 3 returned a newer nested
    shape (``sales``, ``expenses``, ``returns``), which could raise a
    ``KeyError: sales_total`` when opening the reports page.  Keep the nested
    structure for new callers and restore the flat keys for legacy Qt screens.
    """
    report_day = _normalize_date(self, day) or datetime.now().strftime('%Y-%m-%d')
    sales = sales_summary(self, report_day, report_day)
    expenses = expense_summary(self, report_day, report_day)

    if _table_exists(self, 'returns'):
        returns = _rowdict(self.db.one(
            'SELECT COUNT(*) count, COALESCE(SUM(amount),0) total FROM returns WHERE date(created_at)=date(?)',
            (report_day,),
        ))
    else:
        returns = {'count': 0, 'total': 0}

    if _table_exists(self, 'customer_payments'):
        payments_received = float(_scalar(
            self,
            'SELECT COALESCE(SUM(amount),0) FROM customer_payments WHERE date(created_at)=date(?)',
            (report_day,),
            0,
        ) or 0)
    else:
        payments_received = 0.0

    # New debt is informational only.  Keep it defensive across old schemas.
    new_debts = 0.0
    try:
        if _table_exists(self, 'sales'):
            new_debts = float(_scalar(
                self,
                """
                SELECT COALESCE(SUM(total),0)
                  FROM sales
                 WHERE date(created_at)=date(?)
                   AND COALESCE(status,'completed')='completed'
                   AND payment_method='آجل'
                """,
                (report_day,),
                0,
            ) or 0)
    except Exception:
        new_debts = 0.0

    sales_total = float(sales.get('total') or sales.get('sales') or 0)
    invoice_count = int(sales.get('invoices') or 0)
    profit_total = float(sales.get('profit') or 0)
    expenses_total = float(expenses.get('total') or 0)
    returns_total = float(returns.get('total') or returns.get('amount') or 0)
    returns_count = int(returns.get('count') or 0)
    net_profit = profit_total - expenses_total

    report = {
        # Legacy flat keys used by v33_commercial_ui and older reports.
        'date': report_day,
        'sales_total': sales_total,
        'invoice_count': invoice_count,
        'net_profit': net_profit,
        'expenses': expenses_total,
        'returns': returns_total,
        'returns_count': returns_count,
        'new_debts': new_debts,
        'payments_received': payments_received,
        'top_products': [],
        'best_cashiers': [],

        # New structured keys kept for Domain/API callers.
        'sales': sales,
        'expense_summary': expenses,
        'returns_summary': returns,
        'net_profit_after_expenses': net_profit,
    }

    try:
        net_col = 'si.net_line_total' if 'net_line_total' in _columns(self, 'sale_items') else 'si.line_total'
        report['top_products'] = _rows(self.db.all(f'''
            SELECT si.product_name, SUM(si.quantity) qty, COALESCE(SUM({net_col}),0) total
              FROM sale_items si JOIN sales s ON s.id=si.sale_id
             WHERE date(s.created_at)=date(?) AND COALESCE(s.status,'completed')='completed'
             GROUP BY si.product_id, si.product_name ORDER BY qty DESC LIMIT 10
        ''', (report_day,))) if _table_exists(self, 'sale_items') else []
    except Exception:
        report['top_products'] = []

    try:
        if _table_exists(self, 'employees') and _table_exists(self, 'sales'):
            report['best_cashiers'] = _rows(self.db.all('''
                SELECT COALESCE(e.name,'') name, COUNT(s.id) invoices, COALESCE(SUM(s.total),0) total
                  FROM sales s LEFT JOIN employees e ON e.id=s.employee_id
                 WHERE date(s.created_at)=date(?) AND COALESCE(s.status,'completed')='completed'
                 GROUP BY e.id, e.name ORDER BY total DESC LIMIT 10
            ''', (report_day,)))
    except Exception:
        report['best_cashiers'] = []

    return report


@domain_function
def owner_dashboard_snapshot(self: Any) -> dict[str, Any]:
    today = datetime.now().strftime('%Y-%m-%d')
    month = today[:7]
    return {
        'today': dashboard(self),
        'month_sales': sales_summary(self, f'{month}-01', today),
        'low_stock': int(_scalar(self, 'SELECT COUNT(*) FROM products WHERE COALESCE(active,1)=1 AND quantity <= min_quantity')),
        'expenses_month': expense_summary(self, f'{month}-01', today),
    }


@domain_function
def movement_summary(self: Any) -> dict[str, Any]:
    if not _table_exists(self, 'unified_movement_log'):
        return {'today_total': 0, 'sensitive_total': 0, 'discount_total': 0, 'delete_total': 0, 'return_total': 0, 'unread_total': 0, 'top_user': {'name': '', 'c': 0}, 'last_fraud': {}}
    today = now_text()[:10]
    top_user = _rowdict(self.db.one('''
        SELECT COALESCE(user_name,'') name, COUNT(*) c FROM unified_movement_log
         WHERE date(event_time)=date(?) AND COALESCE(user_name,'')<>''
         GROUP BY user_name ORDER BY c DESC LIMIT 1
    ''', (today,)))
    last_fraud = _rowdict(self.db.one('''
        SELECT event_time, action, description FROM unified_movement_log
         WHERE source_table='fraud_alerts' OR action LIKE '%احتيال%'
         ORDER BY datetime(event_time) DESC, id DESC LIMIT 1
    '''))
    return {
        'today_total': int(_scalar(self, 'SELECT COUNT(*) FROM unified_movement_log WHERE date(event_time)=date(?)', (today,))),
        'sensitive_total': int(_scalar(self, 'SELECT COUNT(*) FROM unified_movement_log WHERE date(event_time)=date(?) AND (is_sensitive=1 OR severity IN ("حساس","خطر"))', (today,))),
        'discount_total': int(_scalar(self, 'SELECT COUNT(*) FROM unified_movement_log WHERE date(event_time)=date(?) AND action LIKE ?', (today, '%خصم%'))),
        'delete_total': int(_scalar(self, 'SELECT COUNT(*) FROM unified_movement_log WHERE date(event_time)=date(?) AND (action LIKE ? OR action LIKE ?)', (today, '%حذف%', '%تعطيل%'))),
        'return_total': int(_scalar(self, 'SELECT COUNT(*) FROM unified_movement_log WHERE date(event_time)=date(?) AND (action LIKE ? OR action LIKE ?)', (today, '%إرجاع%', '%مرتجع%'))),
        'unread_total': int(_scalar(self, 'SELECT COUNT(*) FROM unified_movement_log WHERE is_read=0')),
        'top_user': top_user or {'name': '', 'c': 0},
        'last_fraud': last_fraud,
    }


@domain_function
def maintenance_summary(self: Any) -> dict[str, Any]:
    return {
        'notifications': int(_scalar(self, 'SELECT COUNT(*) FROM system_notifications') if _table_exists(self, 'system_notifications') else 0),
        'unified_audit_events': int(_scalar(self, 'SELECT COUNT(*) FROM unified_audit_events') if _table_exists(self, 'unified_audit_events') else 0),
        'maintenance_actions': int(_scalar(self, 'SELECT COUNT(*) FROM maintenance_actions') if _table_exists(self, 'maintenance_actions') else 0),
        'central_services': ['NotificationCenter', 'validators', 'ReportEngine', 'AuditCenter'],
    }


@domain_function
def runtime_health(self: Any) -> dict[str, Any]:
    return runtime_health_v4517416(self)


@domain_function
def runtime_health_v4517415(self: Any) -> dict[str, Any]:
    return runtime_health_v4517416(self)


@domain_function
def runtime_health_v4517416(self: Any) -> dict[str, Any]:
    return {
        'version': 'domain_stage3_reports_read_model',
        'reports_domain_native': True,
        'read_only_migration': True,
        'sqlite_wal_enabled': True,
        'tables': {
            'sales': _table_exists(self, 'sales'),
            'sale_items': _table_exists(self, 'sale_items'),
            'expenses': _table_exists(self, 'expenses'),
            'unified_movement_log': _table_exists(self, 'unified_movement_log'),
        },
    }


@domain_function
def system_health_check(self: Any) -> list[dict[str, Any]]:
    checks: list[dict[str, Any]] = []
    for table in ('users', 'products', 'customers', 'sales', 'sale_items', 'returns'):
        checks.append({'name': f'table:{table}', 'ok': _table_exists(self, table)})
    try:
        journal = _scalar(self, 'PRAGMA journal_mode', default='')
        checks.append({'name': 'sqlite:journal_mode', 'ok': str(journal).lower() == 'wal', 'value': journal})
    except Exception as exc:
        checks.append({'name': 'sqlite:journal_mode', 'ok': False, 'value': str(exc)})
    return checks


@domain_function
def smart_alerts(self: Any) -> list[str]:
    alerts: list[str] = []
    out_count = int(_scalar(self, 'SELECT COUNT(*) FROM products WHERE COALESCE(active,1)=1 AND quantity <= 0'))
    low_count = int(_scalar(self, 'SELECT COUNT(*) FROM products WHERE COALESCE(active,1)=1 AND quantity > 0 AND quantity <= min_quantity'))
    if out_count:
        alerts.append(f'يوجد {out_count} منتج نافد من المخزون')
    if low_count:
        alerts.append(f'يوجد {low_count} منتج وصل إلى حد التنبيه')
    try:
        for row in list(self.debt_rows())[:3]:
            data = _rowdict(row)
            if float(data.get('balance') or 0) > float(data.get('credit_limit') or 0) > 0:
                alerts.append(f"زبون تجاوز حد الدين: {data.get('name','')} - {money(data.get('balance',0))}")
    except Exception as exc:
        log_exception(exc, 'domain smart_alerts debt')
    return alerts
