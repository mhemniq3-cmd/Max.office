from __future__ import annotations

"""V45.17.4.2 medium-severity hardening patch.

Built only on the v45.17.4 line, after v45.17.4.1. It fixes medium-risk
issues without importing v45.17.5+ UI/tool changes.
"""

from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from html import escape as html_escape
import re
from typing import Any

from services.app_core import AppService
from services.core_common import now_text, return_no, money, password_needs_rehash, password_hash, verify_password, validate_password_strength
from services.error_logger import log_exception

_ORIG_INIT = AppService.__init__
_ORIG_LOG = AppService.log
_ORIG_AUTHENTICATE = AppService.authenticate
_ORIG_CHANGE_PASSWORD = AppService.change_password
_ORIG_RETURN_ITEM = AppService.return_item
_ORIG_RETURN_FULL_SALE = AppService.return_full_sale
_ORIG_DEBT_ROWS = AppService.debt_rows
_ORIG_CUSTOMER_STATEMENT = AppService.customer_statement
_ORIG_DASHBOARD = AppService.dashboard
_ORIG_SMART_ALERTS = AppService.smart_alerts
_ORIG_MANAGEMENT_REPORT = AppService.management_report
_ORIG_COMMISSION_REPORT = AppService.commission_report

MONEY = Decimal('0.01')
CONTROL_CHARS = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]')


def _d(value: Any, default: str = '0') -> Decimal:
    try:
        if value is None or str(value).strip() == '':
            value = default
        return Decimal(str(value).replace(',', '').strip()).quantize(MONEY, rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError, TypeError):
        return Decimal(default).quantize(MONEY, rounding=ROUND_HALF_UP)


def _s(value: Any, max_len: int = 500) -> str:
    text = str(value or '')
    text = CONTROL_CHARS.sub('', text).replace('\r', ' ').replace('\n', ' | ')
    return text.strip()[:max_len]


def _html_value(value: Any) -> Any:
    if isinstance(value, str):
        return html_escape(value, quote=True)
    return value


def _html_row(row: Any) -> Any:
    try:
        data = dict(row)
    except Exception:
        return row
    return {k: _html_value(v) for k, v in data.items()}


def _active_case_expr() -> str:
    return "CASE WHEN (COALESCE(subtotal,0)-COALESCE(discount_amount,0)+COALESCE(tax_amount,0)) < 0 THEN 0 ELSE (COALESCE(subtotal,0)-COALESCE(discount_amount,0)+COALESCE(tax_amount,0)) END"


def _table_cols(conn, table: str) -> set[str]:
    try:
        return {r[1] for r in conn.execute(f'PRAGMA table_info({table})')}
    except Exception:
        return set()


def _has_status(conn, table: str) -> bool:
    return 'status' in _table_cols(conn, table)


def _install_migrations(self: AppService) -> None:
    try:
        from services.migrations.v45_17_4_2_medium_security import run
        run(self.db.conn)
    except Exception as exc:
        log_exception(exc, 'v45.17.4.2 migration')


def _init(self: AppService, db):
    _ORIG_INIT(self, db)
    _install_migrations(self)


def _log(self: AppService, action: str, details: str = '', user_id: int | None = None, username: str = '') -> None:
    """Sanitize log fields to prevent log forging/injection."""
    try:
        return _ORIG_LOG(self, _s(action, 120), _s(details, 900), user_id, _s(username, 120))
    except Exception as exc:
        log_exception(exc, 'safe activity log')


def _authenticate(self: AppService, username: str, password: str):
    """Sanitize login input and force PBKDF2 upgrade for legacy hashes.

    v11 already provides lockout/rate-limiting. This patch keeps that chain
    active, adds log sanitization, and makes legacy-hash logins change their
    password immediately after migration.
    """
    username_clean = _s(username, 80)
    before = self.db.one('SELECT id, password_hash FROM users WHERE username=? AND active=1', (username_clean,)) if username_clean else None
    legacy_login = bool(before and password_needs_rehash(before['password_hash']) and verify_password(password, before['password_hash']))
    user = _ORIG_AUTHENTICATE(self, username_clean, password)
    if user and legacy_login:
        try:
            # Rehash immediately, but require a fresh password to remove the legacy risk.
            self.db.execute('UPDATE users SET password_hash=?, must_change_password=1 WHERE id=?', (password_hash(password), int(user['id'])))
            self.log('ترقية تشفير كلمة المرور', 'تمت ترقية حساب قديم ويجب تغيير كلمة المرور', int(user['id']), username_clean)
            user = self.db.one('SELECT * FROM users WHERE id=?', (int(user['id']),))
        except Exception as exc:
            log_exception(exc, 'legacy password migration')
    return user


def _change_password(self: AppService, user_id: int, old_password: str, new_password: str) -> None:
    row = self.db.one('SELECT username, password_hash FROM users WHERE id=? AND active=1', (user_id,))
    if not row or not verify_password(old_password, row['password_hash']):
        raise ValueError('كلمة المرور الحالية غير صحيحة')
    validate_password_strength(new_password, row['username'])
    if str(new_password) == str(old_password):
        raise ValueError('كلمة المرور الجديدة يجب أن تختلف عن الحالية')
    self.db.execute('UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?', (password_hash(new_password), user_id))
    self.log('تغيير كلمة مرور', 'تم تغيير كلمة المرور بتشفير PBKDF2', user_id)


def _sale_remaining_row(conn, sale_item_id: int):
    return conn.execute('''
        SELECT si.*, s.employee_id, s.customer_id, s.id sale_id,
               COALESCE(SUM(r.quantity),0) returned_qty,
               si.quantity - COALESCE(SUM(r.quantity),0) remaining_qty
        FROM sale_items si
        JOIN sales s ON s.id=si.sale_id
        LEFT JOIN returns r ON r.sale_item_id=si.id
        WHERE si.id=?
        GROUP BY si.id
    ''', (sale_item_id,)).fetchone()


def _insert_return_for_row(self: AppService, conn, row, quantity: int, reason: str, user_id: int, refund_method: str) -> str:
    if quantity <= 0:
        raise ValueError('كمية الإرجاع يجب أن تكون أكبر من صفر')
    if quantity > int(row['remaining_qty'] or 0):
        raise ValueError('كمية الإرجاع أكبر من الكمية المتبقية')

    gross_amount = (_d(quantity) * _d(row['unit_price'])).quantize(MONEY, rounding=ROUND_HALF_UP)
    original_subtotal_row = conn.execute('SELECT COALESCE(SUM(line_total),0) v FROM sale_items WHERE sale_id=?', (row['sale_id'],)).fetchone()
    sale_row = conn.execute('SELECT discount_amount, tax_amount FROM sales WHERE id=?', (row['sale_id'],)).fetchone()
    original_subtotal = _d(original_subtotal_row['v'] if original_subtotal_row else 0)
    original_discount = _d(sale_row['discount_amount'] if sale_row else 0)
    original_tax = _d(sale_row['tax_amount'] if sale_row else 0)
    discount_share = (original_discount * gross_amount / original_subtotal).quantize(MONEY, rounding=ROUND_HALF_UP) if original_subtotal else Decimal('0.00')
    net_before_tax = max(gross_amount - discount_share, Decimal('0.00'))
    taxable_base = max(original_subtotal - original_discount, Decimal('0.00'))
    tax_share = (original_tax * net_before_tax / taxable_base).quantize(MONEY, rounding=ROUND_HALF_UP) if taxable_base else Decimal('0.00')
    amount = (net_before_tax + tax_share).quantize(MONEY, rounding=ROUND_HALF_UP)
    commission = (net_before_tax * _d(row['commission_percent']) / Decimal('100')).quantize(MONEY, rounding=ROUND_HALF_UP)
    profit = (_d(quantity) * (_d(row['unit_price']) - _d(row['cost_price'])) - discount_share).quantize(MONEY, rounding=ROUND_HALF_UP)
    ret = return_no()

    conn.execute('''
        INSERT INTO returns (return_no, sale_id, sale_item_id, product_id, product_name, employee_id, customer_id,
                             quantity, unit_price, amount, commission_amount, profit_amount, reason, refund_method,
                             created_by_user_id, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (ret, row['sale_id'], row['id'], row['product_id'], row['product_name'], row['employee_id'], row['customer_id'],
          quantity, row['unit_price'], float(amount), float(commission), float(profit), _s(reason, 300), refund_method,
          user_id, now_text()))

    product = conn.execute('SELECT quantity FROM products WHERE id=?', (row['product_id'],)).fetchone()
    oldq = int(product['quantity'] if product else 0)
    newq = oldq + int(quantity)
    conn.execute('UPDATE products SET quantity=? WHERE id=?', (newq, row['product_id']))
    conn.execute('''
        INSERT INTO inventory_movements (product_id, movement_type, quantity_change, old_quantity, new_quantity,
                                         ref_type, ref_no, note, user_id, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (row['product_id'], 'مرتجع', quantity, oldq, newq, 'return', ret, _s(reason, 300), user_id, now_text()))
    conn.execute('''
        UPDATE sales
        SET total=CASE WHEN (total-?) < 0 THEN 0 ELSE (total-?) END,
            total_commission=CASE WHEN (total_commission-?) < 0 THEN 0 ELSE (total_commission-?) END,
            total_profit=CASE WHEN (total_profit-?) < 0 THEN 0 ELSE (total_profit-?) END
        WHERE id=?
    ''', (float(amount), float(amount), float(commission), float(commission), float(profit), float(profit), row['sale_id']))
    return ret


def _return_item(self: AppService, sale_item_id: int, quantity: int, reason: str = '', user_id: int | None = None, refund_method: str = 'نقدي') -> str:
    user = self.require_permission('can_returns', user_id, 'تسجيل المرتجعات')
    user_id = int(user['id'])
    reason = _s(reason, 300)
    if not reason:
        raise ValueError('سبب الإرجاع مطلوب')
    conn = self.db.conn
    began = False
    try:
        if not conn.in_transaction:
            conn.execute('BEGIN IMMEDIATE')
            began = True
        row = _sale_remaining_row(conn, int(sale_item_id))
        if not row:
            raise ValueError('المادة غير موجودة في الفاتورة')
        ret = _insert_return_for_row(self, conn, row, int(quantity), reason, user_id, refund_method)
        if began and conn.in_transaction:
            conn.commit()
        self.log('مرتجع', ret, user_id)
        return ret
    except Exception:
        if conn.in_transaction:
            conn.rollback()
        raise


def _return_full_sale(self: AppService, sale_id: int, reason: str = '', user_id: int | None = None, refund_method: str = 'نقدي') -> list[str]:
    user = self.require_permission('can_returns', user_id, 'إرجاع الفواتير')
    user_id = int(user['id'])
    if not self.is_admin_user(user) and not bool(self.user_has(user, 'can_return_full')):
        raise ValueError('لا تملك صلاحية إرجاع فاتورة كاملة')
    reason = _s(reason, 300)
    if not reason:
        raise ValueError('سبب الإرجاع مطلوب')
    conn = self.db.conn
    numbers: list[str] = []
    try:
        if not conn.in_transaction:
            conn.execute('BEGIN IMMEDIATE')
        sale = conn.execute('SELECT id FROM sales WHERE id=?', (int(sale_id),)).fetchone()
        if not sale:
            raise ValueError('الفاتورة غير موجودة')
        items = conn.execute('''
            SELECT si.id, si.quantity - COALESCE(SUM(r.quantity),0) remaining_qty
            FROM sale_items si
            LEFT JOIN returns r ON r.sale_item_id=si.id
            WHERE si.sale_id=?
            GROUP BY si.id
        ''', (int(sale_id),)).fetchall()
        for item in items:
            qty = int(item['remaining_qty'] or 0)
            if qty > 0:
                row = _sale_remaining_row(conn, int(item['id']))
                if row and int(row['remaining_qty'] or 0) > 0:
                    numbers.append(_insert_return_for_row(self, conn, row, qty, reason, user_id, refund_method))
        if not numbers:
            raise ValueError('لا توجد مواد متبقية للإرجاع في هذه الفاتورة')
        conn.commit()
        self.log('مرتجع كامل', f'فاتورة {sale_id} | {len(numbers)} عمليات', user_id)
        return numbers
    except Exception:
        if conn.in_transaction:
            conn.rollback()
        raise


def _debt_rows(self: AppService):
    return self.db.all(f'''
        WITH credit AS (
            SELECT customer_id, SUM({_active_case_expr()}) credit_sales
            FROM sales
            WHERE payment_method='آجل'
            GROUP BY customer_id
        ), returned AS (
            SELECT s.customer_id, SUM(COALESCE(r.amount,0)) returns_amount
            FROM returns r JOIN sales s ON s.id=r.sale_id
            GROUP BY s.customer_id
        ), payments AS (
            SELECT customer_id, SUM(COALESCE(amount,0)) payments
            FROM customer_payments
            GROUP BY customer_id
        )
        SELECT c.id, c.name, c.phone, c.credit_limit, c.due_days,
               COALESCE(credit.credit_sales,0) credit_sales,
               COALESCE(returned.returns_amount,0) returns_amount,
               COALESCE(payments.payments,0) payments,
               COALESCE(credit.credit_sales,0) - COALESCE(returned.returns_amount,0) - COALESCE(payments.payments,0) balance
        FROM customers c
        LEFT JOIN credit ON credit.customer_id=c.id
        LEFT JOIN returned ON returned.customer_id=c.id
        LEFT JOIN payments ON payments.customer_id=c.id
        WHERE c.active=1
        ORDER BY balance DESC, c.name
    ''')


def _customer_statement(self: AppService, customer_id: int):
    rows = []
    sale_amount_expr = _active_case_expr()
    for sale in self.db.all(f'SELECT invoice_no ref, created_at, {sale_amount_expr} amount, payment_method note FROM sales WHERE customer_id=? ORDER BY created_at LIMIT 2000', (customer_id,)):
        rows.append(dict(kind='بيع', ref=sale['ref'], created_at=sale['created_at'], debit=sale['amount'] if sale['note'] == 'آجل' else 0, credit=0, note=sale['note']))
    for ret in self.db.all('''SELECT r.return_no ref, r.created_at, r.amount FROM returns r JOIN sales s ON s.id=r.sale_id WHERE s.customer_id=? ORDER BY r.created_at LIMIT 2000''', (customer_id,)):
        rows.append(dict(kind='مرتجع', ref=ret['ref'], created_at=ret['created_at'], debit=0, credit=ret['amount'], note='مرتجع'))
    for pay in self.db.all('SELECT COALESCE(receipt_no,id) ref, created_at, amount, note FROM customer_payments WHERE customer_id=? ORDER BY created_at LIMIT 2000', (customer_id,)):
        rows.append(dict(kind='دفعة', ref=str(pay['ref']), created_at=pay['created_at'], debit=0, credit=pay['amount'], note=pay['note'] or 'دفعة'))
    return sorted((_html_row(r) for r in rows), key=lambda x: x['created_at'])


def _dashboard(self: AppService) -> dict:
    data = dict(_ORIG_DASHBOARD(self))
    try:
        debt = self.db.one(f'''
            WITH credit AS (
                SELECT customer_id, SUM({_active_case_expr()}) amount
                FROM sales WHERE payment_method='آجل' GROUP BY customer_id
            ), payments AS (
                SELECT customer_id, SUM(amount) amount FROM customer_payments GROUP BY customer_id
            ), returned AS (
                SELECT s.customer_id, SUM(r.amount) amount FROM returns r JOIN sales s ON s.id=r.sale_id GROUP BY s.customer_id
            )
            SELECT COALESCE(SUM(COALESCE(credit.amount,0)-COALESCE(returned.amount,0)-COALESCE(payments.amount,0)),0) total_debt
            FROM customers c
            LEFT JOIN credit ON credit.customer_id=c.id
            LEFT JOIN payments ON payments.customer_id=c.id
            LEFT JOIN returned ON returned.customer_id=c.id
            WHERE c.active=1
        ''')
        data['total_debt'] = debt['total_debt'] if debt else 0
        data['best_product'] = _html_value(data.get('best_product', '-'))
    except Exception as exc:
        log_exception(exc, 'v45.17.4.2 dashboard debt')
    return data


def _smart_alerts(self: AppService) -> list[str]:
    return [_s(_html_value(x), 500) for x in _ORIG_SMART_ALERTS(self)]


def _management_report(self: AppService, kind: str):
    return [_html_row(r) for r in _ORIG_MANAGEMENT_REPORT(self, kind)]


def _commission_report(self: AppService):
    return [_html_row(r) for r in _ORIG_COMMISSION_REPORT(self)]


AppService.__init__ = _init
AppService.log = _log
AppService.authenticate = _authenticate
AppService.change_password = _change_password
AppService.return_item = _return_item
AppService.return_full_sale = _return_full_sale
AppService.debt_rows = _debt_rows
AppService.customer_statement = _customer_statement
AppService.dashboard = _dashboard
AppService.smart_alerts = _smart_alerts
AppService.management_report = _management_report
AppService.commission_report = _commission_report
