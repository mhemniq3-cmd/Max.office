from __future__ import annotations

"""V45.17.1 security and integrity hardening.

Built on v45.17 only; no v45.18/v45.19 UI redesign dependencies.
"""

import os
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

from services.app_core import AppService
from services.error_logger import log_exception
from database import now_text, password_needs_rehash

_ORIG_INIT = AppService.__init__
_ORIG_COMPLETE_SALE = getattr(AppService, 'complete_sale', None)
_ORIG_RESOLVE_SALE_LINE = getattr(AppService, 'resolve_sale_line', None)
_ORIG_PRODUCT_BY_BARCODE = getattr(AppService, 'product_by_barcode', None)


def _rowdict(row: Any) -> dict[str, Any]:
    if row is None:
        return {}
    if isinstance(row, dict):
        return dict(row)
    try:
        return dict(row)
    except Exception:
        try:
            return {k: row[k] for k in row.keys()}
        except Exception:
            return {}


def _normalize_date(value: str | None) -> str:
    text = str(value or '').strip()
    if not text:
        return ''
    text = text.translate(str.maketrans('٠١٢٣٤٥٦٧٨٩', '0123456789'))
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d-%m-%Y', '%Y/%m/%d'):
        try:
            return datetime.strptime(text, fmt).strftime('%Y-%m-%d')
        except ValueError:
            pass
    raise ValueError('صيغة التاريخ غير صحيحة. استخدم YYYY-MM-DD أو DD/MM/YYYY')


def _safe_limit(value: Any, default: int = 100, maximum: int = 1000) -> int:
    try:
        n = int(value)
    except Exception:
        n = default
    return max(1, min(n, maximum))


def _safe_offset(value: Any) -> int:
    try:
        n = int(value)
    except Exception:
        n = 0
    return max(0, n)


def _ensure_security_schema(self: AppService) -> None:
    self.db.conn.executescript("""
        CREATE TABLE IF NOT EXISTS fiscal_periods (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            year INTEGER NOT NULL,
            month INTEGER NOT NULL,
            is_closed INTEGER NOT NULL DEFAULT 0,
            closed_at TEXT,
            closed_by_user_id INTEGER,
            note TEXT,
            UNIQUE(year, month)
        );
        CREATE TRIGGER IF NOT EXISTS trg_products_no_negative_qty_v45171
        BEFORE UPDATE OF quantity ON products
        FOR EACH ROW
        WHEN NEW.quantity < 0
        BEGIN
            SELECT RAISE(ABORT, 'لا يمكن أن تصبح كمية المخزون سالبة');
        END;
    """)
    self.db.conn.commit()


def _period_key(created_at: str | None = None) -> tuple[int, int]:
    day = _normalize_date(created_at) if created_at else datetime.now().strftime('%Y-%m-%d')
    dt = datetime.strptime(day[:10], '%Y-%m-%d')
    return dt.year, dt.month


def _is_fiscal_period_closed(self: AppService, date_text: str | None = None) -> bool:
    try:
        year, month = _period_key(date_text)
        row = self.db.one('SELECT is_closed FROM fiscal_periods WHERE year=? AND month=?', (year, month))
        return bool(row and int(row['is_closed'] or 0))
    except Exception:
        return False


def _assert_fiscal_open(self: AppService, date_text: str | None = None, action: str = 'تعديل') -> None:
    if _is_fiscal_period_closed(self, date_text):
        raise ValueError(f'لا يمكن {action} بيانات فترة مالية مقفولة')


def _close_fiscal_period(self: AppService, year: int, month: int, user_id: int | None = None, note: str = '') -> None:
    self.require_permission('can_settings', user_id, 'إغلاق الفترة المالية')
    self.db.execute("""
        INSERT INTO fiscal_periods (year, month, is_closed, closed_at, closed_by_user_id, note)
        VALUES (?, ?, 1, ?, ?, ?)
        ON CONFLICT(year, month) DO UPDATE SET
            is_closed=1, closed_at=excluded.closed_at,
            closed_by_user_id=excluded.closed_by_user_id, note=excluded.note
    """, (int(year), int(month), now_text(), user_id, str(note or '').strip()))


def _open_fiscal_period(self: AppService, year: int, month: int, user_id: int | None = None) -> None:
    self.require_permission('can_settings', user_id, 'فتح الفترة المالية')
    self.db.execute("""
        INSERT INTO fiscal_periods (year, month, is_closed, closed_at, closed_by_user_id, note)
        VALUES (?, ?, 0, NULL, ?, '')
        ON CONFLICT(year, month) DO UPDATE SET is_closed=0, closed_at=NULL, closed_by_user_id=excluded.closed_by_user_id
    """, (int(year), int(month), user_id))


def _list_fiscal_periods(self: AppService) -> list[dict[str, Any]]:
    rows = self.db.all('SELECT * FROM fiscal_periods ORDER BY year DESC, month DESC LIMIT 120')
    return [dict(r) for r in rows]


def _stock_guard_cart(self: AppService, cart: list[dict]) -> None:
    if not cart:
        raise ValueError('السلة فارغة')
    totals: dict[int, int] = {}
    for item in cart:
        pid = int(item.get('product_id') or 0)
        qty = int(float(item.get('quantity') or 0))
        if pid <= 0 or qty <= 0:
            raise ValueError('يوجد صنف غير صالح في الفاتورة')
        totals[pid] = totals.get(pid, 0) + qty
    for pid, qty in totals.items():
        row = self.db.one('SELECT id, name, quantity FROM products WHERE id=? AND active=1', (pid,))
        if not row:
            raise ValueError('منتج غير موجود أو معطل')
        current = int(row['quantity'] or 0)
        if qty > current:
            raise ValueError(f"الكمية المطلوبة من المنتج ({row['name']}) أكبر من المتاح في المخزون. المتاح: {current}")


def _complete_sale(self: AppService, cart: list[dict], employee_id: int, customer_id: int | None,
                   payment_method: str, discount_amount: float = 0, note: str = '',
                   user_id: int | None = None, discount_type: str = 'amount', coupon_code: str = '') -> str:
    self.require_any_permission(('can_sales', 'can_touch_pos'), user_id, 'إصدار فاتورة')
    _assert_fiscal_open(self, None, 'إصدار فاتورة')
    _stock_guard_cart(self, cart or [])
    if _ORIG_COMPLETE_SALE is None:
        raise RuntimeError('دالة البيع الأساسية غير متوفرة')
    try:
        return _ORIG_COMPLETE_SALE(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type, coupon_code)
    except TypeError:
        return _ORIG_COMPLETE_SALE(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type)


def _build_sales_where(date_from: str = '', date_to: str = '') -> tuple[str, list[Any]]:
    where = ["s.status='completed'"]
    params: list[Any] = []
    if date_from:
        where.append('date(s.created_at) >= date(?)')
        params.append(_normalize_date(date_from))
    if date_to:
        where.append('date(s.created_at) <= date(?)')
        params.append(_normalize_date(date_to))
    return ' AND '.join(where), params


def _advanced_reports(self: AppService, date_from: str = '', date_to: str = '', limit: int = 500, offset: int = 0) -> dict[str, Any]:
    self.require_permission('can_reports', action='عرض التقارير المتقدمة')
    limit = _safe_limit(limit, 500, 1000)
    offset = _safe_offset(offset)
    w, params = _build_sales_where(date_from, date_to)

    daily_sql = 'SELECT date(s.created_at) period, COUNT(*) invoices, COALESCE(SUM(s.total),0) sales, COALESCE(SUM(s.total_profit),0) profit, COALESCE(SUM(s.tax_amount),0) tax, COALESCE(SUM(s.discount_amount),0) discounts FROM sales s WHERE ' + w + ' GROUP BY date(s.created_at) ORDER BY period DESC LIMIT ? OFFSET ?'
    daily = [dict(r) for r in self.db.all(daily_sql, (*params, limit, offset))]

    monthly_sql = 'SELECT substr(s.created_at,1,7) period, COUNT(*) invoices, COALESCE(SUM(s.total),0) sales, COALESCE(SUM(s.total_profit),0) profit, COALESCE(SUM(s.tax_amount),0) tax, COALESCE(SUM(s.discount_amount),0) discounts FROM sales s WHERE ' + w + ' GROUP BY substr(s.created_at,1,7) ORDER BY period DESC LIMIT ? OFFSET ?'
    monthly = [dict(r) for r in self.db.all(monthly_sql, (*params, 120, 0))]

    prod_from = ' FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE ' + w
    best_selling = [dict(r) for r in self.db.all('SELECT si.product_id, si.product_name, SUM(si.quantity) qty, SUM(si.line_total) amount, SUM(COALESCE(si.profit_amount, (si.unit_price-si.cost_price)*si.quantity)) profit' + prod_from + ' GROUP BY si.product_id, si.product_name ORDER BY qty DESC LIMIT 50', params)]
    most_profit = [dict(r) for r in self.db.all('SELECT si.product_id, si.product_name, SUM(si.quantity) qty, SUM(si.line_total) amount, SUM(COALESCE(si.profit_amount, (si.unit_price-si.cost_price)*si.quantity)) profit' + prod_from + ' GROUP BY si.product_id, si.product_name ORDER BY profit DESC LIMIT 50', params)]

    least_selling = [dict(r) for r in self.db.all("""SELECT p.id product_id, p.name product_name, COALESCE(SUM(si.quantity),0) qty, p.quantity stock
        FROM products p
        LEFT JOIN sale_items si ON si.product_id=p.id
        LEFT JOIN sales s ON s.id=si.sale_id AND s.status='completed'
        WHERE p.active=1
        GROUP BY p.id
        ORDER BY qty ASC, p.quantity DESC
        LIMIT 50""")]

    inventory = [dict(r) for r in self.db.all("""SELECT im.created_at, p.name product_name, im.movement_type, im.quantity_change, im.old_quantity, im.new_quantity, im.ref_type, im.ref_no, im.note
        FROM inventory_movements im
        LEFT JOIN products p ON p.id=im.product_id
        ORDER BY im.id DESC
        LIMIT ? OFFSET ?""", (limit, offset))]

    customer_debts = [dict(r) for r in self.db.all("""SELECT c.id, c.name, c.phone,
        COALESCE((SELECT SUM(total) FROM sales WHERE customer_id=c.id AND payment_method='آجل' AND status='completed'),0)
        - COALESCE((SELECT SUM(amount) FROM customer_payments WHERE customer_id=c.id),0) balance
        FROM customers c
        WHERE c.active=1
        GROUP BY c.id
        HAVING balance>0
        ORDER BY balance DESC
        LIMIT 100""")]

    try:
        supplier_debts = [dict(r) for r in self.db.all("""SELECT s.id, s.name, s.phone,
            COALESCE((SELECT SUM(total) FROM purchases WHERE supplier_id=s.id),0)
            - COALESCE((SELECT SUM(amount) FROM supplier_payments WHERE supplier_id=s.id),0) balance
            FROM suppliers s
            WHERE s.active=1
            GROUP BY s.id
            HAVING balance>0
            ORDER BY balance DESC
            LIMIT 100""")]
    except Exception:
        supplier_debts = []

    employee_report = [dict(r) for r in self.db.all("""SELECT e.id, e.name, COUNT(s.id) invoices, COALESCE(SUM(s.total),0) sales, COALESCE(SUM(s.total_profit),0) profit
        FROM employees e
        LEFT JOIN sales s ON s.employee_id=e.id AND s.status='completed'
        GROUP BY e.id
        ORDER BY sales DESC
        LIMIT 100""")]

    discount_report = [dict(r) for r in self.db.all('SELECT s.invoice_no, s.created_at, s.subtotal, s.discount_amount, COALESCE(s.coupon_code, "") coupon_code, u.username FROM sales s LEFT JOIN users u ON u.id=s.user_id WHERE s.status="completed" AND COALESCE(s.discount_amount,0)>0 ORDER BY s.id DESC LIMIT ? OFFSET ?', (limit, offset))]

    return {
        'daily_profit': daily,
        'monthly_profit': monthly,
        'best_selling_products': best_selling,
        'most_profit_products': most_profit,
        'least_selling_products': least_selling,
        'inventory_movements': inventory,
        'customer_debts': customer_debts,
        'supplier_debts': supplier_debts,
        'employee_report': employee_report,
        'discount_report': discount_report,
        'pagination': {'limit': limit, 'offset': offset},
    }


def _secure_profit_summary(self: AppService, date_from: str = '', date_to: str = '') -> dict[str, Any]:
    self.require_permission('can_reports', action='عرض الأرباح')
    w, params = _build_sales_where(date_from, date_to)
    row = self.db.one('SELECT COUNT(DISTINCT s.id) invoices, COALESCE(SUM(si.line_total),0) sales, COALESCE(SUM((si.unit_price-si.cost_price)*si.quantity),0) gross_profit, COALESCE(SUM(s.discount_amount),0) discounts FROM sales s JOIN sale_items si ON si.sale_id=s.id WHERE ' + w, params)
    d = _rowdict(row)
    return {
        'invoices': d.get('invoices', 0),
        'sales': d.get('sales', 0),
        'profit': float(d.get('gross_profit') or 0) - float(d.get('discounts') or 0),
        'discounts': d.get('discounts', 0),
    }


def _backup_dir_secure(self: AppService) -> Path:
    path = Path(os.path.expanduser('~/MaxSales_Backups')).resolve()
    path.mkdir(parents=True, exist_ok=True)
    return path


def _backup_database_secure(self: AppService) -> Path:
    self.require_permission('can_backup', action='إنشاء نسخة احتياطية')
    target = _backup_dir_secure(self) / f'max_sales_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.db'
    backup_conn = None
    try:
        backup_conn = sqlite3.connect(target)
        self.db.conn.backup(backup_conn)
    finally:
        if backup_conn is not None:
            backup_conn.close()
    backups = sorted(_backup_dir_secure(self).glob('max_sales_backup_*.db'), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[10:]:
        try:
            old.unlink()
        except Exception as exc:
            log_exception(exc, 'v45.17.1 old backup cleanup')
    return target


def _resolve_sale_line_secure(self: AppService, product_id, quantity=1, *args, **kwargs):
    try:
        pid = int(product_id)
    except Exception:
        text = str(product_id or '').strip()
        if text.isdigit():
            row = self.db.one('SELECT id FROM products WHERE barcode=? AND active=1', (text,))
            if row:
                pid = int(row['id'])
            else:
                raise ValueError('لا يوجد منتج بهذا الباركود')
        else:
            raise
    qty = int(float(quantity or 1))
    row = self.db.one('SELECT quantity, name FROM products WHERE id=? AND active=1', (pid,))
    if not row:
        raise ValueError('المنتج غير موجود أو معطل')
    if qty <= 0:
        raise ValueError('الكمية يجب أن تكون أكبر من صفر')
    if qty > int(row['quantity'] or 0):
        raise ValueError(f"الكمية المطلوبة من المنتج ({row['name']}) أكبر من المتاح")
    if _ORIG_RESOLVE_SALE_LINE:
        return _ORIG_RESOLVE_SALE_LINE(self, pid, qty, *args, **kwargs)
    raise RuntimeError('دالة قراءة المنتج للبيع غير متوفرة')


def _product_by_barcode_secure(self: AppService, barcode: str):
    text = str(barcode or '').strip()
    if not text:
        return None
    candidates = [text]
    if text.isdigit():
        try:
            candidates.append(str(int(text)))
        except Exception:
            pass
    seen = set()
    for value in candidates:
        if value in seen:
            continue
        seen.add(value)
        row = self.db.one('SELECT * FROM products WHERE barcode=? AND active=1 LIMIT 1', (value,))
        if row:
            return row
    if _ORIG_PRODUCT_BY_BARCODE:
        return _ORIG_PRODUCT_BY_BARCODE(self, text)
    return None


def _security_health_v45171(self: AppService) -> dict[str, Any]:
    users = [dict(r) for r in self.db.all('SELECT id, username, password_hash FROM users LIMIT 500')]
    weak = [u['username'] for u in users if password_needs_rehash(u.get('password_hash'))]
    return {
        'sql_parameterized_reports': True,
        'password_scheme': 'PBKDF2-SHA256 with legacy rehash-on-login',
        'weak_password_hash_users': weak,
        'external_backup_dir': str(_backup_dir_secure(self)),
        'fiscal_lock_enabled': True,
        'stock_negative_trigger': True,
    }


def _init(self: AppService, *args, **kwargs):
    _ORIG_INIT(self, *args, **kwargs)
    try:
        _ensure_security_schema(self)
    except Exception as exc:
        log_exception(exc, 'v45.17.1 schema init')


AppService.__init__ = _init
AppService.complete_sale = _complete_sale
AppService.advanced_reports = _advanced_reports
AppService.profit_summary = _secure_profit_summary
AppService.backup_database = _backup_database_secure
AppService.backup_dir = _backup_dir_secure
AppService.resolve_sale_line = _resolve_sale_line_secure
AppService.product_by_barcode = _product_by_barcode_secure
AppService.normalize_search_date = staticmethod(_normalize_date)
AppService.is_fiscal_period_closed = _is_fiscal_period_closed
AppService.assert_fiscal_open = _assert_fiscal_open
AppService.close_fiscal_period = _close_fiscal_period
AppService.open_fiscal_period = _open_fiscal_period
AppService.list_fiscal_periods = _list_fiscal_periods
AppService.security_health_v45171 = _security_health_v45171
