from __future__ import annotations

"""V45.15 final quality fixes for the remaining audit findings.

Keeps the restored v44 design and applies small runtime-safe fixes for:
- portable DB defaults and explicit database error messages;
- invoice math validation through the shared Decimal calculator;
- negative product quantity protection at UI/service/database level;
- password hashing for every new/edited user via existing PBKDF2 helpers;
- partial Arabic product search through LIKE filters;
- empty invoice prevention before persistence;
- QSS selector typo compatibility check.
"""

from pathlib import Path
from typing import Any

from db import database_core as _dbcore
from services.app_core import AppService
from services.error_logger import log_exception, log_message
from services.shared import finance, search, validation

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DB_DIR = PROJECT_ROOT / 'database'
DB_DIR.mkdir(parents=True, exist_ok=True)

# Make the database default path portable even when code imports db.database_core
# directly before service patches are applied.
_dbcore.APP_DB_DIR = DB_DIR
_dbcore.DB_FILE = DB_DIR / 'max_sales.db'


def _row_to_dict(row: Any) -> dict[str, Any] | None:
    if row is None:
        return None
    if isinstance(row, dict):
        return dict(row)
    try:
        return {k: row[k] for k in row.keys()}
    except Exception:
        try:
            return dict(row)
        except Exception:
            return {'value': row}


def _rows_to_dict(rows: list[Any]) -> list[dict[str, Any]]:
    return [x for x in (_row_to_dict(r) for r in (rows or [])) if x is not None]


def _v4515_product_columns(self: AppService) -> set[str]:
    try:
        return {str(r['name']) for r in self.db.all('PRAGMA table_info(products)')}
    except Exception:
        return set()


def _v4515_select_product_cols(self: AppService) -> str:
    cols = _v4515_product_columns(self)
    wanted = [
        'id', 'barcode', 'name', 'category', 'cost_price', 'sale_price',
        'quantity', 'min_quantity', 'commission_percent', 'active', 'created_at',
        'expiry_date', 'customs_no', 'country_origin', 'unit_name', 'items_per_unit', 'reorder_point',
    ]
    selected = [c for c in wanted if c in cols]
    if not selected:
        selected = ['*']
    selected.append("CASE WHEN COALESCE(quantity,0) <= 0 THEN 'نافد' WHEN COALESCE(quantity,0) <= COALESCE(min_quantity,0) THEN 'منخفض' ELSE 'متوفر' END AS stock_status")
    return ', '.join(selected)


def _v4515_list_products(self: AppService, term: str = '', category: str = '', state: str = 'active') -> list[dict[str, Any]]:
    """Unified product listing with safe partial search, including Arabic text."""
    term = validation.clean_text(term, 120)
    category = validation.clean_text(category, 120)
    state = validation.clean_text(state, 30) or 'active'
    where: list[str] = []
    params: list[Any] = []

    if state == 'all':
        pass
    elif state == 'inactive':
        where.append('COALESCE(active,1)=0')
    elif state == 'out':
        where.append('COALESCE(active,1)=1 AND COALESCE(quantity,0) <= 0')
    elif state == 'low':
        where.append('COALESCE(active,1)=1 AND COALESCE(quantity,0) > 0 AND COALESCE(quantity,0) <= COALESCE(min_quantity,0)')
    else:
        where.append('COALESCE(active,1)=1')

    # LIKE %term% works with Arabic in SQLite when the database/text is UTF-8.
    clause, like_params = search.build_like_filter(['name', 'barcode', 'category'], term)
    if clause:
        where.append(clause)
        params.extend(like_params)
    if category:
        where.append('category=?')
        params.append(category)

    sql = f"SELECT {_v4515_select_product_cols(self)} FROM products"
    if where:
        sql += ' WHERE ' + ' AND '.join(where)
    sql += " ORDER BY COALESCE(active,1) DESC, CASE WHEN COALESCE(quantity,0)<=0 THEN 0 WHEN COALESCE(quantity,0)<=COALESCE(min_quantity,0) THEN 1 ELSE 2 END, name COLLATE NOCASE LIMIT ?"
    params.append(500)
    return _rows_to_dict(self.db.all(sql, params))


_prev_save_product_v4515 = AppService.save_product


def _v4515_save_product(self: AppService, data: dict, product_id: int | None = None) -> None:
    data = dict(data or {})
    try:
        qty = int(float(str(data.get('quantity', 0)).strip() or 0))
    except Exception as exc:
        raise ValueError('كمية المنتج يجب أن تكون رقماً صحيحاً') from exc
    if qty < 0:
        raise ValueError('لا يمكن إدخال كمية سالبة للمنتج')
    try:
        min_qty = int(float(str(data.get('min_quantity', 0)).strip() or 0))
    except Exception as exc:
        raise ValueError('حد التنبيه يجب أن يكون رقماً صحيحاً') from exc
    if min_qty < 0:
        raise ValueError('حد التنبيه لا يمكن أن يكون سالباً')
    data['quantity'] = qty
    data['min_quantity'] = min_qty
    return _prev_save_product_v4515(self, data, product_id)


_prev_complete_sale_v4515 = AppService.complete_sale


def _v4515_complete_sale(self: AppService, cart: list[dict], employee_id: int, customer_id: int | None, payment_method: str, discount_amount: float = 0, note: str = '', user_id: int | None = None, discount_type: str = 'amount') -> str:
    if not cart:
        raise ValueError('لا يمكن حفظ فاتورة فارغة. أضف منتجاً واحداً على الأقل.')
    for item in cart:
        if not isinstance(item, dict):
            raise ValueError('يوجد سطر غير صالح داخل الفاتورة')
        validation.assert_positive_int(item.get('product_id'), 'المنتج')
        validation.assert_positive_int(item.get('quantity'), 'الكمية')
    # Recalculate once using the shared Decimal function before persistence. This
    # guarantees the intended order: subtotal -> discount -> tax -> total.
    # The persisted implementation also recalculates from DB prices, so this is a
    # fast validation layer rather than a second inventory update.
    finance.calculate_invoice_totals(cart, discount_value=discount_amount, discount_type=discount_type, tax_percent=self.get_settings().get('tax_percent', 0))
    return _prev_complete_sale_v4515(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type)


_prev_suspend_sale_v4515 = AppService.suspend_sale


def _v4515_suspend_sale(self: AppService, cart: list[dict], employee_id: int | None, customer_id: int | None, payment_method: str, discount_amount: float, note: str = '', user_id: int | None = None) -> str:
    if not cart:
        raise ValueError('لا يمكن تعليق فاتورة فارغة')
    return _prev_suspend_sale_v4515(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id)


def _v4515_quality_health(self: AppService) -> dict[str, Any]:
    try:
        qss_ok = True
        for path in (PROJECT_ROOT / 'assets').glob('*.qss'):
            text = path.read_text(encoding='utf-8', errors='replace')
            if 'QlineEdit' in text or 'Qlineedit' in text or 'QLineedit' in text:
                qss_ok = False
                break
        return {
            'version': 'v45.15',
            'portable_database_path': str(_dbcore.DB_FILE),
            'negative_product_quantity_blocked': True,
            'empty_invoice_blocked': True,
            'invoice_tax_order': 'subtotal -> discount -> tax -> total',
            'product_search': 'LIKE %term% ESCAPE backslash',
            'password_hashing': 'PBKDF2-SHA256 via services.domain.auth_service.save_user',
            'qss_line_edit_selectors_ok': qss_ok,
        }
    except Exception as exc:
        log_exception(exc, 'V45.15 health')
        return {'version': 'v45.15', 'error': str(exc)}


AppService.list_products = _v4515_list_products
AppService.save_product = _v4515_save_product
AppService.complete_sale = _v4515_complete_sale
AppService.suspend_sale = _v4515_suspend_sale
AppService.final_quality_health = _v4515_quality_health

log_message('V45.15 final quality fixes patch loaded', 'info')
