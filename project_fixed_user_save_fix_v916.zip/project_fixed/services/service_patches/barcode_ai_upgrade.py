from __future__ import annotations

import base64
import html
import io
import math
from datetime import date, timedelta
from pathlib import Path
from typing import Any

from services.app_core import AppService
from services.core_common import money, now_text
from services.error_logger import log_exception


def _active_col(self: AppService) -> str:
    cols = [r[1] for r in self.db.conn.execute('PRAGMA table_info(products)').fetchall()]
    return 'active' if 'active' in cols else ('is_active' if 'is_active' in cols else '1')


def _product_active_where(self: AppService, alias: str = 'p') -> str:
    col = _active_col(self)
    if col == '1':
        return '1=1'
    return f'COALESCE({alias}.{col},1)=1'


def _make_qr_data_uri(text: str) -> str:
    try:
        import qrcode
        img = qrcode.make(str(text or ''))
        buf = io.BytesIO()
        img.save(buf, format='PNG')
        return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode('ascii')
    except Exception as exc:
        log_exception(exc, 'advanced barcode qr generation')
        return ''


def _make_datamatrix_uri(text: str) -> str:
    """Generate DataMatrix when optional pylibdmtx is available; fallback to QR image."""
    try:
        from pylibdmtx.pylibdmtx import encode  # type: ignore
        from PIL import Image  # type: ignore
        encoded = encode(str(text or '').encode('utf-8'))
        img = Image.frombytes('RGB', (encoded.width, encoded.height), encoded.pixels)
        buf = io.BytesIO()
        img.save(buf, format='PNG')
        return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode('ascii')
    except Exception:
        return _make_qr_data_uri(text)


def _invoice_qr_payload(self: AppService, invoice_no: str) -> str:
    invoice_no = str(invoice_no or '').strip()
    if not invoice_no:
        raise ValueError('اكتب رقم الفاتورة أولاً')
    row = self.db.one('SELECT * FROM sales WHERE invoice_no=? LIMIT 1', (invoice_no,))
    if not row:
        raise ValueError('الفاتورة غير موجودة')
    try:
        settings = self.get_settings()
    except Exception:
        settings = {}
    company = settings.get('company_name') or 'Max Sales'
    return f"MAXSALES|{company}|INV:{row['invoice_no']}|DATE:{row['created_at']}|TOTAL:{row['total']}|TAX:{row['tax_amount'] if 'tax_amount' in row.keys() else 0}"


def _invoice_qr_data_uri(self: AppService, invoice_no: str) -> str:
    return _make_qr_data_uri(self.invoice_qr_payload(invoice_no))


def _barcode_label_rows(self: AppService, term: str = '', limit: int = 300) -> list[dict[str, Any]]:
    active = _product_active_where(self, 'p')
    params: list[Any] = []
    where = [active]
    if term:
        like = f'%{term.strip()}%'
        where.append('(p.name LIKE ? OR p.barcode LIKE ? OR p.category LIKE ?)')
        params.extend([like, like, like])
    params.append(max(1, min(int(limit or 300), 1000)))
    rows = self.db.all(f'''SELECT p.id, p.name, p.barcode, p.category, p.sale_price, p.quantity
        FROM products p WHERE {' AND '.join(where)} ORDER BY p.name LIMIT ?''', params)
    out = []
    for r in rows:
        code = (r['barcode'] or '').strip() if 'barcode' in r.keys() else ''
        if not code:
            code = f"P{int(r['id']):08d}"
        out.append(dict(id=r['id'], name=r['name'], barcode=code, category=r['category'] if 'category' in r.keys() else '', sale_price=r['sale_price'], quantity=r['quantity']))
    return out


def _barcode_scan_lookup(self: AppService, code: str) -> dict | None:
    text = str(code or '').strip()
    if not text:
        return None
    row = self.db.one('SELECT * FROM products WHERE barcode=? AND active=1 LIMIT 1', (text,))
    if not row:
        row = self.db.one('SELECT * FROM products WHERE barcode=? LIMIT 1', (text,))
    return dict(row) if row else None


def _barcode_labels_html(self: AppService, term: str = '', label_type: str = 'qr', copies: int = 1) -> Path:
    rows = self.barcode_label_rows(term)
    copies = max(1, min(int(copies or 1), 20))
    label_type = (label_type or 'qr').lower()
    out_dir = Path('exports') / 'barcode_labels'
    out_dir.mkdir(parents=True, exist_ok=True)
    parts = []
    for row in rows:
        payload = f"MAXSALES|PRODUCT:{row['id']}|BARCODE:{row['barcode']}|NAME:{row['name']}|PRICE:{row['sale_price']}"
        img = _make_datamatrix_uri(payload if label_type == 'datamatrix' else row['barcode']) if label_type == 'datamatrix' else _make_qr_data_uri(row['barcode'])
        for _ in range(copies):
            parts.append(f"""
            <div class='label'>
              <div class='name'>{html.escape(str(row['name']))}</div>
              <img src='{img}' alt='barcode'>
              <div class='code'>{html.escape(str(row['barcode']))}</div>
              <div class='price'>{html.escape(money(row['sale_price']))}</div>
            </div>""")
    kind = 'datamatrix' if label_type == 'datamatrix' else 'qr'
    body = '\n'.join(parts) or "<p>لا توجد منتجات مطابقة.</p>"
    html_doc = f"""<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'>
    <title>ملصقات باركود</title>
    <style>
    @page{{size:A4;margin:8mm}} body{{font-family:Tahoma,Arial;background:#fff;color:#111;margin:0}}
    .toolbar{{margin:8px 0 14px;text-align:center}} button{{padding:9px 18px;border:0;border-radius:8px;background:#0f4c81;color:white;font-weight:bold}}
    .grid{{display:grid;grid-template-columns:repeat(3, 1fr);gap:7mm}}
    .label{{border:1px solid #111;border-radius:8px;min-height:38mm;padding:5mm;text-align:center;break-inside:avoid}}
    .label img{{width:27mm;height:27mm;object-fit:contain}} .name{{font-weight:800;font-size:13px;min-height:34px}}
    .code{{font-family:monospace;letter-spacing:1px;margin-top:3px}} .price{{font-weight:900;color:#0f4c81;margin-top:3px}}
    @media print{{.toolbar{{display:none}}}}
    </style></head><body><div class='toolbar'><button onclick='window.print()'>طباعة مباشرة</button></div>
    <h2 style='text-align:center'>ملصقات {kind.upper()} - Max Sales</h2><div class='grid'>{body}</div></body></html>"""
    path = out_dir / f'barcode_labels_{kind}_{date.today().isoformat()}.html'
    path.write_text(html_doc, encoding='utf-8')
    return path


def _print_barcode_labels_direct(self: AppService, term: str = '', label_type: str = 'qr', copies: int = 1) -> Path:
    return self.barcode_labels_html(term, label_type, copies)


def _ai_sales_forecast(self: AppService, days: int = 90) -> list[dict[str, Any]]:
    days = max(14, min(int(days or 90), 365))
    active = _product_active_where(self, 'p')
    cutoff = (date.today() - timedelta(days=days)).isoformat()
    rows = self.db.all(f'''SELECT p.id, p.name, p.category, p.quantity, p.min_quantity, p.sale_price, p.cost_price,
            COALESCE(SUM(si.quantity),0) sold_qty, COALESCE(SUM(si.line_total),0) sales_amount
        FROM products p
        LEFT JOIN sale_items si ON si.product_id=p.id
        LEFT JOIN sales s ON s.id=si.sale_id AND s.status='completed' AND date(s.created_at)>=date(?)
        WHERE {active}
        GROUP BY p.id ORDER BY sold_qty DESC LIMIT 200''', (cutoff,))
    out = []
    for r in rows:
        sold = float(r['sold_qty'] or 0)
        avg = sold / days
        forecast_30 = int(math.ceil(avg * 30))
        stock = float(r['quantity'] or 0)
        suggested = max(int(math.ceil(forecast_30 + float(r['min_quantity'] or 0) - stock)), 0)
        risk = 'مرتفع' if suggested > 0 and stock <= float(r['min_quantity'] or 0) else ('متوسط' if suggested > 0 else 'مستقر')
        out.append(dict(product_id=r['id'], product_name=r['name'], category=r['category'] or '', current_stock=stock, sold_qty=sold, daily_avg=round(avg, 2), forecast_30_days=forecast_30, suggested_purchase_qty=suggested, risk=risk, sale_price=r['sale_price'], cost_price=r['cost_price']))
    return out


def _ai_price_suggestions(self: AppService, competitor_margin_percent: float = 10.0) -> list[dict[str, Any]]:
    active = _product_active_where(self, 'p')
    rows = self.db.all(f'''SELECT p.id, p.name, p.category, p.cost_price, p.sale_price,
            COALESCE(SUM(si.quantity),0) sold_qty
        FROM products p LEFT JOIN sale_items si ON si.product_id=p.id
        WHERE {active} GROUP BY p.id ORDER BY sold_qty DESC LIMIT 200''')
    out = []
    margin = max(0, min(float(competitor_margin_percent or 10), 200))
    for r in rows:
        cost = float(r['cost_price'] or 0)
        sale = float(r['sale_price'] or 0)
        if cost <= 0:
            suggestion = sale
            note = 'لا يوجد سعر شراء موثوق، راجع بيانات المنتج.'
        else:
            min_profitable = cost * 1.05
            market_like = cost * (1 + margin / 100.0)
            suggestion = max(min_profitable, market_like)
            if sale < cost:
                note = 'السعر الحالي أقل من التكلفة - خطر خسارة.'
            elif sale < min_profitable:
                note = 'هامش الربح ضعيف.'
            elif sale > suggestion * 1.35:
                note = 'السعر مرتفع؛ راقب المنافسة والطلب.'
            else:
                note = 'السعر مقبول حالياً.'
        out.append(dict(product_id=r['id'], product_name=r['name'], cost_price=cost, current_price=sale, suggested_price=round(suggestion, 0), sold_qty=r['sold_qty'], note=note))
    return out


def _ai_faq_answer(self: AppService, question: str) -> str:
    q = str(question or '').strip().lower()
    if not q:
        return 'اكتب سؤالك أولاً. يمكنك السؤال عن المبيعات، الأرباح، المنتجات الراكدة، الشراء، الأسعار، أو طريقة استخدام النظام.'
    if any(w in q for w in ['بيع', 'فاتورة', 'كاشير']):
        return 'لإصدار فاتورة: افتح البيع أو كاشير لمس، امسح الباركود أو اختر المنتج، راجع الكمية والسعر، ثم اختر طريقة الدفع واضغط إتمام البيع.'
    if any(w in q for w in ['باركود', 'قارئ', 'usb', 'bluetooth']):
        return 'قارئ الباركود USB/Bluetooth يعمل غالباً كلوحة مفاتيح: ضع المؤشر في خانة الباركود ثم امسح الكود واضغط Enter أو يرسله القارئ تلقائياً.'
    if any(w in q for w in ['ربح', 'ارباح', 'أرباح']):
        rows = self.ai_price_suggestions()[:3]
        return 'راجع تقارير الأرباح وسعر الشراء لكل منتج. أهم منتجات تحتاج متابعة سعرية:\n' + '\n'.join(f"- {r['product_name']}: {r['note']}" for r in rows)
    if any(w in q for w in ['شراء', 'مخزون', 'ناقص']):
        rows = [r for r in self.ai_sales_forecast() if r['suggested_purchase_qty'] > 0][:8]
        return 'اقتراحات الشراء الحالية:\n' + ('\n'.join(f"- {r['product_name']}: اشترِ تقريباً {r['suggested_purchase_qty']}" for r in rows) if rows else 'لا توجد احتياجات شراء واضحة حالياً.')
    if any(w in q for w in ['راكد', 'راكدة', 'تصريف']):
        stale = self.ai_notes_analysis('منتجات راكدة وتصريف عروض')
        return stale
    return 'المساعد الذكي يستطيع مساعدتك في: توقع المبيعات، اقتراح الشراء، مراجعة الأسعار، شرح استخدام الباركود، وتحليل الملاحظات النصية.'


def _ai_notes_analysis(self: AppService, notes: str) -> str:
    text = str(notes or '').strip()
    ai = self.ai_sales_forecast(90)
    stale = [r for r in ai if float(r.get('sold_qty') or 0) <= 0 and float(r.get('current_stock') or 0) > 0][:10]
    needs = [r for r in ai if int(r.get('suggested_purchase_qty') or 0) > 0][:10]
    parts = []
    if text:
        parts.append('تحليل الملاحظة:')
        low = text.lower()
        if any(w in low for w in ['زبون', 'عميل', 'شكوى']):
            parts.append('• توجد إشارة لتجربة العملاء؛ راجع الفواتير المرتبطة والمنتجات المتكررة في الشكاوى.')
        if any(w in low for w in ['سعر', 'غالي', 'منافس']):
            parts.append('• توجد إشارة للأسعار؛ راجع تبويب اقتراح الأسعار وقارن هامش الربح بالمنافسة.')
        if any(w in low for w in ['ناقص', 'نفد', 'مخزون']):
            parts.append('• توجد إشارة للمخزون؛ راجع المنتجات المقترح شراؤها أدناه.')
    if needs:
        parts.append('\nمنتجات تحتاج شراء قريباً:')
        parts.extend(f"• {r['product_name']}: {r['suggested_purchase_qty']} قطعة تقريباً" for r in needs[:5])
    if stale:
        parts.append('\nمنتجات راكدة مقترح تصريفها بعروض:')
        parts.extend(f"• {r['product_name']} | مخزون {r['current_stock']}" for r in stale[:5])
    if not parts:
        parts.append('لا توجد مؤشرات قوية من النص الحالي. أضف ملاحظة أو شغّل توقع المبيعات للحصول على تحليل أفضل.')
    return '\n'.join(parts)


# Replace/upgrade existing AI entry points used by older pages.
def _advanced_ai_analysis_new(self: AppService, days: int = 90) -> dict:
    forecasts = self.ai_sales_forecast(days)
    purchase = [r for r in forecasts if int(r.get('suggested_purchase_qty') or 0) > 0]
    stagnant = [r for r in forecasts if float(r.get('sold_qty') or 0) <= 0 and float(r.get('current_stock') or 0) > 0]
    offers = [{'product_id': r['product_id'], 'product_name': r['product_name'], 'suggestion': 'خصم 10-20% أو عرض كمية لتصريف المنتج الراكد.'} for r in stagnant[:20]]
    return {'forecasts': forecasts, 'purchase_suggestions': purchase, 'stagnant_products': stagnant, 'offer_suggestions': offers, 'price_suggestions': self.ai_price_suggestions()}


def _ask_ai_assistant_new(self: AppService, question: str) -> str:
    q = str(question or '').lower()
    if 'سعر' in q or 'منافس' in q:
        rows = self.ai_price_suggestions()[:8]
        return 'اقتراحات الأسعار:\n' + '\n'.join(f"- {r['product_name']}: الحالي {money(r['current_price'])} | المقترح {money(r['suggested_price'])} | {r['note']}" for r in rows)
    return self.ai_faq_answer(question)


AppService.invoice_qr_payload = _invoice_qr_payload
AppService.invoice_qr_data_uri = _invoice_qr_data_uri
AppService.barcode_label_rows = _barcode_label_rows
AppService.barcode_scan_lookup = _barcode_scan_lookup
AppService.barcode_labels_html = _barcode_labels_html
AppService.print_barcode_labels_direct = _print_barcode_labels_direct
AppService.ai_sales_forecast = _ai_sales_forecast
AppService.ai_price_suggestions = _ai_price_suggestions
AppService.ai_faq_answer = _ai_faq_answer
AppService.ai_notes_analysis = _ai_notes_analysis
AppService.advanced_ai_analysis = _advanced_ai_analysis_new
AppService.ask_ai_assistant_deep = _ask_ai_assistant_new
