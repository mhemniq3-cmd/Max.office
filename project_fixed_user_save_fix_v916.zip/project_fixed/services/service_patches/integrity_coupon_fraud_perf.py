from __future__ import annotations

import csv
import hashlib
import hmac
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

from services.app_core import AppService
from database import now_text
from services.error_logger import log_exception

_ORIG_INIT = AppService.__init__
_ORIG_SAVE_FRAUD_RULE = getattr(AppService, 'save_fraud_rule', None)
_ORIG_FRAUD_SCAN_NOW = getattr(AppService, 'fraud_scan_now', None)
_ORIG_SAVE_COUPON = getattr(AppService, 'save_coupon', None)
_ORIG_VALIDATE_COUPON = getattr(AppService, 'validate_coupon', None)
_ORIG_MARK_COUPON_USED = getattr(AppService, 'mark_coupon_used', None)
_ORIG_RECORD_AUDIT_V2 = getattr(AppService, 'record_audit_v2', None)

LEGACY_COUPON_SECRET = os.environ.get('MAX_SALES_COUPON_SECRET', 'MaxSalesCouponPepper@2026')


def _rowdict(row: Any) -> dict:
    if not row:
        return {}
    try:
        return dict(row)
    except Exception:
        try:
            return {k: row[k] for k in row.keys()}
        except Exception:
            return {}


def _json(value: Any) -> str:
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    except Exception:
        return json.dumps(str(value), ensure_ascii=False)


def _ensure_col(conn, table: str, col: str, ddl: str) -> None:
    try:
        cols = [r[1] for r in conn.execute(f'PRAGMA table_info({table})').fetchall()]
        if col not in cols:
            conn.execute(f'ALTER TABLE {table} ADD COLUMN {col} {ddl}')
    except Exception:
        pass


def _system_salt(self: AppService) -> str:
    conn = self.db.conn
    conn.execute('CREATE TABLE IF NOT EXISTS secure_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL)')
    row = conn.execute("SELECT value FROM secure_settings WHERE key='coupon_hash_salt'").fetchone()
    if row and row[0]:
        return str(row[0])
    salt = os.urandom(32).hex()
    conn.execute('INSERT OR REPLACE INTO secure_settings(key, value, updated_at) VALUES (?, ?, ?)', ('coupon_hash_salt', salt, now_text()))
    conn.commit()
    return salt


def _coupon_hash(self: AppService, code: str) -> str:
    normalized = str(code or '').strip().upper()
    salt = _system_salt(self)
    return hashlib.sha256((salt + '|' + normalized).encode('utf-8')).hexdigest()


def _legacy_coupon_hash(code: str) -> str:
    normalized = str(code or '').strip().upper()
    return hashlib.sha256((normalized + '|' + LEGACY_COUPON_SECRET).encode('utf-8')).hexdigest()


def _mask_code(code: str) -> str:
    code = str(code or '').strip().upper()
    if len(code) <= 4:
        return '****'
    return f'{code[:2]}***{code[-2:]}'


def _audit_payload(table_name: str, record_id: Any, action: str, old_values: Any, new_values: Any, user_id: Any, username: str, ip: str, reason: str, timestamp: str, prev_hash: str) -> str:
    payload = {
        'table_name': str(table_name or ''),
        'record_id': record_id,
        'action': str(action or ''),
        'old_values': old_values,
        'new_values': new_values,
        'user_id': user_id,
        'username': str(username or ''),
        'ip': str(ip or ''),
        'reason': str(reason or ''),
        'timestamp': str(timestamp or ''),
        'prev_hash': str(prev_hash or ''),
    }
    return _json(payload)


def _chain_hash(payload: str) -> str:
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()


def _username(self: AppService, user_id=None) -> str:
    try:
        if user_id:
            row = self.db.one('SELECT username FROM users WHERE id=?', (user_id,))
            if row:
                return str(row['username'])
        cu = getattr(self, 'current_user', None)
        if isinstance(cu, dict):
            return str(cu.get('username') or '')
    except Exception:
        pass
    return ''


def _user_id(self: AppService, user_id=None):
    if user_id is not None:
        return user_id
    try:
        cu = getattr(self, 'current_user', None)
        if isinstance(cu, dict):
            return cu.get('id')
        return getattr(self, 'current_user_id', None)
    except Exception:
        return None


def _ensure_schema(self: AppService) -> None:
    conn = self.db.conn
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS secure_settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sale_coupon_types (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sale_id INTEGER NOT NULL,
            coupon_id INTEGER,
            coupon_type TEXT NOT NULL,
            code_hash TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(sale_id, coupon_type)
        );
        CREATE TABLE IF NOT EXISTS coupon_performance_cache (
            coupon_id INTEGER PRIMARY KEY,
            code_mask TEXT,
            type TEXT,
            used_count INTEGER NOT NULL DEFAULT 0,
            total_discount REAL NOT NULL DEFAULT 0,
            sales_total REAL NOT NULL DEFAULT 0,
            discount_to_sales_pct REAL NOT NULL DEFAULT 0,
            new_customers INTEGER NOT NULL DEFAULT 0,
            refreshed_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS fraud_monthly_summary (
            period TEXT PRIMARY KEY,
            total_alerts INTEGER NOT NULL DEFAULT 0,
            open_alerts INTEGER NOT NULL DEFAULT 0,
            high_alerts INTEGER NOT NULL DEFAULT 0,
            closed_alerts INTEGER NOT NULL DEFAULT 0,
            refreshed_at TEXT NOT NULL
        );
    ''')
    for col, ddl in [
        ('prev_hash', 'TEXT'),
        ('chain_hash', 'TEXT'),
        ('signature_payload', 'TEXT'),
    ]:
        _ensure_col(conn, 'audit_logs', col, ddl)
    for col, ddl in [
        ('code_hash_version', 'TEXT NOT NULL DEFAULT \'sha256-salted-v2\''),
    ]:
        _ensure_col(conn, 'coupons', col, ddl)
    # Optional hardened coupon columns may already exist from 4.6; keep them here for safety.
    for col, ddl in [
        ('code_hash', 'TEXT'), ('code_mask', 'TEXT'), ('starts_at', 'TEXT'),
        ('product_id', 'INTEGER'), ('category', 'TEXT'), ('customer_id', 'INTEGER'),
        ('max_uses_per_customer', 'INTEGER NOT NULL DEFAULT 1'), ('requires_manager', 'INTEGER NOT NULL DEFAULT 0'),
        ('last_used_at', 'TEXT')
    ]:
        _ensure_col(conn, 'coupons', col, ddl)
    for sql in [
        'CREATE UNIQUE INDEX IF NOT EXISTS ux_sale_coupon_type_v451747 ON sale_coupon_types(sale_id, coupon_type)',
        'CREATE INDEX IF NOT EXISTS idx_coupon_usages_coupon_sale_v451747 ON coupon_usages(coupon_id, sale_id, customer_id, used_at)',
        'CREATE INDEX IF NOT EXISTS idx_fraud_alerts_month_v451747 ON fraud_alerts(created_at, status, severity)',
        'CREATE INDEX IF NOT EXISTS idx_audit_logs_chain_v451747 ON audit_logs(id, prev_hash, chain_hash)',
        'CREATE INDEX IF NOT EXISTS idx_fraud_rules_updated_v451747 ON fraud_rules(updated_at, active)',
    ]:
        try:
            conn.execute(sql)
        except Exception:
            pass
    conn.commit()


def _reload_fraud_rules_cache(self: AppService, force: bool = False) -> dict[str, dict]:
    try:
        row = self.db.one('SELECT COALESCE(MAX(updated_at), \'\') m, COUNT(*) c FROM fraud_rules')
        version = f"{row['m']}:{row['c']}" if row else ''
        if force or getattr(self, '_fraud_rules_cache_version', None) != version:
            rules = self.db.all('SELECT * FROM fraud_rules WHERE active=1 ORDER BY rule_code')
            self._fraud_rules_cache = {r['rule_code']: dict(r) for r in rules}
            self._fraud_rules_cache_version = version
        return getattr(self, '_fraud_rules_cache', {}) or {}
    except Exception as exc:
        log_exception(exc, 'reload fraud rules cache')
        return {}


def _save_fraud_rule(self: AppService, *args, **kwargs):
    if _ORIG_SAVE_FRAUD_RULE:
        result = _ORIG_SAVE_FRAUD_RULE(self, *args, **kwargs)
    else:
        raise AttributeError('save_fraud_rule is not available')
    _reload_fraud_rules_cache(self, True)
    return result


def _fraud_scan_now(self: AppService):
    # Keep cache fresh before every scan; this avoids restart after editing rules.
    _reload_fraud_rules_cache(self, False)
    if _ORIG_FRAUD_SCAN_NOW:
        return _ORIG_FRAUD_SCAN_NOW(self)
    return []


def _save_coupon(self: AppService, code: str, coupon_type: str, value: float, *args, **kwargs):
    # Re-implement the critical security part with SHA-256 + random system salt.
    self.require_permission('can_discount', action='إدارة الكوبونات')
    raw = str(code or '').strip().upper()
    if not raw:
        raise ValueError('كود القسيمة مطلوب')
    code_hash = _coupon_hash(self, raw)
    legacy_hash = _legacy_coupon_hash(raw)
    mask = _mask_code(raw)
    # Let existing method create/update columns, then normalize hash to the stronger version.
    if _ORIG_SAVE_COUPON:
        try:
            res = _ORIG_SAVE_COUPON(self, raw, coupon_type, value, *args, **kwargs)
        except TypeError:
            res = _ORIG_SAVE_COUPON(self, raw, coupon_type, value)
    else:
        res = None
    row = self.db.one('SELECT id FROM coupons WHERE code_hash IN (?, ?) OR code=? OR code_mask=? ORDER BY id DESC LIMIT 1', (code_hash, legacy_hash, raw, mask))
    if row:
        self.db.execute('UPDATE coupons SET code=?, code_hash=?, code_mask=?, code_hash_version=? WHERE id=?', (mask, code_hash, mask, 'sha256-salted-v2', row['id']))
    return res


def _find_coupon_by_code(self: AppService, code: str):
    raw = str(code or '').strip().upper()
    new_hash = _coupon_hash(self, raw)
    old_hash = _legacy_coupon_hash(raw)
    return self.db.one('SELECT * FROM coupons WHERE (code_hash=? OR code_hash=? OR code=?) AND active=1 ORDER BY id DESC LIMIT 1', (new_hash, old_hash, raw))


def _validate_coupon(self: AppService, code: str, purchase_total: float, customer_id: int | None = None, product_ids: list[int] | None = None, categories: list[str] | None = None, sale_id: int | None = None):
    row = _find_coupon_by_code(self, code)
    if not row:
        raise ValueError('القسيمة غير موجودة أو غير نشطة')
    # Delegate the detailed validation to previous implementation when possible, but ensure it can find legacy rows.
    try:
        if _ORIG_VALIDATE_COUPON:
            result = _ORIG_VALIDATE_COUPON(self, code, purchase_total, customer_id, product_ids, categories, sale_id)
        else:
            result = None
    except ValueError:
        result = None
    if result is None:
        today = datetime.now().strftime('%Y-%m-%d')
        if row['starts_at'] and str(row['starts_at'])[:10] > today:
            raise ValueError('القسيمة لم تبدأ بعد')
        if row['expiry_date'] and str(row['expiry_date'])[:10] < today:
            raise ValueError('القسيمة منتهية الصلاحية')
        total = float(purchase_total or 0)
        if float(row['min_purchase'] or 0) > total:
            raise ValueError('قيمة الشراء أقل من الحد الأدنى للقسيمة')
        if int(row['max_uses'] or 0) > 0 and int(row['used_count'] or 0) >= int(row['max_uses'] or 0):
            raise ValueError('تم استهلاك الحد الأقصى لاستخدام القسيمة')
        if row['customer_id'] and customer_id and int(row['customer_id']) != int(customer_id):
            raise ValueError('هذه القسيمة مخصصة لعميل آخر')
        if row['product_id'] and product_ids is not None and int(row['product_id']) not in [int(x) for x in product_ids]:
            raise ValueError('هذه القسيمة لا تنطبق على منتجات هذه الفاتورة')
        if row['category'] and categories is not None and str(row['category']).strip() not in {str(c or '').strip() for c in categories}:
            raise ValueError('هذه القسيمة لا تنطبق على أصناف هذه الفاتورة')
        typ = str(row['type'])
        val = float(row['value'] or 0)
        discount = total * val / 100.0 if typ == 'percent' else (min(val, total) if typ == 'amount' else 0.0)
        result = {'id': row['id'], 'code': row['code_mask'] or _mask_code(code), 'type': typ, 'discount': discount, 'final_total': max(total - discount, 0.0), 'requires_manager': int(row['requires_manager'] or 0)}
    if sale_id:
        exists = self.db.one('SELECT id FROM sale_coupon_types WHERE sale_id=? AND coupon_type=?', (int(sale_id), str(row['type'])))
        if exists:
            raise ValueError('لا يمكن دمج قسائم من نفس الفئة في الفاتورة')
    return result


def _validate_coupon_batch(self: AppService, codes: list[str], purchase_total: float, customer_id: int | None = None, product_ids: list[int] | None = None, categories: list[str] | None = None, sale_id: int | None = None):
    seen_types: set[str] = set()
    results = []
    current_total = float(purchase_total or 0)
    for code in codes:
        row = _find_coupon_by_code(self, code)
        if not row:
            raise ValueError(f'القسيمة غير موجودة: {code}')
        typ = str(row['type'])
        if typ in seen_types:
            raise ValueError('لا يمكن دمج قسائم من نفس الفئة')
        seen_types.add(typ)
        res = _validate_coupon(self, code, current_total, customer_id, product_ids, categories, sale_id)
        results.append(res)
        current_total = float(res.get('final_total', current_total))
    return {'coupons': results, 'final_total': current_total, 'total_discount': max(float(purchase_total or 0) - current_total, 0.0)}


def _mark_coupon_used(self: AppService, code: str, sale_id: int | None = None, invoice_no: str = '', customer_id: int | None = None, amount: float = 0, user_id: int | None = None):
    row = _find_coupon_by_code(self, code)
    if not row:
        raise ValueError('القسيمة غير موجودة')
    if sale_id:
        existing = self.db.one('SELECT id FROM sale_coupon_types WHERE sale_id=? AND coupon_type=?', (int(sale_id), str(row['type'])))
        if existing:
            raise ValueError('لا يمكن دمج قسائم من نفس الفئة')
    used_by_previous = False
    if _ORIG_MARK_COUPON_USED:
        try:
            _ORIG_MARK_COUPON_USED(self, code, sale_id, invoice_no, customer_id, amount, user_id)
            used_by_previous = True
        except TypeError:
            try:
                _ORIG_MARK_COUPON_USED(self, code, sale_id, invoice_no, customer_id, amount)
                used_by_previous = True
            except ValueError:
                used_by_previous = False
        except ValueError:
            used_by_previous = False
    if not used_by_previous:
        with self.db.conn:
            self.db.conn.execute('INSERT OR IGNORE INTO coupon_usages(coupon_id, code_hash, customer_id, sale_id, invoice_no, amount, used_at, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', (row['id'], row['code_hash'], customer_id, sale_id, invoice_no, float(amount or 0), now_text(), user_id))
            self.db.conn.execute('UPDATE coupons SET used_count=(SELECT COUNT(*) FROM coupon_usages WHERE coupon_id=?), last_used_at=? WHERE id=?', (row['id'], now_text(), row['id']))
    if sale_id:
        self.db.execute('INSERT OR IGNORE INTO sale_coupon_types(sale_id, coupon_id, coupon_type, code_hash, created_at) VALUES (?, ?, ?, ?, ?)', (int(sale_id), row['id'], str(row['type']), row['code_hash'], now_text()))
    try:
        self.refresh_coupon_performance_cache(row['id'])
    except Exception:
        pass


def _record_audit_v2(self: AppService, table_name: str, record_id: int | None, action: str, old_values=None, new_values=None, user_id=None, reason: str = '', ip: str = 'local') -> None:
    try:
        uid = _user_id(self, user_id)
        username = _username(self, uid)
        timestamp = now_text()
        prev = self.db.one('SELECT chain_hash FROM audit_logs WHERE chain_hash IS NOT NULL AND chain_hash<>\'\' ORDER BY id DESC LIMIT 1')
        prev_hash = prev['chain_hash'] if prev else 'GENESIS'
        old_json = _json(old_values)
        new_json = _json(new_values)
        payload = _audit_payload(table_name, record_id, action, old_json, new_json, uid, username, ip, reason, timestamp, prev_hash)
        chash = _chain_hash(payload)
        self.db.execute('''
            INSERT INTO audit_logs(table_name, record_id, action, old_values, new_values, user_id, username, ip, reason, timestamp, prev_hash, chain_hash, signature_payload)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (str(table_name or ''), record_id, str(action or ''), old_json, new_json, uid, username, str(ip or 'local')[:120], str(reason or '')[:500], timestamp, prev_hash, chash, payload))
    except Exception as exc:
        log_exception(exc, 'record chained audit v2')
        if _ORIG_RECORD_AUDIT_V2:
            try:
                _ORIG_RECORD_AUDIT_V2(self, table_name, record_id, action, old_values, new_values, user_id, reason, ip)
            except Exception:
                pass


def _verify_audit_chain(self: AppService, limit: int = 10000) -> dict:
    self.require_permission('can_audit', action='فحص سلامة سجل التدقيق')
    rows = self.db.all('SELECT id, table_name, record_id, action, old_values, new_values, user_id, username, ip, reason, timestamp, prev_hash, chain_hash, signature_payload FROM audit_logs WHERE chain_hash IS NOT NULL AND chain_hash<>\'\' ORDER BY id ASC LIMIT ?', (int(limit or 10000),))
    previous = 'GENESIS'
    checked = 0
    errors = []
    for r in rows:
        d = _rowdict(r)
        if d.get('prev_hash') != previous:
            errors.append({'id': d.get('id'), 'error': 'broken_previous_hash', 'expected': previous, 'actual': d.get('prev_hash')})
            break
        payload = d.get('signature_payload') or _audit_payload(d.get('table_name'), d.get('record_id'), d.get('action'), d.get('old_values'), d.get('new_values'), d.get('user_id'), d.get('username'), d.get('ip'), d.get('reason'), d.get('timestamp'), d.get('prev_hash'))
        expected = _chain_hash(payload)
        if not hmac.compare_digest(str(expected), str(d.get('chain_hash'))):
            errors.append({'id': d.get('id'), 'error': 'invalid_chain_hash'})
            break
        previous = str(d.get('chain_hash'))
        checked += 1
    return {'ok': not errors, 'checked': checked, 'errors': errors, 'last_hash': previous}


def _refresh_coupon_performance_cache(self: AppService, coupon_id: int | None = None):
    where = 'WHERE c.id=?' if coupon_id else ''
    params = (coupon_id,) if coupon_id else ()
    rows = self.db.all(f'''
        SELECT c.id coupon_id, COALESCE(c.code_mask, c.code) code_mask, c.type,
               COUNT(u.id) used_count,
               COALESCE(SUM(u.amount),0) total_discount,
               COALESCE(SUM(s.total),0) sales_total,
               COUNT(DISTINCT CASE WHEN first_sale.first_sale_id = s.id THEN s.customer_id END) new_customers
        FROM coupons c
        LEFT JOIN coupon_usages u ON u.coupon_id=c.id
        LEFT JOIN sales s ON s.id=u.sale_id
        LEFT JOIN (
            SELECT customer_id, MIN(id) first_sale_id FROM sales WHERE customer_id IS NOT NULL GROUP BY customer_id
        ) first_sale ON first_sale.customer_id=s.customer_id
        {where}
        GROUP BY c.id, c.code_mask, c.code, c.type
    ''', params)
    with self.db.conn:
        for r in rows:
            sales_total = float(r['sales_total'] or 0)
            total_discount = float(r['total_discount'] or 0)
            pct = (total_discount * 100.0 / sales_total) if sales_total else 0.0
            self.db.conn.execute('''
                INSERT INTO coupon_performance_cache(coupon_id, code_mask, type, used_count, total_discount, sales_total, discount_to_sales_pct, new_customers, refreshed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(coupon_id) DO UPDATE SET code_mask=excluded.code_mask, type=excluded.type, used_count=excluded.used_count, total_discount=excluded.total_discount, sales_total=excluded.sales_total, discount_to_sales_pct=excluded.discount_to_sales_pct, new_customers=excluded.new_customers, refreshed_at=excluded.refreshed_at
            ''', (r['coupon_id'], r['code_mask'], r['type'], int(r['used_count'] or 0), total_discount, sales_total, pct, int(r['new_customers'] or 0), now_text()))


def _coupon_performance_report(self: AppService, refresh: bool = True):
    self.require_permission('can_reports', action='تقرير أداء القسائم')
    if refresh:
        _refresh_coupon_performance_cache(self)
    return self.db.all('SELECT * FROM coupon_performance_cache ORDER BY sales_total DESC, used_count DESC')


def _refresh_fraud_monthly_summary(self: AppService, period: str | None = None):
    # period format YYYY-MM. If omitted, refresh all periods found in fraud_alerts.
    if period:
        periods = [period[:7]]
    else:
        periods = [r['p'] for r in self.db.all("SELECT DISTINCT substr(created_at,1,7) p FROM fraud_alerts WHERE created_at IS NOT NULL ORDER BY p DESC LIMIT 36") if r['p']]
    with self.db.conn:
        for p in periods:
            r = self.db.one('''
                SELECT COUNT(*) total_alerts,
                       SUM(CASE WHEN status='مفتوح' THEN 1 ELSE 0 END) open_alerts,
                       SUM(CASE WHEN severity IN ('عالية','حرجة') THEN 1 ELSE 0 END) high_alerts,
                       SUM(CASE WHEN status='مغلق' THEN 1 ELSE 0 END) closed_alerts
                FROM fraud_alerts WHERE substr(created_at,1,7)=?
            ''', (p,))
            self.db.conn.execute('''
                INSERT INTO fraud_monthly_summary(period, total_alerts, open_alerts, high_alerts, closed_alerts, refreshed_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(period) DO UPDATE SET total_alerts=excluded.total_alerts, open_alerts=excluded.open_alerts, high_alerts=excluded.high_alerts, closed_alerts=excluded.closed_alerts, refreshed_at=excluded.refreshed_at
            ''', (p, int(r['total_alerts'] or 0), int(r['open_alerts'] or 0), int(r['high_alerts'] or 0), int(r['closed_alerts'] or 0), now_text()))


def _fraud_report_fast(self: AppService, start_month: str = '', end_month: str = ''):
    self.require_permission('can_audit', action='تقرير احتيال سريع')
    _refresh_fraud_monthly_summary(self)
    params = []
    where = []
    if start_month:
        where.append('period>=?'); params.append(start_month[:7])
    if end_month:
        where.append('period<=?'); params.append(end_month[:7])
    sql = 'SELECT * FROM fraud_monthly_summary'
    if where:
        sql += ' WHERE ' + ' AND '.join(where)
    sql += ' ORDER BY period DESC'
    return self.db.all(sql, params)


def _clear_analysis_cache(self: AppService):
    # Small explicit cleanup hook for long sessions; keeps behavioral-analysis cache bounded.
    for name in ('_fraud_rules_cache', '_fraud_rules_cache_version'):
        try:
            if hasattr(self, name):
                delattr(self, name)
        except Exception:
            pass
    return True


def _export_coupon_performance_csv(self: AppService, out_path: str | Path | None = None) -> str:
    self.require_permission('can_reports', action='تصدير تقرير القسائم')
    rows = [dict(r) for r in _coupon_performance_report(self, True)]
    root = Path(out_path).expanduser() if out_path else (Path.home() / 'MaxSales_Coupon_Reports')
    if root.suffix.lower() == '.csv':
        path = root; path.parent.mkdir(parents=True, exist_ok=True)
    else:
        root.mkdir(parents=True, exist_ok=True)
        path = root / f'coupon_performance_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    fields = ['coupon_id','code_mask','type','used_count','total_discount','sales_total','discount_to_sales_pct','new_customers','refreshed_at']
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, '') for k in fields})
    return str(path)


def _init(self: AppService, *args, **kwargs):
    _ORIG_INIT(self, *args, **kwargs)
    try:
        _ensure_schema(self)
        _reload_fraud_rules_cache(self, True)
    except Exception as exc:
        log_exception(exc, 'v45.17.4.7 integrity coupon fraud perf schema')


AppService.__init__ = _init
AppService.reload_fraud_rules_cache = _reload_fraud_rules_cache
AppService.save_fraud_rule = _save_fraud_rule
AppService.fraud_scan_now = _fraud_scan_now
AppService.save_coupon = _save_coupon
AppService.validate_coupon = _validate_coupon
AppService.validate_coupon_batch = _validate_coupon_batch
AppService.mark_coupon_used = _mark_coupon_used
AppService.record_audit_v2 = _record_audit_v2
AppService.verify_audit_chain = _verify_audit_chain
AppService.refresh_coupon_performance_cache = _refresh_coupon_performance_cache
AppService.coupon_performance_report = _coupon_performance_report
AppService.export_coupon_performance_csv = _export_coupon_performance_csv
AppService.refresh_fraud_monthly_summary = _refresh_fraud_monthly_summary
AppService.fraud_report_fast = _fraud_report_fast
AppService.clear_analysis_cache = _clear_analysis_cache
