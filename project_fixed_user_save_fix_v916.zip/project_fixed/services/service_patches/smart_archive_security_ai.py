from __future__ import annotations

import json
from datetime import datetime, timedelta

from services.app_core import AppService
from services.core_common import money, now_text, to_float
from services.error_logger import log_exception


def _ensure_v45_schema(db):
    db.conn.executescript('''
        CREATE TABLE IF NOT EXISTS document_archive (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            doc_type TEXT NOT NULL,
            ref_no TEXT NOT NULL,
            title TEXT NOT NULL,
            customer_name TEXT,
            customer_phone TEXT,
            supplier_name TEXT,
            amount REAL NOT NULL DEFAULT 0,
            doc_date TEXT NOT NULL,
            content_text TEXT,
            content_json TEXT,
            file_path TEXT,
            created_by_user_id INTEGER,
            created_at TEXT NOT NULL,
            UNIQUE(doc_type, ref_no)
        );
        CREATE TABLE IF NOT EXISTS security_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            severity TEXT NOT NULL DEFAULT 'medium',
            alert_type TEXT NOT NULL,
            ref_type TEXT,
            ref_no TEXT,
            user_id INTEGER,
            username TEXT,
            details TEXT,
            status TEXT NOT NULL DEFAULT 'open',
            created_at TEXT NOT NULL,
            resolved_at TEXT,
            resolved_by_user_id INTEGER
        );
        CREATE TABLE IF NOT EXISTS owner_report_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_date TEXT NOT NULL UNIQUE,
            summary_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
    ''')
    db.conn.executescript('''
        CREATE INDEX IF NOT EXISTS idx_document_archive_search ON document_archive(ref_no, doc_date, amount, customer_name, customer_phone, supplier_name);
        CREATE INDEX IF NOT EXISTS idx_document_archive_type_date ON document_archive(doc_type, doc_date);
        CREATE INDEX IF NOT EXISTS idx_security_alerts_created ON security_alerts(created_at, severity, status);
        CREATE INDEX IF NOT EXISTS idx_security_alerts_ref ON security_alerts(ref_type, ref_no);
    ''')
    for key, value in {
        'smart_archive_enabled': '1',
        'security_alert_low_price_enabled': '1',
        'security_alert_large_discount_percent': '20',
        'sales_forecast_days': '30',
        'owner_daily_email_enabled': '0',
        'owner_daily_email_to': '',
    }.items():
        db.conn.execute('INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)', (key, value))
    db.conn.commit()


_orig_init_v45 = AppService.__init__


def _v45_init(self: AppService, db):
    _orig_init_v45(self, db)
    _ensure_v45_schema(self.db)


AppService.__init__ = _v45_init


def _current_username(self: AppService, user_id=None):
    try:
        if user_id:
            row = self.db.one('SELECT username FROM users WHERE id=?', (user_id,))
            if row:
                return row['username']
        user_getter = getattr(self, 'current_user', None)
        user = user_getter() if callable(user_getter) else None
        if user:
            return user['username']
    except Exception:
        pass
    return ''


def _v45_log_security_alert(self: AppService, alert_type: str, details: str, severity: str = 'medium', ref_type: str = '', ref_no: str = '', user_id: int | None = None):
    username = _current_username(self, user_id)
    self.db.execute('''
        INSERT INTO security_alerts (severity, alert_type, ref_type, ref_no, user_id, username, details, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'open', ?)
    ''', (severity, alert_type, ref_type, ref_no, user_id, username, details, now_text()))
    try:
        self.log(f'تنبيه أمني: {alert_type}', details, user_id, username)
    except Exception as exc:
        log_exception(exc)


AppService.log_security_alert = _v45_log_security_alert


def _v45_archive_document(self: AppService, doc_type: str, ref_no: str, title: str, amount: float = 0, doc_date: str | None = None, content_text: str = '', content_json: dict | list | None = None, customer_name: str = '', customer_phone: str = '', supplier_name: str = '', file_path: str = '', user_id: int | None = None):
    self.require_any_permission(('can_tools', 'can_reports', 'can_audit', 'can_print'), user_id, 'الأرشفة الإلكترونية')
    payload = json.dumps(content_json or {}, ensure_ascii=False)
    self.db.execute('''
        INSERT OR REPLACE INTO document_archive
        (doc_type, ref_no, title, customer_name, customer_phone, supplier_name, amount, doc_date, content_text, content_json, file_path, created_by_user_id, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (doc_type, ref_no, title, customer_name, customer_phone, supplier_name, float(amount or 0), doc_date or now_text(), content_text, payload, file_path, user_id, now_text()))
    try:
        self.audit('أرشفة مستند', f'{doc_type} | {ref_no} | {title}', user_id)
    except Exception as exc:
        log_exception(exc)


AppService.archive_document = _v45_archive_document


def _build_sale_archive_payload(self: AppService, invoice_no: str):
    sale = self.db.one('''
        SELECT s.*, COALESCE(c.name,'زبون عام') customer_name, COALESCE(c.phone,'') customer_phone,
               COALESCE(e.name,'') employee_name, COALESCE(u.username,'') username
        FROM sales s
        LEFT JOIN customers c ON c.id=s.customer_id
        LEFT JOIN employees e ON e.id=s.employee_id
        LEFT JOIN users u ON u.id=s.user_id
        WHERE s.invoice_no=?
    ''', (invoice_no,))
    if not sale:
        return None, []
    items = self.db.all('SELECT * FROM sale_items WHERE sale_id=? ORDER BY id', (sale['id'],))
    lines = [
        f"فاتورة: {sale['invoice_no']}",
        f"التاريخ: {sale['created_at']}",
        f"الزبون: {sale['customer_name']} - {sale['customer_phone']}",
        f"الموظف: {sale['employee_name']}",
        f"الكاشير: {sale['username']}",
        f"الإجمالي: {money(sale['total'])}",
        'المواد:',
    ]
    for item in items:
        lines.append(f"- {item['product_name']} | كمية {item['quantity']} | سعر {money(item['unit_price'])} | مجموع {money(item['line_total'])}")
    text = '\n'.join(lines)
    payload = {'sale': dict(sale), 'items': [dict(i) for i in items]}
    return (sale, text, payload), items


def _v45_archive_sale_invoice(self: AppService, invoice_no: str):
    built, _items = _build_sale_archive_payload(self, invoice_no)
    if not built:
        return
    sale, text, payload = built
    self.archive_document(
        'فاتورة بيع', invoice_no, f"فاتورة بيع {invoice_no}", float(sale['total'] or 0), sale['created_at'],
        text, payload, sale['customer_name'] or '', sale['customer_phone'] or '', '', '', sale['user_id']
    )


AppService.archive_sale_invoice = _v45_archive_sale_invoice


_orig_complete_sale_v45 = AppService.complete_sale


def _v45_complete_sale(self: AppService, cart: list[dict], employee_id: int, customer_id: int | None, payment_method: str, discount_amount: float = 0, note: str = '', user_id: int | None = None, discount_type: str = 'amount') -> str:
    subtotal = sum(float(i.get('quantity', 0) or 0) * float(i.get('unit_price', 0) or 0) for i in (cart or []))
    settings = self.get_settings()
    threshold = to_float(settings.get('security_alert_large_discount_percent', 20), 20)
    discount_value = float(discount_amount or 0)
    discount_percent = discount_value if discount_type == 'percent' else ((discount_value / subtotal * 100) if subtotal else 0)

    for item in cart or []:
        try:
            product = self.db.one('SELECT name, sale_price, quantity FROM products WHERE id=?', (item.get('product_id'),))
            if product and str(settings.get('security_alert_low_price_enabled', '1')) == '1':
                unit_price = float(item.get('unit_price') or 0)
                official = float(product['sale_price'] or 0)
                if official > 0 and unit_price < official:
                    self.log_security_alert(
                        'بيع بسعر أقل من السعر المحدد',
                        f"المنتج={product['name']} | السعر الرسمي={money(official)} | سعر البيع={money(unit_price)}",
                        'high', 'sale', '', user_id
                    )
        except Exception as exc:
            log_exception(exc)
    if subtotal > 0 and discount_percent >= threshold:
        self.log_security_alert('خصم كبير على فاتورة', f'نسبة الخصم التقريبية {discount_percent:.1f}% على إجمالي {money(subtotal)}', 'medium', 'sale', '', user_id)

    invoice = _orig_complete_sale_v45(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type)
    try:
        self.archive_sale_invoice(invoice)
    except Exception as exc:
        log_exception(exc)
    return invoice


AppService.complete_sale = _v45_complete_sale


def _v45_search_archive(self: AppService, query: str = '', doc_type: str = '', date_from: str = '', date_to: str = '', limit: int = 300):
    self.require_any_permission(('can_tools', 'can_reports', 'can_audit', 'can_print'), action='البحث في الأرشيف')
    where = []
    params = []
    q = (query or '').strip()
    if q:
        where.append('''(
            ref_no LIKE ? OR title LIKE ? OR customer_name LIKE ? OR customer_phone LIKE ? OR supplier_name LIKE ? OR content_text LIKE ? OR CAST(amount AS TEXT) LIKE ?
        )''')
        like = f'%{q}%'
        params.extend([like, like, like, like, like, like, like])
    if doc_type:
        where.append('doc_type=?')
        params.append(doc_type)
    if date_from:
        where.append('doc_date>=?')
        params.append(date_from)
    if date_to:
        where.append('doc_date<=?')
        params.append(date_to + ' 23:59:59' if len(date_to) == 10 else date_to)
    sql = 'SELECT * FROM document_archive'
    if where:
        sql += ' WHERE ' + ' AND '.join(where)
    sql += ' ORDER BY doc_date DESC, id DESC LIMIT ?'
    params.append(int(limit or 300))
    return self.db.all(sql, params)


AppService.search_archive = _v45_search_archive


def _v45_get_archived_document(self: AppService, archive_id: int):
    self.require_any_permission(('can_tools', 'can_reports', 'can_audit', 'can_print'), action='فتح مستند مؤرشف')
    row = self.db.one('SELECT * FROM document_archive WHERE id=?', (archive_id,))
    if not row:
        raise ValueError('المستند غير موجود في الأرشيف')
    return row


AppService.get_archived_document = _v45_get_archived_document


def _v45_security_alert_rows(self: AppService, limit: int = 300, status: str = ''):
    self.require_any_permission(('can_audit', 'can_tools'), action='عرض تنبيهات الحماية')
    if status:
        return self.db.all('SELECT * FROM security_alerts WHERE status=? ORDER BY id DESC LIMIT ?', (status, int(limit or 300)))
    return self.db.all('SELECT * FROM security_alerts ORDER BY id DESC LIMIT ?', (int(limit or 300),))


AppService.security_alert_rows = _v45_security_alert_rows


def _v45_resolve_security_alert(self: AppService, alert_id: int, user_id: int | None = None):
    user = self.require_any_permission(('can_audit', 'can_tools'), user_id, 'إغلاق تنبيه حماية')
    self.db.execute('UPDATE security_alerts SET status="resolved", resolved_at=?, resolved_by_user_id=? WHERE id=?', (now_text(), user['id'], alert_id))
    self.audit('إغلاق تنبيه حماية', f'id={alert_id}', user['id'])


AppService.resolve_security_alert = _v45_resolve_security_alert


def _v45_sales_forecast(self: AppService, days_back: int = 90, days_forward: int = 30, limit: int = 50):
    self.require_any_permission(('can_reports', 'can_dashboard', 'can_tools'), action='توقع المبيعات')
    end = datetime.now()
    start = end - timedelta(days=max(int(days_back or 90), 7))
    real_days = max((end - start).days, 1)
    rows = self.db.all('''
        SELECT p.id, p.name, p.barcode, p.quantity current_qty, p.min_quantity, COALESCE(SUM(si.quantity),0) sold_qty
        FROM products p
        LEFT JOIN sale_items si ON si.product_id=p.id
        LEFT JOIN sales s ON s.id=si.sale_id AND s.created_at>=? AND s.created_at<=? AND s.status='completed'
        WHERE p.active=1
        GROUP BY p.id
        ORDER BY sold_qty DESC, p.name
        LIMIT ?
    ''', (start.strftime('%Y-%m-%d %H:%M:%S'), end.strftime('%Y-%m-%d %H:%M:%S'), int(limit or 50)))
    result = []
    for row in rows:
        sold = float(row['sold_qty'] or 0)
        avg_daily = sold / real_days
        expected = avg_daily * int(days_forward or 30)
        recommended = max(expected - float(row['current_qty'] or 0), 0)
        if sold <= 0:
            status = 'راكدة / لم تُبع خلال الفترة'
        elif recommended > 0:
            status = 'ينصح بالتوفير'
        elif float(row['current_qty'] or 0) <= float(row['min_quantity'] or 0):
            status = 'قريبة من حد التنبيه'
        else:
            status = 'مستقرة'
        d = dict(row)
        d.update({'avg_daily': avg_daily, 'expected_qty': expected, 'recommended_purchase_qty': recommended, 'status_text': status})
        result.append(d)
    return result


AppService.sales_forecast = _v45_sales_forecast


def _v45_owner_dashboard_snapshot(self: AppService):
    self.require_any_permission(('can_dashboard', 'can_reports', 'can_tools'), action='لوحة تحكم المالك')
    today = datetime.now().strftime('%Y-%m-%d')
    month_start = datetime.now().replace(day=1).strftime('%Y-%m-%d 00:00:00')
    today_start = today + ' 00:00:00'
    today_end = today + ' 23:59:59'
    today_row = self.db.one('SELECT COUNT(*) invoices, COALESCE(SUM(total),0) sales, COALESCE(SUM(total_profit),0) profit FROM sales WHERE created_at BETWEEN ? AND ? AND status="completed"', (today_start, today_end))
    month_row = self.db.one('SELECT COUNT(*) invoices, COALESCE(SUM(total),0) sales, COALESCE(SUM(total_profit),0) profit FROM sales WHERE created_at>=? AND status="completed"', (month_start,))
    debts = self.db.one('''SELECT COALESCE(SUM(s.total),0) - COALESCE((SELECT SUM(amount) FROM customer_payments WHERE status='completed'),0) debt FROM sales s WHERE s.payment_method LIKE '%دين%' OR s.payment_method LIKE '%آجل%' ''')
    alerts = self.db.one("SELECT COUNT(*) c FROM security_alerts WHERE status='open'")
    low_stock = self.db.one('SELECT COUNT(*) c FROM products WHERE active=1 AND quantity<=min_quantity')
    top_products = self.db.all('''
        SELECT si.product_name, SUM(si.quantity) qty, SUM(si.line_total) total
        FROM sale_items si JOIN sales s ON s.id=si.sale_id
        WHERE s.created_at>=? AND s.status='completed'
        GROUP BY si.product_id, si.product_name
        ORDER BY qty DESC LIMIT 10
    ''', (month_start,))
    summary = {
        'today': dict(today_row or {}),
        'month': dict(month_row or {}),
        'debt_estimate': float((debts['debt'] if debts else 0) or 0),
        'open_security_alerts': int((alerts['c'] if alerts else 0) or 0),
        'low_stock_products': int((low_stock['c'] if low_stock else 0) or 0),
        'top_products': [dict(r) for r in top_products],
        'generated_at': now_text(),
    }
    self.db.execute('INSERT OR REPLACE INTO owner_report_snapshots (report_date, summary_json, created_at) VALUES (?, ?, ?)', (today, json.dumps(summary, ensure_ascii=False), now_text()))
    return summary


AppService.owner_dashboard_snapshot = _v45_owner_dashboard_snapshot
