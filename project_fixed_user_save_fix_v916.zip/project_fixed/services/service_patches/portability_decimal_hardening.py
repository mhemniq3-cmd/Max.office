from __future__ import annotations
import logging as _log

"""V45.10 portability, date, decimal, search, and backup hardening.

This patch keeps the restored v44 interface and focuses on runtime correctness:
- portable relative paths and automatic folder creation
- database integrity check + automatic daily backup
- Decimal based sale totals rounded to 2 decimals before storage/display
- ISO date normalization for filters and archive search
- safer partial search helpers with escaped LIKE patterns
- more explicit audit/session logging around important operations
"""

import os
import re
import shutil
from datetime import datetime, date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, getcontext
from pathlib import Path
from typing import Any, Iterable

from db import database_core as _dbcore
from services.app_core import AppService, invoice_no
from services.core_common import money, now_text, to_float
from services.error_logger import log_exception, log_message

getcontext().prec = 28
TWOPLACES = Decimal('0.01')

PROJECT_ROOT = Path(__file__).resolve().parents[2]
APP_DIRS = {
    'db': PROJECT_ROOT / 'database',
    'backups': PROJECT_ROOT / 'backups',
    'exports': PROJECT_ROOT / 'exports',
    'settings': PROJECT_ROOT / 'settings',
    'logs': PROJECT_ROOT / 'logs',
    'receipts': PROJECT_ROOT / 'exports' / 'receipts',
}


def _ensure_app_dirs() -> None:
    for path in APP_DIRS.values():
        path.mkdir(parents=True, exist_ok=True)


def _default_db_path() -> Path:
    env = os.environ.get('MAX_SALES_DB_PATH', '').strip()
    if env:
        
        candidate = Path(env).expanduser()
        return candidate if candidate.is_absolute() else (PROJECT_ROOT / candidate).resolve()
    return APP_DIRS['db'] / 'max_sales.db'


_old_database_init_v4510 = _dbcore.Database.__init__
_old_execute_v4510 = _dbcore.Database.execute
_old_one_v4510 = _dbcore.Database.one
_old_all_v4510 = _dbcore.Database.all


def _v4510_database_init(self: _dbcore.Database, path: Path | str | None = None):
    _ensure_app_dirs()
    db_path = Path(path).expanduser().resolve() if path else _default_db_path()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        _old_database_init_v4510(self, db_path)
        # Stronger connection settings for local POS workloads.
        self.conn.execute('PRAGMA foreign_keys = ON')
        self.conn.execute('PRAGMA busy_timeout = 10000')
        self.conn.execute('PRAGMA synchronous = NORMAL')
        try:
            self.conn.execute('PRAGMA journal_mode = WAL')
        except Exception as _exc:
            _log.getLogger(__name__).warning("Suppressed exception: %s", _exc, exc_info=True)
        _v4510_integrity_check(self)
        _v4510_auto_backup(self)
    except Exception:
        log_exception(context='V45.10 database initialization')
        raise


def _v4510_integrity_check(self: _dbcore.Database) -> None:
    try:
        row = self.conn.execute('PRAGMA quick_check').fetchone()
        result = row[0] if row else 'unknown'
        if str(result).lower() != 'ok':
            raise RuntimeError(f'فحص قاعدة البيانات فشل: {result}')
    except Exception as exc:
        log_exception(exc, 'V45.10 integrity check')
        raise


def _v4510_auto_backup(self: _dbcore.Database) -> None:
    """Create a once-per-day backup without blocking program startup for long."""
    try:
        today = date.today().isoformat()
        row = self.conn.execute("SELECT value FROM app_settings WHERE key='v45_10_last_auto_backup_date'").fetchone()
        if row and str(row['value'] or '') == today:
            return
        if not Path(self.path).exists():
            return
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        target = APP_DIRS['backups'] / f'max_sales_qt_auto_{stamp}.db'
        # sqlite backup API is safer than copying only the main db when WAL is active.
        backup_conn = None
        try:
            import sqlite3
            backup_conn = sqlite3.connect(target)
            self.conn.backup(backup_conn)
        finally:
            if backup_conn is not None:
                backup_conn.close()
        self.conn.execute('INSERT OR REPLACE INTO app_settings (key, value) VALUES (?, ?)', ('v45_10_last_auto_backup_date', today))
        self.conn.commit()
    except Exception as exc:
        # Backup failure should be visible in logs but must not stop sales.
        log_exception(exc, 'V45.10 auto backup')


def _has_params(query: str, params: Iterable[Any]) -> bool:
    try:
        return bool(tuple(params))
    except Exception:
        return False


def _warn_raw_sql(query: str, params: Iterable[Any]) -> None:
    """Non-breaking warning for suspicious raw SQL, to avoid breaking legacy code."""
    text = ' '.join(str(query or '').split()).lower()
    if not text:
        return
    mutating = text.startswith(('insert ', 'update ', 'delete ', 'replace '))
    has_quote_value = bool(re.search(r"=\s*'[^']+'|like\s*'[^']+'", text))
    if (mutating or has_quote_value) and not _has_params(query, params):
        log_message('تحذير أمان SQL: استعلام بدون معاملات ? تم تمريره للنظام', 'warning')


def _v4510_execute(self: _dbcore.Database, query: str, params: Iterable[Any] = ()):  # noqa: ANN001
    _warn_raw_sql(query, params)
    return _old_execute_v4510(self, query, params)


def _v4510_one(self: _dbcore.Database, query: str, params: Iterable[Any] = ()):  # noqa: ANN001
    _warn_raw_sql(query, params)
    return _old_one_v4510(self, query, params)


def _v4510_all(self: _dbcore.Database, query: str, params: Iterable[Any] = ()):  # noqa: ANN001
    _warn_raw_sql(query, params)
    return _old_all_v4510(self, query, params)


_dbcore.Database.__init__ = _v4510_database_init
_dbcore.Database.execute = _v4510_execute
_dbcore.Database.one = _v4510_one
_dbcore.Database.all = _v45110_all if False else _v4510_all

# Also update the facade module if it has already imported Database.
try:
    import database as _database_facade
    _database_facade.Database = _dbcore.Database
except Exception:
    pass


def _D(value: Any, default: str = '0') -> Decimal:
    try:
        if isinstance(value, Decimal):
            return value
        text = str(value if value is not None else default).strip().replace(',', '')
        if not text:
            text = default
        return Decimal(text)
    except (InvalidOperation, ValueError, TypeError):
        return Decimal(default)


def _money2(value: Any) -> Decimal:
    return _D(value).quantize(TWOPLACES, rounding=ROUND_HALF_UP)


def _to_db_money(value: Any) -> float:
    # SQLite schema uses REAL, so store rounded numbers to avoid long tails.
    return float(_money2(value))


def _clean_text(value: Any, max_len: int = 500) -> str:
    text = str(value or '').strip()
    return text[:max_len]


def _normalize_iso_date(value: Any, allow_empty: bool = True) -> str:
    text = str(value or '').strip()
    if not text:
        if allow_empty:
            return ''
        raise ValueError('التاريخ مطلوب')
    # Already ISO date or datetime; keep date part.
    m = re.match(r'^(\d{4})-(\d{1,2})-(\d{1,2})', text)
    if m:
        y, mo, d = map(int, m.groups())
        return date(y, mo, d).isoformat()
    # Arabic/common local formats: dd/mm/yyyy, dd-mm-yyyy, dd.mm.yyyy.
    m = re.match(r'^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$', text)
    if m:
        d, mo, y = map(int, m.groups())
        return date(y, mo, d).isoformat()
    raise ValueError(f'صيغة التاريخ غير صحيحة: {text}. استخدم YYYY-MM-DD')


def _escape_like(term: str) -> str:
    return str(term or '').replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')


def _like_pattern(term: str) -> str:
    return f"%{_escape_like(term.strip())}%"


def _normalize_cart(self: AppService, cart: list[dict]) -> list[dict]:
    if not cart:
        raise ValueError('السلة فارغة')
    clean: list[dict] = []
    for raw in cart:
        if not isinstance(raw, dict):
            raise ValueError('يوجد سطر غير صالح داخل السلة')
        product_id = int(_D(raw.get('product_id')))
        qty = int(_D(raw.get('quantity')))
        if product_id <= 0 or qty <= 0:
            raise ValueError('كل منتج في السلة يحتاج رقم صحيح وكمية أكبر من صفر')
        product = self.db.one('''
            SELECT id, name, cost_price, sale_price, quantity, commission_percent, active
            FROM products WHERE id=? AND active=1
        ''', (product_id,))
        if not product:
            raise ValueError('يوجد منتج غير موجود أو معطل داخل السلة')
        stock = int(product['quantity'] or 0)
        if stock < qty:
            raise ValueError(f"المخزون غير كاف للمنتج: {product['name']}")
        official = _money2(product['sale_price'])
        requested = _money2(raw.get('unit_price', official))
        unit_price = requested if requested > 0 else official
        if unit_price <= 0:
            raise ValueError(f"سعر المنتج غير صالح: {product['name']}")
        clean.append({
            'product_id': int(product['id']),
            'product_name': _clean_text(product['name'], 180),
            'quantity': qty,
            'cost_price': _money2(product['cost_price']),
            'unit_price': unit_price,
            'commission_percent': _D(product['commission_percent']).quantize(TWOPLACES, rounding=ROUND_HALF_UP),
            'official_sale_price': official,
        })
    return clean


def _discount_amount(subtotal: Decimal, value: Any, discount_type: str) -> tuple[Decimal, str, Decimal]:
    dtype = 'percent' if str(discount_type or '').strip() == 'percent' else 'amount'
    raw_value = max(_D(value), Decimal('0'))
    if subtotal <= 0:
        if raw_value:
            raise ValueError('لا يمكن تطبيق خصم على فاتورة قيمتها صفر')
        return Decimal('0'), dtype, Decimal('0')
    if dtype == 'percent':
        if raw_value > 100:
            raise ValueError('نسبة الخصم لا يمكن أن تكون أكبر من 100%')
        real = subtotal * raw_value / Decimal('100')
    else:
        if raw_value > subtotal:
            raise ValueError(f'قيمة الخصم لا يمكن أن تكون أكبر من إجمالي الفاتورة. إجمالي الفاتورة: {money(float(subtotal))}')
        real = raw_value
    real = _money2(real)
    if real >= subtotal:
        raise ValueError('الخصم لا يمكن أن يساوي أو يتجاوز قيمة الفاتورة')
    pct = (real / subtotal * Decimal('100')) if subtotal else Decimal('0')
    return real, dtype, pct


def _log_sale_security(self: AppService, clean_cart: list[dict], subtotal: Decimal, discount_pct: Decimal, user_id: int | None) -> None:
    try:
        settings = self.get_settings()
        threshold = _D(settings.get('security_alert_large_discount_percent', 20))
        for item in clean_cart:
            if str(settings.get('security_alert_low_price_enabled', '1')) == '1' and item['official_sale_price'] > 0 and item['unit_price'] < item['official_sale_price']:
                if hasattr(self, 'log_security_alert'):
                    self.log_security_alert(
                        'بيع بسعر أقل من السعر المحدد',
                        f"المنتج={item['product_name']} | السعر الرسمي={money(float(item['official_sale_price']))} | سعر البيع={money(float(item['unit_price']))}",
                        'high', 'sale', '', user_id,
                    )
        if subtotal > 0 and discount_pct >= threshold and hasattr(self, 'log_security_alert'):
            self.log_security_alert('خصم كبير على فاتورة', f'نسبة الخصم {discount_pct.quantize(TWOPLACES)}% على إجمالي {money(float(subtotal))}', 'medium', 'sale', '', user_id)
    except Exception as exc:
        log_exception(exc, 'V45.10 sale security alerts')


def _v4510_complete_sale(self: AppService, cart: list[dict], employee_id: int, customer_id: int | None, payment_method: str, discount_amount: float = 0, note: str = '', user_id: int | None = None, discount_type: str = 'amount') -> str:
    user = self.require_any_permission(('can_sales', 'can_touch_pos'), user_id, 'إتمام البيع')
    user_id = int(user['id'])
    if not employee_id:
        raise ValueError('اختر الموظف الذي يستحق العمولة')
    employee = self.db.one('SELECT id, active FROM employees WHERE id=? AND active=1', (int(employee_id),))
    if not employee:
        raise ValueError('الموظف المختار غير موجود أو معطل. العمولات تُسجل للموظفين فقط.')

    clean_cart = _normalize_cart(self, cart or [])
    subtotal = _money2(sum(_D(i['quantity']) * i['unit_price'] for i in clean_cart))
    discount, dtype, discount_pct = _discount_amount(subtotal, discount_amount, discount_type)
    taxable_base = max(subtotal - discount, Decimal('0'))
    tax_percent = max(_D(self.get_settings().get('tax_percent', 0)), Decimal('0'))
    tax_amount = _money2(taxable_base * tax_percent / Decimal('100'))
    total = _money2(taxable_base + tax_amount)

    _log_sale_security(self, clean_cart, subtotal, discount_pct, user_id)

    commission = Decimal('0')
    profit = Decimal('0')
    line_rows = []
    for item in clean_cart:
        line_total = _money2(_D(item['quantity']) * item['unit_price'])
        line_discount = _money2(discount * line_total / subtotal) if subtotal else Decimal('0')
        line_net = _money2(line_total - line_discount)
        item_commission = _money2(line_net * item['commission_percent'] / Decimal('100'))
        item_profit = _money2(_D(item['quantity']) * (item['unit_price'] - item['cost_price']) - line_discount)
        commission += item_commission
        profit += item_profit
        line_rows.append((item, line_total, item_commission, item_profit))
    commission = _money2(commission)
    profit = _money2(profit)
    inv = invoice_no()
    safe_payment = _clean_text(payment_method, 40) or 'نقدي'
    safe_note = _clean_text(note, 1000)
    created = now_text()

    with self.db.conn:
        cur = self.db.conn.execute('''
            INSERT INTO sales
            (invoice_no, user_id, employee_id, customer_id, subtotal, discount_amount, total, total_commission, total_profit, payment_method, discount_type, tax_amount, note, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (inv, user_id, int(employee_id), int(customer_id) if customer_id else None, _to_db_money(subtotal), _to_db_money(discount), _to_db_money(total), _to_db_money(commission), _to_db_money(profit), safe_payment, dtype, _to_db_money(tax_amount), safe_note, created))
        sale_id = cur.lastrowid
        for item, line_total, item_commission, item_profit in line_rows:
            self.db.conn.execute('''
                INSERT INTO sale_items
                (sale_id, product_id, product_name, quantity, cost_price, unit_price, line_total, commission_percent, commission_amount, profit_amount)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (sale_id, item['product_id'], item['product_name'], item['quantity'], _to_db_money(item['cost_price']), _to_db_money(item['unit_price']), _to_db_money(line_total), _to_db_money(item['commission_percent']), _to_db_money(item_commission), _to_db_money(item_profit)))
            oldq_row = self.db.conn.execute('SELECT quantity FROM products WHERE id=?', (item['product_id'],)).fetchone()
            oldq = int(oldq_row['quantity'] if oldq_row else 0)
            newq = oldq - int(item['quantity'])
            self.db.conn.execute('UPDATE products SET quantity=? WHERE id=?', (newq, item['product_id']))
            self.db.conn.execute('''
                INSERT INTO inventory_movements
                (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (item['product_id'], 'بيع', -int(item['quantity']), oldq, newq, 'sale', inv, '', user_id, created))
    self.log('بيع', inv, user_id)
    try:
        if hasattr(self, 'archive_sale_invoice'):
            self.archive_sale_invoice(inv)
    except Exception as exc:
        log_exception(exc, 'V45.10 archive sale')
    return inv


AppService.complete_sale = _v4510_complete_sale


_prev_suspend_sale_v4510 = AppService.suspend_sale


def _v4510_suspend_sale(self: AppService, cart: list[dict], employee_id: int | None, customer_id: int | None, payment_method: str, discount_amount: float, note: str = '', user_id: int | None = None) -> str:
    clean = _normalize_cart(self, cart or [])
    subtotal = _money2(sum(_D(i['quantity']) * i['unit_price'] for i in clean))
    _discount_amount(subtotal, discount_amount, 'amount')
    # Convert Decimals back to simple JSON-safe values for the legacy storage path.
    json_safe = []
    for item in clean:
        row = dict(item)
        row.pop('official_sale_price', None)
        for key in ('cost_price', 'unit_price', 'commission_percent'):
            row[key] = _to_db_money(row[key])
        json_safe.append(row)
    return _prev_suspend_sale_v4510(self, json_safe, employee_id, customer_id, _clean_text(payment_method, 40) or 'نقدي', _to_db_money(discount_amount), _clean_text(note, 1000), user_id)


AppService.suspend_sale = _v4510_suspend_sale


_prev_list_products_v4510 = AppService.list_products


def _v4510_list_products(self: AppService, term: str = '', category: str = '', state: str = 'active'):
    """Partial Arabic search with escaped LIKE and sane limit."""
    term = _clean_text(term, 120)
    category = _clean_text(category, 120)
    state = _clean_text(state, 30) or 'active'
    where = []
    params: list[Any] = []
    if state == 'all':
        pass
    elif state == 'inactive':
        where.append('active=0')
    elif state == 'low':
        where.append('active=1 AND quantity <= min_quantity')
    elif state == 'out':
        where.append('active=1 AND quantity <= 0')
    else:
        where.append('active=1')
    if term:
        like = _like_pattern(term)
        where.append('(name LIKE ? ESCAPE \'\\\' OR barcode LIKE ? ESCAPE \'\\\' OR category LIKE ? ESCAPE \'\\\')')
        params.extend([like, like, like])
    if category:
        where.append('category=?')
        params.append(category)
    sql = 'SELECT * FROM products'
    if where:
        sql += ' WHERE ' + ' AND '.join(where)
    sql += ' ORDER BY active DESC, name LIMIT 500'
    return self.db.all(sql, params)


AppService.list_products = _v4510_list_products


_prev_search_archive_v4510 = getattr(AppService, 'search_archive', None)


def _v4510_search_archive(self: AppService, query: str = '', doc_type: str = '', date_from: str = '', date_to: str = '', limit: int = 300):
    self.require_any_permission(('can_tools', 'can_reports', 'can_audit', 'can_print'), action='البحث في الأرشيف')
    where = []
    params: list[Any] = []
    q = _clean_text(query, 160)
    if q:
        like = _like_pattern(q)
        where.append('''(
            ref_no LIKE ? ESCAPE '\\' OR title LIKE ? ESCAPE '\\' OR customer_name LIKE ? ESCAPE '\\' OR
            customer_phone LIKE ? ESCAPE '\\' OR supplier_name LIKE ? ESCAPE '\\' OR content_text LIKE ? ESCAPE '\\' OR CAST(amount AS TEXT) LIKE ? ESCAPE '\\'
        )''')
        params.extend([like, like, like, like, like, like, like])
    if doc_type:
        where.append('doc_type=?')
        params.append(_clean_text(doc_type, 80))
    df = _normalize_iso_date(date_from) if date_from else ''
    dt = _normalize_iso_date(date_to) if date_to else ''
    if df:
        where.append('date(doc_date) >= date(?)')
        params.append(df)
    if dt:
        where.append('date(doc_date) <= date(?)')
        params.append(dt)
    sql = 'SELECT * FROM document_archive'
    if where:
        sql += ' WHERE ' + ' AND '.join(where)
    sql += ' ORDER BY doc_date DESC, id DESC LIMIT ?'
    params.append(max(1, min(int(limit or 300), 1000)))
    return self.db.all(sql, params)


if callable(_prev_search_archive_v4510):
    AppService.search_archive = _v4510_search_archive


_prev_filtered_operations_v4510 = getattr(AppService, 'filtered_operations', None)


def _v4510_filtered_operations(self: AppService, date_from='', date_to='', employee='', customer='', product='', payment_method='', category='', operation_type='', limit=1000):
    if not callable(_prev_filtered_operations_v4510):
        return []
    df = _normalize_iso_date(date_from) if date_from else ''
    dt = _normalize_iso_date(date_to) if date_to else ''
    return _prev_filtered_operations_v4510(self, df, dt, _clean_text(employee, 100), _clean_text(customer, 100), _clean_text(product, 100), _clean_text(payment_method, 50), _clean_text(category, 100), _clean_text(operation_type, 50), max(1, min(int(limit or 1000), 5000)))


if callable(_prev_filtered_operations_v4510):
    AppService.filtered_operations = _v4510_filtered_operations


_prev_list_expenses_v4510 = getattr(AppService, 'list_expenses', None)
_prev_profit_summary_v4510 = getattr(AppService, 'profit_summary', None)
_prev_expense_summary_v4510 = getattr(AppService, 'expense_summary', None)


def _v4510_list_expenses(self: AppService, date_from: str = '', date_to: str = '', limit: int = 500):
    df = _normalize_iso_date(date_from) if date_from else ''
    dt = _normalize_iso_date(date_to) if date_to else ''
    return _prev_list_expenses_v4510(self, df, dt, max(1, min(int(limit or 500), 5000))) if callable(_prev_list_expenses_v4510) else []


def _v4510_profit_summary(self: AppService, date_from: str = '', date_to: str = '') -> dict:
    df = _normalize_iso_date(date_from) if date_from else ''
    dt = _normalize_iso_date(date_to) if date_to else ''
    return _prev_profit_summary_v4510(self, df, dt) if callable(_prev_profit_summary_v4510) else {}


def _v4510_expense_summary(self: AppService, date_from: str = '', date_to: str = '') -> dict:
    df = _normalize_iso_date(date_from) if date_from else ''
    dt = _normalize_iso_date(date_to) if date_to else ''
    return _prev_expense_summary_v4510(self, df, dt) if callable(_prev_expense_summary_v4510) else {'total': 0, 'by_type': {}}


if callable(_prev_list_expenses_v4510):
    AppService.list_expenses = _v4510_list_expenses
if callable(_prev_profit_summary_v4510):
    AppService.profit_summary = _v4510_profit_summary
if callable(_prev_expense_summary_v4510):
    AppService.expense_summary = _v4510_expense_summary


_prev_authenticate_v4510 = AppService.authenticate


def _v4510_authenticate(self: AppService, username: str, password: str):
    user = _prev_authenticate_v4510(self, _clean_text(username, 80), password)
    if user:
        try:
            self.db.execute('''
                CREATE TABLE IF NOT EXISTS user_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    username TEXT,
                    login_at TEXT NOT NULL,
                    logout_at TEXT,
                    note TEXT,
                    FOREIGN KEY(user_id) REFERENCES users(id)
                )
            ''')
            self.db.execute('INSERT INTO user_sessions (user_id, username, login_at, note) VALUES (?, ?, ?, ?)', (user['id'], user['username'], now_text(), 'login'))
        except Exception as exc:
            log_exception(exc, 'V45.10 session log')
    return user


AppService.authenticate = _v4510_authenticate


def _v4510_runtime_health(self: AppService) -> dict:
    """Small health snapshot used by support/tools pages and manual diagnostics."""
    result = {
        'db_path': str(self.db.path),
        'db_exists': Path(self.db.path).exists(),
        'project_root': str(PROJECT_ROOT),
        'backup_dir': str(APP_DIRS['backups']),
        'integrity': 'unknown',
        'today_backup': False,
    }
    try:
        row = self.db.one('PRAGMA quick_check')
        result['integrity'] = row[0] if row else 'unknown'
    except Exception as exc:
        result['integrity'] = f'error: {exc}'
    try:
        today = date.today().strftime('%Y%m%d')
        result['today_backup'] = any(p.name.startswith(f'max_sales_qt_auto_{today}') for p in APP_DIRS['backups'].glob('*.db'))
    except Exception as _exc:
        _log.getLogger(__name__).warning("Suppressed exception: %s", _exc, exc_info=True)
    return result


AppService.runtime_health = _v4510_runtime_health

# Portable export/backup paths and safer backup API.
def _v4510_export_dir(self: AppService) -> Path:
    APP_DIRS['exports'].mkdir(parents=True, exist_ok=True)
    return APP_DIRS['exports']


def _v4510_backup_dir(self: AppService) -> Path:
    APP_DIRS['backups'].mkdir(parents=True, exist_ok=True)
    return APP_DIRS['backups']


def _v4510_backup_database(self: AppService) -> Path:
    self.require_permission('can_backup', action='إنشاء نسخة احتياطية')
    target = APP_DIRS['backups'] / f'max_sales_qt_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.db'
    import sqlite3
    backup_conn = None
    try:
        backup_conn = sqlite3.connect(target)
        self.db.conn.backup(backup_conn)
    finally:
        if backup_conn is not None:
            backup_conn.close()
    self.log('نسخة احتياطية', str(target))
    return target


AppService.export_dir = _v4510_export_dir
AppService.backup_dir = _v4510_backup_dir
AppService.backup_database = _v4510_backup_database


def _v4510_export_rows_csv(self: AppService, filename: str, headers: list[str], rows: list[list[Any]]) -> Path:
    """UTF-8-SIG CSV export so Arabic opens correctly in Excel."""
    import csv
    safe_name = re.sub(r'[^\w\-\u0600-\u06FF]+', '_', str(filename or 'export'), flags=re.UNICODE)[:80]
    path = APP_DIRS['exports'] / f'{safe_name}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)
    self.log('تصدير CSV', str(path))
    return path


AppService.export_rows_csv = _v4510_export_rows_csv
