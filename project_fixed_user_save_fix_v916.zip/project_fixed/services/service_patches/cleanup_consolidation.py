from __future__ import annotations

from pathlib import Path
from typing import Any

from services.app_core import AppService
from services.shared.notification_center import Notification, NotificationCenter, clean_text
from services.shared.validators import as_decimal, require_positive_money, require_text, validate_email, validate_phone
from services.shared.report_engine import ReportEngine
from services.shared.audit_center import AuditCenter
from services.core_common import now_text, log_exception

_ORIG_INIT = AppService.__init__
_ORIG_LOG = getattr(AppService, 'log', None)
_ORIG_SAVE_SETTINGS = getattr(AppService, 'save_settings', None)


def _ensure_cleanup_schema(self: AppService) -> None:
    NotificationCenter(self.db).ensure_schema()
    AuditCenter(self.db).ensure_schema()
    self.db.conn.execute(
        '''CREATE TABLE IF NOT EXISTS maintenance_actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            details TEXT,
            user_id INTEGER,
            created_at TEXT NOT NULL
        )'''
    )
    self.db.conn.execute('CREATE INDEX IF NOT EXISTS idx_maintenance_actions_date ON maintenance_actions(created_at)')
    self.db.conn.commit()


def _notify_event(self: AppService, subject: str, message: str = '', severity: str = 'info', channel: str = 'in_app', target_user_id: int | None = None) -> int:
    center = NotificationCenter(self.db)
    return center.send(Notification(channel=channel, severity=severity, subject=subject, message=message, target_user_id=target_user_id))


def _validate_common(self: AppService, value: Any, kind: str, field_name: str = 'الحقل', required: bool = False):
    if kind == 'money_positive':
        return require_positive_money(value, field_name)
    if kind == 'money':
        return as_decimal(value)
    if kind == 'text':
        return require_text(value, field_name) if required else str(value or '').strip()
    if kind == 'phone':
        return validate_phone(value, required=required)
    if kind == 'email':
        return validate_email(value, required=required)
    raise ValueError('نوع تحقق غير مدعوم')


def _export_report(self: AppService, name: str, rows: list[dict] | list[Any], fields: list[str] | None = None, fmt: str = 'csv', title: str | None = None) -> str:
    data = [dict(r) for r in rows]
    engine = ReportEngine('exports')
    if fmt.lower() == 'html':
        return str(engine.html_table(name, title or name, data, fields))
    return str(engine.csv(name, data, fields))


def _audit_event(self: AppService, category: str, action: str, table_name: str = '', record_id: int | None = None,
                 old_values: Any = None, new_values: Any = None, user_id: int | None = None, username: str = '', reason: str = '') -> int:
    return AuditCenter(self.db).write(category, action, table_name, record_id, old_values, new_values, user_id, username, reason)


def _log(self: AppService, action: str, details: str = '', user_id: int | None = None, username: str = '') -> None:
    action_clean = clean_text(action, 120)
    details_clean = clean_text(details, 800)
    username_clean = clean_text(username, 80)
    try:
        if _ORIG_LOG:
            _ORIG_LOG(self, action_clean, details_clean, user_id, username_clean)
        try:
            self.audit_event('activity', action_clean, 'activity_logs', None, None, {'details': details_clean}, user_id, username_clean, '')
        except Exception:
            pass
    except Exception as exc:
        log_exception(exc)


def _save_settings(self: AppService, data: dict, user_id: int | None = None) -> None:
    # Consolidate duplicated coupon expiry settings: coupon-specific expiry is authoritative.
    normalized = dict(data or {})
    duplicate_keys = ('coupon_default_expiry', 'coupon_default_expiry_date', 'global_coupon_expiry_date')
    for key in duplicate_keys:
        if key in normalized:
            normalized.pop(key, None)
            self.notify_event('تم تجاهل إعداد مكرر', f'تم تجاهل {key} لأن تاريخ القسيمة يحدد داخل القسيمة نفسها.', 'warning')
    if _ORIG_SAVE_SETTINGS:
        return _ORIG_SAVE_SETTINGS(self, normalized, user_id)
    for key, value in normalized.items():
        self.db.execute('INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (str(key), str(value)))


def _cleanup_legacy_artifacts(self: AppService, user_id: int | None = None) -> dict:
    """Audit obsolete tables without deleting customer data.

    Final v1.0.0 packages must never drop tables during normal maintenance.
    This helper now reports candidates only, records the audit action, and
    leaves any table removal to an explicit external backup/DBA process.
    """
    self.require_any_permission(('can_settings', 'can_backup', 'can_tools'), user_id, 'تنظيف النظام')
    found_tables = []
    for table in ('old_error_logs', 'debug_logs', 'test_data'):
        try:
            exists = self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
            if exists:
                found_tables.append(table)
        except Exception as exc:
            log_exception(exc, f'audit obsolete table {table}')
    details = ', '.join(found_tables) if found_tables else 'لا توجد جداول مهملة'
    self.db.conn.execute(
        'INSERT INTO maintenance_actions(action, details, user_id, created_at) VALUES (?, ?, ?, ?)',
        ('فحص مخلفات قديمة بدون حذف', details, user_id, now_text()),
    )
    self.db.conn.commit()
    return {'candidate_tables': found_tables, 'removed_tables': [], 'message': 'تم الفحص فقط؛ لم يتم حذف أي بيانات'}


def _maintenance_summary(self: AppService) -> dict:
    return {
        'notifications': self.db.one('SELECT COUNT(*) c FROM system_notifications')['c'],
        'unified_audit_events': self.db.one('SELECT COUNT(*) c FROM unified_audit_events')['c'],
        'maintenance_actions': self.db.one('SELECT COUNT(*) c FROM maintenance_actions')['c'],
        'central_services': ['NotificationCenter', 'validators', 'ReportEngine', 'AuditCenter'],
    }


def _init(self: AppService, *args, **kwargs):
    _ORIG_INIT(self, *args, **kwargs)
    try:
        _ensure_cleanup_schema(self)
    except Exception as exc:
        log_exception(exc, 'v45.17.4.8 cleanup consolidation schema')


AppService.__init__ = _init
AppService.notify_event = _notify_event
AppService.validate_common = _validate_common
AppService.export_report = _export_report
AppService.audit_event = _audit_event
AppService.cleanup_legacy_artifacts = _cleanup_legacy_artifacts
AppService.maintenance_summary = _maintenance_summary
AppService.log = _log
AppService.save_settings = _save_settings
