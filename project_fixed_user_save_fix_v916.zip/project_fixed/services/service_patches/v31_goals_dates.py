from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})
import services.service_patches.v19_gdrive as _prev_v19_gdrive
globals().update({k: v for k, v in vars(_prev_v19_gdrive).items() if not k.startswith('__')})
import services.service_patches.v20_gdrive_settings as _prev_v20_gdrive_settings
globals().update({k: v for k, v in vars(_prev_v20_gdrive_settings).items() if not k.startswith('__')})
import services.service_patches.v21_backup as _prev_v21_backup
globals().update({k: v for k, v in vars(_prev_v21_backup).items() if not k.startswith('__')})
import services.service_patches.v22_gdrive_final as _prev_v22_gdrive_final
globals().update({k: v for k, v in vars(_prev_v22_gdrive_final).items() if not k.startswith('__')})
import services.service_patches.v23_business_tools as _prev_v23_business_tools
globals().update({k: v for k, v in vars(_prev_v23_business_tools).items() if not k.startswith('__')})
import services.service_patches.v24_smart_assistant as _prev_v24_smart_assistant
globals().update({k: v for k, v in vars(_prev_v24_smart_assistant).items() if not k.startswith('__')})
import services.service_patches.v25_readiness as _prev_v25_readiness
globals().update({k: v for k, v in vars(_prev_v25_readiness).items() if not k.startswith('__')})
import services.service_patches.v25_1_barcode as _prev_v25_1_barcode
globals().update({k: v for k, v in vars(_prev_v25_1_barcode).items() if not k.startswith('__')})
import services.service_patches.v26_tools_repair as _prev_v26_tools_repair
globals().update({k: v for k, v in vars(_prev_v26_tools_repair).items() if not k.startswith('__')})
import services.service_patches.v26_1_tools_stability as _prev_v26_1_tools_stability
globals().update({k: v for k, v in vars(_prev_v26_1_tools_stability).items() if not k.startswith('__')})
import services.service_patches.v27_pricing_excel_qr as _prev_v27_pricing_excel_qr
globals().update({k: v for k, v in vars(_prev_v27_pricing_excel_qr).items() if not k.startswith('__')})
import services.service_patches.v30_safe_delete as _prev_v30_safe_delete
globals().update({k: v for k, v in vars(_prev_v30_safe_delete).items() if not k.startswith('__')})

# ---------------------------------------------------------------------------
# V31 employee goals and date defaults patch
# - Goals start automatically from creation time when no date is provided.
# - Daily goals expire after 24 hours, weekly after 7 days, monthly after 1 month.
# - Expired goals are automatically disabled when goal rows are requested.
# - Add permanent goal deletion for managers.
# ---------------------------------------------------------------------------
from datetime import datetime as _v31_datetime, timedelta as _v31_timedelta


def _v31_add_month(dt: _v31_datetime) -> _v31_datetime:
    month = dt.month + 1
    year = dt.year + (month - 1) // 12
    month = ((month - 1) % 12) + 1
    days = [31, 29 if (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    return dt.replace(year=year, month=month, day=min(dt.day, days[month - 1]))


def _v31_parse_goal_start(text: str | None) -> _v31_datetime:
    raw = str(text or '').strip()
    if not raw or raw.lower() in ('auto', 'today', 'now', 'تلقائي', 'اليوم'):
        return _v31_datetime.now()
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d', '%Y-%m'):
        try:
            return _v31_datetime.strptime(raw[:len(_v31_datetime.now().strftime(fmt))], fmt)
        except Exception as exc:
            log_exception(exc)
    return _v31_datetime.now()


def _v31_goal_period_bounds(self: AppService, period_type: str, period_start: str):
    start = _v31_parse_goal_start(period_start)
    p = str(period_type or '').strip()
    if p == 'يومي':
        end = start + _v31_timedelta(hours=24)
    elif p == 'أسبوعي':
        end = start + _v31_timedelta(days=7)
    elif p == 'ربع سنوي':
        end = _v31_add_month(_v31_add_month(_v31_add_month(start)))
    elif p == 'سنوي':
        try:
            end = start.replace(year=start.year + 1)
        except ValueError:
            end = start.replace(year=start.year + 1, day=28)
    else:
        # شهري: يبدأ من لحظة إنشاء الهدف ويتوقف بعد شهر كامل.
        end = _v31_add_month(start)
    return start.strftime('%Y-%m-%d %H:%M:%S'), end.strftime('%Y-%m-%d %H:%M:%S')


_orig_save_employee_goal_v31 = AppService.save_employee_goal

def _v31_save_employee_goal(self: AppService, employee_id: int, period_type: str, period_start: str = '', target_sales: float = 0,
                            bonus_amount: float = 0, note: str = '', goal_type: str = 'مبيعات', scope_type: str = 'موظف',
                            target_product_id=None, reward_type: str = 'مبلغ ثابت', reward_rate: float = 0,
                            bonus_120: float = 0, bonus_150: float = 0) -> None:
    auto_start = now_text()
    return _orig_save_employee_goal_v31(self, employee_id, period_type, auto_start, target_sales, bonus_amount, note,
                                       goal_type, scope_type, target_product_id, reward_type, reward_rate, bonus_120, bonus_150)


def _v31_expire_finished_goals(self: AppService) -> None:
    try:
        rows = self.db.all('SELECT id, period_type, period_start FROM employee_goals WHERE active=1')
        now = _v31_datetime.now()
        expired_ids = []
        for row in rows:
            _start, end_text = _v31_goal_period_bounds(self, row['period_type'], row['period_start'])
            try:
                if now >= _v31_datetime.strptime(end_text, '%Y-%m-%d %H:%M:%S'):
                    expired_ids.append(int(row['id']))
            except Exception as exc:
                log_exception(exc)
        for gid in expired_ids:
            self.db.execute('UPDATE employee_goals SET active=0 WHERE id=?', (gid,))
        if expired_ids:
            self.log('تعطيل أهداف منتهية تلقائياً', ','.join(str(x) for x in expired_ids))
    except Exception as exc:
        log_exception(exc)


_orig_employee_goal_rows_v31 = AppService.employee_goal_rows

def _v31_employee_goal_rows(self: AppService, user=None):
    _v31_expire_finished_goals(self)
    rows = _orig_employee_goal_rows_v31(self, user)
    now = _v31_datetime.now()
    out = []
    for d in rows:
        start_text, end_text = _v31_goal_period_bounds(self, d.get('period_type'), d.get('period_start'))
        d['period_start'] = start_text
        d['period_end'] = end_text
        try:
            end_dt = _v31_datetime.strptime(end_text, '%Y-%m-%d %H:%M:%S')
            remaining_seconds = max(int((end_dt - now).total_seconds()), 0)
        except Exception:
            remaining_seconds = 0
        d['remaining_time'] = remaining_seconds
        days, rem = divmod(remaining_seconds, 86400)
        hours, rem = divmod(rem, 3600)
        minutes = rem // 60
        if days:
            d['period_remaining_text'] = f'{days} يوم و {hours} ساعة'
        elif hours:
            d['period_remaining_text'] = f'{hours} ساعة و {minutes} دقيقة'
        else:
            d['period_remaining_text'] = f'{minutes} دقيقة'
        out.append(d)
    return out


def _v31_hard_delete_employee_goal(self: AppService, goal_id: int) -> None:
    self.require_permission('can_goals', action='حذف هدف موظف')
    gid = int(goal_id or 0)
    if not gid:
        raise ValueError('اختر الهدف المراد حذفه')
    row = self.db.one('SELECT g.*, e.name employee FROM employee_goals g LEFT JOIN employees e ON e.id=g.employee_id WHERE g.id=?', (gid,))
    if not row:
        raise ValueError('الهدف غير موجود')
    self.db.execute('DELETE FROM employee_goals WHERE id=?', (gid,))
    self.log('حذف هدف موظف نهائياً', f"{row['employee'] or row['employee_id']} - {row['goal_type']} - {row['target_sales']:,.0f}")
    try:
        self.audit('حذف هدف موظف نهائياً', f"id={gid}, الموظف={row['employee'] or row['employee_id']}, النوع={row['goal_type']}")
    except Exception as exc:
        log_exception(exc)


_orig_save_expense_v31 = AppService.save_expense

def _v31_save_expense(self: AppService, expense_type: str, amount: float, expense_date: str = '', note: str = '', user_id: int | None = None) -> int:
    date_text = str(expense_date or '').strip() or _v31_datetime.now().strftime('%Y-%m-%d')
    return _orig_save_expense_v31(self, expense_type, amount, date_text, note, user_id)


AppService._goal_period_bounds = _v31_goal_period_bounds
AppService.save_employee_goal = _v31_save_employee_goal
AppService.employee_goal_rows = _v31_employee_goal_rows
AppService.delete_employee_goal_hard = _v31_hard_delete_employee_goal
AppService.save_expense = _v31_save_expense

