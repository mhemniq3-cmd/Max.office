from __future__ import annotations

from typing import Any

from services.app_service import AppService
from services.error_logger import log_exception

try:
    from services.service_patches.final_cleanup_audit_fix import _sync_unified_movements_v4517416 as _sync_unified
except Exception:  # pragma: no cover
    _sync_unified = None


def _safe_text(value: Any, max_len: int = 200) -> str:
    text = '' if value is None else str(value).strip()
    text = text.replace('\x00', '')
    return text[:max_len]


def _bounded_int(value: Any, default: int, low: int, high: int) -> int:
    try:
        number = int(value)
    except Exception:
        number = default
    return max(low, min(number, high))


def _table_exists(self: AppService, table: str) -> bool:
    try:
        row = self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
        return bool(row)
    except Exception:
        return False


def _list_unified_movements_fast(self: AppService, limit: int = 100, **filters) -> list[dict[str, Any]]:
    """Fast, paginated movement listing used by the optimized Tools movement center.

    Important change from v45.17.4.16: this read method does not run the heavy
    synchronization every time. The UI exposes a separate sync button, so opening
    Tools or switching tabs stays responsive.
    """
    if not _table_exists(self, 'unified_movement_log'):
        return []
    if filters.get('auto_sync') and _sync_unified is not None:
        try:
            _sync_unified(self, limit=_bounded_int(filters.get('sync_limit'), 500, 100, 2000), days=_bounded_int(filters.get('sync_days'), 14, 1, 90))
        except Exception as exc:
            log_exception(exc, 'tools movement optimized sync')
    limit = _bounded_int(limit, 100, 25, 500)
    offset = _bounded_int(filters.get('offset'), 0, 0, 100000)
    clauses: list[str] = []
    params: list[Any] = []

    term = _safe_text(filters.get('term', ''), 200)
    if term:
        like = f'%{term}%'
        clauses.append('(action LIKE ? OR description LIKE ? OR user_name LIKE ? OR module LIKE ? OR record_type LIKE ? OR CAST(record_id AS TEXT) LIKE ?)')
        params.extend([like, like, like, like, like, like])

    mode = str(filters.get('mode') or 'all')
    if mode == 'daily':
        clauses.append("date(event_time)=date('now','localtime')")
    elif mode == 'sensitive':
        clauses.append('(is_sensitive=1 OR severity IN (?,?))')
        params.extend(['حساس', 'خطر'])
    elif mode == 'fraud':
        clauses.append("(source_table='fraud_alerts' OR action LIKE ? OR module LIKE ?)")
        params.extend(['%احتيال%', '%احتيال%'])
    elif mode == 'unread':
        clauses.append('is_read=0')

    severity = _safe_text(filters.get('severity', ''), 30)
    if severity and severity != 'الكل':
        clauses.append('severity=?')
        params.append(severity)

    module = _safe_text(filters.get('module', ''), 80)
    if module and module != 'كل الأقسام':
        clauses.append('module=?')
        params.append(module)

    user_name = _safe_text(filters.get('user_name', ''), 80)
    if user_name:
        clauses.append('user_name LIKE ?')
        params.append(f'%{user_name}%')

    record_type = _safe_text(filters.get('record_type', ''), 80)
    if record_type and record_type not in ('الكل', 'كل الأنواع'):
        clauses.append('record_type LIKE ?')
        params.append(f'%{record_type}%')

    date_from = _safe_text(filters.get('date_from', ''), 20)
    if date_from:
        clauses.append('date(event_time) >= date(?)')
        params.append(date_from)

    date_to = _safe_text(filters.get('date_to', ''), 20)
    if date_to:
        clauses.append('date(event_time) <= date(?)')
        params.append(date_to)

    where = 'WHERE ' + ' AND '.join(clauses) if clauses else ''
    params.extend([limit, offset])
    return [dict(r) for r in self.db.all(f'''
        SELECT id, event_key, event_time, user_id, user_name, module, action, record_type, record_id,
               description, old_values, new_values, severity, source_table, source_id, is_sensitive, is_read, manager_note
          FROM unified_movement_log {where}
         ORDER BY datetime(event_time) DESC, id DESC LIMIT ? OFFSET ?
    ''', tuple(params))]


def _movement_summary_fast(self: AppService) -> dict[str, Any]:
    """Summary query without forced sync on every refresh."""
    if not _table_exists(self, 'unified_movement_log'):
        return {}

    def scalar(sql: str, params: tuple = ()) -> int:
        row = self.db.one(sql, params)
        return int(row['v'] if row and row['v'] is not None else 0)

    top_user = self.db.one('''
        SELECT COALESCE(user_name,'') name, COUNT(*) c FROM unified_movement_log
         WHERE date(event_time)=date('now','localtime') AND COALESCE(user_name,'')<>''
         GROUP BY user_name ORDER BY c DESC LIMIT 1
    ''')
    last_fraud = self.db.one('''
        SELECT event_time, action, description FROM unified_movement_log
         WHERE source_table='fraud_alerts' OR action LIKE '%احتيال%'
         ORDER BY datetime(event_time) DESC, id DESC LIMIT 1
    ''')
    return {
        'today_total': scalar("SELECT COUNT(*) v FROM unified_movement_log WHERE date(event_time)=date('now','localtime')"),
        'sensitive_total': scalar("SELECT COUNT(*) v FROM unified_movement_log WHERE date(event_time)=date('now','localtime') AND (is_sensitive=1 OR severity IN ('حساس','خطر'))"),
        'discount_total': scalar("SELECT COUNT(*) v FROM unified_movement_log WHERE date(event_time)=date('now','localtime') AND action LIKE ?", ('%خصم%',)),
        'delete_total': scalar("SELECT COUNT(*) v FROM unified_movement_log WHERE date(event_time)=date('now','localtime') AND (action LIKE ? OR action LIKE ?)", ('%حذف%', '%تعطيل%')),
        'return_total': scalar("SELECT COUNT(*) v FROM unified_movement_log WHERE date(event_time)=date('now','localtime') AND (action LIKE ? OR action LIKE ?)", ('%إرجاع%', '%مرتجع%')),
        'unread_total': scalar('SELECT COUNT(*) v FROM unified_movement_log WHERE is_read=0'),
        'top_user': dict(top_user) if top_user else {'name': '', 'c': 0},
        'last_fraud': dict(last_fraud) if last_fraud else {},
    }


def _sync_unified_movements_light(self: AppService, limit: int = 500, days: int = 14) -> int:
    if _sync_unified is None:
        return 0
    return _sync_unified(self, limit=_bounded_int(limit, 500, 100, 2000), days=_bounded_int(days, 14, 1, 90))


AppService.list_unified_movements = _list_unified_movements_fast
AppService.movement_summary = _movement_summary_fast
AppService.sync_unified_movements_light = _sync_unified_movements_light
