from __future__ import annotations

"""V45.16 advanced permissions, full audit trail, and barcode automation.

This patch keeps the v44 visual design and adds service-level protections so
operations cannot bypass permissions even if a page/function is called directly.
"""

import json
import time
import random
from typing import Any, Iterable

from services.app_core import AppService
from services.error_logger import log_exception, log_message
from database import now_text

V4516_PERMISSIONS: dict[str, str] = {
    'can_view_profit': 'عرض الأرباح',
    'can_view_cost': 'عرض سعر الشراء/التكلفة',
    'can_price_edit': 'تعديل الأسعار',
    'can_quantity_edit': 'تعديل الكميات',
    'can_barcode_manage': 'توليد/إدارة الباركود',
    'can_scan_barcode': 'استخدام قارئ الباركود في البيع',
    'can_view_activity_logs': 'عرض سجل الحركات',
    'can_export_reports': 'تصدير التقارير',
    'can_print_reports': 'طباعة التقارير',
    'can_delete_records': 'تعطيل/حذف السجلات',
}

PERMISSION_ALIASES = {
    'can_scan_barcode': 'can_sales',
    'can_barcode_manage': 'can_products',
    'can_view_activity_logs': 'can_audit',
    'can_export_reports': 'can_reports',
    'can_print_reports': 'can_print',
    'can_delete_records': 'can_product_delete',
}

_ORIG_INIT = AppService.__init__
_ORIG_ROLE_PERMISSIONS = AppService.role_permissions
_ORIG_USER_HAS = AppService.user_has
_ORIG_SAVE_USER = AppService.save_user
_ORIG_LIST_USERS = AppService.list_users
_ORIG_SAVE_PRODUCT = AppService.save_product
_ORIG_GET_PRODUCT_BY_BARCODE = AppService.get_product_by_barcode
_ORIG_COMPLETE_SALE = AppService.complete_sale
_ORIG_ADJUST_INVENTORY = AppService.adjust_inventory
_ORIG_DEACTIVATE_PRODUCT = getattr(AppService, 'deactivate_product', None)
_ORIG_PRINT_LABELS = getattr(AppService, 'print_barcode_labels_html', None)


def _safe_json(value: Any) -> str:
    try:
        return json.dumps(value, ensure_ascii=False, default=str, sort_keys=True)
    except Exception:
        return str(value)


def _row_dict(row: Any) -> dict[str, Any] | None:
    if row is None:
        return None
    if isinstance(row, dict):
        return dict(row)
    try:
        return {k: row[k] for k in row.keys()}
    except Exception:
        try:
            return dict(row)
        except Exception:
            return None


def _ensure_v4516_schema(self: AppService) -> None:
    for col in V4516_PERMISSIONS:
        try:
            self.db.add_column_if_missing('users', col, 'INTEGER NOT NULL DEFAULT 0')
        except Exception as exc:
            log_exception(exc, f'v45.16 add user permission {col}')
    try:
        self.db.conn.executescript('''
            CREATE TABLE IF NOT EXISTS audit_trail (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                username TEXT,
                action TEXT NOT NULL,
                entity_type TEXT,
                entity_id TEXT,
                before_json TEXT,
                after_json TEXT,
                details TEXT,
                source TEXT NOT NULL DEFAULT 'app',
                created_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_trail(created_at);
            CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_trail(user_id);
            CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_trail(entity_type, entity_id);
        ''')
        # Keep managers/admins fully enabled when upgrading old databases.
        set_sql = ', '.join(f'{c}=1' for c in V4516_PERMISSIONS)
        self.db.conn.execute(f"UPDATE users SET {set_sql} WHERE role='مدير' OR username='admin'")
        # Cashiers may scan barcodes but must not see profit/cost or edit price/qty.
        self.db.conn.execute("""
            UPDATE users
               SET can_scan_barcode=1,
                   can_view_profit=0,
                   can_view_cost=0,
                   can_price_edit=0,
                   can_quantity_edit=0,
                   can_barcode_manage=0
             WHERE role IN ('كاشير', 'موظف مبيعات')
        """)
        self.db.conn.commit()
    except Exception as exc:
        log_exception(exc, 'v45.16 schema')


def _init(self: AppService, db):
    _ORIG_INIT(self, db)
    _ensure_v4516_schema(self)


def _role_permissions(self: AppService, role: str):
    data = dict(_ORIG_ROLE_PERMISSIONS(self, role))
    for key in V4516_PERMISSIONS:
        data.setdefault(key, 0)
    if role in ('مدير', 'مدير النظام', 'admin'):
        for key in data:
            if key.startswith('can_'):
                data[key] = 1
    elif role in ('كاشير', 'موظف مبيعات'):
        data.update(
            can_sales=1, can_touch_pos=1, can_customers=1, can_discount=1, can_print=1,
            can_scan_barcode=1, can_view_profit=0, can_view_cost=0, can_price_edit=0,
            can_quantity_edit=0, can_barcode_manage=0, can_export_reports=0,
            can_print_reports=0, can_delete_records=0, can_view_activity_logs=0,
        )
    elif role == 'محاسب':
        data.update(
            can_reports=1, can_customers=1, can_tools=1, can_view_profit=1, can_view_cost=1,
            can_print=1, can_print_reports=1, can_export_reports=1, can_view_activity_logs=1,
            can_audit=1, can_price_edit=0, can_quantity_edit=0, can_barcode_manage=0,
            can_delete_records=0,
        )
    elif role == 'مخزن':
        data.update(
            can_products=1, can_inventory=1, can_suppliers=1, can_purchases=1,
            can_product_add=1, can_product_edit=1, can_quantity_edit=1,
            can_barcode_manage=1, can_scan_barcode=1, can_view_cost=1,
            can_view_profit=0, can_reports=0, can_users=0,
        )
    elif role == 'مشرف':
        data.update(
            can_sales=1, can_touch_pos=1, can_products=1, can_customers=1, can_returns=1,
            can_reports=1, can_tools=1, can_print=1, can_scan_barcode=1,
            can_barcode_manage=1, can_view_activity_logs=1, can_audit=1,
            can_view_profit=0, can_view_cost=0, can_users=0,
        )
    return data


def _user_has(self: AppService, user, permission: str) -> bool:
    if permission in V4516_PERMISSIONS:
        try:
            if self.is_admin_user(user):
                return True
            try:
                direct = bool(user[permission])
            except Exception:
                direct = bool(user.get(permission, 0)) if hasattr(user, 'get') else False
            if direct:
                return True
            alias = PERMISSION_ALIASES.get(permission)
            return bool(alias and _ORIG_USER_HAS(self, user, alias))
        except Exception:
            alias = PERMISSION_ALIASES.get(permission, permission)
            return bool(_ORIG_USER_HAS(self, user, alias))
    return _ORIG_USER_HAS(self, user, permission)


def _actor(self: AppService, user_id: int | None = None):
    try:
        return self._effective_user(user_id)
    except Exception:
        return None


def _audit(self: AppService, action: str, entity_type: str = '', entity_id: Any = None, before: Any = None, after: Any = None, details: str = '', user_id: int | None = None, source: str = 'app') -> None:
    try:
        user = _actor(self, user_id)
        uid = None
        username = ''
        if user:
            try:
                uid = int(user['id'])
                username = str(user['username'] or '')
            except Exception:
                pass
        self.db.execute(
            '''INSERT INTO audit_trail
               (user_id, username, action, entity_type, entity_id, before_json, after_json, details, source, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            (uid, username, action, entity_type, '' if entity_id is None else str(entity_id), _safe_json(before) if before is not None else None, _safe_json(after) if after is not None else None, str(details or ''), source, now_text()),
        )
        # Mirror important actions into the old visible activity log for compatibility.
        try:
            self.log(action, f'{entity_type} {entity_id or ""} {details or ""}'.strip(), uid, username)
        except Exception:
            pass
    except Exception as exc:
        log_exception(exc, f'v45.16 audit {action}')


def _list_activity_logs(self: AppService, limit: int = 300, term: str = '') -> list[dict[str, Any]]:
    self.require_any_permission(('can_view_activity_logs', 'can_audit', 'can_users'), action='عرض سجل الحركات')
    limit = max(1, min(int(limit or 300), 2000))
    term = str(term or '').strip()
    params: list[Any] = []
    where = ''
    if term:
        like = f'%{term}%'
        where = 'WHERE action LIKE ? OR entity_type LIKE ? OR entity_id LIKE ? OR username LIKE ? OR details LIKE ?'
        params.extend([like, like, like, like, like])
    rows = self.db.all(
        f'''SELECT id, user_id, username, action, entity_type, entity_id, details, source, created_at
              FROM audit_trail {where}
             ORDER BY id DESC LIMIT ?''',
        (*params, limit),
    )
    return [r for r in (_row_dict(x) for x in rows) if r]


def _save_user(self: AppService, data: dict, user_id: int | None = None) -> None:
    before = None
    if user_id:
        before = _row_dict(self.db.one('SELECT * FROM users WHERE id=?', (int(user_id),)))
    data = dict(data or {})
    out = _ORIG_SAVE_USER(self, data, user_id)
    try:
        target = self.db.one('SELECT * FROM users WHERE username=? ORDER BY id DESC LIMIT 1', (str(data.get('username') or '').strip(),))
        after = _row_dict(target)
        _audit(self, 'تعديل مستخدم' if user_id else 'إضافة مستخدم', 'user', after.get('id') if after else user_id, before, after, user_id=self.current_user_id)
    except Exception as exc:
        log_exception(exc, 'v45.16 audit save user')
    return out


def _list_users(self: AppService, include_inactive: bool = True):
    rows = _ORIG_LIST_USERS(self, include_inactive)
    return rows


def _ean13_check_digit(first_12_digits: str) -> str:
    digits = [int(x) for x in first_12_digits]
    checksum = sum(digits[::2]) + sum(d * 3 for d in digits[1::2])
    return str((10 - (checksum % 10)) % 10)


def _make_barcode(self: AppService, product_id: int | None = None) -> str:
    # 29 is an internal-use prefix often accepted by POS systems for local items.
    for _ in range(50):
        seed = int(time.time() * 1000) + random.randint(0, 9999)
        if product_id:
            seed += int(product_id) * 97
        base = ('29' + str(seed)[-10:]).rjust(12, '0')[-12:]
        code = base + _ean13_check_digit(base)
        if not self.db.one('SELECT id FROM products WHERE barcode=?', (code,)):
            return code
    raise RuntimeError('تعذر توليد باركود فريد، حاول مرة أخرى')


def _generate_barcode_value(self: AppService, product_id: int | None = None) -> str:
    self.require_any_permission(('can_barcode_manage', 'can_products', 'can_inventory'), action='توليد باركود')
    code = _make_barcode(self, product_id)
    if product_id:
        before = _row_dict(self.db.one('SELECT id, barcode, name FROM products WHERE id=?', (int(product_id),)))
        self.db.execute('UPDATE products SET barcode=? WHERE id=?', (code, int(product_id)))
        after = _row_dict(self.db.one('SELECT id, barcode, name FROM products WHERE id=?', (int(product_id),)))
        _audit(self, 'توليد باركود', 'product', product_id, before, after, f'barcode={code}', user_id=self.current_user_id)
    return code


def _get_product_by_barcode(self: AppService, barcode: str):
    self.require_any_permission(('can_scan_barcode', 'can_sales', 'can_touch_pos', 'can_products', 'can_purchases'), action='البحث بالباركود')
    code = str(barcode or '').strip()
    if not code:
        return None
    row = _ORIG_GET_PRODUCT_BY_BARCODE(self, code)
    if row:
        data = _row_dict(row) or row
        # Hide cost/profit-sensitive fields from cashiers while keeping sale price.
        user = _actor(self)
        if user and not self.user_has(user, 'can_view_cost'):
            try:
                data = dict(data)
                data['cost_price'] = 0
            except Exception:
                pass
        return data
    # Fallback: scanners may send leading/trailing spaces or a shorter numeric code.
    cleaned = ''.join(ch for ch in code if ch.isdigit()) or code
    if cleaned != code:
        row = _ORIG_GET_PRODUCT_BY_BARCODE(self, cleaned)
        return _row_dict(row) if row else None
    return None


def _save_product(self: AppService, data: dict, product_id: int | None = None) -> None:
    data = dict(data or {})
    is_new = not product_id
    user = _actor(self)
    if product_id:
        before = _row_dict(self.db.one('SELECT * FROM products WHERE id=?', (int(product_id),)))
        if before:
            if 'sale_price' in data and float(data.get('sale_price') or 0) != float(before.get('sale_price') or 0):
                self.require_any_permission(('can_price_edit', 'can_products'), action='تعديل سعر المنتج')
            if 'quantity' in data and int(float(data.get('quantity') or 0)) != int(float(before.get('quantity') or 0)):
                self.require_any_permission(('can_quantity_edit', 'can_inventory'), action='تعديل كمية المنتج')
    else:
        before = None
        self.require_any_permission(('can_product_add', 'can_products'), action='إضافة منتج')
    if not str(data.get('barcode') or '').strip():
        self.require_any_permission(('can_barcode_manage', 'can_products'), action='توليد باركود تلقائي')
        data['barcode'] = _make_barcode(self, product_id)
    out = _ORIG_SAVE_PRODUCT(self, data, product_id)
    try:
        if product_id:
            after = _row_dict(self.db.one('SELECT * FROM products WHERE id=?', (int(product_id),)))
            entity_id = product_id
        else:
            after = _row_dict(self.db.one('SELECT * FROM products WHERE barcode=? ORDER BY id DESC LIMIT 1', (str(data.get('barcode') or '').strip(),)))
            entity_id = after.get('id') if after else None
        _audit(self, 'إضافة منتج' if is_new else 'تعديل منتج', 'product', entity_id, before, after, user_id=self.current_user_id)
    except Exception as exc:
        log_exception(exc, 'v45.16 audit save product')
    return out


def _complete_sale(self: AppService, cart: list[dict], employee_id: int, customer_id: int | None, payment_method: str, discount_amount: float = 0, note: str = '', user_id: int | None = None, discount_type: str = 'amount') -> str:
    self.require_any_permission(('can_sales', 'can_touch_pos'), user_id, 'إصدار فاتورة')
    invoice = _ORIG_COMPLETE_SALE(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type)
    try:
        sale = _row_dict(self.db.one('SELECT * FROM sales WHERE invoice_no=?', (invoice,)))
        _audit(self, 'إصدار فاتورة', 'sale', invoice, None, {'sale': sale, 'items': cart}, user_id=user_id or self.current_user_id)
    except Exception as exc:
        log_exception(exc, 'v45.16 audit sale')
    return invoice


def _adjust_inventory(self: AppService, product_id: int, new_quantity: int, note: str = '', user_id: int | None = None) -> None:
    self.require_any_permission(('can_quantity_edit', 'can_adjust_product_qty', 'can_inventory'), user_id, 'تعديل المخزون')
    before = _row_dict(self.db.one('SELECT id, name, quantity FROM products WHERE id=?', (int(product_id),)))
    out = _ORIG_ADJUST_INVENTORY(self, product_id, new_quantity, note, user_id)
    after = _row_dict(self.db.one('SELECT id, name, quantity FROM products WHERE id=?', (int(product_id),)))
    _audit(self, 'تعديل مخزون', 'product', product_id, before, after, note, user_id=user_id or self.current_user_id)
    return out


def _deactivate_product(self: AppService, product_id: int) -> None:
    self.require_any_permission(('can_delete_records', 'can_product_delete'), action='تعطيل منتج')
    before = _row_dict(self.db.one('SELECT * FROM products WHERE id=?', (int(product_id),)))
    if _ORIG_DEACTIVATE_PRODUCT:
        out = _ORIG_DEACTIVATE_PRODUCT(self, product_id)
    else:
        out = self.db.execute('UPDATE products SET active=0 WHERE id=?', (int(product_id),))
    after = _row_dict(self.db.one('SELECT * FROM products WHERE id=?', (int(product_id),)))
    _audit(self, 'تعطيل منتج', 'product', product_id, before, after, user_id=self.current_user_id)
    return out


def _print_barcode_labels_html(self: AppService):
    self.require_any_permission(('can_barcode_manage', 'can_print', 'can_products'), action='طباعة ملصقات الباركود')
    if _ORIG_PRINT_LABELS:
        return _ORIG_PRINT_LABELS(self)
    raise RuntimeError('أداة طباعة الملصقات غير متوفرة')


def _barcode_security_health(self: AppService) -> dict[str, Any]:
    try:
        duplicates = self.db.all('''
            SELECT barcode, COUNT(*) c FROM products
             WHERE barcode IS NOT NULL AND TRIM(barcode)<>''
             GROUP BY barcode HAVING COUNT(*) > 1
        ''')
        logs_count = self.db.one('SELECT COUNT(*) c FROM audit_trail')
        return {
            'version': 'v45.16',
            'advanced_permissions': list(V4516_PERMISSIONS.keys()),
            'audit_trail_rows': int(logs_count['c'] if logs_count else 0),
            'barcode_auto_generation': True,
            'barcode_scanner_lookup': True,
            'duplicate_barcodes': [dict(r) for r in duplicates],
        }
    except Exception as exc:
        return {'version': 'v45.16', 'error': str(exc)}


AppService.__init__ = _init
AppService.role_permissions = _role_permissions
AppService.user_has = _user_has
AppService.save_user = _save_user
AppService.list_users = _list_users
AppService.save_product = _save_product
AppService.generate_barcode_value = _generate_barcode_value
AppService.get_product_by_barcode = _get_product_by_barcode
AppService.complete_sale = _complete_sale
AppService.adjust_inventory = _adjust_inventory
AppService.deactivate_product = _deactivate_product
AppService.print_barcode_labels_html = _print_barcode_labels_html
AppService.record_audit = _audit
AppService.list_activity_logs = _list_activity_logs
AppService.barcode_security_health = _barcode_security_health

log_message('V45.16 permissions, audit, and barcode patch loaded', 'info')
