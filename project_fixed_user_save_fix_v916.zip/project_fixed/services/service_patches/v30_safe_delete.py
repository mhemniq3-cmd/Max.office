from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})
import services.service_patches.v19_gdrive as _prev_v19_gdrive
globals().update({k: v for k, v in vars(_prev_v19_gdrive).items() if not k.startswith('__')})
import services.service_patches.v20_gdrive_settings as _prev_v20_gdrive_settings
globals().update({k: v for k, v in vars(_prev_v20_gdrive_settings).items() if not k.startswith('__')})
import services.service_patches.v21_backup as _prev_v21_backup
globals().update({k: v for k, v in vars(_prev_v21_backup).items() if not k.startswith('__')})
import services.service_patches.v22_gdrive_final as _prev_v22_gdrive_final
globals().update({k: v for k, v in vars(_prev_v22_gdrive_final).items() if not k.startswith('__')})
import services.service_patches.v23_business_tools as _prev_v23_business_tools
globals().update({k: v for k, v in vars(_prev_v23_business_tools).items() if not k.startswith('__')})
import services.service_patches.v24_smart_assistant as _prev_v24_smart_assistant
globals().update({k: v for k, v in vars(_prev_v24_smart_assistant).items() if not k.startswith('__')})
import services.service_patches.v25_readiness as _prev_v25_readiness
globals().update({k: v for k, v in vars(_prev_v25_readiness).items() if not k.startswith('__')})
import services.service_patches.v25_1_barcode as _prev_v25_1_barcode
globals().update({k: v for k, v in vars(_prev_v25_1_barcode).items() if not k.startswith('__')})
import services.service_patches.v26_tools_repair as _prev_v26_tools_repair
globals().update({k: v for k, v in vars(_prev_v26_tools_repair).items() if not k.startswith('__')})
import services.service_patches.v26_1_tools_stability as _prev_v26_1_tools_stability
globals().update({k: v for k, v in vars(_prev_v26_1_tools_stability).items() if not k.startswith('__')})
import services.service_patches.v27_pricing_excel_qr as _prev_v27_pricing_excel_qr
globals().update({k: v for k, v in vars(_prev_v27_pricing_excel_qr).items() if not k.startswith('__')})

# ---------------------------------------------------------------------------
# V30 Widgets cleanup: safe delete actions for users, customers and products
# ---------------------------------------------------------------------------
def _v30_count(self: AppService, query: str, params=()) -> int:
    try:
        row = self.db.one(query, params)
        return int(row[0] if row is not None else 0)
    except Exception:
        return 0


def _v30_delete_or_deactivate_user(self: AppService, user_id: int, actor_user_id: int | None = None) -> str:
    self.require_permission('can_users', actor_user_id, 'حذف مستخدم')
    uid = int(user_id or 0)
    if not uid:
        raise ValueError('اختر المستخدم أولاً')
    actor = self._effective_user(actor_user_id)
    if actor and int(actor['id']) == uid:
        raise ValueError('لا يمكن حذف أو تعطيل المستخدم الحالي')
    user = self.db.one('SELECT * FROM users WHERE id=?', (uid,))
    if not user:
        raise ValueError('المستخدم غير موجود')
    if str(user['username']).lower() == 'admin':
        raise ValueError('لا يمكن حذف المستخدم الرئيسي admin')
    refs = 0
    for table, col in [('sales', 'user_id'), ('purchases', 'user_id'), ('audit_logs', 'user_id'), ('operation_logs', 'user_id'), ('cashier_shifts', 'user_id'), ('daily_closings', 'user_id')]:
        refs += _v30_count(self, f'SELECT COUNT(*) FROM {table} WHERE {col}=?', (uid,))
    if refs:
        self.db.execute('UPDATE users SET active=0 WHERE id=?', (uid,))
        self.log('تعطيل مستخدم', f"{user['username']} - لديه سجلات مرتبطة", actor_user_id)
        return 'تم تعطيل المستخدم لأنه مرتبط بسجلات مالية أو تدقيق، ولم يتم حذفه نهائياً حفاظاً على الأرشيف.'
    self.db.execute('DELETE FROM users WHERE id=?', (uid,))
    self.log('حذف مستخدم', str(user['username']), actor_user_id)
    return 'تم حذف المستخدم نهائياً.'


def _v30_delete_or_deactivate_customer(self: AppService, customer_id: int, actor_user_id: int | None = None) -> str:
    self.require_permission('can_customers', actor_user_id, 'حذف زبون')
    cid = int(customer_id or 0)
    if not cid:
        raise ValueError('اختر الزبون أولاً')
    customer = self.db.one('SELECT * FROM customers WHERE id=?', (cid,))
    if not customer:
        raise ValueError('الزبون غير موجود')
    refs = 0
    for table, col in [('sales', 'customer_id'), ('returns', 'customer_id'), ('customer_payments', 'customer_id'), ('suspended_sales', 'customer_id')]:
        refs += _v30_count(self, f'SELECT COUNT(*) FROM {table} WHERE {col}=?', (cid,))
    if refs:
        self.db.execute('UPDATE customers SET active=0 WHERE id=?', (cid,))
        self.log('تعطيل زبون', f"{customer['name']} - لديه معاملات مرتبطة", actor_user_id)
        return 'تم تعطيل الزبون لأنه مرتبط بفواتير أو دفعات، ولم يتم حذفه نهائياً حفاظاً على الحسابات.'
    self.db.execute('DELETE FROM customers WHERE id=?', (cid,))
    self.log('حذف زبون', str(customer['name']), actor_user_id)
    return 'تم حذف الزبون نهائياً.'


def _v30_delete_or_deactivate_product(self: AppService, product_id: int, actor_user_id: int | None = None) -> str:
    self.require_permission('can_product_delete', actor_user_id, 'حذف منتج')
    pid = int(product_id or 0)
    if not pid:
        raise ValueError('اختر المنتج أولاً')
    product = self.db.one('SELECT * FROM products WHERE id=?', (pid,))
    if not product:
        raise ValueError('المنتج غير موجود')
    refs = 0
    for table, col in [('sale_items', 'product_id'), ('returns', 'product_id'), ('purchase_items', 'product_id'), ('inventory_movements', 'product_id'), ('product_price_levels', 'product_id'), ('promotions', 'product_id'), ('inventory_counts', 'product_id')]:
        refs += _v30_count(self, f'SELECT COUNT(*) FROM {table} WHERE {col}=?', (pid,))
    if refs:
        self.db.execute('UPDATE products SET active=0 WHERE id=?', (pid,))
        self.log('تعطيل منتج', f"{product['name']} - لديه معاملات مرتبطة", actor_user_id)
        return 'تم تعطيل المنتج لأنه مرتبط بحركات مخزون أو فواتير، ولم يتم حذفه نهائياً حفاظاً على التقارير.'
    self.db.execute('DELETE FROM products WHERE id=?', (pid,))
    self.log('حذف منتج', str(product['name']), actor_user_id)
    return 'تم حذف المنتج نهائياً.'


AppService.delete_or_deactivate_user = _v30_delete_or_deactivate_user
AppService.delete_or_deactivate_customer = _v30_delete_or_deactivate_customer
AppService.delete_or_deactivate_product = _v30_delete_or_deactivate_product

