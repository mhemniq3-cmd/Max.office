from __future__ import annotations

"""V45.17.3 deep report fixes.

Built strictly on the v45.17 line. This patch addresses the latest manual code
review notes without pulling any v45.18/v45.19 UI redesign changes.
"""

import os
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

from services.app_core import AppService
from services.error_logger import log_exception

_ORIG_INIT = AppService.__init__
_ORIG_GET_PRODUCT_BY_BARCODE = getattr(AppService, 'get_product_by_barcode', None)
_ORIG_BACKUP_DATABASE = getattr(AppService, 'backup_database', None)
_ORIG_BACKUP_DIR = getattr(AppService, 'backup_dir', None)
_ORIG_IS_PERIOD_CLOSED = getattr(AppService, 'is_fiscal_period_closed', None)
_ORIG_PROFIT_SUMMARY = getattr(AppService, 'profit_summary', None)


def _safe_rowdict(row: Any) -> dict[str, Any]:
    if row is None:
        return {}
    if isinstance(row, dict):
        return dict(row)
    try:
        return dict(row)
    except Exception:
        try:
            return {k: row[k] for k in row.keys()}
        except Exception:
            return {}


def _normalize_date_v45173(value: str | None) -> str:
    text = str(value or '').strip()
    if not text:
        return ''
    text = text.translate(str.maketrans('٠١٢٣٤٥٦٧٨٩', '0123456789'))
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d-%m-%Y', '%Y/%m/%d'):
        try:
            return datetime.strptime(text, fmt).strftime('%Y-%m-%d')
        except ValueError:
            pass
    raise ValueError('صيغة التاريخ غير صحيحة. استخدم YYYY-MM-DD أو DD/MM/YYYY')


def _ensure_column(conn: sqlite3.Connection, table: str, column: str, ddl: str) -> None:
    cols = {r[1] for r in conn.execute(f'PRAGMA table_info({table})')}
    if column not in cols:
        conn.execute(f'ALTER TABLE {table} ADD COLUMN {column} {ddl}')


def _ensure_v45173_schema(self: AppService) -> None:
    """Create missing compatibility objects and keep them executable, not comments."""
    conn = self.db.conn
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            payment_date TEXT NOT NULL DEFAULT (date('now')),
            payment_type TEXT NOT NULL DEFAULT 'قبض',
            amount REAL NOT NULL DEFAULT 0 CHECK(amount >= 0),
            payment_method TEXT NOT NULL DEFAULT 'نقدي',
            related_type TEXT,
            related_id INTEGER,
            customer_id INTEGER,
            supplier_id INTEGER,
            description TEXT,
            note TEXT,
            user_id INTEGER,
            user_name TEXT NOT NULL DEFAULT '',
            source_table TEXT,
            source_id INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(source_table, source_id)
        );
        CREATE INDEX IF NOT EXISTS idx_payments_payment_date_v45173 ON payments(payment_date);
        CREATE INDEX IF NOT EXISTS idx_payments_customer_v45173 ON payments(customer_id);
        CREATE INDEX IF NOT EXISTS idx_payments_supplier_v45173 ON payments(supplier_id);
        CREATE INDEX IF NOT EXISTS idx_payments_source_v45173 ON payments(source_table, source_id);

        CREATE TABLE IF NOT EXISTS fiscal_periods (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            year INTEGER NOT NULL,
            month INTEGER NOT NULL,
            is_closed INTEGER NOT NULL DEFAULT 0,
            closed_at TEXT,
            closed_by_user_id INTEGER,
            note TEXT,
            UNIQUE(year, month)
        );

        CREATE TRIGGER IF NOT EXISTS trg_products_no_negative_qty_v45173
        BEFORE UPDATE OF quantity ON products
        FOR EACH ROW WHEN NEW.quantity < 0
        BEGIN
            SELECT RAISE(ABORT, 'لا يمكن أن تصبح كمية المخزون سالبة');
        END;
        CREATE TRIGGER IF NOT EXISTS trg_products_no_negative_insert_qty_v45173
        BEFORE INSERT ON products
        FOR EACH ROW WHEN NEW.quantity < 0
        BEGIN
            SELECT RAISE(ABORT, 'كمية المنتج لا يمكن أن تكون سالبة');
        END;
    ''')
    # Compatibility aliases for older code/reports that may refer to min_stock/max_stock.
    try:
        _ensure_column(conn, 'products', 'min_stock', 'INTEGER NOT NULL DEFAULT 0')
        _ensure_column(conn, 'products', 'max_stock', 'INTEGER NOT NULL DEFAULT 0')
        conn.execute('UPDATE products SET min_stock=COALESCE(NULLIF(min_stock,0), min_quantity, 0)')
    except Exception as exc:
        log_exception(exc, 'v45.17.3 product stock alias columns')

    # Mirror old customer/supplier payments into the generic payments table safely.
    try:
        conn.execute('''
            INSERT OR IGNORE INTO payments
            (payment_date, payment_type, amount, payment_method, related_type, related_id,
             customer_id, description, note, user_name, source_table, source_id, created_at)
            SELECT date(created_at), 'قبض', amount, 'نقدي', 'عميل', customer_id,
                   customer_id, note, note, '', 'customer_payments', id, created_at
            FROM customer_payments
            WHERE amount >= 0
        ''')
    except Exception as exc:
        log_exception(exc, 'v45.17.3 customer payments mirror')
    try:
        conn.execute('''
            INSERT OR IGNORE INTO payments
            (payment_date, payment_type, amount, payment_method, related_type, related_id,
             supplier_id, description, note, user_id, user_name, source_table, source_id, created_at)
            SELECT date(created_at), 'صرف', amount, 'نقدي', 'مورد', supplier_id,
                   supplier_id, note, note, user_id, '', 'supplier_payments', id, created_at
            FROM supplier_payments
            WHERE amount >= 0
        ''')
    except Exception as exc:
        log_exception(exc, 'v45.17.3 supplier payments mirror')
    conn.commit()


def _is_fiscal_period_closed_v45173(self: AppService, date_text: str | None = None) -> bool:
    """Correct logic: 1 means closed, 0 means open."""
    try:
        normalized = _normalize_date_v45173(date_text) if date_text else datetime.now().strftime('%Y-%m-%d')
        dt = datetime.strptime(normalized[:10], '%Y-%m-%d')
        row = self.db.one('SELECT is_closed FROM fiscal_periods WHERE year=? AND month=?', (dt.year, dt.month))
        return bool(row and int(row['is_closed'] or 0) == 1)
    except Exception:
        return False


def _assert_fiscal_open_v45173(self: AppService, date_text: str | None = None, action: str = 'تعديل') -> None:
    if _is_fiscal_period_closed_v45173(self, date_text):
        raise ValueError(f'لا يمكن {action} بيانات فترة مالية مقفولة')


def _backup_dir_v45173(self: AppService) -> Path:
    # Outside the application folder so updates/deletes do not wipe backups.
    path = Path(os.path.expanduser('~/MaxSales_Backups')).resolve()
    path.mkdir(parents=True, exist_ok=True)
    return path


def _backup_database_v45173(self: AppService, *args, **kwargs) -> Path:
    try:
        self.require_permission('can_backup', action='إنشاء نسخة احتياطية')
    except TypeError:
        self.require_permission('can_backup', None, 'إنشاء نسخة احتياطية')
    target = _backup_dir_v45173(self) / f'max_sales_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.db'
    backup_conn = None
    try:
        backup_conn = sqlite3.connect(target)
        self.db.conn.backup(backup_conn)
    finally:
        if backup_conn is not None:
            backup_conn.close()
    backups = sorted(_backup_dir_v45173(self).glob('max_sales_backup_*.db'), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[10:]:
        try:
            old.unlink()
        except Exception as exc:
            log_exception(exc, 'v45.17.3 backup cleanup')
    try:
        self.log('نسخة احتياطية', str(target))
    except Exception:
        pass
    return target


def _get_product_by_barcode_v45173(self: AppService, barcode: str):
    text = str(barcode or '').strip()
    if not text:
        return None
    # Avoid crashes from scanners/keyboards sending unexpected control chars.
    cleaned = ''.join(ch for ch in text if ch.isalnum() or ch in ('-', '_'))[:80]
    if not cleaned:
        return None
    if _ORIG_GET_PRODUCT_BY_BARCODE:
        try:
            row = _ORIG_GET_PRODUCT_BY_BARCODE(self, cleaned)
            if row:
                return row
        except ValueError:
            return None
        except Exception as exc:
            log_exception(exc, 'v45.17.3 original barcode lookup')
    row = self.db.one('SELECT * FROM products WHERE active=1 AND barcode=? LIMIT 1', (cleaned,))
    return row


def _sales_report_by_category_v45173(self: AppService, category: str, date_from: str = '', date_to: str = '', limit: int = 500, offset: int = 0) -> list[dict[str, Any]]:
    """Safe category report, parameterized to avoid SQL injection."""
    self.require_permission('can_reports', action='تقرير المبيعات حسب الصنف')
    cat_name = str(category or '').strip()
    where = ["s.status='completed'", 'p.category = ?']
    params: list[Any] = [cat_name]
    if date_from:
        where.append('date(s.created_at) >= date(?)')
        params.append(_normalize_date_v45173(date_from))
    if date_to:
        where.append('date(s.created_at) <= date(?)')
        params.append(_normalize_date_v45173(date_to))
    try:
        limit_i = max(1, min(int(limit), 1000))
    except Exception:
        limit_i = 500
    try:
        offset_i = max(0, int(offset))
    except Exception:
        offset_i = 0
    sql = '''
        SELECT p.category, si.product_id, si.product_name,
               SUM(si.quantity) quantity,
               SUM(si.line_total) total,
               SUM(COALESCE(si.profit_amount, (si.unit_price-si.cost_price)*si.quantity)) profit
          FROM sale_items si
          JOIN sales s ON s.id=si.sale_id
          JOIN products p ON p.id=si.product_id
         WHERE ''' + ' AND '.join(where) + '''
         GROUP BY p.category, si.product_id, si.product_name
         ORDER BY total DESC
         LIMIT ? OFFSET ?
    '''
    return [dict(r) for r in self.db.all(sql, (*params, limit_i, offset_i))]


def _profit_summary_v45173(self: AppService, date_from: str = '', date_to: str = '') -> dict[str, Any]:
    """Profit from real line cost, not total sales."""
    try:
        self.require_permission('can_reports', action='عرض الأرباح')
    except TypeError:
        self.require_permission('can_reports')
    where = ["s.status='completed'"]
    params: list[Any] = []
    if date_from:
        where.append('date(s.created_at) >= date(?)')
        params.append(_normalize_date_v45173(date_from))
    if date_to:
        where.append('date(s.created_at) <= date(?)')
        params.append(_normalize_date_v45173(date_to))
    row = self.db.one('''
        SELECT COUNT(DISTINCT s.id) invoices,
               COALESCE(SUM(si.line_total),0) sales,
               COALESCE(SUM((si.unit_price - si.cost_price) * si.quantity),0) gross_profit,
               COALESCE(SUM(s.discount_amount),0) discounts
          FROM sales s
          JOIN sale_items si ON si.sale_id=s.id
         WHERE ''' + ' AND '.join(where), params)
    data = _safe_rowdict(row)
    return {
        'invoices': int(data.get('invoices') or 0),
        'sales': float(data.get('sales') or 0),
        'profit': float(data.get('gross_profit') or 0) - float(data.get('discounts') or 0),
        'discounts': float(data.get('discounts') or 0),
    }


def _update_cost_average_v45173(self: AppService, product_id: int, new_qty: int, new_price: float) -> float:
    """Weighted average cost with denominator old_qty + new_qty."""
    row = self.db.one('SELECT quantity, cost_price FROM products WHERE id=?', (int(product_id),))
    if not row:
        raise ValueError('المنتج غير موجود')
    old_qty = int(row['quantity'] or 0)
    old_cost = float(row['cost_price'] or 0)
    qty = int(new_qty or 0)
    if qty <= 0:
        return old_cost
    denominator = old_qty + qty
    if denominator <= 0:
        return float(new_price or 0)
    return ((old_cost * old_qty) + (float(new_price or 0) * qty)) / denominator


def _security_health_v45173(self: AppService) -> dict[str, Any]:
    payments = self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name='payments'")
    aliases = {r[1] for r in self.db.conn.execute('PRAGMA table_info(products)')}
    return {
        'version': 'v45.17.3',
        'payments_table_exists': bool(payments),
        'stock_alias_columns': {'min_stock': 'min_stock' in aliases, 'max_stock': 'max_stock' in aliases},
        'fiscal_period_logic': '1=closed, 0=open',
        'backup_dir': str(_backup_dir_v45173(self)),
        'barcode_input_guard': True,
        'category_report_parameterized': True,
    }


def _init_v45173(self: AppService, *args, **kwargs):
    _ORIG_INIT(self, *args, **kwargs)
    try:
        _ensure_v45173_schema(self)
    except Exception as exc:
        log_exception(exc, 'v45.17.3 schema init')


AppService.__init__ = _init_v45173
AppService.get_product_by_barcode = _get_product_by_barcode_v45173
AppService.backup_dir = _backup_dir_v45173
AppService.backup_database = _backup_database_v45173
AppService.is_fiscal_period_closed = _is_fiscal_period_closed_v45173
AppService.assert_fiscal_open = _assert_fiscal_open_v45173
AppService.sales_report_by_category = _sales_report_by_category_v45173
AppService.profit_summary = _profit_summary_v45173
AppService.update_cost_average = _update_cost_average_v45173
AppService.normalize_search_date = staticmethod(_normalize_date_v45173)
AppService.security_health_v45173 = _security_health_v45173
