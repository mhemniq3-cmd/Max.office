from __future__ import annotations

import json
import time
from datetime import datetime
from typing import Any

from services.app_service import AppService
from services.error_logger import log_exception

_ORIG_LIST_UNIFIED = getattr(AppService, 'list_unified_movements', None)
_ORIG_SYNC_LIGHT = getattr(AppService, 'sync_unified_movements_light', None)
_ORIG_SYNC = getattr(AppService, 'sync_unified_movements', None)
_ORIG_MARK_READ = getattr(AppService, 'mark_movements_read', None)
_ORIG_ADD_NOTE = getattr(AppService, 'add_movement_manager_note', None)

_CACHE_TTL_SECONDS = 20


def _safe_text(value: Any, max_len: int = 200) -> str:
    text = '' if value is None else str(value).strip()
    return text.replace('\x00', '')[:max_len]


def _bounded_int(value: Any, default: int, low: int, high: int) -> int:
    try:
        number = int(value)
    except Exception:
        number = default
    return max(low, min(number, high))


def _table_exists(self: AppService, table: str) -> bool:
    try:
        row = self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
        return bool(row)
    except Exception:
        return False


def _clear_movement_cache(self: AppService) -> None:
    try:
        self._v463_movement_cache = {}
    except Exception:
        pass


def _cache_key(limit: int, filters: dict[str, Any]) -> str:
    safe = {str(k): filters.get(k) for k in sorted(filters.keys()) if k not in {'auto_sync'}}
    return json.dumps({'limit': limit, 'filters': safe}, ensure_ascii=False, sort_keys=True, default=str)


def _list_unified_movements_cached(self: AppService, limit: int = 100, **filters) -> list[dict[str, Any]]:
    """Cached, paginated movement read for the Tools center.

    The cache is intentionally short-lived and is cleared by sync/read/note writes.
    It reduces repeated SQL hits when the user switches between filters or returns
    to the same page without changing data.
    """
    if _ORIG_LIST_UNIFIED is None:
        return []
    limit = _bounded_int(limit, 100, 25, 500)
    key = _cache_key(limit, dict(filters))
    now = time.monotonic()
    cache = getattr(self, '_v463_movement_cache', None)
    if not isinstance(cache, dict):
        cache = {}
        self._v463_movement_cache = cache
    hit = cache.get(key)
    if hit and now - hit.get('time', 0) <= _CACHE_TTL_SECONDS:
        return [dict(r) for r in hit.get('rows', [])]
    rows = _ORIG_LIST_UNIFIED(self, limit, **filters)
    clean_rows = [dict(r) for r in rows]
    cache[key] = {'time': now, 'rows': clean_rows}
    if len(cache) > 40:
        oldest = sorted(cache.items(), key=lambda kv: kv[1].get('time', 0))[:10]
        for old_key, _ in oldest:
            cache.pop(old_key, None)
    return [dict(r) for r in clean_rows]


def _sync_unified_movements_light_clear_cache(self: AppService, limit: int = 500, days: int = 14) -> int:
    try:
        if _ORIG_SYNC_LIGHT is not None:
            result = _ORIG_SYNC_LIGHT(self, limit=limit, days=days)
        elif _ORIG_SYNC is not None:
            result = _ORIG_SYNC(self, limit=limit, days=days)
        else:
            result = 0
        _clear_movement_cache(self)
        return int(result or 0)
    except Exception as exc:
        log_exception(exc, 'v46.3 light movement sync')
        raise


def _mark_movements_read_clear_cache(self: AppService, *args, **kwargs) -> int:
    if _ORIG_MARK_READ is None:
        return 0
    result = _ORIG_MARK_READ(self, *args, **kwargs)
    _clear_movement_cache(self)
    return int(result or 0)


def _add_movement_manager_note_history(self: AppService, movement_id: int, note: str) -> None:
    if _ORIG_ADD_NOTE is None:
        return
    note = _safe_text(note, 700)
    current = ''
    try:
        if _table_exists(self, 'unified_movement_log'):
            row = self.db.one('SELECT manager_note FROM unified_movement_log WHERE id=?', (int(movement_id),))
            current = str(row['manager_note'] or '') if row else ''
    except Exception:
        current = ''
    user = getattr(self, 'current_user_name', '') or 'مدير'
    stamped = f"[{datetime.now().strftime('%Y-%m-%d %H:%M')}] {user}: {note}"
    merged = (current + '\n' + stamped).strip() if current else stamped
    # Write directly so note-history line breaks are preserved. Older helper
    # normalizes newlines to spaces, which loses the history structure.
    self.db.conn.execute('UPDATE unified_movement_log SET manager_note=? WHERE id=?', (merged[:3000], int(movement_id)))
    self.db.conn.commit()
    _clear_movement_cache(self)


def _movement_active_users(self: AppService) -> list[str]:
    if not _table_exists(self, 'unified_movement_log'):
        return []
    rows = self.db.all('''
        SELECT DISTINCT COALESCE(NULLIF(TRIM(user_name), ''), 'غير محدد') AS user_name
          FROM unified_movement_log
         WHERE user_name IS NOT NULL AND TRIM(user_name) <> ''
         ORDER BY user_name
         LIMIT 300
    ''')
    return [str(r['user_name']) for r in rows]


def _movement_record_types(self: AppService) -> list[str]:
    if not _table_exists(self, 'unified_movement_log'):
        return []
    rows = self.db.all('''
        SELECT DISTINCT record_type
          FROM unified_movement_log
         WHERE record_type IS NOT NULL AND TRIM(record_type) <> ''
         ORDER BY record_type
         LIMIT 200
    ''')
    return [str(r['record_type']) for r in rows]


def _get_unified_movement_details(self: AppService, movement_id: int) -> dict[str, Any]:
    if not _table_exists(self, 'unified_movement_log'):
        return {}
    row = self.db.one('''
        SELECT id, event_key, event_time, user_id, user_name, module, action, record_type, record_id,
               description, old_values, new_values, severity, source_table, source_id, is_sensitive, is_read, manager_note
          FROM unified_movement_log
         WHERE id=?
    ''', (int(movement_id),))
    if not row:
        return {}
    data = dict(row)
    note_text = str(data.get('manager_note') or '')
    data['manager_notes_history'] = [line for line in note_text.splitlines() if line.strip()]
    return data


def _related_unified_movements(self: AppService, movement_id: int | None = None, **filters) -> list[dict[str, Any]]:
    if not _table_exists(self, 'unified_movement_log'):
        return []
    base = None
    if movement_id is not None:
        base = _get_unified_movement_details(self, int(movement_id))
    record_type = _safe_text(filters.get('record_type') or (base or {}).get('record_type'), 80)
    record_id = _safe_text(filters.get('record_id') or (base or {}).get('record_id'), 80)
    source_table = _safe_text(filters.get('source_table') or (base or {}).get('source_table'), 80)
    source_id = _safe_text(filters.get('source_id') or (base or {}).get('source_id'), 80)
    event_key = _safe_text(filters.get('event_key') or (base or {}).get('event_key'), 120)
    clauses: list[str] = []
    params: list[Any] = []
    if record_type and record_id:
        clauses.append('(record_type=? AND CAST(record_id AS TEXT)=?)')
        params.extend([record_type, record_id])
    if source_table and source_id:
        clauses.append('(source_table=? AND CAST(source_id AS TEXT)=?)')
        params.extend([source_table, source_id])
    if event_key:
        clauses.append('event_key=?')
        params.append(event_key)
    if not clauses:
        return []
    where = ' OR '.join(clauses)
    if movement_id is not None:
        where = f'({where}) AND id<>?'
        params.append(int(movement_id))
    rows = self.db.all(f'''
        SELECT id, event_time, user_name, module, action, record_type, record_id, description, severity, source_table, source_id
          FROM unified_movement_log
         WHERE {where}
         ORDER BY datetime(event_time) DESC, id DESC
         LIMIT 50
    ''', tuple(params))
    return [dict(r) for r in rows]


AppService.list_unified_movements = _list_unified_movements_cached
AppService.sync_unified_movements_light = _sync_unified_movements_light_clear_cache
AppService.mark_movements_read = _mark_movements_read_clear_cache
AppService.add_movement_manager_note = _add_movement_manager_note_history
AppService.movement_active_users = _movement_active_users
AppService.movement_record_types = _movement_record_types
AppService.get_unified_movement_details = _get_unified_movement_details
AppService.related_unified_movements = _related_unified_movements
AppService.clear_movement_cache = _clear_movement_cache
