from __future__ import annotations

import json
import re
from typing import Any

from services.app_service import AppService
from services.error_logger import log_exception

_ORIG_LIST = getattr(AppService, 'list_unified_movements', None)
_ORIG_GET = getattr(AppService, 'get_unified_movement_details', None)
_ORIG_RELATED = getattr(AppService, 'related_unified_movements', None)


def _table_exists(self: AppService, table: str) -> bool:
    try:
        return bool(self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)))
    except Exception:
        return False


def _column_exists(self: AppService, table: str, column: str) -> bool:
    try:
        return any(str(r['name']) == column for r in self.db.all(f'PRAGMA table_info({table})'))
    except Exception:
        return False


def _safe_text(value: Any, max_len: int = 500) -> str:
    text = '' if value is None else str(value).strip()
    return text.replace('\x00', '')[:max_len]


def _as_int(value: Any) -> int | None:
    try:
        if value is None or str(value).strip() == '':
            return None
        return int(float(str(value).strip()))
    except Exception:
        return None


def _money(value: Any) -> str:
    try:
        number = float(value or 0)
    except Exception:
        number = 0.0
    if abs(number - int(number)) < 0.001:
        return f'{int(number):,}'
    return f'{number:,.2f}'


def _first_invoice_text(*values: Any) -> str:
    text = ' '.join(_safe_text(v, 1500) for v in values if v is not None)
    if not text:
        return ''
    patterns = [
        r'(?:فاتورة|الفاتورة|invoice|INV|بيع)\s*[:#\-]?\s*([A-Za-z0-9_\-/]+)',
        r'\b(MAX[-_/]?[0-9A-Za-z_\-/]+)\b',
    ]
    for pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            return m.group(1).strip()
    return ''


def _sale_from_row(self: AppService, row: dict[str, Any]) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    if not _table_exists(self, 'sales'):
        return None, []
    sale_id: int | None = None
    invoice_no = ''
    record_type = _safe_text(row.get('record_type'), 80).lower()
    source_table = _safe_text(row.get('source_table'), 80).lower()
    record_id = _safe_text(row.get('record_id'), 120)
    source_id = _safe_text(row.get('source_id'), 120)
    description = _safe_text(row.get('description'), 2000)
    old_values = _safe_text(row.get('old_values'), 2000)
    new_values = _safe_text(row.get('new_values'), 2000)

    if record_type in {'sale', 'sales', 'invoice', 'فاتورة', 'بيع'}:
        sale_id = _as_int(record_id)
        if sale_id is None:
            invoice_no = record_id
    elif source_table in {'sales', 'sale'}:
        sale_id = _as_int(source_id) or _as_int(record_id)
    elif record_type in {'sale_item', 'sale_items', 'سطر فاتورة'} or source_table == 'sale_items':
        item_id = _as_int(source_id) or _as_int(record_id)
        if item_id and _table_exists(self, 'sale_items'):
            item = self.db.one('SELECT sale_id FROM sale_items WHERE id=?', (item_id,))
            if item:
                sale_id = _as_int(item['sale_id'])
    elif source_table in {'inventory_movements'}:
        # Inventory rows often store invoice reference in ref_no/description.
        invoice_no = _first_invoice_text(description)

    if not invoice_no:
        invoice_no = _first_invoice_text(record_id, source_id, description, old_values, new_values)

    sale_sql = '''
        SELECT s.*,
               COALESCE(NULLIF(u.full_name,''), u.username, '') AS seller_name,
               COALESCE(NULLIF(e.name,''), '') AS employee_name,
               COALESCE(NULLIF(c.name,''), 'زبون عام') AS customer_name
          FROM sales s
          LEFT JOIN users u ON u.id=s.user_id
          LEFT JOIN employees e ON e.id=s.employee_id
          LEFT JOIN customers c ON c.id=s.customer_id
    '''
    sale = None
    try:
        if sale_id is not None:
            sale = self.db.one(sale_sql + ' WHERE s.id=? LIMIT 1', (sale_id,))
        if not sale and invoice_no:
            sale = self.db.one(sale_sql + ' WHERE s.invoice_no=? LIMIT 1', (invoice_no,))
    except Exception:
        sale = None
    if not sale:
        return None, []
    sale_dict = dict(sale)
    items: list[dict[str, Any]] = []
    if _table_exists(self, 'sale_items'):
        try:
            items = [dict(r) for r in self.db.all('SELECT * FROM sale_items WHERE sale_id=? ORDER BY id', (int(sale_dict.get('id') or 0),))]
        except Exception:
            items = []
    return sale_dict, items


def _product_from_row(self: AppService, row: dict[str, Any]) -> dict[str, Any] | None:
    if not _table_exists(self, 'products'):
        return None
    record_type = _safe_text(row.get('record_type'), 80).lower()
    record_id = _as_int(row.get('record_id'))
    if record_type not in {'products', 'product', 'منتج', 'مادة'} or record_id is None:
        return None
    try:
        product = self.db.one('SELECT id, barcode, name, category, quantity, sale_price, cost_price FROM products WHERE id=?', (record_id,))
        return dict(product) if product else None
    except Exception:
        return None


def _item_summary(items: list[dict[str, Any]], max_items: int = 4) -> str:
    parts: list[str] = []
    for item in items[:max_items]:
        name = _safe_text(item.get('product_name') or item.get('name'), 80)
        qty = _safe_text(item.get('quantity'), 20)
        total = _money(item.get('line_total'))
        parts.append(f'{name} × {qty} = {total}')
    if len(items) > max_items:
        parts.append(f'... +{len(items) - max_items}')
    return ' | '.join(parts)


def _enrich_row(self: AppService, row: dict[str, Any]) -> dict[str, Any]:
    out = dict(row)
    try:
        sale, items = _sale_from_row(self, out)
        if sale:
            qty = sum(float(i.get('quantity') or 0) for i in items)
            product_names = ', '.join(_safe_text(i.get('product_name'), 80) for i in items[:3] if _safe_text(i.get('product_name'), 80))
            if len(items) > 3:
                product_names += f'، +{len(items) - 3}'
            seller = sale.get('seller_name') or out.get('user_name') or ''
            employee = sale.get('employee_name') or ''
            out.update({
                'is_sale_related': True,
                'sale_id': sale.get('id'),
                'invoice_no': sale.get('invoice_no') or '',
                'operation_time': sale.get('created_at') or out.get('event_time') or '',
                'seller_name': seller,
                'employee_name': employee,
                'seller_or_employee': employee or seller or out.get('user_name') or '',
                'customer_name': sale.get('customer_name') or 'زبون عام',
                'payment_method': sale.get('payment_method') or '',
                'item_count': len(items),
                'sold_quantity': int(qty) if abs(qty - int(qty)) < 0.001 else qty,
                'product_names': product_names or 'فاتورة بدون مواد مفصلة',
                'items_summary': _item_summary(items),
                'sale_subtotal': sale.get('subtotal') or 0,
                'sale_discount': sale.get('discount_amount') or 0,
                'sale_tax': sale.get('tax_amount') or 0,
                'sale_total': sale.get('total') or 0,
                'operation_summary': f"فاتورة {sale.get('invoice_no') or sale.get('id')} - {product_names or len(items)} - الكمية {int(qty) if abs(qty-int(qty))<0.001 else qty} - الإجمالي {_money(sale.get('total'))}",
            })
            return out
        product = _product_from_row(self, out)
        if product:
            out.update({
                'product_names': product.get('name') or '',
                'sold_quantity': '',
                'seller_or_employee': out.get('user_name') or '',
                'operation_time': out.get('event_time') or '',
                'operation_summary': f"{out.get('action') or ''} - {product.get('name') or ''}",
            })
        else:
            out.setdefault('operation_time', out.get('event_time') or '')
            out.setdefault('seller_or_employee', out.get('user_name') or '')
            out.setdefault('product_names', '')
            out.setdefault('sold_quantity', '')
            out.setdefault('operation_summary', out.get('description') or out.get('action') or '')
    except Exception as exc:
        log_exception(exc, 'v46.12 enrich movement row')
    return out


def _list_unified_movements_enhanced(self: AppService, limit: int = 100, **filters) -> list[dict[str, Any]]:
    if _ORIG_LIST is None:
        return []
    rows = _ORIG_LIST(self, limit, **filters)
    return [_enrich_row(self, dict(r)) for r in rows]


def _movement_details_enhanced(self: AppService, movement_id: int) -> dict[str, Any]:
    base: dict[str, Any] = {}
    try:
        if _ORIG_GET is not None:
            base = dict(_ORIG_GET(self, int(movement_id)) or {})
        elif _table_exists(self, 'unified_movement_log'):
            row = self.db.one('SELECT * FROM unified_movement_log WHERE id=?', (int(movement_id),))
            base = dict(row) if row else {}
        if not base:
            return {}
        enriched = _enrich_row(self, base)
        sale, items = _sale_from_row(self, enriched)
        if sale:
            enriched['sale'] = sale
            enriched['items'] = items
        product = _product_from_row(self, enriched)
        if product:
            enriched['product'] = product
        if _ORIG_RELATED is not None:
            try:
                enriched['related_movements'] = [dict(r) for r in _ORIG_RELATED(self, int(movement_id))]
            except Exception:
                enriched['related_movements'] = []
        else:
            enriched['related_movements'] = []
        note_text = _safe_text(enriched.get('manager_note'), 4000)
        enriched['manager_notes_history'] = [line for line in note_text.splitlines() if line.strip()]
        return enriched
    except Exception as exc:
        log_exception(exc, 'v46.12 movement details enhanced')
        return base


AppService.list_unified_movements = _list_unified_movements_enhanced
AppService.get_unified_movement_details = _movement_details_enhanced
