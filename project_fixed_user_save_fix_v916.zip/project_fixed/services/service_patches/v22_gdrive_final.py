from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})
import services.service_patches.v19_gdrive as _prev_v19_gdrive
globals().update({k: v for k, v in vars(_prev_v19_gdrive).items() if not k.startswith('__')})
import services.service_patches.v20_gdrive_settings as _prev_v20_gdrive_settings
globals().update({k: v for k, v in vars(_prev_v20_gdrive_settings).items() if not k.startswith('__')})
import services.service_patches.v21_backup as _prev_v21_backup
globals().update({k: v for k, v in vars(_prev_v21_backup).items() if not k.startswith('__')})

# ================================================================
# V22 GOOGLE DRIVE BACKUP FINAL FIX
# Strong single-source settings file, stable project paths, direct path
# testing, and robust copy to Google Drive for Desktop folder.
# ================================================================

from pathlib import Path as _V22Path
import json as _v22_json
import shutil as _v22_shutil
from datetime import datetime as _v22_datetime


def _v22_root(self: AppService) -> _V22Path:
    try:
        return _V22Path(__file__).resolve().parents[1]
    except Exception:
        try:
            return _V22Path(self.db.path).resolve().parent
        except Exception:
            return _V22Path.cwd().resolve()


def _v22_settings_folder(self: AppService) -> _V22Path:
    folder = self._v22_root() / 'settings'
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def _v22_gdrive_settings_file(self: AppService) -> _V22Path:
    return self._v22_settings_folder() / 'google_drive_backup_settings.json'


def _v22_backups_folder(self: AppService) -> _V22Path:
    folder = self._v22_root() / 'backups'
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def _v22_is_enabled(value) -> bool:
    return str(value or '').strip().lower() in ('1', 'true', 'yes', 'on', 'نعم', 'مفعل')


def _v22_read_json_config(self: AppService) -> dict:
    try:
        file = self._v22_gdrive_settings_file()
        if file.exists():
            data = _v22_json.loads(file.read_text(encoding='utf-8'))
            if isinstance(data, dict):
                return data
    except Exception as exc:
        try:
            self.log('تحذير قراءة إعدادات Google Drive', str(exc))
        except Exception as exc:
            log_exception(exc)
    return {}


def _v22_write_json_config(self: AppService, enabled: bool, folder: str, status: str = '') -> None:
    data = {
        'google_drive_backup_enabled': '1' if enabled else '0',
        'google_drive_backup_path': str(folder or '').strip().strip('"'),
        'last_google_drive_backup_status': str(status or ''),
        'updated_at': now_text(),
    }
    self._v22_gdrive_settings_file().write_text(_v22_json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def _v22_save_google_drive_backup_settings(self: AppService, enabled: bool, path: str, user_id: int | None = None) -> None:
    user = self.require_any_permission(('can_backup', 'can_settings', 'can_tools'), user_id, 'تعديل إعدادات النسخ الاحتياطي')
    user_id = user['id']
    folder = str(path or '').strip().strip('"')
    enabled_str = '1' if enabled else '0'
    old = self.load_google_drive_backup_settings() if hasattr(self, 'load_google_drive_backup_settings') else {}
    status = str(old.get('last_google_drive_backup_status', '') or '')
    # Write JSON first: this is the reliable settings source even if the DB is locked or later recreated.
    self._v22_write_json_config(enabled, folder, status)
    try:
        self.save_settings({
            'google_drive_backup_enabled': enabled_str,
            'google_drive_backup_path': folder,
            'last_google_drive_backup_status': status,
        }, user_id)
    except Exception as exc:
        self.log('تحذير حفظ إعدادات Google Drive في قاعدة البيانات', str(exc), user_id)


def _v22_load_google_drive_backup_settings(self: AppService) -> dict:
    json_cfg = self._v22_read_json_config()
    try:
        db_cfg = self.get_settings()
    except Exception:
        db_cfg = {}
    # Prefer JSON because it is the dedicated settings file and survives DB replacement/restore.
    folder = str(json_cfg.get('google_drive_backup_path', '') or db_cfg.get('google_drive_backup_path', '') or '').strip()
    enabled = str(json_cfg.get('google_drive_backup_enabled', '') or db_cfg.get('google_drive_backup_enabled', '0') or '0')
    status = str(json_cfg.get('last_google_drive_backup_status', '') or db_cfg.get('last_google_drive_backup_status', '') or '')
    if folder:
        try:
            self.save_settings({
                'google_drive_backup_enabled': '1' if _v22_is_enabled(enabled) else '0',
                'google_drive_backup_path': folder,
                'last_google_drive_backup_status': status,
            })
        except Exception as exc:
            log_exception(exc)
    return {
        'google_drive_backup_enabled': '1' if _v22_is_enabled(enabled) else '0',
        'google_drive_backup_path': folder,
        'last_google_drive_backup_status': status,
    }


def _v22_google_drive_backup_target_dir(self: AppService, base_folder: str) -> _V22Path:
    base = _V22Path(str(base_folder or '').strip().strip('"')).expanduser()
    return base / 'MaxSalesBackups'


def _v22_test_google_drive_backup_path(self: AppService, path: str | None = None) -> tuple[bool, str]:
    cfg = self.load_google_drive_backup_settings()
    raw = str(path if path is not None else cfg.get('google_drive_backup_path', '')).strip().strip('"')
    enabled = _v22_is_enabled(cfg.get('google_drive_backup_enabled'))
    if not raw:
        msg = 'لم يتم اختيار مجلد Google Drive. اضغط اختيار مجلد أولاً.'
        self._v22_write_json_config(enabled, '', msg)
        try: self.save_settings({'last_google_drive_backup_status': msg})
        except Exception as exc:
            log_exception(exc)
        return False, msg
    try:
        base = _V22Path(raw).expanduser()
        if not base.exists():
            msg = f'المجلد المختار غير موجود: {base}'
            self._v22_write_json_config(enabled, str(base), msg)
            try: self.save_settings({'last_google_drive_backup_status': msg})
            except Exception as exc:
                log_exception(exc)
            return False, msg
        if not base.is_dir():
            msg = f'المسار المختار ليس مجلداً: {base}'
            self._v22_write_json_config(enabled, str(base), msg)
            try: self.save_settings({'last_google_drive_backup_status': msg})
            except Exception as exc:
                log_exception(exc)
            return False, msg
        target_dir = self.google_drive_backup_target_dir(str(base))
        target_dir.mkdir(parents=True, exist_ok=True)
        test_file = target_dir / 'max_sales_google_drive_test.txt'
        test_file.write_text('Max Sales Google Drive backup test - ' + now_text(), encoding='utf-8')
        if not test_file.exists() or test_file.stat().st_size <= 0:
            raise ValueError('تعذر إنشاء ملف اختبار داخل مجلد Google Drive')
        test_file.unlink(missing_ok=True)
        msg = f'المجلد جاهز. سيتم حفظ النسخ داخل: {target_dir}'
        self._v22_write_json_config(enabled, str(base), msg)
        try: self.save_settings({'last_google_drive_backup_status': msg, 'google_drive_backup_path': str(base)})
        except Exception as exc:
            log_exception(exc)
        return True, msg
    except Exception as exc:
        msg = f'فشل اختبار Google Drive: {exc}'
        try: self._v22_write_json_config(enabled, raw, msg)
        except Exception as exc:
            log_exception(exc)
        try: self.save_settings({'last_google_drive_backup_status': msg})
        except Exception as exc:
            log_exception(exc)
        try: self.log('فشل اختبار Google Drive', msg)
        except Exception as exc:
            log_exception(exc)
        return False, msg


def _v22_backup_database(self: AppService) -> _V22Path:
    self.require_permission('can_backup', action='إنشاء نسخة احتياطية')
    backups = self.backup_dir()
    stamp = _v22_datetime.now().strftime('%Y%m%d_%H%M%S')
    local_path = backups / f'max_sales_qt_backup_{stamp}.db'
    _v22_shutil.copy2(self.db.path, local_path)
    self.log('نسخة احتياطية محلية', str(local_path))
    try:
        keep = max(to_int(self.get_settings().get('max_backup_keep'), 7), 1)
        files = sorted(backups.glob('max_sales_qt_backup_*.db'), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in files[keep:]:
            old.unlink(missing_ok=True)
    except Exception as exc:
        self.log('تحذير تنظيف النسخ الاحتياطية', str(exc))
    cfg = self.load_google_drive_backup_settings()
    enabled = _v22_is_enabled(cfg.get('google_drive_backup_enabled'))
    folder = str(cfg.get('google_drive_backup_path', '') or '').strip()
    if not enabled:
        msg = 'Google Drive غير مفعل'
        self._v22_write_json_config(False, folder, msg)
        try: self.save_settings({'last_google_drive_backup_status': msg})
        except Exception as exc:
            log_exception(exc)
        return local_path
    ok, msg = self.test_google_drive_backup_path(folder)
    if not ok:
        return local_path
    try:
        target_dir = self.google_drive_backup_target_dir(folder)
        target_dir.mkdir(parents=True, exist_ok=True)
        gtarget = target_dir / local_path.name
        _v22_shutil.copy2(local_path, gtarget)
        if not gtarget.exists() or gtarget.stat().st_size <= 0:
            raise ValueError('تم النسخ لكن ملف Google Drive غير موجود أو حجمه صفر')
        status = f'ناجح: {gtarget}'
        self._v22_write_json_config(True, folder, status)
        try: self.save_settings({'last_google_drive_backup_status': status, 'last_google_drive_backup_at': now_text()})
        except Exception as exc:
            log_exception(exc)
        self.log('نسخ احتياطي Google Drive', status)
    except Exception as exc:
        status = f'فشل نسخ Google Drive: {exc}'
        self._v22_write_json_config(True, folder, status)
        try: self.save_settings({'last_google_drive_backup_status': status})
        except Exception as exc:
            log_exception(exc)
        self.log('فشل نسخ Google Drive', status)
    return local_path


def _v22_google_drive_status(self: AppService) -> str:
    cfg = self.load_google_drive_backup_settings()
    enabled = 'مفعل' if _v22_is_enabled(cfg.get('google_drive_backup_enabled')) else 'غير مفعل'
    folder = cfg.get('google_drive_backup_path') or '-'
    status = cfg.get('last_google_drive_backup_status') or '-'
    return f'الحالة: {enabled}\nالمجلد: {folder}\nآخر نتيجة: {status}'


AppService._v22_root = _v22_root
AppService._v22_settings_folder = _v22_settings_folder
AppService._v22_gdrive_settings_file = _v22_gdrive_settings_file
AppService.backup_dir = _v22_backups_folder
AppService._v22_write_json_config = _v22_write_json_config
AppService._v22_read_json_config = _v22_read_json_config
AppService.save_google_drive_backup_settings = _v22_save_google_drive_backup_settings
AppService.load_google_drive_backup_settings = _v22_load_google_drive_backup_settings
AppService.google_drive_backup_target_dir = _v22_google_drive_backup_target_dir
AppService.test_google_drive_backup_path = _v22_test_google_drive_backup_path
AppService.test_google_drive_backup = _v22_test_google_drive_backup_path
AppService.backup_database = _v22_backup_database
AppService.google_drive_status = _v22_google_drive_status

