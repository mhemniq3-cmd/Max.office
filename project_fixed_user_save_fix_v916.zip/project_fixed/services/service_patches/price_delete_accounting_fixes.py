from __future__ import annotations

"""V45.17.4 price validation, soft-delete audit, and accounting math hardening.

Built only on the v45.17.x line. This patch does not import or depend on any
v45.18/v45.19 UI changes.
"""

from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from typing import Any

from services.app_core import AppService
from services.error_logger import log_exception
from database import now_text

_ORIG_INIT = AppService.__init__
_ORIG_SAVE_PRODUCT = getattr(AppService, 'save_product', None)
_ORIG_DEACTIVATE_PRODUCT = getattr(AppService, 'deactivate_product', None)
_ORIG_DELETE_OR_DEACTIVATE_PRODUCT = getattr(AppService, 'delete_or_deactivate_product', None)
_ORIG_DELETE_OR_DEACTIVATE_CUSTOMER = getattr(AppService, 'delete_or_deactivate_customer', None)
_ORIG_ADJUST_INVENTORY = getattr(AppService, 'adjust_inventory', None)
_ORIG_ADVANCED_REPORTS = getattr(AppService, 'advanced_reports', None)

MONEY = Decimal('0.01')


def _d(value: Any, default: str = '0') -> Decimal:
    try:
        if value is None or str(value).strip() == '':
            value = default
        return Decimal(str(value).replace(',', '').strip()).quantize(MONEY, rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError):
        return Decimal(default).quantize(MONEY, rounding=ROUND_HALF_UP)


def _i(value: Any, default: int = 0) -> int:
    try:
        return int(float(value or default))
    except Exception:
        return default


def _rowdict(row: Any) -> dict[str, Any]:
    if row is None:
        return {}
    if isinstance(row, dict):
        return dict(row)
    try:
        return dict(row)
    except Exception:
        try:
            return {k: row[k] for k in row.keys()}
        except Exception:
            return {}


def _has_column(conn, table: str, col: str) -> bool:
    try:
        return col in {r[1] for r in conn.execute(f'PRAGMA table_info({table})')}
    except Exception:
        return False


def _ensure_column(conn, table: str, col: str, ddl: str) -> None:
    if not _has_column(conn, table, col):
        conn.execute(f'ALTER TABLE {table} ADD COLUMN {col} {ddl}')


def _current_user_name(self: AppService, user_id: int | None = None) -> str:
    uid = user_id or getattr(self, 'current_user_id', None)
    if uid:
        try:
            row = self.db.one('SELECT username, full_name FROM users WHERE id=?', (int(uid),))
            if row:
                return str(row['full_name'] or row['username'] or '').strip()
        except Exception:
            pass
    try:
        user = getattr(self, 'current_user', None)
        if user:
            return str(user.get('full_name') or user.get('username') or '').strip()
    except Exception:
        pass
    return 'system'


def _audit_activity(self: AppService, action_type: str, table_name: str, record_id: int | str | None, note: str = '', user_id: int | None = None) -> None:
    try:
        self.db.conn.execute('''
            INSERT INTO activity_log (action_type, table_name, record_id, note, user_name, action_date)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (action_type, table_name, record_id, str(note or ''), _current_user_name(self, user_id), now_text()))
    except Exception as exc:
        log_exception(exc, 'v45.17.4 activity log')
    try:
        if hasattr(self, 'record_audit'):
            self.record_audit(action_type, table_name, record_id, None, {'note': note}, user_id=user_id or getattr(self, 'current_user_id', None))
    except Exception:
        pass


def _ensure_v45174_schema(self: AppService) -> None:
    conn = self.db.conn
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS activity_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action_type TEXT,
            table_name TEXT,
            record_id INTEGER,
            note TEXT,
            user_name TEXT,
            action_date TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_activity_log_action_date_v45174 ON activity_log(action_date);
        CREATE INDEX IF NOT EXISTS idx_activity_log_table_v45174 ON activity_log(table_name, record_id);

        CREATE TABLE IF NOT EXISTS stock_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            prod_id INTEGER,
            old_qty INTEGER NOT NULL DEFAULT 0,
            new_qty INTEGER NOT NULL DEFAULT 0,
            difference INTEGER NOT NULL DEFAULT 0,
            type TEXT,
            note TEXT,
            user_name TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_stock_log_prod_v45174 ON stock_log(prod_id, created_at);

        CREATE TRIGGER IF NOT EXISTS trg_v45174_products_insert_price_guard
        BEFORE INSERT ON products
        FOR EACH ROW
        WHEN COALESCE(NEW.cost_price,0) <= 0 OR COALESCE(NEW.sale_price,0) <= 0 OR COALESCE(NEW.sale_price,0) < COALESCE(NEW.cost_price,0)
        BEGIN
            SELECT RAISE(ABORT, 'سعر الشراء والبيع يجب أن يكونا أكبر من صفر، ولا يمكن البيع بأقل من سعر الشراء');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_v45174_products_update_price_guard
        BEFORE UPDATE OF cost_price, sale_price ON products
        FOR EACH ROW
        WHEN COALESCE(NEW.cost_price,0) <= 0 OR COALESCE(NEW.sale_price,0) <= 0 OR COALESCE(NEW.sale_price,0) < COALESCE(NEW.cost_price,0)
        BEGIN
            SELECT RAISE(ABORT, 'سعر الشراء والبيع يجب أن يكونا أكبر من صفر، ولا يمكن البيع بأقل من سعر الشراء');
        END;
    ''')
    # Some old schemas use active, some notes refer to is_active. Keep both compatible.
    try:
        _ensure_column(conn, 'products', 'is_active', 'INTEGER NOT NULL DEFAULT 1')
        conn.execute('UPDATE products SET is_active=active WHERE active IS NOT NULL')
    except Exception as exc:
        log_exception(exc, 'v45.17.4 products is_active compatibility')
    try:
        _ensure_column(conn, 'customers', 'is_active', 'INTEGER NOT NULL DEFAULT 1')
        conn.execute('UPDATE customers SET is_active=active WHERE active IS NOT NULL')
    except Exception as exc:
        log_exception(exc, 'v45.17.4 customers is_active compatibility')
    conn.commit()


def _validate_prices(data: dict) -> tuple[Decimal, Decimal]:
    cost = _d(data.get('cost_price'))
    sale = _d(data.get('sale_price'))
    if cost <= 0:
        raise ValueError('لا يمكن أن يكون سعر الشراء صفراً أو أقل')
    if sale <= 0:
        raise ValueError('لا يمكن أن يكون سعر البيع صفراً أو أقل')
    if sale < cost:
        raise ValueError(f'سعر البيع ({sale}) أقل من سعر الشراء ({cost}). العملية ستسبب خسارة وتم إيقاف الحفظ')
    return cost, sale


def _save_product_v45174(self: AppService, data: dict, product_id: int | None = None) -> None:
    cost, sale = _validate_prices(data or {})
    if sale == cost:
        try:
            self.log('تنبيه سعر منتج', 'سعر البيع يساوي سعر الشراء؛ لا يوجد ربح', getattr(self, 'current_user_id', None))
        except Exception:
            pass
    if _ORIG_SAVE_PRODUCT is None:
        raise RuntimeError('دالة حفظ المنتجات غير متوفرة')
    out = _ORIG_SAVE_PRODUCT(self, data, product_id)
    try:
        action = 'تعديل منتج' if product_id else 'إضافة منتج'
        name = str((data or {}).get('name') or '').strip()
        _audit_activity(self, action, 'products', product_id, f'{name} | شراء={cost} | بيع={sale}', getattr(self, 'current_user_id', None))
    except Exception:
        pass
    return out


def _soft_delete_product(self: AppService, product_id: int, actor_user_id: int | None = None, reason: str = '') -> str:
    self.require_any_permission(('can_delete_records', 'can_product_delete', 'can_disable_product'), actor_user_id, 'تعطيل منتج')
    pid = int(product_id or 0)
    if pid <= 0:
        raise ValueError('اختر المنتج أولاً')
    row = self.db.one('SELECT * FROM products WHERE id=?', (pid,))
    if not row:
        raise ValueError('المنتج غير موجود')
    product = _rowdict(row)
    old_qty = _i(product.get('quantity'))
    user_name = _current_user_name(self, actor_user_id)
    note = str(reason or 'تم حذف/تعطيل الصنف من النظام').strip()
    with self.db.conn:
        sets = ['active=0']
        if _has_column(self.db.conn, 'products', 'is_active'):
            sets.append('is_active=0')
        self.db.conn.execute(f'UPDATE products SET {", ".join(sets)} WHERE id=?', (pid,))
        self.db.conn.execute('''
            INSERT INTO stock_log (prod_id, old_qty, new_qty, difference, type, note, user_name, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (pid, old_qty, old_qty, 0, 'حذف منطقي', note, user_name, now_text()))
        try:
            self.db.conn.execute('''
                INSERT INTO inventory_movements (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (pid, 'تعطيل منتج', 0, old_qty, old_qty, 'product', str(pid), note, actor_user_id or getattr(self, 'current_user_id', None), now_text()))
        except Exception as exc:
            log_exception(exc, 'v45.17.4 inventory movement product soft delete')
        self.db.conn.execute('''
            INSERT INTO activity_log (action_type, table_name, record_id, note, user_name, action_date)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', ('حذف منطقي', 'products', pid, f"تم تعطيل الصنف: {product.get('name','')} | {note}", user_name, now_text()))
    try:
        self.log('تعطيل منتج', f"{product.get('name','')} | {note}", actor_user_id)
    except Exception:
        pass
    return 'تم تعطيل المنتج وحفظ أثر العملية في سجل الحركات، ولم يتم حذفه نهائياً.'


def _deactivate_product_v45174(self: AppService, product_id: int) -> None:
    _soft_delete_product(self, product_id, getattr(self, 'current_user_id', None), 'تعطيل من صفحة المنتجات')


def _delete_or_deactivate_product_v45174(self: AppService, product_id: int, actor_user_id: int | None = None, reason: str = '') -> str:
    return _soft_delete_product(self, product_id, actor_user_id, reason)


def _delete_or_deactivate_customer_v45174(self: AppService, customer_id: int, actor_user_id: int | None = None, reason: str = '') -> str:
    self.require_permission('can_customers', actor_user_id, 'تعطيل زبون')
    cid = int(customer_id or 0)
    if cid <= 0:
        raise ValueError('اختر الزبون أولاً')
    row = self.db.one('SELECT * FROM customers WHERE id=?', (cid,))
    if not row:
        raise ValueError('الزبون غير موجود')
    cust = _rowdict(row)
    user_name = _current_user_name(self, actor_user_id)
    note = str(reason or 'تم حذف/تعطيل بيانات العميل').strip()
    with self.db.conn:
        sets = ['active=0']
        if _has_column(self.db.conn, 'customers', 'is_active'):
            sets.append('is_active=0')
        self.db.conn.execute(f'UPDATE customers SET {", ".join(sets)} WHERE id=?', (cid,))
        self.db.conn.execute('''
            INSERT INTO activity_log (action_type, table_name, record_id, note, user_name, action_date)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', ('حذف منطقي', 'customers', cid, f"تم تعطيل العميل: {cust.get('name','')} | {note}", user_name, now_text()))
    try:
        self.log('تعطيل زبون', f"{cust.get('name','')} | {note}", actor_user_id)
    except Exception:
        pass
    return 'تم تعطيل العميل وحفظ أثر العملية في سجل الحركات، ولم يتم حذفه نهائياً.'


def _calculate_invoice_totals_v45174(lines: list[dict], discount_value: Any = 0, discount_type: str = 'amount', tax_rate: Any = 0) -> dict[str, Decimal]:
    subtotal = sum((_d(line.get('unit_price')) * Decimal(_i(line.get('quantity'), 0)) for line in lines or []), Decimal('0.00'))
    discount_val = _d(discount_value)
    if str(discount_type or '').strip().lower() in ('percent', 'percentage', 'نسبة', 'نسبة مئوية'):
        discount = (subtotal * discount_val / Decimal('100')).quantize(MONEY, rounding=ROUND_HALF_UP)
    else:
        discount = discount_val
    if discount < 0:
        raise ValueError('الخصم لا يمكن أن يكون سالباً')
    if discount >= subtotal and subtotal > 0:
        raise ValueError('الخصم لا يمكن أن يساوي أو يتجاوز قيمة الفاتورة')
    taxable_base = max(Decimal('0.00'), subtotal - discount).quantize(MONEY, rounding=ROUND_HALF_UP)
    tax = (taxable_base * _d(tax_rate) / Decimal('100')).quantize(MONEY, rounding=ROUND_HALF_UP)
    total = (taxable_base + tax).quantize(MONEY, rounding=ROUND_HALF_UP)
    return {'subtotal': subtotal.quantize(MONEY), 'discount': discount, 'taxable_base': taxable_base, 'tax': tax, 'total': total}


def _profit_summary_v45174(self: AppService, date_from: str = '', date_to: str = '') -> dict[str, Any]:
    try:
        self.require_permission('can_reports', action='عرض الأرباح')
    except TypeError:
        self.require_permission('can_reports')
    where = ["s.status='completed'"]
    params: list[Any] = []
    normalizer = getattr(self, 'normalize_search_date', lambda x: x)
    if date_from:
        where.append('date(s.created_at) >= date(?)')
        params.append(normalizer(date_from))
    if date_to:
        where.append('date(s.created_at) <= date(?)')
        params.append(normalizer(date_to))
    row = self.db.one('''
        SELECT COUNT(DISTINCT s.id) invoices,
               COALESCE(SUM(si.net_line_total), SUM(si.line_total), 0) sales,
               COALESCE(SUM((si.unit_price - si.cost_price) * si.quantity), 0) gross_profit,
               COALESCE(SUM(s.discount_amount), 0) invoice_discounts,
               COALESCE(SUM(si.profit_amount), 0) stored_profit
          FROM sales s
          JOIN sale_items si ON si.sale_id=s.id
         WHERE ''' + ' AND '.join(where), params)
    d = _rowdict(row)
    # Prefer stored line profit when present because it already includes allocated discount.
    stored_profit = _d(d.get('stored_profit'))
    gross_profit = _d(d.get('gross_profit')) - _d(d.get('invoice_discounts'))
    profit = stored_profit if stored_profit != 0 else gross_profit
    return {
        'invoices': int(d.get('invoices') or 0),
        'sales': float(_d(d.get('sales'))),
        'profit': float(profit.quantize(MONEY, rounding=ROUND_HALF_UP)),
        'discounts': float(_d(d.get('invoice_discounts'))),
    }


def _update_cost_average_v45174(self: AppService, product_id: int, added_qty: int, new_cost: Any) -> float:
    row = self.db.one('SELECT quantity, cost_price FROM products WHERE id=?', (int(product_id),))
    if not row:
        raise ValueError('المنتج غير موجود')
    old_qty = Decimal(max(_i(row['quantity']), 0))
    qty = Decimal(max(_i(added_qty), 0))
    old_cost = _d(row['cost_price'])
    cost = _d(new_cost)
    if qty <= 0:
        return float(old_cost)
    denominator = old_qty + qty
    if denominator <= 0:
        return float(cost)
    avg = ((old_cost * old_qty) + (cost * qty)) / denominator
    return float(avg.quantize(MONEY, rounding=ROUND_HALF_UP))


def _advanced_reports_v45174(self: AppService, date_from: str = '', date_to: str = '', limit: int = 500, offset: int = 0) -> dict[str, Any]:
    if _ORIG_ADVANCED_REPORTS:
        data = _ORIG_ADVANCED_REPORTS(self, date_from, date_to, limit, offset)
    else:
        data = {}
    try:
        where = ["s.status='completed'"]
        params: list[Any] = []
        normalizer = getattr(self, 'normalize_search_date', lambda x: x)
        if date_from:
            where.append('date(s.created_at) >= date(?)')
            params.append(normalizer(date_from))
        if date_to:
            where.append('date(s.created_at) <= date(?)')
            params.append(normalizer(date_to))
        product_filter = ' AND COALESCE(p.active,1)=1'
        data['most_profit_products'] = [dict(r) for r in self.db.all('''
            SELECT si.product_id, si.product_name, SUM(si.quantity) qty,
                   SUM(si.net_line_total) amount,
                   SUM(COALESCE(si.profit_amount, (si.unit_price-si.cost_price)*si.quantity)) profit
              FROM sale_items si
              JOIN sales s ON s.id=si.sale_id
              JOIN products p ON p.id=si.product_id
             WHERE ''' + ' AND '.join(where) + product_filter + '''
             GROUP BY si.product_id, si.product_name
             ORDER BY profit DESC LIMIT 50
        ''', params)]
        data['best_selling_products'] = [dict(r) for r in self.db.all('''
            SELECT si.product_id, si.product_name, SUM(si.quantity) qty,
                   SUM(si.net_line_total) amount,
                   SUM(COALESCE(si.profit_amount, (si.unit_price-si.cost_price)*si.quantity)) profit
              FROM sale_items si
              JOIN sales s ON s.id=si.sale_id
              JOIN products p ON p.id=si.product_id
             WHERE ''' + ' AND '.join(where) + product_filter + '''
             GROUP BY si.product_id, si.product_name
             ORDER BY qty DESC LIMIT 50
        ''', params)]
    except Exception as exc:
        log_exception(exc, 'v45.17.4 advanced report active product filter')
    return data


def _security_health_v45174(self: AppService) -> dict[str, Any]:
    cols_products = {r[1] for r in self.db.conn.execute('PRAGMA table_info(products)')}
    cols_customers = {r[1] for r in self.db.conn.execute('PRAGMA table_info(customers)')}
    payments = self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name='payments'")
    activity = self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name='activity_log'")
    return {
        'version': 'v45.17.4',
        'price_guard': 'cost_price>0, sale_price>0, sale_price>=cost_price',
        'soft_delete_products': True,
        'soft_delete_customers': True,
        'activity_log_exists': bool(activity),
        'payments_table_exists': bool(payments),
        'products_active_columns': {'active': 'active' in cols_products, 'is_active': 'is_active' in cols_products},
        'customers_active_columns': {'active': 'active' in cols_customers, 'is_active': 'is_active' in cols_customers},
        'decimal_invoice_helper': True,
        'profit_uses_real_cost': True,
    }


def _init_v45174(self: AppService, *args, **kwargs):
    _ORIG_INIT(self, *args, **kwargs)
    try:
        _ensure_v45174_schema(self)
    except Exception as exc:
        log_exception(exc, 'v45.17.4 schema init')


AppService.__init__ = _init_v45174
AppService.save_product = _save_product_v45174
AppService.deactivate_product = _deactivate_product_v45174
AppService.delete_or_deactivate_product = _delete_or_deactivate_product_v45174
AppService.delete_or_deactivate_customer = _delete_or_deactivate_customer_v45174
AppService.calculate_invoice_totals_decimal = staticmethod(_calculate_invoice_totals_v45174)
AppService.profit_summary = _profit_summary_v45174
AppService.update_cost_average = _update_cost_average_v45174
AppService.advanced_reports = _advanced_reports_v45174
AppService.security_health_v45174 = _security_health_v45174
