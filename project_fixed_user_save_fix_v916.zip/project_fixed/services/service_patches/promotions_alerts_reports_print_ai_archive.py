from __future__ import annotations

import html
import json
import os
import re
from datetime import date, datetime, timedelta
from pathlib import Path
from statistics import mean

from services.app_core import AppService
from services.error_logger import log_exception

_ORIG_INIT = AppService.__init__
_ORIG_SAVE_PROMOTION = AppService.save_promotion
_ORIG_LIST_PROMOTIONS = AppService.list_promotions
_ORIG_RESOLVE_SALE_LINE = getattr(AppService, 'resolve_sale_line', None)
_ORIG_COMPLETE_SALE = AppService.complete_sale

PROJECT_ROOT = Path(__file__).resolve().parents[2]
ARCHIVE_DIR = PROJECT_ROOT / 'archive_docs'
INVOICE_DIR = PROJECT_ROOT / 'exports' / 'invoices'


def _today() -> str:
    return date.today().isoformat()


def _now() -> str:
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def _rowdict(row) -> dict:
    if row is None:
        return {}
    if isinstance(row, dict):
        return dict(row)
    try:
        return dict(row)
    except Exception:
        return {}


def _money(value) -> str:
    try:
        return f"{float(value or 0):,.0f} د.ع"
    except Exception:
        return '0 د.ع'


def _slug(text: str) -> str:
    text = str(text or '').strip()
    text = re.sub(r'[^\w\u0600-\u06FF-]+', '_', text, flags=re.UNICODE)
    return text[:80] or 'document'


def _ensure_v45_17_schema(self: AppService) -> None:
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    INVOICE_DIR.mkdir(parents=True, exist_ok=True)
    self.db.conn.executescript('''
        CREATE TABLE IF NOT EXISTS smart_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alert_type TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'medium',
            title TEXT NOT NULL,
            message TEXT,
            ref_type TEXT,
            ref_id INTEGER,
            user_id INTEGER,
            status TEXT NOT NULL DEFAULT 'open',
            created_at TEXT NOT NULL,
            resolved_at TEXT
        );
        CREATE TABLE IF NOT EXISTS document_archive (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            doc_type TEXT NOT NULL,
            ref_type TEXT,
            ref_id INTEGER,
            doc_no TEXT,
            party_name TEXT,
            phone TEXT,
            amount REAL NOT NULL DEFAULT 0,
            file_path TEXT,
            content_text TEXT,
            created_by_user_id INTEGER,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS invoice_print_templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            paper_size TEXT NOT NULL DEFAULT '80mm',
            include_logo INTEGER NOT NULL DEFAULT 1,
            include_qr INTEGER NOT NULL DEFAULT 1,
            include_barcode INTEGER NOT NULL DEFAULT 1,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS ai_recommendations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            rec_type TEXT NOT NULL,
            title TEXT NOT NULL,
            message TEXT,
            ref_type TEXT,
            ref_id INTEGER,
            score REAL NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'new',
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_smart_alerts_status ON smart_alerts(status, severity, created_at);
        CREATE INDEX IF NOT EXISTS idx_document_archive_search ON document_archive(doc_type, doc_no, party_name, phone, created_at);
    ''')
    for table, col, sql in [
        ('document_archive', 'doc_type', "TEXT NOT NULL DEFAULT 'document'"),
        ('document_archive', 'ref_type', 'TEXT'),
        ('document_archive', 'ref_id', 'INTEGER'),
        ('document_archive', 'doc_no', 'TEXT'),
        ('document_archive', 'party_name', 'TEXT'),
        ('document_archive', 'phone', 'TEXT'),
        ('document_archive', 'amount', 'REAL NOT NULL DEFAULT 0'),
        ('document_archive', 'file_path', 'TEXT'),
        ('document_archive', 'content_text', 'TEXT'),
        ('document_archive', 'created_by_user_id', 'INTEGER'),
        ('document_archive', 'resolved_at', 'TEXT'),
        ('promotions', 'coupon_code', 'TEXT'),
        ('promotions', 'manager_only', 'INTEGER NOT NULL DEFAULT 0'),
        ('promotions', 'usage_limit', 'INTEGER NOT NULL DEFAULT 0'),
        ('promotions', 'per_customer_limit', 'INTEGER NOT NULL DEFAULT 0'),
        ('promotions', 'stackable', 'INTEGER NOT NULL DEFAULT 0'),
        ('promotions', 'created_by_user_id', 'INTEGER'),
        ('sales', 'coupon_code', 'TEXT'),
        ('sale_items', 'promotion_discount_amount', 'REAL NOT NULL DEFAULT 0'),
        ('sale_items', 'original_unit_price', 'REAL NOT NULL DEFAULT 0'),
        ('sale_items', 'free_quantity', 'INTEGER NOT NULL DEFAULT 0'),
    ]:
        try:
            self.db.add_column_if_missing(table, col, sql)
        except Exception as exc:
            log_exception(exc)
    try:
        c = self.db.one('SELECT COUNT(*) c FROM invoice_print_templates')['c']
        if int(c or 0) == 0:
            for name, size in [('حراري 80mm', '80mm'), ('فاتورة A4', 'A4'), ('مختصر سريع', 'compact')]:
                self.db.execute('INSERT INTO invoice_print_templates (name, paper_size, created_at) VALUES (?, ?, ?)', (name, size, _now()))
    except Exception as exc:
        log_exception(exc)


def _init(self: AppService, db):
    _ORIG_INIT(self, db)
    _ensure_v45_17_schema(self)


def _require_manager_for_offer(self: AppService, user_id=None):
    try:
        return self.require_any_permission(('can_manage_offers', 'can_manage_promotions', 'can_discount_limit'), user_id, 'إدارة العروض المتقدمة')
    except Exception:
        return self.require_any_permission(('can_tools', 'can_settings'), user_id, 'إدارة العروض المتقدمة')


def _save_advanced_offer(self: AppService, data: dict, offer_id: int | None = None, user_id: int | None = None) -> int:
    user = _require_manager_for_offer(self, user_id)
    data = dict(data or {})
    data['coupon_code'] = str(data.get('coupon_code') or '').strip().upper()
    data['manager_only'] = 1 if data.get('manager_only') else 0
    data['usage_limit'] = max(int(data.get('usage_limit') or 0), 0)
    data['per_customer_limit'] = max(int(data.get('per_customer_limit') or 0), 0)
    data['stackable'] = 1 if data.get('stackable') else 0
    out = _ORIG_SAVE_PROMOTION(self, data, offer_id, user['id'] if user else user_id)
    self.db.execute('''UPDATE promotions
                       SET coupon_code=?, manager_only=?, usage_limit=?, per_customer_limit=?, stackable=?, created_by_user_id=COALESCE(created_by_user_id, ?)
                       WHERE id=?''', (data['coupon_code'], data['manager_only'], data['usage_limit'], data['per_customer_limit'], data['stackable'], user['id'] if user else user_id, out))
    try:
        self.log('حفظ عرض متقدم', f"{data.get('name','')} | كوبون: {data.get('coupon_code','')}", user['id'] if user else user_id)
    except Exception:
        pass
    return int(out)


def _list_advanced_offers(self: AppService, active_only: bool = False):
    where = ['1=1']
    params = []
    if active_only:
        today = _today()
        where.append("active=1 AND (start_date IS NULL OR TRIM(start_date)='' OR date(start_date)<=date(?)) AND (end_date IS NULL OR TRIM(end_date)='' OR date(end_date)>=date(?))")
        params.extend([today, today])
    try:
        rows = self.db.all(f'''SELECT pr.*, COALESCE(p.name,'') product_name FROM promotions pr LEFT JOIN products p ON p.id=pr.product_id WHERE {' AND '.join(where)} ORDER BY active DESC, priority DESC, id DESC''', params)
        return [dict(r) for r in rows]
    except Exception as exc:
        log_exception(exc)
        return []


def _promotion_usage_count(self: AppService, promo_id: int, customer_id: int | None = None) -> int:
    where = ['si.promotion_id=?', "s.status='completed'"]
    params = [int(promo_id)]
    if customer_id:
        where.append('s.customer_id=?')
        params.append(int(customer_id))
    row = self.db.one(f'''SELECT COUNT(*) c FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE {' AND '.join(where)}''', params)
    return int((row or {'c': 0})['c'] or 0)


def _applicable_advanced_offers(self: AppService, product, quantity: int, coupon_code: str = '', customer_id: int | None = None, user_id: int | None = None, sale_date: str | None = None):
    sale_date = sale_date or _today()
    coupon = str(coupon_code or '').strip().upper()
    prod = _rowdict(product)
    category = str(prod.get('category') or '')
    rows = self.db.all('''
        SELECT * FROM promotions
        WHERE active=1
          AND (start_date IS NULL OR TRIM(start_date)='' OR date(start_date)<=date(?))
          AND (end_date IS NULL OR TRIM(end_date)='' OR date(end_date)>=date(?))
          AND (coupon_code IS NULL OR TRIM(coupon_code)='' OR UPPER(coupon_code)=?)
          AND (
              scope_type='all'
              OR (scope_type='product' AND product_id=?)
              OR (scope_type='category' AND category=?))
        ORDER BY priority DESC, id DESC
    ''', (sale_date, sale_date, coupon, prod.get('id'), category))
    out = []
    for r in rows:
        rr = dict(r)
        if int(quantity or 0) < int(rr.get('min_quantity') or 1):
            continue
        if rr.get('coupon_code') and str(rr.get('coupon_code')).upper() != coupon:
            continue
        if int(rr.get('manager_only') or 0):
            try:
                self.require_any_permission(('can_discount_limit', 'can_manage_offers', 'can_manage_promotions'), user_id, 'عرض يحتاج موافقة مدير')
            except Exception:
                continue
        if int(rr.get('usage_limit') or 0) and _promotion_usage_count(self, int(rr['id'])) >= int(rr['usage_limit']):
            continue
        if int(rr.get('per_customer_limit') or 0) and customer_id and _promotion_usage_count(self, int(rr['id']), customer_id) >= int(rr['per_customer_limit']):
            continue
        out.append(rr)
    return out


def _apply_offer_to_price(promo: dict, base_price: float, quantity: int) -> dict:
    ptype = str(promo.get('promo_type') or 'percent')
    base = max(float(base_price or 0), 0.0)
    qty = max(int(quantity or 1), 1)
    discount_value = max(float(promo.get('discount_value') or 0), 0.0)
    unit = base
    free_units = 0
    if ptype == 'percent':
        unit = max(base * (1 - discount_value / 100.0), 0.0)
    elif ptype == 'amount':
        unit = max(base - discount_value, 0.0)
    elif ptype == 'fixed_price':
        unit = max(discount_value, 0.0)
    elif ptype == 'buy_x_get_y':
        buy_qty = max(int(promo.get('buy_qty') or 0), 0)
        free_qty = max(int(promo.get('free_qty') or 0), 0)
        if buy_qty > 0 and free_qty > 0:
            groups = qty // (buy_qty + free_qty)
            free_units = groups * free_qty
            discount = min(free_units, qty) * base
            return {'unit_price': base, 'discount_amount': discount, 'free_quantity': free_units}
    return {'unit_price': unit, 'discount_amount': max((base - unit) * qty, 0.0), 'free_quantity': free_units}


def _resolve_sale_line_advanced(self: AppService, product_id: int, quantity: int = 1, price_level_id: int | None = None, sale_date: str | None = None, coupon_code: str = '', customer_id: int | None = None, user_id: int | None = None) -> dict:
    # Start from the existing pricing pipeline, then add coupon/manager/limit-aware selection.
    if _ORIG_RESOLVE_SALE_LINE:
        base_line = _ORIG_RESOLVE_SALE_LINE(self, product_id, quantity, price_level_id, sale_date)
    else:
        p = self.db.one('SELECT * FROM products WHERE id=? AND active=1', (int(product_id),))
        if not p:
            raise ValueError('المنتج غير موجود')
        base_line = {'product_id': int(p['id']), 'product_name': p['name'], 'quantity': quantity, 'cost_price': float(p['cost_price'] or 0), 'original_unit_price': float(p['sale_price'] or 0), 'base_unit_price': float(p['sale_price'] or 0), 'unit_price': float(p['sale_price'] or 0), 'line_total': float(p['sale_price'] or 0) * int(quantity or 1), 'commission_percent': float(p['commission_percent'] or 0)}
    product = self.db.one('SELECT * FROM products WHERE id=?', (int(product_id),))
    base_unit = float(base_line.get('base_unit_price') or base_line.get('original_unit_price') or base_line.get('unit_price') or 0)
    best_promo = None
    best_calc = {'unit_price': float(base_line.get('unit_price') or base_unit), 'discount_amount': float(base_line.get('promotion_discount_amount') or 0), 'free_quantity': int(base_line.get('free_quantity') or 0)}
    for promo in _applicable_advanced_offers(self, product, quantity, coupon_code, customer_id, user_id, sale_date):
        calc = _apply_offer_to_price(promo, base_unit, quantity)
        if float(calc['discount_amount']) > float(best_calc.get('discount_amount') or 0) + 0.001:
            best_promo = promo
            best_calc = calc
    if best_promo:
        base_line['unit_price'] = float(best_calc['unit_price'])
        base_line['line_total'] = float(best_calc['unit_price']) * int(quantity or 1)
        base_line['promotion_id'] = int(best_promo['id'])
        base_line['promotion_name'] = best_promo.get('name') or ''
        base_line['promotion_discount_amount'] = float(best_calc.get('discount_amount') or 0)
        base_line['free_quantity'] = int(best_calc.get('free_quantity') or 0)
    return base_line


def _complete_sale_advanced(self: AppService, cart, employee_id, customer_id, payment_method, discount_amount=0, note='', user_id=None, discount_type='amount', coupon_code: str = ''):
    # Backward compatible signature. If caller sends coupon_code, rebuild each line through advanced offer resolver.
    safe_cart = []
    for item in cart or []:
        raw = dict(item)
        pid = int(raw.get('product_id') or 0)
        qty = int(raw.get('quantity') or 0)
        if pid > 0 and qty > 0:
            try:
                line = _resolve_sale_line_advanced(self, pid, qty, raw.get('price_level_id') or None, coupon_code=coupon_code, customer_id=customer_id, user_id=user_id)
                if raw.get('manual_price'):
                    line['manual_price'] = raw.get('manual_price')
                    line['unit_price'] = raw.get('unit_price')
                safe_cart.append(line)
            except Exception:
                safe_cart.append(raw)
    inv = _ORIG_COMPLETE_SALE(self, safe_cart or cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type)
    if coupon_code:
        try:
            self.db.execute('UPDATE sales SET coupon_code=? WHERE invoice_no=?', (str(coupon_code).strip().upper(), inv))
        except Exception as exc:
            log_exception(exc)
    try:
        self.archive_sale_invoice(inv, user_id=user_id)
    except Exception as exc:
        log_exception(exc)
    try:
        self.generate_smart_alerts(user_id=user_id)
    except Exception:
        pass
    return inv


def _insert_alert(self: AppService, alert_type: str, severity: str, title: str, message: str = '', ref_type: str = '', ref_id=None, user_id=None) -> int:
    # Avoid exact duplicate open alert for same target/title in the same day.
    existing = self.db.one('''SELECT id FROM smart_alerts WHERE status='open' AND alert_type=? AND title=? AND COALESCE(ref_type,'')=? AND COALESCE(ref_id,0)=COALESCE(?,0) AND date(created_at)=date(?)''', (alert_type, title, ref_type, ref_id, _today()))
    if existing:
        return int(existing['id'])
    cur = self.db.execute('''INSERT INTO smart_alerts (alert_type, severity, title, message, ref_type, ref_id, user_id, created_at)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?)''', (alert_type, severity, title, message, ref_type, ref_id, user_id, _now()))
    return int(cur.lastrowid)


def _generate_smart_alerts(self: AppService, user_id=None) -> list[dict]:
    today = _today()
    # Near out-of-stock / out-of-stock
    for p in self.db.all('''SELECT id, name, quantity, min_quantity FROM products WHERE active=1 AND quantity<=min_quantity ORDER BY quantity ASC LIMIT 100'''):
        sev = 'critical' if int(p['quantity'] or 0) <= 0 else 'high'
        _insert_alert(self, 'low_stock', sev, f"منتج قرب النفاد: {p['name']}", f"الكمية الحالية {p['quantity']} والحد الأدنى {p['min_quantity']}", 'product', p['id'], user_id)
    # Stagnant products: no sales in 45 days and stock available.
    cutoff = (date.today() - timedelta(days=45)).isoformat()
    stagnant = self.db.all('''
        SELECT p.id, p.name, p.quantity FROM products p
        LEFT JOIN sale_items si ON si.product_id=p.id
        LEFT JOIN sales s ON s.id=si.sale_id AND s.status='completed' AND date(s.created_at)>=date(?)
        WHERE p.active=1 AND p.quantity>0
        GROUP BY p.id HAVING COUNT(s.id)=0
        ORDER BY p.quantity DESC LIMIT 50
    ''', (cutoff,))
    for p in stagnant:
        _insert_alert(self, 'stagnant_product', 'medium', f"منتج راكد: {p['name']}", f"لا توجد مبيعات خلال آخر 45 يوم والكمية {p['quantity']}", 'product', p['id'], user_id)
    # Deleted/cancelled invoice
    for s in self.db.all("SELECT id, invoice_no, status, created_at FROM sales WHERE status NOT IN ('completed','مكتملة') ORDER BY id DESC LIMIT 50"):
        _insert_alert(self, 'invoice_cancelled', 'high', f"فاتورة غير مكتملة/محذوفة: {s['invoice_no']}", f"الحالة: {s['status']} | التاريخ: {s['created_at']}", 'sale', s['id'], user_id)
    # Abnormal discount
    for s in self.db.all('''SELECT id, invoice_no, subtotal, discount_amount FROM sales
                            WHERE status='completed' AND subtotal>0 AND discount_amount/subtotal>=0.20
                            ORDER BY id DESC LIMIT 50'''):
        pct = float(s['discount_amount'] or 0) / float(s['subtotal'] or 1) * 100
        _insert_alert(self, 'high_discount', 'high', f"خصم غير طبيعي: {s['invoice_no']}", f"نسبة الخصم تقريباً {pct:.1f}%", 'sale', s['id'], user_id)
    # Login outside working hours from user_sessions if exists.
    try:
        for ss in self.db.all('''SELECT us.id, u.username, us.login_at FROM user_sessions us LEFT JOIN users u ON u.id=us.user_id
                                 WHERE CAST(strftime('%H', us.login_at) AS INTEGER) NOT BETWEEN 7 AND 23
                                 ORDER BY us.id DESC LIMIT 50'''):
            _insert_alert(self, 'after_hours_login', 'medium', f"دخول خارج وقت الدوام: {ss['username'] or ''}", f"وقت الدخول: {ss['login_at']}", 'session', ss['id'], user_id)
    except Exception:
        pass
    # Customer over credit limit
    try:
        rows = self.db.all('''SELECT c.id, c.name, c.credit_limit,
               COALESCE((SELECT SUM(total) FROM sales WHERE customer_id=c.id AND payment_method='آجل' AND status='completed'),0)
               - COALESCE((SELECT SUM(amount) FROM customer_payments WHERE customer_id=c.id),0) balance
               FROM customers c WHERE c.active=1 AND c.credit_limit>0 HAVING balance>c.credit_limit LIMIT 100''')
    except Exception:
        rows = []
    for c in rows:
        _insert_alert(self, 'credit_limit', 'high', f"زبون تجاوز حد الدين: {c['name']}", f"الدين {_money(c['balance'])} والحد {_money(c['credit_limit'])}", 'customer', c['id'], user_id)
    return [dict(r) for r in self.db.all("SELECT * FROM smart_alerts WHERE status='open' ORDER BY CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END, id DESC LIMIT 200")]


def _list_smart_alerts(self: AppService, status: str = 'open'):
    if status == 'all':
        return [dict(r) for r in self.db.all('SELECT * FROM smart_alerts ORDER BY id DESC LIMIT 500')]
    return [dict(r) for r in self.db.all('SELECT * FROM smart_alerts WHERE status=? ORDER BY id DESC LIMIT 500', (status,))]


def _resolve_smart_alert(self: AppService, alert_id: int, user_id=None):
    self.db.execute("UPDATE smart_alerts SET status='resolved', resolved_at=? WHERE id=?", (_now(), int(alert_id)))


def _advanced_reports(self: AppService, date_from: str = '', date_to: str = '') -> dict:
    where = ["s.status='completed'"]
    params = []
    if date_from:
        where.append('date(s.created_at)>=date(?)'); params.append(date_from)
    if date_to:
        where.append('date(s.created_at)<=date(?)'); params.append(date_to)
    w = ' AND '.join(where)
    daily = [dict(r) for r in self.db.all(f'''SELECT date(created_at) period, COUNT(*) invoices, COALESCE(SUM(total),0) sales, COALESCE(SUM(total_profit),0) profit, COALESCE(SUM(tax_amount),0) tax, COALESCE(SUM(discount_amount),0) discounts FROM sales s WHERE {w} GROUP BY date(created_at) ORDER BY period DESC LIMIT 370''', params)]
    monthly = [dict(r) for r in self.db.all(f'''SELECT substr(created_at,1,7) period, COUNT(*) invoices, COALESCE(SUM(total),0) sales, COALESCE(SUM(total_profit),0) profit, COALESCE(SUM(tax_amount),0) tax, COALESCE(SUM(discount_amount),0) discounts FROM sales s WHERE {w} GROUP BY substr(created_at,1,7) ORDER BY period DESC LIMIT 60''', params)]
    prod_base = f'''FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE {w}'''
    best_selling = [dict(r) for r in self.db.all(f'''SELECT si.product_id, si.product_name, SUM(si.quantity) qty, SUM(si.line_total) amount, SUM(si.profit_amount) profit {prod_base} GROUP BY si.product_id, si.product_name ORDER BY qty DESC LIMIT 50''', params)]
    most_profit = [dict(r) for r in self.db.all(f'''SELECT si.product_id, si.product_name, SUM(si.quantity) qty, SUM(si.line_total) amount, SUM(si.profit_amount) profit {prod_base} GROUP BY si.product_id, si.product_name ORDER BY profit DESC LIMIT 50''', params)]
    least_selling = [dict(r) for r in self.db.all('''SELECT p.id product_id, p.name product_name, COALESCE(SUM(si.quantity),0) qty, p.quantity stock
        FROM products p LEFT JOIN sale_items si ON si.product_id=p.id LEFT JOIN sales s ON s.id=si.sale_id AND s.status='completed'
        WHERE p.active=1 GROUP BY p.id ORDER BY qty ASC, p.quantity DESC LIMIT 50''')]
    inventory = [dict(r) for r in self.db.all('''SELECT im.created_at, p.name product_name, im.movement_type, im.quantity_change, im.old_quantity, im.new_quantity, im.ref_type, im.ref_no, im.note FROM inventory_movements im LEFT JOIN products p ON p.id=im.product_id ORDER BY im.id DESC LIMIT 500''')]
    customer_debts = [dict(r) for r in self.db.all('''SELECT c.id, c.name, c.phone,
        COALESCE((SELECT SUM(total) FROM sales WHERE customer_id=c.id AND payment_method='آجل' AND status='completed'),0) - COALESCE((SELECT SUM(amount) FROM customer_payments WHERE customer_id=c.id),0) balance
        FROM customers c WHERE c.active=1 ORDER BY balance DESC LIMIT 200''')]
    supplier_debts = [dict(r) for r in self.db.all('''SELECT sp.id, sp.name, sp.phone,
        COALESCE((SELECT SUM(total-paid_amount) FROM purchases WHERE supplier_id=sp.id),0) - COALESCE((SELECT SUM(amount) FROM supplier_payments WHERE supplier_id=sp.id),0) balance
        FROM suppliers sp WHERE sp.active=1 ORDER BY balance DESC LIMIT 200''')]
    employees = [dict(r) for r in self.db.all(f'''SELECT e.name, COUNT(DISTINCT s.id) invoices, COALESCE(SUM(s.total),0) sales, COALESCE(SUM(s.total_profit),0) profit FROM employees e LEFT JOIN sales s ON s.employee_id=e.id AND {w} GROUP BY e.id ORDER BY sales DESC LIMIT 100''', params)]
    discounts = [dict(r) for r in self.db.all(f'''SELECT s.invoice_no, s.created_at, s.subtotal, s.discount_amount, s.coupon_code, u.username FROM sales s LEFT JOIN users u ON u.id=s.user_id WHERE {w} AND s.discount_amount>0 ORDER BY s.discount_amount DESC LIMIT 200''', params)]
    return {'daily_profit': daily, 'monthly_profit': monthly, 'most_profit_products': most_profit, 'best_selling_products': best_selling, 'least_selling_products': least_selling, 'inventory_movements': inventory, 'tax_report': daily, 'customer_debts': customer_debts, 'supplier_debts': supplier_debts, 'employee_report': employees, 'discount_report': discounts}


def _get_sale_invoice_payload(self: AppService, invoice_no: str) -> dict:
    sale = self.db.one('''SELECT s.*, COALESCE(c.name,'زبون عام') customer_name, COALESCE(c.phone,'') customer_phone, COALESCE(u.username,'') username
                          FROM sales s LEFT JOIN customers c ON c.id=s.customer_id LEFT JOIN users u ON u.id=s.user_id
                          WHERE s.invoice_no=?''', (invoice_no,))
    if not sale:
        raise ValueError('الفاتورة غير موجودة')
    items = [dict(r) for r in self.db.all('''SELECT si.*, COALESCE(p.barcode,'') barcode FROM sale_items si LEFT JOIN products p ON p.id=si.product_id WHERE si.sale_id=? ORDER BY si.id''', (sale['id'],))]
    return {'sale': dict(sale), 'items': items}


def _invoice_template_html(self: AppService, invoice_no: str, template: str = '80mm') -> str:
    payload = _get_sale_invoice_payload(self, invoice_no)
    sale = payload['sale']; items = payload['items']
    st = self.get_settings() if hasattr(self, 'get_settings') else {}
    width = '72mm' if template in ('80mm', 'حراري 80mm', 'compact') else '190mm'
    rows = []
    for it in items:
        barcode = f"<div class='muted'>باركود: {html.escape(str(it.get('barcode') or ''))}</div>" if str(it.get('barcode') or '') else ''
        rows.append(f"<tr><td>{html.escape(str(it.get('product_name') or ''))}{barcode}</td><td>{it.get('quantity')}</td><td>{_money(it.get('unit_price'))}</td><td>{_money(it.get('line_total'))}</td></tr>")
    qr_text = f"{sale['invoice_no']}|{sale['total']}|{sale['created_at']}"
    qr_block = f"<div class='qr'>QR: {html.escape(qr_text)}</div>"
    logo_path = str(st.get('company_logo_path') or '').strip()
    logo = f"<img class='logo' src='{html.escape(logo_path)}'>" if logo_path else ''
    return f'''<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>
    body{{font-family:Arial,Tahoma,sans-serif;width:{width};margin:auto;color:#111}} .head{{text-align:center}} .logo{{max-height:70px;max-width:140px}} table{{width:100%;border-collapse:collapse;margin-top:8px}} th,td{{border-bottom:1px solid #ddd;padding:5px;text-align:center;font-size:12px}} .total{{font-size:18px;font-weight:bold;text-align:center;margin:10px 0}} .muted{{font-size:10px;color:#666}} .qr{{border:1px dashed #777;margin:8px auto;padding:8px;text-align:center;font-size:11px;word-break:break-all}} @media print{{button{{display:none}}}}
    </style></head><body><div class='head'>{logo}<h2>{html.escape(st.get('company_name','MAX SALES'))}</h2><div>{html.escape(st.get('company_phone',''))}</div><div>{html.escape(st.get('company_address',''))}</div></div>
    <h3>فاتورة بيع: {html.escape(str(sale['invoice_no']))}</h3><p>التاريخ: {html.escape(str(sale['created_at']))}<br>الزبون: {html.escape(str(sale.get('customer_name') or ''))}<br>الهاتف: {html.escape(str(sale.get('customer_phone') or ''))}<br>الكاشير: {html.escape(str(sale.get('username') or ''))}</p>
    <table><tr><th>المادة</th><th>كمية</th><th>السعر</th><th>المجموع</th></tr>{''.join(rows)}</table>
    <p>قبل الخصم: {_money(sale.get('subtotal'))}<br>الخصم: {_money(sale.get('discount_amount'))}<br>الضريبة: {_money(sale.get('tax_amount'))}</p><div class='total'>الصافي: {_money(sale.get('total'))}</div>{qr_block}<p class='muted'>{html.escape(st.get('invoice_footer','شكراً لتعاملكم معنا'))}</p></body></html>'''


def _save_invoice_pdf_auto(self: AppService, invoice_no: str, template: str = '80mm') -> str:
    INVOICE_DIR.mkdir(parents=True, exist_ok=True)
    html_text = _invoice_template_html(self, invoice_no, template)
    # Without Qt here, save HTML print-ready file as reliable fallback; UI can convert to PDF through QTextDocument.
    path = INVOICE_DIR / f"{_slug(invoice_no)}_{template}.html"
    path.write_text(html_text, encoding='utf-8')
    return str(path)


def _archive_document(self: AppService, doc_type: str, ref_type: str = '', ref_id=None, doc_no: str = '', party_name: str = '', phone: str = '', amount: float = 0, file_path: str = '', content_text: str = '', user_id=None) -> int:
    now = _now()
    title = f"{doc_type} {doc_no}".strip()
    cols = [r[1] for r in self.db.conn.execute('PRAGMA table_info(document_archive)').fetchall()]
    data = {
        'doc_type': doc_type, 'ref_type': ref_type, 'ref_id': ref_id, 'doc_no': doc_no,
        'ref_no': doc_no, 'title': title, 'party_name': party_name, 'customer_name': party_name,
        'phone': phone, 'customer_phone': phone, 'amount': float(amount or 0), 'file_path': file_path,
        'content_text': content_text, 'created_by_user_id': user_id, 'created_at': now, 'doc_date': now[:10],
    }
    insert_cols = [c for c in data if c in cols]
    placeholders = ','.join('?' for _ in insert_cols)
    values = [data[c] for c in insert_cols]
    cur = self.db.execute(f"INSERT OR REPLACE INTO document_archive ({','.join(insert_cols)}) VALUES ({placeholders})", values)
    return int(cur.lastrowid)


def _archive_sale_invoice(self: AppService, invoice_no: str, user_id=None) -> int:
    payload = _get_sale_invoice_payload(self, invoice_no)
    sale = payload['sale']
    file_path = _save_invoice_pdf_auto(self, invoice_no, '80mm')
    text = f"فاتورة بيع {invoice_no} {sale.get('customer_name','')} {sale.get('customer_phone','')} {sale.get('total','')}"
    existing = self.db.one("SELECT id FROM document_archive WHERE doc_type='sale_invoice' AND (doc_no=? OR ref_no=?)", (invoice_no, invoice_no))
    if existing:
        cols = [r[1] for r in self.db.conn.execute('PRAGMA table_info(document_archive)').fetchall()]
        pairs = []
        vals = []
        for col, val in [('file_path', file_path), ('content_text', text), ('amount', sale.get('total') or 0), ('created_at', _now()), ('doc_date', _today()), ('party_name', sale.get('customer_name') or ''), ('customer_name', sale.get('customer_name') or ''), ('phone', sale.get('customer_phone') or ''), ('customer_phone', sale.get('customer_phone') or '')]:
            if col in cols:
                pairs.append(f'{col}=?'); vals.append(val)
        vals.append(existing['id'])
        if pairs:
            self.db.execute(f"UPDATE document_archive SET {', '.join(pairs)} WHERE id=?", vals)
        return int(existing['id'])
    return _archive_document(self, 'sale_invoice', 'sale', sale.get('id'), invoice_no, sale.get('customer_name') or '', sale.get('customer_phone') or '', sale.get('total') or 0, file_path, text, user_id)


def _search_document_archive(self: AppService, term: str = '', doc_type: str = '', date_from: str = '', date_to: str = ''):
    cols = [r[1] for r in self.db.conn.execute('PRAGMA table_info(document_archive)').fetchall()]
    where = ['1=1']; params = []
    if doc_type:
        where.append('doc_type=?'); params.append(doc_type)
    search_cols = [c for c in ['doc_no','ref_no','party_name','customer_name','phone','customer_phone','content_text','amount'] if c in cols]
    if term and search_cols:
        like = f"%{term.strip()}%"
        where.append('(' + ' OR '.join(f"CAST({c} AS TEXT) LIKE ?" for c in search_cols) + ')')
        params.extend([like] * len(search_cols))
    date_col = 'created_at' if 'created_at' in cols else ('doc_date' if 'doc_date' in cols else '')
    if date_from and date_col:
        where.append(f'date({date_col})>=date(?)'); params.append(date_from)
    if date_to and date_col:
        where.append(f'date({date_col})<=date(?)'); params.append(date_to)
    rows = []
    for r in self.db.all(f"SELECT * FROM document_archive WHERE {' AND '.join(where)} ORDER BY id DESC LIMIT 500", params):
        d = dict(r)
        d.setdefault('doc_no', d.get('ref_no',''))
        d.setdefault('party_name', d.get('customer_name') or d.get('supplier_name') or '')
        d.setdefault('phone', d.get('customer_phone') or '')
        rows.append(d)
    return rows

def _advanced_ai_analysis(self: AppService, days: int = 90) -> dict:
    days = max(int(days or 90), 7)
    cutoff = (date.today() - timedelta(days=days)).isoformat()
    sold = [dict(r) for r in self.db.all('''SELECT p.id, p.name, p.quantity, p.min_quantity, COALESCE(SUM(si.quantity),0) sold_qty, COALESCE(SUM(si.profit_amount),0) profit
        FROM products p LEFT JOIN sale_items si ON si.product_id=p.id LEFT JOIN sales s ON s.id=si.sale_id AND s.status='completed' AND date(s.created_at)>=date(?)
        WHERE p.active=1 GROUP BY p.id ORDER BY sold_qty DESC''', (cutoff,))]
    forecasts = []
    stagnant = []
    purchase = []
    for p in sold:
        daily = float(p.get('sold_qty') or 0) / days
        need_30 = int(round(daily * 30))
        suggested = max(need_30 + int(p.get('min_quantity') or 0) - int(p.get('quantity') or 0), 0)
        item = {'product_id': p['id'], 'product_name': p['name'], 'current_stock': p['quantity'], 'sold_qty': p['sold_qty'], 'daily_avg': round(daily, 2), 'forecast_30_days': need_30, 'suggested_purchase_qty': suggested, 'profit': p['profit']}
        forecasts.append(item)
        if suggested > 0:
            purchase.append(item)
        if float(p.get('sold_qty') or 0) <= 0 and int(p.get('quantity') or 0) > 0:
            stagnant.append(item)
    anomalies = _generate_smart_alerts(self)
    offer_suggestions = []
    for item in stagnant[:20]:
        offer_suggestions.append({'product_id': item['product_id'], 'product_name': item['product_name'], 'suggestion': 'اقترح خصم 10-20% أو عرض اشتر 2 واحصل على 1 لتصريف المنتج الراكد.'})
    return {'forecasts': forecasts[:100], 'purchase_suggestions': purchase[:50], 'stagnant_products': stagnant[:50], 'anomalies': anomalies[:100], 'offer_suggestions': offer_suggestions}


def _ask_ai_assistant_deep(self: AppService, question: str) -> str:
    q = str(question or '').strip().lower()
    reports = _advanced_reports(self)
    ai = _advanced_ai_analysis(self)
    if 'أكثر' in q and 'ربح' in q:
        top = reports['most_profit_products'][:5]
        return 'أكثر المنتجات ربحاً:\n' + '\n'.join(f"- {r['product_name']}: {_money(r['profit'])}" for r in top)
    if 'مبيع' in q or 'مبيعات' in q:
        top = reports['best_selling_products'][:5]
        return 'أكثر المنتجات مبيعاً:\n' + '\n'.join(f"- {r['product_name']}: {r['qty']} قطعة / {_money(r['amount'])}" for r in top)
    if 'شراء' in q or 'احتياج' in q or 'توقع' in q:
        top = ai['purchase_suggestions'][:10]
        return 'اقتراحات الشراء القادمة:\n' + '\n'.join(f"- {r['product_name']}: اشترِ تقريباً {r['suggested_purchase_qty']} قطعة" for r in top) if top else 'لا توجد احتياجات شراء واضحة حالياً.'
    if 'راكد' in q or 'راكدة' in q:
        top = ai['stagnant_products'][:10]
        return 'منتجات راكدة مقترحة للعروض:\n' + '\n'.join(f"- {r['product_name']} | مخزون {r['current_stock']}" for r in top) if top else 'لا توجد منتجات راكدة حسب آخر تحليل.'
    if 'تنبيه' in q or 'تلاعب' in q or 'غير طبيعي' in q:
        alerts = _generate_smart_alerts(self)[:10]
        return 'أهم التنبيهات الحالية:\n' + '\n'.join(f"- {a['title']}: {a.get('message','')}" for a in alerts) if alerts else 'لا توجد تنبيهات مفتوحة حالياً.'
    return 'يمكنك سؤالي عن: أكثر منتج ربحاً، أكثر منتج مبيعاً، توقع الشراء، المنتجات الراكدة، أو التنبيهات غير الطبيعية.'


AppService.__init__ = _init
AppService.save_advanced_offer = _save_advanced_offer
AppService.list_advanced_offers = _list_advanced_offers
AppService.resolve_sale_line_advanced = _resolve_sale_line_advanced
AppService.complete_sale = _complete_sale_advanced
AppService.generate_smart_alerts = _generate_smart_alerts
AppService.list_smart_alerts = _list_smart_alerts
AppService.resolve_smart_alert = _resolve_smart_alert
AppService.advanced_reports = _advanced_reports
AppService.invoice_template_html = _invoice_template_html
AppService.save_invoice_pdf_auto = _save_invoice_pdf_auto
AppService.archive_document = _archive_document
AppService.archive_sale_invoice = _archive_sale_invoice
AppService.search_document_archive = _search_document_archive
AppService.advanced_ai_analysis = _advanced_ai_analysis
AppService.ask_ai_assistant_deep = _ask_ai_assistant_deep
