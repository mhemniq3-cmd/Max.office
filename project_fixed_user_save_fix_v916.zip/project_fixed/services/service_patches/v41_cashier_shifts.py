from __future__ import annotations

from pathlib import Path
from typing import Any

from services.app_core import AppService
from database import now_text, money


def _row_get(row: Any, key: str, default: Any = None) -> Any:
    if row is None:
        return default
    if isinstance(row, dict):
        return row.get(key, default)
    try:
        return row[key]
    except Exception:
        return default


def _ensure_v41_shift_schema(self: AppService) -> None:
    self.db.execute('''
        CREATE TABLE IF NOT EXISTS cashier_shifts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            opened_at TEXT NOT NULL,
            closed_at TEXT,
            opening_cash REAL NOT NULL DEFAULT 0,
            expected_cash REAL NOT NULL DEFAULT 0,
            counted_cash REAL,
            cash_difference REAL,
            note TEXT,
            status TEXT NOT NULL DEFAULT 'open',
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    for col, ddl in [
        ('cash_sales', 'REAL NOT NULL DEFAULT 0'),
        ('credit_sales', 'REAL NOT NULL DEFAULT 0'),
        ('customer_payments', 'REAL NOT NULL DEFAULT 0'),
        ('returns_amount', 'REAL NOT NULL DEFAULT 0'),
        ('expenses_amount', 'REAL NOT NULL DEFAULT 0'),
        ('invoice_count', 'INTEGER NOT NULL DEFAULT 0'),
        ('closed_by_user_id', 'INTEGER'),
    ]:
        try:
            self.db.execute(f'ALTER TABLE cashier_shifts ADD COLUMN {col} {ddl}')
        except Exception:
            pass
    try:
        self.db.execute('CREATE INDEX IF NOT EXISTS idx_cashier_shifts_user_status ON cashier_shifts(user_id, status)')
        self.db.execute('CREATE INDEX IF NOT EXISTS idx_cashier_shifts_opened ON cashier_shifts(opened_at)')
    except Exception:
        pass


def _effective_user_id(self: AppService, user_id: int | None = None) -> int | None:
    try:
        user = self._effective_user(user_id)
        return int(user['id']) if user else None
    except Exception:
        return int(user_id) if user_id else None


def _open_cashier_shift_v41(self: AppService, opening_cash: float = 0, note: str = '', user_id: int | None = None) -> int:
    _ensure_v41_shift_schema(self)
    user = self.require_any_permission(('can_sales', 'can_touch_pos'), user_id, 'فتح شفت كاشير')
    uid = int(user['id'])
    open_row = self.db.one("SELECT id FROM cashier_shifts WHERE user_id=? AND status='open' ORDER BY id DESC LIMIT 1", (uid,))
    if open_row:
        raise ValueError('يوجد شفت مفتوح لهذا المستخدم. أغلق الشفت الحالي أولاً.')
    cur = self.db.execute('''
        INSERT INTO cashier_shifts (user_id, opened_at, opening_cash, note, status)
        VALUES (?, ?, ?, ?, 'open')
    ''', (uid, now_text(), float(opening_cash or 0), (note or '').strip()))
    try:
        self.log_detailed('فتح شفت كاشير', 'cashier_shifts', cur.lastrowid, None,
                          {'opening_cash': float(opening_cash or 0), 'note': (note or '').strip(), 'status': 'open'},
                          f'افتتاحي {money(opening_cash)}', 'medium', uid)
    except Exception:
        self.log('فتح شفت كاشير', f'افتتاحي {money(opening_cash)}', uid)
    return int(cur.lastrowid)


def _current_cashier_shift_v41(self: AppService, user_id: int | None = None):
    _ensure_v41_shift_schema(self)
    user = self.require_any_permission(('can_sales', 'can_touch_pos'), user_id, 'عرض الشفت الحالي')
    return self.db.one('''
        SELECT cs.*, COALESCE(NULLIF(u.full_name,''), u.username, '-') username
        FROM cashier_shifts cs LEFT JOIN users u ON u.id=cs.user_id
        WHERE cs.user_id=? AND cs.status='open'
        ORDER BY cs.id DESC LIMIT 1
    ''', (int(user['id']),))


def _shift_financial_summary_v41(self: AppService, shift_id: int | None = None, user_id: int | None = None) -> dict:
    _ensure_v41_shift_schema(self)
    shift = None
    if shift_id:
        shift = self.db.one('SELECT * FROM cashier_shifts WHERE id=?', (int(shift_id),))
    if shift is None:
        shift = self.current_cashier_shift(user_id)
    if not shift:
        return dict(open=False, message='لا يوجد شفت مفتوح', opening_cash=0, cash_sales=0, credit_sales=0,
                    customer_payments=0, returns_amount=0, expenses_amount=0, expected_cash=0,
                    counted_cash=0, cash_difference=0, invoice_count=0, opened_at='')
    opened = shift['opened_at']
    closed = shift['closed_at'] or now_text()
    uid = int(shift['user_id']) if shift['user_id'] is not None else None
    params = [opened, closed]
    user_filter = ''
    if uid:
        user_filter = ' AND user_id=?'
        params.append(uid)
    sales_cash = self.db.one(f"""
        SELECT COALESCE(SUM(total),0) total, COUNT(*) cnt
        FROM sales
        WHERE status='completed' AND payment_method!='آجل' AND created_at>=? AND created_at<=? {user_filter}
    """, tuple(params))
    params2 = [opened, closed]
    user_filter2 = ''
    if uid:
        user_filter2 = ' AND user_id=?'
        params2.append(uid)
    sales_credit = self.db.one(f"""
        SELECT COALESCE(SUM(total),0) total, COUNT(*) cnt
        FROM sales
        WHERE status='completed' AND payment_method='آجل' AND created_at>=? AND created_at<=? {user_filter2}
    """, tuple(params2))
    # customer_payments does not always have user_id in older databases, so we count all payments during shift window.
    pays = self.db.one('SELECT COALESCE(SUM(amount),0) total FROM customer_payments WHERE created_at>=? AND created_at<=?', (opened, closed))
    ret = self.db.one('''
        SELECT COALESCE(SUM(amount),0) total FROM returns
        WHERE refund_method='نقدي' AND created_at>=? AND created_at<=? AND (? IS NULL OR created_by_user_id=?)
    ''', (opened, closed, uid, uid))
    exp = self.db.one('''
        SELECT COALESCE(SUM(amount),0) total FROM expenses
        WHERE created_at>=? AND created_at<=? AND (? IS NULL OR user_id=?)
    ''', (opened, closed, uid, uid))
    opening = float(shift['opening_cash'] or 0)
    cash_sales = float(_row_get(sales_cash, 'total', 0) or 0)
    credit_sales = float(_row_get(sales_credit, 'total', 0) or 0)
    payments = float(_row_get(pays, 'total', 0) or 0)
    returns_amount = float(_row_get(ret, 'total', 0) or 0)
    expenses = float(_row_get(exp, 'total', 0) or 0)
    expected = opening + cash_sales + payments - returns_amount - expenses
    counted = shift['counted_cash'] if shift['counted_cash'] is not None else None
    diff = (float(counted) - expected) if counted is not None else 0.0
    return dict(
        open=(shift['status'] == 'open'), shift_id=shift['id'], user_id=uid, username=_row_get(shift, 'username', ''),
        opened_at=opened, closed_at=shift['closed_at'] or '', status=shift['status'],
        opening_cash=opening, cash_sales=cash_sales, credit_sales=credit_sales,
        customer_payments=payments, returns_amount=returns_amount, expenses_amount=expenses,
        invoice_count=int((_row_get(sales_cash, 'cnt', 0) or 0) + (_row_get(sales_credit, 'cnt', 0) or 0)),
        expected_cash=expected, counted_cash=float(counted or 0), cash_difference=diff,
        note=shift['note'] or ''
    )


def _close_cashier_shift_v41(self: AppService, counted_cash: float, note: str = '', user_id: int | None = None) -> dict:
    _ensure_v41_shift_schema(self)
    user = self.require_any_permission(('can_sales', 'can_touch_pos'), user_id, 'إغلاق شفت كاشير')
    uid = int(user['id'])
    shift = self.current_cashier_shift(uid)
    if not shift:
        raise ValueError('لا يوجد شفت مفتوح لهذا المستخدم')
    summary = self.shift_financial_summary(shift['id'], uid)
    counted = float(counted_cash or 0)
    diff = counted - float(summary['expected_cash'] or 0)
    before = {k: shift[k] for k in shift.keys()} if hasattr(shift, 'keys') else {}
    self.db.execute('''
        UPDATE cashier_shifts
        SET closed_at=?, expected_cash=?, counted_cash=?, cash_difference=?, note=?, status='closed',
            cash_sales=?, credit_sales=?, customer_payments=?, returns_amount=?, expenses_amount=?, invoice_count=?, closed_by_user_id=?
        WHERE id=?
    ''', (now_text(), summary['expected_cash'], counted, diff, (note or '').strip(),
          summary['cash_sales'], summary['credit_sales'], summary['customer_payments'], summary['returns_amount'],
          summary['expenses_amount'], summary['invoice_count'], uid, shift['id']))
    result = self.shift_financial_summary(shift['id'], uid)
    result['counted_cash'] = counted
    result['cash_difference'] = diff
    try:
        self.log_detailed('إغلاق شفت كاشير', 'cashier_shifts', shift['id'], before, result,
                          f"المتوقع {money(summary['expected_cash'])} | المعدود {money(counted)} | الفرق {money(diff)}",
                          'high' if abs(diff) > 0 else 'medium', uid)
    except Exception:
        self.log('إغلاق شفت كاشير', f"المتوقع {money(summary['expected_cash'])} | المعدود {money(counted)} | الفرق {money(diff)}", uid)
    return result


def _list_cashier_shifts_v41(self: AppService, status: str = '', limit: int = 300):
    _ensure_v41_shift_schema(self)
    params = []
    where = ['1=1']
    if status:
        where.append('cs.status=?')
        params.append(status)
    params.append(int(limit))
    return self.db.all(f'''
        SELECT cs.*, COALESCE(NULLIF(u.full_name,''), u.username, '-') username,
               COALESCE(NULLIF(cu.full_name,''), cu.username, '-') closed_by
        FROM cashier_shifts cs
        LEFT JOIN users u ON u.id=cs.user_id
        LEFT JOIN users cu ON cu.id=cs.closed_by_user_id
        WHERE {' AND '.join(where)}
        ORDER BY cs.id DESC LIMIT ?
    ''', tuple(params))


def _cashier_shift_report_html_v41(self: AppService, shift_id: int) -> str:
    s = self.shift_financial_summary(int(shift_id), None)
    html = f'''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>تقرير شفت الكاشير</title>
    <style>body{{font-family:Tahoma,Arial;margin:28px;color:#111827}}table{{width:100%;border-collapse:collapse}}td,th{{border:1px solid #ddd;padding:10px;text-align:center}}th{{background:#0f766e;color:white}}h1{{color:#0f766e}}.diff{{font-weight:bold;color:{'#16a34a' if s.get('cash_difference',0)>=0 else '#dc2626'}}}</style></head><body>
    <h1>تقرير شفت الكاشير</h1><p>رقم الشفت: {s.get('shift_id','')} | المستخدم: {s.get('username','-')} | الحالة: {s.get('status','')}</p>
    <p>فتح: {s.get('opened_at','')} | إغلاق: {s.get('closed_at','-')}</p>
    <table><tr><th>البند</th><th>القيمة</th></tr>
    <tr><td>مبلغ البداية</td><td>{money(s.get('opening_cash',0))}</td></tr>
    <tr><td>المبيعات النقدية/غير الآجلة</td><td>{money(s.get('cash_sales',0))}</td></tr>
    <tr><td>المبيعات الآجلة</td><td>{money(s.get('credit_sales',0))}</td></tr>
    <tr><td>دفعات الزبائن</td><td>{money(s.get('customer_payments',0))}</td></tr>
    <tr><td>المرتجعات النقدية</td><td>{money(s.get('returns_amount',0))}</td></tr>
    <tr><td>المصاريف</td><td>{money(s.get('expenses_amount',0))}</td></tr>
    <tr><td>المبلغ المتوقع</td><td>{money(s.get('expected_cash',0))}</td></tr>
    <tr><td>المبلغ الموجود فعلياً</td><td>{money(s.get('counted_cash',0))}</td></tr>
    <tr><td>فرق الصندوق</td><td class="diff">{money(s.get('cash_difference',0))}</td></tr>
    <tr><td>عدد الفواتير</td><td>{s.get('invoice_count',0)}</td></tr>
    </table><p>© PY : MOHIMEN MAX</p></body></html>'''
    return html


AppService.ensure_v41_shift_schema = _ensure_v41_shift_schema
AppService.open_cashier_shift = _open_cashier_shift_v41
AppService.current_cashier_shift = _current_cashier_shift_v41
AppService.shift_financial_summary = _shift_financial_summary_v41
AppService.close_cashier_shift = _close_cashier_shift_v41
AppService.list_cashier_shifts = _list_cashier_shifts_v41
AppService.cashier_shift_report_html = _cashier_shift_report_html_v41
