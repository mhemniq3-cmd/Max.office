from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})
import services.service_patches.v19_gdrive as _prev_v19_gdrive
globals().update({k: v for k, v in vars(_prev_v19_gdrive).items() if not k.startswith('__')})
import services.service_patches.v20_gdrive_settings as _prev_v20_gdrive_settings
globals().update({k: v for k, v in vars(_prev_v20_gdrive_settings).items() if not k.startswith('__')})
import services.service_patches.v21_backup as _prev_v21_backup
globals().update({k: v for k, v in vars(_prev_v21_backup).items() if not k.startswith('__')})
import services.service_patches.v22_gdrive_final as _prev_v22_gdrive_final
globals().update({k: v for k, v in vars(_prev_v22_gdrive_final).items() if not k.startswith('__')})
import services.service_patches.v23_business_tools as _prev_v23_business_tools
globals().update({k: v for k, v in vars(_prev_v23_business_tools).items() if not k.startswith('__')})
import services.service_patches.v24_smart_assistant as _prev_v24_smart_assistant
globals().update({k: v for k, v in vars(_prev_v24_smart_assistant).items() if not k.startswith('__')})

# ================================================================
# V25 PRACTICAL READINESS PATCH
# Fixes permission leaks, lazy-safe service reads, unique backups,
# stronger archive filters, auto-close backup support, cashier shifts,
# product expiry/CSV helpers, expense categories, purchase returns,
# and cleaner debt due-date reporting.
# ================================================================
import csv as _v25_csv
from datetime import date as _v25_date


def _v25_now_stamp() -> str:
    return datetime.now().strftime('%Y%m%d_%H%M%S_%f')


def _v25_as_dict(row) -> dict:
    return dict(row) if row is not None else {}


def _v25_bool(value) -> bool:
    return str(value or '').strip().lower() in ('1', 'true', 'yes', 'on', 'نعم', 'مفعل')


def _v25_user_can(self: AppService, permission: str, user_id: int | None = None) -> bool:
    user = self._effective_user(user_id)
    return bool(user and not bool(self._user_value(user, 'must_change_password', 0)) and self.user_has(user, permission))


def _v25_require_any(self: AppService, permissions, user_id: int | None = None, action: str = 'تنفيذ العملية'):
    return self.require_any_permission(tuple(permissions), user_id, action)


def _v25_require_print(self: AppService, action: str = 'طباعة'):
    return self.require_permission('can_print', action=action)


def _v25_product_query(term: str = '', extra_where: str = '', extra_params: list | None = None):
    term = (term or '').strip()
    where = ['active=1']
    params: list = []
    if term:
        where.append('(name LIKE ? OR barcode LIKE ? OR category LIKE ?)')
        like = f'%{term}%'
        params.extend([like, like, like])
    if extra_where:
        where.append(extra_where)
        params.extend(extra_params or [])
    sql = f"SELECT * FROM products WHERE {' AND '.join(where)} ORDER BY name LIMIT 1000"
    return sql, params


def _v25_sanitize_product(self: AppService, row, for_sale: bool = False, user_id: int | None = None) -> dict:
    d = _v25_as_dict(row)
    if not d:
        return d
    user = self._effective_user(user_id)
    can_cost = bool(user and self.user_has(user, 'can_view_cost'))
    can_profit = bool(user and self.user_has(user, 'can_view_profit'))
    if for_sale or not can_cost:
        d['cost_price'] = 0
    if not can_profit:
        d.pop('profit_amount', None)
    return d


def _v25_raw_product(self: AppService, product_id: int):
    return self.db.one('SELECT * FROM products WHERE id=? AND active=1', (int(product_id),))


_orig_list_products_v25 = AppService.list_products

def _v25_list_products(self: AppService, term: str = ''):
    _v25_require_any(self, ('can_products', 'can_sales', 'can_touch_pos', 'can_purchases', 'can_inventory'), action='عرض المنتجات')
    sql, params = _v25_product_query(term)
    return [_v25_sanitize_product(self, r) for r in self.db.all(sql, params)]


AppService.list_products = _v25_list_products


def _v25_list_products_public(self: AppService, term: str = ''):
    _v25_require_any(self, ('can_sales', 'can_touch_pos', 'can_products'), action='عرض منتجات البيع')
    sql, params = _v25_product_query(term)
    return [_v25_sanitize_product(self, r, for_sale=True) for r in self.db.all(sql, params)]


AppService.list_products_public = _v25_list_products_public
AppService.list_products_for_sale = _v25_list_products_public


_orig_get_product_by_barcode_v25 = AppService.get_product_by_barcode

def _v25_get_product_by_barcode(self: AppService, barcode: str):
    _v25_require_any(self, ('can_sales', 'can_touch_pos', 'can_products', 'can_purchases'), action='البحث بالباركود')
    barcode = (barcode or '').strip()
    if not barcode:
        return None
    row = self.db.one('SELECT * FROM products WHERE active=1 AND barcode=?', (barcode,))
    return _v25_sanitize_product(self, row, for_sale=True) if row else None


AppService.get_product_by_barcode = _v25_get_product_by_barcode


# Always calculate costs/commissions from the database. The UI must never be
# trusted to send real cost/profit fields, especially for cashier accounts.
def _v25_secure_sale_cart(self: AppService, cart: list[dict], user_id: int | None = None) -> list[dict]:
    safe: list[dict] = []
    for raw in cart or []:
        pid = int(raw.get('product_id') or 0)
        qty = int(raw.get('quantity') or 0)
        if pid <= 0 or qty <= 0:
            raise ValueError('بيانات المنتج أو الكمية غير صحيحة')
        product = self.db.one('SELECT * FROM products WHERE id=? AND active=1', (pid,))
        if not product:
            raise ValueError('منتج البيع غير موجود أو معطل')
        official_price = float(product['sale_price'] or 0)
        unit_price = float(raw.get('unit_price') if raw.get('unit_price') is not None else official_price)
        if abs(unit_price - official_price) > 0.0001:
            self.require_permission('can_price_edit', user_id, 'تعديل سعر البيع داخل الفاتورة')
        safe.append({
            'product_id': pid,
            'product_name': product['name'],
            'name': product['name'],
            'quantity': qty,
            'cost_price': float(product['cost_price'] or 0),
            'unit_price': unit_price,
            'commission_percent': float(product['commission_percent'] or 0),
        })
    return safe


def _v25_maybe_request_approval(self: AppService, subtotal: float, discount_amount: float, user_id: int | None = None, ref_no: str = '') -> None:
    if subtotal <= 0 or discount_amount <= 0:
        return
    st = self.get_settings()
    if not _v25_bool(st.get('require_manager_approval_for_large_discount', '1')):
        return
    threshold = max(to_float(st.get('large_discount_threshold_percent', 20)), 0)
    if not subtotal or subtotal <= 0:
        return
    ratio = discount_amount / subtotal * 100
    if ratio >= threshold and not _v25_user_can(self, 'can_discount_limit', user_id):
        try:
            self.request_manager_approval('خصم كبير', ref_no, f'نسبة الخصم {ratio:.2f}% تتجاوز حد {threshold:.2f}%', user_id)
        except Exception as exc:
            log_exception(exc)
        raise PermissionError('هذا الخصم يحتاج موافقة مدير أو صلاحية خصم كبير')


_orig_complete_sale_v25 = AppService.complete_sale

def _v25_complete_sale(self: AppService, cart, employee_id, customer_id, payment_method, discount_amount=0, note='', user_id=None, discount_type='amount'):
    safe_cart = _v25_secure_sale_cart(self, cart, user_id)
    subtotal = sum(float(i['quantity']) * float(i['unit_price']) for i in safe_cart)
    real_discount = discount_amount
    if discount_type == 'percent':
        real_discount = subtotal * float(discount_amount or 0) / 100.0
    _v25_maybe_request_approval(self, subtotal, float(real_discount or 0), user_id)
    inv = _orig_complete_sale_v25(self, safe_cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type)
    try:
        for item in safe_cart:
            self.db.execute('UPDATE products SET last_sale_at=? WHERE id=?', (now_text(), item['product_id']))
    except Exception as exc:
        log_exception(exc)
    return inv


AppService.complete_sale = _v25_complete_sale


_orig_suspend_sale_v25 = AppService.suspend_sale

def _v25_suspend_sale(self: AppService, cart, employee_id, customer_id, payment_method, discount_amount, note='', user_id=None):
    safe_cart = _v25_secure_sale_cart(self, cart, user_id)
    subtotal = sum(float(i['quantity']) * float(i['unit_price']) for i in safe_cart)
    _v25_maybe_request_approval(self, subtotal, float(discount_amount or 0), user_id)
    return _orig_suspend_sale_v25(self, safe_cart, employee_id, customer_id, payment_method, discount_amount, note, user_id)


AppService.suspend_sale = _v25_suspend_sale


_orig_list_suspended_sales_v25 = AppService.list_suspended_sales

def _v25_list_suspended_sales(self: AppService):
    user = _v25_require_any(self, ('can_sales', 'can_touch_pos'), action='عرض الفواتير المعلقة')
    if self.is_admin_user(user) or self.user_has(user, 'can_reports'):
        return _orig_list_suspended_sales_v25(self)
    return self.db.all('''SELECT h.*, COALESCE(u.username,'-') username, COALESCE(c.name,'زبون عام') customer
                          FROM suspended_sales h LEFT JOIN users u ON u.id=h.user_id LEFT JOIN customers c ON c.id=h.customer_id
                          WHERE h.user_id=? ORDER BY h.id DESC''', (user['id'],))


AppService.list_suspended_sales = _v25_list_suspended_sales


_orig_load_suspended_sale_v25 = AppService.load_suspended_sale

def _v25_load_suspended_sale(self: AppService, hold_id: int):
    user = _v25_require_any(self, ('can_sales', 'can_touch_pos'), action='تحميل فاتورة معلقة')
    row = self.db.one('SELECT * FROM suspended_sales WHERE id=?', (hold_id,))
    if not row:
        raise ValueError('الفاتورة المعلقة غير موجودة')
    if row['user_id'] and int(row['user_id']) != int(user['id']) and not (self.is_admin_user(user) or self.user_has(user, 'can_reports')):
        raise PermissionError('لا يمكنك فتح فاتورة معلقة تخص مستخدماً آخر')
    return row, json.loads(row['cart_json'])


AppService.load_suspended_sale = _v25_load_suspended_sale


def _v25_delete_suspended_sale(self: AppService, hold_id: int) -> None:
    user = _v25_require_any(self, ('can_sales', 'can_touch_pos'), action='حذف فاتورة معلقة')
    row = self.db.one('SELECT id, hold_no, user_id FROM suspended_sales WHERE id=?', (hold_id,))
    if not row:
        return
    if row['user_id'] and int(row['user_id']) != int(user['id']) and not (self.is_admin_user(user) or self.user_has(user, 'can_reports')):
        raise PermissionError('لا يمكنك حذف فاتورة معلقة تخص مستخدماً آخر')
    self.db.execute('DELETE FROM suspended_sales WHERE id=?', (hold_id,))
    self.log('حذف فاتورة معلقة', row['hold_no'] or str(hold_id), user['id'])


AppService.delete_suspended_sale = _v25_delete_suspended_sale


_orig_save_expense_v25 = AppService.save_expense

def _v25_save_expense(self: AppService, expense_type: str, amount: float, expense_date: str, note: str = '', user_id: int | None = None) -> int:
    user = _v25_require_any(self, ('can_tools', 'can_reports'), user_id, 'تسجيل مصروف')
    if not expense_type:
        expense_type = 'أخرى'
    self.db.execute('INSERT OR IGNORE INTO expense_categories (name, active, created_at) VALUES (?, 1, ?)', ((expense_type or '').strip(), now_text()))
    return _orig_save_expense_v25(self, expense_type, amount, expense_date, note, user['id'])


AppService.save_expense = _v25_save_expense


_orig_list_expenses_v25 = AppService.list_expenses

def _v25_list_expenses(self: AppService, date_from: str = '', date_to: str = '', limit: int = 500):
    _v25_require_any(self, ('can_tools', 'can_reports'), action='عرض المصاريف')
    return _orig_list_expenses_v25(self, date_from, date_to, limit)


AppService.list_expenses = _v25_list_expenses


def _v25_list_expense_categories(self: AppService):
    _v25_require_any(self, ('can_tools', 'can_reports'), action='عرض أنواع المصاريف')
    return self.db.all('SELECT * FROM expense_categories WHERE active=1 ORDER BY name')


def _v25_save_expense_category(self: AppService, name: str) -> None:
    _v25_require_any(self, ('can_tools', 'can_settings'), action='حفظ نوع مصروف')
    name = (name or '').strip()
    if not name:
        raise ValueError('اسم نوع المصروف مطلوب')
    self.db.execute('INSERT OR IGNORE INTO expense_categories (name, active, created_at) VALUES (?, 1, ?)', (name, now_text()))


AppService.list_expense_categories = _v25_list_expense_categories
AppService.save_expense_category = _v25_save_expense_category


_orig_dashboard_v25 = AppService.dashboard

def _v25_dashboard(self: AppService) -> dict:
    user = self.require_permission('can_dashboard', action='عرض الرئيسية')
    data = dict(_orig_dashboard_v25(self))
    if not self.user_has(user, 'can_view_profit'):
        data['profit'] = 0
        data['commission'] = 0
    return data


AppService.dashboard = _v25_dashboard


_orig_low_stock_details_v25 = AppService.low_stock_details

def _v25_low_stock_details(self: AppService):
    _v25_require_any(self, ('can_dashboard', 'can_products', 'can_sales', 'can_touch_pos', 'can_inventory'), action='عرض تنبيهات المخزون')
    return _orig_low_stock_details_v25(self)


AppService.low_stock_details = _v25_low_stock_details


_orig_inventory_movements_v25 = AppService.inventory_movements

def _v25_inventory_movements(self: AppService, limit: int = 300):
    _v25_require_any(self, ('can_inventory', 'can_products'), action='عرض حركة المخزون')
    return _orig_inventory_movements_v25(self, limit)


AppService.inventory_movements = _v25_inventory_movements


_orig_list_customers_v25 = AppService.list_customers

def _v25_list_customers(self: AppService, active_only: bool = True):
    _v25_require_any(self, ('can_customers', 'can_sales', 'can_touch_pos'), action='عرض الزبائن')
    return _orig_list_customers_v25(self, active_only)


AppService.list_customers = _v25_list_customers


def _v25_debt_rows(self: AppService):
    _v25_require_any(self, ('can_customers', 'can_reports'), action='عرض الديون')
    return self.db.all('''
        WITH credit AS (
            SELECT customer_id, SUM(CASE WHEN (subtotal-discount_amount+tax_amount) < 0 THEN 0 ELSE (subtotal-discount_amount+tax_amount) END) credit_sales, MAX(created_at) last_credit_sale
            FROM sales WHERE payment_method='آجل' GROUP BY customer_id
        ), returned AS (
            SELECT s.customer_id, SUM(r.amount) returns_amount FROM returns r JOIN sales s ON s.id=r.sale_id GROUP BY s.customer_id
        ), payments AS (
            SELECT customer_id, SUM(amount) payments FROM customer_payments GROUP BY customer_id
        )
        SELECT c.id, c.name, c.phone, c.credit_limit, c.due_days,
               COALESCE(credit.credit_sales,0) credit_sales,
               COALESCE(returned.returns_amount,0) returns_amount,
               COALESCE(payments.payments,0) payments,
               COALESCE(credit.credit_sales,0) - COALESCE(returned.returns_amount,0) - COALESCE(payments.payments,0) balance,
               credit.last_credit_sale,
               CASE WHEN c.debt_due_date IS NOT NULL AND TRIM(c.debt_due_date)<>'' THEN c.debt_due_date
                    WHEN credit.last_credit_sale IS NOT NULL AND c.due_days>0 THEN date(credit.last_credit_sale, '+' || c.due_days || ' day')
                    ELSE '' END due_date,
               CASE WHEN (COALESCE(credit.credit_sales,0) - COALESCE(returned.returns_amount,0) - COALESCE(payments.payments,0)) > 0
                         AND (CASE WHEN c.debt_due_date IS NOT NULL AND TRIM(c.debt_due_date)<>'' THEN date(c.debt_due_date)
                                   WHEN credit.last_credit_sale IS NOT NULL AND c.due_days>0 THEN date(credit.last_credit_sale, '+' || c.due_days || ' day')
                                   ELSE NULL END) < date('now')
                    THEN 1 ELSE 0 END overdue
        FROM customers c
        LEFT JOIN credit ON credit.customer_id=c.id
        LEFT JOIN returned ON returned.customer_id=c.id
        LEFT JOIN payments ON payments.customer_id=c.id
        WHERE c.active=1
        ORDER BY overdue DESC, balance DESC, c.name
    ''')


AppService.debt_rows = _v25_debt_rows


_orig_customer_statement_v25 = AppService.customer_statement

def _v25_customer_statement(self: AppService, customer_id: int):
    _v25_require_any(self, ('can_customers', 'can_reports'), action='عرض كشف حساب الزبون')
    return _orig_customer_statement_v25(self, customer_id)


AppService.customer_statement = _v25_customer_statement


_orig_list_returns_v25 = AppService.list_returns

def _v25_list_returns(self: AppService, limit: int = 200):
    _v25_require_any(self, ('can_returns', 'can_reports'), action='عرض المرتجعات')
    return _orig_list_returns_v25(self, limit)


AppService.list_returns = _v25_list_returns


_orig_find_sale_for_return_v25 = AppService.find_sale_for_return

def _v25_find_sale_for_return(self: AppService, invoice: str):
    _v25_require_any(self, ('can_returns', 'can_reports'), action='البحث عن فاتورة للمرتجع')
    return _orig_find_sale_for_return_v25(self, invoice)


AppService.find_sale_for_return = _v25_find_sale_for_return


_orig_invoice_details_v25 = AppService.invoice_details

def _v25_invoice_details(self: AppService, invoice_no: str):
    user = _v25_require_any(self, ('can_sales', 'can_touch_pos', 'can_reports', 'can_returns', 'can_print'), action='عرض تفاصيل الفاتورة')
    sale, items = _orig_invoice_details_v25(self, invoice_no)
    if self.user_has(user, 'can_view_cost'):
        return sale, items
    safe_items = []
    for item in items:
        d = dict(item)
        d['cost_price'] = 0
        d['profit_amount'] = 0
        safe_items.append(d)
    return sale, safe_items


AppService.invoice_details = _v25_invoice_details


_orig_list_sales_v25 = AppService.list_sales

def _v25_list_sales(self: AppService, limit: int = 200):
    user = _v25_require_any(self, ('can_reports', 'can_sales', 'can_touch_pos'), action='عرض المبيعات')
    rows = [dict(r) for r in _orig_list_sales_v25(self, limit)]
    if not self.user_has(user, 'can_view_profit'):
        for r in rows:
            r['total_profit'] = 0
            r['total_commission'] = 0
    return rows


AppService.list_sales = _v25_list_sales


_orig_commission_report_v25 = AppService.commission_report

def _v25_commission_report(self: AppService, date_from: str, date_to: str):
    _v25_require_any(self, ('can_reports', 'can_goals'), action='عرض تقرير العمولات')
    return _orig_commission_report_v25(self, date_from, date_to)


AppService.commission_report = _v25_commission_report


_orig_management_report_v25 = AppService.management_report

def _v25_management_report(self: AppService, kind: str):
    user = self.require_permission('can_reports', action='عرض التقارير الإدارية')
    rows = [dict(r) for r in _orig_management_report_v25(self, kind)]
    if not self.user_has(user, 'can_view_profit'):
        for r in rows:
            for k in list(r.keys()):
                if 'profit' in k or 'cost' in k:
                    r[k] = 0
    return rows


AppService.management_report = _v25_management_report


_orig_profit_summary_v25 = AppService.profit_summary

def _v25_profit_summary(self: AppService, date_from: str = '', date_to: str = '') -> dict:
    user = self.require_permission('can_reports', action='عرض ملخص الأرباح')
    if not self.user_has(user, 'can_view_profit'):
        raise PermissionError('لا تملك صلاحية عرض الأرباح')
    return _orig_profit_summary_v25(self, date_from, date_to)


AppService.profit_summary = _v25_profit_summary


_orig_cashier_report_v25 = AppService.cashier_report

def _v25_cashier_report(self: AppService, report_date: str = '') -> dict:
    _v25_require_any(self, ('can_tools', 'can_reports'), action='عرض تقرير صندوق الكاشير')
    return _orig_cashier_report_v25(self, report_date)


AppService.cashier_report = _v25_cashier_report


_orig_system_health_check_v25 = AppService.system_health_check

def _v25_system_health_check(self: AppService) -> list[dict]:
    _v25_require_any(self, ('can_tools', 'can_audit', 'can_reports'), action='فحص سلامة النظام')
    return _orig_system_health_check_v25(self)


AppService.system_health_check = _v25_system_health_check


_orig_print_invoice_html_v25 = AppService.print_invoice_html
_orig_print_return_html_v25 = AppService.print_return_html
_orig_print_payment_receipt_html_v25 = AppService.print_payment_receipt_html
_orig_print_customer_statement_html_v25 = AppService.print_customer_statement_html
_orig_print_barcode_labels_html_v25 = AppService.print_barcode_labels_html
_orig_print_purchase_html_v25 = AppService.print_purchase_html
_orig_print_daily_report_html_v25 = AppService.print_daily_report_html


def _v25_print_invoice_html(self: AppService, invoice_no: str) -> Path:
    _v25_require_print(self, 'طباعة الفواتير')
    return _orig_print_invoice_html_v25(self, invoice_no)


def _v25_print_return_html(self: AppService, return_no_value: str) -> Path:
    _v25_require_print(self, 'طباعة المرتجعات')
    return _orig_print_return_html_v25(self, return_no_value)


def _v25_print_payment_receipt_html(self: AppService, payment_id: int) -> Path:
    _v25_require_print(self, 'طباعة وصولات القبض')
    return _orig_print_payment_receipt_html_v25(self, payment_id)


def _v25_print_customer_statement_html(self: AppService, customer_id: int) -> Path:
    _v25_require_print(self, 'طباعة كشف حساب الزبون')
    return _orig_print_customer_statement_html_v25(self, customer_id)


def _v25_print_barcode_labels_html(self: AppService) -> Path:
    _v25_require_any(self, ('can_print', 'can_products'), action='طباعة ملصقات الباركود')
    return _orig_print_barcode_labels_html_v25(self)


def _v25_print_purchase_html(self: AppService, purchase_no_value: str) -> Path:
    _v25_require_any(self, ('can_print', 'can_purchases'), action='طباعة فاتورة شراء')
    return _orig_print_purchase_html_v25(self, purchase_no_value)


def _v25_print_daily_report_html(self: AppService, report_date: str = '') -> Path:
    self.require_permission('can_reports', action='طباعة التقرير اليومي')
    return _orig_print_daily_report_html_v25(self, report_date)


AppService.print_invoice_html = _v25_print_invoice_html
AppService.print_return_html = _v25_print_return_html
AppService.print_payment_receipt_html = _v25_print_payment_receipt_html
AppService.print_customer_statement_html = _v25_print_customer_statement_html
AppService.print_barcode_labels_html = _v25_print_barcode_labels_html
AppService.print_purchase_html = _v25_print_purchase_html
AppService.print_daily_report_html = _v25_print_daily_report_html


# Enhanced HTML output with unique filenames and paper-size support.
def _v25_html_page(self: AppService, title: str, body: str) -> Path:
    safe_title = ''.join(ch if ch.isalnum() or ch in ('_', '-') else '_' for ch in str(title))[:80]
    fn = self.export_dir() / f'{safe_title}_{_v25_now_stamp()}.html'
    settings = self.get_settings()
    paper = str(settings.get('paper_size', '80mm') or '80mm').lower()
    if '80' in paper or 'thermal' in paper:
        page_css = "@page{size:80mm auto;margin:3mm} body{font-family:Tahoma,Arial;margin:4px;color:#111;font-size:12px}.head{text-align:center;border-bottom:1px dashed #333;padding-bottom:6px}table{width:100%;border-collapse:collapse;margin-top:8px}td,th{border-bottom:1px dashed #ddd;padding:4px;text-align:center}.total{font-size:16px;font-weight:bold}.muted{color:#666;font-size:11px}.qrbox{border:1px dashed #555;padding:6px;text-align:center;margin:8px auto;max-width:220px;word-break:break-all}"
    else:
        page_css = "@page{size:A4;margin:12mm} body{font-family:Tahoma,Arial;margin:28px;color:#111}.head{text-align:center;border-bottom:2px solid #0f4c81;padding-bottom:12px}table{width:100%;border-collapse:collapse;margin-top:16px}td,th{border:1px solid #ddd;padding:8px;text-align:center}th{background:#eef6ff}.total{font-size:20px;font-weight:bold}.muted{color:#666}.qrbox{border:1px dashed #555;padding:8px;text-align:center;margin:12px auto;max-width:300px;word-break:break-all}"
    html_doc = f"""<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'><title>{html.escape(title)}</title><style>{page_css}</style></head><body><div class='head'><h2>{html.escape(settings.get('company_name','ماكس للمبيعات'))}</h2><div>{html.escape(settings.get('company_phone',''))} - {html.escape(settings.get('company_address',''))}</div></div>{body}<p class='muted'>{html.escape(settings.get('invoice_footer','شكراً لتعاملكم معنا'))}</p><script>window.print()</script></body></html>"""
    fn.write_text(html_doc, encoding='utf-8')
    return fn


AppService._html_page = _v25_html_page


def _v25_filtered_operations(self: AppService, date_from='', date_to='', employee='', customer='', product='', payment_method='', category='', operation_type='', limit=1000):
    user = self.require_permission('can_reports', action='عرض الأرشيف والفلاتر')
    show_profit = self.user_has(user, 'can_view_profit')
    rows = []
    limit = max(min(int(limit or 1000), 5000), 1)
    product = (product or '').strip()
    category = (category or '').strip()

    sale_where = ['1=1']; sale_params=[]
    sale_join = ''
    if product or category:
        sale_join = ' JOIN sale_items si ON si.sale_id=s.id LEFT JOIN products p ON p.id=si.product_id '
    if date_from: sale_where.append('date(s.created_at)>=date(?)'); sale_params.append(date_from)
    if date_to: sale_where.append('date(s.created_at)<=date(?)'); sale_params.append(date_to)
    if employee: sale_where.append('COALESCE(e.name,"") LIKE ?'); sale_params.append(f'%{employee}%')
    if customer: sale_where.append('COALESCE(c.name,"") LIKE ?'); sale_params.append(f'%{customer}%')
    if payment_method: sale_where.append('s.payment_method=?'); sale_params.append(payment_method)
    if product: sale_where.append('COALESCE(si.product_name,"") LIKE ?'); sale_params.append(f'%{product}%')
    if category: sale_where.append('COALESCE(p.category,"") LIKE ?'); sale_params.append(f'%{category}%')
    if operation_type in ('', 'بيع'):
        sql = f'''SELECT 'بيع' op, s.invoice_no ref, s.created_at, COALESCE(e.name,'') employee,
                         COALESCE(c.name,'') customer, s.payment_method, s.total amount,
                         s.total_profit profit, s.note details
                  FROM sales s {sale_join}
                  LEFT JOIN employees e ON e.id=s.employee_id LEFT JOIN customers c ON c.id=s.customer_id
                  WHERE {' AND '.join(sale_where)} GROUP BY s.id ORDER BY s.id DESC LIMIT ?'''
        for r in self.db.all(sql, sale_params + [limit]):
            d = dict(r); d['profit'] = d['profit'] if show_profit else 0; rows.append(d)

    ret_where=['1=1']; ret_params=[]
    ret_join = ' LEFT JOIN products p ON p.id=r.product_id '
    if date_from: ret_where.append('date(r.created_at)>=date(?)'); ret_params.append(date_from)
    if date_to: ret_where.append('date(r.created_at)<=date(?)'); ret_params.append(date_to)
    if employee: ret_where.append('COALESCE(e.name,"") LIKE ?'); ret_params.append(f'%{employee}%')
    if customer: ret_where.append('COALESCE(c.name,"") LIKE ?'); ret_params.append(f'%{customer}%')
    if product: ret_where.append('COALESCE(r.product_name,"") LIKE ?'); ret_params.append(f'%{product}%')
    if category: ret_where.append('COALESCE(p.category,"") LIKE ?'); ret_params.append(f'%{category}%')
    if operation_type in ('', 'مرتجع'):
        sql = f'''SELECT 'مرتجع' op, r.return_no ref, r.created_at, COALESCE(e.name,'') employee,
                         COALESCE(c.name,'') customer, r.refund_method payment_method, r.amount amount,
                         r.profit_amount profit, r.reason details
                  FROM returns r {ret_join}
                  LEFT JOIN employees e ON e.id=r.employee_id LEFT JOIN customers c ON c.id=r.customer_id
                  WHERE {' AND '.join(ret_where)} ORDER BY r.id DESC LIMIT ?'''
        for r in self.db.all(sql, ret_params + [limit]):
            d = dict(r); d['profit'] = d['profit'] if show_profit else 0; rows.append(d)

    exp_where=['1=1']; exp_params=[]
    if date_from: exp_where.append('date(expense_date)>=date(?)'); exp_params.append(date_from)
    if date_to: exp_where.append('date(expense_date)<=date(?)'); exp_params.append(date_to)
    if category: exp_where.append('expense_type LIKE ?'); exp_params.append(f'%{category}%')
    if product:
        exp_where.append('0=1')
    if operation_type in ('', 'مصروف'):
        sql = f'''SELECT 'مصروف' op, expense_no ref, created_at, '' employee, '' customer,
                         expense_type payment_method, amount, 0 profit, note details
                  FROM expenses WHERE {' AND '.join(exp_where)} ORDER BY id DESC LIMIT ?'''
        for r in self.db.all(sql, exp_params + [limit]): rows.append(dict(r))
    rows.sort(key=lambda x: x.get('created_at') or '', reverse=True)
    return rows[:limit]


AppService.filtered_operations = _v25_filtered_operations


_orig_backup_dir_v25 = AppService.backup_dir

def _v25_backup_database(self: AppService, user_id: int | None = None, system: bool = False) -> Path:
    user = None
    if not system:
        user = self.require_permission('can_backup', user_id, 'إنشاء نسخة احتياطية')
    backups = self.backup_dir()
    backups.mkdir(parents=True, exist_ok=True)
    local_path = backups / f'max_sales_qt_backup_{_v25_now_stamp()}.db'
    shutil.copy2(self.db.path, local_path)
    if not local_path.exists() or local_path.stat().st_size <= 0:
        raise ValueError('فشل إنشاء النسخة الاحتياطية المحلية')
    self.log('نسخة احتياطية تلقائية' if system else 'نسخة احتياطية محلية', str(local_path), user['id'] if user else None)
    try:
        keep = max(to_int(self.get_settings().get('max_backup_keep'), 7), 1)
        files = sorted(backups.glob('max_sales_qt_backup_*.db'), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in files[keep:]:
            old.unlink(missing_ok=True)
    except Exception as exc:
        self.log('تحذير تنظيف النسخ الاحتياطية', str(exc))
    try:
        cfg = self.load_google_drive_backup_settings()
        enabled = _v25_bool(cfg.get('google_drive_backup_enabled'))
        folder = str(cfg.get('google_drive_backup_path', '') or '').strip()
        if enabled and folder:
            ok, msg = self.test_google_drive_backup_path(folder)
            if ok:
                target_dir = self.google_drive_backup_target_dir(folder)
                target_dir.mkdir(parents=True, exist_ok=True)
                gtarget = target_dir / local_path.name
                shutil.copy2(local_path, gtarget)
                status = f'ناجح: {gtarget}' if gtarget.exists() and gtarget.stat().st_size > 0 else 'فشل: ملف Google Drive غير صالح'
                self.save_settings({'last_google_drive_backup_status': status, 'last_google_drive_backup_at': now_text()})
                try: self._v22_write_json_config(True, folder, status)
                except Exception as exc:
                    log_exception(exc)
            else:
                self.save_settings({'last_google_drive_backup_status': msg})
    except Exception as exc:
        try: self.save_settings({'last_google_drive_backup_status': f'فشل نسخ Google Drive: {exc}'})
        except Exception as exc:
            log_exception(exc)
    return local_path


AppService.backup_database = _v25_backup_database


def _v25_auto_backup_if_due(self: AppService) -> tuple[bool, str]:
    settings = self.get_settings()
    if not _v25_bool(settings.get('auto_backup_enabled', '1')):
        return False, 'النسخ الاحتياطي التلقائي غير مفعل'
    today = datetime.now().strftime('%Y-%m-%d')
    if settings.get('last_auto_backup_date') == today:
        return False, 'تم إنشاء نسخة اليوم مسبقاً'
    try:
        path = self.backup_database(system=True)
        self.save_settings({'last_auto_backup_date': today})
        return True, str(path)
    except Exception as exc:
        self.log('فشل النسخ الاحتياطي التلقائي', str(exc))
        return False, f'فشل النسخ الاحتياطي: {exc}'


AppService.auto_backup_if_due = _v25_auto_backup_if_due


def _v25_backup_on_close_if_enabled(self: AppService) -> tuple[bool, str]:
    try:
        st = self.get_settings()
        if not _v25_bool(st.get('auto_backup_on_close', '1')):
            return False, 'النسخ الاحتياطي عند الإغلاق غير مفعل'
        path = self.backup_database(system=True)
        return True, str(path)
    except Exception as exc:
        self.log('فشل النسخ الاحتياطي عند الإغلاق', str(exc))
        return False, str(exc)


AppService.backup_on_close_if_enabled = _v25_backup_on_close_if_enabled


# Cashier shifts.
def _v25_open_cashier_shift(self: AppService, opening_cash: float = 0, note: str = '', user_id: int | None = None) -> int:
    user = _v25_require_any(self, ('can_sales', 'can_touch_pos'), user_id, 'فتح شفت كاشير')
    open_row = self.db.one("SELECT id FROM cashier_shifts WHERE user_id=? AND status='open'", (user['id'],))
    if open_row:
        raise ValueError('يوجد شفت مفتوح لهذا المستخدم')
    cur = self.db.execute('''INSERT INTO cashier_shifts (user_id, opened_at, opening_cash, note, status) VALUES (?, ?, ?, ?, 'open')''', (user['id'], now_text(), float(opening_cash or 0), (note or '').strip()))
    self.log('فتح شفت كاشير', f'افتتاحي {money(opening_cash)}', user['id'])
    return cur.lastrowid


def _v25_current_cashier_shift(self: AppService, user_id: int | None = None):
    user = _v25_require_any(self, ('can_sales', 'can_touch_pos'), user_id, 'عرض الشفت الحالي')
    return self.db.one("SELECT * FROM cashier_shifts WHERE user_id=? AND status='open' ORDER BY id DESC LIMIT 1", (user['id'],))


def _v25_close_cashier_shift(self: AppService, counted_cash: float, note: str = '', user_id: int | None = None) -> dict:
    user = _v25_require_any(self, ('can_sales', 'can_touch_pos'), user_id, 'إغلاق شفت كاشير')
    shift = self.db.one("SELECT * FROM cashier_shifts WHERE user_id=? AND status='open' ORDER BY id DESC LIMIT 1", (user['id'],))
    if not shift:
        raise ValueError('لا يوجد شفت مفتوح')
    opened = shift['opened_at']
    sales = self.db.one("SELECT COALESCE(SUM(total),0) v FROM sales WHERE user_id=? AND payment_method!='آجل' AND created_at>=?", (user['id'], opened))
    pays = self.db.one("SELECT COALESCE(SUM(amount),0) v FROM customer_payments WHERE created_at>=?", (opened,))
    returns = self.db.one("SELECT COALESCE(SUM(amount),0) v FROM returns WHERE created_by_user_id=? AND refund_method='نقدي' AND created_at>=?", (user['id'], opened))
    expenses = self.db.one("SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE user_id=? AND created_at>=?", (user['id'], opened))
    expected = float(shift['opening_cash'] or 0) + float(sales['v'] or 0) + float(pays['v'] or 0) - float(returns['v'] or 0) - float(expenses['v'] or 0)
    counted = float(counted_cash or 0)
    diff = counted - expected
    self.db.execute("""UPDATE cashier_shifts SET closed_at=?, expected_cash=?, counted_cash=?, cash_difference=?, note=?, status='closed' WHERE id=?""", (now_text(), expected, counted, diff, (note or '').strip(), shift['id']))
    self.log('إغلاق شفت كاشير', f'المتوقع {money(expected)} | المعدود {money(counted)} | الفرق {money(diff)}', user['id'])
    return {'shift_id': shift['id'], 'expected_cash': expected, 'counted_cash': counted, 'cash_difference': diff}


AppService.open_cashier_shift = _v25_open_cashier_shift
AppService.current_cashier_shift = _v25_current_cashier_shift
AppService.close_cashier_shift = _v25_close_cashier_shift


# Approval requests.
def _v25_request_manager_approval(self: AppService, request_type: str, ref_no: str = '', details: str = '', user_id: int | None = None) -> int:
    user = self._effective_user(user_id)
    cur = self.db.execute('''INSERT INTO approval_requests (request_type, ref_no, requested_by_user_id, status, details, created_at) VALUES (?, ?, ?, 'pending', ?, ?)''', ((request_type or '').strip(), (ref_no or '').strip(), user['id'] if user else None, (details or '').strip(), now_text()))
    self.log('طلب موافقة مدير', f'{request_type} | {ref_no} | {details}', user['id'] if user else None)
    return cur.lastrowid


def _v25_list_approval_requests(self: AppService, status: str = 'pending'):
    _v25_require_any(self, ('can_users', 'can_audit', 'can_reports'), action='عرض طلبات الموافقة')
    params=[]; where=['1=1']
    if status:
        where.append('a.status=?'); params.append(status)
    return self.db.all(f'''SELECT a.*, COALESCE(req.username,'-') requested_by, COALESCE(ap.username,'-') approved_by
                          FROM approval_requests a LEFT JOIN users req ON req.id=a.requested_by_user_id
                          LEFT JOIN users ap ON ap.id=a.approved_by_user_id
                          WHERE {' AND '.join(where)} ORDER BY a.id DESC''', params)


def _v25_decide_approval_request(self: AppService, request_id: int, approve: bool, user_id: int | None = None, note: str = '') -> None:
    user = _v25_require_any(self, ('can_users', 'can_audit'), user_id, 'اعتماد طلب موافقة')
    status = 'approved' if approve else 'rejected'
    self.db.execute("UPDATE approval_requests SET status=?, approved_by_user_id=?, decided_at=?, details=COALESCE(details,'') || ? WHERE id=?", (status, user['id'], now_text(), (' | قرار: ' + note.strip()) if note else '', request_id))
    self.log('اعتماد طلب موافقة' if approve else 'رفض طلب موافقة', str(request_id), user['id'])


AppService.request_manager_approval = _v25_request_manager_approval
AppService.list_approval_requests = _v25_list_approval_requests
AppService.decide_approval_request = _v25_decide_approval_request


# Expiry, stale stock, and product import/export helpers.
def _v25_expiry_alerts(self: AppService, days: int = 30):
    _v25_require_any(self, ('can_products', 'can_inventory', 'can_dashboard'), action='عرض تنبيهات الصلاحية')
    days = max(int(days or 30), 0)
    return self.db.all("""SELECT id, barcode, name, category, quantity, expiry_date
                          FROM products WHERE active=1 AND expiry_date IS NOT NULL AND TRIM(expiry_date)<>''
                          AND date(expiry_date) <= date('now', ?)
                          ORDER BY date(expiry_date), name""", (f'+{days} day',))


def _v25_reorder_suggestions(self: AppService):
    _v25_require_any(self, ('can_products', 'can_inventory', 'can_purchases', 'can_dashboard'), action='عرض اقتراحات إعادة الطلب')
    return self.db.all("""SELECT id, barcode, name, category, quantity, min_quantity, reorder_point,
                                CASE WHEN reorder_point>0 THEN reorder_point ELSE min_quantity END alert_level
                         FROM products WHERE active=1 AND quantity <= CASE WHEN reorder_point>0 THEN reorder_point ELSE min_quantity END
                         ORDER BY quantity ASC, name""")


def _v25_export_products_csv(self: AppService, path: str | Path | None = None) -> Path:
    user = _v25_require_any(self, ('can_products', 'can_inventory'), action='تصدير المنتجات')
    target = Path(path) if path else self.export_dir() / f'products_export_{_v25_now_stamp()}.csv'
    target.parent.mkdir(parents=True, exist_ok=True)
    show_cost = self.user_has(user, 'can_view_cost')
    headers = ['id','barcode','name','category','sale_price','quantity','min_quantity','unit_name','items_per_unit','expiry_date','reorder_point','commission_percent']
    if show_cost:
        headers.insert(4, 'cost_price')
    rows = self.db.all('SELECT * FROM products WHERE active=1 ORDER BY name')
    with target.open('w', encoding='utf-8-sig', newline='') as f:
        writer = _v25_csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        for r in rows:
            d = {h: (r[h] if h in r.keys() else '') for h in headers}
            writer.writerow(d)
    return target


def _v25_import_products_csv(self: AppService, path: str | Path) -> dict:
    _v25_require_any(self, ('can_product_add', 'can_product_edit'), action='استيراد المنتجات')
    source = Path(path)
    if not source.exists():
        raise ValueError('ملف الاستيراد غير موجود')
    added = updated = skipped = 0
    with source.open('r', encoding='utf-8-sig', newline='') as f:
        reader = _v25_csv.DictReader(f)
        for row in reader:
            name = (row.get('name') or row.get('اسم المنتج') or '').strip()
            if not name:
                skipped += 1; continue
            barcode = (row.get('barcode') or row.get('الباركود') or '').strip() or None
            existing = self.db.one('SELECT id FROM products WHERE barcode=?', (barcode,)) if barcode else None
            data = {
                'barcode': barcode,
                'name': name,
                'category': row.get('category') or row.get('الصنف') or '',
                'cost_price': to_float(row.get('cost_price') or row.get('سعر الشراء')),
                'sale_price': to_float(row.get('sale_price') or row.get('سعر البيع')),
                'quantity': to_int(row.get('quantity') or row.get('الكمية')),
                'min_quantity': to_int(row.get('min_quantity') or row.get('حد التنبيه'), 5),
                'commission_percent': to_float(row.get('commission_percent') or row.get('العمولة')),
            }
            self.save_product(data, existing['id'] if existing else None)
            if existing: updated += 1
            else: added += 1
            p = self.db.one('SELECT id FROM products WHERE barcode=?' if barcode else 'SELECT id FROM products WHERE name=? ORDER BY id DESC LIMIT 1', (barcode or name,))
            if p:
                self.db.execute('''UPDATE products SET unit_name=?, items_per_unit=?, expiry_date=?, reorder_point=? WHERE id=?''', (
                    row.get('unit_name') or row.get('الوحدة') or 'حبة',
                    to_float(row.get('items_per_unit') or row.get('عدد القطع في الوحدة'), 1),
                    (row.get('expiry_date') or row.get('تاريخ الانتهاء') or '').strip() or None,
                    to_int(row.get('reorder_point') or row.get('نقطة إعادة الطلب')),
                    p['id'],
                ))
    return {'added': added, 'updated': updated, 'skipped': skipped}


AppService.expiry_alerts = _v25_expiry_alerts
AppService.reorder_suggestions = _v25_reorder_suggestions
AppService.export_products_csv = _v25_export_products_csv
AppService.import_products_csv = _v25_import_products_csv


# Purchase returns and richer supplier debt rows.
def _v25_create_purchase_return(self: AppService, purchase_id: int, items: list[dict], reason: str = '', user_id: int | None = None) -> str:
    user = _v25_require_any(self, ('can_purchases', 'can_suppliers'), user_id, 'تسجيل مرتجع شراء')
    purchase = self.db.one('SELECT * FROM purchases WHERE id=?', (purchase_id,))
    if not purchase:
        raise ValueError('فاتورة الشراء غير موجودة')
    if not items:
        raise ValueError('مرتجع الشراء فارغ')
    rno = self.next_doc_no('PRT')
    total = 0.0
    safe=[]
    for raw in items:
        pid = int(raw.get('product_id') or 0); qty = int(raw.get('quantity') or 0)
        if qty <= 0:
            raise ValueError('كمية مرتجع الشراء يجب أن تكون أكبر من صفر')
        pi = self.db.one('SELECT product_name, unit_cost, SUM(quantity) qty FROM purchase_items WHERE purchase_id=? AND product_id=? GROUP BY product_id', (purchase_id, pid))
        if not pi:
            raise ValueError('المنتج غير موجود في فاتورة الشراء')
        already = self.db.one('''SELECT COALESCE(SUM(pri.quantity),0) q FROM purchase_return_items pri JOIN purchase_returns pr ON pr.id=pri.purchase_return_id WHERE pr.purchase_id=? AND pri.product_id=?''', (purchase_id, pid))
        remaining = int(pi['qty'] or 0) - int(already['q'] or 0)
        if qty > remaining:
            raise ValueError(f'كمية المرتجع أكبر من المتبقي للمنتج {pi["product_name"]}')
        product = self.db.one('SELECT quantity FROM products WHERE id=?', (pid,))
        if product and int(product['quantity'] or 0) < qty:
            raise ValueError('المخزون الحالي أقل من كمية مرتجع الشراء')
        line = qty * float(pi['unit_cost'] or 0)
        total += line
        safe.append({'product_id': pid, 'product_name': pi['product_name'], 'quantity': qty, 'unit_cost': float(pi['unit_cost'] or 0), 'line_total': line})
    with self.db.conn:
        cur = self.db.conn.execute('''INSERT INTO purchase_returns (return_no, purchase_id, supplier_id, user_id, amount, reason, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)''', (rno, purchase_id, purchase['supplier_id'], user['id'], total, (reason or '').strip(), now_text()))
        rid = cur.lastrowid
        for item in safe:
            self.db.conn.execute('''INSERT INTO purchase_return_items (purchase_return_id, product_id, product_name, quantity, unit_cost, line_total) VALUES (?, ?, ?, ?, ?, ?)''', (rid, item['product_id'], item['product_name'], item['quantity'], item['unit_cost'], item['line_total']))
            oldq = self.db.conn.execute('SELECT quantity FROM products WHERE id=?', (item['product_id'],)).fetchone()['quantity']
            newq = int(oldq) - int(item['quantity'])
            self.db.conn.execute('UPDATE products SET quantity=? WHERE id=?', (newq, item['product_id']))
            self.db.conn.execute('''INSERT INTO inventory_movements (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (item['product_id'], 'مرتجع شراء', -item['quantity'], oldq, newq, 'purchase_return', rno, (reason or '').strip(), user['id'], now_text()))
    self.log('مرتجع شراء', f'{rno} - {money(total)}', user['id'])
    return rno


def _v25_list_purchase_returns(self: AppService, limit: int = 300):
    _v25_require_any(self, ('can_purchases', 'can_suppliers', 'can_reports'), action='عرض مرتجعات الشراء')
    return self.db.all('''SELECT pr.*, s.name supplier, p.purchase_no, COALESCE(u.username,'-') user_name
                          FROM purchase_returns pr JOIN suppliers s ON s.id=pr.supplier_id JOIN purchases p ON p.id=pr.purchase_id
                          LEFT JOIN users u ON u.id=pr.user_id ORDER BY pr.id DESC LIMIT ?''', (limit,))


AppService.create_purchase_return = _v25_create_purchase_return
AppService.list_purchase_returns = _v25_list_purchase_returns


def _v25_supplier_debt_rows(self: AppService):
    _v25_require_any(self, ('can_suppliers', 'can_purchases', 'can_reports'), action='عرض ديون الموردين')
    return self.db.all('''WITH ps AS (SELECT supplier_id, SUM(total) total_purchase, MAX(COALESCE(due_date, created_at)) due_date FROM purchases GROUP BY supplier_id),
                                pr AS (SELECT supplier_id, SUM(amount) returns_total FROM purchase_returns GROUP BY supplier_id),
                                py AS (SELECT supplier_id, SUM(amount) payments FROM supplier_payments GROUP BY supplier_id)
                         SELECT s.id, s.name, s.phone, s.address, COALESCE(ps.total_purchase,0) total_purchase,
                                COALESCE(pr.returns_total,0) returns_total, COALESCE(py.payments,0) payments,
                                COALESCE(ps.total_purchase,0)-COALESCE(pr.returns_total,0)-COALESCE(py.payments,0) balance,
                                COALESCE(ps.due_date,'') due_date,
                                CASE WHEN COALESCE(ps.total_purchase,0)-COALESCE(pr.returns_total,0)-COALESCE(py.payments,0)>0 AND date(ps.due_date)<date('now') THEN 1 ELSE 0 END overdue
                         FROM suppliers s LEFT JOIN ps ON ps.supplier_id=s.id LEFT JOIN pr ON pr.supplier_id=s.id LEFT JOIN py ON py.supplier_id=s.id
                         WHERE s.active=1 ORDER BY overdue DESC, balance DESC, s.name''')


AppService.supplier_debt_rows = _v25_supplier_debt_rows


_orig_list_suppliers_v25 = AppService.list_suppliers

def _v25_list_suppliers(self: AppService, active_only: bool = True):
    _v25_require_any(self, ('can_suppliers', 'can_purchases'), action='عرض الموردين')
    return _orig_list_suppliers_v25(self, active_only)


AppService.list_suppliers = _v25_list_suppliers


_orig_list_purchases_v25 = AppService.list_purchases

def _v25_list_purchases(self: AppService, limit: int = 300):
    _v25_require_any(self, ('can_purchases', 'can_suppliers', 'can_reports'), action='عرض المشتريات')
    return _orig_list_purchases_v25(self, limit)


AppService.list_purchases = _v25_list_purchases

