from __future__ import annotations

"""Native sales/finance adapter helpers for Max Sales v1.0.0.

This module keeps AppService sales and finance entry points aligned with the
clean Domain persistence layer. It stores diagnostic previews for support and
routes write operations through services.domain.persistence. Optional post-save
comparison can be enabled with:

    MAX_SALES_DOMAIN_STRICT_COMPARE=1

When enabled, differences larger than MAX_SALES_DOMAIN_COMPARE_TOLERANCE are
recorded in the adapter state for troubleshooting.
"""

import json
import os
from datetime import datetime
from pathlib import Path
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from functools import wraps
from typing import Any, Callable

from services.app_core import AppService
from services.domain import sales_finance as sf
from services.domain.persistence.sales_finance_writes import (
    add_payment_native,
    complete_sale_native,
    update_sale_native,
    delete_sale_native,
    return_full_sale_native,
    return_item_native,
    run_write_operation,
    emit_sales_event,
)

CENT = Decimal("0.01")
DEFAULT_TOLERANCE = Decimal("0.01")

_ORIG_COMPLETE_SALE = getattr(AppService, "complete_sale", None)
_ORIG_RETURN_ITEM = getattr(AppService, "return_item", None)
_ORIG_RETURN_FULL_SALE = getattr(AppService, "return_full_sale", None)
_ORIG_ADD_PAYMENT = getattr(AppService, "add_payment", None)
_ORIG_OPEN_CASHIER_SHIFT = getattr(AppService, "open_cashier_shift", None)
_ORIG_CLOSE_CASHIER_SHIFT = getattr(AppService, "close_cashier_shift", None)


def _D(value: Any) -> Decimal:
    try:
        return Decimal(str(value if value is not None else "0").replace(",", "").strip() or "0")
    except (InvalidOperation, ValueError, TypeError):
        return Decimal("0")


def _money(value: Any) -> Decimal:
    return _D(value).quantize(CENT, rounding=ROUND_HALF_UP)


def _as_float(value: Any) -> float:
    return float(_money(value))


def _strict_compare_enabled() -> bool:
    return str(os.environ.get("MAX_SALES_DOMAIN_STRICT_COMPARE", "")).lower() in {"1", "true", "yes", "on"}




def _tolerance() -> Decimal:
    try:
        value = os.environ.get("MAX_SALES_DOMAIN_COMPARE_TOLERANCE", str(DEFAULT_TOLERANCE))
        parsed = Decimal(str(value).replace(",", "").strip() or str(DEFAULT_TOLERANCE))
        if parsed < 0:
            return DEFAULT_TOLERANCE
        return parsed.quantize(CENT, rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError, TypeError):
        return DEFAULT_TOLERANCE

def _comparison_log_dir() -> Path:
    return Path(os.environ.get('MAX_SALES_DOMAIN_COMPARE_LOG_PATH', './logs')).expanduser()


def _normalize_payload_dates(self: AppService, payload: Any) -> Any:
    try:
        from services.domain.operations_core import normalize_record_dates, normalize_records_dates

        if isinstance(payload, dict):
            normalized = normalize_record_dates(self, payload)
            for key, value in list(normalized.items()):
                normalized[key] = _normalize_payload_dates(self, value)
            return normalized
        if isinstance(payload, list):
            if all(isinstance(item, dict) for item in payload):
                return normalize_records_dates(self, payload)
            return [_normalize_payload_dates(self, item) for item in payload]
    except Exception:
        pass
    return payload


def _write_daily_comparison_log(self: AppService, operation: str, data: dict[str, Any]) -> None:
    comparison = data.get('comparison') if isinstance(data, dict) else None
    if not comparison:
        return
    try:
        log_dir = _comparison_log_dir()
        log_dir.mkdir(parents=True, exist_ok=True)
        day = datetime.now().strftime('%Y-%m-%d')
        entry = {
            'timestamp': datetime.now().isoformat(timespec='seconds'),
            'operation': operation,
            'comparison': comparison,
        }
        path = log_dir / f'domain_compare_{day}.jsonl'
        with path.open('a', encoding='utf-8') as fh:
            fh.write(json.dumps(entry, ensure_ascii=False, default=str) + '\n')
    except Exception:
        # Comparison logging must never interrupt the native diagnostic path.
        pass


def _store_adapter_state(self: AppService, operation: str, data: dict[str, Any]) -> None:
    data = _normalize_payload_dates(self, data) if isinstance(data, dict) else data
    state = getattr(self, "_domain_adapter_state", None)
    if not isinstance(state, dict):
        state = {}
        setattr(self, "_domain_adapter_state", state)
    history = state.setdefault("history", [])
    history.append({"operation": operation, **data})
    if len(history) > 50:
        del history[:-50]
    state[operation] = data
    setattr(self, "_last_domain_adapter_operation", {"operation": operation, **data})
    _write_daily_comparison_log(self, operation, data)


def _safe_call(operation: str, fn: Callable[[], Any]) -> tuple[Any, str | None]:
    try:
        return fn(), None
    except Exception as exc:  # adapters must never block native persistence
        return None, f"{operation}: {type(exc).__name__}: {exc}"


def _settings_tax_percent(self: AppService) -> Any:
    try:
        settings = self.get_settings() if hasattr(self, "get_settings") else {}
        return (settings or {}).get("tax_percent", 0)
    except Exception:
        return 0


def _customer_data(customer_id: Any) -> dict[str, Any]:
    return {"id": customer_id, "customer_id": customer_id} if customer_id else {}


def _domain_sale_preview(
    self: AppService,
    cart: list[dict[str, Any]] | tuple[dict[str, Any], ...],
    customer_id: int | None,
    user_id: int | None,
    discount_amount: Any,
    discount_type: str,
    payment_method: str,
) -> dict[str, Any]:
    # Use the pure Domain calculation engine before the native writer.
    return sf.sale_preview_payload(
        self,
        list(cart or []),
        customer_data=_customer_data(customer_id),
        user_id=user_id,
        global_discount=discount_amount,
        global_discount_type=discount_type or "amount",
        additional_tax=_settings_tax_percent(self),
        paid_amount=0 if payment_method == "آجل" else None,
    )


def _compare_saved_sale(self: AppService, invoice_no: Any, preview: dict[str, Any] | None) -> dict[str, Any]:
    if not invoice_no or not preview or not hasattr(self, "db"):
        return {}
    try:
        row = self.db.one("SELECT total, subtotal, discount_amount, tax_amount FROM sales WHERE invoice_no=?", (invoice_no,))
        if not row:
            return {"comparison": "missing_saved_sale"}
        saved_total = _money(row["total"])
        domain_total = _money(preview.get("total", preview.get("grand_total", 0)))
        diff = _money(saved_total - domain_total)
        result = {
            "comparison": "ok" if abs(diff) <= _tolerance() else "different",
            "saved_total": _as_float(saved_total),
            "domain_total": _as_float(domain_total),
            "difference": _as_float(diff),
        }
        return result
    except Exception as exc:
        return {"comparison": "error", "error": f"{type(exc).__name__}: {exc}"}


def _domain_return_preview(self: AppService, sale_item_id: int, quantity: int) -> dict[str, Any]:
    if not hasattr(self, "db"):
        return {}
    row = self.db.one(
        """
        SELECT si.unit_price, si.quantity, COALESCE(s.tax_amount, 0) tax_amount,
               COALESCE(s.discount_amount, 0) discount_amount,
               COALESCE((SELECT SUM(line_total) FROM sale_items WHERE sale_id=si.sale_id), 0) sale_subtotal
        FROM sale_items si
        JOIN sales s ON s.id=si.sale_id
        WHERE si.id=?
        """,
        (sale_item_id,),
    )
    if not row:
        return {}
    sale_subtotal = _money(row["sale_subtotal"])
    line_gross = _money(row["unit_price"]) * _money(quantity)
    discount_share = Decimal("0")
    if sale_subtotal > 0:
        discount_share = _money(_money(row["discount_amount"]) * line_gross / sale_subtotal)
    taxable_base = max(sale_subtotal - _money(row["discount_amount"]), Decimal("0"))
    tax_share_percent = Decimal("0")
    if taxable_base > 0:
        tax_share_percent = _money((_money(row["tax_amount"]) / taxable_base) * Decimal("100"))
    return sf.calculate_return_values(
        self,
        original_item_price=row["unit_price"],
        return_quantity=quantity,
        original_tax=tax_share_percent,
        original_discount=discount_share,
        discount_type="amount",
        tax_included=False,
    )


def _wrap_complete_sale(fn: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(fn)
    def wrapper(
        self: AppService,
        cart: list[dict[str, Any]],
        employee_id: int,
        customer_id: int | None,
        payment_method: str,
        discount_amount: float = 0,
        note: str = "",
        user_id: int | None = None,
        discount_type: str = "amount",
    ) -> Any:
        preview, preview_error = _safe_call(
            "complete_sale_preview",
            lambda: _domain_sale_preview(self, cart, customer_id, user_id, discount_amount, discount_type, payment_method),
        )
        # Keep stock/event subscribers fully informed.  The preview produced by
        # the calculation layer is useful for totals, but inventory and alert
        # listeners need the original product_id/quantity/unit_price triplet.
        event_items = []
        for item in list(cart or []):
            event_items.append({
                "product_id": item.get("product_id") or item.get("id"),
                "product_name": item.get("product_name") or item.get("name") or "",
                "barcode": item.get("barcode") or "",
                "quantity": item.get("quantity") or item.get("qty") or 0,
                "unit_price": item.get("unit_price") or item.get("price") or item.get("sale_price") or 0,
            })
        if isinstance(preview, dict):
            preview = {**preview, "items": event_items, "cart_items": event_items}
        else:
            preview = {"items": event_items, "cart_items": event_items}
        _store_adapter_state(self, "complete_sale", {"preview": preview, "preview_error": preview_error})
        write_result = run_write_operation(
            operation="complete_sale",
            preview=preview,
            compat_call=lambda: fn(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type),
            native_call=lambda: complete_sale_native(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type),
            comparison_factory=(lambda result: _compare_saved_sale(self, result, preview)) if _strict_compare_enabled() else None,
        )
        _store_adapter_state(
            self,
            "complete_sale",
            {"preview": preview, "preview_error": preview_error, "result": write_result.result, "comparison": write_result.comparison},
        )
        return write_result.result

    wrapper.__name__ = "complete_sale"
    wrapper.__qualname__ = "sales_finance_adapter.complete_sale"
    wrapper.__module__ = __name__
    setattr(wrapper, "_stage9_sales_finance_adapter", True)
    return wrapper


def _wrap_return_item(fn: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(fn)
    def wrapper(self: AppService, sale_item_id: int, quantity: int, reason: str = "", user_id: int | None = None, refund_method: str = "نقدي") -> Any:
        preview, preview_error = _safe_call("return_item_preview", lambda: _domain_return_preview(self, sale_item_id, quantity))
        _store_adapter_state(self, "return_item", {"preview": preview, "preview_error": preview_error})
        write_result = run_write_operation(
            operation="return_item",
            preview=preview if isinstance(preview, dict) else {},
            compat_call=lambda: fn(self, sale_item_id, quantity, reason, user_id, refund_method),
            native_call=lambda: return_item_native(self, sale_item_id, quantity, reason, user_id, refund_method),
        )
        _store_adapter_state(self, "return_item", {"preview": preview, "preview_error": preview_error, "result": write_result.result})
        return write_result.result

    wrapper.__name__ = "return_item"
    wrapper.__qualname__ = "sales_finance_adapter.return_item"
    wrapper.__module__ = __name__
    setattr(wrapper, "_stage9_sales_finance_adapter", True)
    return wrapper


def _wrap_return_full_sale(fn: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(fn)
    def wrapper(self: AppService, sale_id: int, reason: str = "", user_id: int | None = None, refund_method: str = "نقدي") -> Any:
        _store_adapter_state(self, "return_full_sale", {"sale_id": sale_id, "mode": "domain_native_persistence"})
        write_result = run_write_operation(
            operation="return_full_sale",
            preview={"sale_id": sale_id},
            compat_call=lambda: fn(self, sale_id, reason, user_id, refund_method),
            native_call=lambda: return_full_sale_native(self, sale_id, reason, user_id, refund_method),
        )
        return write_result.result

    wrapper.__name__ = "return_full_sale"
    wrapper.__qualname__ = "sales_finance_adapter.return_full_sale"
    wrapper.__module__ = __name__
    setattr(wrapper, "_stage9_sales_finance_adapter", True)
    return wrapper


def _wrap_add_payment(fn: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(fn)
    def wrapper(self: AppService, customer_id: int, amount: float, note: str = "") -> Any:
        def make_preview() -> dict[str, Any]:
            balance = 0
            if hasattr(self, "get_customer_balance"):
                raw = self.get_customer_balance(customer_id)
                if isinstance(raw, dict):
                    balance = raw.get("balance", raw.get("remaining", 0))
                else:
                    balance = raw
            return sf.calculate_credit_impact(self, current_balance=balance, invoice_total=0, payment_amount=amount)

        preview, preview_error = _safe_call("add_payment_preview", make_preview)
        _store_adapter_state(self, "add_payment", {"preview": preview, "preview_error": preview_error})
        write_result = run_write_operation(
            operation="add_payment",
            preview=preview if isinstance(preview, dict) else {},
            compat_call=lambda: fn(self, customer_id, amount, note),
            native_call=lambda: add_payment_native(self, customer_id, amount, note),
        )
        _store_adapter_state(self, "add_payment", {"preview": preview, "preview_error": preview_error, "result": write_result.result})
        return write_result.result

    wrapper.__name__ = "add_payment"
    wrapper.__qualname__ = "sales_finance_adapter.add_payment"
    wrapper.__module__ = __name__
    setattr(wrapper, "_stage9_sales_finance_adapter", True)
    return wrapper


def _wrap_cash_shift(fn: Callable[..., Any], operation: str) -> Callable[..., Any]:
    @wraps(fn)
    def wrapper(self: AppService, *args: Any, **kwargs: Any) -> Any:
        before, before_error = _safe_call("cash_balance_before", lambda: self.get_cash_balance() if hasattr(self, "get_cash_balance") else None)
        _store_adapter_state(self, operation, {"cash_balance_before": before, "preview_error": before_error})
        write_result = run_write_operation(
            operation=operation,
            preview={"cash_balance_before": before},
            compat_call=lambda: fn(self, *args, **kwargs),
        )
        result = write_result.result
        after, after_error = _safe_call("cash_balance_after", lambda: self.get_cash_balance() if hasattr(self, "get_cash_balance") else None)
        _store_adapter_state(
            self,
            operation,
            {"cash_balance_before": before, "cash_balance_after": after, "preview_error": before_error or after_error, "result": result},
        )
        return result

    wrapper.__name__ = operation
    wrapper.__qualname__ = f"sales_finance_adapter.{operation}"
    wrapper.__module__ = __name__
    setattr(wrapper, "_stage9_sales_finance_adapter", True)
    return wrapper


if callable(_ORIG_COMPLETE_SALE):
    AppService.complete_sale = _wrap_complete_sale(_ORIG_COMPLETE_SALE)
if callable(_ORIG_RETURN_ITEM):
    AppService.return_item = _wrap_return_item(_ORIG_RETURN_ITEM)
if callable(_ORIG_RETURN_FULL_SALE):
    AppService.return_full_sale = _wrap_return_full_sale(_ORIG_RETURN_FULL_SALE)
if callable(_ORIG_ADD_PAYMENT):
    AppService.add_payment = _wrap_add_payment(_ORIG_ADD_PAYMENT)
if callable(_ORIG_OPEN_CASHIER_SHIFT):
    AppService.open_cashier_shift = _wrap_cash_shift(_ORIG_OPEN_CASHIER_SHIFT, "open_cashier_shift")
if callable(_ORIG_CLOSE_CASHIER_SHIFT):
    AppService.close_cashier_shift = _wrap_cash_shift(_ORIG_CLOSE_CASHIER_SHIFT, "close_cashier_shift")


# Stage 24: expose native update/delete sale methods when the historical AppService
# does not define them.  They restore old stock before replacing/removing lines.
def _app_update_sale(self: AppService, sale_id: int, cart: list[dict[str, Any]], employee_id: int, customer_id: int | None, payment_method: str, discount_amount: Any = 0, note: str = "", user_id: int | None = None, discount_type: str = "amount", reason: str = "") -> Any:
    write_result = run_write_operation(
        operation="update_sale",
        preview={"sale_id": sale_id, "items": list(cart or []), "reason": reason},
        native_call=lambda: update_sale_native(self, sale_id, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type, reason),
    )
    return write_result.result


def _app_delete_sale(self: AppService, sale_id: int, reason: str = "", user_id: int | None = None) -> Any:
    write_result = run_write_operation(
        operation="delete_sale",
        preview={"sale_id": sale_id, "reason": reason},
        native_call=lambda: delete_sale_native(self, sale_id, reason, user_id),
    )
    return write_result.result


AppService.update_sale = _app_update_sale
AppService.delete_sale = _app_delete_sale
