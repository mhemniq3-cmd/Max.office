from __future__ import annotations

import base64, html, io, shutil, sqlite3
from datetime import datetime, date
from pathlib import Path

from services.app_core import AppService
from services.core_common import now_text, money, to_int, password_hash, validate_password_strength
from services.error_logger import log_exception

EXTRA_PERMS = {
    'can_reprint_invoice': 'إعادة طباعة فاتورة',
    'can_cancel_invoice': 'إلغاء فاتورة',
    'can_receive_debt_payment': 'تسديد دين',
    'can_manage_promotions': 'إدارة العروض',
}

_ORIG_INIT = AppService.__init__
_ORIG_ROLE_PERMISSIONS = AppService.role_permissions
_ORIG_USER_HAS = AppService.user_has


def _ensure_schema(self: AppService) -> None:
    for col in EXTRA_PERMS:
        try: self.db.add_column_if_missing('users', col, 'INTEGER NOT NULL DEFAULT 0')
        except Exception:
            try: self.db.conn.execute(f'ALTER TABLE users ADD COLUMN {col} INTEGER NOT NULL DEFAULT 0')
            except Exception as exc: log_exception(exc)
    for table, col, sql in [
        ('sales','cancel_reason','TEXT'), ('sales','cancelled_by_user_id','INTEGER'), ('sales','cancelled_at','TEXT'),
        ('products','deactivated_by_user_id','INTEGER'), ('products','deactivated_at','TEXT'),
        ('customers','deactivated_by_user_id','INTEGER'), ('customers','deactivated_at','TEXT'),
        ('users','deactivated_by_user_id','INTEGER'), ('users','deactivated_at','TEXT'),
    ]:
        try: self.db.add_column_if_missing(table, col, sql)
        except Exception as exc: log_exception(exc)
    self.db.conn.executescript('''
        CREATE TABLE IF NOT EXISTS invoice_reprints(id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, invoice_no TEXT NOT NULL, user_id INTEGER, reason TEXT, created_at TEXT NOT NULL);
    ''')
    for key, val in {
        'first_run_completed':'1', 'auto_backup_on_close':'1', 'daily_backup_enabled':'1', 'backup_days_warning':'3',
        'paper_size':'80mm', 'invoice_template':'thermal', 'company_tax_number':'', 'company_logo_path':'',
    }.items():
        self.db.conn.execute('INSERT OR IGNORE INTO app_settings(key,value) VALUES(?,?)', (key, val))
    self.db.conn.execute("UPDATE users SET can_reprint_invoice=1, can_cancel_invoice=1, can_receive_debt_payment=1, can_manage_promotions=1 WHERE role='مدير' OR username='admin'")
    self.db.conn.commit()


def _init(self: AppService, db):
    _ORIG_INIT(self, db)
    _ensure_schema(self)


def _role_permissions(self: AppService, role: str):
    data = dict(_ORIG_ROLE_PERMISSIONS(self, role))
    for key in EXTRA_PERMS: data.setdefault(key, 0)
    if role == 'مدير':
        for key in EXTRA_PERMS: data[key] = 1
    elif role == 'محاسب':
        data.update(can_reprint_invoice=1, can_cancel_invoice=1, can_receive_debt_payment=1)
    elif role in ('كاشير','موظف مبيعات'):
        data.update(can_receive_debt_payment=1)
    return data


def _user_has(self: AppService, user, permission: str) -> bool:
    if permission in EXTRA_PERMS:
        try:
            if self.is_admin_user(user): return True
            return bool(user[permission])
        except Exception:
            fallback = {'can_reprint_invoice':'can_print','can_cancel_invoice':'can_returns','can_receive_debt_payment':'can_customers','can_manage_promotions':'can_tools'}[permission]
            return _ORIG_USER_HAS(self, user, fallback)
    return _ORIG_USER_HAS(self, user, permission)


def _user_message(self: AppService, exc: Exception) -> str:
    text = str(exc or '').strip()
    if isinstance(exc, (ValueError, PermissionError)) and text: return text
    rules = [('UNIQUE constraint failed: products.barcode','هذا الباركود مستخدم مسبقًا.'),('UNIQUE constraint failed: users.username','اسم المستخدم مستخدم مسبقًا.'),('UNIQUE constraint failed','القيمة مكررة.'),('database is locked','قاعدة البيانات مشغولة، حاول مرة أخرى.'),('FOREIGN KEY constraint failed','لا يمكن تنفيذ العملية لأنها مرتبطة بسجلات أخرى.')]
    for n, m in rules:
        if n in text: return m
    log_exception(exc)
    return text if text and 'Traceback' not in text and len(text) < 160 else 'تعذر تنفيذ العملية. تم تسجيل التفاصيل في logs/error.log.'


def _list_products(self: AppService, term: str = '', category: str = '', stock_state: str = 'active'):
    where, params = [], []
    if stock_state != 'all': where.append('active=0' if stock_state == 'inactive' else 'active=1')
    if term:
        like=f'%{term.strip()}%'; where.append('(name LIKE ? OR barcode LIKE ? OR category LIKE ?)'); params += [like, like, like]
    if category: where.append("COALESCE(category,'')=?"); params.append(category)
    if stock_state == 'low': where.append('quantity > 0 AND quantity <= min_quantity')
    elif stock_state == 'out': where.append('quantity <= 0')
    elif stock_state == 'expired': where.append("expiry_date IS NOT NULL AND TRIM(expiry_date)<>'' AND date(expiry_date)<date('now')")
    elif stock_state == 'expiring': where.append("expiry_date IS NOT NULL AND TRIM(expiry_date)<>'' AND date(expiry_date) BETWEEN date('now') AND date('now','+30 day')")
    sql='SELECT * FROM products' + ((' WHERE ' + ' AND '.join(where)) if where else '') + ' ORDER BY active DESC, name LIMIT 1000'
    rows=[dict(r) for r in self.db.all(sql, params)]
    if not self.user_has(self.current_user(), 'can_view_cost'):
        for r in rows: r['cost_price']=0
    return rows


def _product_categories(self: AppService):
    return [r['category'] for r in self.db.all("SELECT DISTINCT category FROM products WHERE COALESCE(category,'')<>'' ORDER BY category")]


def _delete_or_deactivate_product(self: AppService, product_id: int, actor_user_id: int|None=None, reason: str='') -> str:
    u = self.require_permission('can_product_delete', actor_user_id, 'تعطيل منتج')
    row = self.db.one('SELECT name FROM products WHERE id=?', (product_id,))
    if not row: raise ValueError('المنتج غير موجود')
    self.db.execute('UPDATE products SET active=0, deactivated_by_user_id=?, deactivated_at=? WHERE id=?', (u['id'], now_text(), product_id))
    self.log('تعطيل منتج', f"{row['name']} | السبب: {reason or 'بدون سبب'}", u['id'])
    return 'تم تعطيل المنتج بدل حذفه للحفاظ على الفواتير والتقارير.'


def _delete_or_deactivate_customer(self: AppService, customer_id: int, actor_user_id: int|None=None, reason: str='') -> str:
    u = self.require_permission('can_customers', actor_user_id, 'تعطيل زبون')
    row = self.db.one('SELECT name FROM customers WHERE id=?', (customer_id,))
    if not row: raise ValueError('الزبون غير موجود')
    self.db.execute('UPDATE customers SET active=0, deactivated_by_user_id=?, deactivated_at=? WHERE id=?', (u['id'], now_text(), customer_id))
    self.log('تعطيل زبون', f"{row['name']} | السبب: {reason or 'بدون سبب'}", u['id'])
    return 'تم تعطيل الزبون بدل حذفه للحفاظ على كشوف الحساب.'


def _delete_or_deactivate_user(self: AppService, user_id: int, actor_user_id: int|None=None, reason: str='') -> str:
    u = self.require_permission('can_users', actor_user_id, 'تعطيل مستخدم')
    target = self.db.one('SELECT username, can_users FROM users WHERE id=?', (user_id,))
    if not target: raise ValueError('المستخدم غير موجود')
    cnt = self.db.one('SELECT COUNT(*) c FROM users WHERE active=1 AND can_users=1')
    if target['can_users'] and cnt and cnt['c'] <= 1: raise ValueError('لا يمكن تعطيل آخر مدير للمستخدمين')
    self.db.execute('UPDATE users SET active=0, deactivated_by_user_id=?, deactivated_at=? WHERE id=?', (u['id'], now_text(), user_id))
    self.log('تعطيل مستخدم', f"{target['username']} | السبب: {reason or 'بدون سبب'}", u['id'])
    return 'تم تعطيل المستخدم بدل حذفه للحفاظ على سجل العمليات.'


def _cancel_sale(self: AppService, invoice_no: str, reason: str, user_id: int|None=None) -> str:
    u = self.require_any_permission(('can_cancel_invoice','can_return_full'), user_id, 'إلغاء فاتورة')
    reason = (reason or '').strip()
    if not reason: raise ValueError('سبب إلغاء الفاتورة مطلوب')
    sale = self.db.one('SELECT * FROM sales WHERE invoice_no=?', (invoice_no,))
    if not sale: raise ValueError('الفاتورة غير موجودة')
    if sale['status'] == 'cancelled': raise ValueError('الفاتورة ملغاة مسبقًا')
    items = self.db.all('SELECT * FROM sale_items WHERE sale_id=?', (sale['id'],))
    with self.db.conn:
        for it in items:
            p = self.db.conn.execute('SELECT quantity FROM products WHERE id=?', (it['product_id'],)).fetchone()
            old = int(p['quantity']) if p else 0; new = old + int(it['quantity'])
            self.db.conn.execute('UPDATE products SET quantity=? WHERE id=?', (new, it['product_id']))
            self.db.conn.execute('INSERT INTO inventory_movements(product_id,movement_type,quantity_change,old_quantity,new_quantity,ref_type,ref_no,note,user_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)', (it['product_id'],'إلغاء فاتورة',int(it['quantity']),old,new,'sale_cancel',invoice_no,reason,u['id'],now_text()))
        self.db.conn.execute("UPDATE sales SET status='cancelled', cancel_reason=?, cancelled_by_user_id=?, cancelled_at=? WHERE id=?", (reason,u['id'],now_text(),sale['id']))
    self.log('إلغاء فاتورة', f'{invoice_no} | السبب: {reason}', u['id'])
    return 'تم إلغاء الفاتورة وعكس المخزون.'


def _backup_database(self: AppService, user_id: int|None=None, system: bool=False) -> Path:
    if not system: self.require_permission('can_backup', user_id, 'نسخة احتياطية')
    Path('backups').mkdir(exist_ok=True)
    target = Path('backups') / f"max_sales_qt_backup_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.db"
    shutil.copy2(self.db.path, target)
    self.db.execute('INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', ('last_auto_backup_date', date.today().isoformat()))
    self.log('نسخة احتياطية', str(target), user_id)
    return target


def _test_backup_integrity(self: AppService, path: str|Path|None=None):
    try:
        if path is None:
            backups = sorted(Path('backups').glob('*.db'), key=lambda p:p.stat().st_mtime, reverse=True)
            if not backups: return False, 'لا توجد نسخة احتياطية لاختبارها'
            path = backups[0]
        con = sqlite3.connect(path)
        try:
            res = con.execute('PRAGMA integrity_check').fetchone()[0]
            if res != 'ok': return False, f'فحص SQLite فشل: {res}'
            for t in ('users','products','sales'): con.execute(f'SELECT COUNT(*) FROM {t}').fetchone()
        finally: con.close()
        return True, f'النسخة سليمة: {path}'
    except Exception as exc:
        log_exception(exc); return False, _user_message(self, exc)


def _backup_health(self: AppService):
    backups = sorted(Path('backups').glob('*.db'), key=lambda p:p.stat().st_mtime, reverse=True)
    warn = max(to_int(self.get_settings().get('backup_days_warning'), 3), 1)
    if not backups: return {'ok':False,'message':'لا توجد أي نسخة احتياطية حتى الآن','last':'','days':None}
    days = (datetime.now() - datetime.fromtimestamp(backups[0].stat().st_mtime)).days
    return {'ok': days <= warn, 'message': 'النسخ الاحتياطي محدث' if days <= warn else f'آخر نسخة منذ {days} أيام', 'last': str(backups[0]), 'days': days}


def _auto_backup_if_due(self: AppService):
    st=self.get_settings()
    if str(st.get('daily_backup_enabled', st.get('auto_backup_enabled','1'))) not in ('1','true','True','نعم'): return False, 'النسخ اليومي غير مفعل'
    if st.get('last_auto_backup_date') == date.today().isoformat(): return False, 'تم إنشاء نسخة اليوم مسبقًا'
    try: return True, str(_backup_database(self, system=True))
    except Exception as exc: log_exception(exc); return False, _user_message(self, exc)


def _backup_on_close_if_enabled(self: AppService):
    if str(self.get_settings().get('auto_backup_on_close','1')) not in ('1','true','True','نعم'): return False, 'النسخ عند الإغلاق غير مفعل'
    try: return True, str(_backup_database(self, system=True))
    except Exception as exc: log_exception(exc); return False, _user_message(self, exc)


def _daily_business_report(self: AppService, day: str|None=None):
    day = day or date.today().isoformat()
    sales=self.db.one("SELECT COUNT(*) invoices, COALESCE(SUM(total),0) total, COALESCE(SUM(total_profit),0) profit FROM sales WHERE status='completed' AND date(created_at)=date(?)", (day,))
    has_exp = self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name='expenses'")
    exp=self.db.one("SELECT COALESCE(SUM(amount),0) amount FROM expenses WHERE date(expense_date)=date(?)", (day,)) if has_exp else {'amount':0}
    ret=self.db.one("SELECT COUNT(*) count, COALESCE(SUM(amount),0) amount FROM returns WHERE date(created_at)=date(?)", (day,))
    debts=self.db.one("SELECT COALESCE(SUM(total),0) amount FROM sales WHERE payment_method='آجل' AND status='completed' AND date(created_at)=date(?)", (day,))
    pays=self.db.one("SELECT COALESCE(SUM(amount),0) amount FROM customer_payments WHERE date(created_at)=date(?)", (day,))
    top=self.db.all("SELECT si.product_name, SUM(si.quantity) qty, SUM(si.line_total) total FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.status='completed' AND date(s.created_at)=date(?) GROUP BY si.product_id, si.product_name ORDER BY qty DESC LIMIT 10", (day,))
    cash=self.db.all("SELECT COALESCE(NULLIF(u.full_name,''),u.username,'غير محدد') AS cashier, COUNT(s.id) AS invoices, COALESCE(SUM(s.total),0) AS total FROM sales s LEFT JOIN users u ON u.id=s.user_id WHERE s.status='completed' AND date(s.created_at)=date(?) GROUP BY COALESCE(s.user_id,0) ORDER BY total DESC LIMIT 5", (day,))
    return {'date':day,'sales_total':float(sales['total'] if sales else 0),'invoice_count':int(sales['invoices'] if sales else 0),'net_profit':float(sales['profit'] if sales else 0)-float(exp['amount'] if exp else 0),'expenses':float(exp['amount'] if exp else 0),'returns':float(ret['amount'] if ret else 0),'returns_count':int(ret['count'] if ret else 0),'new_debts':float(debts['amount'] if debts else 0),'payments_received':float(pays['amount'] if pays else 0),'top_products':[dict(r) for r in top],'best_cashiers':[dict(r) for r in cash]}


def _export_daily_report_html(self: AppService, day: str|None=None) -> Path:
    r=_daily_business_report(self, day)
    rows=''.join(f'<tr><th>{html.escape(k)}</th><td>{html.escape(str(v))}</td></tr>' for k,v in [('إجمالي المبيعات',money(r['sales_total'])),('عدد الفواتير',r['invoice_count']),('صافي الربح',money(r['net_profit'])),('المصاريف',money(r['expenses'])),('المرتجعات',money(r['returns'])),('الديون الجديدة',money(r['new_debts'])),('الدفعات المستلمة',money(r['payments_received']))])
    top=''.join(f"<tr><td>{html.escape(x['product_name'])}</td><td>{x['qty']}</td><td>{money(x['total'])}</td></tr>" for x in r['top_products']) or '<tr><td colspan=3>لا توجد مبيعات</td></tr>'
    cash=''.join(f"<tr><td>{html.escape(x['cashier'])}</td><td>{x['invoices']}</td><td>{money(x['total'])}</td></tr>" for x in r['best_cashiers']) or '<tr><td colspan=3>لا توجد مبيعات</td></tr>'
    return self._html_page('daily_report_'+r['date'], f"<h3>تقرير يومي احترافي - {r['date']}</h3><table>{rows}</table><h3>أفضل المنتجات</h3><table><tr><th>المنتج</th><th>الكمية</th><th>الإجمالي</th></tr>{top}</table><h3>أفضل كاشير</h3><table><tr><th>الكاشير</th><th>الفواتير</th><th>المبيعات</th></tr>{cash}</table>")


def _export_daily_report_excel(self: AppService, day: str|None=None) -> Path:
    import openpyxl
    r=_daily_business_report(self, day)
    wb=openpyxl.Workbook(); ws=wb.active; ws.title='Daily Report'; ws.append(['البند','القيمة'])
    for k in ['date','sales_total','invoice_count','net_profit','expenses','returns','new_debts','payments_received']: ws.append([k,r[k]])
    ws2=wb.create_sheet('Top Products'); ws2.append(['المنتج','الكمية','الإجمالي'])
    for x in r['top_products']: ws2.append([x['product_name'],x['qty'],x['total']])
    ws3=wb.create_sheet('Best Cashiers'); ws3.append(['الكاشير','الفواتير','المبيعات'])
    for x in r['best_cashiers']: ws3.append([x['cashier'],x['invoices'],x['total']])
    p=self.export_dir()/f"daily_report_{r['date']}_{datetime.now().strftime('%H%M%S')}.xlsx"; wb.save(p); return p


def _promotions_by_status(self: AppService, today: str|None=None):
    today = today or date.today().isoformat(); out={'active':[],'expired':[],'upcoming':[]}
    for row in [dict(r) for r in self.db.all('SELECT * FROM promotions ORDER BY active DESC, priority DESC, id DESC')]:
        start=(row.get('start_date') or '').strip(); end=(row.get('end_date') or '').strip()
        if not row.get('active') or (end and end < today): out['expired'].append(row)
        elif start and start > today: out['upcoming'].append(row)
        else: out['active'].append(row)
    return out


def _smart_alerts(self: AppService):
    alerts=[]
    try:
        for label, sql in [('منتجات قاربت على النفاد','SELECT COUNT(*) c FROM products WHERE active=1 AND quantity>0 AND quantity<=min_quantity'),('منتجات نافدة','SELECT COUNT(*) c FROM products WHERE active=1 AND quantity<=0'),('منتجات قاربت على انتهاء الصلاحية',"SELECT COUNT(*) c FROM products WHERE active=1 AND expiry_date IS NOT NULL AND TRIM(expiry_date)<>'' AND date(expiry_date) BETWEEN date('now') AND date('now','+30 day')"),('منتجات منتهية الصلاحية',"SELECT COUNT(*) c FROM products WHERE active=1 AND expiry_date IS NOT NULL AND TRIM(expiry_date)<>'' AND date(expiry_date)<date('now')")]:
            c=self.db.one(sql); 
            if c and c['c']: alerts.append(f'{label}: {c["c"]}')
        for row in self.debt_rows()[:5]:
            if float(row['balance'] or 0)>0 and row['credit_limit'] and float(row['balance']) > float(row['credit_limit']): alerts.append(f"زبون تجاوز حد الدين: {row['name']} - {money(row['balance'])}")
        health=_backup_health(self)
        if not health['ok']: alerts.append(health['message'])
        today=date.today().isoformat(); hd=self.db.one("SELECT COUNT(*) c FROM sales WHERE date(created_at)=date(?) AND subtotal>0 AND discount_amount/subtotal>=0.2", (today,))
        if hd and hd['c']: alerts.append(f"خصومات عالية اليوم: {hd['c']} فاتورة")
        rr=self.db.one("SELECT COUNT(*) c FROM returns WHERE date(created_at)=date(?)", (today,))
        if rr and rr['c']>=5: alerts.append(f"مرتجعات كثيرة اليوم: {rr['c']} عملية")
    except Exception as exc: log_exception(exc); alerts.append('تعذر تحميل بعض التنبيهات. راجع logs/error.log')
    return alerts


def _needs_first_run_setup(self: AppService) -> bool:
    # V33.1: first-run wizard disabled by request; keep method only for compatibility.
    return False


def _complete_first_run_setup(self: AppService, data: dict):
    user=(data.get('manager_username') or 'admin').strip(); pwd=(data.get('manager_password') or '').strip(); name=(data.get('manager_name') or 'مدير النظام').strip()
    validate_password_strength(pwd, user)
    settings={'company_name':data.get('company_name') or 'ماكس للمبيعات','company_phone':data.get('company_phone') or '','company_address':data.get('company_address') or '','currency':data.get('currency') or 'د.ع','tax_percent':str(data.get('tax_percent') or '0'),'auto_backup_on_close':'1' if data.get('auto_backup_on_close') else '0','daily_backup_enabled':'1' if data.get('daily_backup_enabled') else '0','first_run_completed':'1'}
    for k,v in settings.items(): self.db.execute('INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (k,str(v)))
    admin=self.db.one("SELECT id FROM users WHERE username='admin'")
    if admin: self.db.execute("UPDATE users SET username=?, full_name=?, password_hash=?, must_change_password=0, role='مدير', active=1 WHERE id=?", (user,name,password_hash(pwd),admin['id']))
    self.db.execute("UPDATE users SET can_reprint_invoice=1, can_cancel_invoice=1, can_receive_debt_payment=1, can_manage_promotions=1 WHERE role='مدير' OR username=?", (user,))
    self.log('إعداد أول تشغيل', f"الشركة: {settings['company_name']} | المدير: {user}")


def _print_invoice_html(self: AppService, invoice_no: str) -> Path:
    sale, items = self.invoice_details(invoice_no)
    prior=self.db.one('SELECT COUNT(*) c FROM invoice_reprints WHERE sale_id=?', (sale['id'],))
    self.require_any_permission(('can_reprint_invoice','can_print') if prior and prior['c'] else ('can_print',), action='طباعة فاتورة')
    self.db.execute('INSERT INTO invoice_reprints(sale_id,invoice_no,user_id,reason,created_at) VALUES(?,?,?,?,?)', (sale['id'], invoice_no, getattr(self,'current_user_id',None), 'طباعة/إعادة طباعة', now_text()))
    st=self.get_settings(); rows=''
    for i in items:
        extra=''
        if 'free_quantity' in i.keys() and i['free_quantity']:
            extra=f"<div class='muted'>مدفوع: {int(i['quantity'])-int(i['free_quantity'])} | مجاني: {int(i['free_quantity'])}</div>"
        level = html.escape(i['price_level_name'] or '') if 'price_level_name' in i.keys() else ''
        promo = html.escape(i['promotion_name'] or '') if 'promotion_name' in i.keys() else ''
        rows += f"<tr><td>{html.escape(i['product_name'])}<br><span class='muted'>{level} {promo}</span>{extra}</td><td>{i['quantity']}</td><td>{money(i['unit_price'])}</td><td>{money(i['line_total'])}</td></tr>"
    qr_text=f"{st.get('company_name','')}|{sale['invoice_no']}|{sale['created_at']}|{sale['total']}|{sale['payment_method']}"
    qr_html=f"<div class='qr'>QR فاتورة: {html.escape(qr_text)}</div>"
    try:
        import qrcode
        img=qrcode.make(qr_text); bio=io.BytesIO(); img.save(bio, format='PNG')
        qr_html=f"<div class='qrBox'><img class='qrimg' src='data:image/png;base64,{base64.b64encode(bio.getvalue()).decode()}'><br><small>QR فاتورة</small></div>"
    except Exception as exc: log_exception(exc)
    width='80mm' if st.get('paper_size','80mm')=='80mm' else '210mm'
    style=f"body{{font-family:Tahoma,Arial;margin:12px;color:#111}}.head{{text-align:center;border-bottom:1px solid #222;padding-bottom:8px}}table{{width:100%;border-collapse:collapse;margin-top:10px}}td,th{{border:1px solid #ddd;padding:6px;text-align:center}}th{{background:#f1f5f9}}.total{{font-size:18px;font-weight:bold}}.muted{{color:#555;font-size:11px}}.qrimg{{width:90px;height:90px}}@media print{{body{{width:{width};margin:0 auto}}}}"
    tax_no=st.get('company_tax_number','')
    body=f"<div class='head'><h2>{html.escape(st.get('company_name','ماكس للمبيعات'))}</h2><div>{html.escape(st.get('company_phone',''))} - {html.escape(st.get('company_address',''))}</div><div>{'الرقم الضريبي: '+html.escape(tax_no) if tax_no else ''}</div></div><h3>فاتورة بيع: {html.escape(sale['invoice_no'])}</h3><p>التاريخ: {sale['created_at']}<br>الكاشير: {html.escape(sale['user_name'])}<br>موظف العمولة: {html.escape(sale['employee'])}<br>الزبون: {html.escape(sale['customer'])}<br>طريقة الدفع: {html.escape(sale['payment_method'])}</p><table><tr><th>المادة</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr>{rows}</table><p>الخصم: {money(sale['discount_amount'])} | الضريبة: {money(sale['tax_amount'])}</p><p class='total'>الصافي: {money(sale['total'])}</p>{qr_html}<p class='muted'>{html.escape(st.get('invoice_footer','شكراً لتعاملكم معنا'))}</p><script>window.print()</script>"
    p=self.export_dir()/f"invoice_{sale['invoice_no'].replace('/','_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
    p.write_text(f"<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'><title>{html.escape(sale['invoice_no'])}</title><style>{style}</style></head><body>{body}</body></html>", encoding='utf-8')
    return p

AppService.__init__ = _init
AppService.role_permissions = _role_permissions
AppService.user_has = _user_has
AppService.user_message = _user_message
AppService.list_products = _list_products
AppService.product_categories = _product_categories
AppService.delete_or_deactivate_product = _delete_or_deactivate_product
AppService.delete_or_deactivate_customer = _delete_or_deactivate_customer
AppService.delete_or_deactivate_user = _delete_or_deactivate_user
AppService.cancel_sale = _cancel_sale
AppService.backup_database = _backup_database
AppService.test_backup_integrity = _test_backup_integrity
AppService.backup_health = _backup_health
AppService.auto_backup_if_due = _auto_backup_if_due
AppService.backup_on_close_if_enabled = _backup_on_close_if_enabled
AppService.daily_business_report = _daily_business_report
AppService.export_daily_report_html = _export_daily_report_html
AppService.export_daily_report_excel = _export_daily_report_excel
AppService.promotions_by_status = _promotions_by_status
AppService.smart_alerts = _smart_alerts
AppService.needs_first_run_setup = _needs_first_run_setup
AppService.complete_first_run_setup = _complete_first_run_setup
AppService.print_invoice_html = _print_invoice_html
