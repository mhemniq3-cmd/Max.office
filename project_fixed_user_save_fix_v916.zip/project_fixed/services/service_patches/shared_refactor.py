from __future__ import annotations

"""V45.12 shared-refactor patch.

This version keeps the v44 visual design and does not remove historical patch
files, but it stops the highest-risk duplication at runtime by centralising the
repeated operations behind shared modules:
- Decimal invoice math in services.shared.finance
- date normalization in services.shared.dates
- text validation in services.shared.validation
- LIKE search building in services.shared.search
- CSV export in services.shared.exporting
- transaction helpers in services.shared.db_ops

The public AppService API is unchanged, so existing UI pages continue to work.
"""

from pathlib import Path
from typing import Any

from services.app_core import AppService
from services.core_common import now_text
from services.error_logger import log_exception, log_message
from services.shared import finance, search, validation, dates, exporting, db_ops
from services.service_patches import portability_decimal_hardening as v4510
from services.service_patches import integrity_security_finance as v4511

PROJECT_ROOT = Path(__file__).resolve().parents[2]
EXPORT_DIR = PROJECT_ROOT / 'exports'


def _shared_clean_cart(self: AppService, cart: list[dict]) -> list[dict]:
    if not cart:
        raise ValueError('السلة فارغة')
    clean: list[dict[str, Any]] = []
    for raw in cart:
        if not isinstance(raw, dict):
            raise ValueError('يوجد سطر غير صالح داخل السلة')
        product_id = validation.assert_positive_int(raw.get('product_id'), 'رقم المنتج')
        qty = validation.assert_positive_int(raw.get('quantity'), 'الكمية')
        product = self.db.one('''
            SELECT id, name, cost_price, sale_price, quantity, commission_percent, active
            FROM products
            WHERE id=? AND active=1
        ''', (product_id,))
        if not product:
            raise ValueError('يوجد منتج غير موجود أو معطل داخل السلة')
        stock = int(product['quantity'] or 0)
        if stock < qty:
            raise ValueError(f"المخزون غير كاف للمنتج: {product['name']}")
        official = finance.money2(product['sale_price'])
        requested = finance.money2(raw.get('unit_price', official))
        unit_price = requested if requested > 0 else official
        if unit_price <= 0:
            raise ValueError(f"سعر المنتج غير صالح: {product['name']}")
        clean.append({
            'product_id': int(product['id']),
            'product_name': validation.clean_text(product['name'], 180, required=True, field='اسم المنتج'),
            'quantity': qty,
            'cost_price': finance.money2(product['cost_price']),
            'unit_price': unit_price,
            'commission_percent': finance.money2(product['commission_percent']),
            'official_sale_price': official,
        })
    return clean


def _shared_log_sale_security(self: AppService, clean_cart: list[dict], subtotal, discount_pct, user_id: int | None) -> None:
    try:
        v4510._log_sale_security(self, clean_cart, subtotal, discount_pct, user_id)
    except Exception as exc:
        log_exception(exc, 'V45.12 sale security logging')


def _v4512_complete_sale(self: AppService, cart: list[dict], employee_id: int, customer_id: int | None, payment_method: str, discount_amount: float = 0, note: str = '', user_id: int | None = None, discount_type: str = 'amount') -> str:
    user = self.require_any_permission(('can_sales', 'can_touch_pos'), user_id, 'إتمام البيع')
    user_id = int(user['id'])
    employee_id = validation.assert_positive_int(employee_id, 'الموظف')
    employee = self.db.one('SELECT id, active FROM employees WHERE id=? AND active=1', (employee_id,))
    if not employee:
        raise ValueError('الموظف المختار غير موجود أو معطل')

    clean_cart = _shared_clean_cart(self, cart or [])
    totals = finance.calculate_invoice_totals(
        clean_cart,
        discount_value=discount_amount,
        discount_type=discount_type,
        tax_percent=self.get_settings().get('tax_percent', 0),
    )
    _shared_log_sale_security(self, clean_cart, totals.subtotal, totals.discount_percent, user_id)

    safe_payment = validation.clean_text(payment_method, 40) or 'نقدي'
    safe_note = validation.clean_text(note, 1000)
    created = now_text()
    customer_value = int(customer_id) if customer_id else None

    with self.db.conn:
        inv = self.next_document_no('sale', 'MAX') if hasattr(self, 'next_document_no') else v4510.invoice_no()
        cur = self.db.conn.execute('''
            INSERT INTO sales
            (invoice_no, user_id, employee_id, customer_id, subtotal, discount_amount, total, total_commission, total_profit, payment_method, discount_type, tax_amount, note, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            inv, user_id, employee_id, customer_value,
            finance.db_money(totals.subtotal), finance.db_money(totals.discount_amount), finance.db_money(totals.total),
            finance.db_money(totals.commission), finance.db_money(totals.profit), safe_payment,
            totals.discount_type, finance.db_money(totals.tax_amount), safe_note, created,
        ))
        sale_id = int(cur.lastrowid)
        for line in totals.lines:
            item = line.item
            self.db.conn.execute('''
                INSERT INTO sale_items
                (sale_id, product_id, product_name, quantity, cost_price, unit_price, line_total, commission_percent, commission_amount, profit_amount)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                sale_id, item['product_id'], item['product_name'], item['quantity'], finance.db_money(item['cost_price']),
                finance.db_money(item['unit_price']), finance.db_money(line.line_total), finance.db_money(item['commission_percent']),
                finance.db_money(line.commission_amount), finance.db_money(line.profit_amount),
            ))
            oldq_row = self.db.conn.execute('SELECT quantity FROM products WHERE id=? AND active=1', (item['product_id'],)).fetchone()
            oldq = int(oldq_row['quantity'] if oldq_row else 0)
            updated = self.db.conn.execute(
                'UPDATE products SET quantity = quantity - ? WHERE id=? AND active=1 AND quantity >= ?',
                (int(item['quantity']), item['product_id'], int(item['quantity'])),
            )
            if updated.rowcount != 1:
                raise ValueError(f"المخزون غير كاف أو تغير أثناء البيع للمنتج: {item['product_name']}")
            newq_row = self.db.conn.execute('SELECT quantity FROM products WHERE id=?', (item['product_id'],)).fetchone()
            newq = int(newq_row['quantity'] if newq_row else oldq - int(item['quantity']))
            self.db.conn.execute('''
                INSERT INTO inventory_movements
                (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (item['product_id'], 'بيع', -int(item['quantity']), oldq, newq, 'sale', inv, '', user_id, created))
        account = v4511._account_id(self, v4511._payment_account_name(safe_payment))
        self.db.conn.execute('''
            INSERT INTO cash_movements
            (account_id, movement_type, ref_type, ref_no, amount, payment_method, direction, note, user_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (account, 'بيع', 'sale', inv, finance.db_money(totals.total), safe_payment, 'in', safe_note, user_id, created))
    self.log('بيع', inv, user_id)
    try:
        if hasattr(self, 'archive_sale_invoice'):
            self.archive_sale_invoice(inv)
    except Exception as exc:
        log_exception(exc, 'V45.12 archive sale')
    return inv


def _v4512_suspend_sale(self: AppService, cart: list[dict], employee_id: int | None, customer_id: int | None, payment_method: str, discount_amount: float, note: str = '', user_id: int | None = None) -> str:
    clean = _shared_clean_cart(self, cart or [])
    finance.calculate_invoice_totals(clean, discount_value=discount_amount, discount_type='amount', tax_percent=0)
    json_safe = []
    for item in clean:
        row = dict(item)
        row.pop('official_sale_price', None)
        for key in ('cost_price', 'unit_price', 'commission_percent'):
            row[key] = finance.db_money(row[key])
        json_safe.append(row)
    # Delegate persistence to the previous stable suspend_sale implementation.
    return v4510._prev_suspend_sale_v4510(self, json_safe, employee_id, customer_id, validation.clean_text(payment_method, 40) or 'نقدي', finance.db_money(discount_amount), validation.clean_text(note, 1000), user_id)


def _v4512_list_products(self: AppService, term: str = '', category: str = '', state: str = 'active'):
    term = validation.clean_text(term, 120)
    category = validation.clean_text(category, 120)
    state = validation.clean_text(state, 30) or 'active'
    where: list[str] = []
    params: list[Any] = []
    if state == 'inactive':
        where.append('active=0')
    elif state == 'low':
        where.append('active=1 AND quantity <= min_quantity')
    elif state == 'out':
        where.append('active=1 AND quantity <= 0')
    elif state != 'all':
        where.append('active=1')
    clause, like_params = search.build_like_filter(['name', 'barcode', 'category'], term)
    if clause:
        where.append(clause)
        params.extend(like_params)
    if category:
        where.append('category=?')
        params.append(category)
    sql = 'SELECT * FROM products'
    if where:
        sql += ' WHERE ' + ' AND '.join(where)
    sql += ' ORDER BY active DESC, name LIMIT ?'
    params.append(500)
    return self.db.all(sql, params)


def _v4512_search_archive(self: AppService, query: str = '', doc_type: str = '', date_from: str = '', date_to: str = '', limit: int = 300):
    self.require_any_permission(('can_tools', 'can_reports', 'can_audit', 'can_print'), action='البحث في الأرشيف')
    where: list[str] = []
    params: list[Any] = []
    q = validation.clean_text(query, 160)
    clause, like_params = search.build_like_filter(['ref_no', 'title', 'customer_name', 'customer_phone', 'supplier_name', 'content_text', 'CAST(amount AS TEXT)'], q)
    if clause:
        where.append(clause)
        params.extend(like_params)
    if doc_type:
        where.append('doc_type=?')
        params.append(validation.clean_text(doc_type, 80))
    df = dates.normalize_iso_date(date_from) if date_from else ''
    dt = dates.normalize_iso_date(date_to) if date_to else ''
    if df:
        where.append('date(doc_date) >= date(?)')
        params.append(df)
    if dt:
        where.append('date(doc_date) <= date(?)')
        params.append(dt)
    sql = 'SELECT * FROM document_archive'
    if where:
        sql += ' WHERE ' + ' AND '.join(where)
    sql += ' ORDER BY doc_date DESC, id DESC LIMIT ?'
    params.append(search.clamp_limit(limit, 300, 1000))
    return self.db.all(sql, params)


def _v4512_export_rows_csv(self: AppService, filename: str, headers: list[str], rows: list[list[Any]]) -> Path:
    path = exporting.export_rows_csv(EXPORT_DIR, filename, headers, rows)
    self.log('تصدير CSV', str(path))
    return path


def _v4512_refactor_health(self: AppService) -> dict:
    return {
        'version': 'v45.12',
        'shared_modules': [
            'services.shared.finance', 'services.shared.dates', 'services.shared.validation',
            'services.shared.search', 'services.shared.exporting', 'services.shared.db_ops',
            'ui.shared.table_utils', 'ui.shared.dialogs',
        ],
        'runtime_overrides': ['complete_sale', 'suspend_sale', 'list_products', 'search_archive', 'export_rows_csv'],
        'single_inventory_update_in_complete_sale': True,
        'decimal_invoice_totals': True,
        'utf8_sig_csv_export': True,
    }


# Public utility shortcuts for future pages/patches.
AppService.clean_text = staticmethod(validation.clean_text)
AppService.normalize_iso_date = staticmethod(dates.normalize_iso_date)
AppService.calculate_invoice_totals = staticmethod(finance.calculate_invoice_totals)
AppService.db_transaction = staticmethod(db_ops.transaction)

# Replace duplicated hot paths with shared implementations.
AppService.complete_sale = _v4512_complete_sale
AppService.suspend_sale = _v4512_suspend_sale
AppService.list_products = _v4512_list_products
if hasattr(AppService, 'search_archive'):
    AppService.search_archive = _v4512_search_archive
AppService.export_rows_csv = _v4512_export_rows_csv
AppService.refactor_health = _v4512_refactor_health

log_message('V45.12 shared refactor patch loaded', 'info')
