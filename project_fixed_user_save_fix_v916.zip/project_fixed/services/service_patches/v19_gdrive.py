from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})

# ================================================================
# V19 GOOGLE DRIVE LOCAL FOLDER BACKUP PATCH
# Uses Google Drive for Desktop folder when configured by the user.
# No Google API credentials are required: the backup is copied to the
# selected local Google Drive folder and Google Drive syncs it normally.
# ================================================================

_orig_backup_database_gdrive = AppService.backup_database

def _is_gdrive_enabled_value(value) -> bool:
    return str(value or '').strip() in ('1', 'true', 'True', 'نعم', 'yes', 'on')

def _backup_database_gdrive(self: AppService) -> Path:
    local_path = _orig_backup_database_gdrive(self)
    settings = self.get_settings()
    enabled = _is_gdrive_enabled_value(settings.get('google_drive_backup_enabled', '0'))
    target_dir_raw = str(settings.get('google_drive_backup_path', '') or '').strip()
    if not enabled:
        return local_path
    if not target_dir_raw:
        msg = 'تم تفعيل نسخ Google Drive لكن لم يتم اختيار مجلد Google Drive'
        self.save_settings({'last_google_drive_backup_status': msg})
        self.log('فشل نسخ Google Drive', msg)
        raise ValueError(msg)
    try:
        target_dir = Path(target_dir_raw).expanduser()
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / local_path.name
        shutil.copy2(local_path, target)
        status = f'ناجح: {target}'
        self.save_settings({'last_google_drive_backup_status': status})
        self.log('نسخ احتياطي Google Drive', status)
    except Exception as exc:
        status = f'فشل: {exc}'
        self.save_settings({'last_google_drive_backup_status': status})
        self.log('فشل نسخ Google Drive', status)
        raise
    return local_path

AppService.backup_database = _backup_database_gdrive


def _test_google_drive_backup(self: AppService) -> tuple[bool, str]:
    settings = self.get_settings()
    path_raw = str(settings.get('google_drive_backup_path', '') or '').strip()
    if not path_raw:
        return False, 'لم يتم اختيار مجلد Google Drive'
    try:
        p = Path(path_raw).expanduser()
        p.mkdir(parents=True, exist_ok=True)
        test_file = p / 'max_sales_google_drive_test.txt'
        test_file.write_text('Max Sales Google Drive backup test', encoding='utf-8')
        try:
            test_file.unlink(missing_ok=True)
        except Exception as exc:
            log_exception(exc)
        return True, f'المجلد جاهز للنسخ: {p}'
    except Exception as exc:
        return False, f'تعذر استخدام المجلد: {exc}'

AppService.test_google_drive_backup = _test_google_drive_backup

