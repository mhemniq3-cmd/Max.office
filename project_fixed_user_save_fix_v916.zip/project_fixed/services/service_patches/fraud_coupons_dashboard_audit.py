
from __future__ import annotations

import json
from datetime import datetime, timedelta
from typing import Any

from services.app_core import AppService
from database import now_text
from services.error_logger import log_exception

_ORIG_INIT = AppService.__init__
_ORIG_COMPLETE_SALE = getattr(AppService, 'complete_sale', None)
_ORIG_RETURN_ITEM = getattr(AppService, 'return_item', None)
_ORIG_SAVE_PRODUCT = getattr(AppService, 'save_product', None)


def _rowdict(row: Any) -> dict:
    if not row:
        return {}
    try:
        return dict(row)
    except Exception:
        try:
            return {k: row[k] for k in row.keys()}
        except Exception:
            return {}


def _user_id(self: AppService, user_id=None):
    if user_id:
        return user_id
    try:
        if getattr(self, 'current_user_id', None):
            return self.current_user_id
    except Exception:
        pass
    return None


def _username(self: AppService, user_id=None):
    try:
        uid = _user_id(self, user_id)
        if uid:
            row = self.db.one('SELECT username FROM users WHERE id=?', (uid,))
            return row['username'] if row else ''
    except Exception:
        pass
    return ''


def _json_safe(value: Any) -> str:
    try:
        return json.dumps(value, ensure_ascii=False, default=str)
    except Exception:
        return json.dumps(str(value), ensure_ascii=False)


def _ensure_schema(self: AppService) -> None:
    conn = self.db.conn
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS fraud_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            rule_code TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'متوسطة',
            title TEXT NOT NULL,
            details TEXT,
            entity_type TEXT,
            entity_id INTEGER,
            user_id INTEGER,
            user_name TEXT,
            status TEXT NOT NULL DEFAULT 'مفتوح',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            resolved_at TEXT,
            resolved_by INTEGER,
            resolution_note TEXT
        );

        CREATE TABLE IF NOT EXISTS coupons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT NOT NULL UNIQUE,
            type TEXT NOT NULL DEFAULT 'percent',
            value REAL NOT NULL DEFAULT 0,
            min_purchase REAL NOT NULL DEFAULT 0,
            max_uses INTEGER NOT NULL DEFAULT 0,
            used_count INTEGER NOT NULL DEFAULT 0,
            expiry_date TEXT,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            table_name TEXT,
            record_id INTEGER,
            action TEXT NOT NULL,
            old_values TEXT,
            new_values TEXT,
            user_id INTEGER,
            username TEXT,
            ip TEXT,
            reason TEXT,
            timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
    """)
    try:
        conn.execute('CREATE INDEX IF NOT EXISTS idx_fraud_status_created ON fraud_alerts(status, created_at)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_fraud_rule_entity ON fraud_alerts(rule_code, entity_type, entity_id)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_coupons_code_active ON coupons(code, active)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_audit_logs_table_record ON audit_logs(table_name, record_id, timestamp)')
        conn.commit()
    except Exception:
        conn.commit()


def _init(self: AppService, *args, **kwargs):
    _ORIG_INIT(self, *args, **kwargs)
    try:
        _ensure_schema(self)
    except Exception as exc:
        log_exception(exc, 'v45.17.4.5 schema')


def _record_audit_v2(self: AppService, table_name: str, record_id: int | None, action: str, old_values=None, new_values=None, user_id=None, reason: str = '', ip: str = 'local') -> None:
    try:
        uid = _user_id(self, user_id)
        self.db.execute(
            'INSERT INTO audit_logs (table_name, record_id, action, old_values, new_values, user_id, username, ip, reason, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            (str(table_name or ''), record_id, str(action or ''), _json_safe(old_values), _json_safe(new_values), uid, _username(self, uid), str(ip or 'local')[:120], str(reason or '')[:500], now_text()),
        )
    except Exception as exc:
        log_exception(exc, 'record audit v2')


def _add_fraud_alert(self: AppService, rule_code: str, title: str, details: str = '', entity_type: str = '', entity_id=None, severity: str = 'عالية', user_id=None) -> int | None:
    try:
        uid = _user_id(self, user_id)
        cur = self.db.execute(
            'INSERT INTO fraud_alerts (rule_code, severity, title, details, entity_type, entity_id, user_id, user_name, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            (str(rule_code or ''), str(severity or 'عالية'), str(title or ''), str(details or ''), str(entity_type or ''), entity_id, uid, _username(self, uid), 'مفتوح', now_text()),
        )
        try:
            self.log('تنبيه احتيال', f'{rule_code} - {title}', uid)
        except Exception:
            pass
        return cur.lastrowid
    except Exception as exc:
        log_exception(exc, 'add fraud alert')
        return None


def _list_fraud_alerts(self: AppService, status: str = '', limit: int = 300):
    params = []
    where = []
    if status:
        where.append('status=?')
        params.append(status)
    params.append(max(1, min(int(limit or 300), 1000)))
    sql = 'SELECT id, rule_code, severity, title, details, entity_type, entity_id, user_name, status, created_at FROM fraud_alerts'
    if where:
        sql += ' WHERE ' + ' AND '.join(where)
    sql += ' ORDER BY id DESC LIMIT ?'
    return self.db.all(sql, params)


def _resolve_fraud_alert(self: AppService, alert_id: int, note: str = '', user_id=None):
    uid = _user_id(self, user_id)
    self.db.execute('UPDATE fraud_alerts SET status=?, resolved_at=?, resolved_by=?, resolution_note=? WHERE id=?', ('مغلق', now_text(), uid, str(note or ''), int(alert_id)))
    _record_audit_v2(self, 'fraud_alerts', int(alert_id), 'resolve', None, {'status':'مغلق','note':note}, uid, note)


def _fraud_scan_now(self: AppService) -> list:
    created = []
    today = datetime.now().strftime('%Y-%m-%d')
    for r in self.db.all("SELECT id, invoice_no, total, user_id FROM sales WHERE date(created_at)=date(?) AND COALESCE(total,0)<=0 LIMIT 50", (today,)):
        if not self.db.one("SELECT id FROM fraud_alerts WHERE rule_code='ZERO_INVOICE' AND entity_type='sale' AND entity_id=? AND status='مفتوح'", (r['id'],)):
            created.append(_add_fraud_alert(self, 'ZERO_INVOICE', f"فاتورة بقيمة صفرية: {r['invoice_no']}", 'فاتورة اليوم قيمتها صفر أو أقل', 'sale', r['id'], 'عالية', r['user_id'] if 'user_id' in r.keys() else None))
    for r in self.db.all("SELECT id, invoice_no, subtotal, discount_amount, user_id FROM sales WHERE date(created_at)=date(?) AND COALESCE(subtotal,0)>0 AND (COALESCE(discount_amount,0)*100.0/NULLIF(subtotal,0))>50 LIMIT 50", (today,)):
        if not self.db.one("SELECT id FROM fraud_alerts WHERE rule_code='LARGE_DISCOUNT' AND entity_type='sale' AND entity_id=? AND status='مفتوح'", (r['id'],)):
            details = f"الخصم أكبر من 50%: الخصم={r['discount_amount']} من أصل={r['subtotal']}"
            created.append(_add_fraud_alert(self, 'LARGE_DISCOUNT', f"خصم غير طبيعي: {r['invoice_no']}", details, 'sale', r['id'], 'عالية', r['user_id'] if 'user_id' in r.keys() else None))
    for r in self.db.all("SELECT product_id, COUNT(*) c, SUM(quantity) qty FROM returns WHERE date(created_at)=date(?) GROUP BY product_id HAVING COUNT(*)>3 LIMIT 50", (today,)):
        eid = int(r['product_id'] or 0)
        if not self.db.one("SELECT id FROM fraud_alerts WHERE rule_code='MANY_RETURNS_PRODUCT' AND entity_type='product' AND entity_id=? AND date(created_at)=date(?) AND status='مفتوح'", (eid, today)):
            created.append(_add_fraud_alert(self, 'MANY_RETURNS_PRODUCT', 'إرجاع متكرر لنفس المنتج', f"عدد الإرجاعات اليوم: {r['c']}، الكمية: {r['qty']}", 'product', eid, 'متوسطة'))
    for r in self.db.all("SELECT si.id, si.product_id, si.product_name, si.quantity, s.invoice_no, s.user_id FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE date(s.created_at)=date(?) AND COALESCE(si.quantity,0) >= 50 LIMIT 50", (today,)):
        if not self.db.one("SELECT id FROM fraud_alerts WHERE rule_code='UNUSUAL_QUANTITY' AND entity_type='sale_item' AND entity_id=? AND status='مفتوح'", (r['id'],)):
            created.append(_add_fraud_alert(self, 'UNUSUAL_QUANTITY', 'كمية غير طبيعية لمنتج واحد', f"{r['product_name']} في فاتورة {r['invoice_no']} بكمية {r['quantity']}", 'sale_item', r['id'], 'متوسطة', r['user_id'] if 'user_id' in r.keys() else None))
    for r in self.db.all("SELECT id, user_id, username, action, created_at FROM activity_logs WHERE date(created_at)=date(?) AND (cast(strftime('%H', created_at) as integer) < 7 OR cast(strftime('%H', created_at) as integer) >= 23) AND (action LIKE '%دخول%' OR action LIKE '%Login%' OR action LIKE '%تسجيل%') LIMIT 50", (today,)):
        if not self.db.one("SELECT id FROM fraud_alerts WHERE rule_code='AFTER_HOURS_LOGIN' AND entity_type='activity_log' AND entity_id=? AND status='مفتوح'", (r['id'],)):
            created.append(_add_fraud_alert(self, 'AFTER_HOURS_LOGIN', 'دخول خارج أوقات العمل', f"{r['username']} في {r['created_at']}", 'activity_log', r['id'], 'متوسطة', r['user_id'] if 'user_id' in r.keys() else None))
    return [x for x in created if x]


def _complete_sale(self: AppService, *args, **kwargs):
    inv = _ORIG_COMPLETE_SALE(self, *args, **kwargs)
    try:
        sale = self.db.one('SELECT id, invoice_no, subtotal, discount_amount, total, user_id FROM sales WHERE invoice_no=?', (inv,))
        if sale:
            _record_audit_v2(self, 'sales', sale['id'], 'insert', None, dict(sale), sale['user_id'] if 'user_id' in sale.keys() else None, 'إصدار فاتورة')
        _fraud_scan_now(self)
    except Exception as exc:
        log_exception(exc, 'post sale fraud checks')
    return inv


def _return_item(self: AppService, *args, **kwargs):
    ret = _ORIG_RETURN_ITEM(self, *args, **kwargs)
    try:
        _record_audit_v2(self, 'returns', None, 'insert', None, {'return_no': ret}, _user_id(self), 'إرجاع منتج')
        _fraud_scan_now(self)
    except Exception as exc:
        log_exception(exc, 'post return fraud checks')
    return ret


def _save_product(self: AppService, *args, **kwargs):
    product_id = None
    old = None
    try:
        if len(args) >= 7:
            product_id = args[6]
        product_id = kwargs.get('product_id', product_id)
        if product_id:
            old = self.db.one('SELECT * FROM products WHERE id=?', (product_id,))
    except Exception:
        old = None
    res = _ORIG_SAVE_PRODUCT(self, *args, **kwargs)
    try:
        if product_id:
            new = self.db.one('SELECT * FROM products WHERE id=?', (product_id,))
            _record_audit_v2(self, 'products', int(product_id), 'update', _rowdict(old), _rowdict(new), _user_id(self), 'تعديل منتج')
            c = self.db.one("SELECT COUNT(*) c FROM audit_logs WHERE table_name='products' AND record_id=? AND action='update' AND date(timestamp)=date(?)", (int(product_id), datetime.now().strftime('%Y-%m-%d')))
            if c and int(c['c'] or 0) > 3:
                _add_fraud_alert(self, 'PRICE_CHANGED_OFTEN', 'تعديل سعر المنتج أكثر من 3 مرات/يوم', f"المنتج رقم {product_id} تم تعديله {c['c']} مرات اليوم", 'product', int(product_id), 'متوسطة', _user_id(self))
    except Exception as exc:
        log_exception(exc, 'product audit/fraud')
    return res


def _save_coupon(self: AppService, code: str, coupon_type: str, value: float, min_purchase: float = 0, max_uses: int = 0, expiry_date: str = '', active: int = 1):
    self.require_permission('can_discount', action='إدارة الكوبونات')
    code = str(code or '').strip().upper()
    if not code:
        raise ValueError('كود الكوبون مطلوب')
    if coupon_type not in ('percent', 'amount', 'free_product', 'free_shipping'):
        raise ValueError('نوع الكوبون غير صحيح')
    value = float(value or 0)
    if value <= 0 and coupon_type in ('percent', 'amount'):
        raise ValueError('قيمة الكوبون يجب أن تكون أكبر من صفر')
    if coupon_type == 'percent' and value > 100:
        raise ValueError('نسبة الخصم لا يمكن أن تتجاوز 100%')
    row = self.db.one('SELECT id FROM coupons WHERE code=?', (code,))
    if row:
        self.db.execute('UPDATE coupons SET type=?, value=?, min_purchase=?, max_uses=?, expiry_date=?, active=? WHERE code=?', (coupon_type, value, float(min_purchase or 0), int(max_uses or 0), str(expiry_date or '').strip(), int(bool(active)), code))
        _record_audit_v2(self, 'coupons', row['id'], 'update', None, {'code':code,'type':coupon_type,'value':value}, _user_id(self), 'تعديل كوبون')
    else:
        cur = self.db.execute('INSERT INTO coupons (code, type, value, min_purchase, max_uses, used_count, expiry_date, active, created_at) VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)', (code, coupon_type, value, float(min_purchase or 0), int(max_uses or 0), str(expiry_date or '').strip(), int(bool(active)), now_text()))
        _record_audit_v2(self, 'coupons', cur.lastrowid, 'insert', None, {'code':code,'type':coupon_type,'value':value}, _user_id(self), 'إضافة كوبون')
    self.log('حفظ كوبون', code)


def _list_coupons(self: AppService, include_inactive: bool = True):
    if include_inactive:
        return self.db.all('SELECT * FROM coupons ORDER BY active DESC, expiry_date IS NULL, expiry_date, code')
    return self.db.all('SELECT * FROM coupons WHERE active=1 ORDER BY expiry_date IS NULL, expiry_date, code')


def _apply_coupon_preview(self: AppService, code: str, purchase_total: float):
    code = str(code or '').strip().upper()
    row = self.db.one('SELECT * FROM coupons WHERE code=? AND active=1', (code,))
    if not row:
        raise ValueError('الكوبون غير موجود أو غير نشط')
    total = float(purchase_total or 0)
    if float(row['min_purchase'] or 0) > total:
        raise ValueError('قيمة الشراء أقل من الحد الأدنى للكوبون')
    if row['expiry_date'] and str(row['expiry_date'])[:10] < datetime.now().strftime('%Y-%m-%d'):
        raise ValueError('الكوبون منتهي الصلاحية')
    if int(row['max_uses'] or 0) > 0 and int(row['used_count'] or 0) >= int(row['max_uses'] or 0):
        raise ValueError('تم استهلاك الحد الأقصى لاستخدام الكوبون')
    typ = row['type']
    val = float(row['value'] or 0)
    if typ == 'percent':
        discount = total * val / 100.0
    elif typ == 'amount':
        discount = min(val, total)
    else:
        discount = 0.0
    return {'code': code, 'type': typ, 'discount': discount, 'final_total': max(total - discount, 0)}


def _interactive_dashboard_data(self: AppService, days: int = 30):
    days = max(1, min(int(days or 30), 365))
    since = (datetime.now() - timedelta(days=days-1)).strftime('%Y-%m-%d')
    today = datetime.now().strftime('%Y-%m-%d')
    kpi = self.db.one('SELECT COALESCE(SUM(total),0) sales, COALESCE(SUM(total_profit),0) profit, COUNT(*) invoices FROM sales WHERE date(created_at)=date(?)', (today,))
    line = self.db.all('SELECT date(created_at) day, COALESCE(SUM(total),0) sales, COALESCE(SUM(total_profit),0) profit, COUNT(*) invoices FROM sales WHERE date(created_at)>=date(?) GROUP BY date(created_at) ORDER BY day', (since,))
    payments = self.db.all("SELECT COALESCE(payment_method,'غير محدد') method, COALESCE(SUM(total),0) total, COUNT(*) invoices FROM sales WHERE date(created_at)>=date(?) GROUP BY payment_method ORDER BY total DESC", (since,))
    products = self.db.all('SELECT si.product_name, SUM(si.quantity) qty, COALESCE(SUM(si.profit_amount),0) profit FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE date(s.created_at)>=date(?) GROUP BY si.product_id, si.product_name ORDER BY qty DESC LIMIT 10', (since,))
    heat = self.db.all("SELECT strftime('%H', created_at) hour, COUNT(*) invoices, COALESCE(SUM(total),0) sales FROM sales WHERE date(created_at)>=date(?) GROUP BY hour ORDER BY hour", (since,))
    return {'kpi': dict(kpi) if kpi else {'sales':0,'profit':0,'invoices':0}, 'line': [dict(r) for r in line], 'payments':[dict(r) for r in payments], 'products':[dict(r) for r in products], 'heat':[dict(r) for r in heat]}


def _audit_v2_rows(self: AppService, table_name: str = '', limit: int = 300):
    params = []
    where = []
    if table_name:
        where.append('table_name=?')
        params.append(table_name)
    params.append(max(1, min(int(limit or 300), 1000)))
    sql = 'SELECT id, table_name, record_id, action, user_id, username, ip, reason, timestamp, old_values, new_values FROM audit_logs'
    if where:
        sql += ' WHERE ' + ' AND '.join(where)
    sql += ' ORDER BY id DESC LIMIT ?'
    return self.db.all(sql, params)


AppService.__init__ = _init
AppService.record_audit_v2 = _record_audit_v2
AppService.add_fraud_alert = _add_fraud_alert
AppService.list_fraud_alerts = _list_fraud_alerts
AppService.resolve_fraud_alert = _resolve_fraud_alert
AppService.fraud_scan_now = _fraud_scan_now
if _ORIG_COMPLETE_SALE:
    AppService.complete_sale = _complete_sale
if _ORIG_RETURN_ITEM:
    AppService.return_item = _return_item
if _ORIG_SAVE_PRODUCT:
    AppService.save_product = _save_product
AppService.save_coupon = _save_coupon
AppService.list_coupons = _list_coupons
AppService.apply_coupon_preview = _apply_coupon_preview
AppService.interactive_dashboard_data = _interactive_dashboard_data
AppService.audit_v2_rows = _audit_v2_rows
