from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})
import services.service_patches.v19_gdrive as _prev_v19_gdrive
globals().update({k: v for k, v in vars(_prev_v19_gdrive).items() if not k.startswith('__')})
import services.service_patches.v20_gdrive_settings as _prev_v20_gdrive_settings
globals().update({k: v for k, v in vars(_prev_v20_gdrive_settings).items() if not k.startswith('__')})
import services.service_patches.v21_backup as _prev_v21_backup
globals().update({k: v for k, v in vars(_prev_v21_backup).items() if not k.startswith('__')})
import services.service_patches.v22_gdrive_final as _prev_v22_gdrive_final
globals().update({k: v for k, v in vars(_prev_v22_gdrive_final).items() if not k.startswith('__')})
import services.service_patches.v23_business_tools as _prev_v23_business_tools
globals().update({k: v for k, v in vars(_prev_v23_business_tools).items() if not k.startswith('__')})

# ---------------- V24 Local Smart Assistant ----------------
def _ai_safe_one(self, sql, params=()):
    try:
        return self.db.one(sql, params)
    except Exception:
        return None


def _ai_safe_all(self, sql, params=()):
    try:
        return self.db.all(sql, params)
    except Exception:
        return []


def _ai_money(v):
    try:
        return money(float(v or 0))
    except Exception:
        return str(v or 0)


def _ai_dashboard_data(self, report_date: str = '') -> dict:
    d = (report_date or datetime.now().strftime('%Y-%m-%d')).strip()
    sales = _ai_safe_one(self, """SELECT COALESCE(SUM(subtotal),0) subtotal,
        COALESCE(SUM(discount_amount),0) discounts,
        COALESCE(SUM(total),0) total,
        COALESCE(SUM(total_profit),0) profit,
        COUNT(*) invoices
        FROM sales WHERE status='completed' AND date(created_at)=date(?)""", (d,))
    returns = _ai_safe_one(self, """SELECT COALESCE(SUM(amount),0) total, COUNT(*) count
        FROM returns WHERE date(created_at)=date(?)""", (d,))
    expenses = _ai_safe_one(self, """SELECT COALESCE(SUM(amount),0) total, COUNT(*) count
        FROM expenses WHERE date(expense_date)=date(?)""", (d,))
    top_product = _ai_safe_one(self, """SELECT si.product_name, SUM(si.quantity) qty, SUM(si.line_total) total
        FROM sale_items si JOIN sales s ON s.id=si.sale_id
        WHERE date(s.created_at)=date(?) GROUP BY si.product_id, si.product_name ORDER BY qty DESC LIMIT 1""", (d,))
    top_employee = _ai_safe_one(self, """SELECT e.name, SUM(s.total) total, COUNT(*) invoices
        FROM sales s JOIN employees e ON e.id=s.employee_id
        WHERE date(s.created_at)=date(?) GROUP BY e.id ORDER BY total DESC LIMIT 1""", (d,))
    discounts = float(sales['discounts'] or 0) if sales else 0.0
    total = float(sales['total'] or 0) if sales else 0.0
    gross_profit = float(sales['profit'] or 0) if sales else 0.0
    expense_total = float(expenses['total'] or 0) if expenses else 0.0
    net_profit = gross_profit - expense_total
    return dict(date=d, sales=sales, returns=returns, expenses=expenses, top_product=top_product, top_employee=top_employee,
                total=total, discounts=discounts, gross_profit=gross_profit, expense_total=expense_total, net_profit=net_profit)


def ai_daily_summary(self, report_date: str = '') -> str:
    data = _ai_dashboard_data(self, report_date)
    s = data['sales']; r = data['returns']; e = data['expenses']
    invoices = int(s['invoices'] or 0) if s else 0
    lines = [f"ملخص ذكي ليوم {data['date']}:"]
    lines.append(f"• إجمالي المبيعات: {_ai_money(data['total'])} عبر {invoices} فاتورة.")
    lines.append(f"• الخصومات: {_ai_money(data['discounts'])}.")
    lines.append(f"• المرتجعات: {_ai_money(r['total'] if r else 0)} بعدد {int(r['count'] or 0) if r else 0} عملية.")
    lines.append(f"• المصاريف: {_ai_money(e['total'] if e else 0)} بعدد {int(e['count'] or 0) if e else 0} مصروف.")
    lines.append(f"• الربح قبل المصاريف: {_ai_money(data['gross_profit'])}، وصافي الربح بعد المصاريف: {_ai_money(data['net_profit'])}.")
    if data['top_product']:
        lines.append(f"• أفضل منتج مبيعًا: {data['top_product']['product_name']} بعدد {data['top_product']['qty']} قطعة.")
    if data['top_employee']:
        lines.append(f"• أفضل موظف: {data['top_employee']['name']} بمبيعات {_ai_money(data['top_employee']['total'])}.")
    if data['total'] > 0 and data['discounts'] / data['total'] > 0.15:
        lines.append("⚠️ ملاحظة: نسبة الخصومات مرتفعة مقارنة بالمبيعات، راجع صلاحيات الخصم والعروض.")
    if data['net_profit'] < 0 and data['total'] > 0:
        lines.append("⚠️ ملاحظة: صافي الربح سلبي بعد المصاريف، راجع المصاريف أو أسعار البيع.")
    if invoices == 0:
        lines.append("ℹ️ لا توجد مبيعات مسجلة لهذا اليوم.")
    return '\n'.join(lines)


def ai_stock_forecast(self) -> list[dict]:
    rows = _ai_safe_all(self, """
        SELECT p.id, p.name, p.barcode, p.category, p.quantity, p.min_quantity,
               COALESCE(SUM(CASE WHEN date(s.created_at) >= date('now','-30 day') THEN si.quantity ELSE 0 END),0) sold_30
        FROM products p
        LEFT JOIN sale_items si ON si.product_id=p.id
        LEFT JOIN sales s ON s.id=si.sale_id
        WHERE p.active=1
        GROUP BY p.id
        ORDER BY p.quantity ASC, sold_30 DESC
        LIMIT 120
    """)
    out=[]
    for row in rows:
        sold_30 = float(row['sold_30'] or 0)
        daily = sold_30 / 30.0
        qty = float(row['quantity'] or 0)
        days_left = (qty / daily) if daily > 0 else None
        risk = 'نافد' if qty <= 0 else ('خطر قريب' if days_left is not None and days_left <= 7 else ('منخفض' if qty <= float(row['min_quantity'] or 0) else 'طبيعي'))
        suggested = max(int(round((daily * 30) - qty)), 0) if daily > 0 else 0
        if risk != 'طبيعي' or suggested > 0:
            out.append(dict(name=row['name'], barcode=row['barcode'] or '', category=row['category'] or '', quantity=qty, sold_30=sold_30,
                            days_left='لا توجد حركة' if days_left is None else f'{days_left:.1f}', risk=risk, suggested=suggested))
    return out[:60]


def ai_purchase_suggestions(self) -> list[dict]:
    items = ai_stock_forecast(self)
    return [x for x in items if x.get('suggested', 0) > 0 or x.get('risk') in ('نافد', 'خطر قريب', 'منخفض')]


def ai_stale_products(self, days: int = 45) -> list[dict]:
    rows = _ai_safe_all(self, """
        SELECT p.name, p.barcode, p.category, p.quantity, p.sale_price,
               COALESCE(MAX(s.created_at),'') last_sale
        FROM products p
        LEFT JOIN sale_items si ON si.product_id=p.id
        LEFT JOIN sales s ON s.id=si.sale_id
        WHERE p.active=1
        GROUP BY p.id
        HAVING last_sale='' OR date(last_sale) <= date('now', ?)
        ORDER BY last_sale ASC, p.quantity DESC
        LIMIT 100
    """, (f'-{int(days)} day',))
    return [dict(name=r['name'], barcode=r['barcode'] or '', category=r['category'] or '', quantity=r['quantity'], sale_price=r['sale_price'], last_sale=r['last_sale'] or 'لم يباع') for r in rows]


def ai_profit_analysis(self, date_from: str = '', date_to: str = '') -> dict:
    try:
        return self.profit_summary(date_from, date_to)
    except Exception:
        data = _ai_dashboard_data(self, date_from or '')
        return dict(net_sales=data['total'], gross_profit=data['gross_profit'], expenses=data['expense_total'], net_profit=data['net_profit'])


def ai_employee_analysis(self) -> list[dict]:
    rows = _ai_safe_all(self, """
        SELECT e.name, COUNT(s.id) invoices, COALESCE(SUM(s.total),0) total,
               COALESCE(SUM(s.total_commission),0) commission,
               COALESCE((SELECT SUM(r.amount) FROM returns r WHERE r.employee_id=e.id),0) returns_total
        FROM employees e
        LEFT JOIN sales s ON s.employee_id=e.id AND date(s.created_at) >= date('now','-30 day')
        WHERE e.active=1
        GROUP BY e.id
        ORDER BY total DESC
        LIMIT 100
    """)
    out=[]
    for r in rows:
        total=float(r['total'] or 0); ret=float(r['returns_total'] or 0)
        out.append(dict(name=r['name'], invoices=r['invoices'], total=total, commission=float(r['commission'] or 0), returns_total=ret,
                        note='مرتجعات مرتفعة' if total and ret/total > 0.2 else 'طبيعي'))
    return out


def ai_anomaly_alerts(self) -> list[str]:
    alerts=[]
    high_discount = _ai_safe_all(self, """SELECT invoice_no, discount_amount, subtotal, created_at
        FROM sales WHERE subtotal>0 AND discount_amount/subtotal >= 0.25 ORDER BY id DESC LIMIT 20""")
    for r in high_discount:
        alerts.append(f"خصم مرتفع في الفاتورة {r['invoice_no']}: {_ai_money(r['discount_amount'])} من أصل {_ai_money(r['subtotal'])}")
    frequent_returns = _ai_safe_all(self, """SELECT product_name, COUNT(*) c, SUM(amount) total
        FROM returns WHERE date(created_at) >= date('now','-30 day') GROUP BY product_id, product_name HAVING c>=3 ORDER BY c DESC LIMIT 15""")
    for r in frequent_returns:
        alerts.append(f"مرتجعات متكررة للمنتج {r['product_name']}: {r['c']} مرات خلال 30 يوم")
    neg_stock = _ai_safe_all(self, "SELECT name, quantity FROM products WHERE active=1 AND quantity < 0 LIMIT 20")
    for r in neg_stock:
        alerts.append(f"كمية سالبة للمنتج {r['name']}: {r['quantity']}")
    if not alerts:
        alerts.append('لا توجد مؤشرات خطرة واضحة حالياً حسب الفحص المحلي.')
    return alerts


def ai_full_report(self) -> str:
    parts = [ai_daily_summary(self)]
    stock = ai_purchase_suggestions(self)[:5]
    if stock:
        parts.append('\nاقتراحات شراء سريعة:')
        for x in stock:
            parts.append(f"• {x['name']}: المتوفر {x['quantity']:.0f}، مبيع 30 يوم {x['sold_30']:.0f}، المقترح {x['suggested']}، الحالة {x['risk']}")
    stale = ai_stale_products(self)[:5]
    if stale:
        parts.append('\nمنتجات راكدة أو قليلة الحركة:')
        for x in stale:
            parts.append(f"• {x['name']} - الكمية {x['quantity']} - آخر بيع: {x['last_sale']}")
    alerts = ai_anomaly_alerts(self)[:6]
    parts.append('\nملاحظات رقابية:')
    parts.extend(f'• {a}' for a in alerts)
    return '\n'.join(parts)

AppService.ai_daily_summary = ai_daily_summary
AppService.ai_stock_forecast = ai_stock_forecast
AppService.ai_purchase_suggestions = ai_purchase_suggestions
AppService.ai_stale_products = ai_stale_products
AppService.ai_profit_analysis = ai_profit_analysis
AppService.ai_employee_analysis = ai_employee_analysis
AppService.ai_anomaly_alerts = ai_anomaly_alerts
AppService.ai_full_report = ai_full_report

