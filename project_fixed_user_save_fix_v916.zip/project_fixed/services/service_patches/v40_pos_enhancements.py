from __future__ import annotations

import json
from typing import Any

from services.app_core import AppService
from database import now_text, money


def _row_to_dict(row: Any) -> dict:
    if row is None:
        return {}
    if isinstance(row, dict):
        return dict(row)
    try:
        return {k: row[k] for k in row.keys()}
    except Exception:
        try:
            return dict(row)
        except Exception:
            return {}


def _ensure_v40_schema(self: AppService) -> None:
    self.db.execute('''
        CREATE TABLE IF NOT EXISTS quick_sale_products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL UNIQUE,
            sort_order INTEGER NOT NULL DEFAULT 0,
            active INTEGER NOT NULL DEFAULT 1,
            created_by_user_id INTEGER,
            created_at TEXT NOT NULL,
            FOREIGN KEY(product_id) REFERENCES products(id)
        )
    ''')
    try:
        self.db.execute('CREATE INDEX IF NOT EXISTS idx_quick_sale_active_sort ON quick_sale_products(active, sort_order, id)')
    except Exception:
        pass


def _list_quick_sale_products(self: AppService, active_only: bool = True):
    _ensure_v40_schema(self)
    where = 'WHERE q.active=1 AND p.active=1' if active_only else 'WHERE p.active=1'
    return self.db.all(f'''
        SELECT q.id quick_id, q.sort_order, q.active quick_active,
               p.id, p.barcode, p.name, p.category, p.cost_price, p.sale_price,
               p.quantity, p.min_quantity, p.commission_percent
        FROM quick_sale_products q
        JOIN products p ON p.id=q.product_id
        {where}
        ORDER BY q.sort_order ASC, q.id ASC
    ''')


def _get_product_for_pos(self: AppService, product_id: int):
    _ensure_v40_schema(self)
    if not product_id:
        return None
    return self.db.one('''
        SELECT id, barcode, name, category, cost_price, sale_price, quantity, min_quantity, commission_percent
        FROM products
        WHERE id=? AND active=1
    ''', (int(product_id),))


def _add_quick_sale_product(self: AppService, product_id: int, user_id: int | None = None) -> None:
    _ensure_v40_schema(self)
    self.require_permission('can_products', action='إدارة أزرار البيع السريع')
    product = self.db.one('SELECT id, name FROM products WHERE id=? AND active=1', (int(product_id),))
    if not product:
        raise ValueError('المنتج غير موجود أو معطل')
    old = self.db.one('SELECT id FROM quick_sale_products WHERE product_id=?', (int(product_id),))
    if old:
        self.db.execute('UPDATE quick_sale_products SET active=1 WHERE product_id=?', (int(product_id),))
    else:
        next_order = self.db.one('SELECT COALESCE(MAX(sort_order),0)+1 v FROM quick_sale_products')
        self.db.execute('''INSERT INTO quick_sale_products (product_id, sort_order, active, created_by_user_id, created_at)
                           VALUES (?, ?, 1, ?, ?)''', (int(product_id), int(next_order['v'] if next_order else 1), user_id, now_text()))
    try:
        self.log_detailed('إضافة زر بيع سريع', 'quick_sale_products', int(product_id), None, {'product_id': int(product_id), 'product': product['name']}, f"إضافة {product['name']} إلى أزرار البيع السريع", 'low', user_id)
    except Exception:
        self.log('إضافة زر بيع سريع', str(product['name']))


def _remove_quick_sale_product(self: AppService, product_id: int, user_id: int | None = None) -> None:
    _ensure_v40_schema(self)
    self.require_permission('can_products', action='إدارة أزرار البيع السريع')
    product = self.db.one('SELECT id, name FROM products WHERE id=?', (int(product_id),))
    before = _row_to_dict(self.db.one('SELECT * FROM quick_sale_products WHERE product_id=?', (int(product_id),)))
    self.db.execute('UPDATE quick_sale_products SET active=0 WHERE product_id=?', (int(product_id),))
    try:
        self.log_detailed('تعطيل زر بيع سريع', 'quick_sale_products', int(product_id), before, {'active': 0}, f"تعطيل زر {product['name'] if product else product_id}", 'low', user_id)
    except Exception:
        self.log('تعطيل زر بيع سريع', str(product_id))


def _move_quick_sale_product(self: AppService, product_id: int, direction: str = 'up') -> None:
    _ensure_v40_schema(self)
    self.require_permission('can_products', action='ترتيب أزرار البيع السريع')
    rows = list(self.db.all('SELECT product_id, sort_order FROM quick_sale_products WHERE active=1 ORDER BY sort_order, id'))
    ids = [int(r['product_id']) for r in rows]
    pid = int(product_id)
    if pid not in ids:
        return
    idx = ids.index(pid)
    if direction == 'up' and idx > 0:
        ids[idx-1], ids[idx] = ids[idx], ids[idx-1]
    elif direction == 'down' and idx < len(ids)-1:
        ids[idx+1], ids[idx] = ids[idx], ids[idx+1]
    else:
        return
    for order, item_id in enumerate(ids, start=1):
        self.db.execute('UPDATE quick_sale_products SET sort_order=? WHERE product_id=?', (order, item_id))


def _quick_sale_summary(self: AppService) -> dict:
    _ensure_v40_schema(self)
    rows = self.list_quick_sale_products(True)
    return {'count': len(rows), 'items': [dict(_row_to_dict(r)) for r in rows]}


def _favorite_customers_for_pos(self: AppService, limit: int = 12):
    try:
        return self.db.all('''
            SELECT c.*, COUNT(s.id) sales_count, COALESCE(SUM(s.total),0) sales_total
            FROM customers c
            LEFT JOIN sales s ON s.customer_id=c.id AND s.status='completed'
            WHERE c.active=1
            GROUP BY c.id
            ORDER BY sales_count DESC, sales_total DESC, c.name ASC
            LIMIT ?
        ''', (int(limit),))
    except Exception:
        return self.list_customers()[:limit]


def _customer_balance_for_pos(self: AppService, customer_id: int | None) -> float:
    if not customer_id:
        return 0.0
    try:
        row = self.db.one('''
            WITH credit AS (
                SELECT customer_id, SUM(CASE WHEN (subtotal-discount_amount+tax_amount) < 0 THEN 0 ELSE (subtotal-discount_amount+tax_amount) END) amount
                FROM sales WHERE payment_method='آجل' AND status='completed' GROUP BY customer_id
            ), payments AS (
                SELECT customer_id, SUM(amount) amount FROM customer_payments GROUP BY customer_id
            ), returned AS (
                SELECT s.customer_id, SUM(r.amount) amount FROM returns r JOIN sales s ON s.id=r.sale_id GROUP BY s.customer_id
            )
            SELECT COALESCE(credit.amount,0)-COALESCE(returned.amount,0)-COALESCE(payments.amount,0) balance
            FROM customers c
            LEFT JOIN credit ON credit.customer_id=c.id
            LEFT JOIN payments ON payments.customer_id=c.id
            LEFT JOIN returned ON returned.customer_id=c.id
            WHERE c.id=?
        ''', (int(customer_id),))
        return float(row['balance'] if row else 0)
    except Exception:
        return 0.0


def _sale_preview_payload(self: AppService, cart: list[dict], customer_id: int | None, payment_method: str, discount_amount: float = 0, discount_type: str = 'amount') -> dict:
    subtotal = 0.0
    items = []
    for item in cart or []:
        qty = float(item.get('quantity') or 0)
        price = float(item.get('unit_price') or 0)
        line = qty * price
        subtotal += line
        items.append({'product_name': item.get('product_name', ''), 'quantity': qty, 'unit_price': price, 'line_total': line})
    if discount_type == 'percent':
        discount_value = subtotal * float(discount_amount or 0) / 100
    else:
        discount_value = float(discount_amount or 0)
    total = max(subtotal - discount_value, 0)
    customer = None
    if customer_id:
        customer = self.db.one('SELECT * FROM customers WHERE id=?', (int(customer_id),))
    balance = self.customer_balance_for_pos(customer_id)
    return {
        'items': items,
        'customer': _row_to_dict(customer) if customer else None,
        'payment_method': payment_method,
        'subtotal': subtotal,
        'discount_amount': discount_value,
        'total': total,
        'customer_balance': balance,
        'customer_balance_after': balance + total if payment_method == 'آجل' else balance,
    }


AppService.ensure_v40_pos_schema = _ensure_v40_schema
AppService.list_quick_sale_products = _list_quick_sale_products
AppService.get_product_for_pos = _get_product_for_pos
AppService.add_quick_sale_product = _add_quick_sale_product
AppService.remove_quick_sale_product = _remove_quick_sale_product
AppService.move_quick_sale_product = _move_quick_sale_product
AppService.quick_sale_summary = _quick_sale_summary
AppService.favorite_customers_for_pos = _favorite_customers_for_pos
AppService.customer_balance_for_pos = _customer_balance_for_pos
AppService.sale_preview_payload = _sale_preview_payload
