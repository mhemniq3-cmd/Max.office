from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})
import services.service_patches.v19_gdrive as _prev_v19_gdrive
globals().update({k: v for k, v in vars(_prev_v19_gdrive).items() if not k.startswith('__')})
import services.service_patches.v20_gdrive_settings as _prev_v20_gdrive_settings
globals().update({k: v for k, v in vars(_prev_v20_gdrive_settings).items() if not k.startswith('__')})
import services.service_patches.v21_backup as _prev_v21_backup
globals().update({k: v for k, v in vars(_prev_v21_backup).items() if not k.startswith('__')})
import services.service_patches.v22_gdrive_final as _prev_v22_gdrive_final
globals().update({k: v for k, v in vars(_prev_v22_gdrive_final).items() if not k.startswith('__')})

# ---------------------------------------------------------------------------
# V23 LOCAL BUSINESS TOOLS: printing helpers, expenses, cashier reports,
# stronger health check, smart backup/restore, and report filters.
# This patch keeps the system local/SQLite and does not add cloud/server logic.
# ---------------------------------------------------------------------------
from datetime import date as _V23Date

_old_appservice_init_v23 = AppService.__init__

def _v23_appservice_init(self, db: Database):
    _old_appservice_init_v23(self, db)
    try:
        self.ensure_v23_local_business_schema()
    except Exception as exc:
        log_exception(exc)
    try:
        if str(self.get_settings().get('auto_backup_on_open', '1')).lower() in ('1', 'true', 'yes', 'on', 'نعم'):
            self.auto_backup_if_due()
    except Exception as exc:
        log_exception(exc)

AppService.__init__ = _v23_appservice_init


def _v23_audit(self: AppService, action: str, details: str = '', user_id: int | None = None, username: str = '') -> None:
    self.log('تدقيق - ' + str(action), details, user_id, username)

AppService.audit = _v23_audit


def _v23_ensure_schema(self: AppService) -> None:
    cur = self.db.conn.cursor()
    cur.executescript('''
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            expense_no TEXT UNIQUE,
            expense_type TEXT NOT NULL,
            amount REAL NOT NULL DEFAULT 0,
            expense_date TEXT NOT NULL,
            note TEXT,
            user_id INTEGER,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date);
    ''')
    defaults = {
        'paper_size': '80mm',
        'auto_backup_on_open': '1',
        'auto_backup_on_close': '1',
        'max_backup_keep': self.get_settings().get('max_backup_keep', '7') if hasattr(self, 'get_settings') else '7',
        'direct_print_enabled': '0',
    }
    for k, v in defaults.items():
        cur.execute('INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)', (k, str(v)))
    self.db.conn.commit()

AppService.ensure_v23_local_business_schema = _v23_ensure_schema


def _v23_next_doc_no(self: AppService, prefix: str) -> str:
    return f"{prefix}-{datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]}"

AppService.next_doc_no = _v23_next_doc_no


def _v23_save_expense(self: AppService, expense_type: str, amount: float, expense_date: str, note: str = '', user_id: int | None = None) -> int:
    expense_type = (expense_type or '').strip()
    if not expense_type:
        raise ValueError('نوع المصروف مطلوب')
    amount = to_float(amount)
    if amount <= 0:
        raise ValueError('مبلغ المصروف يجب أن يكون أكبر من صفر')
    expense_date = (expense_date or _V23Date.today().isoformat()).strip()
    no = self.next_doc_no('EXP')
    cur = self.db.execute('''INSERT INTO expenses (expense_no, expense_type, amount, expense_date, note, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)''', (no, expense_type, amount, expense_date, (note or '').strip(), user_id, now_text()))
    self.log('إضافة مصروف', f'{expense_type} - {amount:,.0f}', user_id)
    self.audit('إضافة مصروف', f'{no} | {expense_type} | {amount:,.0f}', user_id)
    return cur.lastrowid

AppService.save_expense = _v23_save_expense


def _v23_list_expenses(self: AppService, date_from: str = '', date_to: str = '', limit: int = 500):
    where = ['1=1']; params = []
    if date_from:
        where.append('date(expense_date) >= date(?)'); params.append(date_from)
    if date_to:
        where.append('date(expense_date) <= date(?)'); params.append(date_to)
    params.append(limit)
    return self.db.all(f'''SELECT e.*, u.full_name user_name FROM expenses e LEFT JOIN users u ON u.id=e.user_id WHERE {' AND '.join(where)} ORDER BY e.expense_date DESC, e.id DESC LIMIT ?''', params)

AppService.list_expenses = _v23_list_expenses


def _v23_expense_summary(self: AppService, date_from: str = '', date_to: str = '') -> dict:
    rows = self.list_expenses(date_from, date_to, 100000)
    total = sum(float(r['amount'] or 0) for r in rows)
    by_type = {}
    for r in rows:
        by_type[r['expense_type']] = by_type.get(r['expense_type'], 0.0) + float(r['amount'] or 0)
    return {'total': total, 'count': len(rows), 'by_type': by_type}

AppService.expense_summary = _v23_expense_summary


def _v23_cashier_report(self: AppService, report_date: str = '') -> dict:
    d = (report_date or _V23Date.today().isoformat()).strip()
    sales = self.db.one("""SELECT
        COALESCE(SUM(CASE WHEN payment_method!='آجل' THEN total ELSE 0 END),0) cash_sales,
        COALESCE(SUM(CASE WHEN payment_method='آجل' THEN total ELSE 0 END),0) credit_sales,
        COALESCE(SUM(discount_amount),0) discounts,
        COUNT(*) invoices
        FROM sales WHERE date(created_at)=date(?) AND status='completed'""", (d,))
    pays = self.db.one("SELECT COALESCE(SUM(amount),0) payments FROM customer_payments WHERE date(created_at)=date(?)", (d,))
    rets = self.db.one("SELECT COALESCE(SUM(CASE WHEN refund_method='نقدي' THEN amount ELSE 0 END),0) cash_returns, COUNT(*) return_count FROM returns WHERE date(created_at)=date(?)", (d,))
    expected_cash = float(sales['cash_sales'] or 0) + float(pays['payments'] or 0) - float(rets['cash_returns'] or 0)
    return {
        'date': d,
        'cash_sales': float(sales['cash_sales'] or 0),
        'credit_sales': float(sales['credit_sales'] or 0),
        'customer_payments': float(pays['payments'] or 0),
        'cash_returns': float(rets['cash_returns'] or 0),
        'expected_cash': expected_cash,
        'discounts': float(sales['discounts'] or 0),
        'invoices': int(sales['invoices'] or 0),
        'returns_count': int(rets['return_count'] or 0),
    }

AppService.cashier_report = _v23_cashier_report


def _v23_profit_summary(self: AppService, date_from: str = '', date_to: str = '') -> dict:
    where = ["status='completed'"]; params = []
    if date_from:
        where.append('date(created_at) >= date(?)'); params.append(date_from)
    if date_to:
        where.append('date(created_at) <= date(?)'); params.append(date_to)
    w = ' AND '.join(where)
    sales = self.db.one(f"SELECT COALESCE(SUM(subtotal),0) subtotal, COALESCE(SUM(discount_amount),0) discounts, COALESCE(SUM(total),0) net_sales, COALESCE(SUM(total_profit),0) gross_profit, COUNT(*) invoices FROM sales WHERE {w}", params)
    ret_params = list(params)
    # Return filters use their own created_at field but the same date boundaries.
    ret_where = ['1=1']; ret_params = []
    if date_from:
        ret_where.append('date(created_at) >= date(?)'); ret_params.append(date_from)
    if date_to:
        ret_where.append('date(created_at) <= date(?)'); ret_params.append(date_to)
    returns = self.db.one(f"SELECT COALESCE(SUM(amount),0) returns_amount, COALESCE(SUM(profit_amount),0) returns_profit FROM returns WHERE {' AND '.join(ret_where)}", ret_params)
    expenses = self.expense_summary(date_from, date_to)['total']
    gross_profit = float(sales['gross_profit'] or 0)
    net_profit = gross_profit - float(expenses or 0)
    return {
        'subtotal': float(sales['subtotal'] or 0),
        'discounts': float(sales['discounts'] or 0),
        'net_sales': float(sales['net_sales'] or 0),
        'returns_amount': float(returns['returns_amount'] or 0),
        'gross_profit': gross_profit,
        'expenses': float(expenses or 0),
        'net_profit': net_profit,
        'invoices': int(sales['invoices'] or 0),
    }

AppService.profit_summary = _v23_profit_summary


def _v23_system_health_check(self: AppService) -> list[dict]:
    issues = []
    def add(level, item, details):
        issues.append({'level': level, 'item': item, 'details': details})
    q = self.db.one('SELECT COUNT(*) c FROM sales s LEFT JOIN sale_items i ON i.sale_id=s.id WHERE s.status="completed" GROUP BY s.id HAVING COUNT(i.id)=0 LIMIT 1')
    if q: add('خطر', 'فواتير بدون مواد', 'توجد فاتورة مكتملة لا تحتوي مواد')
    q = self.db.one('SELECT COUNT(*) c FROM products WHERE quantity < 0')
    if q and q['c']: add('خطر', 'مواد بكميات سالبة', f"عدد المنتجات: {q['c']}")
    q = self.db.all('SELECT barcode, COUNT(*) c FROM products WHERE barcode IS NOT NULL AND TRIM(barcode)<>"" GROUP BY barcode HAVING COUNT(*)>1')
    if q: add('خطر', 'باركودات مكررة', f"عدد الباركودات المكررة: {len(q)}")
    q = self.db.one('''SELECT COUNT(*) c FROM returns r JOIN sale_items si ON si.id=r.sale_item_id GROUP BY r.sale_item_id HAVING SUM(r.quantity) > si.quantity LIMIT 1''')
    if q: add('خطر', 'مرتجعات أكبر من البيع', 'توجد مادة راجعة بكميات أكبر من كمية البيع')
    q = self.db.one('SELECT COUNT(*) c FROM products WHERE active=1 AND (sale_price <= 0 OR name IS NULL OR TRIM(name)="")')
    if q and q['c']: add('تحذير', 'منتجات بدون سعر أو اسم', f"عدد المنتجات: {q['c']}")
    q = self.db.one('SELECT COUNT(*) c FROM sales WHERE discount_amount < 0 OR total < 0 OR discount_amount >= subtotal')
    if q and q['c']: add('خطر', 'خصومات أو فواتير غير منطقية', f"عدد السجلات: {q['c']}")
    q = self.db.one('''SELECT COUNT(*) c FROM customer_payments p JOIN customers c ON c.id=p.customer_id WHERE p.amount <= 0''')
    if q and q['c']: add('تحذير', 'دفعات زبائن غير صحيحة', f"عدد الدفعات: {q['c']}")
    comm = self.db.one('SELECT COUNT(*) c FROM sales WHERE total_commission < 0')
    if comm and comm['c']: add('خطر', 'عمولات سالبة', f"عدد السجلات: {comm['c']}")
    st = self.get_settings()
    last = st.get('last_auto_backup_date') or st.get('last_google_drive_backup_at') or ''
    if not last:
        add('تحذير', 'نسخ احتياطي قديم', 'لا توجد معلومة عن آخر نسخة احتياطية')
    if not issues:
        add('نجاح', 'فحص سلامة النظام', 'لا توجد مشاكل حرجة في الفحص الحالي')
    return issues

AppService.system_health_check = _v23_system_health_check


def _v23_filtered_operations(self: AppService, date_from='', date_to='', employee='', customer='', product='', payment_method='', category='', operation_type='', limit=1000):
    rows = []
    params = []
    where = ['1=1']
    if date_from: where.append('date(s.created_at)>=date(?)'); params.append(date_from)
    if date_to: where.append('date(s.created_at)<=date(?)'); params.append(date_to)
    if employee: where.append('COALESCE(e.name,"") LIKE ?'); params.append(f'%{employee}%')
    if customer: where.append('COALESCE(c.name,"") LIKE ?'); params.append(f'%{customer}%')
    if payment_method: where.append('s.payment_method=?'); params.append(payment_method)
    if operation_type in ('', 'بيع'):
        sql = f'''SELECT 'بيع' op, s.invoice_no ref, s.created_at, COALESCE(e.name,'') employee, COALESCE(c.name,'') customer, s.payment_method, s.total amount, s.total_profit profit, s.note details
                  FROM sales s LEFT JOIN employees e ON e.id=s.employee_id LEFT JOIN customers c ON c.id=s.customer_id
                  WHERE {' AND '.join(where)} ORDER BY s.id DESC LIMIT ?'''
        for r in self.db.all(sql, params + [limit]): rows.append(dict(r))
    ret_params=[]; ret_where=['1=1']
    if date_from: ret_where.append('date(r.created_at)>=date(?)'); ret_params.append(date_from)
    if date_to: ret_where.append('date(r.created_at)<=date(?)'); ret_params.append(date_to)
    if employee: ret_where.append('COALESCE(e.name,"") LIKE ?'); ret_params.append(f'%{employee}%')
    if customer: ret_where.append('COALESCE(c.name,"") LIKE ?'); ret_params.append(f'%{customer}%')
    if product: ret_where.append('COALESCE(r.product_name,"") LIKE ?'); ret_params.append(f'%{product}%')
    if operation_type in ('', 'مرتجع'):
        sql = f'''SELECT 'مرتجع' op, r.return_no ref, r.created_at, COALESCE(e.name,'') employee, COALESCE(c.name,'') customer, r.refund_method payment_method, r.amount amount, r.profit_amount profit, r.reason details
                  FROM returns r LEFT JOIN employees e ON e.id=r.employee_id LEFT JOIN customers c ON c.id=r.customer_id
                  WHERE {' AND '.join(ret_where)} ORDER BY r.id DESC LIMIT ?'''
        for r in self.db.all(sql, ret_params + [limit]): rows.append(dict(r))
    exp_params=[]; exp_where=['1=1']
    if date_from: exp_where.append('date(expense_date)>=date(?)'); exp_params.append(date_from)
    if date_to: exp_where.append('date(expense_date)<=date(?)'); exp_params.append(date_to)
    if operation_type in ('', 'مصروف'):
        sql = f'''SELECT 'مصروف' op, expense_no ref, created_at, '' employee, '' customer, expense_type payment_method, amount, 0 profit, note details
                  FROM expenses WHERE {' AND '.join(exp_where)} ORDER BY id DESC LIMIT ?'''
        for r in self.db.all(sql, exp_params + [limit]): rows.append(dict(r))
    rows.sort(key=lambda x: x.get('created_at') or '', reverse=True)
    return rows[:limit]

AppService.filtered_operations = _v23_filtered_operations


def _v23_print_purchase_html(self: AppService, purchase_no_value: str) -> Path:
    p = self.db.one('''SELECT p.*, s.name supplier FROM purchases p JOIN suppliers s ON s.id=p.supplier_id WHERE p.purchase_no=?''', (purchase_no_value,))
    if not p: raise ValueError('فاتورة الشراء غير موجودة')
    items = self.db.all('SELECT * FROM purchase_items WHERE purchase_id=?', (p['id'],))
    rows = ''.join(f"<tr><td>{html.escape(i['product_name'])}</td><td>{i['quantity']}</td><td>{money(i['unit_cost'])}</td><td>{money(i['line_total'])}</td></tr>" for i in items)
    body = f"<h3>فاتورة شراء {html.escape(purchase_no_value)}</h3><p>المورد: {html.escape(p['supplier'])}</p><table><tr><th>المادة</th><th>الكمية</th><th>الكلفة</th><th>الإجمالي</th></tr>{rows}</table><p class='total'>الصافي: {money(p['total'])}</p>"
    return self._write_html('purchase_'+purchase_no_value, 'فاتورة شراء', body)

AppService.print_purchase_html = _v23_print_purchase_html


def _v23_print_daily_report_html(self: AppService, report_date: str = '') -> Path:
    data = self.cashier_report(report_date)
    profit = self.profit_summary(data['date'], data['date'])
    body = f"""
    <h3>تقرير يومي - {html.escape(data['date'])}</h3>
    <table><tr><th>البند</th><th>القيمة</th></tr>
    <tr><td>مبيعات نقدية</td><td>{money(data['cash_sales'])}</td></tr>
    <tr><td>بيع آجل</td><td>{money(data['credit_sales'])}</td></tr>
    <tr><td>دفعات زبائن</td><td>{money(data['customer_payments'])}</td></tr>
    <tr><td>مرتجعات نقدية</td><td>{money(data['cash_returns'])}</td></tr>
    <tr><td>صافي الصندوق</td><td>{money(data['expected_cash'])}</td></tr>
    <tr><td>المصاريف</td><td>{money(profit['expenses'])}</td></tr>
    <tr><td>صافي الربح</td><td>{money(profit['net_profit'])}</td></tr>
    </table>"""
    return self._write_html('daily_report_'+data['date'], 'تقرير يومي', body)

AppService.print_daily_report_html = _v23_print_daily_report_html


def _v23_restore_database_safe(self: AppService, source: Path | str) -> None:
    self.require_permission('can_restore', action='استرجاع نسخة احتياطية')
    self.backup_database()
    self.audit('نسخة قبل الاسترجاع', 'تم إنشاء نسخة احتياطية قبل استرجاع قاعدة البيانات')
    self.restore_database(source)

AppService.restore_database_safe = _v23_restore_database_safe

# V23 small compatibility fix: use the existing HTML writer for added reports.
def _v23_print_purchase_html_fixed(self: AppService, purchase_no_value: str) -> Path:
    p = self.db.one('''SELECT p.*, s.name supplier FROM purchases p JOIN suppliers s ON s.id=p.supplier_id WHERE p.purchase_no=?''', (purchase_no_value,))
    if not p: raise ValueError('فاتورة الشراء غير موجودة')
    items = self.db.all('SELECT * FROM purchase_items WHERE purchase_id=?', (p['id'],))
    rows = ''.join(f"<tr><td>{html.escape(i['product_name'])}</td><td>{i['quantity']}</td><td>{money(i['unit_cost'])}</td><td>{money(i['line_total'])}</td></tr>" for i in items)
    body = f"<h3>فاتورة شراء {html.escape(purchase_no_value)}</h3><p>المورد: {html.escape(p['supplier'])}</p><table><tr><th>المادة</th><th>الكمية</th><th>الكلفة</th><th>الإجمالي</th></tr>{rows}</table><p class='total'>الصافي: {money(p['total'])}</p>"
    return self._html_page('purchase_'+purchase_no_value, body)

AppService.print_purchase_html = _v23_print_purchase_html_fixed


def _v23_print_daily_report_html_fixed(self: AppService, report_date: str = '') -> Path:
    data = self.cashier_report(report_date)
    profit = self.profit_summary(data['date'], data['date'])
    body = f"""
    <h3>تقرير يومي - {html.escape(data['date'])}</h3>
    <table><tr><th>البند</th><th>القيمة</th></tr>
    <tr><td>مبيعات نقدية</td><td>{money(data['cash_sales'])}</td></tr>
    <tr><td>بيع آجل</td><td>{money(data['credit_sales'])}</td></tr>
    <tr><td>دفعات زبائن</td><td>{money(data['customer_payments'])}</td></tr>
    <tr><td>مرتجعات نقدية</td><td>{money(data['cash_returns'])}</td></tr>
    <tr><td>صافي الصندوق</td><td>{money(data['expected_cash'])}</td></tr>
    <tr><td>المصاريف</td><td>{money(profit['expenses'])}</td></tr>
    <tr><td>صافي الربح</td><td>{money(profit['net_profit'])}</td></tr>
    </table>"""
    return self._html_page('daily_report_'+data['date'], body)

AppService.print_daily_report_html = _v23_print_daily_report_html_fixed


