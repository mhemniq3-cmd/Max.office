from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})
import services.service_patches.v19_gdrive as _prev_v19_gdrive
globals().update({k: v for k, v in vars(_prev_v19_gdrive).items() if not k.startswith('__')})
import services.service_patches.v20_gdrive_settings as _prev_v20_gdrive_settings
globals().update({k: v for k, v in vars(_prev_v20_gdrive_settings).items() if not k.startswith('__')})
import services.service_patches.v21_backup as _prev_v21_backup
globals().update({k: v for k, v in vars(_prev_v21_backup).items() if not k.startswith('__')})
import services.service_patches.v22_gdrive_final as _prev_v22_gdrive_final
globals().update({k: v for k, v in vars(_prev_v22_gdrive_final).items() if not k.startswith('__')})
import services.service_patches.v23_business_tools as _prev_v23_business_tools
globals().update({k: v for k, v in vars(_prev_v23_business_tools).items() if not k.startswith('__')})
import services.service_patches.v24_smart_assistant as _prev_v24_smart_assistant
globals().update({k: v for k, v in vars(_prev_v24_smart_assistant).items() if not k.startswith('__')})
import services.service_patches.v25_readiness as _prev_v25_readiness
globals().update({k: v for k, v in vars(_prev_v25_readiness).items() if not k.startswith('__')})
import services.service_patches.v25_1_barcode as _prev_v25_1_barcode
globals().update({k: v for k, v in vars(_prev_v25_1_barcode).items() if not k.startswith('__')})

# ---------------------------------------------------------------------------
# V26 TOOLS PAGE REPAIR
# Fixes the tools page refresh failure caused by the V25 commission_report
# wrapper requiring date_from/date_to while the UI correctly calls it with no
# arguments. The repaired method supports both old UI calls and future date
# filters, and keeps profit/commission visibility permission-aware.
# ---------------------------------------------------------------------------

def _v26_commission_report(self: AppService, date_from: str = '', date_to: str = ''):
    user = _v25_require_any(self, ('can_reports', 'can_goals', 'can_tools'), action='عرض تقرير العمولات')
    sale_where = ['1=1']
    sale_params = []
    return_where = ['1=1']
    return_params = []
    date_from = str(date_from or '').strip()
    date_to = str(date_to or '').strip()
    if date_from:
        sale_where.append('date(created_at) >= date(?)')
        sale_params.append(date_from)
        return_where.append('date(created_at) >= date(?)')
        return_params.append(date_from)
    if date_to:
        sale_where.append('date(created_at) <= date(?)')
        sale_params.append(date_to)
        return_where.append('date(created_at) <= date(?)')
        return_params.append(date_to)
    sql = f'''
        SELECT e.name employee,
               COALESCE(s.sales, 0) sales,
               COALESCE(s.commission, 0) commission,
               COALESCE(r.returned_commission, 0) returned_commission
        FROM employees e
        LEFT JOIN (
            SELECT employee_id, COALESCE(SUM(total),0) sales, COALESCE(SUM(total_commission),0) commission
            FROM sales
            WHERE {' AND '.join(sale_where)}
            GROUP BY employee_id
        ) s ON s.employee_id=e.id
        LEFT JOIN (
            SELECT employee_id, COALESCE(SUM(commission_amount),0) returned_commission
            FROM returns
            WHERE {' AND '.join(return_where)}
            GROUP BY employee_id
        ) r ON r.employee_id=e.id
        WHERE e.active=1
        ORDER BY commission DESC, e.name
    '''
    rows = [dict(r) for r in self.db.all(sql, sale_params + return_params)]
    if not self.user_has(user, 'can_view_profit') and not self.is_admin_user(user):
        for row in rows:
            row['commission'] = 0
            row['returned_commission'] = 0
    return rows


AppService.commission_report = _v26_commission_report

