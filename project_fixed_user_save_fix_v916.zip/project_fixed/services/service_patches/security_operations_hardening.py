from __future__ import annotations

import csv
import hashlib
import html
import json
import os
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from services.app_core import AppService
from database import now_text
from services.error_logger import log_exception

_ORIG_INIT = AppService.__init__
_ORIG_FRAUD_SCAN_NOW = getattr(AppService, 'fraud_scan_now', None)
_ORIG_SAVE_COUPON = getattr(AppService, 'save_coupon', None)
_ORIG_LIST_COUPONS = getattr(AppService, 'list_coupons', None)
_ORIG_APPLY_COUPON_PREVIEW = getattr(AppService, 'apply_coupon_preview', None)
_ORIG_AUDIT_ROWS = getattr(AppService, 'audit_v2_rows', None)

SECRET = os.environ.get('MAX_SALES_COUPON_SECRET', 'MaxSalesCouponPepper@2026')
SAFE_TEXT_RE = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f]+')


def _sanitize_text(value: Any, limit: int = 1000) -> str:
    text = '' if value is None else str(value)
    text = SAFE_TEXT_RE.sub(' ', text).replace('\r', ' ').replace('\n', ' ')
    return text.strip()[:limit]


def _sha_coupon(code: str) -> str:
    normalized = str(code or '').strip().upper()
    return hashlib.sha256((normalized + '|' + SECRET).encode('utf-8')).hexdigest()


def _mask_code(code: str) -> str:
    code = str(code or '').strip().upper()
    if len(code) <= 4:
        return '****'
    return code[:2] + '***' + code[-2:]


def _row_to_dict(row: Any) -> dict:
    if not row:
        return {}
    try:
        return dict(row)
    except Exception:
        try:
            return {k: row[k] for k in row.keys()}
        except Exception:
            return {}


def _safe_json(value: Any) -> str:
    try:
        return json.dumps(value, ensure_ascii=False, default=str, sort_keys=True)
    except Exception:
        return json.dumps(str(value), ensure_ascii=False)


def _today() -> str:
    return datetime.now().strftime('%Y-%m-%d')


def _now_hour() -> int:
    return int(datetime.now().strftime('%H'))


def _ensure_col(conn, table: str, col: str, ddl: str) -> None:
    cols = [r[1] for r in conn.execute(f'PRAGMA table_info({table})').fetchall()]
    if col not in cols:
        conn.execute(f'ALTER TABLE {table} ADD COLUMN {col} {ddl}')


def _ensure_schema(self: AppService) -> None:
    conn = self.db.conn
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS fraud_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            rule_code TEXT NOT NULL UNIQUE,
            title TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'متوسطة',
            threshold_value REAL NOT NULL DEFAULT 0,
            action TEXT NOT NULL DEFAULT 'تنبيه',
            active INTEGER NOT NULL DEFAULT 1,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS coupon_usages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            coupon_id INTEGER NOT NULL,
            code_hash TEXT NOT NULL,
            customer_id INTEGER,
            sale_id INTEGER,
            invoice_no TEXT,
            amount REAL NOT NULL DEFAULT 0,
            used_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            user_id INTEGER,
            UNIQUE(coupon_id, customer_id, sale_id)
        );

        CREATE TABLE IF NOT EXISTS system_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'info',
            details TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
    ''')
    # Extend v45.17.4.5 tables without breaking old UI.
    for col, ddl in [
        ('code_hash', 'TEXT'),
        ('code_mask', 'TEXT'),
        ('starts_at', 'TEXT'),
        ('product_id', 'INTEGER'),
        ('category', 'TEXT'),
        ('customer_id', 'INTEGER'),
        ('max_uses_per_customer', 'INTEGER NOT NULL DEFAULT 1'),
        ('requires_manager', 'INTEGER NOT NULL DEFAULT 0'),
        ('last_used_at', 'TEXT'),
    ]:
        try:
            _ensure_col(conn, 'coupons', col, ddl)
        except Exception:
            pass

    # Seed editable fraud rules. These are data, not hard-coded thresholds.
    default_rules = [
        ('MANY_RETURNS_PRODUCT', 'إرجاع أكثر من 3 مرات لنفس المنتج', 'متوسطة', 3, 'تنبيه'),
        ('LARGE_DISCOUNT', 'خصم أكبر من 50% بدون موافقة', 'عالية', 50, 'مراجعة'),
        ('PRICE_CHANGED_OFTEN', 'تعديل سعر المنتج أكثر من 3 مرات/يوم', 'متوسطة', 3, 'تنبيه'),
        ('ZERO_INVOICE', 'فاتورة بقيمة صفرية', 'عالية', 0, 'مراجعة'),
        ('AFTER_HOURS_LOGIN', 'دخول خارج أوقات العمل', 'متوسطة', 0, 'تنبيه'),
        ('UNUSUAL_QUANTITY', 'كمية غير طبيعية لمنتج واحد', 'متوسطة', 50, 'تنبيه'),
        ('HIGH_CUSTOMER_ORDER', 'فاتورة أعلى من متوسط العميل بشكل غير طبيعي', 'متوسطة', 3, 'مراجعة'),
        ('CUSTOMER_CHANGED_BEFORE_HIGH_ORDER', 'تغيير بيانات العميل قبل شراء كبير', 'عالية', 1, 'مراجعة'),
    ]
    for rule in default_rules:
        conn.execute('''
            INSERT INTO fraud_rules(rule_code, title, severity, threshold_value, action, active, updated_at)
            VALUES (?, ?, ?, ?, ?, 1, ?)
            ON CONFLICT(rule_code) DO NOTHING
        ''', (*rule, now_text()))

    # Indices for scalable dashboards and fraud scans.
    idx_sql = [
        'CREATE INDEX IF NOT EXISTS idx_fraud_rules_active_code ON fraud_rules(active, rule_code)',
        'CREATE INDEX IF NOT EXISTS idx_fraud_alerts_status_created_v451746 ON fraud_alerts(status, created_at)',
        'CREATE INDEX IF NOT EXISTS idx_coupon_hash_active ON coupons(code_hash, active)',
        'CREATE INDEX IF NOT EXISTS idx_coupon_usage_hash_customer ON coupon_usages(code_hash, customer_id, used_at)',
        'CREATE INDEX IF NOT EXISTS idx_sales_customer_created_v451746 ON sales(customer_id, created_at)',
        'CREATE INDEX IF NOT EXISTS idx_sales_created_total_v451746 ON sales(created_at, total)',
        'CREATE INDEX IF NOT EXISTS idx_sale_items_product_qty_v451746 ON sale_items(product_id, quantity)',
        'CREATE INDEX IF NOT EXISTS idx_activity_user_created_v451746 ON activity_logs(user_id, created_at)',
        'CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp_v451746 ON audit_logs(timestamp)',
    ]
    for sql in idx_sql:
        try:
            conn.execute(sql)
        except Exception:
            pass

    # Make audit records append-only. SQLite triggers are the strongest protection
    # available in this local desktop architecture.
    try:
        conn.executescript('''
            CREATE TRIGGER IF NOT EXISTS trg_audit_logs_no_update_v451746
            BEFORE UPDATE ON audit_logs
            BEGIN
                SELECT RAISE(ABORT, 'audit_logs are append-only');
            END;
            CREATE TRIGGER IF NOT EXISTS trg_audit_logs_no_delete_v451746
            BEFORE DELETE ON audit_logs
            BEGIN
                SELECT RAISE(ABORT, 'audit_logs are append-only');
            END;
        ''')
    except Exception:
        pass

    conn.commit()


def _rule_map(self: AppService) -> dict[str, dict]:
    try:
        return {r['rule_code']: dict(r) for r in self.db.all('SELECT * FROM fraud_rules WHERE active=1')}
    except Exception:
        return {}


def _rule_threshold(rules: dict, code: str, default: float) -> float:
    try:
        return float(rules.get(code, {}).get('threshold_value', default) or default)
    except Exception:
        return default


def _add_alert_once(self: AppService, rule_code: str, title: str, details: str, entity_type: str, entity_id: Any, severity: str, user_id=None) -> int | None:
    try:
        existing = self.db.one(
            'SELECT id FROM fraud_alerts WHERE rule_code=? AND entity_type=? AND entity_id=? AND status=?',
            (rule_code, entity_type, entity_id, 'مفتوح'),
        )
        if existing:
            return existing['id']
        return self.add_fraud_alert(rule_code, title, details, entity_type, entity_id, severity, user_id)
    except Exception as exc:
        log_exception(exc, 'fraud alert once')
        return None


def _fraud_scan_now(self: AppService) -> list:
    rules = _rule_map(self)
    created = []
    today = _today()
    if not rules:
        try:
            return _ORIG_FRAUD_SCAN_NOW(self) if _ORIG_FRAUD_SCAN_NOW else []
        except Exception:
            return []

    def active(code: str) -> bool:
        return code in rules

    if active('ZERO_INVOICE'):
        for r in self.db.all("SELECT id, invoice_no, total, user_id FROM sales WHERE date(created_at)=date(?) AND COALESCE(total,0)<=0 LIMIT 50", (today,)):
            created.append(_add_alert_once(self, 'ZERO_INVOICE', f"فاتورة بقيمة صفرية: {r['invoice_no']}", 'فاتورة قيمتها صفر أو أقل', 'sale', r['id'], rules['ZERO_INVOICE']['severity'], r['user_id'] if 'user_id' in r.keys() else None))

    if active('LARGE_DISCOUNT'):
        limit = _rule_threshold(rules, 'LARGE_DISCOUNT', 50)
        for r in self.db.all("SELECT id, invoice_no, subtotal, discount_amount, user_id FROM sales WHERE date(created_at)=date(?) AND COALESCE(subtotal,0)>0 AND (COALESCE(discount_amount,0)*100.0/NULLIF(subtotal,0))>? LIMIT 50", (today, limit)):
            details = f"الخصم {r['discount_amount']} من أصل {r['subtotal']} ويتجاوز {limit}%"
            created.append(_add_alert_once(self, 'LARGE_DISCOUNT', f"خصم غير طبيعي: {r['invoice_no']}", details, 'sale', r['id'], rules['LARGE_DISCOUNT']['severity'], r['user_id'] if 'user_id' in r.keys() else None))

    if active('MANY_RETURNS_PRODUCT'):
        n = _rule_threshold(rules, 'MANY_RETURNS_PRODUCT', 3)
        for r in self.db.all("SELECT product_id, COUNT(*) c, SUM(quantity) qty FROM returns WHERE date(created_at)=date(?) GROUP BY product_id HAVING COUNT(*)>? LIMIT 50", (today, n)):
            created.append(_add_alert_once(self, 'MANY_RETURNS_PRODUCT', 'إرجاع متكرر لنفس المنتج', f"عدد الإرجاعات اليوم: {r['c']}، الكمية: {r['qty']}", 'product', int(r['product_id'] or 0), rules['MANY_RETURNS_PRODUCT']['severity']))

    if active('UNUSUAL_QUANTITY'):
        q = _rule_threshold(rules, 'UNUSUAL_QUANTITY', 50)
        for r in self.db.all("SELECT si.id, si.product_id, si.product_name, si.quantity, s.invoice_no, s.user_id FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE date(s.created_at)=date(?) AND COALESCE(si.quantity,0)>=? LIMIT 50", (today, q)):
            created.append(_add_alert_once(self, 'UNUSUAL_QUANTITY', 'كمية غير طبيعية لمنتج واحد', f"{r['product_name']} في فاتورة {r['invoice_no']} بكمية {r['quantity']}", 'sale_item', r['id'], rules['UNUSUAL_QUANTITY']['severity'], r['user_id'] if 'user_id' in r.keys() else None))

    if active('AFTER_HOURS_LOGIN'):
        for r in self.db.all("SELECT id, user_id, username, action, created_at FROM activity_logs WHERE date(created_at)=date(?) AND (cast(strftime('%H', created_at) as integer)<7 OR cast(strftime('%H', created_at) as integer)>=23) AND (action LIKE '%دخول%' OR action LIKE '%Login%' OR action LIKE '%تسجيل%') LIMIT 50", (today,)):
            created.append(_add_alert_once(self, 'AFTER_HOURS_LOGIN', 'دخول خارج أوقات العمل', f"{r['username']} في {r['created_at']}", 'activity_log', r['id'], rules['AFTER_HOURS_LOGIN']['severity'], r['user_id'] if 'user_id' in r.keys() else None))

    if active('HIGH_CUSTOMER_ORDER'):
        multiplier = _rule_threshold(rules, 'HIGH_CUSTOMER_ORDER', 3)
        rows = self.db.all('''
            SELECT s.id, s.invoice_no, s.customer_id, s.total, s.user_id,
                   (SELECT AVG(total) FROM sales old WHERE old.customer_id=s.customer_id AND old.id<>s.id AND old.created_at>=datetime(s.created_at, '-180 days')) avg_total
            FROM sales s
            WHERE date(s.created_at)=date(?) AND s.customer_id IS NOT NULL AND COALESCE(s.total,0)>0
            LIMIT 100
        ''', (today,))
        for r in rows:
            avg_total = float(r['avg_total'] or 0)
            if avg_total > 0 and float(r['total'] or 0) > avg_total * multiplier:
                created.append(_add_alert_once(self, 'HIGH_CUSTOMER_ORDER', 'فاتورة أعلى من نمط العميل', f"فاتورة {r['invoice_no']} = {r['total']}، متوسط العميل = {avg_total:.0f}", 'sale', r['id'], rules['HIGH_CUSTOMER_ORDER']['severity'], r['user_id'] if 'user_id' in r.keys() else None))

    if active('CUSTOMER_CHANGED_BEFORE_HIGH_ORDER'):
        rows = self.db.all('''
            SELECT s.id, s.invoice_no, s.customer_id, s.total, s.user_id, a.timestamp
            FROM sales s
            JOIN audit_logs a ON a.table_name='customers' AND a.record_id=s.customer_id
            WHERE date(s.created_at)=date(?) AND a.timestamp>=datetime(s.created_at, '-24 hours') AND COALESCE(s.total,0)>0
            LIMIT 100
        ''', (today,))
        for r in rows:
            created.append(_add_alert_once(self, 'CUSTOMER_CHANGED_BEFORE_HIGH_ORDER', 'تغيير بيانات عميل قبل عملية بيع', f"العميل {r['customer_id']} عُدل قبل فاتورة {r['invoice_no']}", 'sale', r['id'], rules['CUSTOMER_CHANGED_BEFORE_HIGH_ORDER']['severity'], r['user_id'] if 'user_id' in r.keys() else None))

    return [x for x in created if x]


def _fraud_rules(self: AppService):
    self.require_permission('can_audit', action='عرض قواعد الاحتيال')
    return self.db.all('SELECT * FROM fraud_rules ORDER BY active DESC, severity DESC, rule_code')


def _save_fraud_rule(self: AppService, rule_code: str, title: str, severity: str, threshold_value: float, action: str = 'تنبيه', active: int = 1):
    self.require_permission('can_audit', action='تعديل قواعد الاحتيال')
    code = _sanitize_text(rule_code, 80).upper()
    if not code:
        raise ValueError('رمز القاعدة مطلوب')
    self.db.execute('''
        INSERT INTO fraud_rules(rule_code, title, severity, threshold_value, action, active, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(rule_code) DO UPDATE SET title=excluded.title, severity=excluded.severity, threshold_value=excluded.threshold_value, action=excluded.action, active=excluded.active, updated_at=excluded.updated_at
    ''', (code, _sanitize_text(title, 200), _sanitize_text(severity, 40) or 'متوسطة', float(threshold_value or 0), _sanitize_text(action, 40) or 'تنبيه', int(bool(active)), now_text()))
    try:
        self.record_audit_v2('fraud_rules', None, 'upsert', None, {'rule_code': code, 'threshold': threshold_value}, getattr(self, 'current_user_id', None), 'تعديل قواعد الاحتيال')
    except Exception:
        pass


def _save_coupon(self: AppService, code: str, coupon_type: str, value: float, min_purchase: float = 0, max_uses: int = 0, expiry_date: str = '', active: int = 1, starts_at: str = '', product_id: int | None = None, category: str = '', customer_id: int | None = None, max_uses_per_customer: int = 1, requires_manager: int = 0):
    self.require_permission('can_discount', action='إدارة الكوبونات')
    raw = str(code or '').strip().upper()
    if not raw:
        raise ValueError('كود الكوبون مطلوب')
    if coupon_type not in ('percent', 'amount', 'free_product', 'free_shipping'):
        raise ValueError('نوع الكوبون غير صحيح')
    if coupon_type == 'percent' and float(value or 0) > 100:
        raise ValueError('نسبة الخصم لا يمكن أن تتجاوز 100%')
    if coupon_type in ('percent', 'amount') and float(value or 0) <= 0:
        raise ValueError('قيمة الكوبون يجب أن تكون أكبر من صفر')
    code_hash = _sha_coupon(raw)
    mask = _mask_code(raw)
    row = self.db.one('SELECT id FROM coupons WHERE code_hash=? OR code=?', (code_hash, raw))
    payload = (coupon_type, float(value or 0), float(min_purchase or 0), int(max_uses or 0), _sanitize_text(expiry_date, 20), int(bool(active)), code_hash, mask, _sanitize_text(starts_at, 20), product_id, _sanitize_text(category, 120), customer_id, max(1, int(max_uses_per_customer or 1)), int(bool(requires_manager)))
    if row:
        self.db.execute('''
            UPDATE coupons SET type=?, value=?, min_purchase=?, max_uses=?, expiry_date=?, active=?, code_hash=?, code_mask=?, starts_at=?, product_id=?, category=?, customer_id=?, max_uses_per_customer=?, requires_manager=? WHERE id=?
        ''', (*payload, row['id']))
        cid = row['id']
        action = 'update'
    else:
        cur = self.db.execute('''
            INSERT INTO coupons(code, type, value, min_purchase, max_uses, used_count, expiry_date, active, created_at, code_hash, code_mask, starts_at, product_id, category, customer_id, max_uses_per_customer, requires_manager)
            VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (mask, coupon_type, float(value or 0), float(min_purchase or 0), int(max_uses or 0), _sanitize_text(expiry_date, 20), int(bool(active)), now_text(), code_hash, mask, _sanitize_text(starts_at, 20), product_id, _sanitize_text(category, 120), customer_id, max(1, int(max_uses_per_customer or 1)), int(bool(requires_manager))))
        cid = cur.lastrowid
        action = 'insert'
    try:
        self.record_audit_v2('coupons', cid, action, None, {'code_mask': mask, 'type': coupon_type, 'value': value}, getattr(self, 'current_user_id', None), 'حفظ كوبون آمن')
    except Exception:
        pass
    self.log('حفظ كوبون', mask)


def _list_coupons(self: AppService, include_inactive: bool = True):
    sql = 'SELECT id, COALESCE(code_mask, code) code, type, value, min_purchase, max_uses, used_count, expiry_date, active, starts_at, product_id, category, customer_id, max_uses_per_customer, requires_manager, created_at FROM coupons'
    if not include_inactive:
        sql += ' WHERE active=1'
    sql += ' ORDER BY active DESC, expiry_date IS NULL, expiry_date, id DESC'
    return self.db.all(sql)


def _validate_coupon(self: AppService, code: str, purchase_total: float, customer_id: int | None = None, product_ids: list[int] | None = None, categories: list[str] | None = None, sale_id: int | None = None):
    raw = str(code or '').strip().upper()
    code_hash = _sha_coupon(raw)
    row = self.db.one('SELECT * FROM coupons WHERE (code_hash=? OR code=?) AND active=1', (code_hash, raw))
    if not row:
        raise ValueError('الكوبون غير موجود أو غير نشط')
    today = _today()
    if row['starts_at'] and str(row['starts_at'])[:10] > today:
        raise ValueError('الكوبون لم يبدأ بعد')
    if row['expiry_date'] and str(row['expiry_date'])[:10] < today:
        raise ValueError('الكوبون منتهي الصلاحية')
    total = float(purchase_total or 0)
    if float(row['min_purchase'] or 0) > total:
        raise ValueError('قيمة الشراء أقل من الحد الأدنى للكوبون')
    if int(row['max_uses'] or 0) > 0 and int(row['used_count'] or 0) >= int(row['max_uses'] or 0):
        raise ValueError('تم استهلاك الحد الأقصى لاستخدام الكوبون')
    if row['customer_id'] and customer_id and int(row['customer_id']) != int(customer_id):
        raise ValueError('هذا الكوبون مخصص لعميل آخر')
    if row['customer_id'] and not customer_id:
        raise ValueError('هذا الكوبون يتطلب اختيار العميل')
    if row['product_id'] and product_ids is not None and int(row['product_id']) not in [int(x) for x in product_ids]:
        raise ValueError('هذا الكوبون لا ينطبق على منتجات هذه الفاتورة')
    if row['category'] and categories is not None:
        cats = {str(c or '').strip() for c in categories}
        if str(row['category']).strip() not in cats:
            raise ValueError('هذا الكوبون لا ينطبق على أصناف هذه الفاتورة')
    if customer_id:
        used = self.db.one('SELECT COUNT(*) c FROM coupon_usages WHERE coupon_id=? AND customer_id=?', (row['id'], int(customer_id)))
        if used and int(used['c'] or 0) >= int(row['max_uses_per_customer'] or 1):
            raise ValueError('تم استخدام هذا الكوبون للعميل بالحد الأقصى المسموح')
    typ = row['type']
    val = float(row['value'] or 0)
    if typ == 'percent':
        discount = total * val / 100.0
    elif typ == 'amount':
        discount = min(val, total)
    else:
        discount = 0.0
    return {'id': row['id'], 'code': _mask_code(raw), 'type': typ, 'discount': discount, 'final_total': max(total - discount, 0), 'requires_manager': int(row['requires_manager'] or 0)}


def _apply_coupon_preview(self: AppService, code: str, purchase_total: float, customer_id: int | None = None, product_ids: list[int] | None = None, categories: list[str] | None = None):
    return _validate_coupon(self, code, purchase_total, customer_id, product_ids, categories)


def _mark_coupon_used(self: AppService, code: str, sale_id: int | None = None, invoice_no: str = '', customer_id: int | None = None, amount: float = 0, user_id: int | None = None):
    raw = str(code or '').strip().upper()
    code_hash = _sha_coupon(raw)
    row = self.db.one('SELECT id FROM coupons WHERE code_hash=? OR code=?', (code_hash, raw))
    if not row:
        raise ValueError('الكوبون غير موجود')
    with self.db.conn:
        self.db.conn.execute('INSERT OR IGNORE INTO coupon_usages(coupon_id, code_hash, customer_id, sale_id, invoice_no, amount, used_at, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', (row['id'], code_hash, customer_id, sale_id, invoice_no, float(amount or 0), now_text(), user_id))
        self.db.conn.execute('UPDATE coupons SET used_count=(SELECT COUNT(*) FROM coupon_usages WHERE coupon_id=?), last_used_at=? WHERE id=?', (row['id'], now_text(), row['id']))


def _audit_v2_rows(self: AppService, table_name: str = '', limit: int = 300):
    rows = _ORIG_AUDIT_ROWS(self, table_name, limit) if _ORIG_AUDIT_ROWS else []
    clean = []
    for r in rows:
        d = _row_to_dict(r)
        for key in ('old_values', 'new_values', 'reason', 'username', 'ip'):
            if key in d:
                d[key] = html.escape(_sanitize_text(d[key], 2000))
        clean.append(d)
    return clean


def _export_audit_legal_csv(self: AppService, out_path: str | Path | None = None, table_name: str = '') -> str:
    self.require_permission('can_audit', action='تصدير سجل التدقيق')
    root = Path(out_path).expanduser() if out_path else (Path.home() / 'MaxSales_Audit_Exports')
    if root.suffix.lower() == '.csv':
        path = root
        path.parent.mkdir(parents=True, exist_ok=True)
    else:
        root.mkdir(parents=True, exist_ok=True)
        path = root / f'audit_logs_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    rows = _audit_v2_rows(self, table_name, 5000)
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['id','table_name','record_id','action','user_id','username','ip','reason','timestamp','old_values','new_values'])
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, '') for k in writer.fieldnames})
    return str(path)


def _dashboard_page_data(self: AppService, page: int = 1, page_size: int = 50):
    page = max(1, int(page or 1))
    page_size = max(20, min(int(page_size or 50), 200))
    offset = (page - 1) * page_size
    return self.db.all('SELECT id, invoice_no, total, total_profit, payment_method, created_at FROM sales ORDER BY id DESC LIMIT ? OFFSET ?', (page_size, offset))


def _init(self: AppService, *args, **kwargs):
    _ORIG_INIT(self, *args, **kwargs)
    try:
        _ensure_schema(self)
    except Exception as exc:
        log_exception(exc, 'v45.17.4.6 security operations schema')


AppService.__init__ = _init
AppService.fraud_scan_now = _fraud_scan_now
AppService.fraud_rules = _fraud_rules
AppService.save_fraud_rule = _save_fraud_rule
AppService.save_coupon = _save_coupon
AppService.list_coupons = _list_coupons
AppService.validate_coupon = _validate_coupon
AppService.apply_coupon_preview = _apply_coupon_preview
AppService.mark_coupon_used = _mark_coupon_used
AppService.audit_v2_rows = _audit_v2_rows
AppService.export_audit_legal_csv = _export_audit_legal_csv
AppService.dashboard_page_data = _dashboard_page_data
