from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})
import services.service_patches.v19_gdrive as _prev_v19_gdrive
globals().update({k: v for k, v in vars(_prev_v19_gdrive).items() if not k.startswith('__')})
import services.service_patches.v20_gdrive_settings as _prev_v20_gdrive_settings
globals().update({k: v for k, v in vars(_prev_v20_gdrive_settings).items() if not k.startswith('__')})
import services.service_patches.v21_backup as _prev_v21_backup
globals().update({k: v for k, v in vars(_prev_v21_backup).items() if not k.startswith('__')})
import services.service_patches.v22_gdrive_final as _prev_v22_gdrive_final
globals().update({k: v for k, v in vars(_prev_v22_gdrive_final).items() if not k.startswith('__')})
import services.service_patches.v23_business_tools as _prev_v23_business_tools
globals().update({k: v for k, v in vars(_prev_v23_business_tools).items() if not k.startswith('__')})
import services.service_patches.v24_smart_assistant as _prev_v24_smart_assistant
globals().update({k: v for k, v in vars(_prev_v24_smart_assistant).items() if not k.startswith('__')})
import services.service_patches.v25_readiness as _prev_v25_readiness
globals().update({k: v for k, v in vars(_prev_v25_readiness).items() if not k.startswith('__')})
import services.service_patches.v25_1_barcode as _prev_v25_1_barcode
globals().update({k: v for k, v in vars(_prev_v25_1_barcode).items() if not k.startswith('__')})
import services.service_patches.v26_tools_repair as _prev_v26_tools_repair
globals().update({k: v for k, v in vars(_prev_v26_tools_repair).items() if not k.startswith('__')})
import services.service_patches.v26_1_tools_stability as _prev_v26_1_tools_stability
globals().update({k: v for k, v in vars(_prev_v26_1_tools_stability).items() if not k.startswith('__')})

# ================================================================
# V27 PROMOTIONS, PRICE LEVELS, EXCEL IMPORT/EXPORT AND INVOICE QR
# ================================================================
from datetime import date as _v27_date


def _v27_norm_text(value) -> str:
    return str(value or '').strip()


def _v27_bool(value) -> bool:
    return str(value or '').strip().lower() in ('1', 'true', 'yes', 'on', 'نعم', 'مفعل')


def _v27_require_pricing_admin(self: AppService, user_id: int | None = None, action: str = 'إدارة الأسعار والعروض'):
    return _v25_require_any(self, ('can_products', 'can_price_edit', 'can_settings', 'can_tools'), user_id, action)


def _v27_list_price_levels(self: AppService, active_only: bool = True):
    _v25_require_any(self, ('can_sales', 'can_touch_pos', 'can_products', 'can_price_edit', 'can_tools', 'can_reports'), action='عرض مستويات الأسعار')
    where = 'WHERE active=1' if active_only else ''
    return self.db.all(f'SELECT * FROM price_levels {where} ORDER BY sort_order, id')


def _v27_save_price_level(self: AppService, data: dict, level_id: int | None = None, user_id: int | None = None) -> int:
    user = _v27_require_pricing_admin(self, user_id, 'حفظ مستوى سعر')
    name = _v27_norm_text(data.get('name'))
    if not name:
        raise ValueError('اسم مستوى السعر مطلوب')
    desc = _v27_norm_text(data.get('description'))
    auto_apply = 1 if _v27_bool(data.get('auto_apply', 1)) else 0
    is_default = 1 if _v27_bool(data.get('is_default', 0)) else 0
    active = 1 if _v27_bool(data.get('active', 1)) else 0
    sort_order = to_int(data.get('sort_order'), 50)
    if level_id:
        self.db.execute('''UPDATE price_levels SET name=?, description=?, auto_apply=?, is_default=?, active=?, sort_order=? WHERE id=?''',
                        (name, desc, auto_apply, is_default, active, sort_order, int(level_id)))
        out_id = int(level_id)
    else:
        cur = self.db.execute('''INSERT INTO price_levels (name, description, auto_apply, is_default, active, sort_order, created_at)
                                 VALUES (?, ?, ?, ?, ?, ?, ?)''',
                              (name, desc, auto_apply, is_default, active, sort_order, now_text()))
        out_id = int(cur.lastrowid)
    if is_default:
        self.db.execute('UPDATE price_levels SET is_default=CASE WHEN id=? THEN 1 ELSE 0 END', (out_id,))
    self.log('حفظ مستوى سعر', name, user['id'])
    return out_id


def _v27_deactivate_price_level(self: AppService, level_id: int, user_id: int | None = None) -> None:
    user = _v27_require_pricing_admin(self, user_id, 'تعطيل مستوى سعر')
    row = self.db.one('SELECT name, is_default FROM price_levels WHERE id=?', (int(level_id),))
    if not row:
        return
    if int(row['is_default'] or 0):
        raise ValueError('لا يمكن تعطيل مستوى السعر الافتراضي')
    self.db.execute('UPDATE price_levels SET active=0 WHERE id=?', (int(level_id),))
    self.log('تعطيل مستوى سعر', row['name'], user['id'])


def _v27_set_product_price_level(self: AppService, product_id: int, level_id: int, price: float, min_quantity: int = 1, active: bool = True, user_id: int | None = None) -> int:
    user = _v27_require_pricing_admin(self, user_id, 'حفظ سعر مستوى للمنتج')
    product = self.db.one('SELECT id, name FROM products WHERE id=? AND active=1', (int(product_id),))
    level = self.db.one('SELECT id, name FROM price_levels WHERE id=? AND active=1', (int(level_id),))
    if not product:
        raise ValueError('المنتج غير موجود')
    if not level:
        raise ValueError('مستوى السعر غير موجود أو معطل')
    price = float(price or 0)
    if price < 0:
        raise ValueError('السعر لا يمكن أن يكون سالباً')
    min_quantity = max(int(min_quantity or 1), 1)
    active_i = 1 if active else 0
    existing = self.db.one('SELECT id FROM product_price_levels WHERE product_id=? AND price_level_id=?', (int(product_id), int(level_id)))
    if existing:
        self.db.execute('''UPDATE product_price_levels SET price=?, min_quantity=?, active=? WHERE id=?''', (price, min_quantity, active_i, existing['id']))
        out_id = int(existing['id'])
    else:
        cur = self.db.execute('''INSERT INTO product_price_levels (product_id, price_level_id, price, min_quantity, active, created_at)
                                 VALUES (?, ?, ?, ?, ?, ?)''', (int(product_id), int(level_id), price, min_quantity, active_i, now_text()))
        out_id = int(cur.lastrowid)
    self.log('حفظ سعر مستوى للمنتج', f"{product['name']} | {level['name']} | {money(price)} | حد {min_quantity}", user['id'])
    return out_id


def _v27_list_product_price_levels(self: AppService, product_id: int | None = None):
    _v25_require_any(self, ('can_products', 'can_price_edit', 'can_tools', 'can_reports', 'can_sales', 'can_touch_pos'), action='عرض أسعار المستويات')
    params = []
    where = ['p.active=1']
    if product_id:
        where.append('p.id=?')
        params.append(int(product_id))
    return self.db.all(f'''
        SELECT ppl.*, p.name product_name, p.barcode, pl.name level_name, pl.auto_apply, pl.is_default
        FROM product_price_levels ppl
        JOIN products p ON p.id=ppl.product_id
        JOIN price_levels pl ON pl.id=ppl.price_level_id
        WHERE {' AND '.join(where)}
        ORDER BY p.name, pl.sort_order, pl.id
    ''', params)


def _v27_delete_product_price_level(self: AppService, product_price_id: int, user_id: int | None = None) -> None:
    user = _v27_require_pricing_admin(self, user_id, 'حذف سعر مستوى للمنتج')
    row = self.db.one('''SELECT ppl.id, p.name product_name, pl.name level_name FROM product_price_levels ppl
                         JOIN products p ON p.id=ppl.product_id JOIN price_levels pl ON pl.id=ppl.price_level_id
                         WHERE ppl.id=?''', (int(product_price_id),))
    if row:
        self.db.execute('DELETE FROM product_price_levels WHERE id=?', (int(product_price_id),))
        self.log('حذف سعر مستوى للمنتج', f"{row['product_name']} | {row['level_name']}", user['id'])


def _v27_list_promotions(self: AppService, active_only: bool = False):
    _v25_require_any(self, ('can_products', 'can_price_edit', 'can_tools', 'can_reports', 'can_sales', 'can_touch_pos'), action='عرض العروض')
    where = ['1=1']
    if active_only:
        today = _v27_date.today().isoformat()
        where.append("active=1 AND (start_date IS NULL OR TRIM(start_date)='' OR date(start_date)<=date(?)) AND (end_date IS NULL OR TRIM(end_date)='' OR date(end_date)>=date(?))")
        params = [today, today]
    else:
        params = []
    return self.db.all(f'''
        SELECT pr.*, COALESCE(p.name, '') product_name
        FROM promotions pr LEFT JOIN products p ON p.id=pr.product_id
        WHERE {' AND '.join(where)}
        ORDER BY active DESC, priority DESC, id DESC
    ''', params)


def _v27_save_promotion(self: AppService, data: dict, promo_id: int | None = None, user_id: int | None = None) -> int:
    user = _v27_require_pricing_admin(self, user_id, 'حفظ عرض')
    name = _v27_norm_text(data.get('name'))
    if not name:
        raise ValueError('اسم العرض مطلوب')
    scope_type = _v27_norm_text(data.get('scope_type') or 'all')
    if scope_type not in ('all', 'product', 'category'):
        raise ValueError('نطاق العرض غير صحيح')
    product_id = data.get('product_id') if scope_type == 'product' else None
    product_id = int(product_id) if product_id not in (None, '', 0, '0') else None
    category = _v27_norm_text(data.get('category')) if scope_type == 'category' else ''
    if scope_type == 'product' and not product_id:
        raise ValueError('اختر منتجاً للعرض')
    if scope_type == 'category' and not category:
        raise ValueError('اكتب الصنف للعرض')
    promo_type = _v27_norm_text(data.get('promo_type') or 'percent')
    if promo_type not in ('percent', 'amount', 'fixed_price', 'buy_x_get_y'):
        raise ValueError('نوع العرض غير صحيح')
    discount_value = max(float(data.get('discount_value') or 0), 0.0)
    buy_qty = max(to_int(data.get('buy_qty'), 0), 0)
    free_qty = max(to_int(data.get('free_qty'), 0), 0)
    min_quantity = max(to_int(data.get('min_quantity'), 1), 1)
    if promo_type == 'percent' and discount_value > 100:
        raise ValueError('نسبة الخصم لا يمكن أن تتجاوز 100%')
    if promo_type == 'buy_x_get_y' and (buy_qty <= 0 or free_qty <= 0):
        raise ValueError('عرض اشتر واحصل يتطلب كمية شراء وكمية مجانية')
    start_date = _v27_norm_text(data.get('start_date')) or None
    end_date = _v27_norm_text(data.get('end_date')) or None
    priority = to_int(data.get('priority'), 0)
    active = 1 if _v27_bool(data.get('active', 1)) else 0
    note = _v27_norm_text(data.get('note'))
    values = (name, scope_type, product_id, category, promo_type, discount_value, buy_qty, free_qty, min_quantity, start_date, end_date, priority, active, note)
    if promo_id:
        self.db.execute('''UPDATE promotions SET name=?, scope_type=?, product_id=?, category=?, promo_type=?, discount_value=?, buy_qty=?, free_qty=?, min_quantity=?, start_date=?, end_date=?, priority=?, active=?, note=? WHERE id=?''', values + (int(promo_id),))
        out_id = int(promo_id)
    else:
        cur = self.db.execute('''INSERT INTO promotions (name, scope_type, product_id, category, promo_type, discount_value, buy_qty, free_qty, min_quantity, start_date, end_date, priority, active, note, created_at)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', values + (now_text(),))
        out_id = int(cur.lastrowid)
    self.log('حفظ عرض', name, user['id'])
    return out_id


def _v27_deactivate_promotion(self: AppService, promo_id: int, user_id: int | None = None) -> None:
    user = _v27_require_pricing_admin(self, user_id, 'تعطيل عرض')
    row = self.db.one('SELECT name FROM promotions WHERE id=?', (int(promo_id),))
    if row:
        self.db.execute('UPDATE promotions SET active=0 WHERE id=?', (int(promo_id),))
        self.log('تعطيل عرض', row['name'], user['id'])


def _v27_applicable_promotions(self: AppService, product, quantity: int, sale_date: str | None = None):
    settings = self.get_settings()
    if not _v27_bool(settings.get('auto_apply_promotions', '1')):
        return []
    sale_date = sale_date or _v27_date.today().isoformat()
    category = product['category'] or ''
    rows = self.db.all('''
        SELECT * FROM promotions
        WHERE active=1
          AND (start_date IS NULL OR TRIM(start_date)='' OR date(start_date)<=date(?))
          AND (end_date IS NULL OR TRIM(end_date)='' OR date(end_date)>=date(?))
          AND (
              scope_type='all'
              OR (scope_type='product' AND product_id=?)
              OR (scope_type='category' AND category=?))
        ORDER BY priority DESC, id DESC
    ''', (sale_date, sale_date, product['id'], category))
    return [r for r in rows if int(quantity or 0) >= int(r['min_quantity'] or 1)]


def _v27_apply_promotion_to_price(promo, base_price: float, quantity: int) -> dict:
    return apply_promotion_to_price(promo, base_price, quantity)


def _v27_resolve_sale_line(self: AppService, product_id: int, quantity: int = 1, price_level_id: int | None = None, sale_date: str | None = None) -> dict:
    _v25_require_any(self, ('can_sales', 'can_touch_pos', 'can_products', 'can_reports', 'can_tools'), action='احتساب سعر البيع')
    quantity = max(int(quantity or 1), 1)
    product = self.db.one('SELECT * FROM products WHERE id=? AND active=1', (int(product_id),))
    if not product:
        raise ValueError('منتج البيع غير موجود أو معطل')
    original = float(product['sale_price'] or 0)
    unit = original
    level_id = None
    level_name = 'مفرد'
    settings = self.get_settings()
    auto_levels = _v27_bool(settings.get('auto_apply_price_levels', '1'))
    if price_level_id:
        level_row = self.db.one('''SELECT ppl.*, pl.name level_name FROM product_price_levels ppl
                                   JOIN price_levels pl ON pl.id=ppl.price_level_id
                                   WHERE ppl.product_id=? AND ppl.price_level_id=? AND ppl.active=1 AND pl.active=1''', (int(product_id), int(price_level_id)))
        if level_row and float(level_row['price'] or 0) > 0 and quantity >= int(level_row['min_quantity'] or 1):
            unit = float(level_row['price'] or original)
            level_id = int(level_row['price_level_id'])
            level_name = level_row['level_name']
    elif auto_levels:
        level_row = self.db.one('''SELECT ppl.*, pl.name level_name FROM product_price_levels ppl
                                   JOIN price_levels pl ON pl.id=ppl.price_level_id
                                   WHERE ppl.product_id=? AND ppl.active=1 AND pl.active=1 AND pl.auto_apply=1
                                     AND ppl.price>0 AND ? >= ppl.min_quantity
                                   ORDER BY ppl.min_quantity DESC, pl.sort_order DESC, ppl.id DESC LIMIT 1''', (int(product_id), quantity))
        if level_row:
            unit = float(level_row['price'] or original)
            level_id = int(level_row['price_level_id'])
            level_name = level_row['level_name']
    best_promo = None
    best_calc = {'unit_price': unit, 'discount_amount': 0.0, 'free_quantity': 0}
    for promo in _v27_applicable_promotions(self, product, quantity, sale_date):
        calc = _v27_apply_promotion_to_price(promo, unit, quantity)
        if calc['discount_amount'] > best_calc['discount_amount'] + 0.0001:
            best_promo = promo
            best_calc = calc
    final_unit = float(best_calc['unit_price'])
    return {
        'product_id': int(product['id']),
        'product_name': product['name'],
        'quantity': quantity,
        'cost_price': float(product['cost_price'] or 0),
        'original_unit_price': original,
        'base_unit_price': unit,
        'unit_price': final_unit,
        'line_total': final_unit * quantity,
        'price_level_id': level_id,
        'price_level_name': level_name,
        'promotion_id': int(best_promo['id']) if best_promo else None,
        'promotion_name': best_promo['name'] if best_promo else '',
        'promotion_discount_amount': float(best_calc['discount_amount'] or 0),
        'free_quantity': int(best_calc['free_quantity'] or 0),
        'commission_percent': float(product['commission_percent'] or 0),
        'stock_quantity': int(product['quantity'] or 0),
    }


def _v27_secure_sale_cart(self: AppService, cart: list[dict], user_id: int | None = None) -> list[dict]:
    safe: list[dict] = []
    for raw in cart or []:
        pid = int(raw.get('product_id') or 0)
        qty = int(raw.get('quantity') or 0)
        if pid <= 0 or qty <= 0:
            raise ValueError('بيانات المنتج أو الكمية غير صحيحة')
        level_id = raw.get('price_level_id') or None
        line = _v27_resolve_sale_line(self, pid, qty, int(level_id) if level_id else None)
        if raw.get('manual_price'):
            self.require_permission('can_price_edit', user_id, 'تعديل سعر البيع داخل الفاتورة')
            manual = float(raw.get('unit_price') or 0)
            if manual < 0:
                raise ValueError('سعر البيع لا يمكن أن يكون سالباً')
            line['unit_price'] = manual
            line['line_total'] = manual * qty
            line['promotion_id'] = None
            line['promotion_name'] = 'سعر يدوي'
            line['promotion_discount_amount'] = max((float(line['base_unit_price']) - manual) * qty, 0.0)
        safe.append({
            'product_id': line['product_id'],
            'product_name': line['product_name'],
            'name': line['product_name'],
            'quantity': qty,
            'cost_price': line['cost_price'],
            'unit_price': line['unit_price'],
            'commission_percent': line['commission_percent'],
            'price_level_id': line['price_level_id'],
            'price_level_name': line['price_level_name'],
            'promotion_id': line['promotion_id'],
            'promotion_name': line['promotion_name'],
            'original_unit_price': line['original_unit_price'],
            'promotion_discount_amount': line['promotion_discount_amount'],
            'free_quantity': line['free_quantity'],
        })
    return safe

# Rebind the V25 secure-cart global used by V25 complete/suspend wrappers.
_v25_secure_sale_cart = _v27_secure_sale_cart


_orig_complete_sale_v27 = AppService.complete_sale

def _v27_complete_sale(self: AppService, cart, employee_id, customer_id, payment_method, discount_amount=0, note='', user_id=None, discount_type='amount'):
    safe_cart = _v27_secure_sale_cart(self, cart, user_id)
    inv = _orig_complete_sale_v27(self, safe_cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type)
    try:
        sale = self.db.one('SELECT id FROM sales WHERE invoice_no=?', (inv,))
        if sale:
            rows = self.db.all('SELECT id FROM sale_items WHERE sale_id=? ORDER BY id', (sale['id'],))
            promo_total = 0.0
            for idx, row in enumerate(rows):
                if idx >= len(safe_cart):
                    break
                item = safe_cart[idx]
                promo_total += float(item.get('promotion_discount_amount') or 0)
                self.db.execute('''UPDATE sale_items
                                   SET price_level_id=?, price_level_name=?, promotion_id=?, promotion_name=?,
                                       original_unit_price=?, promotion_discount_amount=?, free_quantity=?
                                   WHERE id=?''',
                                (item.get('price_level_id'), item.get('price_level_name'), item.get('promotion_id'), item.get('promotion_name'),
                                 float(item.get('original_unit_price') or item.get('unit_price') or 0), float(item.get('promotion_discount_amount') or 0), int(item.get('free_quantity') or 0), row['id']))
            self.db.execute('UPDATE sales SET promotion_discount_amount=? WHERE id=?', (promo_total, sale['id']))
    except Exception as exc:
        self.log('تنبيه تحديث بيانات العروض للفاتورة', str(exc), user_id)
    return inv

AppService.complete_sale = _v27_complete_sale


_orig_suspend_sale_v27 = AppService.suspend_sale

def _v27_suspend_sale(self: AppService, cart, employee_id, customer_id, payment_method, discount_amount, note='', user_id=None):
    safe_cart = _v27_secure_sale_cart(self, cart, user_id)
    return _orig_suspend_sale_v27(self, safe_cart, employee_id, customer_id, payment_method, discount_amount, note, user_id)

AppService.suspend_sale = _v27_suspend_sale


def _v27_qr_data_uri(self: AppService, payload: str) -> str:
    try:
        import base64
        import io
        import qrcode
        img = qrcode.make(payload)
        buf = io.BytesIO()
        img.save(buf, format='PNG')
        return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode('ascii')
    except Exception:
        return ''


def _v27_invoice_qr_payload(self: AppService, sale) -> str:
    st = self.get_settings()
    company = st.get('company_name', 'MAX SALES')
    return f"MAXSALES|{company}|{sale['invoice_no']}|{sale['created_at']}|{float(sale['total'] or 0):.2f}|{sale['payment_method']}"


def _v27_print_invoice_html(self: AppService, invoice_no: str) -> Path:
    _v25_require_print(self, 'طباعة الفواتير')
    sale, items = self.invoice_details(invoice_no)
    rows = ''
    for i in items:
        level = i['price_level_name'] if 'price_level_name' in i.keys() and i['price_level_name'] else 'مفرد'
        promo = i['promotion_name'] if 'promotion_name' in i.keys() and i['promotion_name'] else ''
        original = i['original_unit_price'] if 'original_unit_price' in i.keys() and i['original_unit_price'] else i['unit_price']
        discount = i['promotion_discount_amount'] if 'promotion_discount_amount' in i.keys() else 0
        detail = html.escape(level)
        if promo:
            detail += '<br><span class="muted">' + html.escape(promo) + '</span>'
        free_qty = int(i['free_quantity']) if 'free_quantity' in i.keys() and i['free_quantity'] else 0
        qty_text = str(i['quantity'])
        if free_qty:
            note = format_buy_get_note(int(i['quantity'] or 0), free_qty)
            qty_text += '<br><span class="freeNote">' + html.escape(note) + '</span>'
            detail += '<br><span class="freeNote">عرض اشترِ واحصل على مجاني</span>'
        rows += f"<tr><td>{html.escape(i['product_name'])}</td><td>{qty_text}</td><td>{money(original)}</td><td>{money(i['unit_price'])}</td><td>{detail}</td><td>{money(discount)}</td><td>{money(i['line_total'])}</td></tr>"
    qr_html = ''
    if _v27_bool(self.get_settings().get('qr_on_invoice_enabled', '1')):
        payload = _v27_invoice_qr_payload(self, sale)
        uri = _v27_qr_data_uri(self, payload)
        if uri:
            qr_html = f"<div class='qrBox'><img src='{uri}' style='width:125px;height:125px'><br><small>QR فاتورة</small></div>"
        else:
            qr_html = f"<div class='qrBox'><b>QR</b><br><small>{html.escape(payload)}</small></div>"
    promo_total = sale['promotion_discount_amount'] if 'promotion_discount_amount' in sale.keys() else 0
    body = f"""
    <div style='display:flex;gap:18px;align-items:flex-start;justify-content:space-between'>
      <div style='flex:1'>
        <h3>فاتورة بيع: {html.escape(sale['invoice_no'])}</h3>
        <p>التاريخ: {sale['created_at']}<br>المستخدم: {html.escape(sale['user_name'])}<br>موظف العمولة: {html.escape(sale['employee'])}<br>الزبون: {html.escape(sale['customer'])}<br>الدفع: {html.escape(sale['payment_method'])}</p>
      </div>
      {qr_html}
    </div>
    <table><tr><th>المادة</th><th>الكمية</th><th>السعر الأصلي</th><th>سعر البيع</th><th>المستوى / العرض</th><th>خصم العرض</th><th>الإجمالي</th></tr>{rows}</table>
    <p>خصومات العروض: {money(promo_total)}<br>خصم الفاتورة: {money(sale['discount_amount'])}</p>
    <p class='total'>الصافي: {money(sale['total'])}</p>
    <style>.qrBox{{border:1px solid #ddd;border-radius:10px;padding:10px;text-align:center;min-width:145px}} .muted{{color:#666;font-size:12px}} .freeNote{{display:inline-block;margin-top:3px;color:#0f766e;font-weight:700;font-size:12px}}</style>
    """
    return self._html_page('invoice_'+sale['invoice_no'].replace('/','_'), body)

AppService.print_invoice_html = _v27_print_invoice_html


def _v27_product_price_level_map(self: AppService, product_id: int) -> dict:
    rows = self.db.all('''SELECT pl.name, ppl.price, ppl.min_quantity FROM product_price_levels ppl
                          JOIN price_levels pl ON pl.id=ppl.price_level_id
                          WHERE ppl.product_id=? AND ppl.active=1 AND pl.active=1''', (int(product_id),))
    return {r['name']: {'price': r['price'], 'min_quantity': r['min_quantity']} for r in rows}


def _v27_xlsx_headers(self: AppService) -> list[str]:
    base = ['id', 'barcode', 'name', 'category', 'cost_price', 'sale_price', 'quantity', 'min_quantity', 'unit_name', 'items_per_unit', 'expiry_date', 'reorder_point', 'commission_percent']
    for lvl in self.db.all("SELECT name FROM price_levels WHERE active=1 AND name<>'مفرد' ORDER BY sort_order, id"):
        base.extend([f"سعر {lvl['name']}", f"حد {lvl['name']}"])
    return base


def _v27_export_products_xlsx(self: AppService, path: str | Path | None = None) -> Path:
    user = _v25_require_any(self, ('can_products', 'can_inventory', 'can_tools'), action='تصدير المنتجات Excel')
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
    except Exception as exc:
        raise RuntimeError('مكتبة openpyxl غير مثبتة. شغل: python -m pip install openpyxl') from exc
    target = Path(path) if path else self.export_dir() / f'products_export_{_v25_now_stamp()}.xlsx'
    target.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = 'Products'
    headers = _v27_xlsx_headers(self)
    if not self.user_has(user, 'can_view_cost') and 'cost_price' in headers:
        headers.remove('cost_price')
    ws.append(headers)
    for r in self.db.all('SELECT * FROM products WHERE active=1 ORDER BY name'):
        levels = _v27_product_price_level_map(self, r['id'])
        row = []
        for h in headers:
            if h.startswith('سعر '):
                row.append(levels.get(h.replace('سعر ', '', 1), {}).get('price', ''))
            elif h.startswith('حد '):
                row.append(levels.get(h.replace('حد ', '', 1), {}).get('min_quantity', ''))
            else:
                row.append(r[h] if h in r.keys() else '')
        ws.append(row)
    header_fill = PatternFill('solid', fgColor='1F4E79')
    thin = Side(style='thin', color='DDDDDD')
    for cell in ws[1]:
        cell.font = Font(bold=True, color='FFFFFF')
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
        cell.border = Border(bottom=thin)
    ws.freeze_panes = 'A2'
    for col in range(1, ws.max_column + 1):
        letter = get_column_letter(col)
        max_len = max(len(str(ws.cell(row=row, column=col).value or '')) for row in range(1, min(ws.max_row, 100) + 1))
        ws.column_dimensions[letter].width = min(max(max_len + 2, 10), 28)
    wb.save(target)
    self.log('تصدير منتجات Excel', str(target), user['id'])
    return target


def _v27_export_products_template_xlsx(self: AppService, path: str | Path | None = None) -> Path:
    _v25_require_any(self, ('can_products', 'can_inventory', 'can_tools'), action='تصدير قالب Excel')
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
    except Exception as exc:
        raise RuntimeError('مكتبة openpyxl غير مثبتة. شغل: python -m pip install openpyxl') from exc
    target = Path(path) if path else self.export_dir() / f'products_template_{_v25_now_stamp()}.xlsx'
    target.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = 'Products'
    headers = _v27_xlsx_headers(self)
    ws.append(headers)
    sample = {h: '' for h in headers}
    sample.update({'barcode': 'SAMPLE-001', 'name': 'منتج تجريبي', 'category': 'مواد غذائية', 'cost_price': 1000, 'sale_price': 1500, 'quantity': 20, 'min_quantity': 5, 'unit_name': 'حبة', 'items_per_unit': 1, 'reorder_point': 5, 'commission_percent': 0})
    for h in headers:
        if h == 'سعر جملة': sample[h] = 1400
        if h == 'حد جملة': sample[h] = 10
        if h == 'سعر خاص': sample[h] = 1300
        if h == 'حد خاص': sample[h] = 1
    ws.append([sample.get(h, '') for h in headers])
    ws['A4'] = 'ملاحظات: اترك id فارغاً عند إضافة منتج جديد. الباركود أو id يستخدمان للتحديث. أعمدة سعر/حد جملة وخاص اختيارية.'
    ws['A4'].font = Font(italic=True, color='666666')
    for cell in ws[1]:
        cell.font = Font(bold=True, color='FFFFFF')
        cell.fill = PatternFill('solid', fgColor='1F4E79')
        cell.alignment = Alignment(horizontal='center')
    for col in range(1, ws.max_column + 1):
        ws.column_dimensions[get_column_letter(col)].width = 18
    ws.freeze_panes = 'A2'
    wb.save(target)
    return target


def _v27_import_products_xlsx(self: AppService, path: str | Path) -> dict:
    user = _v25_require_any(self, ('can_product_add', 'can_product_edit', 'can_tools'), action='استيراد منتجات Excel')
    try:
        from openpyxl import load_workbook
    except Exception as exc:
        raise RuntimeError('مكتبة openpyxl غير مثبتة. شغل: python -m pip install openpyxl') from exc
    source = Path(path)
    if not source.exists():
        raise ValueError('ملف Excel غير موجود')
    wb = load_workbook(source, data_only=True)
    ws = wb.active
    headers = [str(c.value or '').strip() for c in ws[1]]
    if not any(h in headers for h in ('name', 'اسم المنتج')):
        raise ValueError('ملف Excel لا يحتوي عمود name أو اسم المنتج')
    added = updated = skipped = 0

    def cell_value(row_dict: dict, *names):
        for n in names:
            if n in row_dict and row_dict[n] not in (None, ''):
                return row_dict[n]
        return None

    levels = self.db.all("SELECT id, name FROM price_levels WHERE active=1 AND name<>'مفرد' ORDER BY sort_order, id")
    for row in ws.iter_rows(min_row=2, values_only=True):
        row_dict = {headers[i]: row[i] for i in range(min(len(headers), len(row))) if headers[i]}
        name = _v27_norm_text(cell_value(row_dict, 'name', 'اسم المنتج'))
        if not name or name.startswith('ملاحظات'):
            skipped += 1
            continue
        barcode = _v27_norm_text(cell_value(row_dict, 'barcode', 'الباركود')) or None
        row_id = cell_value(row_dict, 'id', 'المعرف')
        existing = None
        if row_id not in (None, ''):
            existing = self.db.one('SELECT * FROM products WHERE id=?', (to_int(row_id),))
        if not existing and barcode:
            existing = self.db.one('SELECT * FROM products WHERE barcode=?', (barcode,))
        if not existing:
            existing = self.db.one('SELECT * FROM products WHERE name=? ORDER BY id DESC LIMIT 1', (name,))
        def keep_or(default_key, value, default=0):
            if value not in (None, ''):
                return value
            if existing and default_key in existing.keys():
                return existing[default_key]
            return default
        data = {
            'barcode': barcode,
            'name': name,
            'category': cell_value(row_dict, 'category', 'الصنف') or (existing['category'] if existing else ''),
            'cost_price': to_float(keep_or('cost_price', cell_value(row_dict, 'cost_price', 'سعر الشراء'))),
            'sale_price': to_float(keep_or('sale_price', cell_value(row_dict, 'sale_price', 'سعر البيع'))),
            'quantity': to_int(keep_or('quantity', cell_value(row_dict, 'quantity', 'الكمية'))),
            'min_quantity': to_int(keep_or('min_quantity', cell_value(row_dict, 'min_quantity', 'حد التنبيه'), 5), 5),
            'commission_percent': to_float(keep_or('commission_percent', cell_value(row_dict, 'commission_percent', 'العمولة'))),
        }
        self.save_product(data, existing['id'] if existing else None)
        product = None
        if barcode:
            product = self.db.one('SELECT * FROM products WHERE barcode=?', (barcode,))
        if not product:
            product = self.db.one('SELECT * FROM products WHERE name=? ORDER BY id DESC LIMIT 1', (name,))
        if not product:
            skipped += 1
            continue
        self.db.execute('''UPDATE products SET unit_name=?, items_per_unit=?, expiry_date=?, reorder_point=? WHERE id=?''',
                        (_v27_norm_text(cell_value(row_dict, 'unit_name', 'الوحدة')) or (product['unit_name'] if 'unit_name' in product.keys() else 'حبة'),
                         to_float(cell_value(row_dict, 'items_per_unit', 'عدد القطع في الوحدة') or (product['items_per_unit'] if 'items_per_unit' in product.keys() else 1), 1),
                         _v27_norm_text(cell_value(row_dict, 'expiry_date', 'تاريخ الانتهاء')) or None,
                         to_int(cell_value(row_dict, 'reorder_point', 'نقطة إعادة الطلب') or (product['reorder_point'] if 'reorder_point' in product.keys() else 0)),
                         product['id']))
        for lvl in levels:
            price_value = cell_value(row_dict, f"سعر {lvl['name']}", f"{lvl['name']}_price", f"price_{lvl['id']}")
            min_value = cell_value(row_dict, f"حد {lvl['name']}", f"{lvl['name']}_min_qty", f"min_qty_{lvl['id']}")
            if price_value not in (None, ''):
                _v27_set_product_price_level(self, product['id'], lvl['id'], to_float(price_value), to_int(min_value, 1), True, user['id'])
        if existing:
            updated += 1
        else:
            added += 1
    self.log('استيراد منتجات Excel', f'{source} | إضافة {added} | تحديث {updated} | تخطي {skipped}', user['id'])
    return {'added': added, 'updated': updated, 'skipped': skipped}


AppService.list_price_levels = _v27_list_price_levels
AppService.save_price_level = _v27_save_price_level
AppService.deactivate_price_level = _v27_deactivate_price_level
AppService.set_product_price_level = _v27_set_product_price_level
AppService.list_product_price_levels = _v27_list_product_price_levels
AppService.delete_product_price_level = _v27_delete_product_price_level
AppService.list_promotions = _v27_list_promotions
AppService.save_promotion = _v27_save_promotion
AppService.deactivate_promotion = _v27_deactivate_promotion
AppService.resolve_sale_line = _v27_resolve_sale_line
AppService.export_products_xlsx = _v27_export_products_xlsx
AppService.export_products_template_xlsx = _v27_export_products_template_xlsx
AppService.import_products_xlsx = _v27_import_products_xlsx

