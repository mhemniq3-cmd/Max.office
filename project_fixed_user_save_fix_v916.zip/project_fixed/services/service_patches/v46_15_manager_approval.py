"""Manager approval for sensitive sales.

Adds a safe override path for large discounts or below-cost sales:
- cashiers/sales staff remain blocked by default;
- a manager/owner can approve the single sale using username + password;
- the approval is recorded in activity_logs and attached to the sale note.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Any

from database import verify_password, now_text
from services.app_core import AppService
from services.error_logger import log_exception
from services.domain.persistence import sales_finance_writes as sfw

_ORIG_COMPLETE_SALE = AppService.complete_sale
_ORIG_GET_POLICY = sfw._get_discount_policy


def _user_value(user: Any, key: str, default: Any = None) -> Any:
    if not user:
        return default
    try:
        return user[key]
    except Exception:
        try:
            return user.get(key, default)
        except Exception:
            return default


def _is_manager_approver(service: AppService, user: Any) -> bool:
    if not user:
        return False
    try:
        if service.is_admin_user(user):
            return True
    except Exception:
        pass
    role = str(_user_value(user, "role", "") or "").strip().lower()
    if role in {"مدير", "مدير النظام", "مالك", "admin", "administrator"}:
        return True
    return bool(_user_value(user, "can_discount_limit", 0)) or bool(_user_value(user, "can_discount_below_cost", 0))


def _verify_manager_approval_v46_15(
    self: AppService,
    manager_username: str,
    manager_password: str,
    requesting_user_id: int | None = None,
    reason: str = "",
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    username = str(manager_username or "").strip()
    password = str(manager_password or "")
    if not username or not password:
        raise PermissionError("موافقة المدير تتطلب اسم المستخدم وكلمة المرور")
    manager = self.db.one("SELECT * FROM users WHERE username=? AND active=1", (username,))
    if not manager or not verify_password(password, manager["password_hash"]):
        try:
            self.log("فشل موافقة مدير", f"بيانات موافقة غير صحيحة للمستخدم: {username}", requesting_user_id, username=username)
        except Exception:
            pass
        raise PermissionError("بيانات المدير غير صحيحة")
    if not _is_manager_approver(self, manager):
        raise PermissionError("هذا المستخدم لا يملك صلاحية الموافقة على الخصومات الخاصة")
    if requesting_user_id and int(_user_value(manager, "id", 0) or 0) == int(requesting_user_id):
        # المدير يستطيع تنفيذ العملية مباشرة بحسابه، لكن لا نعتمد نفس المستخدم كموافقة خارجية.
        raise PermissionError("موافقة المدير يجب أن تكون من حساب مدير مختلف أو نفّذ العملية بحساب المدير")
    approval = {
        "approved": True,
        "manager_id": int(manager["id"]),
        "manager_username": str(manager["username"]),
        "manager_role": str(_user_value(manager, "role", "")),
        "requesting_user_id": int(requesting_user_id) if requesting_user_id else None,
        "reason": str(reason or "موافقة مدير على خصم خاص").strip(),
        "details": details or {},
        "approved_at": now_text(),
    }
    return approval


def _get_discount_policy_v46_15(service: Any, user_id: int | None) -> dict[str, Any]:
    policy = _ORIG_GET_POLICY(service, user_id)
    ctx = getattr(service, "_manager_sale_approval_context_v46_15", None)
    if isinstance(ctx, dict) and ctx.get("approved"):
        ctx_user = ctx.get("requesting_user_id")
        if not ctx_user or not user_id or int(ctx_user) == int(user_id):
            policy = dict(policy)
            policy["can_discount"] = True
            policy["can_discount_limit"] = True
            policy["max_discount_percent"] = Decimal("100")
            policy["can_discount_below_cost"] = True
            policy["manager_approved"] = True
            policy["manager_approval"] = ctx
    return policy


def _approval_note(approval: dict[str, Any]) -> str:
    manager = approval.get("manager_username") or approval.get("manager_id") or "مدير"
    reason = approval.get("reason") or "موافقة مدير"
    return f"موافقة مدير: {manager} - السبب: {reason} - الوقت: {approval.get('approved_at','')}"


def _complete_sale_v46_15(self: AppService, *args: Any, **kwargs: Any) -> Any:
    approval_payload = kwargs.pop("manager_approval", None)
    if approval_payload is None and len(args) >= 9 and isinstance(args[8], dict):
        # Optional positional compatibility for external callers.
        approval_payload = args[8]
        args = tuple(args[:8])

    requesting_user_id = kwargs.get("user_id")
    if requesting_user_id is None and len(args) >= 7:
        requesting_user_id = args[6]

    note_index = 5
    original_note = kwargs.get("note") if "note" in kwargs else (args[note_index] if len(args) > note_index else "")

    approval = None
    if approval_payload:
        if not isinstance(approval_payload, dict):
            raise ValueError("بيانات موافقة المدير غير صحيحة")
        approval = self.verify_manager_approval(
            approval_payload.get("username") or approval_payload.get("manager_username") or "",
            approval_payload.get("password") or approval_payload.get("manager_password") or "",
            requesting_user_id,
            approval_payload.get("reason") or "موافقة على خصم خاص / أقل من التكلفة",
            approval_payload.get("details") if isinstance(approval_payload.get("details"), dict) else {},
        )
        setattr(self, "_manager_sale_approval_context_v46_15", approval)
        note_with_approval = (str(original_note or "").strip() + "\n" + _approval_note(approval)).strip()
        if "note" in kwargs:
            kwargs["note"] = note_with_approval
        elif len(args) > note_index:
            temp = list(args)
            temp[note_index] = note_with_approval
            args = tuple(temp)
        else:
            kwargs["note"] = note_with_approval

    try:
        result = _ORIG_COMPLETE_SALE(self, *args, **kwargs)
        if approval:
            try:
                self.log(
                    "موافقة مدير على بيع حساس",
                    f"الفاتورة: {result} | المدير: {approval['manager_username']} | السبب: {approval['reason']}",
                    approval.get("requesting_user_id"),
                )
            except Exception as exc:
                log_exception(exc)
        return result
    finally:
        if approval:
            try:
                delattr(self, "_manager_sale_approval_context_v46_15")
            except Exception:
                setattr(self, "_manager_sale_approval_context_v46_15", None)


AppService.verify_manager_approval = _verify_manager_approval_v46_15
AppService.complete_sale = _complete_sale_v46_15
sfw._get_discount_policy = _get_discount_policy_v46_15
