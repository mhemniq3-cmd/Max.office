# V44: clean accounting release patch.
# - deterministic accounting math: discount -> taxes -> total, no negative values
# - transaction-safe sales save and stock update
# - two separated taxes
# - credit-limit and debt-payment guards
# - extra product/customer fields and simple customer statement

from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP, getcontext
from pathlib import Path
import html

from database import Database, DB_FILE, now_text, to_float, to_int, money
from services.app_core import AppService
from services.core_common import invoice_no, receipt_no

getcontext().prec = 28


def _D(value=0) -> Decimal:
    try:
        return Decimal(str(value or 0))
    except Exception:
        return Decimal('0')


def _money_round(value) -> float:
    return float(_D(value).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))


def _clamp0(value) -> Decimal:
    d = _D(value)
    return d if d > 0 else Decimal('0')


_orig_db_init_v44 = Database.__init__


def _db_init_v44(self, path: Path | str = DB_FILE):
    _orig_db_init_v44(self, path)
    for table, column, sql in [
        ('products', 'customs_no', 'TEXT'),
        ('products', 'country_origin', 'TEXT'),
        ('products', 'expiry_date', 'TEXT'),
        ('customers', 'credit_limit', 'REAL NOT NULL DEFAULT 0'),
        ('customers', 'due_days', 'INTEGER NOT NULL DEFAULT 0'),
        ('sales', 'vat_tax_amount', 'REAL NOT NULL DEFAULT 0'),
        ('sales', 'municipal_tax_amount', 'REAL NOT NULL DEFAULT 0'),
        ('sales', 'vat_tax_percent', 'REAL NOT NULL DEFAULT 0'),
        ('sales', 'municipal_tax_percent', 'REAL NOT NULL DEFAULT 0'),
        ('sale_items', 'net_line_total', 'REAL NOT NULL DEFAULT 0'),
        ('sale_items', 'tax_share', 'REAL NOT NULL DEFAULT 0'),
        ('sale_items', 'price_level_name', 'TEXT'),
        ('sale_items', 'promotion_name', 'TEXT'),
        ('sale_items', 'promotion_discount_amount', 'REAL NOT NULL DEFAULT 0'),
        ('sale_items', 'free_quantity', 'INTEGER NOT NULL DEFAULT 0'),
    ]:
        try:
            self.add_column_if_missing(table, column, sql)
        except Exception:
            pass
    for key, value in {
        'vat_tax_percent': '0',
        'municipal_tax_percent': '0',
        'rounding_mode': 'end_only',
        'allow_negative_totals': '0',
    }.items():
        self.conn.execute('INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)', (key, value))
    # Add the requested half-wholesale price level without disturbing existing prices.
    try:
        self.conn.execute(
            '''INSERT OR IGNORE INTO price_levels
               (name, description, auto_apply, is_default, active, sort_order, created_at)
               VALUES (?, ?, 1, 0, 1, 20, ?)''',
            ('نصف جملة', 'سعر متوسط بين المفرد والجملة', now_text())
        )
    except Exception:
        pass
    self.conn.commit()


Database.__init__ = _db_init_v44


def _customer_balance(self: AppService, customer_id: int | None) -> float:
    if not customer_id:
        return 0.0
    row = self.db.one('''
        WITH credit AS (
            SELECT customer_id, SUM(CASE WHEN total < 0 THEN 0 ELSE total END) amount
            FROM sales WHERE payment_method='آجل' AND status='completed' GROUP BY customer_id
        ), returned AS (
            SELECT s.customer_id, SUM(CASE WHEN r.amount < 0 THEN 0 ELSE r.amount END) amount
            FROM returns r JOIN sales s ON s.id=r.sale_id GROUP BY s.customer_id
        ), payments AS (
            SELECT customer_id, SUM(CASE WHEN amount < 0 THEN 0 ELSE amount END) amount FROM customer_payments GROUP BY customer_id
        )
        SELECT COALESCE(credit.amount,0)-COALESCE(returned.amount,0)-COALESCE(payments.amount,0) balance
        FROM customers c
        LEFT JOIN credit ON credit.customer_id=c.id
        LEFT JOIN returned ON returned.customer_id=c.id
        LEFT JOIN payments ON payments.customer_id=c.id
        WHERE c.id=?
    ''', (int(customer_id),))
    return max(float(row['balance'] or 0) if row else 0.0, 0.0)


def _secure_discount(subtotal: Decimal, discount_value, discount_type: str) -> Decimal:
    value = _clamp0(discount_value)
    if discount_type == 'percent':
        if value > 100:
            raise ValueError('نسبة الخصم لا يمكن أن تكون أكبر من 100%')
        discount = subtotal * value / Decimal('100')
    else:
        discount = value
    if discount > subtotal:
        raise ValueError(f'قيمة الخصم لا يمكن أن تكون أكبر من إجمالي الفاتورة. إجمالي الفاتورة: {money(float(subtotal))}')
    if subtotal > 0 and discount >= subtotal:
        raise ValueError('الخصم لا يمكن أن يساوي أو يتجاوز قيمة الفاتورة')
    return _clamp0(discount)


def _tax_settings(self: AppService):
    settings = self.get_settings()
    vat = _clamp0(settings.get('vat_tax_percent') or settings.get('tax_percent') or 0)
    municipal = _clamp0(settings.get('municipal_tax_percent') or 0)
    return vat, municipal


_orig_complete_sale_v44 = AppService.complete_sale


def _complete_sale_v44(self: AppService, cart: list[dict], employee_id: int, customer_id: int | None, payment_method: str, discount_amount: float = 0, note: str = '', user_id: int | None = None, discount_type: str = 'amount') -> str:
    user = self.require_any_permission(('can_sales', 'can_touch_pos'), user_id, 'إتمام البيع')
    user_id = user['id']
    if not cart:
        raise ValueError('السلة فارغة')
    if not employee_id:
        raise ValueError('اختر الموظف الذي يستحق العمولة')
    employee = self.db.one('SELECT id FROM employees WHERE id=? AND active=1', (int(employee_id),))
    if not employee:
        raise ValueError('الموظف المختار غير موجود أو معطل')

    # Secure line values from the database-friendly cart values without trusting negative UI data.
    safe_lines: list[dict] = []
    requested: dict[int, int] = {}
    for raw in cart:
        pid = int(raw.get('product_id') or 0)
        qty = int(raw.get('quantity') or 0)
        if pid <= 0 or qty <= 0:
            raise ValueError('بيانات المنتج أو الكمية غير صحيحة')
        product = self.db.one('SELECT * FROM products WHERE id=? AND active=1', (pid,))
        if not product:
            raise ValueError('منتج البيع غير موجود أو معطل')
        requested[pid] = requested.get(pid, 0) + qty
        if int(product['quantity'] or 0) < requested[pid]:
            raise ValueError(f"المخزون غير كاف للمنتج: {product['name']}")
        unit_price = _clamp0(raw.get('unit_price', product['sale_price']))
        cost_price = _clamp0(raw.get('cost_price', product['cost_price']))
        line_total = unit_price * Decimal(qty)
        safe_lines.append({
            'product_id': pid,
            'product_name': str(raw.get('product_name') or raw.get('name') or product['name']),
            'quantity': qty,
            'unit_price': unit_price,
            'cost_price': cost_price,
            'line_total': line_total,
            'commission_percent': _clamp0(raw.get('commission_percent') or product['commission_percent']),
            'price_level_id': raw.get('price_level_id'),
            'price_level_name': str(raw.get('price_level_name') or ''),
            'promotion_id': raw.get('promotion_id'),
            'promotion_name': str(raw.get('promotion_name') or ''),
            'promotion_discount_amount': _clamp0(raw.get('promotion_discount_amount') or 0),
            'free_quantity': max(int(raw.get('free_quantity') or 0), 0),
        })

    subtotal = sum((line['line_total'] for line in safe_lines), Decimal('0'))
    discount = _secure_discount(subtotal, discount_amount, discount_type)
    taxable_base = _clamp0(subtotal - discount)
    vat_percent, municipal_percent = _tax_settings(self)
    vat_tax = taxable_base * vat_percent / Decimal('100')
    municipal_tax = taxable_base * municipal_percent / Decimal('100')
    total = _clamp0(taxable_base + vat_tax + municipal_tax)

    # Credit-limit guard uses the final total after discount and taxes.
    if payment_method == 'آجل' and customer_id:
        cust = self.db.one('SELECT credit_limit FROM customers WHERE id=? AND active=1', (int(customer_id),))
        if not cust:
            raise ValueError('الزبون غير موجود أو معطل')
        limit = float(cust['credit_limit'] or 0)
        if limit > 0 and _customer_balance(self, int(customer_id)) + float(total) > limit + 0.0001:
            raise ValueError(f'تجاوز العميل الحد الائتماني المسموح. الحد: {money(limit)}')

    commission = Decimal('0')
    profit = Decimal('0')
    inv = invoice_no()
    now = now_text()
    with self.db.conn:
        cur = self.db.conn.execute('''
            INSERT INTO sales
            (invoice_no, user_id, employee_id, customer_id, subtotal, discount_amount, total,
             total_commission, total_profit, payment_method, discount_type, tax_amount,
             vat_tax_amount, municipal_tax_amount, vat_tax_percent, municipal_tax_percent, note, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (inv, user_id, employee_id, customer_id, _money_round(subtotal), _money_round(discount), _money_round(total), 0, 0, payment_method, discount_type, _money_round(vat_tax + municipal_tax), _money_round(vat_tax), _money_round(municipal_tax), _money_round(vat_percent), _money_round(municipal_percent), str(note or '').strip(), now))
        sale_id = cur.lastrowid
        for line in safe_lines:
            line_discount = (discount * line['line_total'] / subtotal) if subtotal else Decimal('0')
            net_line = _clamp0(line['line_total'] - line_discount)
            tax_share = ((vat_tax + municipal_tax) * net_line / taxable_base) if taxable_base else Decimal('0')
            item_comm = net_line * line['commission_percent'] / Decimal('100')
            # الربح الصحيح = صافي السطر (بعد الخصم) ناقص التكلفة الإجمالية
            item_profit = net_line - Decimal(line['quantity']) * line['cost_price']
            commission += item_comm
            profit += item_profit
            self.db.conn.execute('''
                INSERT INTO sale_items
                (sale_id, product_id, product_name, quantity, cost_price, unit_price, line_total,
                 commission_percent, commission_amount, profit_amount, price_level_id, price_level_name,
                 promotion_id, promotion_name, original_unit_price, promotion_discount_amount,
                 free_quantity, net_line_total, tax_share)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (sale_id, line['product_id'], line['product_name'], line['quantity'], _money_round(line['cost_price']), _money_round(line['unit_price']), _money_round(line['line_total']), _money_round(line['commission_percent']), _money_round(item_comm), _money_round(item_profit), line['price_level_id'], line['price_level_name'], line['promotion_id'], line['promotion_name'], _money_round(line['unit_price']), _money_round(line['promotion_discount_amount']), line['free_quantity'], _money_round(net_line), _money_round(tax_share)))
            # تحديث ذري آمن يمنع المخزون السالب حتى مع الطلبات المتزامنة
            _upd = self.db.conn.execute(
                'UPDATE products SET quantity = quantity - ?, last_sale_at=? WHERE id=? AND quantity >= ?',
                (line['quantity'], now, line['product_id'], line['quantity'])
            )
            if _upd.rowcount == 0:
                raise ValueError(f"المخزون غير كافٍ للمنتج: {line['product_name']}")
            oldq = int(self.db.conn.execute('SELECT quantity FROM products WHERE id=?', (line['product_id'],)).fetchone()['quantity']) + line['quantity']
            newq = oldq - line['quantity']
            self.db.conn.execute('''INSERT INTO inventory_movements (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (line['product_id'], 'بيع', -line['quantity'], oldq, newq, 'sale', inv, '', user_id, now))
        self.db.conn.execute('UPDATE sales SET total_commission=?, total_profit=? WHERE id=?', (_money_round(commission), _money_round(profit), sale_id))
    self.log('بيع', inv, user_id)
    return inv


def _add_payment_v44(self: AppService, customer_id: int, amount: float, note: str = '') -> int:
    self.require_permission('can_customers', action='تسجيل دفعات الزبائن')
    amount = float(amount or 0)
    if amount <= 0:
        raise ValueError('مبلغ الدفعة يجب أن يكون أكبر من صفر')
    bal = _customer_balance(self, int(customer_id))
    if bal <= 0:
        raise ValueError('لا يوجد دين على هذا الزبون')
    if amount > bal + 0.0001:
        raise ValueError(f'لا يمكن دفع مبلغ أكبر من الدين الحالي. الدين الحالي: {money(bal)}')
    receipt = receipt_no()
    cur = self.db.execute('INSERT INTO customer_payments (customer_id, amount, receipt_no, note, created_at) VALUES (?, ?, ?, ?, ?)', (int(customer_id), _money_round(amount), receipt, str(note or '').strip(), now_text()))
    self.log('تسجيل دفعة زبون', f'{customer_id} - {amount:,.0f}')
    return cur.lastrowid


def _save_product_v44(self: AppService, data: dict, product_id: int | None = None) -> None:
    # Delegate existing validation/save, then update optional commercial fields.
    original_save_product(self, data, product_id)
    name = str(data.get('name') or '').strip()
    row = self.db.one('SELECT id FROM products WHERE id=?', (product_id,)) if product_id else self.db.one('SELECT id FROM products WHERE name=? ORDER BY id DESC LIMIT 1', (name,))
    if row:
        self.db.execute('UPDATE products SET expiry_date=?, customs_no=?, country_origin=? WHERE id=?', (
            str(data.get('expiry_date') or '').strip() or None,
            str(data.get('customs_no') or data.get('customs_number') or '').strip(),
            str(data.get('country_origin') or data.get('origin_country') or '').strip(),
            row['id'],
        ))


def _customer_statement_detailed(self: AppService, customer_id: int):
    self.require_any_permission(('can_customers', 'can_reports', 'can_tools'), action='كشف حساب زبون')
    rows = []
    for sale in self.db.all('SELECT invoice_no ref, created_at, CASE WHEN total < 0 THEN 0 ELSE total END amount, payment_method note FROM sales WHERE customer_id=? ORDER BY created_at LIMIT 2000', (int(customer_id),)):
        rows.append(dict(kind='بيع', ref=sale['ref'], created_at=sale['created_at'], debit=sale['amount'] if sale['note'] == 'آجل' else 0, credit=0, note=sale['note']))
    for ret in self.db.all('''SELECT r.return_no ref, r.created_at, r.amount FROM returns r JOIN sales s ON s.id=r.sale_id WHERE s.customer_id=? ORDER BY r.created_at LIMIT 2000''', (int(customer_id),)):
        rows.append(dict(kind='مرتجع', ref=ret['ref'], created_at=ret['created_at'], debit=0, credit=ret['amount'], note='مرتجع'))
    for pay in self.db.all('SELECT COALESCE(receipt_no,id) ref, created_at, amount, note FROM customer_payments WHERE customer_id=? ORDER BY created_at LIMIT 2000', (int(customer_id),)):
        rows.append(dict(kind='دفعة', ref=str(pay['ref']), created_at=pay['created_at'], debit=0, credit=pay['amount'], note=pay['note'] or 'دفعة'))
    rows = sorted(rows, key=lambda x: x['created_at'])
    balance = 0.0
    out = []
    for r in rows:
        balance = max(balance + float(r['debit'] or 0) - float(r['credit'] or 0), 0.0)
        rr = dict(r)
        rr['balance'] = balance
        out.append(rr)
    return out


def _smart_alerts_v44(self: AppService):
    alerts = []
    for row in self.db.all('SELECT id,name,quantity,min_quantity FROM products WHERE active=1 AND quantity<=min_quantity ORDER BY quantity ASC LIMIT 20'):
        alerts.append({'type': 'low_stock', 'title': 'كمية منخفضة', 'message': f"{row['name']} | الكمية: {row['quantity']} | الحد: {row['min_quantity']}"})
    for row in self.db.all("SELECT id,name,expiry_date FROM products WHERE active=1 AND expiry_date IS NOT NULL AND TRIM(expiry_date)<>'' AND date(expiry_date) <= date('now','+30 day') ORDER BY expiry_date LIMIT 20"):
        alerts.append({'type': 'expiry', 'title': 'صلاحية قريبة/منتهية', 'message': f"{row['name']} | تاريخ الصلاحية: {row['expiry_date']}"})
    for row in self.debt_rows():
        if float(row['balance'] or 0) > 0:
            alerts.append({'type': 'debt', 'title': 'دين يحتاج متابعة', 'message': f"{row['name']} | الرصيد: {money(row['balance'])}"})
    return alerts


def _print_invoice_html_v44(self: AppService, sale_id: int):
    sale = self.db.one('''SELECT s.*, e.name employee, COALESCE(c.name,'زبون عام') customer, COALESCE(NULLIF(u.full_name,''), u.username, '-') user_name FROM sales s JOIN employees e ON e.id=s.employee_id LEFT JOIN customers c ON c.id=s.customer_id LEFT JOIN users u ON u.id=s.user_id WHERE s.id=?''', (int(sale_id),))
    if not sale:
        raise ValueError('الفاتورة غير موجودة')
    items = self.db.all('SELECT * FROM sale_items WHERE sale_id=? ORDER BY id', (int(sale_id),))
    st = self.get_settings()
    rows = ''
    for i in items:
        note = []
        if 'price_level_name' in i.keys() and i['price_level_name']:
            note.append(str(i['price_level_name']))
        if 'promotion_name' in i.keys() and i['promotion_name']:
            note.append(str(i['promotion_name']))
        if 'free_quantity' in i.keys() and i['free_quantity']:
            note.append(f"مدفوع: {int(i['quantity'])-int(i['free_quantity'])} | مجاني: {int(i['free_quantity'])}")
        rows += f"<tr><td>{html.escape(i['product_name'])}<br><small>{html.escape(' | '.join(note))}</small></td><td>{i['quantity']}</td><td>{money(i['unit_price'])}</td><td>{money(i['line_total'])}</td></tr>"
    tax_lines = f"<div>ضريبة القيمة المضافة: {money(sale['vat_tax_amount'] if 'vat_tax_amount' in sale.keys() else 0)}</div><div>الضريبة البلدية/الإضافية: {money(sale['municipal_tax_amount'] if 'municipal_tax_amount' in sale.keys() else 0)}</div>"
    html_body = f"""<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'><style>
    body{{font-family:Tahoma,Arial;margin:16px;color:#111}} table{{width:100%;border-collapse:collapse}} th,td{{border:1px solid #ddd;padding:7px;text-align:center}} .head{{text-align:center}} .total{{font-size:20px;font-weight:900}} small{{color:#666}}
    @media print{{body{{width:80mm;margin:0 auto;font-size:12px}}}}
    </style></head><body><div class='head'><h2>{html.escape(st.get('company_name','نظام ماكس للمبيعات'))}</h2><div>{html.escape(st.get('company_phone',''))}</div></div>
    <h3>فاتورة بيع: {html.escape(sale['invoice_no'])}</h3><p>التاريخ: {sale['created_at']}<br>الكاشير: {html.escape(sale['user_name'])}<br>الزبون: {html.escape(sale['customer'])}<br>طريقة الدفع: {html.escape(sale['payment_method'])}</p>
    <table><tr><th>المادة</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr>{rows}</table>
    <p>الإجمالي قبل الخصم: {money(sale['subtotal'])}<br>الخصم: {money(sale['discount_amount'])}</p>{tax_lines}<p class='total'>الصافي: {money(sale['total'])}</p><p>{html.escape(st.get('invoice_footer','شكراً لتعاملكم معنا'))}</p><script>window.print()</script></body></html>"""
    out = Path('exports') / f"invoice_{sale['invoice_no']}_{now_text().replace(':','').replace(' ','_')}.html"
    out.parent.mkdir(exist_ok=True)
    out.write_text(html_body, encoding='utf-8')
    return out


# Preserve original save product so optional fields can be layered on top.
original_save_product = AppService.save_product

# AppService.complete_sale = _complete_sale_v44  # معطّل: يُلغَى بواسطة stability_cleanup._complete_sale_v4517415 المُحسَّن
AppService.add_payment = _add_payment_v44
AppService.save_product = _save_product_v44
AppService.customer_statement = _customer_statement_detailed
AppService.customer_statement_detailed = _customer_statement_detailed
AppService.smart_alerts = _smart_alerts_v44
AppService.customer_balance = _customer_balance
AppService.print_invoice_html = _print_invoice_html_v44

# Simplified user-facing roles while preserving fine-grained internal columns.
def _roles_v44(self: AppService) -> list[str]:
    return ['مدير', 'كاشير', 'مستخدم']


def _role_permissions_v44(self: AppService, role: str) -> dict[str, int]:
    base = {k: 0 for k in [
        'can_dashboard','can_sales','can_products','can_customers','can_returns','can_reports','can_users','can_tools',
        'can_product_add','can_product_edit','can_product_delete','can_view_cost','can_view_profit','can_return_full','can_discount','can_print','can_backup','can_restore','can_settings','can_inventory','can_suppliers','can_purchases','can_touch_pos','can_price_edit','can_quantity_edit','can_discount_limit','can_goals','can_audit',
        'can_reprint_invoice','can_cancel_invoice','can_receive_debt_payment','can_manage_promotions','can_manage_offers','can_view_activity_logs'
    ]}
    r = str(role or '').strip()
    if r == 'مدير':
        return {k: 1 for k in base}
    if r == 'كاشير':
        base.update(can_dashboard=1, can_sales=1, can_touch_pos=1, can_customers=1, can_discount=1, can_print=1)
        return base
    # مستخدم: قراءة محدودة وتقارير فقط بدون أرقام حساسة.
    base.update(can_dashboard=1, can_reports=1, can_products=1, can_customers=1)
    return base

AppService.roles = _roles_v44
AppService.role_permissions = _role_permissions_v44
