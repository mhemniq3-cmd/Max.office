from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *

# =========================
# V11 Safety Core additions
# =========================
from datetime import timedelta


def _v11_doc(prefix: str) -> str:
    # Human-friendly, sortable, and practically unique without needing an opened DB connection.
    return prefix + '-' + datetime.now().strftime('%Y%m%d-%H%M%S%f')[:-3]

# Replace document number functions used by existing methods.
def invoice_no() -> str:  # type: ignore[no-redef]
    return _v11_doc('INV')

def return_no() -> str:  # type: ignore[no-redef]
    return _v11_doc('RET')

def receipt_no() -> str:  # type: ignore[no-redef]
    return _v11_doc('PAY')

def purchase_no() -> str:  # type: ignore[no-redef]
    return _v11_doc('PUR')


def _v11_user(service: AppService, user_id: int | None):
    if not user_id:
        return service.current_user() if hasattr(service, 'current_user') else None
    return service.db.one('SELECT * FROM users WHERE id=?', (user_id,))


def _v11_is_admin(user) -> bool:
    return bool(user and (user['role'] == 'مدير' or user['username'] == 'admin' or user['can_users']))


def _v11_day_is_closed(service: AppService, text_date: str) -> bool:
    d = (text_date or now_text())[:10]
    row = service.db.one('SELECT id FROM day_closings WHERE close_date=?', (d,))
    return bool(row)


def _v11_require_open_day(service: AppService, user_id: int | None, text_date: str | None = None, operation: str = 'العملية') -> None:
    user = _v11_user(service, user_id)
    if _v11_day_is_closed(service, text_date or now_text()) and not _v11_is_admin(user):
        raise ValueError(f'لا يمكن تنفيذ {operation} لأن اليوم المحاسبي مغلق. يحتاج الأمر صلاحية مدير.')


def _v11_discount_amount(subtotal: float, discount_value: float, discount_type: str = 'amount') -> float:
    subtotal = float(subtotal or 0)
    val = max(float(discount_value or 0), 0.0)
    if subtotal <= 0:
        if val > 0:
            raise ValueError('لا يمكن إضافة خصم على فاتورة فارغة')
        return 0.0
    if discount_type == 'percent':
        if val >= 100:
            raise ValueError('نسبة الخصم لا يمكن أن تساوي أو تتجاوز 100%')
        return subtotal * val / 100
    if val >= subtotal:
        raise ValueError(f'قيمة الخصم لا يمكن أن تساوي أو تتجاوز إجمالي الفاتورة. إجمالي الفاتورة: {money(subtotal)}')
    return val


def _v11_check_discount_permission(service: AppService, user_id: int | None, subtotal: float, discount_amount: float) -> None:
    if discount_amount <= 0:
        return
    user = _v11_user(service, user_id)
    if user and not _v11_is_admin(user) and not bool(user['can_discount']):
        raise ValueError('لا تملك صلاحية إضافة خصم')
    settings = service.get_settings()
    ratio = (float(discount_amount) / float(subtotal) * 100) if subtotal else 0.0
    role = user['role'] if user else 'مدير'
    limit = 100.0
    if role == 'كاشير':
        limit = to_float(settings.get('max_discount_cashier_percent'), 5)
    elif role == 'موظف مبيعات':
        limit = to_float(settings.get('max_discount_sales_percent'), 10)
    if ratio > limit and user and not bool(user['can_discount_limit']):
        raise ValueError(f'الخصم {ratio:.1f}% أكبر من الحد المسموح لدورك ({limit:.1f}%). يحتاج موافقة مدير.')


def _v11_validate_cart(service: AppService, cart: list[dict]) -> tuple[float, list[str]]:
    errors: list[str] = []
    if not cart:
        errors.append('السلة فارغة')
        return 0.0, errors
    subtotal = 0.0
    seen = set()
    for item in cart:
        pid = int(item.get('product_id') or 0)
        qty = int(item.get('quantity') or 0)
        price = float(item.get('unit_price') or 0)
        if pid <= 0:
            errors.append('يوجد منتج غير معروف داخل السلة')
            continue
        if qty <= 0:
            errors.append(f"كمية غير صحيحة للمنتج: {item.get('product_name','')}")
        if price < 0:
            errors.append(f"سعر بيع سالب للمنتج: {item.get('product_name','')}")
        product = service.db.one('SELECT name, quantity, active FROM products WHERE id=?', (pid,))
        if not product or not product['active']:
            errors.append(f"المنتج غير موجود أو معطل: {item.get('product_name','')}")
        elif int(product['quantity']) < qty:
            errors.append(f"المخزون غير كاف للمنتج {product['name']}: المتوفر {product['quantity']} والمطلوب {qty}")
        subtotal += qty * price
        seen.add(pid)
    return subtotal, errors


_orig_authenticate_v11 = AppService.authenticate

def _authenticate_v11(self: AppService, username: str, password: str):
    username = (username or '').strip()
    settings = self.get_settings()
    max_attempts = max(to_int(settings.get('login_max_attempts'), 5), 1)
    lock_minutes = max(to_int(settings.get('login_lock_minutes'), 10), 1)
    attempt = self.db.one('SELECT * FROM login_attempts WHERE username=?', (username,)) if username else None
    if attempt and attempt['locked_until']:
        try:
            locked_until = datetime.strptime(attempt['locked_until'], '%Y-%m-%d %H:%M:%S')
            if datetime.now() < locked_until:
                self.log('منع دخول مؤقت', f'الحساب {username} مقفل حتى {attempt["locked_until"]}', username=username)
                return None
        except Exception as exc:
            log_exception(exc)
    user = _orig_authenticate_v11(self, username, password)
    if user:
        self.db.execute('INSERT OR REPLACE INTO login_attempts (username, failed_count, locked_until, last_failed_at) VALUES (?, 0, NULL, NULL)', (username,))
        # تنظيف السجلات القديمة (أكثر من 30 يوماً) لمنع تضخم الجدول
        try:
            self.db.execute(
                "DELETE FROM login_attempts WHERE last_failed_at < datetime('now', '-30 days') AND locked_until IS NULL",
                ()
            )
        except Exception:
            pass
        return user
    if username:
        failed = int(attempt['failed_count']) + 1 if attempt else 1
        locked_until = None
        if failed >= max_attempts:
            locked_until = (datetime.now() + timedelta(minutes=lock_minutes)).strftime('%Y-%m-%d %H:%M:%S')
            self.log('قفل حساب مؤقت', f'{username} حتى {locked_until}', username=username)
        self.db.execute('INSERT OR REPLACE INTO login_attempts (username, failed_count, locked_until, last_failed_at) VALUES (?, ?, ?, ?)', (username, failed, locked_until, now_text()))
    return None

AppService.authenticate = _authenticate_v11


_orig_complete_sale_v11 = AppService.complete_sale

def _complete_sale_v11(self: AppService, cart, employee_id, customer_id, payment_method, discount_amount=0, note='', user_id=None, discount_type='amount'):
    _v11_require_open_day(self, user_id, operation='البيع')
    subtotal, errors = _v11_validate_cart(self, cart)
    if errors:
        raise ValueError('\n'.join(errors))
    real_discount = _v11_discount_amount(subtotal, discount_amount, discount_type)
    _v11_check_discount_permission(self, user_id, subtotal, real_discount)
    if payment_method == 'آجل' and customer_id:
        customer = self.db.one('SELECT credit_limit FROM customers WHERE id=?', (customer_id,))
        if customer and float(customer['credit_limit'] or 0) > 0:
            current = 0.0
            for row in self.debt_rows():
                if int(row['id']) == int(customer_id):
                    current = float(row['balance'] or 0)
                    break
            tax_percent = to_float(self.get_settings().get('tax_percent', 0))
            expected_total = (subtotal - real_discount) * (1 + tax_percent / 100)
            if current + expected_total > float(customer['credit_limit']):
                raise ValueError('لا يمكن البيع آجل: الدين سيتجاوز حد الزبون الائتماني')
    return _orig_complete_sale_v11(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type)

AppService.complete_sale = _complete_sale_v11


_orig_suspend_sale_v11 = AppService.suspend_sale

def _suspend_sale_v11(self: AppService, cart, employee_id, customer_id, payment_method, discount_amount, note='', user_id=None):
    subtotal, errors = _v11_validate_cart(self, cart)
    if errors:
        raise ValueError('\n'.join(errors))
    real_discount = _v11_discount_amount(subtotal, discount_amount, 'amount')
    _v11_check_discount_permission(self, user_id, subtotal, real_discount)
    return _orig_suspend_sale_v11(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id)

AppService.suspend_sale = _suspend_sale_v11


_orig_return_item_v11 = AppService.return_item

def _return_item_v11(self: AppService, sale_item_id: int, quantity: int, reason: str = '', user_id: int | None = None, refund_method: str = 'نقدي'):
    if not (reason or '').strip():
        raise ValueError('سبب الإرجاع مطلوب')
    row = self.db.one('''SELECT s.created_at FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE si.id=?''', (sale_item_id,))
    if row:
        _v11_require_open_day(self, user_id, row['created_at'], 'إرجاع مادة من يوم مغلق')
    return _orig_return_item_v11(self, sale_item_id, quantity, reason, user_id, refund_method)

AppService.return_item = _return_item_v11


_orig_return_full_sale_v11 = AppService.return_full_sale

def _return_full_sale_v11(self: AppService, sale_id: int, reason: str = '', user_id: int | None = None, refund_method: str = 'نقدي'):
    user = _v11_user(self, user_id)
    if user and not _v11_is_admin(user) and not bool(user['can_return_full']):
        raise ValueError('لا تملك صلاحية إرجاع فاتورة كاملة')
    sale = self.db.one('SELECT created_at FROM sales WHERE id=?', (sale_id,))
    if sale:
        _v11_require_open_day(self, user_id, sale['created_at'], 'إرجاع فاتورة من يوم مغلق')
    return _orig_return_full_sale_v11(self, sale_id, reason, user_id, refund_method)

AppService.return_full_sale = _return_full_sale_v11


_orig_add_payment_v11 = AppService.add_payment

def _add_payment_v11(self: AppService, customer_id: int, amount: float, note: str = ''):
    if amount <= 0:
        raise ValueError('مبلغ الدفعة يجب أن يكون أكبر من صفر')
    balance = 0.0
    for row in self.debt_rows():
        if int(row['id']) == int(customer_id):
            balance = float(row['balance'] or 0)
            break
    if balance > 0 and float(amount) > balance:
        raise ValueError(f'مبلغ التسديد أكبر من دين الزبون. الدين الحالي: {money(balance)}')
    return _orig_add_payment_v11(self, customer_id, amount, note)

AppService.add_payment = _add_payment_v11


_orig_supplier_payment_v11 = AppService.add_supplier_payment

def _add_supplier_payment_v11(self: AppService, supplier_id: int, amount: float, note: str = '', user_id: int | None = None):
    if amount <= 0:
        raise ValueError('مبلغ الدفعة يجب أن يكون أكبر من صفر')
    balance = 0.0
    for row in self.supplier_debt_rows():
        if int(row['id']) == int(supplier_id):
            balance = float(row['balance'] or 0)
            break
    if balance > 0 and float(amount) > balance:
        raise ValueError(f'مبلغ التسديد أكبر من دين المورد. الدين الحالي: {money(balance)}')
    return _orig_supplier_payment_v11(self, supplier_id, amount, note, user_id)

AppService.add_supplier_payment = _add_supplier_payment_v11


_orig_create_purchase_v11 = AppService.create_purchase

def _create_purchase_v11(self: AppService, supplier_id: int, items: list[dict], paid_amount: float = 0, payment_method: str = 'نقدي', discount_amount: float = 0, note: str = '', user_id: int | None = None):
    _v11_require_open_day(self, user_id, operation='فاتورة شراء')
    if not items:
        raise ValueError('فاتورة الشراء فارغة')
    subtotal = 0.0
    for item in items:
        qty = int(item.get('quantity') or 0)
        cost = float(item.get('unit_cost') or 0)
        if qty <= 0:
            raise ValueError('كمية الشراء يجب أن تكون أكبر من صفر')
        if cost <= 0:
            raise ValueError('تكلفة الشراء يجب أن تكون أكبر من صفر')
        subtotal += qty * cost
    if float(discount_amount or 0) >= subtotal and subtotal > 0:
        raise ValueError('خصم الشراء لا يمكن أن يساوي أو يتجاوز قيمة الفاتورة')
    if float(paid_amount or 0) > subtotal - float(discount_amount or 0):
        raise ValueError('المبلغ المدفوع أكبر من صافي فاتورة الشراء')
    return _orig_create_purchase_v11(self, supplier_id, items, paid_amount, payment_method, discount_amount, note, user_id)

AppService.create_purchase = _create_purchase_v11


_orig_backup_database_v11 = AppService.backup_database

def _backup_database_v11(self: AppService) -> Path:
    path = _orig_backup_database_v11(self)
    try:
        keep = max(to_int(self.get_settings().get('max_backup_keep'), 7), 1)
        files = sorted(Path('backups').glob('max_sales_qt_backup_*.db'), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in files[keep:]:
            old.unlink(missing_ok=True)
    except Exception as exc:
        self.log('تنبيه نسخ احتياطي', f'تعذر حذف النسخ القديمة: {exc}')
    return path

AppService.backup_database = _backup_database_v11


def _daily_close_summary_v11(self: AppService, close_date: str | None = None) -> dict:
    d = (close_date or datetime.now().strftime('%Y-%m-%d'))[:10]
    sales = self.db.one("""SELECT COUNT(*) invoices, COALESCE(SUM(CASE WHEN payment_method='آجل' THEN 0 ELSE total END),0) cash_sales, COALESCE(SUM(CASE WHEN payment_method='آجل' THEN total ELSE 0 END),0) credit_sales, COALESCE(SUM(discount_amount),0) discounts, COALESCE(SUM(total_profit),0) profit FROM sales WHERE date(created_at)=date(?)""", (d,))
    rets = self.db.one("SELECT COALESCE(SUM(amount),0) amount FROM returns WHERE date(created_at)=date(?)", (d,))
    expected_cash = float(sales['cash_sales'] or 0) - float(rets['amount'] or 0)
    return dict(date=d, invoices=int(sales['invoices'] or 0), cash_sales=float(sales['cash_sales'] or 0), credit_sales=float(sales['credit_sales'] or 0), discounts=float(sales['discounts'] or 0), profit=float(sales['profit'] or 0), returns_amount=float(rets['amount'] or 0), expected_cash=expected_cash)

AppService.daily_close_summary = _daily_close_summary_v11


def _close_day_v11(self: AppService, close_date: str, counted_cash: float, note: str = '', user_id: int | None = None) -> None:
    d = (close_date or datetime.now().strftime('%Y-%m-%d'))[:10]
    if self.db.one('SELECT id FROM day_closings WHERE close_date=?', (d,)):
        raise ValueError('هذا اليوم مغلق مسبقاً')
    data = self.daily_close_summary(d)
    diff = float(counted_cash or 0) - data['expected_cash']
    self.db.execute('''INSERT INTO day_closings (close_date, user_id, cash_sales, credit_sales, returns_amount, discounts_amount, profit_amount, invoices_count, counted_cash, cash_difference, note, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (d, user_id, data['cash_sales'], data['credit_sales'], data['returns_amount'], data['discounts'], data['profit'], data['invoices'], counted_cash, diff, note.strip(), now_text()))
    self.log('إغلاق يومي', f'{d} | الصندوق المتوقع {money(data["expected_cash"])} | المعدود {money(counted_cash)} | الفرق {money(diff)}', user_id)

AppService.close_day = _close_day_v11


def _daily_closings_v11(self: AppService, limit: int = 100):
    return self.db.all('SELECT dc.*, COALESCE(NULLIF(u.full_name,\'\'), u.username, \'-\') user_name FROM day_closings dc LEFT JOIN users u ON u.id=dc.user_id ORDER BY close_date DESC LIMIT ?', (limit,))

AppService.daily_closings = _daily_closings_v11


def _system_health_check_v11(self: AppService) -> list[dict]:
    checks: list[dict] = []
    def add(level: str, title: str, details: str):
        checks.append({'level': level, 'title': title, 'details': details})
    c = self.db.one('SELECT COUNT(*) c FROM sale_items si LEFT JOIN sales s ON s.id=si.sale_id WHERE s.id IS NULL')['c']
    if c: add('خطير', 'مواد بيع بدون فاتورة', str(c))
    c = self.db.one('SELECT COUNT(*) c FROM sales s LEFT JOIN sale_items si ON si.sale_id=s.id WHERE si.id IS NULL')['c']
    if c: add('خطير', 'فواتير بدون مواد', str(c))
    c = self.db.one('SELECT COUNT(*) c FROM products WHERE quantity < 0')['c']
    if c: add('خطير', 'منتجات بكميات سالبة', str(c))
    c = self.db.one('SELECT COUNT(*) c FROM products WHERE active=1 AND (name IS NULL OR TRIM(name)=\'\' OR sale_price < 0 OR cost_price < 0)')['c']
    if c: add('خطير', 'منتجات ببيانات أو أسعار غير صحيحة', str(c))
    c = self.db.one('SELECT COUNT(*) c FROM (SELECT barcode FROM products WHERE barcode IS NOT NULL AND TRIM(barcode)<>\'\' GROUP BY barcode HAVING COUNT(*)>1)')['c']
    if c: add('خطير', 'باركودات مكررة', str(c))
    c = self.db.one('SELECT COUNT(*) c FROM sales WHERE discount_amount < 0 OR discount_amount >= subtotal AND subtotal > 0')['c']
    if c: add('خطير', 'فواتير بخصم غير منطقي', str(c))
    c = self.db.one('SELECT COUNT(*) c FROM customer_payments WHERE amount <= 0')['c']
    if c: add('متوسط', 'دفعات زبائن غير صحيحة', str(c))
    c = self.db.one('''SELECT COUNT(*) c FROM (SELECT si.id, si.quantity sold, COALESCE(SUM(r.quantity),0) returned FROM sale_items si LEFT JOIN returns r ON r.sale_item_id=si.id GROUP BY si.id HAVING returned > sold)''')['c']
    if c: add('خطير', 'مرتجعات أكبر من الكمية المباعة', str(c))
    c = self.db.one('SELECT COUNT(*) c FROM returns WHERE TRIM(COALESCE(reason,\'\'))=\'\'')['c']
    if c: add('منخفض', 'مرتجعات بدون سبب', str(c))
    low = self.db.one('SELECT COUNT(*) c FROM products WHERE active=1 AND quantity <= min_quantity')['c']
    if low: add('تنبيه', 'مواد وصلت حد التنبيه أو نفدت', str(low))
    if not checks:
        add('سليم', 'لم يتم العثور على أخطاء محاسبية أو تشغيلية ظاهرة', 'النظام اجتاز الفحص الأساسي')
    return checks

AppService.system_health_check = _system_health_check_v11

