from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})
import services.service_patches.v19_gdrive as _prev_v19_gdrive
globals().update({k: v for k, v in vars(_prev_v19_gdrive).items() if not k.startswith('__')})
import services.service_patches.v20_gdrive_settings as _prev_v20_gdrive_settings
globals().update({k: v for k, v in vars(_prev_v20_gdrive_settings).items() if not k.startswith('__')})
import services.service_patches.v21_backup as _prev_v21_backup
globals().update({k: v for k, v in vars(_prev_v21_backup).items() if not k.startswith('__')})
import services.service_patches.v22_gdrive_final as _prev_v22_gdrive_final
globals().update({k: v for k, v in vars(_prev_v22_gdrive_final).items() if not k.startswith('__')})
import services.service_patches.v23_business_tools as _prev_v23_business_tools
globals().update({k: v for k, v in vars(_prev_v23_business_tools).items() if not k.startswith('__')})
import services.service_patches.v24_smart_assistant as _prev_v24_smart_assistant
globals().update({k: v for k, v in vars(_prev_v24_smart_assistant).items() if not k.startswith('__')})
import services.service_patches.v25_readiness as _prev_v25_readiness
globals().update({k: v for k, v in vars(_prev_v25_readiness).items() if not k.startswith('__')})

# V25.1: barcode lookup keeps cost visible only for users with can_view_cost;
# sale screens still call it safely because cashiers do not have that permission.
def _v251_get_product_by_barcode(self: AppService, barcode: str):
    _v25_require_any(self, ('can_sales', 'can_touch_pos', 'can_products', 'can_purchases'), action='البحث بالباركود')
    barcode = (barcode or '').strip()
    if not barcode:
        return None
    row = self.db.one('SELECT * FROM products WHERE active=1 AND barcode=?', (barcode,))
    return _v25_sanitize_product(self, row, for_sale=False) if row else None

AppService.get_product_by_barcode = _v251_get_product_by_barcode

