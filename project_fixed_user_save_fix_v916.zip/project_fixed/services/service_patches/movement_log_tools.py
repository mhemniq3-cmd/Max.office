from __future__ import annotations

from typing import Any

from services.app_core import AppService
from services.core_common import now_text, log_exception

_ORIG_INIT = AppService.__init__
_ORIG_LOG = getattr(AppService, 'log', None)


def _table_exists(self: AppService, name: str) -> bool:
    try:
        return bool(self.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,)))
    except Exception:
        return False


def _ensure_movement_schema(self: AppService) -> None:
    self.db.conn.execute('''
        CREATE TABLE IF NOT EXISTS system_movements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_time TEXT NOT NULL,
            source TEXT NOT NULL DEFAULT 'system',
            username TEXT,
            user_id INTEGER,
            action TEXT NOT NULL,
            table_name TEXT,
            record_id TEXT,
            details TEXT,
            severity TEXT DEFAULT 'info'
        )
    ''')
    self.db.conn.execute('CREATE INDEX IF NOT EXISTS idx_system_movements_time ON system_movements(event_time)')
    self.db.conn.execute('CREATE INDEX IF NOT EXISTS idx_system_movements_action ON system_movements(action)')
    self.db.conn.execute('CREATE INDEX IF NOT EXISTS idx_system_movements_source ON system_movements(source)')

    # Lightweight DB-level triggers for critical tables. They complement AppService.log
    # and make the movement log catch changes even when an old code path forgets to log.
    watched = {
        'products': 'منتج',
        'customers': 'عميل',
        'sales': 'فاتورة بيع',
        'sale_items': 'سطر فاتورة',
        'inventory_movements': 'حركة مخزون',
        'coupons': 'قسيمة',
        'fraud_alerts': 'تنبيه احتيال',
        'audit_logs': 'سجل تدقيق',
        'payments': 'حركة مالية',
    }
    for table, label in watched.items():
        if not _table_exists(self, table):
            continue
        safe = ''.join(ch if ch.isalnum() else '_' for ch in table)
        try:
            self.db.conn.execute(f'''
                CREATE TRIGGER IF NOT EXISTS trg_sys_move_{safe}_insert
                AFTER INSERT ON {table}
                BEGIN
                    INSERT INTO system_movements(event_time, source, action, table_name, record_id, details, severity)
                    VALUES (datetime('now'), 'db_trigger', 'إضافة {label}', '{table}', CAST(NEW.id AS TEXT), 'تمت إضافة سجل في {table}', 'info');
                END;
            ''')
        except Exception as exc:
            log_exception(exc, f'v45.17.4.11 trigger insert {table}')
        try:
            self.db.conn.execute(f'''
                CREATE TRIGGER IF NOT EXISTS trg_sys_move_{safe}_update
                AFTER UPDATE ON {table}
                BEGIN
                    INSERT INTO system_movements(event_time, source, action, table_name, record_id, details, severity)
                    VALUES (datetime('now'), 'db_trigger', 'تعديل {label}', '{table}', CAST(NEW.id AS TEXT), 'تم تعديل سجل في {table}', 'info');
                END;
            ''')
        except Exception as exc:
            log_exception(exc, f'v45.17.4.11 trigger update {table}')
        try:
            self.db.conn.execute(f'''
                CREATE TRIGGER IF NOT EXISTS trg_sys_move_{safe}_delete
                AFTER DELETE ON {table}
                BEGIN
                    INSERT INTO system_movements(event_time, source, action, table_name, record_id, details, severity)
                    VALUES (datetime('now'), 'db_trigger', 'حذف {label}', '{table}', CAST(OLD.id AS TEXT), 'تم حذف سجل من {table}', 'warning');
                END;
            ''')
        except Exception as exc:
            log_exception(exc, f'v45.17.4.11 trigger delete {table}')
    self.db.conn.commit()


def _log_system_movement(self: AppService, action: str, details: str = '', user_id: int | None = None,
                         username: str = '', source: str = 'app', table_name: str = '', record_id: Any = None,
                         severity: str = 'info') -> None:
    try:
        _ensure_movement_schema(self)
        if user_id and not username:
            try:
                row = self.db.one('SELECT username FROM users WHERE id=?', (user_id,))
                username = row['username'] if row else ''
            except Exception:
                username = ''
        action = str(action or '').replace('\n', ' ').replace('\r', ' ')[:180]
        details = str(details or '').replace('\n', ' ').replace('\r', ' ')[:1200]
        username = str(username or '').replace('\n', ' ').replace('\r', ' ')[:120]
        self.db.conn.execute('''
            INSERT INTO system_movements(event_time, source, username, user_id, action, table_name, record_id, details, severity)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (now_text(), str(source or 'app')[:60], username, user_id, action, str(table_name or '')[:80], '' if record_id is None else str(record_id)[:80], details, str(severity or 'info')[:20]))
        self.db.conn.commit()
    except Exception as exc:
        log_exception(exc, 'v45.17.4.11 log system movement')


def _log(self: AppService, action: str, details: str = '', user_id: int | None = None, username: str = '') -> None:
    if _ORIG_LOG:
        _ORIG_LOG(self, action, details, user_id, username)
    _log_system_movement(self, action, details, user_id, username, 'activity_log')


def _safe_row(row: Any) -> dict[str, Any]:
    try:
        return dict(row)
    except Exception:
        return {}


def _append_rows(self: AppService, out: list[dict[str, Any]], table: str, sql: str, params: tuple = (), source: str = '') -> None:
    if not _table_exists(self, table):
        return
    try:
        for row in self.db.all(sql, params):
            r = _safe_row(row)
            r.setdefault('source', source or table)
            out.append(r)
    except Exception as exc:
        log_exception(exc, f'v45.17.4.11 list movements {table}')


def _list_system_movements(self: AppService, limit: int = 500, term: str = '', source: str = '') -> list[dict[str, Any]]:
    try:
        self.require_any_permission(('can_view_activity_logs', 'can_audit', 'can_users', 'can_tools'), action='عرض سجل الحركات')
    except Exception:
        # Keep compatibility for older roles that could open tools before this patch.
        pass
    _ensure_movement_schema(self)
    limit = max(1, min(int(limit or 500), 3000))
    term = str(term or '').strip()
    src_filter = str(source or '').strip()
    rows: list[dict[str, Any]] = []

    params: list[Any] = []
    where = []
    if term:
        like = f'%{term}%'
        where.append('(action LIKE ? OR details LIKE ? OR username LIKE ? OR table_name LIKE ? OR record_id LIKE ? OR source LIKE ?)')
        params.extend([like, like, like, like, like, like])
    if src_filter:
        where.append('source LIKE ?')
        params.append(f'%{src_filter}%')
    w = ('WHERE ' + ' AND '.join(where)) if where else ''
    for r in self.db.all(f'''SELECT id, event_time, source, username, user_id, action, table_name, record_id, details, severity
                              FROM system_movements {w}
                             ORDER BY id DESC LIMIT ?''', (*params, limit)):
        rows.append(_safe_row(r))

    # Backfill old historical sources so the movement log shows all existing events.
    remaining = max(0, limit - len(rows))
    if remaining:
        like_params = ()
        old_where = ''
        if term:
            like = f'%{term}%'
            old_where = 'WHERE action LIKE ? OR details LIKE ? OR username LIKE ?'
            like_params = (like, like, like)
        _append_rows(self, rows, 'activity_logs', f'''SELECT id, created_at AS event_time, 'activity_logs' AS source, username, user_id, action, '' AS table_name, '' AS record_id, details, 'info' AS severity FROM activity_logs {old_where} ORDER BY id DESC LIMIT ?''', (*like_params, remaining), 'activity_logs')

    remaining = max(0, limit - len(rows))
    if remaining:
        old_where = ''
        like_params = ()
        if term:
            like = f'%{term}%'
            old_where = 'WHERE action LIKE ? OR details LIKE ? OR username LIKE ? OR entity_type LIKE ? OR entity_id LIKE ?'
            like_params = (like, like, like, like, like)
        _append_rows(self, rows, 'audit_trail', f'''SELECT id, created_at AS event_time, 'audit_trail' AS source, username, user_id, action, entity_type AS table_name, entity_id AS record_id, details, 'info' AS severity FROM audit_trail {old_where} ORDER BY id DESC LIMIT ?''', (*like_params, remaining), 'audit_trail')

    remaining = max(0, limit - len(rows))
    if remaining:
        old_where = ''
        like_params = ()
        if term:
            like = f'%{term}%'
            old_where = 'WHERE action LIKE ? OR table_name LIKE ? OR reason LIKE ?'
            like_params = (like, like, like)
        _append_rows(self, rows, 'audit_logs', f'''SELECT id, timestamp AS event_time, 'audit_logs' AS source, '' AS username, user_id, action, table_name, CAST(record_id AS TEXT) AS record_id, reason AS details, 'info' AS severity FROM audit_logs {old_where} ORDER BY id DESC LIMIT ?''', (*like_params, remaining), 'audit_logs')

    remaining = max(0, limit - len(rows))
    if remaining:
        old_where = ''
        like_params = ()
        if term:
            like = f'%{term}%'
            old_where = 'WHERE movement_type LIKE ? OR note LIKE ? OR ref_no LIKE ?'
            like_params = (like, like, like)
        _append_rows(self, rows, 'inventory_movements', f'''SELECT id, created_at AS event_time, 'inventory_movements' AS source, '' AS username, user_id, movement_type AS action, 'products' AS table_name, CAST(product_id AS TEXT) AS record_id, note || ' ' || COALESCE(ref_no,'') AS details, 'info' AS severity FROM inventory_movements {old_where} ORDER BY id DESC LIMIT ?''', (*like_params, remaining), 'inventory_movements')

    remaining = max(0, limit - len(rows))
    if remaining:
        old_where = ''
        like_params = ()
        if term:
            like = f'%{term}%'
            old_where = 'WHERE alert_type LIKE ? OR details LIKE ? OR status LIKE ?'
            like_params = (like, like, like)
        _append_rows(self, rows, 'fraud_alerts', f'''SELECT id, created_at AS event_time, 'fraud_alerts' AS source, '' AS username, user_id, alert_type AS action, ref_type AS table_name, ref_no AS record_id, details, COALESCE(severity,'warning') AS severity FROM fraud_alerts {old_where} ORDER BY id DESC LIMIT ?''', (*like_params, remaining), 'fraud_alerts')

    # Normalize and sort. De-dup only identical source/id pairs.
    seen = set()
    normalized: list[dict[str, Any]] = []
    for r in rows:
        key = (r.get('source'), r.get('id'))
        if key in seen:
            continue
        seen.add(key)
        normalized.append({
            'id': r.get('id', ''),
            'event_time': r.get('event_time') or r.get('created_at') or r.get('timestamp') or '',
            'source': r.get('source') or '',
            'username': r.get('username') or '',
            'user_id': r.get('user_id') or '',
            'action': r.get('action') or '',
            'table_name': r.get('table_name') or '',
            'record_id': r.get('record_id') or '',
            'details': r.get('details') or '',
            'severity': r.get('severity') or 'info',
        })
    normalized.sort(key=lambda x: str(x.get('event_time') or ''), reverse=True)
    return normalized[:limit]


def _activity_logs_compat(self: AppService, limit: int = 300, term: str = '') -> list[dict[str, Any]]:
    return _list_system_movements(self, limit, term)


def _init(self: AppService, *args, **kwargs):
    _ORIG_INIT(self, *args, **kwargs)
    try:
        _ensure_movement_schema(self)
    except Exception as exc:
        log_exception(exc, 'v45.17.4.11 movement schema')


AppService.__init__ = _init
AppService.log = _log
AppService.log_system_movement = _log_system_movement
AppService.list_system_movements = _list_system_movements
AppService.list_activity_logs = _activity_logs_compat
