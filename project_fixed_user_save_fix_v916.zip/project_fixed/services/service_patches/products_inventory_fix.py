from __future__ import annotations

"""V45.13 product-page and inventory correctness fixes.

Keeps the restored v44 design, but fixes product-entry edge cases reported by
users:
- new products could be saved with quantity 0 and immediately appear only in
  low/out-of-stock alerts;
- product list refresh/search could hide low-stock products because every screen
  had its own assumptions;
- product financial fields accepted invalid values that later broke sale/profit
  calculations.
"""

from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from typing import Any

from services.app_core import AppService
from services.core_common import now_text
from services.error_logger import log_exception
from services.shared import validation, search


def _d(value: Any, default: str = '0') -> Decimal:
    try:
        text = str(value if value is not None else default).strip().replace(',', '')
        if not text:
            text = default
        return Decimal(text)
    except (InvalidOperation, ValueError, TypeError):
        return Decimal(default)


def _money(value: Any) -> Decimal:
    return _d(value).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


def _int(value: Any, default: int = 0) -> int:
    try:
        if value is None or str(value).strip() == '':
            return default
        return int(Decimal(str(value).strip()).to_integral_value(rounding=ROUND_HALF_UP))
    except Exception:
        return default


def _clean_product_payload(data: dict, *, is_new: bool) -> dict:
    barcode = validation.clean_text(data.get('barcode'), 80) or None
    name = validation.clean_text(data.get('name'), 180, required=True, field='اسم المنتج')
    category = validation.clean_text(data.get('category'), 120)
    cost = _money(data.get('cost_price'))
    price = _money(data.get('sale_price'))
    qty = _int(data.get('quantity'), 0)
    min_qty = _int(data.get('min_quantity'), 1)
    commission = _money(data.get('commission_percent'))

    if cost < 0:
        raise ValueError('سعر الشراء لا يمكن أن يكون سالباً')
    if price <= 0:
        raise ValueError('سعر البيع يجب أن يكون أكبر من صفر')
    if qty < 0:
        raise ValueError('كمية المنتج لا يمكن أن تكون سالبة')
    if is_new and qty <= 0:
        raise ValueError('لا يمكن إضافة مادة جديدة بكمية صفر. أدخل كمية افتتاحية أو أضفها لاحقاً من الجرد.')
    if min_qty < 0:
        raise ValueError('حد التنبيه لا يمكن أن يكون سالباً')
    if commission < 0 or commission > 100:
        raise ValueError('نسبة العمولة يجب أن تكون بين 0 و 100')

    # If the user leaves the alert limit as zero, keep it zero to mean: alert only
    # when the item is actually out of stock. Do not silently change stock math.
    return {
        'barcode': barcode,
        'name': name,
        'category': category,
        'cost_price': float(cost),
        'sale_price': float(price),
        'quantity': qty,
        'min_quantity': min_qty,
        'commission_percent': float(commission),
        'expiry_date': validation.clean_text(data.get('expiry_date'), 30) or None,
        'customs_no': validation.clean_text(data.get('customs_no') or data.get('customs_number'), 80),
        'country_origin': validation.clean_text(data.get('country_origin') or data.get('origin_country'), 80),
    }


def _v4513_save_product(self: AppService, data: dict, product_id: int | None = None) -> None:
    is_new = not bool(product_id)
    user = self.require_permission('can_product_edit' if product_id else 'can_product_add', action='حفظ المنتجات')
    payload = _clean_product_payload(data or {}, is_new=is_new)

    if payload['barcode']:
        other = self.db.one(
            'SELECT id, name FROM products WHERE barcode=? AND (? IS NULL OR id<>?)',
            (payload['barcode'], product_id, product_id),
        )
        if other:
            raise ValueError(f"هذا الباركود مستخدم مسبقاً للمنتج: {other['name']}")

    if product_id:
        old = self.db.one('SELECT * FROM products WHERE id=?', (int(product_id),))
        if not old:
            raise ValueError('المنتج غير موجود')
        # Existing disabled products are reactivated when saved from the product page.
        with self.db.conn:
            self.db.conn.execute('''
                UPDATE products
                SET barcode=?, name=?, category=?, cost_price=?, sale_price=?, quantity=?,
                    min_quantity=?, commission_percent=?, active=1
                WHERE id=?
            ''', (
                payload['barcode'], payload['name'], payload['category'], payload['cost_price'],
                payload['sale_price'], payload['quantity'], payload['min_quantity'],
                payload['commission_percent'], int(product_id),
            ))
            # Optional commercial columns may not exist in very old databases.
            try:
                self.db.conn.execute(
                    'UPDATE products SET expiry_date=?, customs_no=?, country_origin=? WHERE id=?',
                    (payload['expiry_date'], payload['customs_no'], payload['country_origin'], int(product_id)),
                )
            except Exception as exc:
                log_exception(exc, 'V45.13 optional product columns')
            if int(old['quantity'] or 0) != int(payload['quantity']):
                self.db.conn.execute('''
                    INSERT INTO inventory_movements
                    (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    int(product_id), 'تعديل من صفحة المنتجات', int(payload['quantity']) - int(old['quantity'] or 0),
                    int(old['quantity'] or 0), int(payload['quantity']), 'product', str(product_id),
                    'تعديل كمية من صفحة المنتجات', int(user['id']), now_text(),
                ))
        self.log('حفظ منتج', payload['name'], int(user['id']))
        return

    with self.db.conn:
        cur = self.db.conn.execute('''
            INSERT INTO products
            (barcode, name, category, cost_price, sale_price, quantity, min_quantity, commission_percent, active, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
        ''', (
            payload['barcode'], payload['name'], payload['category'], payload['cost_price'],
            payload['sale_price'], payload['quantity'], payload['min_quantity'], payload['commission_percent'], now_text(),
        ))
        new_id = int(cur.lastrowid)
        try:
            self.db.conn.execute(
                'UPDATE products SET expiry_date=?, customs_no=?, country_origin=? WHERE id=?',
                (payload['expiry_date'], payload['customs_no'], payload['country_origin'], new_id),
            )
        except Exception as exc:
            log_exception(exc, 'V45.13 optional product columns insert')
        self.db.conn.execute('''
            INSERT INTO inventory_movements
            (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (new_id, 'رصيد افتتاحي', int(payload['quantity']), 0, int(payload['quantity']), 'product', str(new_id), 'إضافة منتج جديد', int(user['id']), now_text()))
    self.log('إضافة منتج', payload['name'], int(user['id']))


def _v4513_list_products(self: AppService, term: str = '', category: str = '', state: str = 'active'):
    """Single source of truth for products table listing.

    The normal products page must show all active products, including quantity 0
    and low-stock items. Alerts are separate views, not hidden products.
    """
    term = validation.clean_text(term, 120)
    category = validation.clean_text(category, 120)
    state = validation.clean_text(state, 30) or 'active'
    where: list[str] = []
    params: list[Any] = []

    if state == 'all':
        pass
    elif state == 'inactive':
        where.append('COALESCE(active,1)=0')
    elif state == 'out':
        where.append('COALESCE(active,1)=1 AND COALESCE(quantity,0) <= 0')
    elif state == 'low':
        where.append('COALESCE(active,1)=1 AND COALESCE(quantity,0) > 0 AND COALESCE(quantity,0) <= COALESCE(min_quantity,0)')
    else:
        where.append('COALESCE(active,1)=1')

    clause, like_params = search.build_like_filter(['name', 'barcode', 'category'], term)
    if clause:
        where.append(clause)
        params.extend(like_params)
    if category:
        where.append('category=?')
        params.append(category)

    sql = '''
        SELECT id, barcode, name, category, cost_price, sale_price, quantity, min_quantity,
               commission_percent, active, created_at,
               CASE
                   WHEN COALESCE(quantity,0) <= 0 THEN 'نافد'
                   WHEN COALESCE(quantity,0) <= COALESCE(min_quantity,0) THEN 'منخفض'
                   ELSE 'متوفر'
               END AS stock_status
        FROM products
    '''
    if where:
        sql += ' WHERE ' + ' AND '.join(where)
    sql += " ORDER BY COALESCE(active,1) DESC, CASE WHEN COALESCE(quantity,0)<=0 THEN 0 WHEN COALESCE(quantity,0)<=COALESCE(min_quantity,0) THEN 1 ELSE 2 END, name COLLATE NOCASE LIMIT ?"
    params.append(500)
    return self.db.all(sql, params)


def _v4513_low_stock_details(self: AppService):
    return self.db.all('''
        SELECT id, barcode, name, category, quantity, min_quantity,
               CASE WHEN COALESCE(quantity,0) <= 0 THEN 'نافد' ELSE 'منخفض' END AS stock_status
        FROM products
        WHERE COALESCE(active,1)=1
          AND COALESCE(quantity,0) <= COALESCE(min_quantity,0)
        ORDER BY COALESCE(quantity,0) ASC, name COLLATE NOCASE
    ''')


def _v4513_adjust_inventory(self: AppService, product_id: int, new_quantity: int, note: str = '', user_id: int | None = None) -> None:
    user = self.require_any_permission(('can_quantity_edit', 'can_inventory'), user_id, 'تعديل المخزون')
    pid = validation.assert_positive_int(product_id, 'رقم المنتج')
    qty = _int(new_quantity, 0)
    if qty < 0:
        raise ValueError('الكمية لا يمكن أن تكون سالبة')
    row = self.db.one('SELECT id, name, quantity FROM products WHERE id=? AND COALESCE(active,1)=1', (pid,))
    if not row:
        raise ValueError('المنتج غير موجود أو معطل')
    old = int(row['quantity'] or 0)
    with self.db.conn:
        self.db.conn.execute('UPDATE products SET quantity=? WHERE id=?', (qty, pid))
        self.db.conn.execute('''
            INSERT INTO inventory_movements
            (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (pid, 'تعديل يدوي', qty - old, old, qty, 'manual', '', validation.clean_text(note, 500), int(user['id']), now_text()))
    self.log('تعديل مخزون', f"{row['name']}: {old} -> {qty}", int(user['id']))


AppService.save_product = _v4513_save_product
AppService.list_products = _v4513_list_products
AppService.low_stock_details = _v4513_low_stock_details
AppService.low_stock_rows = _v4513_low_stock_details
AppService.adjust_inventory = _v4513_adjust_inventory
