from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})
import services.service_patches.v19_gdrive as _prev_v19_gdrive
globals().update({k: v for k, v in vars(_prev_v19_gdrive).items() if not k.startswith('__')})
import services.service_patches.v20_gdrive_settings as _prev_v20_gdrive_settings
globals().update({k: v for k, v in vars(_prev_v20_gdrive_settings).items() if not k.startswith('__')})

# ================================================================
# V21 BACKUP & BARCODE RESTRUCTURE - ROBUST GOOGLE DRIVE BACKUP
# Single source of truth for Google Drive settings, stable paths based
# on the database folder, clear status messages, and safe copy checks.
# ================================================================

from datetime import datetime as _v21_datetime


def _v21_project_root(self: AppService) -> Path:
    try:
        return Path(self.db.path).resolve().parent
    except Exception:
        return Path.cwd().resolve()


def _v21_settings_dir(self: AppService) -> Path:
    p = _v21_project_root(self) / 'settings'
    p.mkdir(parents=True, exist_ok=True)
    return p


def _v21_gdrive_config_file(self: AppService) -> Path:
    return _v21_settings_dir(self) / 'google_drive_backup_settings.json'


def _v21_backup_dir(self: AppService) -> Path:
    p = _v21_project_root(self) / 'backups'
    p.mkdir(parents=True, exist_ok=True)
    return p


def _v21_bool(value) -> bool:
    return str(value or '').strip().lower() in ('1', 'true', 'yes', 'on', 'نعم', 'مفعل')


def _v21_write_gdrive_json(self: AppService, enabled: bool, folder: str, status: str = '') -> None:
    cfg = {
        'google_drive_backup_enabled': '1' if enabled else '0',
        'google_drive_backup_path': str(folder or '').strip(),
        'last_google_drive_backup_status': str(status or ''),
        'updated_at': now_text(),
    }
    self._gdrive_config_file().write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding='utf-8')


def _v21_read_gdrive_json(self: AppService) -> dict:
    try:
        fn = self._gdrive_config_file()
        if fn.exists():
            return json.loads(fn.read_text(encoding='utf-8'))
    except Exception:
        return {}
    return {}


def _v21_save_google_drive_backup_settings(self: AppService, enabled: bool, path: str, user_id: int | None = None) -> None:
    folder = str(path or '').strip().strip('"')
    enabled_value = '1' if enabled else '0'
    current_status = self.get_settings().get('last_google_drive_backup_status', '') or ''
    self.save_settings({
        'google_drive_backup_enabled': enabled_value,
        'google_drive_backup_path': folder,
        'last_google_drive_backup_status': current_status,
    }, user_id)
    try:
        self._write_gdrive_json(enabled, folder, current_status)
    except Exception as exc:
        self.log('تحذير حفظ إعدادات Google Drive', str(exc), user_id)


def _v21_load_google_drive_backup_settings(self: AppService) -> dict:
    settings = self.get_settings()
    json_cfg = self._read_gdrive_json()
    enabled = str(settings.get('google_drive_backup_enabled', '') or json_cfg.get('google_drive_backup_enabled', '0') or '0')
    folder = str(settings.get('google_drive_backup_path', '') or json_cfg.get('google_drive_backup_path', '') or '').strip()
    status = str(settings.get('last_google_drive_backup_status', '') or json_cfg.get('last_google_drive_backup_status', '') or '')
    if folder and settings.get('google_drive_backup_path', '') != folder:
        self.save_settings({'google_drive_backup_enabled': enabled, 'google_drive_backup_path': folder, 'last_google_drive_backup_status': status})
    return {
        'google_drive_backup_enabled': enabled,
        'google_drive_backup_path': folder,
        'last_google_drive_backup_status': status,
    }


def _v21_google_drive_backup_target_dir(self: AppService, base_folder: str) -> Path:
    base = Path(str(base_folder or '').strip().strip('"')).expanduser()
    # Store Max Sales backups inside a subfolder to keep Google Drive tidy.
    return base / 'MaxSalesBackups'


def _v21_test_google_drive_backup_path(self: AppService, path: str | None = None) -> tuple[bool, str]:
    raw = str(path if path is not None else self.load_google_drive_backup_settings().get('google_drive_backup_path', '')).strip().strip('"')
    if not raw:
        msg = 'لم يتم اختيار مجلد Google Drive. اختر مجلد Google Drive من زر اختيار المجلد أولاً.'
        self.save_settings({'last_google_drive_backup_status': msg})
        return False, msg
    try:
        base = Path(raw).expanduser()
        if not base.exists():
            msg = f'المجلد المختار غير موجود: {base}'
            self.save_settings({'last_google_drive_backup_status': msg})
            return False, msg
        if not base.is_dir():
            msg = f'المسار المختار ليس مجلداً: {base}'
            self.save_settings({'last_google_drive_backup_status': msg})
            return False, msg
        target_dir = self.google_drive_backup_target_dir(str(base))
        target_dir.mkdir(parents=True, exist_ok=True)
        test_file = target_dir / 'max_sales_google_drive_test.txt'
        test_file.write_text(f'Max Sales Google Drive backup test - {now_text()}', encoding='utf-8')
        ok = test_file.exists() and test_file.stat().st_size > 0
        try:
            test_file.unlink()
        except Exception as exc:
            log_exception(exc)
        if not ok:
            msg = 'تعذر إنشاء ملف اختبار داخل مجلد Google Drive'
            self.save_settings({'last_google_drive_backup_status': msg})
            return False, msg
        msg = f'جاهز: سيتم حفظ نسخ Google Drive داخل {target_dir}'
        self.save_settings({'last_google_drive_backup_status': msg})
        try:
            self._write_gdrive_json(_v21_bool(self.load_google_drive_backup_settings().get('google_drive_backup_enabled')), str(base), msg)
        except Exception as exc:
            log_exception(exc)
        return True, msg
    except Exception as exc:
        msg = f'فشل اختبار مجلد Google Drive: {exc}'
        self.save_settings({'last_google_drive_backup_status': msg})
        self.log('فشل اختبار Google Drive', msg)
        return False, msg


def _v21_backup_database(self: AppService) -> Path:
    self.require_permission('can_backup', action='إنشاء نسخة احتياطية')
    backups = self.backup_dir()
    stamp = _v21_datetime.now().strftime('%Y%m%d_%H%M%S')
    target = backups / f'max_sales_qt_backup_{stamp}.db'
    shutil.copy2(self.db.path, target)
    self.log('نسخة احتياطية محلية', str(target))
    # Keep recent local backups only.
    try:
        keep = max(to_int(self.get_settings().get('max_backup_keep'), 7), 1)
        files = sorted(backups.glob('max_sales_qt_backup_*.db'), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in files[keep:]:
            old.unlink(missing_ok=True)
    except Exception as exc:
        self.log('تحذير تنظيف النسخ الاحتياطية', str(exc))

    cfg = self.load_google_drive_backup_settings()
    enabled = _v21_bool(cfg.get('google_drive_backup_enabled'))
    folder = str(cfg.get('google_drive_backup_path', '') or '').strip()
    if not enabled:
        self.save_settings({'last_google_drive_backup_status': 'Google Drive غير مفعل'})
        return target
    if not folder:
        status = 'فشل: Google Drive مفعل لكن لم يتم اختيار مجلد'
        self.save_settings({'last_google_drive_backup_status': status})
        self.log('فشل نسخ Google Drive', status)
        return target
    ok, msg = self.test_google_drive_backup_path(folder)
    if not ok:
        self.save_settings({'last_google_drive_backup_status': msg})
        self.log('فشل نسخ Google Drive', msg)
        return target
    try:
        gdir = self.google_drive_backup_target_dir(folder)
        gdir.mkdir(parents=True, exist_ok=True)
        gtarget = gdir / target.name
        shutil.copy2(target, gtarget)
        if not gtarget.exists() or gtarget.stat().st_size == 0:
            raise ValueError('تم النسخ لكن ملف Google Drive غير موجود أو حجمه صفر')
        status = f'ناجح: {gtarget}'
        self.save_settings({'last_google_drive_backup_status': status, 'last_google_drive_backup_at': now_text()})
        try:
            self._write_gdrive_json(True, folder, status)
        except Exception as exc:
            log_exception(exc)
        self.log('نسخ احتياطي Google Drive', status)
    except Exception as exc:
        status = f'فشل نسخ Google Drive: {exc}'
        self.save_settings({'last_google_drive_backup_status': status})
        self.log('فشل نسخ Google Drive', status)
    return target


def _v21_google_drive_status(self: AppService) -> str:
    cfg = self.load_google_drive_backup_settings()
    enabled = 'مفعل' if _v21_bool(cfg.get('google_drive_backup_enabled')) else 'غير مفعل'
    folder = cfg.get('google_drive_backup_path', '') or '-'
    status = cfg.get('last_google_drive_backup_status', '') or '-'
    return f'الحالة: {enabled}\nالمجلد: {folder}\nآخر نتيجة: {status}'


AppService._gdrive_config_file = _v21_gdrive_config_file
AppService._write_gdrive_json = _v21_write_gdrive_json
AppService._read_gdrive_json = _v21_read_gdrive_json
AppService.backup_dir = _v21_backup_dir
AppService.save_google_drive_backup_settings = _v21_save_google_drive_backup_settings
AppService.load_google_drive_backup_settings = _v21_load_google_drive_backup_settings
AppService.google_drive_backup_target_dir = _v21_google_drive_backup_target_dir
AppService.test_google_drive_backup_path = _v21_test_google_drive_backup_path
AppService.test_google_drive_backup = _v21_test_google_drive_backup_path
AppService.backup_database = _v21_backup_database
AppService.google_drive_status = _v21_google_drive_status

