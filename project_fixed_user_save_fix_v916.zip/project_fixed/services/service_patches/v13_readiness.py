from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})

# ================================================================
# V13 FINAL READINESS PATCH
# Extra guards discovered during full button/accounting scan.
# These wrappers keep the existing behavior while hardening cart data
# before saving or suspending a sale.
# ================================================================


def _v13_normalize_cart_items(self: AppService, cart: list[dict]) -> list[dict]:
    """Return a safe cart copy with required keys populated.

    Some UI paths create cart rows with product_name, while future/imported
    paths may provide only name. This keeps the service layer defensive so a
    button or shortcut cannot crash with KeyError before validation.
    """
    safe: list[dict] = []
    for raw in cart or []:
        item = dict(raw)
        pid = int(item.get('product_id') or 0)
        product = self.db.one('SELECT name, cost_price, sale_price, commission_percent FROM products WHERE id=?', (pid,)) if pid else None
        if not item.get('product_name'):
            item['product_name'] = item.get('name') or (product['name'] if product else 'منتج غير معروف')
        if item.get('cost_price') is None and product:
            item['cost_price'] = product['cost_price']
        if item.get('unit_price') is None and product:
            item['unit_price'] = product['sale_price']
        if item.get('commission_percent') is None and product:
            item['commission_percent'] = product['commission_percent']
        safe.append(item)
    return safe


def _v13_validate_aggregate_stock(self: AppService, cart: list[dict]) -> None:
    totals: dict[int, int] = {}
    names: dict[int, str] = {}
    for item in cart or []:
        pid = int(item.get('product_id') or 0)
        qty = int(item.get('quantity') or 0)
        if pid > 0:
            totals[pid] = totals.get(pid, 0) + qty
            names[pid] = str(item.get('product_name') or item.get('name') or pid)
    errors: list[str] = []
    for pid, qty in totals.items():
        product = self.db.one('SELECT name, quantity, active FROM products WHERE id=?', (pid,))
        if not product or not product['active']:
            errors.append(f"المنتج غير موجود أو معطل: {names.get(pid, pid)}")
            continue
        if qty <= 0:
            errors.append(f"كمية غير صحيحة للمنتج: {product['name']}")
        if int(product['quantity']) < qty:
            errors.append(f"المخزون غير كاف للمنتج {product['name']}: المتوفر {product['quantity']} والمطلوب {qty}")
    if errors:
        raise ValueError('\n'.join(errors))


_orig_complete_sale_v13 = AppService.complete_sale

def _complete_sale_v13(self: AppService, cart, employee_id, customer_id, payment_method, discount_amount=0, note='', user_id=None, discount_type='amount'):
    cart = _v13_normalize_cart_items(self, cart)
    _v13_validate_aggregate_stock(self, cart)
    return _orig_complete_sale_v13(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type)

AppService.complete_sale = _complete_sale_v13


_orig_suspend_sale_v13 = AppService.suspend_sale

def _suspend_sale_v13(self: AppService, cart, employee_id, customer_id, payment_method, discount_amount, note='', user_id=None):
    cart = _v13_normalize_cart_items(self, cart)
    _v13_validate_aggregate_stock(self, cart)
    return _orig_suspend_sale_v13(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id)

AppService.suspend_sale = _suspend_sale_v13


