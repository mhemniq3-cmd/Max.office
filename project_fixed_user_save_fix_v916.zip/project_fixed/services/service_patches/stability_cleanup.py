from __future__ import annotations

import csv
import hashlib
import json
import re
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from pathlib import Path
from typing import Any

from services.app_core import AppService
from services.core_common import now_text, money, return_no, log_exception

_ORIG_INIT = AppService.__init__
_ORIG_SAVE_PRODUCT = getattr(AppService, 'save_product', None)
_ORIG_SYNC_MOVEMENTS = getattr(AppService, 'sync_unified_movements', None)
_ORIG_LIST_MOVEMENTS = getattr(AppService, 'list_unified_movements', None)
_ORIG_MOVEMENT_SUMMARY = getattr(AppService, 'movement_summary', None)

CENT = Decimal('0.01')
ZERO = Decimal('0.00')


def _D(value: Any, default: Decimal = ZERO) -> Decimal:
    if value is None:
        return default
    try:
        text = str(value).strip().replace(',', '')
        if not text:
            return default
        return Decimal(text)
    except (InvalidOperation, ValueError, TypeError):
        return default


def _Q(value: Any) -> Decimal:
    return _D(value).quantize(CENT, rounding=ROUND_HALF_UP)


def _F(value: Any) -> float:
    return float(_Q(value))


def _safe_text(value: Any, limit: int = 1000) -> str:
    text = str(value or '').replace('\r', ' ').replace('\n', ' ')
    text = re.sub(r'\s+', ' ', text).strip()
    return text[:limit]


def _table_exists(self: AppService, table: str) -> bool:
    try:
        return bool(self.db.one("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)))
    except Exception:
        return False


def _column_exists(self: AppService, table: str, column: str) -> bool:
    try:
        return any(str(r['name']) == column for r in self.db.all(f'PRAGMA table_info({table})'))
    except Exception:
        return False


def _logic_bucket(event_time: Any, seconds: int = 2) -> str:
    raw = str(event_time or now_text())[:19]
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d'):
        try:
            dt = datetime.strptime(raw[:len(fmt)], fmt)
            epoch = int(dt.timestamp())
            return str(epoch // max(1, seconds))
        except Exception:
            pass
    return datetime.now().strftime('%Y%m%d%H%M%S')[:-1]


def _action_group(action: Any, details: Any = '') -> str:
    text = f'{action or ""} {details or ""}'
    mapping = [
        ('fraud', ('احتيال', 'تنبيه خطر', 'خطر')),
        ('delete', ('حذف', 'تعطيل', 'deactivate')),
        ('price_update', ('تعديل سعر', 'سعر البيع', 'سعر الشراء', 'price')),
        ('stock_update', ('مخزون', 'كمية', 'جرد', 'inventory')),
        ('return', ('إرجاع', 'مرتجع', 'return')),
        ('sale', ('بيع', 'فاتورة', 'invoice', 'sale')),
        ('payment', ('دفعة', 'سداد', 'قبض', 'صرف', 'payment')),
        ('auth', ('دخول', 'خروج', 'login', 'logout')),
        ('coupon', ('قسيمة', 'coupon')),
        ('create', ('إضافة', 'إنشاء', 'حفظ', 'create')),
        ('update', ('تعديل', 'تغيير', 'update')),
    ]
    for group, words in mapping:
        if any(w in text for w in words):
            return group
    return re.sub(r'\W+', '_', str(action or 'event').lower())[:40] or 'event'


def _normalize_record_type(source: Any, record_type: Any, action: Any, desc: Any) -> str:
    text = f'{source or ""} {record_type or ""} {action or ""} {desc or ""}'.lower()
    if any(x in text for x in ('product', 'products', 'منتج', 'صنف', 'inventory', 'مخزون')):
        return 'product'
    if any(x in text for x in ('sale', 'sales', 'invoice', 'فاتورة', 'بيع')):
        return 'sale'
    if any(x in text for x in ('customer', 'زبون', 'عميل', 'دين')):
        return 'customer'
    if any(x in text for x in ('coupon', 'قسيمة')):
        return 'coupon'
    if any(x in text for x in ('user', 'login', 'مستخدم', 'دخول')):
        return 'user'
    if any(x in text for x in ('fraud', 'احتيال')):
        return 'fraud'
    return _safe_text(record_type or source or 'system', 60).lower()


def _extract_record_id(record_id: Any, description: Any) -> str:
    rid = _safe_text(record_id, 80)
    if rid and rid not in ('0', '-', 'None', 'none'):
        return rid
    text = str(description or '')
    m = re.search(r'(?:id|رقم|منتج|فاتورة|عميل|زبون)\s*[:#-]?\s*([A-Za-z0-9_\-]+)', text, flags=re.I)
    if m:
        return m.group(1)[:80]
    nums = re.findall(r'\d+', text)
    return nums[0][:80] if nums else ''


def _dedupe_key(row: dict[str, Any]) -> str:
    action = row.get('action') or ''
    desc = row.get('description') or row.get('details') or ''
    rtype = _normalize_record_type(row.get('source_table'), row.get('record_type'), action, desc)
    rid = _extract_record_id(row.get('record_id') or row.get('source_id'), desc)
    user = _safe_text(row.get('user_id') or row.get('user_name') or '', 80).lower()
    group = _action_group(action, desc)
    bucket = _logic_bucket(row.get('event_time') or row.get('created_at'), 2)
    # Do not include source_table: one operation can generate activity + audit + trigger rows.
    raw = '|'.join([bucket, user, group, rtype, rid])
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def _severity_from(action: Any, desc: Any, source: Any = '') -> tuple[str, int]:
    text = f'{action or ""} {desc or ""} {source or ""}'
    if any(w in text for w in ('احتيال', 'خطر', 'فشل دخول', 'استعادة', 'تلاعب')):
        return 'خطر', 1
    if any(w in text for w in ('حذف', 'تعطيل', 'تعديل سعر', 'خصم', 'مرتجع', 'إرجاع', 'صلاحية', 'مخزون')):
        return 'حساس', 1
    if any(w in text for w in ('إضافة', 'حفظ', 'دفعة', 'شراء')):
        return 'مهم', 0
    return 'عادي', 0


def _module_from(row: dict[str, Any]) -> str:
    text = f"{row.get('source_table','')} {row.get('record_type','')} {row.get('action','')} {row.get('description','')}"
    if any(x in text for x in ('product', 'products', 'inventory', 'مخزون', 'منتج', 'صنف')):
        return 'المخزون والمنتجات'
    if any(x in text for x in ('sale', 'invoice', 'فاتورة', 'بيع')):
        return 'المبيعات'
    if any(x in text for x in ('customer', 'زبون', 'عميل', 'دين')):
        return 'الزبائن والديون'
    if any(x in text for x in ('coupon', 'قسيمة', 'خصم')):
        return 'القسائم والخصومات'
    if any(x in text for x in ('fraud', 'احتيال')):
        return 'الأمان والاحتيال'
    if any(x in text for x in ('audit', 'تدقيق', 'user', 'مستخدم', 'دخول')):
        return 'السجلات والصلاحيات'
    return 'النظام'


def _ensure_cleanup_schema(self: AppService) -> None:
    # Unified movement log canonical schema.
    self.db.conn.execute('''
        CREATE TABLE IF NOT EXISTS unified_movement_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_key TEXT NOT NULL UNIQUE,
            event_time TEXT NOT NULL,
            user_id INTEGER,
            user_name TEXT,
            module TEXT,
            action TEXT NOT NULL,
            record_type TEXT,
            record_id TEXT,
            description TEXT,
            old_values TEXT,
            new_values TEXT,
            severity TEXT DEFAULT 'عادي',
            source_table TEXT,
            source_id TEXT,
            is_sensitive INTEGER DEFAULT 0,
            is_read INTEGER DEFAULT 0,
            manager_note TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    for sql in (
        'CREATE UNIQUE INDEX IF NOT EXISTS ux_unified_event_key ON unified_movement_log(event_key)',
        'CREATE INDEX IF NOT EXISTS idx_unified_move_time2 ON unified_movement_log(event_time)',
        'CREATE INDEX IF NOT EXISTS idx_unified_move_module2 ON unified_movement_log(module)',
        'CREATE INDEX IF NOT EXISTS idx_unified_move_severity2 ON unified_movement_log(severity, is_sensitive, is_read)',
        'CREATE UNIQUE INDEX IF NOT EXISTS ux_sales_invoice_no_runtime ON sales(invoice_no)',
    ):
        try:
            self.db.conn.execute(sql)
        except Exception:
            pass
    self.db.conn.commit()


def _fetch_source_rows(self: AppService, limit: int, days: int) -> list[dict[str, Any]]:
    cutoff = (datetime.now() - timedelta(days=max(1, int(days or 30)))).strftime('%Y-%m-%d %H:%M:%S')
    limit = max(100, min(int(limit or 1000), 5000))
    rows: list[dict[str, Any]] = []

    def add(table: str, sql: str, params: tuple = ()):
        if not _table_exists(self, table):
            return
        try:
            rows.extend(dict(r) for r in self.db.all(sql, params))
        except Exception as exc:
            log_exception(exc, f'v45.17.4.15 movement source {table}')

    add('system_movements', '''
        SELECT id AS source_id, event_time, source AS source_table, username AS user_name, user_id, action,
               table_name AS record_type, record_id, details AS description, severity
        FROM system_movements WHERE event_time >= ? ORDER BY id DESC LIMIT ?
    ''', (cutoff, limit))
    add('activity_logs', '''
        SELECT id AS source_id, created_at AS event_time, 'activity_logs' AS source_table, username AS user_name,
               user_id, action, '' AS record_type, '' AS record_id, details AS description, 'عادي' AS severity
        FROM activity_logs WHERE created_at >= ? ORDER BY id DESC LIMIT ?
    ''', (cutoff, limit))
    add('activity_log', '''
        SELECT id AS source_id, action_date AS event_time, 'activity_log' AS source_table, user_name AS user_name,
               NULL AS user_id, action_type AS action, table_name AS record_type, record_id, note AS description, 'عادي' AS severity
        FROM activity_log WHERE action_date >= ? ORDER BY id DESC LIMIT ?
    ''', (cutoff, limit))
    add('audit_logs', '''
        SELECT id AS source_id, COALESCE(timestamp, created_at, datetime('now')) AS event_time, 'audit_logs' AS source_table,
               COALESCE(user_name, user_id, '') AS user_name, user_id, action, table_name AS record_type,
               record_id, COALESCE(reason, action, '') AS description, 'حساس' AS severity,
               old_values, new_values
        FROM audit_logs ORDER BY id DESC LIMIT ?
    ''', (limit,))
    add('audit_trail', '''
        SELECT id AS source_id, COALESCE(created_at, datetime('now')) AS event_time, 'audit_trail' AS source_table,
               COALESCE(user_name, user_id, '') AS user_name, user_id, action, table_name AS record_type,
               record_id, COALESCE(note, action, '') AS description, 'حساس' AS severity,
               old_values, new_values
        FROM audit_trail ORDER BY id DESC LIMIT ?
    ''', (limit,))
    add('inventory_movements', '''
        SELECT m.id AS source_id, m.created_at AS event_time, 'inventory_movements' AS source_table,
               COALESCE(u.username, m.user_id, '') AS user_name, m.user_id, m.movement_type AS action,
               'product' AS record_type, m.product_id AS record_id,
               (COALESCE(p.name,'منتج') || ' | ' || COALESCE(m.note,'') || ' | ' || m.old_quantity || ' -> ' || m.new_quantity) AS description,
               CASE WHEN m.movement_type LIKE '%حذف%' OR m.movement_type LIKE '%تعديل%' THEN 'حساس' ELSE 'مهم' END AS severity
        FROM inventory_movements m
        LEFT JOIN products p ON p.id=m.product_id
        LEFT JOIN users u ON u.id=m.user_id
        WHERE m.created_at >= ? ORDER BY m.id DESC LIMIT ?
    ''', (cutoff, limit))
    add('fraud_alerts', '''
        SELECT id AS source_id, COALESCE(created_at, detected_at, datetime('now')) AS event_time, 'fraud_alerts' AS source_table,
               '' AS user_name, NULL AS user_id, COALESCE(alert_type, pattern, 'تنبيه احتيال') AS action,
               COALESCE(related_type, 'fraud') AS record_type, related_id AS record_id,
               COALESCE(description, details, alert_type, 'تنبيه احتيال') AS description, 'خطر' AS severity
        FROM fraud_alerts ORDER BY id DESC LIMIT ?
    ''', (limit,))
    return rows


def _sync_unified_movements_v4517415(self: AppService, limit: int = 1200, days: int = 45) -> int:
    _ensure_cleanup_schema(self)
    before = self.db.one('SELECT COUNT(*) c FROM unified_movement_log')
    before_count = int(before['c'] if before else 0)
    best_by_key: dict[str, dict[str, Any]] = {}
    source_rank = {'audit_logs': 6, 'audit_trail': 5, 'system_movements': 4, 'fraud_alerts': 4, 'inventory_movements': 3, 'activity_logs': 2, 'activity_log': 1}
    for row in _fetch_source_rows(self, limit, days):
        key = _dedupe_key(row)
        current = best_by_key.get(key)
        if not current or source_rank.get(str(row.get('source_table')), 0) > source_rank.get(str(current.get('source_table')), 0):
            best_by_key[key] = row
    with self.db.conn:
        for key, row in best_by_key.items():
            desc = _safe_text(row.get('description'), 1500)
            severity, sensitive = _severity_from(row.get('action'), desc, row.get('source_table'))
            if row.get('severity') in ('خطر', 'حساس', 'مهم', 'عادي'):
                severity = row.get('severity')
                sensitive = 1 if severity in ('خطر', 'حساس') else sensitive
            self.db.conn.execute('''
                INSERT INTO unified_movement_log(
                    event_key, event_time, user_id, user_name, module, action, record_type, record_id,
                    description, old_values, new_values, severity, source_table, source_id, is_sensitive, is_read, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
                ON CONFLICT(event_key) DO UPDATE SET
                    description=CASE WHEN length(excluded.description)>length(unified_movement_log.description) THEN excluded.description ELSE unified_movement_log.description END,
                    old_values=COALESCE(NULLIF(excluded.old_values,''), unified_movement_log.old_values),
                    new_values=COALESCE(NULLIF(excluded.new_values,''), unified_movement_log.new_values),
                    severity=CASE WHEN excluded.severity='خطر' THEN 'خطر' WHEN unified_movement_log.severity='خطر' THEN 'خطر' WHEN excluded.severity='حساس' THEN 'حساس' ELSE unified_movement_log.severity END,
                    is_sensitive=MAX(unified_movement_log.is_sensitive, excluded.is_sensitive)
            ''', (
                key, _safe_text(row.get('event_time') or now_text(), 40), row.get('user_id'), _safe_text(row.get('user_name'), 120),
                _module_from(row), _safe_text(row.get('action'), 180), _normalize_record_type(row.get('source_table'), row.get('record_type'), row.get('action'), desc),
                _extract_record_id(row.get('record_id'), desc), desc, _safe_text(row.get('old_values'), 2000), _safe_text(row.get('new_values'), 2000),
                severity, _safe_text(row.get('source_table'), 80), _safe_text(row.get('source_id'), 80), int(bool(sensitive)), now_text()
            ))
    # Remove duplicates imported by older v45.17.4.14 logic, keeping the richest/latest row per logical key.
    _dedupe_existing_unified(self)
    after = self.db.one('SELECT COUNT(*) c FROM unified_movement_log')
    return int(after['c'] if after else 0) - before_count


def _dedupe_existing_unified(self: AppService) -> int:
    if not _table_exists(self, 'unified_movement_log'):
        return 0
    rows = [dict(r) for r in self.db.all('''
        SELECT * FROM unified_movement_log ORDER BY datetime(event_time) DESC, id DESC LIMIT 10000
    ''')]
    seen: dict[str, int] = {}
    delete_ids: list[int] = []
    for row in rows:
        key = _dedupe_key(row)
        if key in seen:
            delete_ids.append(int(row['id']))
        else:
            seen[key] = int(row['id'])
            if row.get('event_key') != key:
                try:
                    self.db.conn.execute('UPDATE unified_movement_log SET event_key=? WHERE id=?', (key, int(row['id'])))
                except Exception:
                    # If target key exists, mark duplicate for deletion.
                    delete_ids.append(int(row['id']))
    if delete_ids:
        qs = ','.join('?' for _ in delete_ids)
        self.db.conn.execute(f'DELETE FROM unified_movement_log WHERE id IN ({qs})', tuple(delete_ids))
    self.db.conn.commit()
    return len(delete_ids)


def _list_unified_movements_v4517415(self: AppService, limit: int = 500, **filters) -> list[dict[str, Any]]:
    _sync_unified_movements_v4517415(self, limit=max(limit, 1200), days=45)
    limit = max(1, min(int(limit or 500), 5000))
    clauses = []
    params: list[Any] = []
    term = _safe_text(filters.get('term', ''), 200)
    if term:
        like = f'%{term}%'
        clauses.append('(action LIKE ? OR description LIKE ? OR user_name LIKE ? OR module LIKE ? OR record_type LIKE ? OR record_id LIKE ?)')
        params.extend([like, like, like, like, like, like])
    mode = str(filters.get('mode') or 'all')
    if mode == 'daily':
        clauses.append('date(event_time)=date(?)')
        params.append(now_text()[:10])
    elif mode == 'sensitive':
        clauses.append('(is_sensitive=1 OR severity IN (?,?))')
        params.extend(['حساس', 'خطر'])
    elif mode == 'fraud':
        clauses.append("(source_table='fraud_alerts' OR action LIKE ? OR module LIKE ?)")
        params.extend(['%احتيال%', '%احتيال%'])
    severity = _safe_text(filters.get('severity', ''), 30)
    if severity and severity != 'الكل':
        clauses.append('severity=?')
        params.append(severity)
    module = _safe_text(filters.get('module', ''), 80)
    if module and module != 'كل الأقسام':
        clauses.append('module=?')
        params.append(module)
    where = 'WHERE ' + ' AND '.join(clauses) if clauses else ''
    return [dict(r) for r in self.db.all(f'''
        SELECT id, event_key, event_time, user_id, user_name, module, action, record_type, record_id,
               description, old_values, new_values, severity, source_table, source_id, is_sensitive, is_read, manager_note
        FROM unified_movement_log {where}
        ORDER BY datetime(event_time) DESC, id DESC LIMIT ?
    ''', (*params, limit))]


def _movement_summary_v4517415(self: AppService) -> dict[str, Any]:
    _sync_unified_movements_v4517415(self, 1200, 45)
    today = now_text()[:10]
    def scalar(sql: str, params: tuple = ()) -> int:
        r = self.db.one(sql, params)
        return int(r['v'] if r and r['v'] is not None else 0)
    top_user = self.db.one('''
        SELECT COALESCE(user_name,'') name, COUNT(*) c FROM unified_movement_log
        WHERE date(event_time)=date(?) AND COALESCE(user_name,'')<>'' GROUP BY user_name ORDER BY c DESC LIMIT 1
    ''', (today,))
    last_fraud = self.db.one('''
        SELECT event_time, action, description FROM unified_movement_log
        WHERE source_table='fraud_alerts' OR action LIKE '%احتيال%'
        ORDER BY datetime(event_time) DESC, id DESC LIMIT 1
    ''')
    return {
        'today_total': scalar('SELECT COUNT(*) v FROM unified_movement_log WHERE date(event_time)=date(?)', (today,)),
        'sensitive_total': scalar('SELECT COUNT(*) v FROM unified_movement_log WHERE date(event_time)=date(?) AND (is_sensitive=1 OR severity IN ("حساس","خطر"))', (today,)),
        'discount_total': scalar('SELECT COUNT(*) v FROM unified_movement_log WHERE date(event_time)=date(?) AND action LIKE ?', (today, '%خصم%')),
        'delete_total': scalar('SELECT COUNT(*) v FROM unified_movement_log WHERE date(event_time)=date(?) AND (action LIKE ? OR action LIKE ?)', (today, '%حذف%', '%تعطيل%')),
        'return_total': scalar('SELECT COUNT(*) v FROM unified_movement_log WHERE date(event_time)=date(?) AND (action LIKE ? OR action LIKE ?)', (today, '%إرجاع%', '%مرتجع%')),
        'unread_total': scalar('SELECT COUNT(*) v FROM unified_movement_log WHERE is_read=0'),
        'top_user': dict(top_user) if top_user else {'name': '', 'c': 0},
        'last_fraud': dict(last_fraud) if last_fraud else {},
    }


def _db_has_credit_limit(self: AppService) -> bool:
    return _column_exists(self, 'customers', 'credit_limit')


def _customer_debt_decimal(self: AppService, customer_id: int) -> Decimal:
    if not customer_id:
        return ZERO
    expr = "CASE WHEN (subtotal - discount_amount + tax_amount) < 0 THEN 0 ELSE (subtotal - discount_amount + tax_amount) END"
    r = self.db.one(f'''
        WITH credit AS (SELECT COALESCE(SUM({expr}),0) v FROM sales WHERE customer_id=? AND payment_method='آجل'),
             payments AS (SELECT COALESCE(SUM(amount),0) v FROM customer_payments WHERE customer_id=?),
             returned AS (SELECT COALESCE(SUM(r.amount),0) v FROM returns r JOIN sales s ON s.id=r.sale_id WHERE s.customer_id=?)
        SELECT COALESCE(credit.v,0)-COALESCE(payments.v,0)-COALESCE(returned.v,0) balance FROM credit, payments, returned
    ''', (customer_id, customer_id, customer_id))
    return _Q(r['balance'] if r else 0)


def _next_invoice_no(self: AppService) -> str:
    # Use the existing document_counters(kind, year, last_number) schema to avoid conflicts with older DBs.
    year = datetime.now().strftime('%Y')
    today = datetime.now().strftime('%Y%m%d')
    self.db.conn.execute('''CREATE TABLE IF NOT EXISTS document_counters(
        kind TEXT NOT NULL,
        year TEXT NOT NULL,
        last_number INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY(kind, year)
    )''')
    self.db.conn.execute('INSERT OR IGNORE INTO document_counters(kind, year, last_number) VALUES(?,?,0)', ('sale', year))
    self.db.conn.execute('UPDATE document_counters SET last_number = last_number + 1 WHERE kind=? AND year=?', ('sale', year))
    row = self.db.conn.execute('SELECT last_number FROM document_counters WHERE kind=? AND year=?', ('sale', year)).fetchone()
    val = int(row['last_number'] if row else 1)
    inv = f'MAX-{today}-{val:06d}'
    while self.db.conn.execute('SELECT 1 FROM sales WHERE invoice_no=?', (inv,)).fetchone():
        val += 1
        self.db.conn.execute('UPDATE document_counters SET last_number=? WHERE kind=? AND year=?', (val, 'sale', year))
        inv = f'MAX-{today}-{val:06d}'
    return inv


def _normalize_cart_item(self: AppService, item: dict[str, Any]) -> dict[str, Any]:
    product_id = int(item.get('product_id') or item.get('id') or 0)
    if product_id <= 0:
        raise ValueError('منتج غير صالح في السلة')
    product = self.db.conn.execute('SELECT * FROM products WHERE id=? AND active=1', (product_id,)).fetchone()
    if not product:
        raise ValueError(f'المنتج غير موجود أو معطل: {item.get("product_name", product_id)}')
    qty = int(item.get('quantity') or 0)
    if qty <= 0:
        raise ValueError('كمية السلة يجب أن تكون أكبر من صفر')
    if int(product['quantity']) < qty:
        raise ValueError(f"المخزون غير كافٍ: {product['name']} (متاح: {product['quantity']}, مطلوب: {qty})")
    db_sale = _Q(product['sale_price'])
    db_cost = _Q(product['cost_price'])
    item_price = _Q(item.get('unit_price', db_sale))
    if item_price <= ZERO:
        raise ValueError('سعر البيع في السلة غير صالح')
    if item_price < db_cost:
        raise ValueError(f"سعر البيع أقل من التكلفة للمنتج: {product['name']}")
    # Only managers/price editors may override the saved sale price.
    if item_price != db_sale:
        self.require_permission('can_price_edit', action='تعديل سعر المنتج داخل الفاتورة')
    return {
        'product_id': product_id,
        'product_name': str(product['name']),
        'quantity': qty,
        'unit_price': item_price,
        'cost_price': db_cost,
        'commission_percent': _Q(item.get('commission_percent', product['commission_percent'] or 0)),
        'old_quantity': int(product['quantity']),
    }


def _complete_sale_v4517415(self: AppService, cart: list[dict], employee_id: int, customer_id: int | None,
                            payment_method: str, discount_amount: float = 0, note: str = '',
                            user_id: int | None = None, discount_type: str = 'amount') -> str:
    user = self.require_any_permission(('can_sales', 'can_touch_pos'), user_id, 'إتمام البيع')
    user_id = int(user['id'])
    if not cart:
        raise ValueError('السلة فارغة')
    if not employee_id:
        raise ValueError('اختر الموظف الذي يستحق العمولة')
    employee = self.db.one('SELECT id, active FROM employees WHERE id=? AND active=1', (employee_id,))
    if not employee:
        raise ValueError('الموظف المختار غير موجود أو معطل')

    try:
        self.db.conn.execute('BEGIN IMMEDIATE')
        normalized = [_normalize_cart_item(self, item) for item in cart]
        subtotal = sum((i['unit_price'] * i['quantity'] for i in normalized), ZERO).quantize(CENT)
        discount_value = max(_Q(discount_amount), ZERO)
        if str(discount_type or 'amount').lower() in ('percent', 'نسبة'):
            if discount_value > Decimal('100.00'):
                raise ValueError('نسبة الخصم لا يمكن أن تتجاوز 100%')
            discount = (subtotal * discount_value / Decimal('100')).quantize(CENT, rounding=ROUND_HALF_UP)
        else:
            discount = discount_value
        if discount > subtotal:
            raise ValueError(f'قيمة الخصم لا يمكن أن تكون أكبر من إجمالي الفاتورة: {money(float(subtotal))}')
        if discount >= subtotal and subtotal > ZERO:
            raise ValueError('الخصم لا يمكن أن يساوي أو يتجاوز قيمة الفاتورة')
        taxable = max(subtotal - discount, ZERO)
        settings = self.get_settings() if hasattr(self, 'get_settings') else {}
        tax_percent = _Q((settings or {}).get('tax_percent', 0))
        tax_amount = (taxable * tax_percent / Decimal('100')).quantize(CENT, rounding=ROUND_HALF_UP)
        total = (taxable + tax_amount).quantize(CENT, rounding=ROUND_HALF_UP)

        if customer_id:
            cwhere = 'id=?'
            customer = self.db.conn.execute(f'SELECT * FROM customers WHERE {cwhere}', (customer_id,)).fetchone()
            if not customer or int(customer['active']) != 1:
                raise ValueError('الزبون غير موجود أو معطل')
            if payment_method == 'آجل' and _db_has_credit_limit(self):
                limit = _Q(customer['credit_limit'] if 'credit_limit' in customer.keys() else 0)
                if limit > ZERO and _customer_debt_decimal(self, int(customer_id)) + total > limit:
                    raise ValueError(f'تجاوز حد الائتمان: الدين الحالي {money(float(_customer_debt_decimal(self, int(customer_id))))} + الفاتورة {money(float(total))} > الحد {money(float(limit))}')

        commission = ZERO
        profit = ZERO
        for i in normalized:
            line_total = (i['unit_price'] * i['quantity']).quantize(CENT)
            line_discount = (discount * line_total / subtotal).quantize(CENT, rounding=ROUND_HALF_UP) if subtotal else ZERO
            line_net = line_total - line_discount
            commission += (line_net * i['commission_percent'] / Decimal('100')).quantize(CENT, rounding=ROUND_HALF_UP)
            # الربح الصحيح = صافي السطر (بعد الخصم) ناقص التكلفة الإجمالية
            profit += (line_net - i['quantity'] * i['cost_price']).quantize(CENT, rounding=ROUND_HALF_UP)
        profit = max(profit, ZERO)
        inv = _next_invoice_no(self)
        cur = self.db.conn.execute('''
            INSERT INTO sales(invoice_no, user_id, employee_id, customer_id, subtotal, discount_amount, total,
                total_commission, total_profit, payment_method, discount_type, tax_amount, note, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (inv, user_id, employee_id, customer_id, _F(subtotal), _F(discount), _F(total), _F(commission), _F(profit), payment_method, discount_type, _F(tax_amount), _safe_text(note, 500), now_text()))
        sale_id = cur.lastrowid
        for i in normalized:
            line_total = (i['unit_price'] * i['quantity']).quantize(CENT)
            line_discount = (discount * line_total / subtotal).quantize(CENT, rounding=ROUND_HALF_UP) if subtotal else ZERO
            line_net = line_total - line_discount
            item_comm = (line_net * i['commission_percent'] / Decimal('100')).quantize(CENT, rounding=ROUND_HALF_UP)
            # الربح الصحيح للصنف = صافي السطر ناقص التكلفة
            item_profit = max((line_net - i['quantity'] * i['cost_price']).quantize(CENT, rounding=ROUND_HALF_UP), ZERO)
            self.db.conn.execute('''
                INSERT INTO sale_items(sale_id, product_id, product_name, quantity, cost_price, unit_price,
                    line_total, commission_percent, commission_amount, profit_amount)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (sale_id, i['product_id'], i['product_name'], i['quantity'], _F(i['cost_price']), _F(i['unit_price']), _F(line_total), _F(i['commission_percent']), _F(item_comm), _F(item_profit)))
            oldq = int(i['old_quantity'])
            newq = oldq - int(i['quantity'])
            if newq < 0:
                raise ValueError(f"المخزون غير كافٍ: {i['product_name']}")
            self.db.conn.execute('UPDATE products SET quantity=? WHERE id=?', (newq, i['product_id']))
            self.db.conn.execute('''
                INSERT INTO inventory_movements(product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (i['product_id'], 'بيع', -int(i['quantity']), oldq, newq, 'sale', inv, '', user_id, now_text()))
        self.db.conn.commit()
    except Exception:
        try:
            self.db.conn.rollback()
        except Exception:
            pass
        raise
    self.log('بيع', inv, user_id)
    return inv


def _return_item_v4517415(self: AppService, sale_item_id: int, quantity: int, reason: str = '', user_id: int | None = None, refund_method: str = 'نقدي') -> str:
    user = self.require_permission('can_returns', user_id, 'تسجيل المرتجعات')
    user_id = int(user['id'])
    if quantity <= 0:
        raise ValueError('كمية الإرجاع يجب أن تكون أكبر من صفر')
    if not _safe_text(reason):
        raise ValueError('سبب الإرجاع مطلوب')
    try:
        self.db.conn.execute('BEGIN IMMEDIATE')
        row = self.db.conn.execute('''
            SELECT si.*, s.employee_id, s.customer_id, s.id sale_id,
                   COALESCE(SUM(r.quantity),0) returned_qty,
                   si.quantity - COALESCE(SUM(r.quantity),0) remaining_qty
            FROM sale_items si JOIN sales s ON s.id=si.sale_id
            LEFT JOIN returns r ON r.sale_item_id=si.id
            WHERE si.id=? GROUP BY si.id
        ''', (sale_item_id,)).fetchone()
        if not row:
            raise ValueError('المادة غير موجودة في الفاتورة')
        if quantity > int(row['remaining_qty']):
            raise ValueError('كمية الإرجاع أكبر من الكمية المتبقية')
        gross = _Q(row['unit_price']) * int(quantity)
        orig = self.db.conn.execute('SELECT COALESCE(SUM(line_total),0) v FROM sale_items WHERE sale_id=?', (row['sale_id'],)).fetchone()
        sale_row = self.db.conn.execute('SELECT discount_amount, tax_amount FROM sales WHERE id=?', (row['sale_id'],)).fetchone()
        orig_sub = _Q(orig['v'] if orig else 0)
        orig_discount = _Q(sale_row['discount_amount'] if sale_row else 0)
        orig_tax = _Q(sale_row['tax_amount'] if sale_row else 0)
        discount_share = (orig_discount * gross / orig_sub).quantize(CENT, rounding=ROUND_HALF_UP) if orig_sub else ZERO
        net_before_tax = max(gross - discount_share, ZERO)
        taxable_base = max(orig_sub - orig_discount, ZERO)
        tax_share = (orig_tax * net_before_tax / taxable_base).quantize(CENT, rounding=ROUND_HALF_UP) if taxable_base else ZERO
        amount = (net_before_tax + tax_share).quantize(CENT)
        commission = (net_before_tax * _Q(row['commission_percent']) / Decimal('100')).quantize(CENT)
        # الربح الصحيح للمرتجع = صافي المبلغ المُرجَع ناقص التكلفة
        _net_before_tax_ret = max(_Q(int(quantity)) * _Q(row['unit_price']) - discount_share, ZERO)
        profit = (_net_before_tax_ret - _Q(int(quantity)) * _Q(row['cost_price'])).quantize(CENT)
        ret = return_no()
        self.db.conn.execute('''
            INSERT INTO returns(return_no, sale_id, sale_item_id, product_id, product_name, employee_id, customer_id, quantity, unit_price, amount, commission_amount, profit_amount, reason, refund_method, created_by_user_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (ret, row['sale_id'], row['id'], row['product_id'], row['product_name'], row['employee_id'], row['customer_id'], int(quantity), _F(row['unit_price']), _F(amount), _F(commission), _F(profit), _safe_text(reason, 500), refund_method, user_id, now_text()))
        oldq = self.db.conn.execute('SELECT quantity FROM products WHERE id=?', (row['product_id'],)).fetchone()['quantity']
        newq = int(oldq) + int(quantity)
        self.db.conn.execute('UPDATE products SET quantity=? WHERE id=?', (newq, row['product_id']))
        self.db.conn.execute('''
            INSERT INTO inventory_movements(product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (row['product_id'], 'مرتجع', int(quantity), int(oldq), newq, 'return', ret, _safe_text(reason, 500), user_id, now_text()))
        self.db.conn.execute('''
            UPDATE sales SET
                total = CASE WHEN (total - ?) < 0 THEN 0 ELSE (total - ?) END,
                total_commission = CASE WHEN (total_commission - ?) < 0 THEN 0 ELSE (total_commission - ?) END,
                total_profit = CASE WHEN (total_profit - ?) < 0 THEN 0 ELSE (total_profit - ?) END
            WHERE id=?
        ''', (_F(amount), _F(amount), _F(commission), _F(commission), _F(profit), _F(profit), row['sale_id']))
        self.db.conn.commit()
    except Exception:
        try:
            self.db.conn.rollback()
        except Exception:
            pass
        raise
    self.log('مرتجع', ret, user_id)
    return ret


def _return_full_sale_v4517415(self: AppService, sale_id: int, reason: str = '', user_id: int | None = None, refund_method: str = 'نقدي') -> list[str]:
    # Keep all returns atomic by validating first, then applying one item at a time. Each item starts its own
    # transaction in return_item, but no partial operation remains if validation fails before execution.
    user = self.require_permission('can_returns', user_id, 'إرجاع الفواتير')
    user_id = int(user['id'])
    if not _safe_text(reason):
        raise ValueError('سبب الإرجاع مطلوب')
    items = self.db.all('''
        SELECT si.id, si.quantity - COALESCE(SUM(r.quantity),0) remaining_qty
        FROM sale_items si LEFT JOIN returns r ON r.sale_item_id=si.id
        WHERE si.sale_id=? GROUP BY si.id
    ''', (sale_id,))
    todo = [(int(i['id']), int(i['remaining_qty'])) for i in items if int(i['remaining_qty']) > 0]
    if not todo:
        raise ValueError('لا توجد مواد متبقية للإرجاع في هذه الفاتورة')
    numbers = []
    for item_id, qty in todo:
        numbers.append(_return_item_v4517415(self, item_id, qty, reason, user_id, refund_method))
    return numbers


def _save_product_v4517415(self: AppService, data: dict, product_id: int | None = None, *args, **kwargs) -> None:
    kwargs.pop('user_id', None)
    barcode = (data.get('barcode') or '').strip() or None
    name = (data.get('name') or '').strip()
    if not name:
        raise ValueError('اسم المنتج مطلوب')
    cost = _Q(data.get('cost_price'))
    price = _Q(data.get('sale_price'))
    qty = int(data.get('quantity') or 0)
    min_qty = int(data.get('min_quantity', data.get('min_qty', 5)) or 5)
    commission = _Q(data.get('commission_percent'))
    if cost <= ZERO:
        raise ValueError('سعر الشراء يجب أن يكون أكبر من صفر')
    if price <= ZERO:
        raise ValueError('سعر البيع يجب أن يكون أكبر من صفر')
    if price < cost:
        raise ValueError(f'سعر البيع ({money(float(price))}) أقل من سعر الشراء ({money(float(cost))})')
    if qty < 0 or min_qty < 0 or commission < ZERO:
        raise ValueError('القيم لا يمكن أن تكون سالبة')
    # Delegate to final product implementation, but pass normalized values and no unsupported kwargs.
    clean = dict(data)
    clean.update(cost_price=_F(cost), sale_price=_F(price), quantity=qty, min_quantity=min_qty, commission_percent=_F(commission), barcode=barcode)
    if _ORIG_SAVE_PRODUCT:
        return _ORIG_SAVE_PRODUCT(self, clean, product_id)
    raise RuntimeError('دالة حفظ المنتج غير متوفرة')


def _patch_debt_methods(self: AppService):
    # Runtime marker used by health checks; actual debt SQL is provided in methods below.
    return True


def _debt_rows_v4517415(self: AppService):
    expr = "CASE WHEN (s.subtotal - s.discount_amount + s.tax_amount) < 0 THEN 0 ELSE (s.subtotal - s.discount_amount + s.tax_amount) END"
    return self.db.all(f'''
        WITH credit AS (
            SELECT customer_id, SUM({expr}) credit_sales, MAX(created_at) last_credit_sale
            FROM sales s WHERE payment_method='آجل' GROUP BY customer_id
        ), payments AS (
            SELECT customer_id, SUM(amount) payments FROM customer_payments GROUP BY customer_id
        ), returned AS (
            SELECT s.customer_id, SUM(r.amount) returns_amount FROM returns r JOIN sales s ON s.id=r.sale_id GROUP BY s.customer_id
        )
        SELECT c.*, COALESCE(credit.credit_sales,0)-COALESCE(payments.payments,0)-COALESCE(returned.returns_amount,0) balance,
               COALESCE(credit.last_credit_sale,'') last_credit_sale
        FROM customers c
        LEFT JOIN credit ON credit.customer_id=c.id
        LEFT JOIN payments ON payments.customer_id=c.id
        LEFT JOIN returned ON returned.customer_id=c.id
        WHERE c.active=1 AND (COALESCE(credit.credit_sales,0)-COALESCE(payments.payments,0)-COALESCE(returned.returns_amount,0)) > 0
        ORDER BY balance DESC
    ''')


def _customer_statement_v4517415(self: AppService, customer_id: int):
    rows = []
    expr = "CASE WHEN (subtotal - discount_amount + tax_amount) < 0 THEN 0 ELSE (subtotal - discount_amount + tax_amount) END"
    for sale in self.db.all(f'SELECT invoice_no ref, created_at, {expr} amount, payment_method note FROM sales WHERE customer_id=? ORDER BY created_at LIMIT 2000', (int(customer_id),)):
        rows.append({'type': 'فاتورة', **dict(sale)})
    if _table_exists(self, 'customer_payments'):
        for pay in self.db.all('SELECT receipt_no ref, created_at, amount, note FROM customer_payments WHERE customer_id=? ORDER BY created_at LIMIT 2000', (int(customer_id),)):
            d = dict(pay); d['amount'] = -abs(d.get('amount') or 0); rows.append({'type': 'دفعة', **d})
    rows.sort(key=lambda r: str(r.get('created_at') or ''))
    balance = ZERO
    out = []
    for r in rows:
        balance += _Q(r.get('amount'))
        r['balance'] = _F(balance)
        out.append(r)
    return out


def _sales_summary_v4517415(self: AppService, date_from: str | None = None, date_to: str | None = None) -> dict[str, Any]:
    clauses = []
    params = []
    if date_from:
        clauses.append('date(created_at) >= date(?)'); params.append(date_from)
    if date_to:
        clauses.append('date(created_at) <= date(?)'); params.append(date_to)
    where = 'WHERE ' + ' AND '.join(clauses) if clauses else ''
    r = self.db.one(f'''SELECT COUNT(*) invoices, COALESCE(SUM(total),0) sales, COALESCE(SUM(total_profit),0) profit, COALESCE(SUM(tax_amount),0) tax FROM sales {where}''', tuple(params))
    return dict(r) if r else {'invoices':0,'sales':0,'profit':0,'tax':0}


def _runtime_health_v4517415(self: AppService) -> dict[str, Any]:
    max_patterns = []
    for rel in ('services/domain/people_service.py','services/domain/report_service.py','services/domain/sales_service.py','services/remote_dashboard.py'):
        p = Path(rel)
        if p.exists():
            text = p.read_text(encoding='utf-8', errors='ignore')
            if 'MAX(subtotal-discount_amount+tax_amount' in text or 'MAX(total-?' in text:
                max_patterns.append(rel)
    return {
        'version': 'v45.17.4.15_stability_cleanup',
        'movement_dedup': 'logical_event_key_2s_bucket',
        'save_product_user_id_safe': True,
        'decimal_sale_runtime': True,
        'legacy_max_patterns_remaining_in_files': max_patterns,
        'runtime_patch_mode': 'clean_final_overrides_loaded_last',
    }


def _init_v4517415(self: AppService, *args, **kwargs):
    _ORIG_INIT(self, *args, **kwargs)
    try:
        _ensure_cleanup_schema(self)
        _sync_unified_movements_v4517415(self, limit=1200, days=45)
    except Exception as exc:
        log_exception(exc, 'v45.17.4.15 init cleanup')


AppService.__init__ = _init_v4517415
AppService.save_product = _save_product_v4517415
AppService.complete_sale = _complete_sale_v4517415
AppService.return_item = _return_item_v4517415
AppService.return_full_sale = _return_full_sale_v4517415
AppService.sync_unified_movements = _sync_unified_movements_v4517415
AppService.list_unified_movements = _list_unified_movements_v4517415
AppService.movement_summary = _movement_summary_v4517415
AppService.dedupe_existing_unified_movements = _dedupe_existing_unified
AppService.debt_rows = _debt_rows_v4517415
AppService.customer_statement = _customer_statement_v4517415
AppService.sales_summary = _sales_summary_v4517415
AppService.runtime_health_v4517415 = _runtime_health_v4517415
