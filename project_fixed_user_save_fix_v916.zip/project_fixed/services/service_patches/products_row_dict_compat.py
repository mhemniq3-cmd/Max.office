from __future__ import annotations

"""V45.14 product page compatibility fix.

The restored v44/v33 products UI expects product rows to behave like dicts and
calls p.get(...). SQLite returns sqlite3.Row, which supports row['name'] but not
row.get(...). That caused:
    'sqlite3.Row' object has no attribute 'get'
when opening/refreshing the products page, and made newly saved products look as
if they were not added.

This patch makes the product-facing service methods return plain dictionaries
and keeps low/out-of-stock products visible in the normal products list.
"""

from typing import Any

from services.app_core import AppService
from services.shared import validation, search


def _row_dict(row: Any) -> dict[str, Any] | None:
    if row is None:
        return None
    if isinstance(row, dict):
        return dict(row)
    try:
        return {k: row[k] for k in row.keys()}
    except Exception:
        try:
            return dict(row)
        except Exception:
            return {'value': row}


def _rows_dict(rows: list[Any]) -> list[dict[str, Any]]:
    return [x for x in (_row_dict(r) for r in (rows or [])) if x is not None]


def _product_columns(self: AppService) -> set[str]:
    try:
        return {str(r['name']) for r in self.db.all('PRAGMA table_info(products)')}
    except Exception:
        return set()


def _select_products_sql(self: AppService) -> str:
    cols = _product_columns(self)
    base = [
        'id', 'barcode', 'name', 'category', 'cost_price', 'sale_price',
        'quantity', 'min_quantity', 'commission_percent', 'active', 'created_at'
    ]
    optional = [
        'expiry_date', 'customs_no', 'country_origin', 'unit_name',
        'items_per_unit', 'reorder_point'
    ]
    selected = [c for c in base if c in cols]
    selected += [c for c in optional if c in cols]
    if not selected:
        selected = ['*']
    selected.append("CASE WHEN COALESCE(quantity,0) <= 0 THEN 'نافد' WHEN COALESCE(quantity,0) <= COALESCE(min_quantity,0) THEN 'منخفض' ELSE 'متوفر' END AS stock_status")
    return ', '.join(selected)


def _v4514_list_products(self: AppService, term: str = '', category: str = '', state: str = 'active') -> list[dict[str, Any]]:
    term = validation.clean_text(term, 120)
    category = validation.clean_text(category, 120)
    state = validation.clean_text(state, 30) or 'active'
    where: list[str] = []
    params: list[Any] = []

    if state == 'all':
        pass
    elif state == 'inactive':
        where.append('COALESCE(active,1)=0')
    elif state == 'out':
        where.append('COALESCE(active,1)=1 AND COALESCE(quantity,0) <= 0')
    elif state == 'low':
        where.append('COALESCE(active,1)=1 AND COALESCE(quantity,0) > 0 AND COALESCE(quantity,0) <= COALESCE(min_quantity,0)')
    else:
        # Important: active products include available, low-stock, and zero-stock.
        # Low/out-of-stock alerts are not separate hidden records.
        where.append('COALESCE(active,1)=1')

    clause, like_params = search.build_like_filter(['name', 'barcode', 'category'], term)
    if clause:
        where.append(clause)
        params.extend(like_params)
    if category:
        where.append('category=?')
        params.append(category)

    sql = f"SELECT {_select_products_sql(self)} FROM products"
    if where:
        sql += ' WHERE ' + ' AND '.join(where)
    sql += " ORDER BY COALESCE(active,1) DESC, CASE WHEN COALESCE(quantity,0)<=0 THEN 0 WHEN COALESCE(quantity,0)<=COALESCE(min_quantity,0) THEN 1 ELSE 2 END, name COLLATE NOCASE LIMIT ?"
    params.append(500)
    return _rows_dict(self.db.all(sql, params))


def _v4514_list_products_for_sale(self: AppService, term: str = '') -> list[dict[str, Any]]:
    # POS should not offer out-of-stock items for sale, but it should still use
    # dict rows to keep all older UI patches compatible.
    term = validation.clean_text(term, 120)
    where = ['COALESCE(active,1)=1', 'COALESCE(quantity,0) > 0']
    params: list[Any] = []
    clause, like_params = search.build_like_filter(['name', 'barcode', 'category'], term)
    if clause:
        where.append(clause)
        params.extend(like_params)
    sql = f"SELECT {_select_products_sql(self)} FROM products WHERE {' AND '.join(where)} ORDER BY name COLLATE NOCASE LIMIT 500"
    return _rows_dict(self.db.all(sql, params))


def _v4514_get_product_by_barcode(self: AppService, barcode: str):
    barcode = validation.clean_text(barcode, 120)
    if not barcode:
        return None
    row = self.db.one(f"SELECT {_select_products_sql(self)} FROM products WHERE COALESCE(active,1)=1 AND barcode=?", (barcode,))
    return _row_dict(row)


def _v4514_get_product_for_pos(self: AppService, product_id: int):
    row = self.db.one(f"SELECT {_select_products_sql(self)} FROM products WHERE id=? AND COALESCE(active,1)=1", (int(product_id),))
    return _row_dict(row)


def _v4514_low_stock_details(self: AppService) -> list[dict[str, Any]]:
    rows = self.db.all('''
        SELECT id, barcode, name, category, quantity, min_quantity, active,
               CASE WHEN COALESCE(quantity,0) <= 0 THEN 'نافد' ELSE 'منخفض' END AS stock_status
        FROM products
        WHERE COALESCE(active,1)=1
          AND COALESCE(quantity,0) <= COALESCE(min_quantity,0)
        ORDER BY COALESCE(quantity,0) ASC, name COLLATE NOCASE
    ''')
    return _rows_dict(rows)


def _v4514_product_categories(self: AppService) -> list[str]:
    try:
        rows = self.db.all("SELECT DISTINCT category FROM products WHERE COALESCE(active,1)=1 AND TRIM(COALESCE(category,''))<>'' ORDER BY category COLLATE NOCASE")
        return [str(r['category']) for r in rows if str(r['category'] or '').strip()]
    except Exception:
        return []


AppService.list_products = _v4514_list_products
AppService.list_products_for_sale = _v4514_list_products_for_sale
AppService.get_product_by_barcode = _v4514_get_product_by_barcode
AppService.get_product_for_pos = _v4514_get_product_for_pos
AppService.low_stock_details = _v4514_low_stock_details
AppService.low_stock_rows = _v4514_low_stock_details
AppService.product_categories = _v4514_product_categories
