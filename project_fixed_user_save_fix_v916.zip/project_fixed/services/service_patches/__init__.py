"""Feature patch loader for Max Sales v1.0.0 Stable.

This package loads existing AppService feature extensions such as reports,
backup, tools and UI helpers. It is not a persistence fallback layer. Sales and
finance writes remain native-only through ``services.domain.persistence``.
"""
from __future__ import annotations

PATCH_MODULES = [
    'services.service_patches.v11_safety',
    'services.service_patches.v13_readiness',
    'services.service_patches.v19_gdrive',
    'services.service_patches.v20_gdrive_settings',
    'services.service_patches.v21_backup',
    'services.service_patches.v22_gdrive_final',
    'services.service_patches.v23_business_tools',
    'services.service_patches.v24_smart_assistant',
    'services.service_patches.v25_readiness',
    'services.service_patches.v25_1_barcode',
    'services.service_patches.v26_tools_repair',
    'services.service_patches.v26_1_tools_stability',
    'services.service_patches.v27_pricing_excel_qr',
    'services.service_patches.v30_safe_delete',
    'services.service_patches.v31_goals_dates',
    'services.service_patches.v32_4_debt_guard',
    'services.service_patches.v33_commercial_features',
    'services.service_patches.v34_permissions_offers',
    'services.service_patches.v40_pos_enhancements',
    'services.service_patches.v41_cashier_shifts',
    'services.service_patches.v44_accounting_clean_release',
    'services.service_patches.smart_archive_security_ai',
    'services.service_patches.stability_safety',
    'services.service_patches.portability_decimal_hardening',
    'services.service_patches.integrity_security_finance',
    'services.service_patches.shared_refactor',
    'services.service_patches.products_inventory_fix',
    'services.service_patches.products_row_dict_compat',
    'services.service_patches.final_quality_fixes',
    'services.service_patches.permissions_barcode_audit',
    'services.service_patches.promotions_alerts_reports_print_ai_archive',
    'services.service_patches.security_integrity_fixes',
    'services.service_patches.deep_report_fixes',
    'services.service_patches.price_delete_accounting_fixes',
    'services.service_patches.high_security_fixes',
    'services.service_patches.medium_security_fixes',
    'services.service_patches.barcode_ai_upgrade',
    'services.service_patches.fraud_coupons_dashboard_audit',
    'services.service_patches.security_operations_hardening',
    'services.service_patches.integrity_coupon_fraud_perf',
    'services.service_patches.cleanup_consolidation',
    'services.service_patches.movement_log_tools',
    'services.service_patches.barcode_customer_speed_movements',
    'services.service_patches.movement_center',
    'services.service_patches.stability_cleanup',
    'services.service_patches.final_cleanup_audit_fix',
    'services.service_patches.native_sales_finance_adapters',
    'services.service_patches.v46_1_ui_reporting_payment_fixes',
    'services.service_patches.return_financial_reconciliation',
    'services.service_patches.tools_movement_optimization',
    'services.service_patches.v46_3_tools_movement_completion',
]


def apply_all_patches() -> None:
    import importlib
    for module_name in PATCH_MODULES:
        importlib.import_module(module_name)

    from services.domain.domain_bridge import install_domain_bridge
    install_domain_bridge()

    # Loaded after the domain bridge because the bridge reinstalls domain methods.
    importlib.import_module('services.service_patches.v46_12_movement_details_enhancement')

    # Final reporting guard: loaded after the domain bridge so wrappers remain active.
    importlib.import_module('services.service_patches.report_quantity_total_fix')

    # Final user-role templates and discount-policy UI support.
    importlib.import_module('services.service_patches.v46_14_user_role_templates')

    # Manager approval for large discounts / below-cost sales.
    importlib.import_module('services.service_patches.v46_15_manager_approval')

__all__ = ['PATCH_MODULES', 'apply_all_patches']
