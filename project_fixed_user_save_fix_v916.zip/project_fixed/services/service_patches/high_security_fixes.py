from __future__ import annotations

"""V45.17.4.1 high-severity hardening patch.

Built only on the v45.17.4 line. It fixes high-risk issues reported after
v45.17.4 without importing v45.17.5+ UI changes.
"""

from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from pathlib import Path
import os
import shutil
import sqlite3
import tempfile
from typing import Any

from services.app_core import AppService
from services.error_logger import log_exception, log_message
from database import now_text

_ORIG_INIT = AppService.__init__
_ORIG_COMPLETE_SALE = getattr(AppService, 'complete_sale', None)
_ORIG_BACKUP_DATABASE = getattr(AppService, 'backup_database', None)
_ORIG_RESTORE_DATABASE = getattr(AppService, 'restore_database', None)
_ORIG_EMPLOYEE_GOAL_ROWS = getattr(AppService, 'employee_goal_rows', None)
_ORIG_BACKUP_DIR = getattr(AppService, 'backup_dir', None)

MONEY = Decimal('0.01')


def _d(value: Any, default: str = '0') -> Decimal:
    try:
        if value is None or str(value).strip() == '':
            value = default
        return Decimal(str(value).replace(',', '').strip()).quantize(MONEY, rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError):
        return Decimal(default).quantize(MONEY, rounding=ROUND_HALF_UP)


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(float(value or default))
    except Exception:
        return default


def _rowdict(row: Any) -> dict[str, Any]:
    if row is None:
        return {}
    if isinstance(row, dict):
        return dict(row)
    try:
        return dict(row)
    except Exception:
        try:
            return {k: row[k] for k in row.keys()}
        except Exception:
            return {}


def _has_column(conn, table: str, col: str) -> bool:
    try:
        return col in {r[1] for r in conn.execute(f'PRAGMA table_info({table})')}
    except Exception:
        return False


def _ensure_column(conn, table: str, col: str, ddl: str) -> None:
    if not _has_column(conn, table, col):
        conn.execute(f'ALTER TABLE {table} ADD COLUMN {col} {ddl}')


def _safe_contains_path(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except Exception:
        return False


def _backup_root() -> Path:
    path = Path(os.path.expanduser('~/MaxSales_Backups')).resolve()
    path.mkdir(parents=True, exist_ok=True)
    return path


def _legacy_backup_root() -> Path:
    path = Path('backups').resolve()
    path.mkdir(parents=True, exist_ok=True)
    return path


def _validate_sqlite_file(path: Path) -> None:
    if not path.exists() or not path.is_file():
        raise ValueError('ملف النسخة الاحتياطية غير موجود')
    if path.stat().st_size <= 0:
        raise ValueError('ملف النسخة الاحتياطية فارغ')
    conn = None
    try:
        conn = sqlite3.connect(path)
        row = conn.execute('PRAGMA quick_check').fetchone()
        result = str(row[0] if row else '')
        if result.lower() != 'ok':
            raise ValueError(f'فشل فحص سلامة قاعدة البيانات: {result}')
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        required = {'users', 'products', 'sales'}
        if not required.issubset(tables):
            raise ValueError('ملف النسخة لا يبدو قاعدة بيانات Max Sales صالحة')
    except sqlite3.Error as exc:
        raise ValueError(f'ملف النسخة الاحتياطية غير صالح أو تالف: {exc}') from exc
    finally:
        if conn is not None:
            conn.close()


def _fernet_key_path() -> Path:
    return _backup_root() / '.maxsales_backup.key'


def _get_fernet():
    try:
        from cryptography.fernet import Fernet  # type: ignore
    except Exception as exc:
        raise RuntimeError('مكتبة cryptography غير مثبتة. شغل install_requirements.bat لتفعيل تشفير النسخ الاحتياطي.') from exc
    key_path = _fernet_key_path()
    if key_path.exists():
        key = key_path.read_bytes().strip()
    else:
        key = Fernet.generate_key()
        key_path.write_bytes(key)
        try:
            os.chmod(key_path, 0o600)
        except Exception:
            pass
    return Fernet(key)


def _encrypt_file(src: Path, dst: Path) -> Path:
    f = _get_fernet()
    dst.write_bytes(f.encrypt(src.read_bytes()))
    return dst


def _decrypt_to_temp(src: Path) -> Path:
    f = _get_fernet()
    data = f.decrypt(src.read_bytes())
    fd, name = tempfile.mkstemp(prefix='maxsales_restore_', suffix='.db')
    os.close(fd)
    out = Path(name)
    out.write_bytes(data)
    return out


def _safe_query_one(conn, sql: str, params=()):
    return conn.execute(sql, tuple(params)).fetchone()


def _is_credit_method(payment_method: str) -> bool:
    text = str(payment_method or '').strip().lower()
    return any(word in text for word in ('آجل', 'اجل', 'دين', 'credit'))


def _current_customer_debt(conn, customer_id: int) -> Decimal:
    row = conn.execute('''
        WITH credit AS (
            SELECT SUM(CASE
                WHEN (COALESCE(subtotal,0)-COALESCE(discount_amount,0)+COALESCE(tax_amount,0)) < 0 THEN 0
                ELSE (COALESCE(subtotal,0)-COALESCE(discount_amount,0)+COALESCE(tax_amount,0))
            END) v
            FROM sales
            WHERE customer_id=? AND payment_method='آجل' AND status='completed'
        ),
        payments AS (
            SELECT SUM(COALESCE(amount,0)) v FROM customer_payments WHERE customer_id=?
        ),
        returned AS (
            SELECT SUM(COALESCE(r.amount,0)) v
            FROM returns r JOIN sales s ON s.id=r.sale_id
            WHERE s.customer_id=?
        )
        SELECT COALESCE(credit.v,0)-COALESCE(payments.v,0)-COALESCE(returned.v,0) balance
        FROM credit, payments, returned
    ''', (customer_id, customer_id, customer_id)).fetchone()
    return _d(row['balance'] if row else 0)


def _validate_cart_inside_lock(self: AppService, conn, cart: list[dict], user_id: int | None) -> tuple[Decimal, Decimal]:
    if not cart:
        raise ValueError('السلة فارغة')
    subtotal = Decimal('0.00')
    db_subtotal = Decimal('0.00')
    for item in cart:
        product_id = _as_int(item.get('product_id'))
        qty = _d(item.get('quantity'))
        if product_id <= 0 or qty <= 0:
            raise ValueError('يوجد صنف غير صالح في السلة')
        row = conn.execute('''SELECT id, name, quantity, sale_price, cost_price, active
                              FROM products WHERE id=?''', (product_id,)).fetchone()
        if not row or int(row['active'] or 0) != 1:
            raise ValueError(f"المنتج غير موجود أو معطل: {item.get('product_name', product_id)}")
        current_qty = _d(row['quantity'])
        if qty > current_qty:
            raise ValueError(f"المخزون غير كافٍ: {row['name']} (متاح: {row['quantity']}, مطلوب: {item.get('quantity')})")

        db_sale = _d(row['sale_price'])
        db_cost = _d(row['cost_price'])
        item_price = _d(item.get('unit_price', db_sale))
        if item_price <= 0:
            raise ValueError(f"سعر البيع غير صالح للمنتج: {row['name']}")
        if db_sale <= 0:
            raise ValueError(f"سعر البيع في قاعدة البيانات غير صالح للمنتج: {row['name']}")
        if abs(item_price - db_sale) > MONEY:
            # Any manual cart price override must be explicitly permitted.
            self.require_permission('can_price_edit', user_id, 'تغيير سعر منتج داخل الفاتورة')
        if item_price < db_cost:
            self.require_permission('can_discount_limit', user_id, 'البيع بأقل من سعر الشراء')
            raise ValueError(f"سعر البيع أقل من تكلفة المنتج: {row['name']}")

        subtotal += (qty * item_price).quantize(MONEY, rounding=ROUND_HALF_UP)
        db_subtotal += (qty * db_sale).quantize(MONEY, rounding=ROUND_HALF_UP)
    return subtotal, db_subtotal


def _new_complete_sale(self: AppService, cart: list[dict], employee_id: int, customer_id: int | None,
                       payment_method: str, discount_amount: float = 0, note: str = '',
                       user_id: int | None = None, discount_type: str = 'amount', coupon_code: str = '') -> str:
    user = self.require_any_permission(('can_sales', 'can_touch_pos'), user_id, 'إتمام البيع')
    user_id = int(user['id'])
    if _ORIG_COMPLETE_SALE is None:
        raise RuntimeError('دالة البيع الأساسية غير متوفرة')

    conn = self.db.conn
    began = False
    try:
        if not conn.in_transaction:
            conn.execute('BEGIN IMMEDIATE')
            began = True
        subtotal, _db_subtotal = _validate_cart_inside_lock(self, conn, cart or [], user_id)

        # Credit-limit validation must happen while the DB write lock is held so
        # another POS cannot add an آجل invoice between debt check and save.
        if _is_credit_method(payment_method):
            if not customer_id:
                raise ValueError('يجب اختيار زبون عند البيع الآجل')
            customer = conn.execute('SELECT id, active, credit_limit FROM customers WHERE id=?', (int(customer_id),)).fetchone()
            if not customer or int(customer['active'] or 0) != 1:
                raise ValueError('الزبون غير موجود أو معطل')
            credit_limit = _d(customer['credit_limit'] if 'credit_limit' in customer.keys() else 0)
            if credit_limit > 0:
                current_debt = _current_customer_debt(conn, int(customer_id))
                discount_value = max(_d(discount_amount), Decimal('0.00'))
                if str(discount_type or '').lower() == 'percent':
                    if discount_value > 100:
                        raise ValueError('نسبة الخصم لا يمكن أن تكون أكبر من 100%')
                    new_discount = (subtotal * discount_value / Decimal('100')).quantize(MONEY, rounding=ROUND_HALF_UP)
                else:
                    new_discount = discount_value
                new_invoice_total = max(subtotal - new_discount, Decimal('0.00'))
                if current_debt + new_invoice_total > credit_limit:
                    raise ValueError(
                        f'تجاوز حد الائتمان: الرصيد الحالي {current_debt:,.0f} د.ع + '
                        f'الفاتورة {new_invoice_total:,.0f} د.ع > الحد {credit_limit:,.0f} د.ع'
                    )

        try:
            return _ORIG_COMPLETE_SALE(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type, coupon_code)
        except TypeError:
            return _ORIG_COMPLETE_SALE(self, cart, employee_id, customer_id, payment_method, discount_amount, note, user_id, discount_type)
    except Exception:
        if conn.in_transaction:
            conn.rollback()
        raise
    finally:
        if began and conn.in_transaction:
            # Some historical sale implementations commit themselves via with conn.
            # If a transaction is still open here, finish it cleanly.
            conn.commit()


def _backup_dir(self: AppService) -> Path:
    return _backup_root()


def _backup_database(self: AppService) -> Path:
    self.require_permission('can_backup', action='إنشاء نسخة احتياطية')
    root = _backup_root()
    temp_db = root / f'max_sales_backup_plain_{datetime.now().strftime("%Y%m%d_%H%M%S")}.db'
    encrypted = root / f'max_sales_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.maxbak'
    backup_conn = None
    try:
        backup_conn = sqlite3.connect(temp_db)
        self.db.conn.backup(backup_conn)
    finally:
        if backup_conn is not None:
            backup_conn.close()
    _validate_sqlite_file(temp_db)
    try:
        _encrypt_file(temp_db, encrypted)
        temp_db.unlink(missing_ok=True)
        target = encrypted
    except Exception as exc:
        log_exception(exc, 'فشل تشفير النسخة الاحتياطية، تم حفظ نسخة SQLite عادية')
        target = root / f'max_sales_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.db'
        shutil.move(str(temp_db), str(target))
    backups = sorted(list(root.glob('max_sales_backup_*.maxbak')) + list(root.glob('max_sales_backup_*.db')), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[10:]:
        try:
            old.unlink()
        except Exception as exc:
            log_exception(exc, 'تنظيف النسخ الاحتياطية القديمة')
    self.log('نسخة احتياطية مشفرة' if target.suffix == '.maxbak' else 'نسخة احتياطية', str(target))
    return target


def _restore_database(self: AppService, source: Path | str) -> None:
    self.require_permission('can_restore', action='استرجاع نسخة احتياطية')
    src = Path(source).expanduser().resolve()
    allowed_roots = [_backup_root(), _legacy_backup_root()]
    if not any(_safe_contains_path(src, root) for root in allowed_roots):
        raise ValueError('مسار النسخة غير مسموح به. ضع النسخة داخل مجلد النسخ الاحتياطي أولاً.')
    if not src.exists() or not src.is_file():
        raise ValueError('ملف النسخة الاحتياطية غير موجود')

    temp_decrypted: Path | None = None
    try:
        if src.suffix.lower() == '.maxbak':
            temp_decrypted = _decrypt_to_temp(src)
            candidate = temp_decrypted
        else:
            candidate = src
        _validate_sqlite_file(candidate)
        self.db.close()
        shutil.copy2(candidate, self.db.path)
    finally:
        if temp_decrypted is not None:
            try:
                temp_decrypted.unlink(missing_ok=True)
            except Exception:
                pass


def _goal_period_bounds(self: AppService, goal) -> tuple[str, str]:
    return self._goal_period_bounds(goal['period_type'], goal['period_start'])


def _employee_goal_rows(self: AppService, user=None):
    if _ORIG_EMPLOYEE_GOAL_ROWS is None:
        return []
    # Faster than the old N+1 path for common goal dashboards: precompute common
    # sales/returns aggregates per employee-period once, then reuse them.
    params: list[Any] = []
    where = 'g.active=1'
    if user is not None and not self.is_admin_user(user):
        employee_id = self.employee_id_for_user(user)
        if not employee_id:
            return []
        where += ' AND g.employee_id=?'
        params.append(employee_id)
    goals = [dict(r) for r in self.db.all(f'''
        SELECT g.*, e.name employee, p.name product_name
        FROM employee_goals g
        JOIN employees e ON e.id=g.employee_id
        LEFT JOIN products p ON p.id=g.target_product_id
        WHERE {where}
        ORDER BY g.id DESC
    ''', params)]
    if not goals:
        return []

    cache: dict[tuple, dict[str, Decimal]] = {}
    product_cache: dict[tuple, Decimal] = {}
    for g in goals:
        try:
            start, end = self._goal_period_bounds(g['period_type'], g['period_start'])
        except Exception:
            continue
        key = (int(g['employee_id']), start, end)
        if key not in cache:
            emp, s, e = key
            sales = self.db.one('''SELECT COALESCE(SUM(total),0) sales, COALESCE(SUM(total_profit),0) profit, COUNT(*) invoices
                                   FROM sales WHERE employee_id=? AND created_at>=? AND created_at<? AND status='completed' ''', (emp, s, e))
            returns = self.db.one('''SELECT COALESCE(SUM(amount),0) amount, COALESCE(SUM(profit_amount),0) profit, COALESCE(SUM(quantity),0) qty
                                     FROM returns WHERE employee_id=? AND created_at>=? AND created_at<?''', (emp, s, e))
            sold_qty = self.db.one('''SELECT COALESCE(SUM(si.quantity),0) qty
                                      FROM sale_items si JOIN sales s ON s.id=si.sale_id
                                      WHERE s.employee_id=? AND s.created_at>=? AND s.created_at<? AND s.status='completed' ''', (emp, s, e))
            cache[key] = {
                'sales': _d(sales['sales'] if sales else 0) - _d(returns['amount'] if returns else 0),
                'profit': _d(sales['profit'] if sales else 0) - _d(returns['profit'] if returns else 0),
                'invoices': _d(sales['invoices'] if sales else 0),
                'sold_qty': max(_d(sold_qty['qty'] if sold_qty else 0) - _d(returns['qty'] if returns else 0), Decimal('0')),
                'returns_amount': _d(returns['amount'] if returns else 0),
            }
        if g.get('goal_type') == 'بيع منتج معين' and g.get('target_product_id'):
            pkey = (int(g['employee_id']), start, end, int(g['target_product_id']))
            if pkey not in product_cache:
                emp, s, e, pid = pkey
                sold = self.db.one('''SELECT COALESCE(SUM(si.quantity),0) qty
                                      FROM sale_items si JOIN sales s ON s.id=si.sale_id
                                      WHERE s.employee_id=? AND s.created_at>=? AND s.created_at<? AND s.status='completed' AND si.product_id=?''', (emp, s, e, pid))
                ret = self.db.one('''SELECT COALESCE(SUM(quantity),0) qty FROM returns
                                     WHERE employee_id=? AND created_at>=? AND created_at<? AND product_id=?''', (emp, s, e, pid))
                product_cache[pkey] = max(_d(sold['qty'] if sold else 0) - _d(ret['qty'] if ret else 0), Decimal('0'))

    result = []
    for g in goals:
        try:
            start, end = self._goal_period_bounds(g['period_type'], g['period_start'])
            key = (int(g['employee_id']), start, end)
            agg = cache.get(key, {})
            goal_type = g.get('goal_type') or 'مبيعات'
            if goal_type == 'أرباح':
                achieved = agg.get('profit', Decimal('0'))
            elif goal_type == 'عدد فواتير':
                achieved = agg.get('invoices', Decimal('0'))
            elif goal_type == 'عدد منتجات مباعة':
                achieved = agg.get('sold_qty', Decimal('0'))
            elif goal_type == 'بيع منتج معين' and g.get('target_product_id'):
                achieved = product_cache.get((int(g['employee_id']), start, end, int(g['target_product_id'])), Decimal('0'))
            elif goal_type == 'تقليل المرتجعات':
                achieved = max(_d(g.get('target_sales')) - agg.get('returns_amount', Decimal('0')), Decimal('0'))
            elif goal_type == 'تحصيل ديون':
                row = self.db.one('SELECT COALESCE(SUM(amount),0) v FROM customer_payments WHERE created_at>=? AND created_at<? AND status="completed"', (start, end))
                achieved = _d(row['v'] if row else 0)
            else:
                achieved = agg.get('sales', Decimal('0'))
            target = _d(g.get('target_sales'))
            ratio = (achieved / target * Decimal('100')) if target > 0 else Decimal('0')
            remaining = max(target - achieved, Decimal('0'))
            reward = _d(self._goal_reward(g, float(achieved), float(ratio))) if hasattr(self, '_goal_reward') else Decimal('0')
            row = dict(g)
            row['achieved'] = float(achieved)
            row['ratio'] = float(ratio)
            row['remaining'] = float(remaining)
            row['reward_amount'] = float(reward)
            row['status_text'] = '✅ مكتمل' if ratio >= 100 else ('🔥 قريب جداً' if ratio >= 80 else ('⚠️ متأخر' if ratio < 50 else 'قيد المتابعة'))
            result.append(row)
        except Exception as exc:
            log_exception(exc, 'حساب هدف موظف')
    return result


def _ensure_schema(self: AppService) -> None:
    conn = self.db.conn
    _ensure_column(conn, 'customers', 'credit_limit', 'REAL NOT NULL DEFAULT 0')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_sales_invoice_no_v451741 ON sales(invoice_no)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_sales_emp_date_v451741 ON sales(employee_id, created_at)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_returns_emp_date_v451741 ON returns(employee_id, created_at)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_sale_items_sale_product_v451741 ON sale_items(sale_id, product_id)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_customer_payments_customer_v451741 ON customer_payments(customer_id, created_at)')
    conn.commit()


def _init(self: AppService, *args, **kwargs):
    _ORIG_INIT(self, *args, **kwargs)
    try:
        _ensure_schema(self)
    except Exception as exc:
        log_exception(exc, 'v45.17.4.1 schema hardening')


AppService.__init__ = _init
AppService.complete_sale = _new_complete_sale
AppService.backup_dir = _backup_dir
AppService.backup_database = _backup_database
AppService.restore_database = _restore_database
AppService.employee_goal_rows = _employee_goal_rows
