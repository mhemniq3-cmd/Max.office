from __future__ import annotations

from datetime import date
from services.app_core import AppService
from services.error_logger import log_exception

# V34: professional fine-grained permissions + advanced promotion dashboard/statistics.
NEW_PERMS = {
    'can_register_return': 'تسجيل مرتجع',
    'can_repay_debt': 'تسديد دين',
    'can_adjust_product_qty': 'تعديل كمية منتج',
    'can_disable_product': 'حذف/تعطيل منتج',
    'can_view_activity_logs': 'رؤية سجل العمليات',
    'can_manage_offers': 'إدارة العروض',
}

# Map new permissions to older permissions so existing databases continue to work.
FALLBACK_PERMS = {
    'can_register_return': 'can_returns',
    'can_repay_debt': 'can_receive_debt_payment',
    'can_adjust_product_qty': 'can_quantity_edit',
    'can_disable_product': 'can_product_delete',
    'can_view_activity_logs': 'can_audit',
    'can_manage_offers': 'can_manage_promotions',
}

_ORIG_INIT = AppService.__init__
_ORIG_ROLES = AppService.roles
_ORIG_ROLE_PERMISSIONS = AppService.role_permissions
_ORIG_USER_HAS = AppService.user_has
_ORIG_RETURN_ITEM = AppService.return_item
_ORIG_RETURN_FULL_SALE = AppService.return_full_sale
_ORIG_ADD_PAYMENT = AppService.add_payment
_ORIG_ADD_SUPPLIER_PAYMENT = AppService.add_supplier_payment
_ORIG_DELETE_OR_DEACTIVATE_PRODUCT = getattr(AppService, 'delete_or_deactivate_product', None)
_ORIG_ADJUST_INVENTORY = AppService.adjust_inventory
_ORIG_SAVE_PROMOTION = AppService.save_promotion
_ORIG_DEACTIVATE_PROMOTION = AppService.deactivate_promotion
_ORIG_LIST_PROMOTIONS = AppService.list_promotions


def _ensure_v34_schema(self: AppService) -> None:
    for col in list(NEW_PERMS) + ['can_reprint_invoice', 'can_cancel_invoice', 'can_receive_debt_payment', 'can_manage_promotions']:
        try:
            self.db.add_column_if_missing('users', col, 'INTEGER NOT NULL DEFAULT 0')
        except Exception as exc:
            log_exception(exc)
    for table, col, sql in [
        ('promotions', 'coupon_code', 'TEXT'),
        ('promotions', 'manager_only', 'INTEGER NOT NULL DEFAULT 0'),
        ('promotions', 'stopped_at', 'TEXT'),
        ('promotions', 'stopped_by_user_id', 'INTEGER'),
        ('promotions', 'status_note', 'TEXT'),
    ]:
        try:
            self.db.add_column_if_missing(table, col, sql)
        except Exception as exc:
            log_exception(exc)
    try:
        # Grant full fine-grained permissions to managers/admins in existing databases.
        all_cols = list(NEW_PERMS) + ['can_reprint_invoice', 'can_cancel_invoice', 'can_receive_debt_payment', 'can_manage_promotions']
        set_sql = ', '.join(f'{c}=1' for c in all_cols)
        self.db.execute(f"UPDATE users SET {set_sql} WHERE role='مدير' OR username='admin'")
    except Exception as exc:
        log_exception(exc)


def _init(self: AppService, db):
    _ORIG_INIT(self, db)
    _ensure_v34_schema(self)


def _roles(self: AppService):
    roles = list(_ORIG_ROLES(self))
    for r in ('مشرف', 'مستخدم تقارير فقط'):
        if r not in roles:
            roles.append(r)
    return roles


def _role_permissions(self: AppService, role: str):
    data = dict(_ORIG_ROLE_PERMISSIONS(self, role))
    # Always expose the new keys to save_user and the permissions UI.
    for key in NEW_PERMS:
        data.setdefault(key, 0)
    # Normalize aliases requested by the user.
    if role == 'مدير':
        for key in data:
            if key.startswith('can_'):
                data[key] = 1
        for key in NEW_PERMS:
            data[key] = 1
    elif role == 'كاشير':
        data.update(
            can_dashboard=1, can_sales=1, can_touch_pos=1, can_customers=1,
            can_print=1, can_discount=1,
            can_view_cost=0, can_view_profit=0, can_price_edit=0, can_discount_limit=0,
            can_register_return=0, can_cancel_invoice=0, can_reprint_invoice=0,
            can_repay_debt=0, can_view_activity_logs=0, can_manage_offers=0,
        )
    elif role == 'محاسب':
        data.update(
            can_dashboard=1, can_customers=1, can_reports=1, can_tools=1,
            can_view_cost=1, can_view_profit=1, can_print=1,
            can_reprint_invoice=1, can_repay_debt=1, can_receive_debt_payment=1,
            can_view_activity_logs=1, can_audit=1,
        )
    elif role == 'مخزن':
        data.update(
            can_dashboard=1, can_products=1, can_inventory=1, can_suppliers=1, can_purchases=1,
            can_product_add=1, can_product_edit=1, can_adjust_product_qty=1, can_quantity_edit=1,
            can_disable_product=1, can_product_delete=1, can_view_cost=1,
            can_reports=0, can_view_profit=0, can_users=0,
        )
    elif role == 'مشرف':
        data.update(
            can_dashboard=1, can_sales=1, can_touch_pos=1, can_products=1, can_customers=1,
            can_returns=1, can_register_return=1, can_reports=1, can_tools=1,
            can_print=1, can_reprint_invoice=1, can_cancel_invoice=1, can_discount=1,
            can_discount_limit=1, can_repay_debt=1, can_receive_debt_payment=1,
            can_manage_offers=1, can_manage_promotions=1, can_view_activity_logs=1, can_audit=1,
            can_view_cost=0, can_view_profit=0, can_users=0, can_settings=0,
        )
    elif role == 'مستخدم تقارير فقط':
        data.update(
            can_dashboard=1, can_reports=1, can_view_profit=1, can_view_cost=1,
            can_print=1, can_reprint_invoice=1, can_view_activity_logs=1,
            can_sales=0, can_products=0, can_customers=0, can_users=0, can_tools=0,
        )
    return data


def _user_has(self: AppService, user, permission: str) -> bool:
    if permission in NEW_PERMS:
        try:
            if self.is_admin_user(user):
                return True
            return bool(user[permission]) or bool(_ORIG_USER_HAS(self, user, FALLBACK_PERMS.get(permission, permission)))
        except Exception:
            return bool(_ORIG_USER_HAS(self, user, FALLBACK_PERMS.get(permission, permission)))
    return _ORIG_USER_HAS(self, user, permission)


def _return_item(self: AppService, sale_item_id: int, quantity: int, reason: str = '', user_id: int | None = None, refund_method: str = 'نقدي'):
    self.require_any_permission(('can_register_return', 'can_returns'), user_id, 'تسجيل مرتجع')
    return _ORIG_RETURN_ITEM(self, sale_item_id, quantity, reason, user_id, refund_method)


def _return_full_sale(self: AppService, sale_id: int, reason: str = '', user_id: int | None = None, refund_method: str = 'نقدي'):
    self.require_any_permission(('can_register_return', 'can_return_full'), user_id, 'تسجيل مرتجع كامل')
    return _ORIG_RETURN_FULL_SALE(self, sale_id, reason, user_id, refund_method)


def _add_payment(self: AppService, customer_id: int, amount: float, note: str = '') -> int:
    self.require_any_permission(('can_repay_debt', 'can_receive_debt_payment'), action='تسديد دين زبون')
    return _ORIG_ADD_PAYMENT(self, customer_id, amount, note)


def _add_supplier_payment(self: AppService, supplier_id: int, amount: float, note: str = '', user_id: int | None = None) -> int:
    self.require_any_permission(('can_repay_debt', 'can_receive_debt_payment'), user_id, 'تسديد دين مورد')
    return _ORIG_ADD_SUPPLIER_PAYMENT(self, supplier_id, amount, note, user_id)


def _adjust_inventory(self: AppService, product_id: int, new_quantity: int, note: str = '', user_id: int | None = None) -> None:
    self.require_any_permission(('can_adjust_product_qty', 'can_quantity_edit', 'can_inventory'), user_id, 'تعديل كمية منتج')
    return _ORIG_ADJUST_INVENTORY(self, product_id, new_quantity, note, user_id)


def _delete_or_deactivate_product(self: AppService, product_id: int, actor_user_id: int | None = None, reason: str = '') -> str:
    self.require_any_permission(('can_disable_product', 'can_product_delete'), actor_user_id, 'حذف/تعطيل منتج')
    if _ORIG_DELETE_OR_DEACTIVATE_PRODUCT:
        return _ORIG_DELETE_OR_DEACTIVATE_PRODUCT(self, product_id, actor_user_id, reason)
    self.db.execute('UPDATE products SET active=0 WHERE id=?', (int(product_id),))
    self.log('تعطيل منتج', f'{product_id} | السبب: {reason}', actor_user_id)
    return 'تم تعطيل المنتج.'


def _save_promotion(self: AppService, data: dict, promo_id: int | None = None, user_id: int | None = None) -> int:
    user = self.require_any_permission(('can_manage_offers', 'can_manage_promotions'), user_id, 'إدارة العروض')
    out = _ORIG_SAVE_PROMOTION(self, data, promo_id, user['id'])
    try:
        coupon = str(data.get('coupon_code') or '').strip()
        manager_only = 1 if data.get('manager_only') else 0
        note = str(data.get('status_note') or '').strip()
        self.db.execute('UPDATE promotions SET coupon_code=?, manager_only=?, status_note=? WHERE id=?', (coupon, manager_only, note, out))
    except Exception as exc:
        log_exception(exc)
    return out


def _deactivate_promotion(self: AppService, promo_id: int, user_id: int | None = None) -> None:
    user = self.require_any_permission(('can_manage_offers', 'can_manage_promotions'), user_id, 'إيقاف عرض')
    _ORIG_DEACTIVATE_PROMOTION(self, promo_id, user['id'])
    try:
        self.db.execute('UPDATE promotions SET stopped_at=datetime("now"), stopped_by_user_id=? WHERE id=?', (user['id'], int(promo_id)))
    except Exception as exc:
        log_exception(exc)


def _list_promotions(self: AppService, active_only: bool = False):
    # Reports/sales may read offers, but management still requires manage permission above.
    return _ORIG_LIST_PROMOTIONS(self, active_only)


def _promotion_scope_label(row) -> str:
    scope = row.get('scope_type') if hasattr(row, 'get') else row['scope_type']
    if scope == 'all':
        return 'كل المنتجات'
    if scope == 'product':
        return row.get('product_name', '') if hasattr(row, 'get') else (row['product_name'] if 'product_name' in row.keys() else '')
    return row.get('category', '') if hasattr(row, 'get') else row['category']


def _promotions_by_status(self: AppService, today: str | None = None):
    self.require_any_permission(('can_manage_offers', 'can_manage_promotions', 'can_reports', 'can_tools'), action='عرض حالة العروض')
    today = today or date.today().isoformat()
    rows = [dict(r) for r in _ORIG_LIST_PROMOTIONS(self, False)]
    out = {'active': [], 'upcoming': [], 'expired': [], 'stopped': []}
    for r in rows:
        active = bool(r.get('active'))
        start = str(r.get('start_date') or '')
        end = str(r.get('end_date') or '')
        if not active:
            bucket = 'stopped'
        elif start and start > today:
            bucket = 'upcoming'
        elif end and end < today:
            bucket = 'expired'
        else:
            bucket = 'active'
        r['scope_label'] = _promotion_scope_label(r)
        out[bucket].append(r)
    return out


def _promotion_usage_stats(self: AppService, promo_id: int | None = None, date_from: str = '', date_to: str = ''):
    self.require_any_permission(('can_manage_offers', 'can_manage_promotions', 'can_reports'), action='عرض إحصائيات العروض')
    where = ['si.promotion_id IS NOT NULL']
    params: list[object] = []
    if promo_id:
        where.append('si.promotion_id=?')
        params.append(int(promo_id))
    if date_from:
        where.append('date(s.created_at)>=date(?)')
        params.append(date_from)
    if date_to:
        where.append('date(s.created_at)<=date(?)')
        params.append(date_to)
    where_sql = ' AND '.join(where)
    summary = self.db.all(f'''
        SELECT pr.id, pr.name, pr.scope_type, COALESCE(p.name,'') product_name, pr.category, pr.promo_type,
               COUNT(DISTINCT s.id) used_invoices,
               COUNT(si.id) used_lines,
               COALESCE(SUM(si.quantity),0) total_qty,
               COALESCE(SUM(si.promotion_discount_amount),0) total_discount,
               COALESCE(SUM(si.profit_amount),0) total_profit
        FROM sale_items si
        JOIN sales s ON s.id=si.sale_id
        LEFT JOIN promotions pr ON pr.id=si.promotion_id
        LEFT JOIN products p ON p.id=pr.product_id
        WHERE {where_sql} AND s.status='completed'
        GROUP BY pr.id, pr.name
        ORDER BY total_discount DESC, used_lines DESC
    ''', params)
    products = self.db.all(f'''
        SELECT si.promotion_id, si.product_name, SUM(si.quantity) qty,
               SUM(si.promotion_discount_amount) discount_amount,
               SUM(si.profit_amount) profit_amount
        FROM sale_items si
        JOIN sales s ON s.id=si.sale_id
        WHERE {where_sql} AND s.status='completed'
        GROUP BY si.promotion_id, si.product_id, si.product_name
        ORDER BY discount_amount DESC, qty DESC
        LIMIT 200
    ''', params)
    by_promo: dict[int, list[dict]] = {}
    for p in products:
        pid = int(p['promotion_id'] or 0)
        by_promo.setdefault(pid, []).append(dict(p))
    result = []
    for r in summary:
        item = dict(r)
        item['scope_label'] = _promotion_scope_label(item)
        item['products'] = by_promo.get(int(item.get('id') or 0), [])
        result.append(item)
    return result


AppService.__init__ = _init
AppService.roles = _roles
AppService.role_permissions = _role_permissions
AppService.user_has = _user_has
AppService.return_item = _return_item
AppService.return_full_sale = _return_full_sale
AppService.add_payment = _add_payment
AppService.add_supplier_payment = _add_supplier_payment
AppService.adjust_inventory = _adjust_inventory
AppService.delete_or_deactivate_product = _delete_or_deactivate_product
AppService.save_promotion = _save_promotion
AppService.deactivate_promotion = _deactivate_promotion
AppService.list_promotions = _list_promotions
AppService.promotions_by_status = _promotions_by_status
AppService.promotion_usage_stats = _promotion_usage_stats
