from __future__ import annotations

"""Final return reconciliation for Max Sales v1.0.0.

A return must affect three places consistently:
- inventory: quantity goes back to stock,
- returns: return document is stored,
- sales/reporting: the original invoice remaining total/profit/commission are reduced.

Older UI/report paths read directly from ``sales.total`` and ``sales.total_profit``.
This patch reconciles those fields after every return and before report reads, so
reports stay correct even if a return entered through an older service wrapper.
"""

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from functools import wraps
from typing import Any, Callable

from services.app_core import AppService

CENT = Decimal("0.01")
ZERO = Decimal("0.00")


def _D(value: Any) -> Decimal:
    try:
        return Decimal(str(value if value is not None else "0").replace(",", "").strip() or "0")
    except (InvalidOperation, ValueError, TypeError):
        return ZERO


def _money(value: Any) -> float:
    return float(_D(value).quantize(CENT, rounding=ROUND_HALF_UP))


def _one(self: AppService, sql: str, params: tuple[Any, ...] = ()) -> Any:
    return self.db.one(sql, params)


def _all(self: AppService, sql: str, params: tuple[Any, ...] = ()) -> list[Any]:
    return list(self.db.all(sql, params) or [])


def _execute(self: AppService, sql: str, params: tuple[Any, ...] = ()) -> None:
    self.db.execute(sql, params)


def _sale_has_returns(self: AppService, sale_id: int) -> bool:
    row = _one(self, "SELECT COUNT(*) c FROM returns WHERE sale_id=?", (int(sale_id),))
    return bool(row and int(row["c"] or 0) > 0)


def reconcile_sale_financials(self: AppService, sale_id: int) -> dict[str, float]:
    """Recalculate remaining invoice total/profit/commission after returns.

    The invoice original commercial basis remains ``subtotal``,
    ``discount_amount`` and ``tax_amount``.  Returns are stored separately in
    ``returns``.  The remaining values displayed by dashboards/reports are:

        original invoice net - returned amount
        original item profit - returned profit
        original item commission - returned commission
    """
    sale_id = int(sale_id)
    sale = _one(self, "SELECT id, subtotal, discount_amount, tax_amount FROM sales WHERE id=?", (sale_id,))
    if not sale:
        return {"total": 0.0, "profit": 0.0, "commission": 0.0}

    item_totals = _one(
        self,
        """
        SELECT COALESCE(SUM(line_total),0) subtotal,
               COALESCE(SUM(profit_amount),0) profit,
               COALESCE(SUM(commission_amount),0) commission
        FROM sale_items WHERE sale_id=?
        """,
        (sale_id,),
    ) or {}
    return_totals = _one(
        self,
        """
        SELECT COALESCE(SUM(amount),0) amount,
               COALESCE(SUM(profit_amount),0) profit,
               COALESCE(SUM(commission_amount),0) commission
        FROM returns WHERE sale_id=?
        """,
        (sale_id,),
    ) or {}

    original_subtotal = _D(sale["subtotal"])
    if original_subtotal == ZERO:
        original_subtotal = _D(item_totals["subtotal"] if item_totals else 0)
    original_total = original_subtotal - _D(sale["discount_amount"]) + _D(sale["tax_amount"])
    remaining_total = max(original_total - _D(return_totals["amount"]), ZERO)
    remaining_commission = max(_D(item_totals["commission"]) - _D(return_totals["commission"]), ZERO)
    # Profit can legitimately be negative in a loss sale, so do not clamp it to
    # zero unless the invoice is fully returned and floating noise leaves cents.
    remaining_profit = _D(item_totals["profit"]) - _D(return_totals["profit"])
    if abs(remaining_profit) < Decimal("0.005"):
        remaining_profit = ZERO

    values = {
        "total": _money(remaining_total),
        "profit": _money(remaining_profit),
        "commission": _money(remaining_commission),
    }
    _execute(
        self,
        "UPDATE sales SET total=?, total_profit=?, total_commission=? WHERE id=?",
        (values["total"], values["profit"], values["commission"], sale_id),
    )
    return values


def reconcile_sales_with_returns(self: AppService, limit: int | None = None) -> int:
    sql = "SELECT DISTINCT sale_id FROM returns WHERE sale_id IS NOT NULL ORDER BY sale_id DESC"
    params: tuple[Any, ...] = ()
    if limit:
        sql += " LIMIT ?"
        params = (int(limit),)
    rows = _all(self, sql, params)
    count = 0
    for row in rows:
        try:
            reconcile_sale_financials(self, int(row["sale_id"]))
            count += 1
        except Exception:
            # Reporting reconciliation must not block the user interface.
            continue
    return count


_ORIG_RETURN_ITEM = getattr(AppService, "return_item", None)
_ORIG_RETURN_FULL_SALE = getattr(AppService, "return_full_sale", None)
_ORIG_DASHBOARD = getattr(AppService, "dashboard", None)
_ORIG_LIST_SALES = getattr(AppService, "list_sales", None)
_ORIG_MANAGEMENT_REPORT = getattr(AppService, "management_report", None)
_ORIG_SALES_SUMMARY = getattr(AppService, "sales_summary", None)
_ORIG_PROFIT_SUMMARY = getattr(AppService, "profit_summary", None)
_ORIG_FIND_SALE_FOR_RETURN = getattr(AppService, "find_sale_for_return", None)


def _sale_id_from_return_no(self: AppService, return_no: Any) -> int | None:
    row = _one(self, "SELECT sale_id FROM returns WHERE return_no=?", (str(return_no),))
    return int(row["sale_id"]) if row and row["sale_id"] is not None else None


def _wrap_return_item(fn: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(fn)
    def wrapper(self: AppService, sale_item_id: int, quantity: int, reason: str = "", user_id: int | None = None, refund_method: str = "نقدي") -> Any:
        result = fn(self, sale_item_id, quantity, reason, user_id, refund_method)
        sale_id = _sale_id_from_return_no(self, result)
        if sale_id is not None:
            reconcile_sale_financials(self, sale_id)
        return result
    return wrapper


def _wrap_return_full_sale(fn: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(fn)
    def wrapper(self: AppService, sale_id: int, reason: str = "", user_id: int | None = None, refund_method: str = "نقدي") -> Any:
        result = fn(self, sale_id, reason, user_id, refund_method)
        reconcile_sale_financials(self, int(sale_id))
        return result
    return wrapper


def _wrap_report(fn: Callable[..., Any], *, limit: int | None = 1000) -> Callable[..., Any]:
    @wraps(fn)
    def wrapper(self: AppService, *args: Any, **kwargs: Any) -> Any:
        reconcile_sales_with_returns(self, limit=limit)
        return fn(self, *args, **kwargs)
    return wrapper


def _wrap_find_sale_for_return(fn: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(fn)
    def wrapper(self: AppService, invoice: str) -> Any:
        result = fn(self, invoice)
        try:
            sale = result[0]
            sale_id = int(sale["id"])
            if _sale_has_returns(self, sale_id):
                reconcile_sale_financials(self, sale_id)
                result = fn(self, invoice)
        except Exception:
            pass
        return result
    return wrapper


if callable(_ORIG_RETURN_ITEM):
    AppService.return_item = _wrap_return_item(_ORIG_RETURN_ITEM)
if callable(_ORIG_RETURN_FULL_SALE):
    AppService.return_full_sale = _wrap_return_full_sale(_ORIG_RETURN_FULL_SALE)
if callable(_ORIG_DASHBOARD):
    AppService.dashboard = _wrap_report(_ORIG_DASHBOARD)
if callable(_ORIG_LIST_SALES):
    AppService.list_sales = _wrap_report(_ORIG_LIST_SALES)
if callable(_ORIG_MANAGEMENT_REPORT):
    AppService.management_report = _wrap_report(_ORIG_MANAGEMENT_REPORT)
if callable(_ORIG_SALES_SUMMARY):
    AppService.sales_summary = _wrap_report(_ORIG_SALES_SUMMARY)
if callable(_ORIG_PROFIT_SUMMARY):
    AppService.profit_summary = _wrap_report(_ORIG_PROFIT_SUMMARY)
if callable(_ORIG_FIND_SALE_FOR_RETURN):
    AppService.find_sale_for_return = _wrap_find_sale_for_return(_ORIG_FIND_SALE_FOR_RETURN)

AppService.reconcile_sale_financials = reconcile_sale_financials
AppService.reconcile_sales_with_returns = reconcile_sales_with_returns
