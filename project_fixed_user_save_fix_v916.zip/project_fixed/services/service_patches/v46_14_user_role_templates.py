"""Role templates and discount-permission persistence for the users screen.

This patch keeps the existing users table and UI compatible while adding the
fields needed by the secure discount policy:
- max_discount_percent
- can_discount_below_cost
"""
from __future__ import annotations

from typing import Any

from services.app_core import AppService


ROLE_TEMPLATES: dict[str, dict[str, Any]] = {
    "كاشير": {
        "label": "🟡 كاشير",
        "max_discount_percent": 10.0,
        "can_discount_below_cost": 0,
        "perms": dict(
            can_dashboard=1, can_sales=1, can_touch_pos=1, can_customers=1,
            can_discount=1, can_print=1,
        ),
    },
    "موظف مبيعات": {
        "label": "🟢 موظف مبيعات",
        "max_discount_percent": 15.0,
        "can_discount_below_cost": 0,
        "perms": dict(
            can_dashboard=1, can_sales=1, can_touch_pos=1, can_customers=1,
            can_discount=1, can_print=1,
        ),
    },
    "مدير": {
        "label": "🔴 مدير / مالك",
        "max_discount_percent": 100.0,
        "can_discount_below_cost": 1,
        "all_permissions": True,
        "perms": {},
    },
}


def _columns(self: AppService) -> set[str]:
    try:
        return {str(row[1]) for row in self.db.conn.execute("PRAGMA table_info(users)")}
    except Exception:
        return set()


def _ensure_user_discount_columns(self: AppService) -> None:
    cols = _columns(self)
    additions = []
    if "can_discount_below_cost" not in cols:
        additions.append(("can_discount_below_cost", "INTEGER NOT NULL DEFAULT 0"))
    if "max_discount_percent" not in cols:
        additions.append(("max_discount_percent", "REAL NOT NULL DEFAULT 0"))
    for name, definition in additions:
        self.db.execute(f"ALTER TABLE users ADD COLUMN {name} {definition}")

    # Keep old databases aligned with safe defaults. Only fill empty/zero max limits
    # so manually tuned user limits are not overwritten.
    try:
        self.db.execute("UPDATE users SET max_discount_percent=100, can_discount_below_cost=1, can_discount_limit=1 WHERE role='مدير' OR username='admin'")
        self.db.execute("UPDATE users SET max_discount_percent=10, can_discount_below_cost=0 WHERE role='كاشير' AND COALESCE(max_discount_percent,0)=0")
        self.db.execute("UPDATE users SET max_discount_percent=15, can_discount_below_cost=0 WHERE role='موظف مبيعات' AND COALESCE(max_discount_percent,0)=0")
    except Exception:
        pass


def _permission_keys(self: AppService) -> list[str]:
    return sorted(col for col in _columns(self) if col.startswith("can_"))


def _role_key(role: str) -> str:
    text = str(role or "").strip()
    if text in {"مدير", "مدير النظام", "مالك", "admin", "administrator"}:
        return "مدير"
    if text in {"موظف مبيعات", "مبيعات", "مندوب مبيعات"}:
        return "موظف مبيعات"
    return "كاشير"


_ORIG_ROLES = AppService.roles
_ORIG_ROLE_PERMISSIONS = AppService.role_permissions
_ORIG_SAVE_USER = AppService.save_user
_ORIG_LIST_USERS = AppService.list_users


def _roles_v46_14(self: AppService) -> list[str]:
    return ["كاشير", "موظف مبيعات", "مدير"]


def _role_permissions_v46_14(self: AppService, role: str) -> dict[str, int]:
    _ensure_user_discount_columns(self)
    keys = _permission_keys(self)
    base = {key: 0 for key in keys}
    role_name = _role_key(role)
    template = ROLE_TEMPLATES[role_name]
    if template.get("all_permissions"):
        return {key: 1 for key in keys}
    for key, value in template.get("perms", {}).items():
        if key in base:
            base[key] = 1 if value else 0
    if "can_discount_below_cost" in base:
        base["can_discount_below_cost"] = int(template.get("can_discount_below_cost", 0))
    if role_name != "مدير" and "can_discount_limit" in base:
        base["can_discount_limit"] = 0
    return base


def _role_template_v46_14(self: AppService, role: str) -> dict[str, Any]:
    role_name = _role_key(role)
    perms = _role_permissions_v46_14(self, role_name)
    template = ROLE_TEMPLATES[role_name]
    return {
        "role": role_name,
        "label": template["label"],
        "permissions": perms,
        "max_discount_percent": float(template.get("max_discount_percent", 0)),
        "can_discount_below_cost": int(template.get("can_discount_below_cost", 0)),
    }


def _save_user_v46_14(self: AppService, data: dict, user_id: int | None = None) -> None:
    _ensure_user_discount_columns(self)
    role_name = _role_key(data.get("role") or "كاشير")
    data = dict(data)
    data["role"] = role_name
    template = _role_template_v46_14(self, role_name)
    if "max_discount_percent" not in data or data.get("max_discount_percent") in (None, ""):
        data["max_discount_percent"] = template["max_discount_percent"]
    if "can_discount_below_cost" not in data:
        data["can_discount_below_cost"] = template["can_discount_below_cost"]
    if "can_discount_limit" not in data:
        data["can_discount_limit"] = 1 if role_name == "مدير" else 0

    _ORIG_SAVE_USER(self, data, user_id)

    target_id = user_id
    if not target_id:
        row = self.db.one("SELECT id FROM users WHERE username=?", ((data.get("username") or "").strip(),))
        target_id = int(row["id"]) if row else None
    if target_id:
        max_discount = float(data.get("max_discount_percent") or 0)
        below_cost = 1 if data.get("can_discount_below_cost") else 0
        special_discount = 1 if data.get("can_discount_limit") else 0
        # If selling below cost is allowed, special discount must also be allowed.
        if below_cost:
            special_discount = 1
        self.db.execute(
            "UPDATE users SET max_discount_percent=?, can_discount_below_cost=?, can_discount_limit=? WHERE id=?",
            (max_discount, below_cost, special_discount, int(target_id)),
        )
        try:
            self.log("تحديث صلاحيات مستخدم", f"تم حفظ قالب {role_name} وحد الخصم {max_discount}%", target_id)
        except Exception:
            pass


def _list_users_v46_14(self: AppService, include_inactive: bool = True):
    _ensure_user_discount_columns(self)
    return _ORIG_LIST_USERS(self, include_inactive)


def _apply_default_role_templates_to_users_v46_14(self: AppService) -> int:
    self.require_permission("can_users", action="تطبيق قوالب الصلاحيات")
    _ensure_user_discount_columns(self)
    rows = self.db.all("SELECT id, username, role FROM users")
    count = 0
    for row in rows:
        role_name = _role_key(row["role"] or "كاشير")
        if str(row["username"] or "").strip().lower() == "admin":
            role_name = "مدير"
        template = _role_template_v46_14(self, role_name)
        perms = template["permissions"]
        assignments = []
        params = []
        for key, value in perms.items():
            if key in _columns(self):
                assignments.append(f"{key}=?")
                params.append(1 if value else 0)
        if "max_discount_percent" in _columns(self):
            assignments.append("max_discount_percent=?")
            params.append(float(template["max_discount_percent"]))
        if "can_discount_below_cost" in _columns(self):
            assignments.append("can_discount_below_cost=?")
            params.append(1 if template["can_discount_below_cost"] else 0)
        assignments.append("role=?")
        params.append(role_name)
        params.append(int(row["id"]))
        if assignments:
            self.db.execute(f"UPDATE users SET {', '.join(assignments)} WHERE id=?", params)
            count += 1
    try:
        self.log("تطبيق قوالب الصلاحيات", f"تم تحديث {count} مستخدم")
    except Exception:
        pass
    return count


AppService.roles = _roles_v46_14
AppService.role_permissions = _role_permissions_v46_14
AppService.role_template = _role_template_v46_14
AppService.save_user = _save_user_v46_14
AppService.list_users = _list_users_v46_14
AppService.apply_default_role_templates_to_users = _apply_default_role_templates_to_users_v46_14
