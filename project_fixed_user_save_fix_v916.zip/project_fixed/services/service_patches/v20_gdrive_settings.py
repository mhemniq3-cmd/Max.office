from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})
import services.service_patches.v19_gdrive as _prev_v19_gdrive
globals().update({k: v for k, v in vars(_prev_v19_gdrive).items() if not k.startswith('__')})

# ================================================================
# V20 GOOGLE DRIVE BACKUP SETTINGS FIX
# Adds a small JSON mirror for the Google Drive backup settings and
# validates the selected folder using the current UI value, not only DB cache.
# ================================================================

_GDRIVE_CONFIG_FILE = Path('google_drive_backup_settings.json')

def _save_google_drive_backup_settings_v20(self: AppService, enabled: bool, path: str, user_id: int | None = None) -> None:
    enabled_value = '1' if enabled else '0'
    path_value = str(path or '').strip()
    self.save_settings({
        'google_drive_backup_enabled': enabled_value,
        'google_drive_backup_path': path_value,
    }, user_id)
    try:
        _GDRIVE_CONFIG_FILE.write_text(json.dumps({
            'google_drive_backup_enabled': enabled_value,
            'google_drive_backup_path': path_value,
        }, ensure_ascii=False, indent=2), encoding='utf-8')
    except Exception as exc:
        self.log('تحذير حفظ إعدادات Google Drive', str(exc), user_id)


def _load_google_drive_backup_settings_v20(self: AppService) -> dict:
    settings = self.get_settings()
    db_enabled = str(settings.get('google_drive_backup_enabled', '0') or '0')
    db_path = str(settings.get('google_drive_backup_path', '') or '').strip()
    if db_path:
        return {
            'google_drive_backup_enabled': db_enabled,
            'google_drive_backup_path': db_path,
            'last_google_drive_backup_status': settings.get('last_google_drive_backup_status', '') or '',
        }
    try:
        if _GDRIVE_CONFIG_FILE.exists():
            data = json.loads(_GDRIVE_CONFIG_FILE.read_text(encoding='utf-8'))
            cfg_path = str(data.get('google_drive_backup_path', '') or '').strip()
            cfg_enabled = str(data.get('google_drive_backup_enabled', db_enabled) or db_enabled)
            if cfg_path:
                self.save_settings({
                    'google_drive_backup_enabled': cfg_enabled,
                    'google_drive_backup_path': cfg_path,
                })
                return {
                    'google_drive_backup_enabled': cfg_enabled,
                    'google_drive_backup_path': cfg_path,
                    'last_google_drive_backup_status': settings.get('last_google_drive_backup_status', '') or '',
                }
    except Exception as exc:
        self.log('تحذير قراءة إعدادات Google Drive', str(exc))
    return {
        'google_drive_backup_enabled': db_enabled,
        'google_drive_backup_path': db_path,
        'last_google_drive_backup_status': settings.get('last_google_drive_backup_status', '') or '',
    }


def _test_google_drive_backup_path_v20(self: AppService, path: str | None = None) -> tuple[bool, str]:
    raw = str(path if path is not None else self.load_google_drive_backup_settings().get('google_drive_backup_path', '')).strip()
    if not raw:
        msg = 'لم يتم اختيار مجلد Google Drive'
        self.save_settings({'last_google_drive_backup_status': msg})
        return False, msg
    try:
        p = Path(raw).expanduser()
        if not p.exists():
            return False, f'المجلد غير موجود: {p}'
        if not p.is_dir():
            return False, f'المسار المختار ليس مجلداً: {p}'
        test_file = p / 'max_sales_google_drive_test.txt'
        test_file.write_text('Max Sales Google Drive backup test', encoding='utf-8')
        if not test_file.exists():
            return False, 'تعذر إنشاء ملف اختبار داخل المجلد'
        try:
            test_file.unlink()
        except Exception as exc:
            log_exception(exc)
        msg = f'المجلد جاهز للنسخ: {p}'
        self.save_settings({'last_google_drive_backup_status': msg})
        return True, msg
    except Exception as exc:
        msg = f'تعذر استخدام المجلد: {exc}'
        self.save_settings({'last_google_drive_backup_status': msg})
        return False, msg

AppService.save_google_drive_backup_settings = _save_google_drive_backup_settings_v20
AppService.load_google_drive_backup_settings = _load_google_drive_backup_settings_v20
AppService.test_google_drive_backup_path = _test_google_drive_backup_path_v20

# Replace V19 backup implementation so it reads the mirrored config too.
def _backup_database_gdrive_v20(self: AppService) -> Path:
    local_path = _orig_backup_database_gdrive(self)
    cfg = self.load_google_drive_backup_settings()
    enabled = _is_gdrive_enabled_value(cfg.get('google_drive_backup_enabled', '0'))
    target_dir_raw = str(cfg.get('google_drive_backup_path', '') or '').strip()
    if not enabled:
        return local_path
    if not target_dir_raw:
        msg = 'تم تفعيل نسخ Google Drive لكن لم يتم اختيار مجلد Google Drive'
        self.save_settings({'last_google_drive_backup_status': msg})
        self.log('فشل نسخ Google Drive', msg)
        return local_path
    try:
        target_dir = Path(target_dir_raw).expanduser()
        if not target_dir.exists() or not target_dir.is_dir():
            raise ValueError(f'مجلد Google Drive غير موجود: {target_dir}')
        target = target_dir / local_path.name
        shutil.copy2(local_path, target)
        status = f'ناجح: {target}'
        self.save_settings({'last_google_drive_backup_status': status})
        self.log('نسخ احتياطي Google Drive', status)
    except Exception as exc:
        status = f'فشل: {exc}'
        self.save_settings({'last_google_drive_backup_status': status})
        self.log('فشل نسخ Google Drive', status)
    return local_path

AppService.backup_database = _backup_database_gdrive_v20

