from __future__ import annotations

"""Repair and guard sales totals where reports used unit price for multi-quantity lines.

Some legacy/UI paths could leave ``sale_items.line_total`` equal to the unit
price when quantity was greater than one.  Reports then showed 5,000 for a line
sold as 3 x 5,000 instead of 15,000.  This patch repairs obvious bad rows and
reconciles invoice totals before report reads.
"""

from functools import wraps
from typing import Any, Callable

from services.app_core import AppService

CENT_TOLERANCE = 0.01


def _columns(self: AppService, table: str) -> set[str]:
    try:
        return {str(row[1]) for row in self.db.conn.execute(f"PRAGMA table_info({table})")}
    except Exception:
        return set()


def _line_has_discount_column(self: AppService) -> bool:
    return "discount_amount" in _columns(self, "sale_items")


def repair_sale_quantity_totals(self: AppService, sale_id: int | None = None) -> int:
    """Fix obvious line_total anomalies and update invoice totals.

    Only rows matching the safe anomaly pattern are changed:
    quantity > 1, unit_price > 0, and line_total is approximately equal to
    unit_price.  If an item-level discount column exists and has a positive
    value, the row is left untouched to avoid overriding intentional discounts.
    """
    if not hasattr(self, "db") or not hasattr(self.db, "conn"):
        return 0
    cols = _columns(self, "sale_items")
    if not {"id", "sale_id", "quantity", "unit_price", "line_total"}.issubset(cols):
        return 0

    params: tuple[Any, ...] = ()
    where = "WHERE COALESCE(quantity,0) > 1 AND COALESCE(unit_price,0) > 0"
    if sale_id is not None:
        where += " AND sale_id=?"
        params = (int(sale_id),)

    rows = list(self.db.conn.execute(
        f"SELECT id, sale_id, quantity, unit_price, line_total"
        + (", discount_amount" if _line_has_discount_column(self) else "")
        + f" FROM sale_items {where}",
        params,
    ))
    changed_sale_ids: set[int] = set()
    fixed = 0
    for row in rows:
        qty = float(row["quantity"] or 0)
        unit = float(row["unit_price"] or 0)
        current = float(row["line_total"] or 0)
        item_discount = float(row["discount_amount"] or 0) if "discount_amount" in row.keys() else 0.0
        if item_discount > 0:
            continue
        if abs(current - unit) <= CENT_TOLERANCE:
            expected = round(qty * unit, 2)
            if abs(expected - current) > CENT_TOLERANCE:
                self.db.conn.execute("UPDATE sale_items SET line_total=? WHERE id=?", (expected, int(row["id"])))
                changed_sale_ids.add(int(row["sale_id"]))
                fixed += 1

    if not changed_sale_ids:
        return 0

    sales_cols = _columns(self, "sales")
    for sid in changed_sale_ids:
        sale = self.db.conn.execute("SELECT * FROM sales WHERE id=?", (sid,)).fetchone()
        if not sale:
            continue
        subtotal_row = self.db.conn.execute("SELECT COALESCE(SUM(line_total),0) v FROM sale_items WHERE sale_id=?", (sid,)).fetchone()
        subtotal = round(float(subtotal_row["v"] or 0), 2)
        discount = float(sale["discount_amount"] or 0) if "discount_amount" in sales_cols else 0.0
        tax = float(sale["tax_amount"] or 0) if "tax_amount" in sales_cols else 0.0
        total = max(round(subtotal - discount + tax, 2), 0.0)
        assignments = []
        values: list[Any] = []
        if "subtotal" in sales_cols:
            assignments.append("subtotal=?")
            values.append(subtotal)
        if "total" in sales_cols:
            assignments.append("total=?")
            values.append(total)
        if assignments:
            values.append(sid)
            self.db.conn.execute(f"UPDATE sales SET {', '.join(assignments)} WHERE id=?", tuple(values))
    try:
        self.db.conn.commit()
    except Exception:
        pass
    return fixed


def repair_all_quantity_totals(self: AppService, limit: int | None = None) -> int:
    # limit is accepted for compatibility with report wrappers; anomaly scan is
    # narrow and indexed enough for normal store databases.
    return repair_sale_quantity_totals(self, None)


def _sale_id_by_invoice(self: AppService, invoice_no: Any) -> int | None:
    try:
        row = self.db.one("SELECT id FROM sales WHERE invoice_no=?", (str(invoice_no),))
        return int(row["id"]) if row else None
    except Exception:
        return None


def _wrap_complete_sale(fn: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(fn)
    def wrapper(self: AppService, *args: Any, **kwargs: Any) -> Any:
        invoice = fn(self, *args, **kwargs)
        try:
            sid = _sale_id_by_invoice(self, invoice)
            if sid is not None:
                repair_sale_quantity_totals(self, sid)
        except Exception:
            pass
        return invoice
    return wrapper


def _wrap_report(fn: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(fn)
    def wrapper(self: AppService, *args: Any, **kwargs: Any) -> Any:
        try:
            repair_all_quantity_totals(self)
        except Exception:
            pass
        return fn(self, *args, **kwargs)
    return wrapper


for _name in ("dashboard", "list_sales", "management_report", "sales_summary", "profit_summary", "advanced_reports", "interactive_dashboard_data", "daily_business_report"):
    _fn = getattr(AppService, _name, None)
    if callable(_fn):
        setattr(AppService, _name, _wrap_report(_fn))

_complete = getattr(AppService, "complete_sale", None)
if callable(_complete):
    AppService.complete_sale = _wrap_complete_sale(_complete)

AppService.repair_sale_quantity_totals = repair_sale_quantity_totals
AppService.repair_all_quantity_totals = repair_all_quantity_totals
