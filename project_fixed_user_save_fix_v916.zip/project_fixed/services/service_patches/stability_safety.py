from __future__ import annotations

"""V45.9 runtime stability and accounting safety patch.

Keeps the restored v44 visual design and adds guards around sensitive runtime
paths: dependencies, cart data, discount math, zero values, and missing keys.
"""

from typing import Any

from services.app_core import AppService
from services.core_common import money
from services.error_logger import log_exception


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(float(value))
    except Exception:
        return default


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _clean_text(value: Any, max_len: int = 500) -> str:
    text = str(value or '').strip()
    return text[:max_len] if len(text) > max_len else text


def _normalize_cart_from_database(self: AppService, cart: list[dict]) -> list[dict]:
    if not cart:
        raise ValueError('السلة فارغة')
    clean: list[dict] = []
    for raw in cart:
        if not isinstance(raw, dict):
            raise ValueError('يوجد سطر غير صالح داخل السلة')
        product_id = _safe_int(raw.get('product_id'))
        quantity = _safe_int(raw.get('quantity'))
        if product_id <= 0:
            raise ValueError('يوجد منتج غير صالح داخل السلة')
        if quantity <= 0:
            raise ValueError('كمية البيع يجب أن تكون أكبر من صفر')
        product = self.db.one('''
            SELECT id, name, cost_price, sale_price, quantity, commission_percent, active
            FROM products
            WHERE id=? AND active=1
        ''', (product_id,))
        if not product:
            raise ValueError('يوجد منتج غير موجود أو معطل داخل السلة')
        official_price = _safe_float(product['sale_price'])
        requested_price = _safe_float(raw.get('unit_price'), official_price)
        unit_price = requested_price if requested_price > 0 else official_price
        if unit_price <= 0:
            raise ValueError(f"سعر المنتج غير صالح: {product['name']}")
        if _safe_int(product['quantity']) < quantity:
            raise ValueError(f"المخزون غير كاف للمنتج: {product['name']}")
        clean.append({
            'product_id': int(product['id']),
            'product_name': _clean_text(product['name'], 180),
            'quantity': quantity,
            'cost_price': max(_safe_float(product['cost_price']), 0.0),
            'unit_price': max(unit_price, 0.0),
            'commission_percent': max(_safe_float(product['commission_percent']), 0.0),
        })
    return clean


def _validate_discount(subtotal: float, discount_amount: float, discount_type: str) -> tuple[float, str]:
    dtype = 'percent' if str(discount_type or '').strip() == 'percent' else 'amount'
    value = max(_safe_float(discount_amount), 0.0)
    if subtotal <= 0:
        if value:
            raise ValueError('لا يمكن تطبيق خصم على فاتورة قيمتها صفر')
        return 0.0, dtype
    if dtype == 'percent':
        if value > 100:
            raise ValueError('نسبة الخصم لا يمكن أن تكون أكبر من 100%')
        real_discount = subtotal * value / 100.0
    else:
        if value > subtotal:
            raise ValueError(f'قيمة الخصم لا يمكن أن تكون أكبر من إجمالي الفاتورة. إجمالي الفاتورة: {money(subtotal)}')
        real_discount = value
    if real_discount >= subtotal:
        raise ValueError('الخصم لا يمكن أن يساوي أو يتجاوز قيمة الفاتورة')
    return real_discount, dtype


_prev_complete_sale_v459 = AppService.complete_sale


def _v459_complete_sale(self: AppService, cart: list[dict], employee_id: int, customer_id: int | None, payment_method: str, discount_amount: float = 0, note: str = '', user_id: int | None = None, discount_type: str = 'amount') -> str:
    clean_cart = _normalize_cart_from_database(self, cart or [])
    subtotal = sum(float(i['quantity']) * float(i['unit_price']) for i in clean_cart)
    _real_discount, dtype = _validate_discount(subtotal, discount_amount, discount_type)
    try:
        return _prev_complete_sale_v459(
            self,
            clean_cart,
            int(employee_id or 0),
            int(customer_id) if customer_id else None,
            _clean_text(payment_method, 40) or 'نقدي',
            discount_amount,
            _clean_text(note, 1000),
            user_id,
            dtype,
        )
    except KeyError as exc:
        log_exception(exc)
        raise ValueError(f'بيانات الفاتورة ناقصة: {exc}') from exc
    except ZeroDivisionError as exc:
        log_exception(exc)
        raise ValueError('تعذر الحساب بسبب قيمة صفرية غير صالحة في الفاتورة') from exc


AppService.complete_sale = _v459_complete_sale


_prev_suspend_sale_v459 = AppService.suspend_sale


def _v459_suspend_sale(self: AppService, cart: list[dict], employee_id: int | None, customer_id: int | None, payment_method: str, discount_amount: float, note: str = '', user_id: int | None = None) -> str:
    clean_cart = _normalize_cart_from_database(self, cart or [])
    subtotal = sum(float(i['quantity']) * float(i['unit_price']) for i in clean_cart)
    _validate_discount(subtotal, discount_amount, 'amount')
    return _prev_suspend_sale_v459(self, clean_cart, employee_id, customer_id, _clean_text(payment_method, 40) or 'نقدي', discount_amount, _clean_text(note, 1000), user_id)


AppService.suspend_sale = _v459_suspend_sale


_prev_owner_dashboard_snapshot_v459 = getattr(AppService, 'owner_dashboard_snapshot', None)


def _v459_owner_dashboard_snapshot(self: AppService):
    if not callable(_prev_owner_dashboard_snapshot_v459):
        return {}
    try:
        data = _prev_owner_dashboard_snapshot_v459(self)
        data.setdefault('today', {})
        data.setdefault('month', {})
        data.setdefault('debt_estimate', 0.0)
        data.setdefault('open_security_alerts', 0)
        data.setdefault('low_stock_products', 0)
        data.setdefault('top_products', [])
        return data
    except Exception as exc:
        log_exception(exc)
        return {
            'today': {'invoices': 0, 'sales': 0, 'profit': 0},
            'month': {'invoices': 0, 'sales': 0, 'profit': 0},
            'debt_estimate': 0.0,
            'open_security_alerts': 0,
            'low_stock_products': 0,
            'top_products': [],
        }


AppService.owner_dashboard_snapshot = _v459_owner_dashboard_snapshot
