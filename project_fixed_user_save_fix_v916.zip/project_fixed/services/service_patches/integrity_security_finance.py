from __future__ import annotations

"""V45.11 critical data-integrity, finance and security hardening.

This patch intentionally keeps the restored v44 visual design. It adds guards
around the highest-risk areas reported by the user:
- friendlier database open/corruption errors
- required-field and non-negative database triggers
- atomic, non-repeating invoice numbers based on document_counters
- stock updates that cannot become negative even under concurrent use
- cashier/accounting cash movements separated from invoices
- stricter profit calculation using current purchase cost at sale time
- category rename helper that updates products consistently
- backup compression/maintenance utilities
"""

import os
import sqlite3
import zipfile
from datetime import datetime, date
from decimal import Decimal
from pathlib import Path
from typing import Any

from db import database_core as _dbcore
from services.app_core import AppService
from services.core_common import now_text, money
from services.error_logger import log_exception, log_message
from services.service_patches import portability_decimal_hardening as v4510

PROJECT_ROOT = Path(__file__).resolve().parents[2]
BACKUP_DIR = PROJECT_ROOT / 'backups'
ARCHIVE_DIR = BACKUP_DIR / 'compressed'

_old_db_init_v4511 = _dbcore.Database.__init__


def _db_error_message(path: Path, exc: BaseException) -> str:
    raw = str(exc)
    if isinstance(exc, sqlite3.DatabaseError) and ('malformed' in raw.lower() or 'not a database' in raw.lower()):
        return f'قاعدة البيانات تالفة أو ليست ملف SQLite صالح: {path}'
    if isinstance(exc, PermissionError) or 'permission' in raw.lower() or 'readonly' in raw.lower():
        return f'لا توجد صلاحية قراءة/كتابة على قاعدة البيانات: {path}'
    if 'unable to open database file' in raw.lower():
        return f'تعذر فتح ملف قاعدة البيانات. تحقق من وجود المجلد والصلاحيات: {path}'
    return f'خطأ في الاتصال بقاعدة البيانات: {raw}'


def _install_v4511_schema(self: _dbcore.Database) -> None:
    self.conn.execute('PRAGMA foreign_keys = ON')
    self.conn.execute('PRAGMA busy_timeout = 15000')
    # Finance separation: invoices are documents; cash movements are ledger rows.
    self.conn.executescript('''
        CREATE TABLE IF NOT EXISTS cash_accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            account_type TEXT NOT NULL DEFAULT 'cash',
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS cash_movements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account_id INTEGER NOT NULL,
            movement_type TEXT NOT NULL,
            ref_type TEXT,
            ref_no TEXT,
            amount REAL NOT NULL CHECK(amount >= 0),
            payment_method TEXT,
            direction TEXT NOT NULL DEFAULT 'in',
            note TEXT,
            user_id INTEGER,
            created_at TEXT NOT NULL,
            FOREIGN KEY(account_id) REFERENCES cash_accounts(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        CREATE INDEX IF NOT EXISTS idx_cash_movements_ref ON cash_movements(ref_type, ref_no);
        CREATE INDEX IF NOT EXISTS idx_cash_movements_created ON cash_movements(created_at);
        CREATE INDEX IF NOT EXISTS idx_products_active_name ON products(active, name);
        CREATE INDEX IF NOT EXISTS idx_products_category_active ON products(category, active);
        CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id);
        CREATE INDEX IF NOT EXISTS idx_sales_invoice_no ON sales(invoice_no);
    ''')
    for name, account_type in [('الصندوق الرئيسي', 'cash'), ('مبيعات آجلة', 'credit'), ('تحويل/بطاقة', 'bank')]:
        self.conn.execute(
            'INSERT OR IGNORE INTO cash_accounts (name, account_type, active, created_at) VALUES (?, ?, 1, ?)',
            (name, account_type, now_text()),
        )

    # Triggers are used because SQLite cannot add CHECK constraints to existing tables.
    # They protect old and new code paths equally.
    self.conn.executescript('''
        CREATE TRIGGER IF NOT EXISTS trg_v4511_products_insert_guard
        BEFORE INSERT ON products
        BEGIN
            SELECT CASE WHEN trim(COALESCE(NEW.name,''))='' THEN RAISE(ABORT, 'اسم المنتج مطلوب') END;
            SELECT CASE WHEN COALESCE(NEW.cost_price,0) < 0 THEN RAISE(ABORT, 'سعر الشراء لا يمكن أن يكون سالباً') END;
            SELECT CASE WHEN COALESCE(NEW.sale_price,0) < 0 THEN RAISE(ABORT, 'سعر البيع لا يمكن أن يكون سالباً') END;
            SELECT CASE WHEN COALESCE(NEW.quantity,0) < 0 THEN RAISE(ABORT, 'كمية المنتج لا يمكن أن تكون سالبة') END;
            SELECT CASE WHEN COALESCE(NEW.min_quantity,0) < 0 THEN RAISE(ABORT, 'حد التنبيه لا يمكن أن يكون سالباً') END;
        END;
        CREATE TRIGGER IF NOT EXISTS trg_v4511_products_update_guard
        BEFORE UPDATE ON products
        BEGIN
            SELECT CASE WHEN trim(COALESCE(NEW.name,''))='' THEN RAISE(ABORT, 'اسم المنتج مطلوب') END;
            SELECT CASE WHEN COALESCE(NEW.cost_price,0) < 0 THEN RAISE(ABORT, 'سعر الشراء لا يمكن أن يكون سالباً') END;
            SELECT CASE WHEN COALESCE(NEW.sale_price,0) < 0 THEN RAISE(ABORT, 'سعر البيع لا يمكن أن يكون سالباً') END;
            SELECT CASE WHEN COALESCE(NEW.quantity,0) < 0 THEN RAISE(ABORT, 'كمية المنتج لا يمكن أن تكون سالبة') END;
            SELECT CASE WHEN COALESCE(NEW.min_quantity,0) < 0 THEN RAISE(ABORT, 'حد التنبيه لا يمكن أن يكون سالباً') END;
        END;
        CREATE TRIGGER IF NOT EXISTS trg_v4511_customers_insert_guard
        BEFORE INSERT ON customers
        BEGIN
            SELECT CASE WHEN trim(COALESCE(NEW.name,''))='' THEN RAISE(ABORT, 'اسم الزبون مطلوب') END;
        END;
        CREATE TRIGGER IF NOT EXISTS trg_v4511_employees_insert_guard
        BEFORE INSERT ON employees
        BEGIN
            SELECT CASE WHEN trim(COALESCE(NEW.name,''))='' THEN RAISE(ABORT, 'اسم الموظف مطلوب') END;
        END;
        CREATE TRIGGER IF NOT EXISTS trg_v4511_sales_insert_guard
        BEFORE INSERT ON sales
        BEGIN
            SELECT CASE WHEN trim(COALESCE(NEW.invoice_no,''))='' THEN RAISE(ABORT, 'رقم الفاتورة مطلوب') END;
            SELECT CASE WHEN COALESCE(NEW.subtotal,0) < 0 OR COALESCE(NEW.discount_amount,0) < 0 OR COALESCE(NEW.total,0) < 0 THEN RAISE(ABORT, 'قيم الفاتورة لا يمكن أن تكون سالبة') END;
        END;
        CREATE TRIGGER IF NOT EXISTS trg_v4511_sale_items_insert_guard
        BEFORE INSERT ON sale_items
        BEGIN
            SELECT CASE WHEN COALESCE(NEW.quantity,0) <= 0 THEN RAISE(ABORT, 'كمية سطر الفاتورة يجب أن تكون أكبر من صفر') END;
            SELECT CASE WHEN trim(COALESCE(NEW.product_name,''))='' THEN RAISE(ABORT, 'اسم المنتج في الفاتورة مطلوب') END;
            SELECT CASE WHEN COALESCE(NEW.unit_price,0) < 0 OR COALESCE(NEW.line_total,0) < 0 THEN RAISE(ABORT, 'قيم سطر الفاتورة لا يمكن أن تكون سالبة') END;
        END;
        CREATE TRIGGER IF NOT EXISTS trg_v4511_cash_movements_insert_guard
        BEFORE INSERT ON cash_movements
        BEGIN
            SELECT CASE WHEN COALESCE(NEW.amount,0) < 0 THEN RAISE(ABORT, 'حركة الصندوق لا يمكن أن تكون سالبة') END;
            SELECT CASE WHEN trim(COALESCE(NEW.movement_type,''))='' THEN RAISE(ABORT, 'نوع حركة الصندوق مطلوب') END;
        END;
    ''')
    self.conn.commit()


def _v4511_database_init(self: _dbcore.Database, path: Path | str | None = None):
    try:
        _old_db_init_v4511(self, path)
        _install_v4511_schema(self)
    except Exception as exc:
        try:
            db_path = Path(path or getattr(self, 'path', PROJECT_ROOT / 'database' / 'max_sales.db'))
        except Exception:
            db_path = PROJECT_ROOT / 'database' / 'max_sales.db'
        message = _db_error_message(db_path, exc)
        log_exception(exc, 'V45.11 database open/schema')
        raise RuntimeError(message) from exc


_dbcore.Database.__init__ = _v4511_database_init
try:
    import database as _database_facade
    _database_facade.Database = _dbcore.Database
except Exception:
    pass


def _clean(value: Any, max_len: int = 500) -> str:
    return str(value or '').strip()[:max_len]


def _payment_account_name(payment_method: str) -> str:
    text = str(payment_method or '').strip().lower()
    if any(word in text for word in ('آجل', 'اجل', 'دين', 'credit')):
        return 'مبيعات آجلة'
    if any(word in text for word in ('بطاقة', 'تحويل', 'كي كارد', 'visa', 'master', 'bank')):
        return 'تحويل/بطاقة'
    return 'الصندوق الرئيسي'


def _account_id(self: AppService, account_name: str) -> int:
    row = self.db.conn.execute('SELECT id FROM cash_accounts WHERE name=? AND active=1', (account_name,)).fetchone()
    if row:
        return int(row['id'])
    self.db.conn.execute('INSERT INTO cash_accounts (name, account_type, active, created_at) VALUES (?, ?, 1, ?)', (account_name, 'cash', now_text()))
    return int(self.db.conn.execute('SELECT id FROM cash_accounts WHERE name=?', (account_name,)).fetchone()['id'])


def _next_document_no(self: AppService, kind: str = 'sale', prefix: str = 'MAX') -> str:
    year = date.today().strftime('%Y')
    kind = _clean(kind, 30) or 'sale'
    prefix = _clean(prefix, 12).upper() or 'MAX'
    self.db.conn.execute(
        'INSERT OR IGNORE INTO document_counters (kind, year, last_number) VALUES (?, ?, 0)',
        (kind, year),
    )
    self.db.conn.execute(
        'UPDATE document_counters SET last_number = last_number + 1 WHERE kind=? AND year=?',
        (kind, year),
    )
    row = self.db.conn.execute('SELECT last_number FROM document_counters WHERE kind=? AND year=?', (kind, year)).fetchone()
    number = int(row['last_number'] if row else 1)
    return f'{prefix}-{year}-{number:06d}'


AppService.next_document_no = _next_document_no


def _v4511_complete_sale(self: AppService, cart: list[dict], employee_id: int, customer_id: int | None, payment_method: str, discount_amount: float = 0, note: str = '', user_id: int | None = None, discount_type: str = 'amount') -> str:
    user = self.require_any_permission(('can_sales', 'can_touch_pos'), user_id, 'إتمام البيع')
    user_id = int(user['id'])
    if not employee_id:
        raise ValueError('اختر الموظف الذي يستحق العمولة')
    employee = self.db.one('SELECT id, active FROM employees WHERE id=? AND active=1', (int(employee_id),))
    if not employee:
        raise ValueError('الموظف المختار غير موجود أو معطل')

    clean_cart = v4510._normalize_cart(self, cart or [])
    subtotal = v4510._money2(sum(v4510._D(i['quantity']) * i['unit_price'] for i in clean_cart))
    discount, dtype, discount_pct = v4510._discount_amount(subtotal, discount_amount, discount_type)
    taxable_base = max(subtotal - discount, Decimal('0'))
    tax_percent = max(v4510._D(self.get_settings().get('tax_percent', 0)), Decimal('0'))
    tax_amount = v4510._money2(taxable_base * tax_percent / Decimal('100'))
    total = v4510._money2(taxable_base + tax_amount)
    v4510._log_sale_security(self, clean_cart, subtotal, discount_pct, user_id)

    commission = Decimal('0')
    profit = Decimal('0')
    line_rows = []
    for item in clean_cart:
        # The current cost_price was reread from products by _normalize_cart.
        line_total = v4510._money2(v4510._D(item['quantity']) * item['unit_price'])
        line_discount = v4510._money2(discount * line_total / subtotal) if subtotal else Decimal('0')
        line_net = v4510._money2(line_total - line_discount)
        item_commission = v4510._money2(line_net * item['commission_percent'] / Decimal('100'))
        item_profit = v4510._money2(v4510._D(item['quantity']) * (item['unit_price'] - item['cost_price']) - line_discount)
        commission += item_commission
        profit += item_profit
        line_rows.append((item, line_total, item_commission, item_profit))
    commission = v4510._money2(commission)
    profit = v4510._money2(profit)
    safe_payment = _clean(payment_method, 40) or 'نقدي'
    safe_note = _clean(note, 1000)
    created = now_text()
    inv = ''

    with self.db.conn:
        inv = self.next_document_no('sale', 'MAX')
        cur = self.db.conn.execute('''
            INSERT INTO sales
            (invoice_no, user_id, employee_id, customer_id, subtotal, discount_amount, total, total_commission, total_profit, payment_method, discount_type, tax_amount, note, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (inv, user_id, int(employee_id), int(customer_id) if customer_id else None, v4510._to_db_money(subtotal), v4510._to_db_money(discount), v4510._to_db_money(total), v4510._to_db_money(commission), v4510._to_db_money(profit), safe_payment, dtype, v4510._to_db_money(tax_amount), safe_note, created))
        sale_id = int(cur.lastrowid)
        for item, line_total, item_commission, item_profit in line_rows:
            self.db.conn.execute('''
                INSERT INTO sale_items
                (sale_id, product_id, product_name, quantity, cost_price, unit_price, line_total, commission_percent, commission_amount, profit_amount)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (sale_id, item['product_id'], item['product_name'], item['quantity'], v4510._to_db_money(item['cost_price']), v4510._to_db_money(item['unit_price']), v4510._to_db_money(line_total), v4510._to_db_money(item['commission_percent']), v4510._to_db_money(item_commission), v4510._to_db_money(item_profit)))
            oldq_row = self.db.conn.execute('SELECT quantity FROM products WHERE id=? AND active=1', (item['product_id'],)).fetchone()
            oldq = int(oldq_row['quantity'] if oldq_row else 0)
            updated = self.db.conn.execute(
                'UPDATE products SET quantity = quantity - ? WHERE id=? AND active=1 AND quantity >= ?',
                (int(item['quantity']), item['product_id'], int(item['quantity'])),
            )
            if updated.rowcount != 1:
                raise ValueError(f"المخزون غير كاف أو تغير أثناء البيع للمنتج: {item['product_name']}")
            newq_row = self.db.conn.execute('SELECT quantity FROM products WHERE id=?', (item['product_id'],)).fetchone()
            newq = int(newq_row['quantity'] if newq_row else oldq - int(item['quantity']))
            self.db.conn.execute('''
                INSERT INTO inventory_movements
                (product_id, movement_type, quantity_change, old_quantity, new_quantity, ref_type, ref_no, note, user_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (item['product_id'], 'بيع', -int(item['quantity']), oldq, newq, 'sale', inv, '', user_id, created))
        account = _account_id(self, _payment_account_name(safe_payment))
        self.db.conn.execute('''
            INSERT INTO cash_movements
            (account_id, movement_type, ref_type, ref_no, amount, payment_method, direction, note, user_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (account, 'بيع', 'sale', inv, v4510._to_db_money(total), safe_payment, 'in', safe_note, user_id, created))
    self.log('بيع', inv, user_id)
    try:
        if hasattr(self, 'archive_sale_invoice'):
            self.archive_sale_invoice(inv)
    except Exception as exc:
        log_exception(exc, 'V45.11 archive sale')
    return inv


AppService.complete_sale = _v4511_complete_sale


def _v4511_cash_summary(self: AppService, date_from: str = '', date_to: str = '') -> list[dict]:
    self.require_any_permission(('can_reports', 'can_tools', 'can_audit'), action='عرض حركة الصندوق')
    where = []
    params: list[Any] = []
    if date_from:
        where.append('date(cm.created_at) >= date(?)')
        params.append(v4510._normalize_iso_date(date_from))
    if date_to:
        where.append('date(cm.created_at) <= date(?)')
        params.append(v4510._normalize_iso_date(date_to))
    sql = '''SELECT ca.name account, ca.account_type, SUM(CASE WHEN cm.direction='out' THEN -cm.amount ELSE cm.amount END) balance, COUNT(*) movements
             FROM cash_movements cm JOIN cash_accounts ca ON ca.id=cm.account_id'''
    if where:
        sql += ' WHERE ' + ' AND '.join(where)
    sql += ' GROUP BY ca.id, ca.name, ca.account_type ORDER BY ca.name'
    return [dict(r) for r in self.db.all(sql, params)]


AppService.cash_summary = _v4511_cash_summary


def _v4511_rename_product_category(self: AppService, old_name: str, new_name: str, user_id: int | None = None) -> int:
    user = self.require_permission('can_product_edit', user_id, 'تعديل مجموعة منتجات')
    old = _clean(old_name, 120)
    new = _clean(new_name, 120)
    if not old or not new:
        raise ValueError('اسم المجموعة القديم والجديد مطلوبان')
    with self.db.conn:
        cur = self.db.conn.execute('UPDATE products SET category=? WHERE category=?', (new, old))
        count = int(cur.rowcount or 0)
        self.db.conn.execute('INSERT INTO activity_logs (user_id, username, action, details, created_at) VALUES (?, ?, ?, ?, ?)', (int(user['id']), user['username'], 'تعديل مجموعة منتجات', f'{old} -> {new} | {count} منتج', now_text()))
    return count


AppService.rename_product_category = _v4511_rename_product_category


def _v4511_vacuum_and_compress_old_data(self: AppService, days_to_keep_backups: int = 30) -> dict:
    self.require_permission('can_backup', action='ضغط وأرشفة النسخ القديمة')
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    cutoff_seconds = max(1, int(days_to_keep_backups or 30)) * 86400
    now_ts = datetime.now().timestamp()
    compressed = 0
    for path in BACKUP_DIR.glob('*.db'):
        try:
            if now_ts - path.stat().st_mtime < cutoff_seconds:
                continue
            zip_path = ARCHIVE_DIR / f'{path.stem}.zip'
            with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
                zf.write(path, arcname=path.name)
            path.unlink()
            compressed += 1
        except Exception as exc:
            log_exception(exc, f'V45.11 compress backup {path}')
    # VACUUM can fail when another transaction is open; keep non-fatal.
    vacuumed = False
    try:
        self.db.conn.execute('VACUUM')
        vacuumed = True
    except Exception as exc:
        log_exception(exc, 'V45.11 vacuum')
    self.log('صيانة قاعدة البيانات', f'compressed={compressed}, vacuumed={vacuumed}')
    return {'compressed_backups': compressed, 'vacuumed': vacuumed}


AppService.vacuum_and_compress_old_data = _v4511_vacuum_and_compress_old_data


def _v4511_security_health(self: AppService) -> dict:
    """Diagnostics snapshot for support without exposing sensitive data."""
    result = {}
    try:
        result['integrity'] = self.db.one('PRAGMA quick_check')[0]
    except Exception as exc:
        result['integrity'] = f'error: {exc}'
    try:
        rows = self.db.all("SELECT name FROM sqlite_master WHERE type='trigger' AND name LIKE 'trg_v4511_%' ORDER BY name")
        result['integrity_triggers'] = len(rows)
    except Exception:
        result['integrity_triggers'] = 0
    try:
        result['negative_stock_rows'] = int(self.db.one('SELECT COUNT(*) c FROM products WHERE quantity < 0')['c'])
    except Exception:
        result['negative_stock_rows'] = 'unknown'
    try:
        result['cash_accounts'] = int(self.db.one('SELECT COUNT(*) c FROM cash_accounts')['c'])
    except Exception:
        result['cash_accounts'] = 0
    return result


AppService.security_health = _v4511_security_health

log_message('V45.11 integrity/security/finance patch loaded', 'info')
