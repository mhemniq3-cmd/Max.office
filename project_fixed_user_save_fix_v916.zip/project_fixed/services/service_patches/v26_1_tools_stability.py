from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})
import services.service_patches.v19_gdrive as _prev_v19_gdrive
globals().update({k: v for k, v in vars(_prev_v19_gdrive).items() if not k.startswith('__')})
import services.service_patches.v20_gdrive_settings as _prev_v20_gdrive_settings
globals().update({k: v for k, v in vars(_prev_v20_gdrive_settings).items() if not k.startswith('__')})
import services.service_patches.v21_backup as _prev_v21_backup
globals().update({k: v for k, v in vars(_prev_v21_backup).items() if not k.startswith('__')})
import services.service_patches.v22_gdrive_final as _prev_v22_gdrive_final
globals().update({k: v for k, v in vars(_prev_v22_gdrive_final).items() if not k.startswith('__')})
import services.service_patches.v23_business_tools as _prev_v23_business_tools
globals().update({k: v for k, v in vars(_prev_v23_business_tools).items() if not k.startswith('__')})
import services.service_patches.v24_smart_assistant as _prev_v24_smart_assistant
globals().update({k: v for k, v in vars(_prev_v24_smart_assistant).items() if not k.startswith('__')})
import services.service_patches.v25_readiness as _prev_v25_readiness
globals().update({k: v for k, v in vars(_prev_v25_readiness).items() if not k.startswith('__')})
import services.service_patches.v25_1_barcode as _prev_v25_1_barcode
globals().update({k: v for k, v in vars(_prev_v25_1_barcode).items() if not k.startswith('__')})
import services.service_patches.v26_tools_repair as _prev_v26_tools_repair
globals().update({k: v for k, v in vars(_prev_v26_tools_repair).items() if not k.startswith('__')})

# ================================================================
# V26.1 TOOLS PAGE STABILITY FIX
# Allows the Tools page read-only widgets to refresh for can_tools users.
# ================================================================

def _v261_list_products(self: AppService, term: str = ''):
    _v25_require_any(self, ('can_products', 'can_sales', 'can_touch_pos', 'can_purchases', 'can_inventory', 'can_tools', 'can_reports'), action='عرض المنتجات')
    sql, params = _v25_product_query(term)
    return [_v25_sanitize_product(self, r) for r in self.db.all(sql, params)]

AppService.list_products = _v261_list_products


def _v261_inventory_movements(self: AppService, limit: int = 300):
    _v25_require_any(self, ('can_inventory', 'can_tools', 'can_reports', 'can_audit'), action='عرض حركة المخزون')
    return self.db.all('''SELECT m.*, p.name product_name FROM inventory_movements m JOIN products p ON p.id=m.product_id ORDER BY m.id DESC LIMIT ?''', (limit,))

AppService.inventory_movements = _v261_inventory_movements


def _v261_audit_rows(self: AppService, limit: int = 500):
    _v25_require_any(self, ('can_audit', 'can_tools'), action='عرض سجل التدقيق')
    return self.db.all('SELECT * FROM activity_logs ORDER BY id DESC LIMIT ?', (limit,))

AppService.audit_rows = _v261_audit_rows


def _v261_commission_report(self: AppService, date_from: str = '', date_to: str = ''):
    user = _v25_require_any(self, ('can_reports', 'can_goals', 'can_tools'), action='عرض تقرير العمولات')
    sale_where = ['1=1']; sale_params = []
    ret_where = ['1=1']; ret_params = []
    date_from = str(date_from or '').strip(); date_to = str(date_to or '').strip()
    if date_from:
        sale_where.append('date(created_at) >= date(?)'); sale_params.append(date_from)
        ret_where.append('date(created_at) >= date(?)'); ret_params.append(date_from)
    if date_to:
        sale_where.append('date(created_at) <= date(?)'); sale_params.append(date_to)
        ret_where.append('date(created_at) <= date(?)'); ret_params.append(date_to)
    sql = f'''
        SELECT e.name employee,
               COALESCE(s.sales, 0) sales,
               COALESCE(s.commission, 0) commission,
               COALESCE(r.returned_commission, 0) returned_commission
        FROM employees e
        LEFT JOIN (
            SELECT employee_id, COALESCE(SUM(total),0) sales, COALESCE(SUM(total_commission),0) commission
            FROM sales WHERE {' AND '.join(sale_where)} GROUP BY employee_id
        ) s ON s.employee_id=e.id
        LEFT JOIN (
            SELECT employee_id, COALESCE(SUM(commission_amount),0) returned_commission
            FROM returns WHERE {' AND '.join(ret_where)} GROUP BY employee_id
        ) r ON r.employee_id=e.id
        WHERE e.active=1
        ORDER BY commission DESC, e.name
    '''
    rows = [dict(r) for r in self.db.all(sql, sale_params + ret_params)]
    if not self.user_has(user, 'can_view_profit') and not self.is_admin_user(user):
        for row in rows:
            row['commission'] = 0
            row['returned_commission'] = 0
    return rows

AppService.commission_report = _v261_commission_report


def _v261_list_suspended_sales(self: AppService):
    user = _v25_require_any(self, ('can_sales', 'can_touch_pos', 'can_tools', 'can_reports'), action='عرض الفواتير المعلقة')
    if self.is_admin_user(user) or self.user_has(user, 'can_reports') or self.user_has(user, 'can_tools'):
        return self.db.all('''SELECT h.*, COALESCE(u.username,'-') username, COALESCE(c.name,'زبون عام') customer
                              FROM suspended_sales h LEFT JOIN users u ON u.id=h.user_id LEFT JOIN customers c ON c.id=h.customer_id
                              ORDER BY h.id DESC''')
    return self.db.all('''SELECT h.*, COALESCE(u.username,'-') username, COALESCE(c.name,'زبون عام') customer
                          FROM suspended_sales h LEFT JOIN users u ON u.id=h.user_id LEFT JOIN customers c ON c.id=h.customer_id
                          WHERE h.user_id=? ORDER BY h.id DESC''', (user['id'],))

AppService.list_suspended_sales = _v261_list_suspended_sales


def _v261_load_suspended_sale(self: AppService, hold_id: int):
    user = _v25_require_any(self, ('can_sales', 'can_touch_pos', 'can_tools', 'can_reports'), action='تحميل فاتورة معلقة')
    row = self.db.one('SELECT * FROM suspended_sales WHERE id=?', (hold_id,))
    if not row:
        raise ValueError('الفاتورة المعلقة غير موجودة')
    if row['user_id'] and int(row['user_id']) != int(user['id']) and not (self.is_admin_user(user) or self.user_has(user, 'can_reports') or self.user_has(user, 'can_tools')):
        raise PermissionError('لا يمكنك فتح فاتورة معلقة تخص مستخدماً آخر')
    return row, json.loads(row['cart_json'])

AppService.load_suspended_sale = _v261_load_suspended_sale


def _v261_delete_suspended_sale(self: AppService, hold_id: int) -> None:
    user = _v25_require_any(self, ('can_sales', 'can_touch_pos', 'can_tools', 'can_reports'), action='حذف فاتورة معلقة')
    row = self.db.one('SELECT id, hold_no, user_id FROM suspended_sales WHERE id=?', (hold_id,))
    if not row:
        return
    if row['user_id'] and int(row['user_id']) != int(user['id']) and not (self.is_admin_user(user) or self.user_has(user, 'can_reports') or self.user_has(user, 'can_tools')):
        raise PermissionError('لا يمكنك حذف فاتورة معلقة تخص مستخدماً آخر')
    self.db.execute('DELETE FROM suspended_sales WHERE id=?', (hold_id,))
    self.log('حذف فاتورة معلقة', row['hold_no'] or str(hold_id), user['id'])

AppService.delete_suspended_sale = _v261_delete_suspended_sale


def _v261_profit_summary(self: AppService, date_from: str = '', date_to: str = '') -> dict:
    user = _v25_require_any(self, ('can_reports', 'can_tools'), action='عرض ملخص الأرباح')
    data = _orig_profit_summary_v25(self, date_from, date_to)
    if not self.user_has(user, 'can_view_profit'):
        data = dict(data)
        data['gross_profit'] = 0.0
        data['net_profit'] = 0.0
    return data

AppService.profit_summary = _v261_profit_summary

