from __future__ import annotations

"""Stage 4.1.1 hotfixes for reports, dashboard names and debt payments."""

from services.app_core import AppService, receipt_no
from database import now_text

_ORIG_ADD_PAYMENT_V461 = AppService.add_payment


def _v461_add_payment(self: AppService, customer_id: int, amount: float, note: str = '') -> int:
    payment_id = _ORIG_ADD_PAYMENT_V461(self, customer_id, amount, note)
    try:
        row = self.db.one('SELECT * FROM customer_payments WHERE id=?', (int(payment_id),))
        if row:
            receipt = row['receipt_no'] or receipt_no()
            if not row['receipt_no']:
                self.db.execute('UPDATE customer_payments SET receipt_no=? WHERE id=?', (receipt, int(payment_id)))
            self.db.execute('''
                INSERT OR IGNORE INTO payments
                (payment_date, payment_type, amount, payment_method, related_type, related_id,
                 customer_id, description, note, user_name, source_table, source_id, created_at)
                VALUES (?, 'قبض', ?, 'نقدي', 'عميل', ?, ?, ?, ?, '', 'customer_payments', ?, ?)
            ''', (
                row['created_at'] or now_text(),
                float(row['amount'] or 0),
                int(customer_id),
                int(customer_id),
                f'تسديد دين زبون #{customer_id}',
                str(note or row['note'] or '').strip(),
                int(payment_id),
                row['created_at'] or now_text(),
            ))
    except Exception:
        pass
    return payment_id


AppService.add_payment = _v461_add_payment
