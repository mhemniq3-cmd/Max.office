from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note
from services.app_core import *
import services.service_patches.v11_safety as _prev_v11_safety
globals().update({k: v for k, v in vars(_prev_v11_safety).items() if not k.startswith('__')})
import services.service_patches.v13_readiness as _prev_v13_readiness
globals().update({k: v for k, v in vars(_prev_v13_readiness).items() if not k.startswith('__')})
import services.service_patches.v19_gdrive as _prev_v19_gdrive
globals().update({k: v for k, v in vars(_prev_v19_gdrive).items() if not k.startswith('__')})
import services.service_patches.v20_gdrive_settings as _prev_v20_gdrive_settings
globals().update({k: v for k, v in vars(_prev_v20_gdrive_settings).items() if not k.startswith('__')})
import services.service_patches.v21_backup as _prev_v21_backup
globals().update({k: v for k, v in vars(_prev_v21_backup).items() if not k.startswith('__')})
import services.service_patches.v22_gdrive_final as _prev_v22_gdrive_final
globals().update({k: v for k, v in vars(_prev_v22_gdrive_final).items() if not k.startswith('__')})
import services.service_patches.v23_business_tools as _prev_v23_business_tools
globals().update({k: v for k, v in vars(_prev_v23_business_tools).items() if not k.startswith('__')})
import services.service_patches.v24_smart_assistant as _prev_v24_smart_assistant
globals().update({k: v for k, v in vars(_prev_v24_smart_assistant).items() if not k.startswith('__')})
import services.service_patches.v25_readiness as _prev_v25_readiness
globals().update({k: v for k, v in vars(_prev_v25_readiness).items() if not k.startswith('__')})
import services.service_patches.v25_1_barcode as _prev_v25_1_barcode
globals().update({k: v for k, v in vars(_prev_v25_1_barcode).items() if not k.startswith('__')})
import services.service_patches.v26_tools_repair as _prev_v26_tools_repair
globals().update({k: v for k, v in vars(_prev_v26_tools_repair).items() if not k.startswith('__')})
import services.service_patches.v26_1_tools_stability as _prev_v26_1_tools_stability
globals().update({k: v for k, v in vars(_prev_v26_1_tools_stability).items() if not k.startswith('__')})
import services.service_patches.v27_pricing_excel_qr as _prev_v27_pricing_excel_qr
globals().update({k: v for k, v in vars(_prev_v27_pricing_excel_qr).items() if not k.startswith('__')})
import services.service_patches.v30_safe_delete as _prev_v30_safe_delete
globals().update({k: v for k, v in vars(_prev_v30_safe_delete).items() if not k.startswith('__')})
import services.service_patches.v31_goals_dates as _prev_v31_goals_dates
globals().update({k: v for k, v in vars(_prev_v31_goals_dates).items() if not k.startswith('__')})

# =============================================================================
# V32.4 - Strict debt payment validation
# =============================================================================
# Previous protection blocked payments larger than the current balance only when
# the balance was already positive. A zero-balance account could still receive a
# payment through the debt-settlement actions. These wrappers keep settlement
# payments tied to real outstanding debt and avoid accidental credit balances.

def _v324_customer_balance(self: AppService, customer_id: int) -> float:
    for row in self.debt_rows():
        if int(row['id']) == int(customer_id):
            return float(row['balance'] or 0)
    # If the customer is not in the active debt list, treat it as no payable debt.
    return 0.0


def _v324_supplier_balance(self: AppService, supplier_id: int) -> float:
    for row in self.supplier_debt_rows():
        if int(row['id']) == int(supplier_id):
            return float(row['balance'] or 0)
    return 0.0


_orig_add_payment_v324 = AppService.add_payment

def _v324_add_payment(self: AppService, customer_id: int, amount: float, note: str = '') -> int:
    amount = float(amount or 0)
    if amount <= 0:
        raise ValueError('مبلغ الدفعة يجب أن يكون أكبر من صفر')
    balance = _v324_customer_balance(self, customer_id)
    if balance <= 0:
        raise ValueError('لا يوجد دين مستحق على هذا الزبون. لا يمكن تسجيل دفعة تسديد دين.')
    if amount > balance:
        raise ValueError(f'مبلغ التسديد أكبر من دين الزبون. الدين الحالي: {money(balance)}')
    return _orig_add_payment_v324(self, customer_id, amount, note)


_orig_add_supplier_payment_v324 = AppService.add_supplier_payment

def _v324_add_supplier_payment(self: AppService, supplier_id: int, amount: float, note: str = '', user_id: int | None = None) -> int:
    amount = float(amount or 0)
    if amount <= 0:
        raise ValueError('مبلغ الدفعة يجب أن يكون أكبر من صفر')
    balance = _v324_supplier_balance(self, supplier_id)
    if balance <= 0:
        raise ValueError('لا يوجد دين مستحق لهذا المورد. لا يمكن تسجيل دفعة تسديد دين.')
    if amount > balance:
        raise ValueError(f'مبلغ التسديد أكبر من دين المورد. الدين الحالي: {money(balance)}')
    return _orig_add_supplier_payment_v324(self, supplier_id, amount, note, user_id)


AppService.add_payment = _v324_add_payment
AppService.add_supplier_payment = _v324_add_supplier_payment
