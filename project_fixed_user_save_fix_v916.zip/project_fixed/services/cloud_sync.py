from __future__ import annotations

import json
import secrets
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

from services.error_logger import log_exception
from services.remote_dashboard import RemoteDashboardData

APP_ROOT = Path(__file__).resolve().parents[1]
SETTINGS_DIR = APP_ROOT / 'settings'
CONFIG_FILE = SETTINGS_DIR / 'cloud_sync.json'
PENDING_FILE = SETTINGS_DIR / 'cloud_sync_pending.json'


def _now() -> str:
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def _load_json(path: Path, default):
    try:
        if path.exists():
            data = json.loads(path.read_text(encoding='utf-8'))
            return data if data is not None else default
    except Exception as exc:
        log_exception(exc, f'load json {path.name}')
    return default


def _save_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def default_cloud_config() -> Dict[str, Any]:
    return {
        'enabled': False,
        'server_url': 'http://127.0.0.1:9080/api/sync',
        'store_id': 'store-' + secrets.token_hex(4),
        'store_name': 'نظام ماكس للمبيعات',
        'api_key': secrets.token_urlsafe(24),
        'interval_minutes': 5,
        'read_only': True,
        'last_sync_at': '',
        'last_sync_status': 'لم تتم المزامنة بعد',
    }


class CloudSyncClient:
    """Outbound-only cloud sync client.

    The local POS never opens an incoming internet port. It only performs HTTPS/HTTP
    POST requests to a hosted dashboard API. The first implementation is read-only
    and sends operational summaries, not user passwords or a full database dump.
    لا يتم إرسال كلمات مرور المستخدمين ولا قاعدة البيانات كاملة.
    """

    def __init__(self, db_path: Path):
        self.db_path = Path(db_path)
        self.config = self.load_config()
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    def load_config(self) -> Dict[str, Any]:
        SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
        current = _load_json(CONFIG_FILE, None)
        if not isinstance(current, dict):
            current = default_cloud_config()
            _save_json(CONFIG_FILE, current)
        defaults = default_cloud_config()
        changed = False
        for key, value in defaults.items():
            if key not in current:
                current[key] = value
                changed = True
        if changed:
            _save_json(CONFIG_FILE, current)
        return current

    def save_config(self, **updates) -> Dict[str, Any]:
        self.config.update(updates)
        self.config['interval_minutes'] = max(1, int(self.config.get('interval_minutes') or 5))
        self.config['server_url'] = str(self.config.get('server_url') or '').strip()
        self.config['store_id'] = str(self.config.get('store_id') or '').strip() or ('store-' + secrets.token_hex(4))
        self.config['store_name'] = str(self.config.get('store_name') or 'نظام ماكس للمبيعات').strip()
        self.config['api_key'] = str(self.config.get('api_key') or '').strip() or secrets.token_urlsafe(24)
        _save_json(CONFIG_FILE, self.config)
        return self.config

    def reset_api_key(self) -> str:
        key = secrets.token_urlsafe(32)
        self.save_config(api_key=key)
        return key

    def build_payload(self) -> Dict[str, Any]:
        snapshot = RemoteDashboardData(self.db_path).snapshot()
        return {
            'schema_version': 1,
            'sent_at': _now(),
            'store_id': self.config.get('store_id'),
            'store_name': self.config.get('store_name'),
            'read_only': True,
            'snapshot': snapshot,
        }

    def _pending(self) -> list:
        data = _load_json(PENDING_FILE, [])
        return data if isinstance(data, list) else []

    def _save_pending(self, items: list) -> None:
        _save_json(PENDING_FILE, items[-25:])

    def _post_payload(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        url = str(self.config.get('server_url') or '').strip()
        if not url:
            raise ValueError('رابط السيرفر السحابي غير محدد')
        data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        req = urllib.request.Request(
            url,
            data=data,
            method='POST',
            headers={
                'Content-Type': 'application/json; charset=utf-8',
                'X-API-Key': str(self.config.get('api_key') or ''),
                'User-Agent': 'MaxSalesCloudSync/1.0',
            },
        )
        with urllib.request.urlopen(req, timeout=12) as resp:
            raw = resp.read().decode('utf-8', errors='replace')
            try:
                parsed = json.loads(raw)
            except Exception:
                parsed = {'raw': raw}
            if resp.status >= 400:
                raise RuntimeError(f'HTTP {resp.status}: {raw}')
            return parsed

    def sync_once(self, include_pending: bool = True) -> Dict[str, Any]:
        payload = self.build_payload()
        pending = self._pending() if include_pending else []
        errors = []
        sent_pending = 0
        if pending:
            remaining = []
            for item in pending:
                try:
                    self._post_payload(item)
                    sent_pending += 1
                except Exception as exc:
                    remaining.append(item)
                    errors.append(str(exc))
            self._save_pending(remaining)
        try:
            result = self._post_payload(payload)
            status = f'تمت المزامنة بنجاح {payload.get("sent_at")}'
            self.save_config(last_sync_at=payload.get('sent_at'), last_sync_status=status)
            return {'ok': True, 'message': status, 'server': result, 'pending_sent': sent_pending}
        except Exception as exc:
            log_exception(exc, 'cloud sync once')
            queue = self._pending()
            queue.append(payload)
            self._save_pending(queue)
            status = f'فشلت المزامنة وتم حفظها للمحاولة لاحقاً: {exc}'
            self.save_config(last_sync_status=status)
            return {'ok': False, 'message': status, 'pending_count': len(queue), 'errors': errors}

    def start(self) -> None:
        if self.is_running():
            return
        self._stop.clear()
        self.save_config(enabled=True)
        self._thread = threading.Thread(target=self._loop, name='MaxSalesCloudSync', daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self.save_config(enabled=False)
        self._stop.set()

    def is_running(self) -> bool:
        return bool(self._thread and self._thread.is_alive() and not self._stop.is_set())

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.sync_once(include_pending=True)
            except Exception as exc:
                log_exception(exc, 'cloud sync loop')
            interval = max(1, int(self.config.get('interval_minutes') or 5)) * 60
            self._stop.wait(interval)


_MANAGERS: dict[str, CloudSyncClient] = {}


def get_cloud_sync_client(db_path: Path) -> CloudSyncClient:
    key = str(Path(db_path).resolve())
    if key not in _MANAGERS:
        _MANAGERS[key] = CloudSyncClient(Path(db_path))
    return _MANAGERS[key]
