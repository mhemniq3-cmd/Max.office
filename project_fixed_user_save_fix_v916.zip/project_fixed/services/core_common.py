from __future__ import annotations

from datetime import datetime
from pathlib import Path
import shutil
import json
import html
import urllib.request

from database import Database, now_text, password_hash, verify_password, password_needs_rehash, validate_password_strength, to_float, to_int, money
from services.error_logger import log_exception
from services.pricing_helpers import apply_promotion_to_price, format_buy_get_note


def invoice_no() -> str:
    return 'MAX-' + datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]


def return_no() -> str:
    return 'RET-' + datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]


def receipt_no() -> str:
    return 'PAY-' + datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]


def purchase_no() -> str:
    return 'PUR-' + datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]


BASE_PERMISSIONS = dict(
    can_dashboard=0, can_sales=0, can_products=0, can_customers=0, can_returns=0,
    can_reports=0, can_users=0, can_tools=0, can_product_add=0, can_product_edit=0,
    can_product_delete=0, can_view_cost=0, can_view_profit=0, can_return_full=0,
    can_discount=0, can_print=0, can_backup=0, can_restore=0, can_settings=0,
    can_inventory=0, can_suppliers=0, can_purchases=0, can_touch_pos=0, can_price_edit=0,
    can_quantity_edit=0, can_discount_limit=0, can_goals=0, can_audit=0,
)


def perms(**kwargs):
    data = dict(BASE_PERMISSIONS)
    data.update(kwargs)
    return data


ROLE_PERMISSIONS: dict[str, dict[str, int]] = {
    'مدير': perms(can_dashboard=1, can_sales=1, can_products=1, can_customers=1, can_returns=1, can_reports=1, can_users=1, can_tools=1, can_product_add=1, can_product_edit=1, can_product_delete=1, can_view_cost=1, can_view_profit=1, can_return_full=1, can_discount=1, can_print=1, can_backup=1, can_restore=1, can_settings=1, can_inventory=1, can_suppliers=1, can_purchases=1, can_touch_pos=1, can_price_edit=1, can_quantity_edit=1, can_discount_limit=1, can_goals=1, can_audit=1),
    'كاشير': perms(can_dashboard=1, can_sales=1, can_touch_pos=1, can_customers=1, can_discount=1, can_print=1),
    'موظف مبيعات': perms(can_dashboard=1, can_sales=1, can_touch_pos=1, can_customers=1, can_discount=1, can_print=1),
    'مخزن': perms(can_dashboard=1, can_products=1, can_returns=1, can_product_add=1, can_product_edit=1, can_view_cost=1, can_inventory=1, can_suppliers=1, can_purchases=1, can_price_edit=1, can_quantity_edit=1),
    'محاسب': perms(can_dashboard=1, can_customers=1, can_returns=1, can_reports=1, can_tools=1, can_view_cost=1, can_view_profit=1, can_return_full=1, can_print=1, can_backup=1, can_suppliers=1, can_purchases=1, can_goals=1, can_audit=1),
}


