"""Schema migrations kept separate from runtime monkey patches."""
