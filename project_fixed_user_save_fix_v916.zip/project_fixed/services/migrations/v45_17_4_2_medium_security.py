from __future__ import annotations


def run(conn) -> None:
    """Idempotent schema hardening for v45.17.4.2."""
    conn.execute('CREATE INDEX IF NOT EXISTS idx_returns_sale_item_v451742 ON returns(sale_item_id, sale_id)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_returns_sale_v451742 ON returns(sale_id, created_at)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_sales_customer_payment_v451742 ON sales(customer_id, payment_method, status, created_at)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_customer_payments_customer_v451742b ON customer_payments(customer_id, created_at)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_activity_logs_user_created_v451742 ON activity_logs(username, created_at)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_sale_items_sale_v451742 ON sale_items(sale_id)')
    conn.commit()
