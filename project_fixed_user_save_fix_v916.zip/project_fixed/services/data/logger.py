from __future__ import annotations

"""Small data-layer logger bootstrap.

Importing this module is safe and ensures the logs directory exists before any
RotatingFileHandler or migration logger attempts to write. It also removes old
log files so long-running installations do not keep growing logs forever.
"""

import logging
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path

try:
    from config import LOG_DIR, LOG_RETENTION_DAYS, DEBUG_MODE
except Exception:  # pragma: no cover - defensive fallback for unusual packaging
    APP_ROOT = Path(__file__).resolve().parents[2]
    LOG_DIR = APP_ROOT / "logs"
    LOG_RETENTION_DAYS = 180
    DEBUG_MODE = False

LOG_DIR = Path(LOG_DIR)
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "data.log"


def cleanup_old_logs(retention_days: int | None = None) -> int:
    """Delete log files older than the configured retention period.

    Returns the number of deleted files. The cleanup is intentionally quiet so
    startup never fails just because a stale log could not be removed.
    """
    days = int(retention_days or LOG_RETENTION_DAYS or 180)
    if days <= 0:
        return 0
    cutoff = time.time() - (days * 24 * 60 * 60)
    deleted = 0
    for path in LOG_DIR.glob("*.log*"):
        try:
            if path.is_file() and path.stat().st_mtime < cutoff:
                path.unlink()
                deleted += 1
        except OSError:
            continue
    return deleted


cleanup_old_logs()


def get_logger(name: str = "max_sales.data") -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG if DEBUG_MODE else logging.INFO)
    if not logger.handlers:
        handler = RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=5, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        logger.addHandler(handler)
    return logger
