from __future__ import annotations

"""Query helpers used by Domain read/write models.

Stage 14 keeps the helpers deliberately small and SQLite-friendly.  They can be
used with an explicit connection (preferred for transactions) or with the
managed default connection when called without one.
"""

from contextlib import contextmanager
import sqlite3
from typing import Any, Iterable, Iterator, Sequence

from services.data.connections import managed_connection

Params = Iterable[Any] | Sequence[Any]


def _dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row is not None else None


def _coerce_conn(conn_or_query: sqlite3.Connection | str, query: str | None) -> tuple[sqlite3.Connection | None, str]:
    if isinstance(conn_or_query, sqlite3.Connection):
        if query is None:
            raise ValueError("query is required when passing a connection")
        return conn_or_query, query
    if query is not None:
        raise ValueError("query must be omitted when no connection is passed")
    return None, conn_or_query


@contextmanager
def _connection_scope(conn: sqlite3.Connection | None) -> Iterator[sqlite3.Connection]:
    if conn is not None:
        yield conn
        return
    with managed_connection() as managed:
        yield managed


def fetch_one_dict(conn: sqlite3.Connection, query: str, params: Params = ()) -> dict[str, Any] | None:
    return _dict(conn.execute(query, tuple(params)).fetchone())


def fetch_all_dicts(conn: sqlite3.Connection, query: str, params: Params = ()) -> list[dict[str, Any]]:
    return [dict(row) for row in conn.execute(query, tuple(params)).fetchall()]


def fetch_one(conn_or_query: sqlite3.Connection | str, query: str | None = None, params: Params = ()) -> dict[str, Any] | None:
    """Fetch one row as a dict.

    Supported forms:
        fetch_one(conn, "SELECT ...", params)
        fetch_one("SELECT ...", params)  # via managed default connection
    """
    if query is not None and not isinstance(conn_or_query, sqlite3.Connection):
        # Compatibility with fetch_one(sql, params)
        if not isinstance(query, str):
            params = query  # type: ignore[assignment]
            query = None
    conn, sql = _coerce_conn(conn_or_query, query)
    with _connection_scope(conn) as active:
        return fetch_one_dict(active, sql, params)


def fetch_all(conn_or_query: sqlite3.Connection | str, query: str | None = None, params: Params = ()) -> list[dict[str, Any]]:
    if query is not None and not isinstance(conn_or_query, sqlite3.Connection):
        if not isinstance(query, str):
            params = query  # type: ignore[assignment]
            query = None
    conn, sql = _coerce_conn(conn_or_query, query)
    with _connection_scope(conn) as active:
        return fetch_all_dicts(active, sql, params)


def execute_write(conn_or_query: sqlite3.Connection | str, query: str | None = None, params: Params = ()) -> int:
    """Execute a write and return lastrowid when available.

    In transactions, pass the active connection explicitly.  Without a
    connection this function commits by closing the managed connection after the
    statement succeeds.
    """
    if query is not None and not isinstance(conn_or_query, sqlite3.Connection):
        if not isinstance(query, str):
            params = query  # type: ignore[assignment]
            query = None
    conn, sql = _coerce_conn(conn_or_query, query)
    with _connection_scope(conn) as active:
        cur = active.execute(sql, tuple(params))
        if conn is None:
            active.commit()
        return int(cur.lastrowid or cur.rowcount or 0)


def _safe_identifier(name: str) -> str:
    if not str(name).replace("_", "").isalnum():
        raise ValueError(f"unsafe sqlite identifier: {name!r}")
    return f'"{name}"'


def table_exists(conn_or_table: sqlite3.Connection | str, table_name: str | None = None) -> bool:
    """Return whether a table exists.

    Supports both table_exists(conn, "sales") and table_exists("sales").
    """
    if isinstance(conn_or_table, sqlite3.Connection):
        if table_name is None:
            raise ValueError("table_name is required when passing a connection")
        row = conn_or_table.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table_name,)).fetchone()
        return row is not None
    with managed_connection() as conn:
        row = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (str(conn_or_table),)).fetchone()
        return row is not None


def column_exists(conn: sqlite3.Connection, table_name: str, column_name: str) -> bool:
    try:
        return any(row[1] == column_name for row in conn.execute(f"PRAGMA table_info({_safe_identifier(table_name)})"))
    except sqlite3.Error:
        return False


def table_columns(conn_or_table: sqlite3.Connection | str, table_name: str | None = None) -> set[str]:
    """Return table column names.

    Supports both table_columns(conn, "sales") and table_columns("sales").
    """
    def _columns(active: sqlite3.Connection, name: str) -> set[str]:
        try:
            return {str(row[1]) for row in active.execute(f"PRAGMA table_info({_safe_identifier(name)})")}
        except (sqlite3.Error, ValueError):
            return set()

    if isinstance(conn_or_table, sqlite3.Connection):
        if table_name is None:
            raise ValueError("table_name is required when passing a connection")
        return _columns(conn_or_table, table_name)
    with managed_connection() as conn:
        return _columns(conn, str(conn_or_table))


def require_columns(
    conn_or_table: sqlite3.Connection | str,
    table_or_columns: str | Iterable[str],
    columns: Iterable[str] | None = None,
) -> bool:
    """Check whether a table contains all required columns.

    Supports both require_columns(conn, "sales", cols) and
    require_columns("sales", cols), which is useful for migration diagnostics.
    """
    if isinstance(conn_or_table, sqlite3.Connection):
        if columns is None or not isinstance(table_or_columns, str):
            raise ValueError("require_columns(conn, table_name, columns) expected")
        existing = table_columns(conn_or_table, table_or_columns)
        return set(columns).issubset(existing)
    if columns is not None:
        raise ValueError("columns must be omitted when no connection is passed")
    existing = table_columns(str(conn_or_table))
    return set(table_or_columns).issubset(existing)  # type: ignore[arg-type]
