from __future__ import annotations

"""Smart schema migration runner for v1.0.0 Stable.

The project schema is centered on `sales`, `sale_items`, `products`,
`customer_payments`, and `inventory_movements`.  Earlier notes used generic
invoice names; this runner upgrades the real Max Sales tables used by the
Native Persistence path without deleting or rewriting customer data.
"""

import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

from services.data.connections import managed_connection

PROJECT_ROOT = Path(__file__).resolve().parents[3]
LOG_DIR = PROJECT_ROOT / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.FileHandler(LOG_DIR / "migrations.log", encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)
logger.propagate = False

# Only safe ADD COLUMN definitions are used here.  NOT NULL columns include
# defaults so older databases can be upgraded without SQLite rejecting ALTER.
SMART_SCHEMA: dict[str, dict[str, Any]] = {
    "sales": {
        "columns": {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "invoice_no": "TEXT UNIQUE",
            "user_id": "INTEGER",
            "employee_id": "INTEGER DEFAULT 0",
            "customer_id": "INTEGER",
            "subtotal": "REAL NOT NULL DEFAULT 0",
            "discount_amount": "REAL NOT NULL DEFAULT 0",
            "total": "REAL NOT NULL DEFAULT 0",
            "total_commission": "REAL NOT NULL DEFAULT 0",
            "total_profit": "REAL NOT NULL DEFAULT 0",
            "payment_method": "TEXT NOT NULL DEFAULT 'نقدي'",
            "discount_type": "TEXT NOT NULL DEFAULT 'amount'",
            "tax_amount": "REAL NOT NULL DEFAULT 0",
            "status": "TEXT NOT NULL DEFAULT 'completed'",
            "receipt_no": "TEXT",
            "note": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP",
        },
        "indexes": [
            "CREATE INDEX IF NOT EXISTS idx_sales_created_at ON sales(created_at)",
            "CREATE INDEX IF NOT EXISTS idx_sales_customer_id ON sales(customer_id)",
            "CREATE INDEX IF NOT EXISTS idx_sales_employee_id ON sales(employee_id)",
            "CREATE INDEX IF NOT EXISTS idx_sales_invoice_no ON sales(invoice_no)",
        ],
    },
    "sale_items": {
        "columns": {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "sale_id": "INTEGER NOT NULL DEFAULT 0",
            "product_id": "INTEGER NOT NULL DEFAULT 0",
            "product_name": "TEXT NOT NULL DEFAULT ''",
            "quantity": "INTEGER NOT NULL DEFAULT 0",
            "cost_price": "REAL NOT NULL DEFAULT 0",
            "unit_price": "REAL NOT NULL DEFAULT 0",
            "line_total": "REAL NOT NULL DEFAULT 0",
            "commission_percent": "REAL NOT NULL DEFAULT 0",
            "commission_amount": "REAL NOT NULL DEFAULT 0",
            "profit_amount": "REAL NOT NULL DEFAULT 0",
            "discount_amount": "REAL NOT NULL DEFAULT 0",
            "tax_amount": "REAL NOT NULL DEFAULT 0",
        },
        "indexes": [
            "CREATE INDEX IF NOT EXISTS idx_sale_items_sale_id ON sale_items(sale_id)",
            "CREATE INDEX IF NOT EXISTS idx_sale_items_product_id ON sale_items(product_id)",
        ],
    },
    "products": {
        "columns": {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "barcode": "TEXT UNIQUE",
            "name": "TEXT NOT NULL DEFAULT ''",
            "category": "TEXT",
            "cost_price": "REAL NOT NULL DEFAULT 0",
            "sale_price": "REAL NOT NULL DEFAULT 0",
            "quantity": "INTEGER NOT NULL DEFAULT 0",
            "min_quantity": "INTEGER NOT NULL DEFAULT 5",
            "commission_percent": "REAL NOT NULL DEFAULT 0",
            "active": "INTEGER NOT NULL DEFAULT 1",
            "created_at": "TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP",
        },
        "indexes": [
            "CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode)",
            "CREATE INDEX IF NOT EXISTS idx_products_name ON products(name)",
            "CREATE INDEX IF NOT EXISTS idx_products_active ON products(active)",
        ],
    },
    "returns": {
        "columns": {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "return_no": "TEXT NOT NULL DEFAULT ''",
            "sale_id": "INTEGER NOT NULL DEFAULT 0",
            "sale_item_id": "INTEGER NOT NULL DEFAULT 0",
            "product_id": "INTEGER NOT NULL DEFAULT 0",
            "product_name": "TEXT NOT NULL DEFAULT ''",
            "employee_id": "INTEGER NOT NULL DEFAULT 0",
            "customer_id": "INTEGER",
            "quantity": "INTEGER NOT NULL DEFAULT 0",
            "unit_price": "REAL NOT NULL DEFAULT 0",
            "amount": "REAL NOT NULL DEFAULT 0",
            "commission_amount": "REAL NOT NULL DEFAULT 0",
            "profit_amount": "REAL NOT NULL DEFAULT 0",
            "reason": "TEXT",
            "refund_method": "TEXT NOT NULL DEFAULT 'نقدي'",
            "created_by_user_id": "INTEGER",
            "created_at": "TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP",
        },
        "indexes": [
            "CREATE INDEX IF NOT EXISTS idx_returns_sale_id ON returns(sale_id)",
            "CREATE INDEX IF NOT EXISTS idx_returns_sale_item_id ON returns(sale_item_id)",
            "CREATE INDEX IF NOT EXISTS idx_returns_return_no ON returns(return_no)",
        ],
    },
    "customer_payments": {
        "columns": {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "customer_id": "INTEGER NOT NULL DEFAULT 0",
            "amount": "REAL NOT NULL DEFAULT 0",
            "discount_type": "TEXT NOT NULL DEFAULT 'amount'",
            "tax_amount": "REAL NOT NULL DEFAULT 0",
            "status": "TEXT NOT NULL DEFAULT 'completed'",
            "receipt_no": "TEXT",
            "note": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP",
        },
        "indexes": [
            "CREATE INDEX IF NOT EXISTS idx_customer_payments_customer_id ON customer_payments(customer_id)",
            "CREATE INDEX IF NOT EXISTS idx_customer_payments_created_at ON customer_payments(created_at)",
        ],
    },
    "inventory_movements": {
        "columns": {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "product_id": "INTEGER NOT NULL DEFAULT 0",
            "movement_type": "TEXT NOT NULL DEFAULT ''",
            "quantity_change": "INTEGER NOT NULL DEFAULT 0",
            "old_quantity": "INTEGER NOT NULL DEFAULT 0",
            "new_quantity": "INTEGER NOT NULL DEFAULT 0",
            "ref_type": "TEXT",
            "ref_no": "TEXT",
            "note": "TEXT",
            "user_id": "INTEGER",
            "created_at": "TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP",
        },
        "indexes": [
            "CREATE INDEX IF NOT EXISTS idx_inventory_movements_product_id ON inventory_movements(product_id)",
            "CREATE INDEX IF NOT EXISTS idx_inventory_movements_ref ON inventory_movements(ref_type, ref_no)",
            "CREATE INDEX IF NOT EXISTS idx_inventory_movements_created_at ON inventory_movements(created_at)",
        ],
    },
    "payments": {
        "columns": {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "payment_date": "TEXT",
            "payment_type": "TEXT NOT NULL DEFAULT 'قبض'",
            "amount": "REAL NOT NULL DEFAULT 0",
            "payment_method": "TEXT NOT NULL DEFAULT 'نقدي'",
            "related_type": "TEXT",
            "related_id": "INTEGER",
            "customer_id": "INTEGER",
            "supplier_id": "INTEGER",
            "description": "TEXT",
            "note": "TEXT",
            "user_id": "INTEGER",
            "user_name": "TEXT NOT NULL DEFAULT ''",
            "source_table": "TEXT",
            "source_id": "INTEGER",
            "created_at": "TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP",
        },
        "indexes": [
            "CREATE INDEX IF NOT EXISTS idx_payments_customer_id ON payments(customer_id)",
            "CREATE INDEX IF NOT EXISTS idx_payments_supplier_id ON payments(supplier_id)",
            "CREATE INDEX IF NOT EXISTS idx_payments_created_at ON payments(created_at)",
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_source ON payments(source_table, source_id)",
        ],
    },
    "system_events": {
        "columns": {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "event_name": "TEXT NOT NULL DEFAULT ''",
            "payload_json": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP",
        },
        "indexes": [
            "CREATE INDEX IF NOT EXISTS idx_system_events_name_date ON system_events(event_name, created_at)",
        ],
    },
}


def _quote_ident(identifier: str) -> str:
    if not identifier.replace("_", "").isalnum():
        raise ValueError(f"unsafe sqlite identifier: {identifier!r}")
    return f'"{identifier}"'


def table_exists(conn: sqlite3.Connection, table_name: str) -> bool:
    row = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table_name,)).fetchone()
    return row is not None


def get_existing_columns(conn: sqlite3.Connection, table_name: str) -> dict[str, str]:
    try:
        return {str(row[1]): str(row[2]) for row in conn.execute(f"PRAGMA table_info({_quote_ident(table_name)})")}
    except sqlite3.Error as exc:
        logger.warning("Could not inspect table %s: %s", table_name, exc)
        return {}


def _create_table(conn: sqlite3.Connection, table_name: str, schema_def: dict[str, Any]) -> None:
    columns_sql = ", ".join(f"{_quote_ident(name)} {definition}" for name, definition in schema_def["columns"].items())
    conn.execute(f"CREATE TABLE IF NOT EXISTS {_quote_ident(table_name)} ({columns_sql})")
    logger.info("Created missing table: %s", table_name)


def upgrade_table(conn: sqlite3.Connection, table_name: str, schema_def: dict[str, Any]) -> list[str]:
    """Create a missing table or add missing columns/indexes in-place."""
    changes: list[str] = []
    if not table_exists(conn, table_name):
        _create_table(conn, table_name, schema_def)
        changes.append(f"created:{table_name}")
    else:
        existing = get_existing_columns(conn, table_name)
        for column_name, column_def in schema_def["columns"].items():
            if column_name in existing:
                continue
            conn.execute(f"ALTER TABLE {_quote_ident(table_name)} ADD COLUMN {_quote_ident(column_name)} {column_def}")
            logger.info("Added missing column: %s.%s", table_name, column_name)
            changes.append(f"column:{table_name}.{column_name}")

    for index_sql in schema_def.get("indexes", []):
        conn.execute(index_sql)
    return changes


def ensure_schema_migrations(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS schema_migrations (
            version TEXT PRIMARY KEY,
            applied_at TEXT NOT NULL,
            description TEXT
        )
        """
    )
    cols = get_existing_columns(conn, "schema_migrations")
    if "description" not in cols:
        conn.execute("ALTER TABLE schema_migrations ADD COLUMN description TEXT")


def run_smart_migrations(conn: sqlite3.Connection | None = None, *, version: str = "v1.0.0_STABLE_HARDENED") -> list[str]:
    """Apply Stage 15 smart migrations and return the applied changes."""
    def _run(active: sqlite3.Connection) -> list[str]:
        logger.info("=== v1.0.0 stable smart migration started ===")
        ensure_schema_migrations(active)
        changes: list[str] = []
        for table_name, schema_def in SMART_SCHEMA.items():
            changes.extend(upgrade_table(active, table_name, schema_def))
        active.execute(
            "INSERT OR REPLACE INTO schema_migrations(version, applied_at, description) VALUES (?, ?, ?)",
            (version, datetime.now().isoformat(timespec="seconds"), "v1.0.0 stable schema repair for native-only persistence"),
        )
        active.commit()
        logger.info("=== v1.0.0 stable smart migration finished: %s changes ===", len(changes))
        return changes

    if conn is not None:
        return _run(conn)
    with managed_connection() as managed:
        return _run(managed)


# Backward-friendly name for manual execution/imports.
def run_migrations(conn: sqlite3.Connection | None = None) -> list[str]:
    return run_smart_migrations(conn)


if __name__ == "__main__":
    applied = run_smart_migrations()
    print(f"✅ v1.0.0 stable smart migrations completed. Changes: {len(applied)}")
