from __future__ import annotations

"""Lightweight migration runner for Stage 13."""

import sqlite3
from datetime import datetime
from typing import Callable, Iterable

from services.data.migrations.runner import run_smart_migrations

Migration = tuple[str, Callable[[sqlite3.Connection], None]]


def _ensure_migration_table(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS schema_migrations (
            version TEXT PRIMARY KEY,
            applied_at TEXT NOT NULL
        )
        """
    )


def _system_events_migration(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS system_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_name TEXT NOT NULL,
            payload_json TEXT,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_system_events_name_date ON system_events(event_name, created_at)")


def _stage15_smart_schema_migration(conn: sqlite3.Connection) -> None:
    run_smart_migrations(conn)


MIGRATIONS: tuple[Migration, ...] = (
    ("2026_05_15_01_system_events", _system_events_migration),
    ("2026_05_15_02_stage15_smart_schema", _stage15_smart_schema_migration),
)


def run_migrations(conn: sqlite3.Connection, migrations: Iterable[Migration] = MIGRATIONS) -> list[str]:
    """Apply idempotent migrations and return versions applied in this run."""
    _ensure_migration_table(conn)
    applied: list[str] = []
    known = {row[0] for row in conn.execute("SELECT version FROM schema_migrations")}
    for version, fn in migrations:
        if version in known:
            continue
        fn(conn)
        conn.execute("INSERT INTO schema_migrations(version, applied_at) VALUES (?, ?)", (version, datetime.now().isoformat(timespec="seconds")))
        applied.append(version)
    conn.commit()
    return applied
