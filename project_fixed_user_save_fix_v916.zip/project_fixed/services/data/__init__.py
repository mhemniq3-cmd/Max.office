"""Stage 13 data access package.

This package is the modern, modular data layer.  It does not remove the
historical ``db.database_core.Database`` class; it wraps and standardises its
connection, transaction, migration and row-mapping responsibilities so new code
can depend on smaller modules instead of one large file.
"""
from __future__ import annotations

from .connections import connect_sqlite, managed_connection, transaction
from .models import MoneyAmount, PersistResult, SaleWriteContext, StockMovement
from .queries import fetch_all_dicts, fetch_one_dict, table_exists, column_exists
from .migrations import run_migrations

__all__ = [
    "connect_sqlite",
    "managed_connection",
    "transaction",
    "MoneyAmount",
    "PersistResult",
    "SaleWriteContext",
    "StockMovement",
    "fetch_all_dicts",
    "fetch_one_dict",
    "table_exists",
    "column_exists",
    "run_migrations",
]
