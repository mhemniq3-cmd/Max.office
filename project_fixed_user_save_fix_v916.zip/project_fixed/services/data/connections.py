from __future__ import annotations

"""SQLite connection and transaction helpers for Stage 13."""

from contextlib import contextmanager
import os
import sqlite3
from pathlib import Path
from typing import Iterator

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DB_PATH = PROJECT_ROOT / "database" / "max_sales.db"


def _db_path(path: str | Path | None = None) -> Path:
    raw = path or os.environ.get("MAX_SALES_DB_PATH") or DEFAULT_DB_PATH
    resolved = Path(raw).expanduser()
    if not resolved.is_absolute():
        resolved = (PROJECT_ROOT / resolved).resolve()
    resolved.parent.mkdir(parents=True, exist_ok=True)
    return resolved


def connect_sqlite(path: str | Path | None = None) -> sqlite3.Connection:
    """Open a configured SQLite connection with the same safe PRAGMAs as Database."""
    timeout = float(os.environ.get("MAX_SALES_SQLITE_TIMEOUT", "10"))
    cache_kib = int(os.environ.get("MAX_SALES_SQLITE_CACHE_KIB", "20000"))
    conn = sqlite3.connect(
        _db_path(path),
        timeout=timeout,
        detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES,
        cached_statements=256,
    )
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute(f"PRAGMA busy_timeout = {int(timeout * 1000)}")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA temp_store = MEMORY")
    conn.execute(f"PRAGMA cache_size = {-abs(cache_kib)}")
    return conn


@contextmanager
def managed_connection(path: str | Path | None = None) -> Iterator[sqlite3.Connection]:
    conn = connect_sqlite(path)
    try:
        yield conn
    finally:
        try:
            conn.execute("PRAGMA optimize")
        except sqlite3.Error:
            pass
        conn.close()


@contextmanager
def transaction(conn: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    """Run a write operation atomically using BEGIN IMMEDIATE."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
    except Exception:
        conn.rollback()
        raise
    else:
        conn.commit()
