from __future__ import annotations

"""Typed value objects shared between Domain and persistence code."""

from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP
from typing import Any

CENT = Decimal("0.01")


def to_money(value: Any) -> Decimal:
    try:
        return Decimal(str(value if value is not None else "0").replace(",", "").strip() or "0").quantize(CENT, rounding=ROUND_HALF_UP)
    except Exception:
        return Decimal("0.00")


@dataclass(frozen=True)
class MoneyAmount:
    amount: Decimal
    currency: str = "IQD"

    @classmethod
    def from_any(cls, value: Any, currency: str = "IQD") -> "MoneyAmount":
        return cls(to_money(value), currency)

    def as_float(self) -> float:
        return float(self.amount)

    def __float__(self) -> float:
        return self.as_float()


@dataclass(frozen=True)
class SaleWriteContext:
    operation: str = "complete_sale"
    preview: dict[str, Any] = field(default_factory=dict)
    user_id: int | None = None
    customer_id: int | None = None
    invoice_no: str | None = None
    employee_id: int | None = None
    payment_method: str = "نقدي"
    discount_type: str = "amount"
    note: str = ""
    items: list[dict[str, Any]] = field(default_factory=list)


@dataclass(frozen=True)
class PaymentContext:
    customer_id: int | None
    amount: Decimal
    note: str = ""
    user_id: int | None = None
    payment_method: str = "نقدي"


@dataclass(frozen=True)
class DatabaseResult:
    success: bool
    rowcount: int = 0
    lastrowid: int | None = None
    message: str = ""
    error: str = ""


@dataclass(frozen=True)
class PersistResult:
    operation: str
    result: Any = None
    preview: dict[str, Any] = field(default_factory=dict)
    comparison: dict[str, Any] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    engine: str = "domain_native"
    native_attempted: bool = False
    native_used: bool = False


@dataclass(frozen=True)
class StockMovement:
    product_id: int
    quantity_delta: Decimal
    reason: str
    ref_no: str | None = None


@dataclass(frozen=True)
class ProductItem:
    """Validated sale line item for API-style native persistence callers."""

    product_id: int
    name: str
    barcode: str = ""
    quantity: Decimal = field(default_factory=lambda: to_money(0))
    unit_price: Decimal = field(default_factory=lambda: to_money(0))
    discount: Decimal = field(default_factory=lambda: to_money(0))
    tax: Decimal = field(default_factory=lambda: to_money(0))
    cost_price: Decimal = field(default_factory=lambda: to_money(0))
    total_price: Decimal = field(init=False)

    def __post_init__(self) -> None:
        quantity = to_money(self.quantity)
        unit_price = to_money(self.unit_price)
        discount = to_money(self.discount)
        tax = to_money(self.tax)
        cost_price = to_money(self.cost_price)
        if quantity <= 0:
            raise ValueError("الكمية يجب أن تكون أكبر من صفر")
        if unit_price < 0 or cost_price < 0 or discount < 0 or tax < 0:
            raise ValueError("القيم المالية لا يمكن أن تكون سالبة")
        object.__setattr__(self, "quantity", quantity)
        object.__setattr__(self, "unit_price", unit_price)
        object.__setattr__(self, "discount", discount)
        object.__setattr__(self, "tax", tax)
        object.__setattr__(self, "cost_price", cost_price)
        object.__setattr__(self, "total_price", to_money((quantity * unit_price) - discount + tax))

    def to_dict(self) -> dict[str, Any]:
        return {
            "product_id": self.product_id,
            "name": self.name,
            "barcode": self.barcode,
            "quantity": self.quantity,
            "unit_price": self.unit_price,
            "discount": self.discount,
            "tax": self.tax,
            "cost_price": self.cost_price,
            "total_price": self.total_price,
        }


@dataclass(frozen=True)
class SaleContext:
    """Validated sale context for API-style callers.

    The Qt application continues to use SaleWriteContext/AppService wrappers;
    this model gives integrations a clean native-only object without relying on
    removed storage engines.
    """

    invoice_number: str
    customer_id: int | None
    customer_name: str = ""
    items: list[ProductItem] = field(default_factory=list)
    total_amount: Decimal = field(default_factory=lambda: to_money(0))
    tax_amount: Decimal = field(default_factory=lambda: to_money(0))
    discount_amount: Decimal = field(default_factory=lambda: to_money(0))
    net_amount: Decimal = field(default_factory=lambda: to_money(0))
    paid_amount: Decimal = field(default_factory=lambda: to_money(0))
    remaining_amount: Decimal = field(default_factory=lambda: to_money(0))
    payment_type: str = "نقدي"
    user_id: int | None = None
    invoice_id: int | None = None

    def __post_init__(self) -> None:
        if not self.invoice_number:
            raise ValueError("رقم الفاتورة مطلوب")
        if not self.items:
            raise ValueError("الفاتورة يجب أن تحتوي على مادة واحدة على الأقل")
        total_amount = to_money(self.total_amount or sum((item.total_price for item in self.items), Decimal("0")))
        discount_amount = to_money(self.discount_amount)
        tax_amount = to_money(self.tax_amount)
        net_amount = to_money(self.net_amount or (total_amount - discount_amount + tax_amount))
        paid_amount = to_money(self.paid_amount)
        remaining_amount = to_money(self.remaining_amount or max(net_amount - paid_amount, Decimal("0")))
        if discount_amount < 0 or tax_amount < 0 or paid_amount < 0 or remaining_amount < 0:
            raise ValueError("القيم المالية لا يمكن أن تكون سالبة")
        object.__setattr__(self, "total_amount", total_amount)
        object.__setattr__(self, "discount_amount", discount_amount)
        object.__setattr__(self, "tax_amount", tax_amount)
        object.__setattr__(self, "net_amount", net_amount)
        object.__setattr__(self, "paid_amount", paid_amount)
        object.__setattr__(self, "remaining_amount", remaining_amount)

    def to_dict(self) -> dict[str, Any]:
        return {
            "invoice_number": self.invoice_number,
            "customer_id": self.customer_id,
            "customer_name": self.customer_name,
            "items": [item.to_dict() for item in self.items],
            "total_amount": self.total_amount,
            "tax_amount": self.tax_amount,
            "discount_amount": self.discount_amount,
            "net_amount": self.net_amount,
            "paid_amount": self.paid_amount,
            "remaining_amount": self.remaining_amount,
            "payment_type": self.payment_type,
            "user_id": self.user_id,
            "invoice_id": self.invoice_id,
        }
