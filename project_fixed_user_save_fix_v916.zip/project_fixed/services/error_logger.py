from __future__ import annotations

import logging
import sys
import traceback
from logging.handlers import RotatingFileHandler
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOG_DIR = ROOT / 'logs'
LOG_FILE = LOG_DIR / 'error.log'
LOG_DIR.mkdir(parents=True, exist_ok=True)  # Stage 26: create logs folder on import


def _sanitize(text: object) -> str:
    s = str(text or '')
    # Hide local project/home paths from logs while preserving useful context.
    replacements = {
        str(ROOT): '<APP_ROOT>',
        str(Path.home()): '<USER_HOME>',
    }
    for old, new in replacements.items():
        if old:
            s = s.replace(old, new)
    return s.replace('\r', ' ').replace('\n', ' | ')


def _ensure_logger() -> logging.Logger:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger('max_sales')
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=5, encoding='utf-8')
        handler.setFormatter(logging.Formatter('%(asctime)s | %(levelname)s | %(message)s'))
        logger.addHandler(handler)
    return logger


def log_exception(exc: BaseException | None = None, context: str = '') -> None:
    logger = _ensure_logger()
    if exc is None:
        logger.error('%s', _sanitize(context or 'Unknown error'))
        return
    logger.error('%s%s: %s', (_sanitize(context) + ' | ') if context else '', exc.__class__.__name__, _sanitize(exc))
    trace = ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    logger.error('%s', _sanitize(trace))


def log_message(message: str, level: str = 'info') -> None:
    logger = _ensure_logger()
    method = getattr(logger, level if level in ('debug', 'info', 'warning', 'error', 'critical') else 'info')
    method('%s', _sanitize(message))


def install_global_exception_hook() -> None:
    old_hook = sys.excepthook
    def hook(exc_type, exc, tb):
        log_exception(exc, 'Unhandled application exception')
        old_hook(exc_type, exc, tb)
    sys.excepthook = hook
