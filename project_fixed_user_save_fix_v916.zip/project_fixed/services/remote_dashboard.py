from __future__ import annotations

import base64
import html
import json
import secrets
import shutil
import socket
import sqlite3
import threading
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from services.error_logger import log_exception
from db.database_core import SQLITE_CACHE_KIB, SQLITE_TIMEOUT_SECONDS

APP_ROOT = Path(__file__).resolve().parents[1]
SETTINGS_DIR = APP_ROOT / 'settings'
BACKUP_DIR = APP_ROOT / 'backups'
CONFIG_FILE = SETTINGS_DIR / 'remote_dashboard.json'


def _money(value) -> str:
    try:
        return f'{float(value):,.0f} د.ع'
    except Exception:
        return '0 د.ع'


def _now() -> str:
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def _today() -> str:
    return datetime.now().strftime('%Y-%m-%d')


def _load_config() -> dict:
    SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding='utf-8'))
            if isinstance(data, dict):
                return data
        except Exception as exc:
            log_exception(exc, 'remote dashboard load config')
    data = {
        'enabled': False,
        'host': '127.0.0.1',
        'port': 8765,
        'username': 'admin',
        'password': secrets.token_urlsafe(8),
    }
    _save_config(data)
    return data


def _save_config(config: dict) -> None:
    SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
    safe = dict(config)
    safe['port'] = int(safe.get('port') or 8765)
    safe['host'] = str(safe.get('host') or '127.0.0.1')
    safe['username'] = str(safe.get('username') or 'admin')
    safe['password'] = str(safe.get('password') or secrets.token_urlsafe(8))
    CONFIG_FILE.write_text(json.dumps(safe, ensure_ascii=False, indent=2), encoding='utf-8')


def _local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return '127.0.0.1'


def _row_dict(row) -> dict:
    if row is None:
        return {}
    return {k: row[k] for k in row.keys()}


def _table_exists(con, name: str) -> bool:
    try:
        row = con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone()
        return row is not None
    except Exception:
        return False


def _column_exists(con, table: str, column: str) -> bool:
    try:
        return any(r[1] == column for r in con.execute(f'PRAGMA table_info({table})').fetchall())
    except Exception:
        return False


def _date_range(days: int = 7) -> list[str]:
    from datetime import timedelta
    today = datetime.now().date()
    return [(today - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(days - 1, -1, -1)]


def _safe_float(value) -> float:
    try:
        return float(value or 0)
    except Exception:
        return 0.0



class RemoteDashboardData:
    def __init__(self, db_path: Path):
        self.db_path = Path(db_path)

    def connect(self):
        con = sqlite3.connect(
            self.db_path,
            timeout=SQLITE_TIMEOUT_SECONDS,
            detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES,
            cached_statements=128,
        )
        con.row_factory = sqlite3.Row
        con.execute('PRAGMA foreign_keys = ON')
        con.execute(f'PRAGMA busy_timeout = {int(SQLITE_TIMEOUT_SECONDS * 1000)}')
        con.execute('PRAGMA journal_mode = WAL')
        con.execute('PRAGMA synchronous = NORMAL')
        con.execute('PRAGMA temp_store = MEMORY')
        con.execute(f'PRAGMA cache_size = {-abs(SQLITE_CACHE_KIB)}')
        return con

    def snapshot(self) -> dict:
        today = _today()
        with self.connect() as con:
            one = lambda q, p=(): _row_dict(con.execute(q, p).fetchone())
            all_ = lambda q, p=(): [dict(r) for r in con.execute(q, p).fetchall()]
            sales = one('''SELECT COALESCE(SUM(total),0) total, COALESCE(SUM(total_profit),0) profit, COUNT(*) invoices
                           FROM sales WHERE date(created_at)=date(?)''', (today,))
            returns = one('''SELECT COALESCE(SUM(amount),0) total, COUNT(*) count
                             FROM returns WHERE date(created_at)=date(?)''', (today,))
            low_stock = one('SELECT COUNT(*) c FROM products WHERE active=1 AND quantity <= min_quantity')
            out_stock = one('SELECT COUNT(*) c FROM products WHERE active=1 AND quantity <= 0')
            debt = one('''WITH credit AS (
                            SELECT customer_id, SUM(CASE WHEN (subtotal-discount_amount+tax_amount) < 0 THEN 0 ELSE (subtotal-discount_amount+tax_amount) END) amount
                            FROM sales WHERE payment_method='آجل' GROUP BY customer_id
                          ), payments AS (
                            SELECT customer_id, SUM(amount) amount FROM customer_payments GROUP BY customer_id
                          ), returned AS (
                            SELECT s.customer_id, SUM(r.amount) amount FROM returns r JOIN sales s ON s.id=r.sale_id GROUP BY s.customer_id
                          )
                          SELECT COALESCE(SUM(COALESCE(credit.amount,0)-COALESCE(returned.amount,0)-COALESCE(payments.amount,0)),0) total_debt
                          FROM customers c
                          LEFT JOIN credit ON credit.customer_id=c.id
                          LEFT JOIN payments ON payments.customer_id=c.id
                          LEFT JOIN returned ON returned.customer_id=c.id
                          WHERE c.active=1''')
            top_products = all_('''SELECT product_name, SUM(quantity) qty, SUM(line_total) total
                                   FROM sale_items si JOIN sales s ON s.id=si.sale_id
                                   WHERE date(s.created_at)=date(?)
                                   GROUP BY product_id, product_name
                                   ORDER BY qty DESC LIMIT 10''', (today,))
            recent_sales = all_('''SELECT invoice_no, total, payment_method, created_at
                                   FROM sales ORDER BY id DESC LIMIT 10''')
            debt_rows = all_('''WITH credit AS (
                                   SELECT customer_id, SUM(CASE WHEN (subtotal-discount_amount+tax_amount) < 0 THEN 0 ELSE (subtotal-discount_amount+tax_amount) END) credit_sales
                                   FROM sales WHERE payment_method='آجل' GROUP BY customer_id
                                 ), returned AS (
                                   SELECT s.customer_id, SUM(r.amount) returns_amount
                                   FROM returns r JOIN sales s ON s.id=r.sale_id GROUP BY s.customer_id
                                 ), payments AS (
                                   SELECT customer_id, SUM(amount) payments FROM customer_payments GROUP BY customer_id
                                 )
                                 SELECT c.name, c.phone,
                                        COALESCE(credit.credit_sales,0) - COALESCE(returned.returns_amount,0) - COALESCE(payments.payments,0) balance
                                 FROM customers c
                                 LEFT JOIN credit ON credit.customer_id=c.id
                                 LEFT JOIN returned ON returned.customer_id=c.id
                                 LEFT JOIN payments ON payments.customer_id=c.id
                                 WHERE c.active=1
                                 ORDER BY balance DESC LIMIT 10''')
            low_rows = all_('''SELECT name, quantity, min_quantity FROM products
                               WHERE active=1 AND quantity <= min_quantity
                               ORDER BY quantity ASC, name LIMIT 10''')
            sales_series = self._sales_series(con, 7)
            cashier_rows = self._cashier_performance_today(con, today)
            shift_summary = self._shift_summary(con)
            security_alerts = self._security_alert_rows(con)
            debt_rows_filtered = [r for r in debt_rows if float(r.get('balance') or 0) > 0]
            alerts = self._cloud_alerts(
                sales=sales,
                returns=returns,
                low_stock=int(low_stock.get('c') or 0),
                out_stock=int(out_stock.get('c') or 0),
                debt_rows=debt_rows_filtered,
                shift_summary=shift_summary,
                security_alerts=security_alerts,
            )
            return {
                'generated_at': _now(),
                'sales': sales,
                'returns': returns,
                'low_stock': int(low_stock.get('c') or 0),
                'out_stock': int(out_stock.get('c') or 0),
                'total_debt': float(debt.get('total_debt') or 0),
                'top_products': top_products,
                'recent_sales': recent_sales,
                'debt_rows': debt_rows_filtered,
                'low_rows': low_rows,
                'sales_series': sales_series,
                'cashier_rows': cashier_rows,
                'shift_summary': shift_summary,
                'security_alerts': security_alerts,
                'cloud_alerts': alerts,
            }

    def _sales_series(self, con, days: int = 7) -> list[dict]:
        dates = _date_range(days)
        rows = []
        try:
            data = {
                r['d']: dict(r)
                for r in con.execute("""
                    SELECT date(created_at) d,
                           COALESCE(SUM(total),0) total,
                           COALESCE(SUM(total_profit),0) profit,
                           COUNT(*) invoices
                    FROM sales
                    WHERE date(created_at) >= date(?)
                    GROUP BY date(created_at)
                    ORDER BY d
                """, (dates[0],)).fetchall()
            }
        except Exception:
            data = {}
        for d in dates:
            row = data.get(d, {})
            rows.append({
                'date': d,
                'sales': _safe_float(row.get('total') if isinstance(row, dict) else 0),
                'profit': _safe_float(row.get('profit') if isinstance(row, dict) else 0),
                'invoices': int(_safe_float(row.get('invoices') if isinstance(row, dict) else 0)),
            })
        return rows

    def _cashier_performance_today(self, con, today: str) -> list[dict]:
        if not _table_exists(con, 'sales'):
            return []
        user_col = 'user_id' if _column_exists(con, 'sales', 'user_id') else ''
        if not user_col:
            return []
        try:
            return [dict(r) for r in con.execute("""
                SELECT COALESCE(NULLIF(u.full_name,''), u.username, 'غير محدد') cashier,
                       COUNT(s.id) invoices,
                       COALESCE(SUM(s.total),0) sales,
                       COALESCE(SUM(s.total_profit),0) profit
                FROM sales s
                LEFT JOIN users u ON u.id=s.user_id
                WHERE date(s.created_at)=date(?)
                GROUP BY s.user_id
                ORDER BY sales DESC
                LIMIT 10
            """, (today,)).fetchall()]
        except Exception:
            return []

    def _shift_summary(self, con) -> dict:
        summary = {
            'has_data': False,
            'open_count': 0,
            'open_shifts': [],
            'last_closed': None,
            'recent_closed': [],
            'total_difference_today': 0.0,
        }
        if not _table_exists(con, 'cashier_shifts'):
            return summary
        try:
            summary['has_data'] = True
            open_rows = [dict(r) for r in con.execute("""
                SELECT cs.id, cs.opened_at, cs.opening_cash, cs.expected_cash,
                       COALESCE(NULLIF(u.full_name,''), u.username, '-') cashier
                FROM cashier_shifts cs
                LEFT JOIN users u ON u.id=cs.user_id
                WHERE cs.status='open'
                ORDER BY cs.opened_at DESC
                LIMIT 10
            """).fetchall()]
            summary['open_shifts'] = open_rows
            summary['open_count'] = len(open_rows)
            closed = [dict(r) for r in con.execute("""
                SELECT cs.id, cs.opened_at, cs.closed_at, cs.opening_cash, cs.expected_cash,
                       cs.counted_cash, cs.cash_difference, cs.invoice_count,
                       COALESCE(NULLIF(u.full_name,''), u.username, '-') cashier
                FROM cashier_shifts cs
                LEFT JOIN users u ON u.id=cs.user_id
                WHERE cs.status='closed'
                ORDER BY cs.closed_at DESC, cs.id DESC
                LIMIT 10
            """).fetchall()]
            summary['recent_closed'] = closed
            summary['last_closed'] = closed[0] if closed else None
            diff = con.execute("""
                SELECT COALESCE(SUM(cash_difference),0) total
                FROM cashier_shifts
                WHERE status='closed' AND date(closed_at)=date(?)
            """, (_today(),)).fetchone()
            summary['total_difference_today'] = _safe_float(diff['total'] if diff else 0)
        except Exception as exc:
            log_exception(exc, 'cloud shift summary')
        return summary

    def _security_alert_rows(self, con) -> list[dict]:
        if not _table_exists(con, 'security_alerts'):
            return []
        try:
            return [dict(r) for r in con.execute("""
                SELECT created_at, alert_type, title, message, severity, status
                FROM security_alerts
                ORDER BY id DESC
                LIMIT 10
            """).fetchall()]
        except Exception:
            return []

    def _cloud_alerts(self, *, sales: dict, returns: dict, low_stock: int, out_stock: int,
                      debt_rows: list[dict], shift_summary: dict, security_alerts: list[dict]) -> list[dict]:
        alerts: list[dict] = []
        if out_stock > 0:
            alerts.append({'level': 'danger', 'title': 'منتجات نافدة', 'message': f'يوجد {out_stock} منتج نافد من المخزون.'})
        if low_stock > 0:
            alerts.append({'level': 'warning', 'title': 'مخزون منخفض', 'message': f'يوجد {low_stock} منتج تحت حد التنبيه.'})
        high_debts = [r for r in debt_rows if _safe_float(r.get('balance')) > 0]
        if high_debts:
            alerts.append({'level': 'warning', 'title': 'ديون تحتاج متابعة', 'message': f'يوجد {len(high_debts)} زبون لديهم ديون فعالة.'})
        returns_total = _safe_float(returns.get('total'))
        sales_total = _safe_float(sales.get('total'))
        if sales_total > 0 and returns_total / sales_total >= 0.20:
            alerts.append({'level': 'danger', 'title': 'مرتجعات مرتفعة', 'message': 'قيمة المرتجعات اليوم مرتفعة مقارنة بالمبيعات.'})
        last_closed = (shift_summary or {}).get('last_closed') or {}
        diff = abs(_safe_float(last_closed.get('cash_difference'))) if isinstance(last_closed, dict) else 0
        if diff > 0:
            alerts.append({'level': 'warning', 'title': 'فرق صندوق', 'message': f'آخر شفت مغلق يحتوي فرق صندوق { _money(diff) }.'})
        if (shift_summary or {}).get('open_count', 0):
            alerts.append({'level': 'info', 'title': 'شفت مفتوح', 'message': f"يوجد {(shift_summary or {}).get('open_count')} شفت مفتوح حالياً."})
        for a in security_alerts[:3]:
            alerts.append({'level': str(a.get('severity') or 'warning'), 'title': str(a.get('title') or a.get('alert_type') or 'تنبيه أمان'), 'message': str(a.get('message') or '')})
        if not alerts:
            alerts.append({'level': 'success', 'title': 'الوضع مستقر', 'message': 'لا توجد تنبيهات خطرة واضحة حالياً.'})
        return alerts[:10]

    def create_backup(self) -> Path:
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        target = BACKUP_DIR / f'remote_dashboard_backup_{datetime.now().strftime("%Y%m%d_%H%M%S_%f")}.db'
        shutil.copy2(self.db_path, target)
        return target


class RemoteDashboardHandler(BaseHTTPRequestHandler):
    server_version = 'MaxSalesRemoteDashboard/1.0'

    def log_message(self, fmt, *args):
        # Avoid noisy console logging; errors are written to logs/error.log.
        return

    def _auth_ok(self) -> bool:
        expected_user = self.server.config.get('username', 'admin')
        expected_pass = self.server.config.get('password', '')
        auth = self.headers.get('Authorization', '')
        if not auth.startswith('Basic '):
            return False
        try:
            raw = base64.b64decode(auth.split(' ', 1)[1]).decode('utf-8')
            username, password = raw.split(':', 1)
            return username == expected_user and password == expected_pass
        except Exception:
            return False

    def _require_auth(self) -> bool:
        if self._auth_ok():
            return True
        self.send_response(401)
        self.send_header('WWW-Authenticate', 'Basic realm="Max Sales Remote Dashboard"')
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write('<h3>تسجيل الدخول مطلوب</h3>'.encode('utf-8'))
        return False

    def _send_html(self, text: str, status: int = 200) -> None:
        data = text.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if not self._require_auth():
            return
        try:
            path = urlparse(self.path).path
            if path == '/backup':
                backup = self.server.data.create_backup()
                self._send_html(self._page(message=f'تم إنشاء نسخة احتياطية: {html.escape(str(backup.name))}'))
                return
            self._send_html(self._page())
        except Exception as exc:
            log_exception(exc, 'remote dashboard request')
            self._send_html('<h3>حدث خطأ أثناء تحميل لوحة التحكم. راجع logs/error.log</h3>', 500)

    def _page(self, message: str = '') -> str:
        snap = self.server.data.snapshot()
        sales = snap['sales']; returns = snap['returns']
        def tr(cells):
            return '<tr>' + ''.join(f'<td>{html.escape(str(c))}</td>' for c in cells) + '</tr>'
        recent_rows = ''.join(tr([r.get('created_at',''), r.get('invoice_no',''), _money(r.get('total')), r.get('payment_method','')]) for r in snap['recent_sales']) or '<tr><td colspan="4">لا توجد فواتير</td></tr>'
        low_rows = ''.join(tr([r.get('name',''), r.get('quantity',''), r.get('min_quantity','')]) for r in snap['low_rows']) or '<tr><td colspan="3">لا توجد منتجات ناقصة</td></tr>'
        debt_rows = ''.join(tr([r.get('name',''), r.get('phone',''), _money(r.get('balance'))]) for r in snap['debt_rows']) or '<tr><td colspan="3">لا توجد ديون فعالة</td></tr>'
        top_rows = ''.join(tr([r.get('product_name',''), r.get('qty',''), _money(r.get('total'))]) for r in snap['top_products']) or '<tr><td colspan="3">لا توجد مبيعات اليوم</td></tr>'
        msg = f'<div class="msg">{html.escape(message)}</div>' if message else ''
        return f'''<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>لوحة تحكم نظام ماكس للمبيعات</title>
<style>
body{{margin:0;background:#f3f7f8;color:#0f172a;font-family:Tahoma,Arial,sans-serif}}
.header{{background:linear-gradient(90deg,#0f3439,#0b8786);color:white;padding:18px 24px;display:flex;justify-content:space-between;align-items:center}}
.header h1{{margin:0;font-size:22px}} .header small{{opacity:.9}}
.wrap{{padding:20px;max-width:1280px;margin:auto}}
.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:18px}}
.card{{background:white;border:1px solid #dce8ea;border-radius:16px;padding:18px;box-shadow:0 8px 24px rgba(15,52,57,.08)}}
.card .label{{color:#64748b;font-size:14px;margin-bottom:8px}} .card .value{{font-weight:900;font-size:24px;color:#0f766e}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:14px}}
table{{width:100%;border-collapse:collapse;background:white;border-radius:14px;overflow:hidden}} th{{background:#e7f5f5;color:#0f3439}} th,td{{padding:10px;border-bottom:1px solid #edf2f3;text-align:right;font-size:14px}}
.panel{{background:white;border:1px solid #dce8ea;border-radius:16px;padding:14px;box-shadow:0 8px 24px rgba(15,52,57,.06)}}
.panel h2{{font-size:17px;margin:0 0 10px;color:#11383d}} .actions{{margin:16px 0;display:flex;gap:10px;flex-wrap:wrap}}
a.btn{{background:#0d9488;color:white;text-decoration:none;border-radius:12px;padding:10px 14px;font-weight:bold}} a.btn.gray{{background:#334155}}
.msg{{background:#dcfce7;color:#166534;border:1px solid #86efac;border-radius:12px;padding:12px;margin-bottom:12px;font-weight:bold}}
.footer{{text-align:center;color:#64748b;padding:18px}}
</style>
</head>
<body>
<div class="header"><h1>نظام ماكس للمبيعات - لوحة التحكم عن بعد</h1><small>آخر تحديث: {html.escape(snap['generated_at'])}</small></div>
<div class="wrap">{msg}
<div class="actions"><a class="btn" href="/">تحديث البيانات</a><a class="btn gray" href="/backup">إنشاء نسخة احتياطية</a></div>
<div class="cards">
<div class="card"><div class="label">مبيعات اليوم</div><div class="value">{_money(sales.get('total'))}</div></div>
<div class="card"><div class="label">ربح اليوم</div><div class="value">{_money(sales.get('profit'))}</div></div>
<div class="card"><div class="label">عدد الفواتير</div><div class="value">{int(sales.get('invoices') or 0)}</div></div>
<div class="card"><div class="label">مرتجعات اليوم</div><div class="value">{_money(returns.get('total'))}</div></div>
<div class="card"><div class="label">إجمالي الديون</div><div class="value">{_money(snap['total_debt'])}</div></div>
<div class="card"><div class="label">منتجات ناقصة / نافدة</div><div class="value">{snap['low_stock']} / {snap['out_stock']}</div></div>
</div>
<div class="grid">
<div class="panel"><h2>آخر الفواتير</h2><table><thead><tr><th>الوقت</th><th>الفاتورة</th><th>الإجمالي</th><th>الدفع</th></tr></thead><tbody>{recent_rows}</tbody></table></div>
<div class="panel"><h2>أفضل المنتجات اليوم</h2><table><thead><tr><th>المنتج</th><th>الكمية</th><th>الإجمالي</th></tr></thead><tbody>{top_rows}</tbody></table></div>
<div class="panel"><h2>منتجات تحتاج إعادة طلب</h2><table><thead><tr><th>المنتج</th><th>الكمية</th><th>حد التنبيه</th></tr></thead><tbody>{low_rows}</tbody></table></div>
<div class="panel"><h2>ديون تحتاج متابعة</h2><table><thead><tr><th>الزبون</th><th>الهاتف</th><th>الرصيد</th></tr></thead><tbody>{debt_rows}</tbody></table></div>
</div>
</div><div class="footer">إذا واجهت أي مشكلة يرجى التواصل مع الدعم الفني 07805245980<br>© PY : MOHIMEN MAX</div>
</body></html>'''


class RemoteDashboardServer(ThreadingHTTPServer):
    def __init__(self, server_address, handler, data: RemoteDashboardData, config: dict):
        super().__init__(server_address, handler)
        self.data = data
        self.config = config


class RemoteDashboardManager:
    def __init__(self, db_path: Path):
        self.db_path = Path(db_path)
        self.config = _load_config()
        self.server: RemoteDashboardServer | None = None
        self.thread: threading.Thread | None = None

    def configure(self, host: str, port: int, username: str, password: str) -> None:
        if self.is_running():
            raise RuntimeError('أوقف لوحة التحكم قبل تغيير الإعدادات')
        self.config.update({'host': host, 'port': int(port), 'username': username.strip() or 'admin', 'password': password.strip() or secrets.token_urlsafe(8)})
        _save_config(self.config)

    def reset_password(self) -> str:
        if self.is_running():
            raise RuntimeError('أوقف لوحة التحكم قبل تغيير كلمة المرور')
        password = secrets.token_urlsafe(8)
        self.config['password'] = password
        _save_config(self.config)
        return password

    def start(self) -> None:
        if self.is_running():
            return
        data = RemoteDashboardData(self.db_path)
        host = str(self.config.get('host') or '127.0.0.1')
        port = int(self.config.get('port') or 8765)
        self.server = RemoteDashboardServer((host, port), RemoteDashboardHandler, data, self.config)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.config['enabled'] = True
        _save_config(self.config)

    def stop(self) -> None:
        if self.server:
            self.server.shutdown()
            self.server.server_close()
        self.server = None
        self.thread = None
        self.config['enabled'] = False
        _save_config(self.config)

    def is_running(self) -> bool:
        return self.server is not None and self.thread is not None and self.thread.is_alive()

    def url(self) -> str:
        host = str(self.config.get('host') or '127.0.0.1')
        shown = '127.0.0.1' if host in ('127.0.0.1', 'localhost') else _local_ip()
        return f'http://{shown}:{int(self.config.get("port") or 8765)}'


_MANAGER: RemoteDashboardManager | None = None


def get_remote_dashboard_manager(db_path: Path) -> RemoteDashboardManager:
    global _MANAGER
    if _MANAGER is None or Path(db_path) != _MANAGER.db_path:
        _MANAGER = RemoteDashboardManager(Path(db_path))
    return _MANAGER
