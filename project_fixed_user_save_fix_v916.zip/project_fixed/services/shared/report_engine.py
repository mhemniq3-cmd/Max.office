from __future__ import annotations

import csv
import html
from pathlib import Path
from datetime import datetime
from typing import Iterable, Mapping, Any


def _safe(value: Any) -> str:
    return html.escape(str(value if value is not None else ''))


class ReportEngine:
    """Unified CSV/HTML report exporter for all modules."""

    def __init__(self, export_root: str | Path = 'exports'):
        self.export_root = Path(export_root)
        self.export_root.mkdir(parents=True, exist_ok=True)

    def csv(self, name: str, rows: Iterable[Mapping[str, Any]], fields: list[str] | None = None) -> Path:
        rows = list(rows)
        if fields is None:
            fields = list(rows[0].keys()) if rows else []
        path = self.export_root / f'{name}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        with path.open('w', encoding='utf-8-sig', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for row in rows:
                writer.writerow({k: row.get(k, '') for k in fields})
        return path

    def html_table(self, name: str, title: str, rows: Iterable[Mapping[str, Any]], fields: list[str] | None = None) -> Path:
        rows = list(rows)
        if fields is None:
            fields = list(rows[0].keys()) if rows else []
        head = ''.join(f'<th>{_safe(f)}</th>' for f in fields)
        body = ''.join('<tr>' + ''.join(f'<td>{_safe(row.get(f, ""))}</td>' for f in fields) + '</tr>' for row in rows)
        path = self.export_root / f'{name}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.html'
        path.write_text(
            "<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'>"
            f"<title>{_safe(title)}</title><style>body{{font-family:Tahoma,Arial;margin:24px}}table{{width:100%;border-collapse:collapse}}th,td{{border:1px solid #ddd;padding:8px;text-align:center}}th{{background:#eef6ff}}</style></head>"
            f"<body><h2>{_safe(title)}</h2><table><tr>{head}</tr>{body}</table></body></html>",
            encoding='utf-8',
        )
        return path
