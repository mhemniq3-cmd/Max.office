from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any
import html
import re

_CONTROL_RE = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]+')


def clean_text(value: Any, max_len: int = 500) -> str:
    text = _CONTROL_RE.sub(' ', str(value or ''))
    text = ' '.join(text.replace('\r', ' ').replace('\n', ' ').split())
    if len(text) > max_len:
        text = text[: max_len - 1] + '…'
    return text


@dataclass(frozen=True)
class Notification:
    channel: str
    subject: str
    message: str
    severity: str = 'info'
    target_user_id: int | None = None


class NotificationCenter:
    """Small central notification helper used by feature modules.

    It stores notifications locally first. Email/SMS/WhatsApp integrations can later
    be added here once, instead of duplicating sending logic in sales/security/coupons.
    """

    def __init__(self, db):
        self.db = db

    def ensure_schema(self) -> None:
        self.db.conn.execute(
            '''CREATE TABLE IF NOT EXISTS system_notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel TEXT NOT NULL DEFAULT 'in_app',
                severity TEXT NOT NULL DEFAULT 'info',
                subject TEXT NOT NULL,
                message TEXT,
                target_user_id INTEGER,
                status TEXT NOT NULL DEFAULT 'pending',
                created_at TEXT NOT NULL,
                sent_at TEXT
            )'''
        )
        self.db.conn.execute('CREATE INDEX IF NOT EXISTS idx_system_notifications_status ON system_notifications(status, created_at)')
        self.db.conn.commit()

    def send(self, notification: Notification) -> int:
        self.ensure_schema()
        subject = clean_text(notification.subject, 180)
        message = clean_text(notification.message, 2000)
        channel = clean_text(notification.channel, 40) or 'in_app'
        severity = clean_text(notification.severity, 20) or 'info'
        cur = self.db.conn.execute(
            '''INSERT INTO system_notifications(channel, severity, subject, message, target_user_id, status, created_at)
               VALUES (?, ?, ?, ?, ?, 'pending', ?)''',
            (channel, severity, subject, message, notification.target_user_id, datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
        )
        self.db.conn.commit()
        return int(cur.lastrowid)

    @staticmethod
    def html_safe(value: Any) -> str:
        return html.escape(clean_text(value, 4000))
