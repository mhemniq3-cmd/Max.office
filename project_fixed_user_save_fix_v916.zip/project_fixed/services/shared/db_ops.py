from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Iterable


@contextmanager
def transaction(db):
    with db.conn:
        yield db.conn


def fetch_one(db, query: str, params: Iterable[Any] = ()):  # noqa: ANN001
    return db.one(query, tuple(params))


def fetch_all(db, query: str, params: Iterable[Any] = ()):  # noqa: ANN001
    return db.all(query, tuple(params))


def execute(db, query: str, params: Iterable[Any] = (), auto_commit: bool = True):  # noqa: ANN001
    return db.execute(query, tuple(params), auto_commit=auto_commit)
