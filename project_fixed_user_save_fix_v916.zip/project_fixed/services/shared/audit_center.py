from __future__ import annotations

import json
from datetime import datetime
from typing import Any
from services.shared.notification_center import clean_text


class AuditCenter:
    """Single audit writer for login/activity/change operations."""

    def __init__(self, db):
        self.db = db

    def ensure_schema(self) -> None:
        self.db.conn.execute(
            '''CREATE TABLE IF NOT EXISTS unified_audit_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                action TEXT NOT NULL,
                table_name TEXT,
                record_id INTEGER,
                old_values TEXT,
                new_values TEXT,
                user_id INTEGER,
                username TEXT,
                reason TEXT,
                created_at TEXT NOT NULL
            )'''
        )
        self.db.conn.execute('CREATE INDEX IF NOT EXISTS idx_unified_audit_category_date ON unified_audit_events(category, created_at)')
        self.db.conn.commit()

    def write(self, category: str, action: str, table_name: str = '', record_id: int | None = None,
              old_values: Any = None, new_values: Any = None, user_id: int | None = None,
              username: str = '', reason: str = '') -> int:
        self.ensure_schema()
        old_json = json.dumps(old_values, ensure_ascii=False, sort_keys=True) if old_values is not None else None
        new_json = json.dumps(new_values, ensure_ascii=False, sort_keys=True) if new_values is not None else None
        cur = self.db.conn.execute(
            '''INSERT INTO unified_audit_events(category, action, table_name, record_id, old_values, new_values, user_id, username, reason, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            (clean_text(category, 60), clean_text(action, 100), clean_text(table_name, 80), record_id,
             old_json, new_json, user_id, clean_text(username, 80), clean_text(reason, 300), datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
        )
        self.db.conn.commit()
        return int(cur.lastrowid)
