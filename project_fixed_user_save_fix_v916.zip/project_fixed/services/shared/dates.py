from __future__ import annotations

import re
from datetime import date, datetime
from typing import Any

ISO_DATETIME = '%Y-%m-%d %H:%M:%S'


def now_text() -> str:
    return datetime.now().strftime(ISO_DATETIME)


def normalize_iso_date(value: Any, *, allow_empty: bool = True) -> str:
    text = str(value or '').strip()
    if not text:
        if allow_empty:
            return ''
        raise ValueError('التاريخ مطلوب')
    m = re.match(r'^(\d{4})-(\d{1,2})-(\d{1,2})', text)
    if m:
        y, mo, d = map(int, m.groups())
        return date(y, mo, d).isoformat()
    m = re.match(r'^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$', text)
    if m:
        d, mo, y = map(int, m.groups())
        return date(y, mo, d).isoformat()
    raise ValueError(f'صيغة التاريخ غير صحيحة: {text}. استخدم YYYY-MM-DD')
