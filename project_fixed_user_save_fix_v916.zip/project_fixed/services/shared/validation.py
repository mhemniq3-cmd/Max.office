from __future__ import annotations

from typing import Any


class ValidationError(ValueError):
    """User-facing validation failure."""


def clean_text(value: Any, max_len: int = 500, *, required: bool = False, field: str = 'الحقل') -> str:
    text = str(value or '').strip()
    if required and not text:
        raise ValidationError(f'{field} مطلوب')
    return text[:max(1, int(max_len))]


def require_value(value: Any, field: str) -> Any:
    if value is None or str(value).strip() == '':
        raise ValidationError(f'{field} مطلوب')
    return value


def to_int(value: Any, default: int = 0, *, min_value: int | None = None, field: str = 'القيمة') -> int:
    try:
        result = int(float(str(value).replace(',', '').strip()))
    except Exception:
        result = default
    if min_value is not None and result < min_value:
        raise ValidationError(f'{field} يجب أن يكون {min_value} أو أكثر')
    return result


def assert_positive_int(value: Any, field: str) -> int:
    return to_int(value, min_value=1, field=field)
