from __future__ import annotations

from typing import Any


def escape_like(term: str) -> str:
    return str(term or '').replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')


def like_pattern(term: str) -> str:
    return f"%{escape_like(str(term or '').strip())}%"


def build_like_filter(columns: list[str], term: str) -> tuple[str, list[Any]]:
    if not term:
        return '', []
    pattern = like_pattern(term)
    return '(' + ' OR '.join(f"{col} LIKE ? ESCAPE '\\'" for col in columns) + ')', [pattern] * len(columns)


def clamp_limit(limit: Any, default: int = 300, maximum: int = 1000) -> int:
    try:
        value = int(limit)
    except Exception:
        value = default
    return max(1, min(value, maximum))
