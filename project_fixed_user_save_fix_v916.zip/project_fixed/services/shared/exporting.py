from __future__ import annotations

import csv
import re
from datetime import datetime
from pathlib import Path
from typing import Any


def export_rows_csv(export_dir: Path, filename: str, headers: list[str], rows: list[list[Any]]) -> Path:
    export_dir.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r'[^\w\-\u0600-\u06FF]+', '_', str(filename or 'export'), flags=re.UNICODE)[:80]
    path = export_dir / f'{safe}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)
    return path
