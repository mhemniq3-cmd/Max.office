from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, getcontext
from typing import Any, Iterable

getcontext().prec = 28
TWOPLACES = Decimal('0.01')


def D(value: Any, default: str = '0') -> Decimal:
    try:
        if isinstance(value, Decimal):
            return value
        text = str(value if value is not None else default).replace(',', '').strip()
        return Decimal(text or default)
    except (InvalidOperation, ValueError, TypeError):
        return Decimal(default)


def money2(value: Any) -> Decimal:
    return D(value).quantize(TWOPLACES, rounding=ROUND_HALF_UP)


def db_money(value: Any) -> float:
    return float(money2(value))


@dataclass(frozen=True)
class InvoiceLine:
    item: dict[str, Any]
    line_total: Decimal
    line_discount: Decimal
    net_before_tax: Decimal
    commission_amount: Decimal
    profit_amount: Decimal


@dataclass(frozen=True)
class InvoiceTotals:
    subtotal: Decimal
    discount_amount: Decimal
    discount_type: str
    discount_percent: Decimal
    taxable_base: Decimal
    tax_amount: Decimal
    total: Decimal
    commission: Decimal
    profit: Decimal
    lines: list[InvoiceLine]


def resolve_discount(subtotal: Decimal, value: Any, discount_type: str) -> tuple[Decimal, str, Decimal]:
    dtype = 'percent' if str(discount_type or '').strip() == 'percent' else 'amount'
    raw = max(D(value), Decimal('0'))
    if subtotal <= 0:
        if raw:
            raise ValueError('لا يمكن تطبيق خصم على فاتورة قيمتها صفر')
        return Decimal('0'), dtype, Decimal('0')
    if dtype == 'percent':
        if raw > 100:
            raise ValueError('نسبة الخصم لا يمكن أن تكون أكبر من 100%')
        amount = subtotal * raw / Decimal('100')
    else:
        if raw > subtotal:
            raise ValueError('قيمة الخصم لا يمكن أن تكون أكبر من إجمالي الفاتورة')
        amount = raw
    amount = money2(amount)
    if amount >= subtotal:
        raise ValueError('الخصم لا يمكن أن يساوي أو يتجاوز قيمة الفاتورة')
    pct = money2(amount / subtotal * Decimal('100')) if subtotal else Decimal('0')
    return amount, dtype, pct


def calculate_invoice_totals(cart: Iterable[dict[str, Any]], discount_value: Any = 0, discount_type: str = 'amount', tax_percent: Any = 0) -> InvoiceTotals:
    items = list(cart or [])
    subtotal = money2(sum(D(i.get('quantity')) * D(i.get('unit_price')) for i in items))
    discount, dtype, discount_pct = resolve_discount(subtotal, discount_value, discount_type)
    taxable_base = money2(max(subtotal - discount, Decimal('0')))
    tax_amount = money2(taxable_base * max(D(tax_percent), Decimal('0')) / Decimal('100'))
    total = money2(taxable_base + tax_amount)
    lines: list[InvoiceLine] = []
    commission = Decimal('0')
    profit = Decimal('0')
    for item in items:
        line_total = money2(D(item.get('quantity')) * D(item.get('unit_price')))
        line_discount = money2(discount * line_total / subtotal) if subtotal else Decimal('0')
        net = money2(line_total - line_discount)
        line_commission = money2(net * D(item.get('commission_percent')) / Decimal('100'))
        line_profit = money2(D(item.get('quantity')) * (D(item.get('unit_price')) - D(item.get('cost_price'))) - line_discount)
        commission += line_commission
        profit += line_profit
        lines.append(InvoiceLine(item=item, line_total=line_total, line_discount=line_discount, net_before_tax=net, commission_amount=line_commission, profit_amount=line_profit))
    return InvoiceTotals(subtotal=subtotal, discount_amount=discount, discount_type=dtype, discount_percent=discount_pct, taxable_base=taxable_base, tax_amount=tax_amount, total=total, commission=money2(commission), profit=money2(profit), lines=lines)
