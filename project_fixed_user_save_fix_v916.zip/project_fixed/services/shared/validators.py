from __future__ import annotations

from decimal import Decimal, InvalidOperation
import re
from typing import Any

_PHONE_RE = re.compile(r'^[0-9+\-()\s]{6,20}$')
_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


def as_decimal(value: Any, default: Decimal = Decimal('0')) -> Decimal:
    try:
        text = str(value if value is not None else '').strip().replace(',', '')
        return Decimal(text) if text else default
    except (InvalidOperation, ValueError, TypeError):
        return default


def require_positive_money(value: Any, field_name: str) -> Decimal:
    amount = as_decimal(value)
    if amount <= 0:
        raise ValueError(f'{field_name} يجب أن يكون أكبر من صفر')
    return amount


def validate_phone(value: Any, required: bool = False) -> str:
    text = str(value or '').strip()
    if not text and not required:
        return ''
    if not _PHONE_RE.match(text):
        raise ValueError('رقم الهاتف غير صالح')
    return text


def validate_email(value: Any, required: bool = False) -> str:
    text = str(value or '').strip()
    if not text and not required:
        return ''
    if not _EMAIL_RE.match(text):
        raise ValueError('البريد الإلكتروني غير صالح')
    return text


def require_text(value: Any, field_name: str, max_len: int = 200) -> str:
    text = ' '.join(str(value or '').split())
    if not text:
        raise ValueError(f'{field_name} مطلوب')
    if len(text) > max_len:
        raise ValueError(f'{field_name} طويل جداً')
    return text
