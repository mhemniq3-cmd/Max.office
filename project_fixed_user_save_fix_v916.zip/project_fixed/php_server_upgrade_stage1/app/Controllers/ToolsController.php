<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\SalesModel;
use JsonException;

final class ToolsController
{
    public function __construct(private readonly SalesModel $salesModel)
    {
    }

    /**
     * Minimal JSON endpoint style method. Adapt to your router/framework.
     *
     * @return array<string, mixed>
     */
    public function latestSales(array $request = []): array
    {
        $limit = (int) ($request['limit'] ?? 50);

        return [
            'ok' => true,
            'data' => $this->salesModel->latestSales($limit),
        ];
    }

    /**
     * @throws JsonException
     */
    public function jsonResponse(array $payload, int $statusCode = 200): void
    {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}
