<?php

declare(strict_types=1);

namespace App\Models;

use PDO;

final class SalesModel
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    /**
     * Returns the latest sales rows. Adjust table/columns to match the current schema.
     *
     * @return list<array<string, mixed>>
     */
    public function latestSales(int $limit = 50): array
    {
        $limit = max(1, min($limit, 500));

        $statement = $this->pdo->prepare(
            'SELECT * FROM sales ORDER BY created_at DESC, id DESC LIMIT :limit'
        );
        $statement->bindValue(':limit', $limit, PDO::PARAM_INT);
        $statement->execute();

        return $statement->fetchAll();
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findSaleById(int $id): ?array
    {
        $statement = $this->pdo->prepare('SELECT * FROM sales WHERE id = :id LIMIT 1');
        $statement->execute(['id' => $id]);

        $row = $statement->fetch();

        return $row ?: null;
    }

    /**
     * @param array<string, mixed> $payload
     */
    public function createSale(array $payload): int
    {
        $customerId = $payload['customer_id'] ?? null;
        $total = $payload['total'] ?? 0;
        $discount = $payload['discount'] ?? 0;
        $notes = $payload['notes'] ?? null;

        $statement = $this->pdo->prepare(
            'INSERT INTO sales (customer_id, total, discount, notes, created_at)
             VALUES (:customer_id, :total, :discount, :notes, NOW())'
        );

        $statement->execute([
            'customer_id' => $customerId,
            'total' => $total,
            'discount' => $discount,
            'notes' => $notes,
        ]);

        return (int) $this->pdo->lastInsertId();
    }
}
