<?php

declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOException;
use RuntimeException;

final readonly class DatabaseConfig
{
    public function __construct(
        public string $host,
        public string $database,
        public string $username,
        public string $password,
        public string $charset = 'utf8mb4',
        public bool $persistent = true,
    ) {
    }

    /**
     * @param array{host:string,database:string,username:string,password:string,charset?:string,persistent?:bool} $config
     */
    public static function fromArray(array $config): self
    {
        return new self(
            host: $config['host'],
            database: $config['database'],
            username: $config['username'],
            password: $config['password'],
            charset: $config['charset'] ?? 'utf8mb4',
            persistent: $config['persistent'] ?? true,
        );
    }
}

final class Database
{
    private ?PDO $pdo = null;

    public function __construct(private readonly DatabaseConfig $config)
    {
    }

    public function connection(): PDO
    {
        if ($this->pdo instanceof PDO) {
            return $this->pdo;
        }

        $dsn = sprintf(
            'mysql:host=%s;dbname=%s;charset=%s',
            $this->config->host,
            $this->config->database,
            $this->config->charset,
        );

        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_PERSISTENT => $this->config->persistent,
        ];

        try {
            $this->pdo = new PDO($dsn, $this->config->username, $this->config->password, $options);
            return $this->pdo;
        } catch (PDOException $exception) {
            throw new RuntimeException('Database connection failed.', previous: $exception);
        }
    }
}
