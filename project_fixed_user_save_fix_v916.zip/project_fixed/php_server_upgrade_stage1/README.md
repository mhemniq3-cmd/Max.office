# PHP Server Upgrade Stage 1

This folder is a PHP 8.3/8.4 modernization scaffold for the server-side files mentioned in the migration plan.

It is intentionally separated from the Python/Qt app because the uploaded archive did not contain PHP source files.

Main entry points:
- `app/Core/Database.php`
- `app/Models/SalesModel.php`
- `app/Controllers/ToolsController.php`
- `docs/PHP_STAGE1_UPGRADE_AR.md`
