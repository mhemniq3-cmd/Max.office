# المرحلة 1: تحديث الجانب الخادمي PHP 8.3/8.4

## نتيجة الفحص
الأرشيف الحالي لا يحتوي على ملفات PHP باسم `tools_controller.php` أو `sales_model.php`. المشروع المرفوع يبدو تطبيق Python/Qt. لذلك لم يتم تعديل منطق ملفات PHP الأصلية مباشرة، وتمت إضافة قالب تحديث جاهز ومنظم داخل:

`php_server_upgrade_stage1/`

## ماذا تحتوي الحزمة؟
- `app/Core/Database.php`: اتصال PDO حديث مع `utf8mb4`، وتعطيل prepared statements الوهمية، وإمكانية الاتصالات المستمرة.
- `app/Models/SalesModel.php`: نموذج PSR-12 باسم `SalesModel` و namespace `App\Models`.
- `app/Controllers/ToolsController.php`: Controller منظم باسم `ToolsController` و namespace `App\Controllers`.
- `config/database.php`: إعدادات اتصال تعتمد على متغيرات البيئة.
- `composer.json`: Autoload PSR-4 وأدوات فحص PSR-12 و PHPStan.

## أوامر مقترحة عند الدمج في مشروع PHP حقيقي
```bash
composer install
composer dump-autoload
composer cs
composer analyse
```

## ملاحظات مهمة
1. يفضل PHP 8.4 أو أحدث عند توفره في الاستضافة؛ PHP 8.3 ما زال صالحًا لكنه أقل مستقبلية من 8.4.
2. `PDO::ATTR_PERSISTENT => true` مفيد غالبًا، لكن يجب اختباره على الاستضافة، خصوصًا مع MySQL محدود الاتصالات.
3. قبل الاعتماد النهائي، يجب مطابقة أسماء الجداول والأعمدة مع قاعدة بياناتك الحالية.
4. عند إرسال الملفات الأصلية `tools_controller.php` و `sales_model.php` يمكن تحويلها مباشرة دون تغيير المنطق.
