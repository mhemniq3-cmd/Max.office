# سجل الإصلاحات المطبقة — Max Sales v1.0.0

تاريخ التطبيق: 2026-05-16  
الإصدار المُصلَح بناءً على: Stage 27 Return Financial Reconciliation

---

## 🔴 إصلاحات حرجة

### إصلاح 1 — توحيد Database.__init__ Monkey-Patching
**الملف:** `db/database_core.py`

كانت `Database.__init__` تُعاد كتابتها 6 مرات عبر ملفات مختلفة (v11/v25/v27 في database_core.py، وv4510/v4511/v44 في service_patches). هذه السلسلة الهشة كانت تعني أنه عند أي تغيير في ترتيب الاستيراد، يمكن أن تُفقد جداول Schema كاملة بصمت.

**الحل:** دمج V11/V25/V27 في دالة `_create_extended_schema()` واحدة داخل الكلاس، تُستدعى من `__init__()` مباشرةً.

---

### إصلاح 2 — خطأ في حساب الربح عند وجود خصم على الصنف
**الملف:** `services/domain/persistence/sales_finance_writes.py`

المعادلة القديمة كانت:
```python
profit += qty * (unit_price - cost_price) - item_discount - global_share
```
هذا خاطئ لأن `item_discount` يُخصم من الربح كرقم مطلق بدلاً من حساب سعر البيع الفعلي.

**المعادلة الصحيحة:**
```python
profit = line_net - qty * cost_price
# حيث line_net = صافي السطر بعد جميع الخصومات
```

---

### إصلاح 3 — إزالة CREATE TABLE من create_indexes()
**الملف:** `db/database_core.py`

دالة `create_indexes()` كانت تحتوي على عبارات `CREATE TABLE IF NOT EXISTS` لجداول معرّفة أصلاً في `create_schema()`. أزلناها وأبقينا الدالة للفهارس فقط.

---

### إصلاح 4 — إضافة معاملة أتمية لترحيل customer_payments
**الملف:** `db/database_core.py — upgrade_schema()`

عملية نسخ السجلات القديمة من `customer_payments` إلى `payments` أصبحت محاطة بـ `self.transaction()` لضمان اتساق البيانات، مع تسجيل أي خطأ بدلاً من ابتلاعه بصمت.

---

## 🟡 إصلاحات التحذيرات

### إصلاح 5 — إزالة الكود الميت من main.py
**الملف:** `main.py`

أُزيل بلوك `if qdarkstyle is not None: pass` الذي لا يؤدي أي وظيفة.

---

### إصلاح 6 — استبدال الاستيراد بالنجمة في auth_service.py
**الملف:** `services/domain/auth_service.py`

استُبدل `from services.core_common import *` باستيرادات صريحة لكل ما يُستخدم فعلاً.

---

### إصلاح 7 — تأمين منطق is_admin_user()
**الملف:** `services/domain/auth_service.py`

أُزيل الشرط الهش الذي كان يُعطي صلاحيات المدير لأي مستخدم يمتلك `can_users + can_goals`. الآن الدالة تتحقق فقط من `role` الصريح.

---

### إصلاح 8 — تسجيل الاستثناءات المُبتلَعة
**الملف:** `services/service_patches/portability_decimal_hardening.py`

الاستثناءات التي كانت تُلتهم بـ `except: pass` أصبحت تُسجَّل عبر `logging.warning()`.

---

### إصلاح 9 — تصحيح التقريب في توزيع الخصم العالمي
**الملف:** `services/domain/persistence/sales_finance_writes.py`

عند توزيع الخصم العالمي على الأصناف، الصنف الأخير الآن يأخذ الباقي الدقيق بدلاً من قيمة مقرّبة، مما يضمن أن مجموع الحصص يساوي الخصم الإجمالي بالضبط.

---

## 🔵 تحسينات الجودة

### إصلاح 10 — تعزيز سياسة كلمات المرور
**الملف:** `db/database_core.py — validate_password_strength()`

- توسيع قائمة الكلمات الشائعة المحظورة من 7 إلى 23 كلمة
- إضافة شرط: يجب أن تحتوي كلمة المرور على رقم أو رمز خاص واحد على الأقل

---

### إصلاح 13 — إضافة user_id إلى جدول employees
**الملف:** `db/database_core.py`

إضافة عمود `user_id INTEGER` مع Foreign Key إلى جدول `users` للربط الصريح بين الموظفين وحسابات النظام، بدلاً من الاعتماد على مطابقة الأسماء.


---

## الجولة الثانية — إصلاحات إضافية

### إصلاح 14 — نفس خطأ الربح في stability_cleanup.py (المسار الفعلي للبيع)
**الملف:** `services/service_patches/stability_cleanup.py:525,539,598`

الخطأ نفسه المُصلَح في `sales_finance_writes.py` كان موجوداً في `_complete_sale_v4517415` وهو المسار الحقيقي المستخدم. تم تطبيق نفس الإصلاح:
```python
# قبل: profit = qty*(price-cost) - line_discount  ← خطأ
# بعد: profit = line_net - qty*cost_price         ← صحيح
```

---

### إصلاح 15 — منع المخزون السالب بتحديث ذري
**الملف:** `services/domain/persistence/sales_finance_writes.py`

استُبدل:
```python
newq = oldq - qty
UPDATE products SET quantity=newq WHERE id=?
```
بـ:
```python
UPDATE products SET quantity = quantity - ? WHERE id=? AND quantity >= ?
# ثم فحص rowcount == 1، وإلا رفع ValueError
```
هذا يمنع race condition في حالة بيعَين متزامنَين لنفس المنتج.

---

### إصلاح 16 — منع الإقلاع بكلمات مرور افتراضية (خادم سحابي)
**الملف:** `cloud_dashboard_server/app.py`

بدلاً من طباعة تحذير، يرفع النظام الآن `RuntimeError` ويمنع الخادم من الإقلاع إن كانت `API_KEY` أو `ADMIN_PASSWORD` على قيمهما الافتراضية.

---

### إصلاح 17 — إضافة LIMIT 2000 لاستعلامات كشف حساب العملاء
**الملفات:** `medium_security_fixes.py · stability_cleanup.py · v44_accounting_clean_release.py · people_service.py`

جميع استعلامات المبيعات والمرتجعات والمدفوعات في كشف حساب العميل أصبح عليها حد أقصى 2000 سجل.

---

### إصلاح 18 — تغيير الاستماع الافتراضي من 0.0.0.0 إلى 127.0.0.1
**الملف:** `cloud_dashboard_server/app.py`

---

### إصلاح 19 — تنظيف جدول login_attempts تلقائياً
**الملف:** `services/service_patches/v11_safety.py`

عند كل تسجيل دخول ناجح، تُحذف السجلات الأقدم من 30 يوماً.

---

### إصلاح 20 — إخفاء وقت الخادم من نقطة /health
**الملف:** `cloud_dashboard_server/app.py`

نقطة `/health` لا تُفصح عن وقت الخادم بعد الآن.

---

### إصلاح 22 — تحذير واضح على كود PHP التجريبي
**الملف:** `php_server_upgrade_stage1/WARNING.md`

إضافة ملف تحذير صريح يمنع النشر العرضي للكود غير المكتمل.

---

## الجولة الثالثة — إصلاح المشاكل الكامنة

### إصلاح 23 — تنظيف v44_accounting_clean_release.py بالكامل
**الملف:** `services/service_patches/v44_accounting_clean_release.py`

كانت دالة `_complete_sale_v44` تحتوي على 3 مشاكل كامنة (غير نشطة):

**أ) معادلة الربح الخاطئة:**
```python
# قبل: خطأ
item_profit = qty * (unit_price - cost_price) - line_discount
# بعد: صحيح
item_profit = net_line - qty * cost_price
```

**ب) تحديث المخزون غير الذري:**
استُبدل بـ UPDATE مشروط يرفض العملية ذرياً إن لم يكن المخزون كافياً.

**ج) إلغاء تسجيل الدالة:**
أُضيف تعليق توضيحي لمنع تسجيل v44 كمسار نشط،
نظراً لأن `stability_cleanup._complete_sale_v4517415` هو المسار المُصلَح والمُعتمد.

---

### إصلاح 24 — إزالة كلمة المرور الافتراضية الثابتة للمدير
**الملف:** `db/database_core.py`

لم تعد قاعدة البيانات الجديدة تُنشئ دخول `admin/admin`. عند أول إنشاء لقاعدة البيانات، يولّد النظام كلمة مرور مؤقتة قوية ويحفظها في:

```text
settings/initial_admin_password.txt
```

أو يستخدم المتغير `MAX_SALES_INITIAL_ADMIN_PASSWORD` عند ضبطه قبل أول تشغيل. يبقى `must_change_password=1` مفعلًا حتى يغيّر المدير كلمة المرور.

---

### إصلاح 25 — توحيد تشغيل الاختبارات ومسار الاستيراد
**الملفات:** `pyproject.toml`, `tests/conftest.py`, `run_tests.bat`

أضيف إعداد `pythonpath = ["."]` وملف `conftest.py` حتى لا تفشل الاستيرادات عند تشغيل `pytest` مباشرة. كما أضيف ملف `run_tests.bat` يستدعي:

```powershell
python -m compileall -q .
python -m pytest -q
```

---

### إصلاح 26 — توثيق حدود دمج الترقيعات
**الملف:** `PATCHES_CONSOLIDATION.md`

تم توثيق مجلدات `service_patches` و `ui_patches` كطبقة توافق مستقرة، مع قاعدة واضحة: الميزات الجديدة تذهب إلى `services/domain` و `services/data` و `ui/pages` بدل إضافة ترقيعات جديدة.
