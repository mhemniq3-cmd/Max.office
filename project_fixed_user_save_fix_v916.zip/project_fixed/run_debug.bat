@echo off
cd /d "%~dp0"
echo ================================
echo   Max Sales - Debug Mode
echo ================================
echo.
python --version
echo.
echo Starting main.py ...
echo.
python main.py
echo.
echo ================================
echo Exit code: %ERRORLEVEL%
echo ================================
pause
