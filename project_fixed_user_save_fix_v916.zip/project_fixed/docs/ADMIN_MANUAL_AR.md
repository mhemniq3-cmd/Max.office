# دليل الإدارة والصيانة - Max Sales v1.0.0

## البنية الحالية

```text
services/
├── domain/                 # منطق الأعمال الحديث: قراءة، تقارير، حسابات، إعدادات
├── domain/persistence/     # مسار الحفظ Native الوحيد للمبيعات والمالية
├── data/                   # الاتصال الآمن، الاستعلامات، والترقيات الذكية
├── service_patches/        # تحميل ميزات AppService القديمة غير المتعلقة بالحفظ
└── core_bridge.py          # نقطة ربط وتوثيق بين الطبقات
```

## إعدادات البيئة المهمة

```env
MAX_SALES_NATIVE_PERSISTENCE=on
MAX_SALES_DB_PATH=./database/max_sales.db
MAX_SALES_SQLITE_TIMEOUT=10
MAX_SALES_SQLITE_CACHE_KIB=20000
MAX_SALES_BACKUP_PATH=./backups
MAX_SALES_EXPORT_PATH=./exports
MAX_SALES_ARCHIVE_PATH=./archives
MAX_SALES_ENV_PATH=.env
```

## سياسة الحفظ النهائية

- لا يوجد مسار حفظ قديم أو fallback للمبيعات والمالية.
- أي خطأ في الحفظ يظهر مباشرة حتى لا تُكتب البيانات في مسارين مختلفين.
- دفعات الزبائن تُسجل في `customer_payments` وتُزامن في `payments` عند توفر جدول المدفوعات العام.
- الترقيات الذكية تفحص الجداول عبر `PRAGMA table_info` وتضيف الأعمدة الناقصة فقط.

## إدارة الإعدادات برمجياً

```python
from services.domain.settings_manager import get_config, update_config, list_config
```

كل تعديل عبر `update_config` يقوم بـ:

1. التحقق من صحة المفتاح والقيمة.
2. إنشاء نسخة احتياطية من `.env` قبل الكتابة.
3. تحديث متغيرات التشغيل في الذاكرة.
4. حفظ القيمة في جدول `system_settings` عند توفره.
5. تسجيل العملية في `audit_logs` عند توفره.

## مراقبة التشغيل

- سجلات الترقيات: `logs/migrations.log`
- سجلات مسار الحفظ: `logs/persistence_fallback.log`
- أحداث الدومين الاختيارية: حسب المسار الممرر إلى `make_jsonl_logger`

## فحص الجودة قبل التسليم

```bash
python -m compileall -q services tests
python -m pytest -q
```
