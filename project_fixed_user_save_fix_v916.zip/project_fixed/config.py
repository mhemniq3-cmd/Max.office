from __future__ import annotations

"""Portable runtime paths for Max Sales.

This module keeps writable data next to the running application.  It works in
both modes:
- normal Python execution from the project folder
- packaged/frozen execution such as PyInstaller .exe

Bundled read-only resources may live in PyInstaller's temporary _MEIPASS
folder, while customer data always stays beside the executable/project.
"""

import os
import sys
from pathlib import Path


def _runtime_base_dir() -> Path:
    """Folder that owns database/logs/backups for the current run."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def _bundle_base_dir() -> Path:
    """Folder where bundled read-only resources are available."""
    bundle = getattr(sys, "_MEIPASS", None)
    if bundle:
        return Path(bundle).resolve()
    return BASE_DIR


BASE_DIR = _runtime_base_dir()
BUNDLE_DIR = _bundle_base_dir()

DATABASE_DIR = BASE_DIR / "database"
LOG_DIR = BASE_DIR / "logs"
BACKUP_DIR = BASE_DIR / "backups"
EXPORT_DIR = BASE_DIR / "exports"
ARCHIVE_DIR = BASE_DIR / "archives"
SETTINGS_DIR = BASE_DIR / "settings"
RESOURCES_DIR = BASE_DIR / "resources"
ASSETS_DIR = BASE_DIR / "ui" / "assets"
BUNDLE_ASSETS_DIR = BUNDLE_DIR / "ui" / "assets"
BUNDLE_RESOURCES_DIR = BUNDLE_DIR / "resources"


def _ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


for _directory in (DATABASE_DIR, LOG_DIR, BACKUP_DIR, EXPORT_DIR, ARCHIVE_DIR, SETTINGS_DIR, RESOURCES_DIR):
    _ensure_dir(_directory)


def _resolve_env_path(key: str, default: Path, *, is_dir: bool = False) -> Path:
    raw = os.environ.get(key, "").strip()
    path = Path(raw).expanduser() if raw else default
    if not path.is_absolute():
        path = (BASE_DIR / path).resolve()
    if is_dir:
        path.mkdir(parents=True, exist_ok=True)
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


DB_PATH = _resolve_env_path("MAX_SALES_DB_PATH", DATABASE_DIR / "max_sales.db")
LOG_PATH = _resolve_env_path("MAX_SALES_LOG_PATH", LOG_DIR / "max_sales.log")
BACKUP_PATH = _resolve_env_path("MAX_SALES_BACKUP_PATH", BACKUP_DIR, is_dir=True)
EXPORT_PATH = _resolve_env_path("MAX_SALES_EXPORT_PATH", EXPORT_DIR, is_dir=True)
ARCHIVE_PATH = _resolve_env_path("MAX_SALES_ARCHIVE_PATH", ARCHIVE_DIR, is_dir=True)

PRINTER_NAME = os.environ.get("MAX_SALES_PRINTER_NAME", "").strip()
PRINTER_PORT = os.environ.get("MAX_SALES_PRINTER_PORT", "").strip()
APP_NAME = "ماكس سيلز"
APP_VERSION = "1.0.8"
DEFAULT_TAX_RATE = 15.0
CURRENCY_SYMBOL = "ر.س"
DEBUG_MODE = False
LOG_RETENTION_DAYS = 180


def resource_path(*parts: str) -> Path:
    """Return a readable resource path from runtime folder, then bundled folder."""
    runtime_candidate = BASE_DIR.joinpath(*parts)
    if runtime_candidate.exists():
        return runtime_candidate
    bundled_candidate = BUNDLE_DIR.joinpath(*parts)
    if bundled_candidate.exists():
        return bundled_candidate
    return runtime_candidate


def asset_path(*parts: str) -> Path:
    """Return an asset path that works in source and packaged exe modes."""
    runtime_candidate = ASSETS_DIR.joinpath(*parts)
    if runtime_candidate.exists():
        return runtime_candidate
    bundled_candidate = BUNDLE_ASSETS_DIR.joinpath(*parts)
    if bundled_candidate.exists():
        return bundled_candidate
    legacy_candidate = BASE_DIR / "assets" / Path(*parts)
    if legacy_candidate.exists():
        return legacy_candidate
    return runtime_candidate
