from __future__ import annotations

from contextlib import contextmanager
import hashlib
import hmac
import secrets
import os
import sqlite3
from pathlib import Path
from datetime import datetime
from typing import Iterable, Any, Iterator

PROJECT_ROOT = Path(__file__).resolve().parents[1]
APP_DB_DIR = PROJECT_ROOT / 'database'

_env_db_path = os.environ.get('MAX_SALES_DB_PATH')
if _env_db_path:
    DB_FILE = Path(_env_db_path).expanduser()
    if not DB_FILE.is_absolute():
        DB_FILE = (PROJECT_ROOT / DB_FILE).resolve()
else:
    DB_FILE = APP_DB_DIR / 'max_sales.db'
SQLITE_TIMEOUT_SECONDS = float(os.environ.get('MAX_SALES_SQLITE_TIMEOUT', '10'))
SQLITE_CACHE_KIB = int(os.environ.get('MAX_SALES_SQLITE_CACHE_KIB', '20000'))


PERMISSION_KEYS = (
    'can_dashboard', 'can_sales', 'can_products', 'can_customers',
    'can_returns', 'can_reports', 'can_users', 'can_tools',
    'can_product_add', 'can_product_edit', 'can_product_delete', 'can_view_cost', 'can_view_profit',
    'can_return_full', 'can_discount', 'can_print', 'can_backup', 'can_restore', 'can_settings', 'can_inventory', 'can_suppliers', 'can_purchases', 'can_touch_pos', 'can_price_edit', 'can_quantity_edit', 'can_discount_limit', 'can_discount_below_cost', 'can_goals', 'can_audit'
)


def now_text() -> str:
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


PASSWORD_SCHEME = 'pbkdf2_sha256'
PASSWORD_ITERATIONS = 60_000
_SALT_BYTES = 16


def legacy_password_hash(password: str) -> str:
    """Return the legacy SHA-256 hash used by older releases.

    Kept only so existing databases can log in once and be migrated to the
    salted PBKDF2 format automatically. Do not use for new passwords.
    """
    return hashlib.sha256(str(password).encode('utf-8')).hexdigest()


def password_hash(password: str) -> str:
    """Return a salted PBKDF2-SHA256 password hash.

    Stored format:
        pbkdf2_sha256$iterations$salt_hex$hash_hex
    """
    salt = secrets.token_bytes(_SALT_BYTES)
    digest = hashlib.pbkdf2_hmac('sha256', str(password).encode('utf-8'), salt, PASSWORD_ITERATIONS)
    return f'{PASSWORD_SCHEME}${PASSWORD_ITERATIONS}${salt.hex()}${digest.hex()}'


def verify_password(password: str, stored_hash: str | None) -> bool:
    """Verify a password against both current and legacy hash formats."""
    stored = str(stored_hash or '')
    if not stored:
        return False
    if stored.startswith(f'{PASSWORD_SCHEME}$'):
        try:
            _scheme, iterations, salt_hex, digest_hex = stored.split('$', 3)
            salt = bytes.fromhex(salt_hex)
            expected = bytes.fromhex(digest_hex)
            actual = hashlib.pbkdf2_hmac('sha256', str(password).encode('utf-8'), salt, int(iterations))
            return hmac.compare_digest(actual, expected)
        except Exception:
            return False
    # Legacy unsalted SHA-256 from old versions.
    return hmac.compare_digest(stored, legacy_password_hash(password))


def password_needs_rehash(stored_hash: str | None) -> bool:
    """True when the stored hash is legacy or uses weaker parameters."""
    stored = str(stored_hash or '')
    if not stored.startswith(f'{PASSWORD_SCHEME}$'):
        return True
    try:
        _scheme, iterations, _salt_hex, _digest_hex = stored.split('$', 3)
        return int(iterations) < PASSWORD_ITERATIONS
    except Exception:
        return True


def initial_admin_password_file() -> Path:
    """Return the one-time password handoff file used on a brand-new install.

    The application no longer seeds a permanent well-known admin/admin login.
    On first database creation it either uses MAX_SALES_INITIAL_ADMIN_PASSWORD
    / MAX_SALES_ADMIN_PASSWORD, or writes a generated one-time password here.
    Tests and packaged deployments may override the handoff path with
    MAX_SALES_INITIAL_ADMIN_PASSWORD_FILE.
    """
    configured_path = os.environ.get('MAX_SALES_INITIAL_ADMIN_PASSWORD_FILE')
    if configured_path:
        path = Path(configured_path).expanduser()
        return path if path.is_absolute() else (PROJECT_ROOT / path).resolve()
    return PROJECT_ROOT / 'settings' / 'initial_admin_password.txt'


def _write_initial_admin_password(password: str) -> None:
    password_file = initial_admin_password_file()
    try:
        password_file.parent.mkdir(parents=True, exist_ok=True)
        if not password_file.exists():
            password_file.write_text(
                'كلمة مرور المدير المؤقتة لأول تشغيل فقط:\n'
                f'{password}\n\n'
                'ادخل بالمستخدم admin ثم غيّر كلمة المرور فوراً.\n'
                'يمكن حذف هذا الملف بعد إكمال أول دخول.\n',
                encoding='utf-8',
            )
            try:
                password_file.chmod(0o600)
            except OSError:
                pass
    except Exception:
        # Do not block database creation if the filesystem is read-only.
        # The password can still be provided explicitly through the environment.
        pass



def _read_initial_admin_password_file() -> str:
    """Read an existing first-run password handoff file, if present.

    This fixes packaged builds where settings/initial_admin_password.txt already
    exists before the first database is created. In that case the database must
    use the same password shown to the user, not generate a different hidden one.
    """
    password_file = initial_admin_password_file()
    try:
        if not password_file.exists():
            return ''
        lines = [line.strip() for line in password_file.read_text(encoding='utf-8').splitlines()]
        for line in lines:
            if not line or line.startswith('#'):
                continue
            if 'كلمة مرور' in line or 'ادخل' in line or 'يمكن حذف' in line or 'temporary' in line.lower():
                continue
            return line
    except Exception:
        return ''
    return ''

def generate_initial_admin_password() -> tuple[str, bool]:
    """Return the first-run admin password and whether it was generated.

    Priority:
    1. MAX_SALES_INITIAL_ADMIN_PASSWORD / MAX_SALES_ADMIN_PASSWORD
    2. An existing settings/initial_admin_password.txt handoff file
    3. A newly generated one-time password written to that file
    """
    configured = (
        os.environ.get('MAX_SALES_INITIAL_ADMIN_PASSWORD')
        or os.environ.get('MAX_SALES_ADMIN_PASSWORD')
        or ''
    ).strip()
    if configured:
        validate_password_strength(configured, 'admin')
        return configured, False

    existing = _read_initial_admin_password_file().strip()
    if existing:
        validate_password_strength(existing, 'admin')
        return existing, False

    password = secrets.token_urlsafe(18)
    return password, True


def validate_password_strength(password: str, username: str = '') -> None:
    """Raise ValueError when a password is too weak for a local POS system.

    Rules (improved):
    - At least 8 characters
    - Not in a list of common weak passwords
    - Not identical to the username
    - Must contain at least one digit OR one non-letter character
    """
    text = str(password or '')
    stripped = text.strip()
    if len(stripped) < 8:
        raise ValueError('كلمة المرور يجب أن تكون 8 أحرف على الأقل')
    lowered = stripped.lower()
    user = str(username or '').strip().lower()
    weak_values = {
        'admin', 'admin123', '1234', '12345', '123456', '1234567', '12345678',
        '123456789', '1234567890', 'password', 'qwerty', 'abc123', 'letmein',
        'welcome', 'monkey', 'dragon', 'master', 'pass', 'test', '000000',
        '111111', '222222', '333333', '654321', 'azerty', 'qwerty123',
    }
    if lowered in weak_values:
        raise ValueError('كلمة المرور شائعة جداً وسهلة التخمين. اختر كلمة مرور أقوى')
    if user and lowered == user:
        raise ValueError('كلمة المرور لا يمكن أن تكون مطابقة لاسم المستخدم')
    has_digit = any(ch.isdigit() for ch in stripped)
    has_symbol = any(not ch.isalpha() for ch in stripped)
    if not (has_digit or has_symbol):
        raise ValueError('كلمة المرور يجب أن تحتوي على رقم أو رمز خاص على الأقل')


def to_float(value: object, default: float = 0.0) -> float:
    if value is None:
        return default
    text = str(value).strip()
    if not text:
        return default
    try:
        return float(text)
    except (ValueError, TypeError):
        return default


def to_int(value: object, default: int = 0) -> int:
    if value is None:
        return default
    text = str(value).strip()
    if not text:
        return default
    try:
        return int(float(text))
    except (ValueError, TypeError):
        return default


def money(value: object) -> str:
    try:
        return f'{float(value):,.0f} د.ع'
    except Exception:
        return '0 د.ع'


class Database:
    def __init__(self, path: Path | str = DB_FILE):
        self.path = Path(path).expanduser()
        if not self.path.is_absolute():
            self.path = (PROJECT_ROOT / self.path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self.conn = sqlite3.connect(
                self.path,
                timeout=SQLITE_TIMEOUT_SECONDS,
                detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES,
                cached_statements=256,
            )
        except sqlite3.Error as exc:
            raise RuntimeError(f'تعذر فتح قاعدة البيانات: {self.path} - {exc}') from exc
        self.conn.row_factory = sqlite3.Row
        self._configure_connection()
        self.create_schema()
        self.upgrade_schema()
        self._create_extended_schema()   # يجب قبل seed_defaults لأنها تُنشئ جداول يحتاجها seed
        self.seed_defaults()
        self.seed_settings()
        self.create_indexes()


    def _configure_connection(self) -> None:
        """Apply safe SQLite settings for a desktop POS workload."""
        self.conn.execute('PRAGMA foreign_keys = ON')
        self.conn.execute(f'PRAGMA busy_timeout = {int(SQLITE_TIMEOUT_SECONDS * 1000)}')
        self.conn.execute('PRAGMA journal_mode = WAL')
        self.conn.execute('PRAGMA synchronous = NORMAL')
        self.conn.execute('PRAGMA temp_store = MEMORY')
        self.conn.execute(f'PRAGMA cache_size = {-abs(SQLITE_CACHE_KIB)}')

    def optimize(self) -> None:
        """Ask SQLite to refresh lightweight planner statistics when possible."""
        try:
            self.conn.execute('PRAGMA optimize')
        except sqlite3.Error:
            pass

    def close(self) -> None:
        try:
            self.optimize()
            self.conn.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    @staticmethod
    def _safe_identifier(name: str) -> str:
        text = str(name or '')
        if not text.replace('_', '').isalnum():
            raise ValueError('اسم جدول/حقل غير صالح')
        return text

    def execute(self, query: str, params: Iterable[Any] = (), auto_commit: bool = True) -> sqlite3.Cursor:
        cur = self.conn.execute(query, tuple(params))
        if auto_commit:
            self.conn.commit()
        return cur

    def begin_transaction(self) -> None:
        self.conn.execute('BEGIN IMMEDIATE')

    def commit(self) -> None:
        self.conn.commit()

    def rollback(self) -> None:
        self.conn.rollback()

    @contextmanager
    def transaction(self) -> Iterator[None]:
        """Run a group of database operations atomically."""
        self.begin_transaction()
        try:
            yield
        except Exception:
            self.rollback()
            raise
        else:
            self.commit()

    def executemany(self, query: str, rows: Iterable[Iterable[Any]], auto_commit: bool = True) -> sqlite3.Cursor:
        cur = self.conn.executemany(query, [tuple(row) for row in rows])
        if auto_commit:
            self.conn.commit()
        return cur

    def one(self, query: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
        cur = self.conn.execute(query, tuple(params))
        return cur.fetchone()

    def all(self, query: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        cur = self.conn.execute(query, tuple(params))
        return list(cur.fetchall())

    def create_schema(self) -> None:
        self.conn.executescript(
            '''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                full_name TEXT,
                role TEXT NOT NULL DEFAULT 'كاشير',
                can_dashboard INTEGER NOT NULL DEFAULT 1,
                can_sales INTEGER NOT NULL DEFAULT 1,
                can_products INTEGER NOT NULL DEFAULT 0,
                can_customers INTEGER NOT NULL DEFAULT 0,
                can_returns INTEGER NOT NULL DEFAULT 0,
                can_reports INTEGER NOT NULL DEFAULT 0,
                can_users INTEGER NOT NULL DEFAULT 0,
                can_tools INTEGER NOT NULL DEFAULT 0,
                must_change_password INTEGER NOT NULL DEFAULT 0,
                last_login_at TEXT,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS employees (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                phone TEXT,
                user_id INTEGER,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );

            CREATE TABLE IF NOT EXISTS customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                phone TEXT,
                address TEXT,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                barcode TEXT UNIQUE,
                name TEXT NOT NULL,
                category TEXT,
                cost_price REAL NOT NULL DEFAULT 0,
                sale_price REAL NOT NULL DEFAULT 0,
                quantity INTEGER NOT NULL DEFAULT 0,
                min_quantity INTEGER NOT NULL DEFAULT 5,
                commission_percent REAL NOT NULL DEFAULT 0,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_no TEXT NOT NULL UNIQUE,
                user_id INTEGER,
                employee_id INTEGER NOT NULL,
                customer_id INTEGER,
                subtotal REAL NOT NULL DEFAULT 0,
                discount_amount REAL NOT NULL DEFAULT 0,
                total REAL NOT NULL DEFAULT 0,
                total_commission REAL NOT NULL DEFAULT 0,
                total_profit REAL NOT NULL DEFAULT 0,
                payment_method TEXT NOT NULL DEFAULT 'نقدي',
                discount_type TEXT NOT NULL DEFAULT 'amount',
                tax_amount REAL NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'completed',
                receipt_no TEXT,
                note TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id),
                FOREIGN KEY(employee_id) REFERENCES employees(id),
                FOREIGN KEY(customer_id) REFERENCES customers(id)
            );

            CREATE TABLE IF NOT EXISTS sale_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sale_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                product_name TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                cost_price REAL NOT NULL DEFAULT 0,
                unit_price REAL NOT NULL,
                line_total REAL NOT NULL,
                commission_percent REAL NOT NULL,
                commission_amount REAL NOT NULL,
                profit_amount REAL NOT NULL DEFAULT 0,
                FOREIGN KEY(sale_id) REFERENCES sales(id),
                FOREIGN KEY(product_id) REFERENCES products(id)
            );

            CREATE TABLE IF NOT EXISTS returns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                return_no TEXT NOT NULL,
                sale_id INTEGER NOT NULL,
                sale_item_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                product_name TEXT NOT NULL,
                employee_id INTEGER NOT NULL,
                customer_id INTEGER,
                quantity INTEGER NOT NULL,
                unit_price REAL NOT NULL,
                amount REAL NOT NULL,
                commission_amount REAL NOT NULL DEFAULT 0,
                profit_amount REAL NOT NULL DEFAULT 0,
                reason TEXT,
                refund_method TEXT NOT NULL DEFAULT 'نقدي',
                created_by_user_id INTEGER,
                created_at TEXT NOT NULL,
                FOREIGN KEY(sale_id) REFERENCES sales(id),
                FOREIGN KEY(sale_item_id) REFERENCES sale_items(id),
                FOREIGN KEY(product_id) REFERENCES products(id),
                FOREIGN KEY(employee_id) REFERENCES employees(id),
                FOREIGN KEY(customer_id) REFERENCES customers(id),
                FOREIGN KEY(created_by_user_id) REFERENCES users(id)
            );

            CREATE TABLE IF NOT EXISTS customer_payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER NOT NULL,
                amount REAL NOT NULL,
                discount_type TEXT NOT NULL DEFAULT 'amount',
                tax_amount REAL NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'completed',
                receipt_no TEXT,
                note TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(customer_id) REFERENCES customers(id)
            );


            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                payment_date TEXT,
                payment_type TEXT NOT NULL DEFAULT 'قبض',
                amount REAL NOT NULL DEFAULT 0,
                payment_method TEXT NOT NULL DEFAULT 'نقدي',
                related_type TEXT,
                related_id INTEGER,
                customer_id INTEGER,
                supplier_id INTEGER,
                description TEXT,
                note TEXT,
                user_id INTEGER,
                user_name TEXT NOT NULL DEFAULT '',
                source_table TEXT,
                source_id INTEGER,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(source_table, source_id),
                FOREIGN KEY(customer_id) REFERENCES customers(id),
                FOREIGN KEY(supplier_id) REFERENCES suppliers(id),
                FOREIGN KEY(user_id) REFERENCES users(id)
            );


            -- جميع الجداول معرّفة في create_schema(). هذه الدالة مخصصة للـ indexes فقط.

            CREATE TABLE IF NOT EXISTS suppliers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                phone TEXT,
                address TEXT,
                note TEXT,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS purchases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                purchase_no TEXT NOT NULL UNIQUE,
                supplier_id INTEGER NOT NULL,
                user_id INTEGER,
                subtotal REAL NOT NULL DEFAULT 0,
                discount_amount REAL NOT NULL DEFAULT 0,
                total REAL NOT NULL DEFAULT 0,
                paid_amount REAL NOT NULL DEFAULT 0,
                payment_method TEXT NOT NULL DEFAULT 'نقدي',
                note TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(supplier_id) REFERENCES suppliers(id),
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS purchase_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                purchase_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                product_name TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                unit_cost REAL NOT NULL DEFAULT 0,
                line_total REAL NOT NULL DEFAULT 0,
                FOREIGN KEY(purchase_id) REFERENCES purchases(id),
                FOREIGN KEY(product_id) REFERENCES products(id)
            );
            CREATE TABLE IF NOT EXISTS supplier_payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                supplier_id INTEGER NOT NULL,
                amount REAL NOT NULL,
                receipt_no TEXT,
                note TEXT,
                user_id INTEGER,
                created_at TEXT NOT NULL,
                FOREIGN KEY(supplier_id) REFERENCES suppliers(id),
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS employee_goals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id INTEGER NOT NULL,
                period_type TEXT NOT NULL DEFAULT 'شهري',
                period_start TEXT NOT NULL,
                target_sales REAL NOT NULL DEFAULT 0,
                bonus_amount REAL NOT NULL DEFAULT 0,
                note TEXT,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                FOREIGN KEY(employee_id) REFERENCES employees(id)
            );

            -- جداول أساسية كانت في create_indexes (أُعيد وضعها هنا بشكل صحيح)
            CREATE TABLE IF NOT EXISTS app_settings (
                key TEXT PRIMARY KEY,
                value TEXT
            );
            CREATE TABLE IF NOT EXISTS activity_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                username TEXT,
                action TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS inventory_movements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                movement_type TEXT NOT NULL,
                quantity_change INTEGER NOT NULL,
                old_quantity INTEGER NOT NULL DEFAULT 0,
                new_quantity INTEGER NOT NULL DEFAULT 0,
                ref_type TEXT,
                ref_no TEXT,
                note TEXT,
                user_id INTEGER,
                created_at TEXT NOT NULL,
                FOREIGN KEY(product_id) REFERENCES products(id),
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS suspended_sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hold_no TEXT NOT NULL UNIQUE,
                user_id INTEGER,
                employee_id INTEGER,
                customer_id INTEGER,
                payment_method TEXT,
                discount_amount REAL NOT NULL DEFAULT 0,
                note TEXT,
                cart_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS branches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                address TEXT,
                phone TEXT,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS warehouses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                branch_id INTEGER,
                name TEXT NOT NULL,
                address TEXT,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                FOREIGN KEY(branch_id) REFERENCES branches(id)
            );
            CREATE TABLE IF NOT EXISTS inventory_counts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                branch_id INTEGER,
                warehouse_id INTEGER,
                system_quantity INTEGER NOT NULL DEFAULT 0,
                counted_quantity INTEGER NOT NULL DEFAULT 0,
                difference INTEGER NOT NULL DEFAULT 0,
                damaged_quantity INTEGER NOT NULL DEFAULT 0,
                note TEXT,
                user_id INTEGER,
                created_at TEXT NOT NULL,
                FOREIGN KEY(product_id) REFERENCES products(id),
                FOREIGN KEY(branch_id) REFERENCES branches(id),
                FOREIGN KEY(warehouse_id) REFERENCES warehouses(id),
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            '''
        )
        self.conn.commit()

    def upgrade_schema(self) -> None:
        for table, column, sql in [
            ('users', 'must_change_password', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'last_login_at', 'TEXT'),
            ('customers', 'credit_limit', 'REAL NOT NULL DEFAULT 0'),
            ('customers', 'due_days', 'INTEGER NOT NULL DEFAULT 0'),
            ('sales', 'discount_type', "TEXT NOT NULL DEFAULT 'amount'"),
            ('sales', 'tax_amount', 'REAL NOT NULL DEFAULT 0'),
            ('sales', 'status', "TEXT NOT NULL DEFAULT 'completed'"),
            ('returns', 'refund_method', "TEXT NOT NULL DEFAULT 'نقدي'"),
            ('customer_payments', 'receipt_no', 'TEXT'),
            ('customer_payments', 'discount_type', "TEXT NOT NULL DEFAULT 'amount'"),
            ('customer_payments', 'tax_amount', 'REAL NOT NULL DEFAULT 0'),
            ('customer_payments', 'status', "TEXT NOT NULL DEFAULT 'completed'"),
            ('payments', 'payment_date', 'TEXT'),
            ('payments', 'payment_type', "TEXT NOT NULL DEFAULT 'قبض'"),
            ('payments', 'payment_method', "TEXT NOT NULL DEFAULT 'نقدي'"),
            ('payments', 'related_type', 'TEXT'),
            ('payments', 'related_id', 'INTEGER'),
            ('payments', 'customer_id', 'INTEGER'),
            ('payments', 'supplier_id', 'INTEGER'),
            ('payments', 'description', 'TEXT'),
            ('payments', 'note', 'TEXT'),
            ('payments', 'user_id', 'INTEGER'),
            ('payments', 'user_name', "TEXT NOT NULL DEFAULT ''"),
            ('payments', 'source_table', 'TEXT'),
            ('payments', 'source_id', 'INTEGER'),
            ('sales', 'user_id', 'INTEGER'),
            ('users', 'can_dashboard', 'INTEGER NOT NULL DEFAULT 1'),
            ('users', 'can_sales', 'INTEGER NOT NULL DEFAULT 1'),
            ('users', 'can_products', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_customers', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_returns', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_reports', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_users', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_tools', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_product_add', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_product_edit', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_product_delete', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_view_cost', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_view_profit', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_return_full', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_discount', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_print', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_backup', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_restore', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_settings', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_inventory', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_suppliers', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_purchases', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_touch_pos', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_price_edit', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_quantity_edit', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_discount_limit', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_discount_below_cost', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'max_discount_percent', 'REAL NOT NULL DEFAULT 0'),
            ('users', 'can_goals', 'INTEGER NOT NULL DEFAULT 0'),
            ('users', 'can_audit', 'INTEGER NOT NULL DEFAULT 0'),
            ('products', 'branch_id', 'INTEGER'),
            ('products', 'warehouse_id', 'INTEGER'),
            ('employee_goals', 'goal_type', "TEXT NOT NULL DEFAULT 'مبيعات'"),
            ('employee_goals', 'scope_type', "TEXT NOT NULL DEFAULT 'موظف'"),
            ('employee_goals', 'target_product_id', 'INTEGER'),
            ('employee_goals', 'reward_type', "TEXT NOT NULL DEFAULT 'مبلغ ثابت'"),
            ('employee_goals', 'reward_rate', 'REAL NOT NULL DEFAULT 0'),
            ('employee_goals', 'bonus_100', 'REAL NOT NULL DEFAULT 0'),
            ('employee_goals', 'bonus_120', 'REAL NOT NULL DEFAULT 0'),
            ('employee_goals', 'bonus_150', 'REAL NOT NULL DEFAULT 0'),
            ('employees', 'user_id', 'INTEGER'),
        ]:
            self.add_column_if_missing(table, column, sql)

        self.conn.executescript('''
            CREATE TABLE IF NOT EXISTS suppliers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, address TEXT, note TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS purchases (id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_no TEXT NOT NULL UNIQUE, supplier_id INTEGER NOT NULL, user_id INTEGER, subtotal REAL NOT NULL DEFAULT 0, discount_amount REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0, paid_amount REAL NOT NULL DEFAULT 0, payment_method TEXT NOT NULL DEFAULT 'نقدي', note TEXT, created_at TEXT NOT NULL, FOREIGN KEY(supplier_id) REFERENCES suppliers(id), FOREIGN KEY(user_id) REFERENCES users(id));
            CREATE TABLE IF NOT EXISTS purchase_items (id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_id INTEGER NOT NULL, product_id INTEGER NOT NULL, product_name TEXT NOT NULL, quantity INTEGER NOT NULL, unit_cost REAL NOT NULL DEFAULT 0, line_total REAL NOT NULL DEFAULT 0, FOREIGN KEY(purchase_id) REFERENCES purchases(id), FOREIGN KEY(product_id) REFERENCES products(id));
            CREATE TABLE IF NOT EXISTS supplier_payments (id INTEGER PRIMARY KEY AUTOINCREMENT, supplier_id INTEGER NOT NULL, amount REAL NOT NULL, receipt_no TEXT, note TEXT, user_id INTEGER, created_at TEXT NOT NULL, FOREIGN KEY(supplier_id) REFERENCES suppliers(id), FOREIGN KEY(user_id) REFERENCES users(id));
            CREATE TABLE IF NOT EXISTS payments (id INTEGER PRIMARY KEY AUTOINCREMENT, payment_date TEXT, payment_type TEXT NOT NULL DEFAULT 'قبض', amount REAL NOT NULL DEFAULT 0, payment_method TEXT NOT NULL DEFAULT 'نقدي', related_type TEXT, related_id INTEGER, customer_id INTEGER, supplier_id INTEGER, description TEXT, note TEXT, user_id INTEGER, user_name TEXT NOT NULL DEFAULT '', source_table TEXT, source_id INTEGER, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(source_table, source_id), FOREIGN KEY(customer_id) REFERENCES customers(id), FOREIGN KEY(supplier_id) REFERENCES suppliers(id), FOREIGN KEY(user_id) REFERENCES users(id));
            CREATE TABLE IF NOT EXISTS employee_goals (id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, period_type TEXT NOT NULL DEFAULT 'شهري', period_start TEXT NOT NULL, target_sales REAL NOT NULL DEFAULT 0, bonus_amount REAL NOT NULL DEFAULT 0, note TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, FOREIGN KEY(employee_id) REFERENCES employees(id));
        ''')

        # Keep the generic payments table compatible with old customer payment rows.
        # This prevents tools/accounting screens from failing on databases created before v45.17.2.
        try:
            with self.transaction():
                self.conn.execute('''
                    INSERT OR IGNORE INTO payments
                    (payment_date, payment_type, amount, payment_method, related_type, related_id,
                     customer_id, description, note, user_name, source_table, source_id, created_at)
                    SELECT created_at, 'قبض', amount, 'نقدي', 'عميل', customer_id,
                           customer_id, note, note, '', 'customer_payments', id, created_at
                    FROM customer_payments
                ''')
        except Exception as _migration_exc:
            import logging as _logging
            _logging.getLogger(__name__).warning('customer_payments migration skipped: %s', _migration_exc)

    def add_column_if_missing(self, table: str, column: str, column_sql: str) -> None:
        safe_table = self._safe_identifier(table)
        safe_column = self._safe_identifier(column)
        existing = [row[1] for row in self.conn.execute(f'PRAGMA table_info({safe_table})').fetchall()]
        if safe_column not in existing:
            self.conn.execute(f'ALTER TABLE {safe_table} ADD COLUMN {safe_column} {column_sql}')

    def seed_defaults(self) -> None:
        if self.one('SELECT COUNT(*) c FROM users')['c'] == 0:  # type: ignore[index]
            initial_password, was_generated = generate_initial_admin_password()
            self.execute(
                '''
                INSERT INTO users
                (username, password_hash, full_name, role, can_dashboard, can_sales, can_products,
                 can_customers, can_returns, can_reports, can_users, can_tools, active, created_at, must_change_password)
                VALUES (?, ?, ?, ?, 1, 1, 1, 1, 1, 1, 1, 1, 1, ?, 1)
                ''',
                ('admin', password_hash(initial_password), 'مدير النظام', 'مدير', now_text()),
            )
            if was_generated:
                _write_initial_admin_password(initial_password)
        else:
            # Existing databases from older releases may still contain admin/admin
            # using the legacy SHA-256 format. Keep the account usable, but force
            # a password change as soon as the real admin logs in.
            admin = self.one("SELECT id, password_hash FROM users WHERE username='admin'")
            if admin and verify_password('admin', admin['password_hash']):
                self.execute("UPDATE users SET must_change_password=1 WHERE id=?", (admin['id'],))
        try:
            self.execute("UPDATE users SET can_suppliers=1, can_purchases=1, can_touch_pos=1, can_price_edit=1, can_quantity_edit=1, can_discount_limit=1, can_goals=1, can_audit=1 WHERE role='مدير' OR username='admin'")
        except Exception:
            pass
        if self.one('SELECT COUNT(*) c FROM employees')['c'] == 0:  # type: ignore[index]
            self.execute(
                'INSERT INTO employees (name, phone, active, created_at) VALUES (?, ?, 1, ?)',
                ('موظف افتراضي', '', now_text()),
            )
        if self.one('SELECT COUNT(*) c FROM customers')['c'] == 0:  # type: ignore[index]
            self.execute(
                'INSERT INTO customers (name, phone, address, active, created_at) VALUES (?, ?, ?, 1, ?)',
                ('زبون عام', '', '', now_text()),
            )
        if self.one('SELECT COUNT(*) c FROM branches')['c'] == 0:  # type: ignore[index]
            self.execute('INSERT INTO branches (name, address, phone, active, created_at) VALUES (?, ?, ?, 1, ?)', ('الفرع الرئيسي', '', '', now_text()))
        if self.one('SELECT COUNT(*) c FROM suppliers')['c'] == 0:  # type: ignore[index]
            self.execute('INSERT INTO suppliers (name, phone, address, note, active, created_at) VALUES (?, ?, ?, ?, 1, ?)', ('مورد عام', '', '', '', now_text()))
        if self.one('SELECT COUNT(*) c FROM warehouses')['c'] == 0:  # type: ignore[index]
            branch = self.one('SELECT id FROM branches ORDER BY id LIMIT 1')
            self.execute('INSERT INTO warehouses (branch_id, name, address, active, created_at) VALUES (?, ?, ?, 1, ?)', (branch['id'] if branch else None, 'المخزن الرئيسي', '', now_text()))

    def seed_settings(self) -> None:
        default_settings = {
            'company_name': 'ماكس للمبيعات',
            'company_phone': '',
            'company_address': '',
            'currency': 'د.ع',
            'tax_percent': '0',
            'invoice_footer': 'شكراً لتعاملكم معنا',
            'backup_days_warning': '7',
            'printer_name': '',
            'auto_backup_enabled': '1',
            'last_auto_backup_date': '',
            'google_drive_backup_enabled': '0',
            'google_drive_backup_path': '',
            'last_google_drive_backup_status': '',
        }
        for key, value in default_settings.items():
            self.conn.execute('INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)', (key, value))
        self.conn.commit()

    def create_indexes(self) -> None:
        self.conn.executescript(
            '''
            CREATE INDEX IF NOT EXISTS idx_products_search ON products(name, barcode, category);
            CREATE INDEX IF NOT EXISTS idx_sales_customer ON sales(customer_id);
            CREATE INDEX IF NOT EXISTS idx_sales_employee ON sales(employee_id);
            CREATE INDEX IF NOT EXISTS idx_sales_user ON sales(user_id);
            CREATE INDEX IF NOT EXISTS idx_sales_created ON sales(created_at);
            CREATE INDEX IF NOT EXISTS idx_returns_sale ON returns(sale_id);
            CREATE INDEX IF NOT EXISTS idx_returns_item ON returns(sale_item_id);
            CREATE INDEX IF NOT EXISTS idx_returns_created ON returns(created_at);
            CREATE INDEX IF NOT EXISTS idx_payments_customer ON customer_payments(customer_id);
            CREATE INDEX IF NOT EXISTS idx_general_payments_customer ON payments(customer_id);
            CREATE INDEX IF NOT EXISTS idx_general_payments_supplier ON payments(supplier_id);
            CREATE INDEX IF NOT EXISTS idx_general_payments_created ON payments(created_at);
            CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_logs(created_at);
            CREATE INDEX IF NOT EXISTS idx_inventory_product ON inventory_movements(product_id);
            CREATE INDEX IF NOT EXISTS idx_suspended_created ON suspended_sales(created_at);
            CREATE INDEX IF NOT EXISTS idx_purchases_supplier ON purchases(supplier_id);
            CREATE INDEX IF NOT EXISTS idx_purchases_created ON purchases(created_at);
            CREATE INDEX IF NOT EXISTS idx_supplier_payments_supplier ON supplier_payments(supplier_id);
            CREATE INDEX IF NOT EXISTS idx_employee_goals_emp ON employee_goals(employee_id);



            -- جميع الجداول معرّفة في create_schema(). هذه الدالة مخصصة للـ indexes فقط.
            '''
        )
        self.conn.commit()

    def _create_extended_schema(self) -> None:
        """Schema extensions from v11, v25, and v27 — called once from __init__.

        Previously applied as monkey-patches on Database.__init__ which made the
        call chain fragile.  Consolidated here so the order is explicit and a
        failure in any block raises immediately instead of being silently skipped.
        """
        # ── V11: safety tables ─────────────────────────────────────────────────
        self.conn.executescript('''
            CREATE TABLE IF NOT EXISTS day_closings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                close_date TEXT NOT NULL UNIQUE,
                user_id INTEGER,
                cash_sales REAL NOT NULL DEFAULT 0,
                credit_sales REAL NOT NULL DEFAULT 0,
                returns_amount REAL NOT NULL DEFAULT 0,
                discounts_amount REAL NOT NULL DEFAULT 0,
                profit_amount REAL NOT NULL DEFAULT 0,
                invoices_count INTEGER NOT NULL DEFAULT 0,
                counted_cash REAL NOT NULL DEFAULT 0,
                cash_difference REAL NOT NULL DEFAULT 0,
                note TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS login_attempts (
                username TEXT PRIMARY KEY,
                failed_count INTEGER NOT NULL DEFAULT 0,
                locked_until TEXT,
                last_failed_at TEXT
            );
            CREATE TABLE IF NOT EXISTS document_counters (
                kind TEXT NOT NULL,
                year TEXT NOT NULL,
                last_number INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(kind, year)
            );
        ''')
        for key, value in {
            'max_discount_cashier_percent': '10',
            'max_discount_sales_percent': '15',
            'max_backup_keep': '7',
            'daily_close_enabled': '1',
            'login_max_attempts': '5',
            'login_lock_minutes': '10',
        }.items():
            self.conn.execute('INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)', (key, value))
        try:
            for perm in PERMISSION_KEYS:
                self.conn.execute(f"UPDATE users SET {perm}=1 WHERE role='مدير' OR username='admin'")
        except Exception as _exc:
            import logging as _log
            _log.getLogger(__name__).warning('v11 permission seed failed: %s', _exc)
        self.conn.commit()

        # ── V25: practical readiness tables ────────────────────────────────────
        self.conn.executescript('''
            CREATE TABLE IF NOT EXISTS expense_categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS cashier_shifts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                opened_at TEXT NOT NULL,
                closed_at TEXT,
                opening_cash REAL NOT NULL DEFAULT 0,
                expected_cash REAL NOT NULL DEFAULT 0,
                counted_cash REAL,
                cash_difference REAL,
                note TEXT,
                status TEXT NOT NULL DEFAULT 'open',
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS approval_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                request_type TEXT NOT NULL,
                ref_no TEXT,
                requested_by_user_id INTEGER,
                approved_by_user_id INTEGER,
                status TEXT NOT NULL DEFAULT 'pending',
                details TEXT,
                created_at TEXT NOT NULL,
                decided_at TEXT,
                FOREIGN KEY(requested_by_user_id) REFERENCES users(id),
                FOREIGN KEY(approved_by_user_id) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS purchase_returns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                return_no TEXT NOT NULL UNIQUE,
                purchase_id INTEGER NOT NULL,
                supplier_id INTEGER NOT NULL,
                user_id INTEGER,
                amount REAL NOT NULL DEFAULT 0,
                reason TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(purchase_id) REFERENCES purchases(id),
                FOREIGN KEY(supplier_id) REFERENCES suppliers(id),
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS purchase_return_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                purchase_return_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                product_name TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                unit_cost REAL NOT NULL DEFAULT 0,
                line_total REAL NOT NULL DEFAULT 0,
                FOREIGN KEY(purchase_return_id) REFERENCES purchase_returns(id),
                FOREIGN KEY(product_id) REFERENCES products(id)
            );
        ''')
        for table, column, sql in [
            ('products', 'unit_name', "TEXT NOT NULL DEFAULT 'حبة'"),
            ('products', 'items_per_unit', 'REAL NOT NULL DEFAULT 1'),
            ('products', 'expiry_date', 'TEXT'),
            ('products', 'reorder_point', 'INTEGER NOT NULL DEFAULT 0'),
            ('products', 'last_sale_at', 'TEXT'),
            ('customers', 'debt_due_date', 'TEXT'),
            ('purchases', 'supplier_invoice_no', 'TEXT'),
            ('purchases', 'due_date', 'TEXT'),
        ]:
            try:
                self.add_column_if_missing(table, column, sql)
            except Exception:
                pass
        for name in ['إيجار', 'رواتب', 'كهرباء', 'نقل', 'صيانة', 'مشتريات نثرية', 'أخرى']:
            self.conn.execute('INSERT OR IGNORE INTO expense_categories (name, active, created_at) VALUES (?, 1, ?)', (name, now_text()))
        for key, value in {
            'require_manager_approval_for_large_discount': '1',
            'large_discount_threshold_percent': '20',
            'paper_size': '80mm',
            'invoice_template': 'thermal',
            'currency': 'د.ع',
        }.items():
            self.conn.execute('INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)', (key, value))
        self.conn.commit()

        # ── V27: pricing, promotions, Excel and QR schema ──────────────────────
        self.conn.executescript('''
            CREATE TABLE IF NOT EXISTS price_levels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                description TEXT,
                auto_apply INTEGER NOT NULL DEFAULT 1,
                is_default INTEGER NOT NULL DEFAULT 0,
                active INTEGER NOT NULL DEFAULT 1,
                sort_order INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS product_price_levels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                price_level_id INTEGER NOT NULL,
                price REAL NOT NULL DEFAULT 0,
                min_quantity INTEGER NOT NULL DEFAULT 1,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                UNIQUE(product_id, price_level_id),
                FOREIGN KEY(product_id) REFERENCES products(id),
                FOREIGN KEY(price_level_id) REFERENCES price_levels(id)
            );
            CREATE TABLE IF NOT EXISTS promotions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                scope_type TEXT NOT NULL DEFAULT 'all',
                product_id INTEGER,
                category TEXT,
                promo_type TEXT NOT NULL DEFAULT 'percent',
                discount_value REAL NOT NULL DEFAULT 0,
                buy_qty INTEGER NOT NULL DEFAULT 0,
                free_qty INTEGER NOT NULL DEFAULT 0,
                min_quantity INTEGER NOT NULL DEFAULT 1,
                start_date TEXT,
                end_date TEXT,
                priority INTEGER NOT NULL DEFAULT 0,
                active INTEGER NOT NULL DEFAULT 1,
                note TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(product_id) REFERENCES products(id)
            );
        ''')
        for table, column, sql in [
            ('price_levels', 'description', 'TEXT'),
            ('price_levels', 'auto_apply', 'INTEGER NOT NULL DEFAULT 1'),
            ('price_levels', 'is_default', 'INTEGER NOT NULL DEFAULT 0'),
            ('price_levels', 'sort_order', 'INTEGER NOT NULL DEFAULT 0'),
            ('product_price_levels', 'min_quantity', 'INTEGER NOT NULL DEFAULT 1'),
            ('product_price_levels', 'active', 'INTEGER NOT NULL DEFAULT 1'),
            ('promotions', 'min_quantity', 'INTEGER NOT NULL DEFAULT 1'),
            ('promotions', 'priority', 'INTEGER NOT NULL DEFAULT 0'),
            ('promotions', 'note', 'TEXT'),
            ('sale_items', 'price_level_id', 'INTEGER'),
            ('sale_items', 'price_level_name', 'TEXT'),
            ('sale_items', 'promotion_id', 'INTEGER'),
            ('sale_items', 'promotion_name', 'TEXT'),
            ('sale_items', 'original_unit_price', 'REAL NOT NULL DEFAULT 0'),
            ('sale_items', 'promotion_discount_amount', 'REAL NOT NULL DEFAULT 0'),
            ('sale_items', 'free_quantity', 'INTEGER NOT NULL DEFAULT 0'),
            ('sales', 'promotion_discount_amount', 'REAL NOT NULL DEFAULT 0'),
        ]:
            try:
                self.add_column_if_missing(table, column, sql)
            except Exception:
                pass
        for name, desc, auto_apply, is_default, sort_order in [
            ('مفرد', 'السعر العادي الافتراضي', 1, 1, 10),
            ('جملة', 'سعر كمية أو جملة، يطبق تلقائياً عند بلوغ الحد الأدنى', 1, 0, 20),
            ('خاص', 'سعر خاص يختاره المدير ولا يطبق تلقائياً', 0, 0, 30),
        ]:
            self.conn.execute(
                '''INSERT OR IGNORE INTO price_levels
                   (name, description, auto_apply, is_default, active, sort_order, created_at)
                   VALUES (?, ?, ?, ?, 1, ?, ?)''',
                (name, desc, auto_apply, is_default, sort_order, now_text()))
        self.conn.execute(
            "UPDATE price_levels SET is_default=CASE WHEN name='مفرد' THEN 1 ELSE 0 END WHERE name IN ('مفرد','جملة','خاص')")
        for key, value in {
            'qr_on_invoice_enabled': '1',
            'qr_invoice_payload': 'basic',
            'auto_apply_promotions': '1',
            'auto_apply_price_levels': '1',
        }.items():
            self.conn.execute('INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)', (key, value))
        self.conn.executescript('''
            CREATE INDEX IF NOT EXISTS idx_price_levels_active ON price_levels(active, sort_order);
            CREATE INDEX IF NOT EXISTS idx_product_price_levels_product ON product_price_levels(product_id, active, min_quantity);
            CREATE INDEX IF NOT EXISTS idx_promotions_active_dates ON promotions(active, start_date, end_date, priority);
            CREATE INDEX IF NOT EXISTS idx_promotions_product ON promotions(product_id, scope_type);
        ''')
        self.conn.commit()


