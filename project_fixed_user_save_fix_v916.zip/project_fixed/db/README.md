# Database layer

`database.py` is kept as a compatibility facade for existing imports.
The real implementation now lives in `db/database_core.py` so future work can split it into:

- `connection.py` for SQLite connection helpers
- `schema.py` for table definitions
- `migrations.py` for versioned schema upgrades
- `seed.py` for default data
- `security.py` for password hashing and validation
- `formatting.py` for money/date conversion helpers

This keeps the public API stable while making the project ready for commercial maintenance.
