@echo off
cd /d "%~dp0"
python -m compileall -q .
python -m pytest -q
pause
