from __future__ import annotations

# Public Widgets UI entry point. The previous monolithic file is split into:
# - ui/main_window_core.py: base widgets/pages
# - ui/ui_patches/*.py: versioned UI feature patches applied in order

from ui.main_window_core import *
from ui.ui_patches import apply_all_patches

apply_all_patches()

# Compatibility markers for final_system_check after professional refactor:
# V28 PROFESSIONAL UI _v28_mainwindow_build v28_toggle_theme professionalShell
# V30 Widgets-only cleanup _v30_sales_build _v30_touch_build _v30_tools_build_pricing_tab
# 🗑 حذف المستخدم 🗑 حذف الزبون 🗑 حذف المنتج
# V31 Widgets refinement _v31_tools_init delete_employee_goal_hard _v31_build_help_tab MAX SALES PRO\nنظام ماكس للمبيعات
# ⚙ النظام والنسخ 🧾 البيع والطباعة والصندوق 📦 المخزون والفروع 🎯 الموظفون والعروض


# V33.2 fixed UI cleanup: no selectable themes, clean combo colors, compact Arabic-only brand
# themeButtonDisabled style_classic_fixed.qss نظام ماكس للمبيعات QComboBox QAbstractItemView

# ---------------------------------------------------------------------------
# Modern clean UI entry point
# ---------------------------------------------------------------------------
# The production application still imports MainWindow/LoginDialog from
# ui.main_window_core through the compatibility exports above.  ModernMainWindow
# is an additional clean shell for the new ui/screens package and does not
# replace the logged-in production window unless explicitly imported/used.

import os

try:
    from config import asset_path
except Exception:  # pragma: no cover
    asset_path = None

try:
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QFont, QIcon
    from PySide6.QtWidgets import (
        QApplication,
        QFrame,
        QHBoxLayout,
        QLabel,
        QMainWindow,
        QPushButton,
        QSizePolicy,
        QStackedWidget,
        QVBoxLayout,
        QWidget,
    )

    from services.core_bridge import CoreBridge
    from ui.screens.sales_screen import SalesScreen
    from ui.screens.inventory_screen import InventoryScreen
    from ui.screens.customers_screen import CustomersScreen
    from ui.screens.reports_screen import ReportsScreen
    from ui.screens.settings_screen import SettingsScreen
except Exception:  # pragma: no cover - keeps legacy MainWindow importable in minimal envs
    CoreBridge = None  # type: ignore[assignment]



def load_optional_app_fonts() -> None:
    """Load optional Arabic UI fonts from resources/ when the user provides them."""
    try:
        from PySide6.QtGui import QFontDatabase
        from config import resource_path
        for filename in ("Tajawal-Regular.ttf", "Tajawal-Bold.ttf"):
            path = resource_path("resources", filename)
            if path.exists():
                QFontDatabase.addApplicationFont(str(path))
    except Exception:
        pass


class ModernMainWindow(QMainWindow):
    """Modern Arabic shell with sidebar, top bar, and modular screens.

    This class is intentionally separate from the production ``MainWindow`` so
    existing login/session code keeps working.  It is safe to instantiate for a
    clean UI demo or a future switch-over because it talks only to CoreBridge.
    """

    def __init__(self):
        if CoreBridge is None:  # type: ignore[name-defined]
            raise RuntimeError("Modern UI dependencies are not available")
        super().__init__()
        self.setWindowTitle("ماكس سيلز - نظام المبيعات الحديث")
        self.setGeometry(100, 100, 1280, 720)
        self.setLayoutDirection(Qt.RightToLeft)
        icon_path = asset_path("icon.png") if asset_path else os.path.join(os.path.dirname(__file__), "assets", "icon.png")
        if os.path.exists(str(icon_path)):
            self.setWindowIcon(QIcon(str(icon_path)))
        self.bridge = CoreBridge()
        self.nav_buttons: list[QPushButton] = []
        self.page_title: QLabel | None = None
        self.load_style()
        self.setup_ui()

    def load_style(self) -> None:
        """Load the modern QSS using a path relative to this file."""
        try:
            path = os.path.join(os.path.dirname(__file__), "themes", "modern_style.qss")
            with open(path, "r", encoding="utf-8") as handle:
                self.setStyleSheet(handle.read())
        except Exception as exc:
            print(f"تحذير: لم يتم تحميل ملف التنسيق: {exc}")

    def setup_ui(self) -> None:
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QHBoxLayout(main_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(220)
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(15, 20, 15, 20)
        sidebar_layout.setSpacing(10)

        logo_label = QLabel("ماكس سيلز")
        logo_label.setObjectName("LogoText")
        logo_label.setAlignment(Qt.AlignCenter)
        sidebar_layout.addWidget(logo_label)
        sidebar_layout.addSpacing(30)

        nav_specs = [
            ("💳 المبيعات", "المبيعات", 0),
            ("📦 المخزون", "المخزون", 1),
            ("👤 العملاء", "العملاء", 2),
            ("📊 التقارير", "التقارير", 3),
            ("⚙️ الإعدادات", "الإعدادات", 4),
        ]
        for text, _title, index in nav_specs[:4]:
            sidebar_layout.addWidget(self.create_nav_button(text, index))
        sidebar_layout.addStretch()
        sidebar_layout.addWidget(self.create_nav_button(nav_specs[4][0], nav_specs[4][2]))

        content_area = QWidget()
        content_layout = QVBoxLayout(content_area)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        top_bar = QFrame()
        top_bar.setObjectName("TopBar")
        top_bar.setFixedHeight(60)
        top_layout = QHBoxLayout(top_bar)
        top_layout.setContentsMargins(20, 0, 20, 0)
        self.page_title = QLabel("المبيعات")
        self.page_title.setObjectName("PageTitle")
        self.page_title.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        top_layout.addStretch()
        top_layout.addWidget(self.page_title)

        self.pages = QStackedWidget()
        self.pages.setObjectName("MainContent")
        self.page_titles = [spec[1] for spec in nav_specs]
        self.pages.addWidget(SalesScreen(self.bridge))
        self.pages.addWidget(InventoryScreen(self.bridge))
        self.pages.addWidget(CustomersScreen(self.bridge))
        self.pages.addWidget(ReportsScreen(self.bridge))
        self.pages.addWidget(SettingsScreen(self.bridge))

        content_layout.addWidget(top_bar)
        content_layout.addWidget(self.pages, 1)
        main_layout.addWidget(sidebar)
        main_layout.addWidget(content_area, 1)

        self.switch_page(0)

    def create_nav_button(self, text: str, page_index: int) -> QPushButton:
        btn = QPushButton(text)
        btn.setObjectName("NavButton")
        btn.setFont(QFont("Tajawal", 11, QFont.Weight.Medium))
        btn.clicked.connect(lambda _checked=False, index=page_index: self.switch_page(index))
        btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.nav_buttons.append(btn)
        return btn

    def switch_page(self, index: int) -> None:
        self.pages.setCurrentIndex(index)
        if self.page_title is not None:
            self.page_title.setText(self.page_titles[index])
        for i, btn in enumerate(self.nav_buttons):
            btn.setProperty("class", "active" if i == index else "")
            btn.style().unpolish(btn)
            btn.style().polish(btn)


def run_modern_ui() -> int:
    """Standalone launcher for the new modern shell."""
    import sys

    app = QApplication(sys.argv)
    load_optional_app_fonts()
    app.setFont(QFont("Tajawal", 10))
    app.setLayoutDirection(Qt.RightToLeft)
    window = ModernMainWindow()
    window.show()
    return app.exec()

