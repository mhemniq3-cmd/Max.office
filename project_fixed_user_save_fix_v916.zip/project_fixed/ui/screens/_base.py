from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QLabel, QVBoxLayout, QWidget


class _ModernPlaceholder(QWidget):
    title = ""
    subtitle = ""

    def __init__(self, bridge=None, parent=None):
        super().__init__(parent)
        self.bridge = bridge
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        card = QFrame()
        card.setObjectName("Card")
        card_layout = QVBoxLayout(card)
        title = QLabel(self.title)
        title.setObjectName("sectionTitle")
        title.setAlignment(Qt.AlignRight)
        subtitle = QLabel(self.subtitle)
        subtitle.setObjectName("mutedText")
        subtitle.setWordWrap(True)
        subtitle.setAlignment(Qt.AlignRight)
        card_layout.addWidget(title)
        card_layout.addWidget(subtitle)
        card_layout.addStretch()
        layout.addWidget(card)

    def refresh(self):
        return None
