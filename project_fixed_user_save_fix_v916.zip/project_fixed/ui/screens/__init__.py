"""Modern screen compatibility package.

Production uses ui.pages with AppService; these classes provide lightweight
CoreBridge-compatible screens for future clean UI entry points.
"""
from .sales_screen import SalesScreen
from .inventory_screen import InventoryScreen
from .customers_screen import CustomersScreen
from .reports_screen import ReportsScreen
from .settings_screen import SettingsScreen

__all__ = ["SalesScreen", "InventoryScreen", "CustomersScreen", "ReportsScreen", "SettingsScreen"]
