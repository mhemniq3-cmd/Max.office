from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QLabel, QPushButton, QVBoxLayout, QWidget, QMessageBox


class SettingsScreen(QWidget):
    title = "⚙️ الإعدادات"

    def __init__(self, bridge=None, parent=None):
        super().__init__(parent)
        self.setLayoutDirection(Qt.RightToLeft)
        self.bridge = bridge
        self._build_ui()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        card = QFrame()
        card.setObjectName("Card")
        card_layout = QVBoxLayout(card)
        title = QLabel("⚙️ الإعدادات والهوية البصرية")
        title.setObjectName("sectionTitle")
        subtitle = QLabel("الإصدار النهائي يعمل بالمسار الحديث فقط. يمكن تعديل السمات من ملفات settings/ui_brand_theme.json و settings/ui_mode.txt.")
        subtitle.setObjectName("mutedText")
        subtitle.setWordWrap(True)
        status = QLabel("MAX_SALES_NATIVE_PERSISTENCE=on\nDB_PATH=./database/max_sales.db\nواجهة عربية RTL مفعّلة")
        status.setObjectName("noticeBox")
        btn = QPushButton("فحص حالة المعمارية")
        btn.clicked.connect(self.show_architecture_status)
        card_layout.addWidget(title)
        card_layout.addWidget(subtitle)
        card_layout.addWidget(status)
        card_layout.addWidget(btn)
        card_layout.addStretch()
        layout.addWidget(card, 1)

    def show_architecture_status(self) -> None:
        try:
            if self.bridge and hasattr(self.bridge, "architecture_status"):
                data = self.bridge.architecture_status()
            else:
                from services.core_bridge import architecture_status
                data = architecture_status()
            QMessageBox.information(self, "حالة النظام", "\n".join(f"{k}: {v}" for k, v in data.items()))
        except Exception as exc:
            QMessageBox.warning(self, "تعذر الفحص", str(exc))
