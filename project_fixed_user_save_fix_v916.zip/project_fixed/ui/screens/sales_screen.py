from __future__ import annotations

"""Modern Arabic sales screen.

This screen is intentionally UI-focused and can work with either:
- the application's AppService instance, or
- a light bridge/facade that exposes get_records and execute_sale_process.

It does not use legacy storage paths; saves are routed through the provided
service/bridge only.
"""

from typing import Any
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from PySide6.QtCore import Qt, QRegularExpression
from PySide6.QtGui import QFont, QRegularExpressionValidator
from services.domain.calculations import format_currency

from PySide6.QtWidgets import (
    QComboBox,
    QDoubleSpinBox,
    QFrame,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
    QHeaderView,
)


def _row_get(row: Any, *names: str, default: Any = None) -> Any:
    for name in names:
        if isinstance(row, dict) and name in row:
            return row.get(name, default)
        try:
            return row[name]
        except Exception:
            pass
        if hasattr(row, name):
            return getattr(row, name)
    return default


def _as_decimal(value: Any, default: str | int | Decimal = "0") -> Decimal:
    """Convert UI/service values to Decimal without using binary floats."""
    try:
        if isinstance(value, Decimal):
            amount = value
        else:
            amount = Decimal(str(value if value is not None and value != "" else default))
        return amount.quantize(Decimal("0.0000"), rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError, TypeError):
        return Decimal(str(default)).quantize(Decimal("0.0000"), rounding=ROUND_HALF_UP)


def _money_text(value: Any) -> str:
    return format_currency(_as_decimal(value))


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(_as_decimal(value or 0))
    except Exception:
        return default


class SalesScreen(QWidget):
    """Modern sales screen with product search, cart, totals, and safe save flow."""

    def __init__(self, core_bridge: Any, current_user: Any | None = None):
        super().__init__()
        self.setLayoutDirection(Qt.RightToLeft)
        self.bridge = core_bridge
        self.current_user = current_user
        self.cart_items: list[dict[str, Any]] = []
        self.product_rows: list[dict[str, Any]] = []
        self.customer_rows: list[dict[str, Any]] = []
        self.employee_rows: list[dict[str, Any]] = []
        self.setup_ui()
        self.load_initial_data()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def setup_ui(self) -> None:
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(15)

        top_frame = QFrame()
        top_frame.setObjectName("Card")
        top_layout = QHBoxLayout(top_frame)
        top_layout.setSpacing(14)

        customer_group = QGroupBox("بيانات العميل")
        customer_group.setFont(QFont("Tajawal", 10, QFont.Bold))
        customer_layout = QFormLayout(customer_group)
        customer_layout.setLabelAlignment(Qt.AlignRight)
        customer_layout.setSpacing(10)

        self.customer_selector = QComboBox()
        self.customer_selector.setEditable(True)
        self.customer_selector.setPlaceholderText("بحث أو اختيار عميل...")
        self.customer_selector.currentIndexChanged.connect(self.fill_customer_data)

        self.customer_name = QLineEdit()
        self.customer_name.setPlaceholderText("اسم العميل أو زبون عابر")
        self.customer_phone = QLineEdit()
        self.customer_phone.setValidator(QRegularExpressionValidator(QRegularExpression(r"[0-9+\- ]+")))
        self.customer_phone.setPlaceholderText("رقم الهاتف اختياري")

        customer_layout.addRow(QLabel("العميل:"), self.customer_selector)
        customer_layout.addRow(QLabel("الاسم:"), self.customer_name)
        customer_layout.addRow(QLabel("الهاتف:"), self.customer_phone)

        invoice_group = QGroupBox("معلومات الفاتورة")
        invoice_group.setFont(QFont("Tajawal", 10, QFont.Bold))
        invoice_layout = QFormLayout(invoice_group)
        invoice_layout.setLabelAlignment(Qt.AlignRight)

        self.invoice_number = QLabel("تلقائي عند الحفظ")
        self.invoice_number.setObjectName("StatLabel")
        self.payment_method = QComboBox()
        self.payment_method.addItems(["نقدي", "بطاقة", "تحويل", "آجل", "شبكة", "بطاقة ائتمان"])
        self.employee_selector = QComboBox()
        self.employee_selector.setPlaceholderText("اختر الموظف")

        invoice_layout.addRow(QLabel("رقم الفاتورة:"), self.invoice_number)
        invoice_layout.addRow(QLabel("طريقة الدفع:"), self.payment_method)
        invoice_layout.addRow(QLabel("الموظف:"), self.employee_selector)

        top_layout.addWidget(customer_group, 2)
        top_layout.addWidget(invoice_group, 1)

        center_splitter = QSplitter(Qt.Horizontal)
        center_splitter.setObjectName("Card")
        center_splitter.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        search_panel = QWidget()
        search_layout = QVBoxLayout(search_panel)
        search_layout.setContentsMargins(15, 15, 15, 15)
        search_layout.setSpacing(10)

        search_title = QLabel("البحث عن منتج")
        search_title.setFont(QFont("Tajawal", 12, QFont.Bold))
        self.product_search = QLineEdit()
        self.product_search.setPlaceholderText("اكتب الباركود أو اسم المنتج للبحث الفوري...")
        self.product_search.returnPressed.connect(self.search_product)
        self.product_search.textChanged.connect(lambda _text: self.search_product(False))

        self.product_list = QTableWidget()
        self.product_list.setColumnCount(4)
        self.product_list.setHorizontalHeaderLabels(["الباركود", "الاسم", "السعر", "المتوفر"])
        self.product_list.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.product_list.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.product_list.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.product_list.doubleClicked.connect(self.add_selected_product)

        search_layout.addWidget(search_title)
        search_layout.addWidget(self.product_search)
        search_layout.addWidget(self.product_list, 1)

        cart_panel = QWidget()
        cart_layout = QVBoxLayout(cart_panel)
        cart_layout.setContentsMargins(15, 15, 15, 15)
        cart_layout.setSpacing(10)

        cart_title = QLabel("سلة المشتريات")
        cart_title.setFont(QFont("Tajawal", 12, QFont.Bold))
        self.cart_table = QTableWidget()
        self.cart_table.setColumnCount(7)
        self.cart_table.setHorizontalHeaderLabels(["الباركود", "المنتج", "الكمية", "السعر", "خصم الصنف", "الإجمالي", "حذف"])
        self.cart_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.cart_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)

        cart_layout.addWidget(cart_title)
        cart_layout.addWidget(self.cart_table, 1)

        center_splitter.addWidget(search_panel)
        center_splitter.addWidget(cart_panel)
        center_splitter.setSizes([420, 680])

        bottom_frame = QFrame()
        bottom_frame.setObjectName("Card")
        bottom_layout = QHBoxLayout(bottom_frame)
        bottom_layout.setContentsMargins(20, 15, 20, 15)

        summary_layout = QVBoxLayout()
        summary_layout.setAlignment(Qt.AlignRight)
        self.sub_total_label = QLabel("المجموع الفرعي: 0")
        self.discount_label = QLabel("الخصم: 0")
        self.total_label = QLabel("الإجمالي النهائي: 0")
        self.total_label.setObjectName("StatLabel")
        self.total_label.setFont(QFont("Tajawal", 14, QFont.Bold))

        discount_layout = QHBoxLayout()
        discount_layout.addWidget(QLabel("قيمة الخصم:"))
        self.discount_input = QDoubleSpinBox()
        self.discount_input.setMaximum(999999999)
        self.discount_input.setDecimals(0)
        self.discount_input.valueChanged.connect(self.calculate_total)
        discount_layout.addWidget(self.discount_input)

        summary_layout.addWidget(self.sub_total_label)
        summary_layout.addWidget(self.discount_label)
        summary_layout.addLayout(discount_layout)
        summary_layout.addWidget(self.total_label)

        btn_layout = QVBoxLayout()
        btn_layout.setSpacing(10)
        self.btn_clear = QPushButton("مسح السلة")
        self.btn_clear.setObjectName("warningButton")
        self.btn_clear.clicked.connect(self.clear_cart)
        self.btn_save = QPushButton("حفظ وطباعة الفاتورة")
        self.btn_save.setObjectName("successButton")
        self.btn_save.clicked.connect(self.save_sale)
        btn_layout.addWidget(self.btn_clear)
        btn_layout.addWidget(self.btn_save)

        bottom_layout.addLayout(summary_layout)
        bottom_layout.addStretch()
        bottom_layout.addLayout(btn_layout)

        main_layout.addWidget(top_frame)
        main_layout.addWidget(center_splitter, 1)
        main_layout.addWidget(bottom_frame)

    # ------------------------------------------------------------------
    # Data adapters
    # ------------------------------------------------------------------
    def _records(self, table: str, filters: dict[str, Any] | None = None, order_by: str | None = None) -> list[dict[str, Any]]:
        if hasattr(self.bridge, "get_records"):
            return list(self.bridge.get_records(table, filters=filters, order_by=order_by) or [])
        if hasattr(self.bridge, "get_data"):
            return list(self.bridge.get_data(table, filters=filters) or [])
        return []

    def _list_customers(self) -> list[dict[str, Any]]:
        if hasattr(self.bridge, "list_customers"):
            return [dict(r) for r in (self.bridge.list_customers() or [])]
        return self._records("customers", filters={"active": 1}, order_by="name ASC")

    def _list_employees(self) -> list[dict[str, Any]]:
        if hasattr(self.bridge, "list_employees"):
            return [dict(r) for r in (self.bridge.list_employees() or [])]
        return self._records("employees", filters={"active": 1}, order_by="name ASC")

    def _list_products(self, term: str) -> list[dict[str, Any]]:
        if hasattr(self.bridge, "list_products_for_sale"):
            return [dict(r) for r in (self.bridge.list_products_for_sale(term) or [])]
        if hasattr(self.bridge, "list_products"):
            return [dict(r) for r in (self.bridge.list_products(term) or [])]
        rows = self._records("products", filters={"active": 1}, order_by="name ASC")
        needle = term.strip().lower()
        if not needle:
            return rows[:500]
        return [
            row for row in rows
            if needle in str(_row_get(row, "barcode", default="")).lower()
            or needle in str(_row_get(row, "name", default="")).lower()
            or needle in str(_row_get(row, "category", default="")).lower()
        ][:500]

    # ------------------------------------------------------------------
    # Runtime logic
    # ------------------------------------------------------------------
    def load_initial_data(self) -> None:
        try:
            self.customer_rows = self._list_customers()
            self.customer_selector.blockSignals(True)
            self.customer_selector.clear()
            self.customer_selector.addItem("زبون عابر", None)
            for customer in self.customer_rows:
                self.customer_selector.addItem(str(_row_get(customer, "name", default="")), _row_get(customer, "id"))
            self.customer_selector.blockSignals(False)
            self.customer_selector.setCurrentIndex(0)

            self.employee_rows = self._list_employees()
            self.employee_selector.clear()
            for employee in self.employee_rows:
                self.employee_selector.addItem(str(_row_get(employee, "name", "full_name", default="")), _row_get(employee, "id"))
            if not self.employee_rows:
                self.employee_selector.addItem("بدون موظف", None)

            self.search_product(show_all=True)
        except Exception as exc:
            QMessageBox.warning(self, "تنبيه", f"خطأ في تحميل البيانات الأولية: {exc}")

    def fill_customer_data(self) -> None:
        idx = self.customer_selector.currentIndex()
        if idx <= 0:
            self.customer_name.clear()
            self.customer_phone.clear()
            return
        customer_id = self.customer_selector.currentData()
        row = next((c for c in self.customer_rows if _row_get(c, "id") == customer_id), None)
        if row:
            self.customer_name.setText(str(_row_get(row, "name", default="")))
            self.customer_phone.setText(str(_row_get(row, "phone", default="") or ""))

    def search_product(self, show_all: bool = False) -> None:
        term = "" if show_all else self.product_search.text().strip()
        try:
            self.product_rows = self._list_products(term)
            self.product_list.setRowCount(len(self.product_rows))
            for row, product in enumerate(self.product_rows):
                barcode = str(_row_get(product, "barcode", default="") or "")
                name = str(_row_get(product, "name", "product_name", default="") or "")
                price = _as_decimal(_row_get(product, "sale_price", "sell_price", "unit_price", default=0))
                stock = _as_decimal(_row_get(product, "quantity", "stock_quantity", "current_stock", default=0))
                values = [barcode, name, _money_text(price), _money_text(stock)]
                for col, value in enumerate(values):
                    item = QTableWidgetItem(value)
                    item.setToolTip(value)
                    if col in (2, 3):
                        item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                    else:
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    if col == 0:
                        item.setData(Qt.UserRole, product)
                    self.product_list.setItem(row, col, item)
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشل البحث عن المنتج: {exc}")

    def add_selected_product(self) -> None:
        selected = self.product_list.currentRow()
        if selected < 0 or selected >= len(self.product_rows):
            return
        product_data = self.product_rows[selected]
        self.add_product_to_cart(product_data)

    def add_product_to_cart(self, product_data: dict[str, Any]) -> None:
        product_id = _row_get(product_data, "id", "product_id")
        barcode = str(_row_get(product_data, "barcode", default="") or "")
        name = str(_row_get(product_data, "name", "product_name", default="") or "")
        stock = _as_int(_row_get(product_data, "quantity", "stock_quantity", "current_stock", default=999999), 999999)
        price = _as_decimal(_row_get(product_data, "sale_price", "sell_price", "unit_price", default=0))
        cost = _as_decimal(_row_get(product_data, "cost_price", default=0))
        commission = _as_decimal(_row_get(product_data, "commission_percent", default=0))

        if stock <= 0:
            QMessageBox.warning(self, "مخزون غير متاح", f"المنتج {name} غير متوفر في المخزون.")
            return

        for item in self.cart_items:
            if item.get("product_id") == product_id:
                if item["quantity"] + 1 > stock:
                    QMessageBox.warning(self, "مخزون غير كاف", "الكمية المطلوبة أكبر من المخزون المتاح.")
                    return
                item["quantity"] += 1
                self.render_cart()
                return

        self.cart_items.append(
            {
                "product_id": product_id,
                "barcode": barcode,
                "product_name": name,
                "name": name,
                "quantity": 1,
                "unit_price": price,
                "sale_price": price,
                "cost_price": cost,
                "commission_percent": commission,
                "item_discount": Decimal("0.0000"),
                "stock_quantity": stock,
            }
        )
        self.render_cart()
        self.product_search.clear()

    def render_cart(self) -> None:
        self.cart_table.blockSignals(True)
        self.cart_table.setRowCount(len(self.cart_items))
        for row, item in enumerate(self.cart_items):
            price = _as_decimal(item.get("unit_price"))
            qty = _as_int(item.get("quantity"), 1)
            line_total = _as_decimal(qty) * price
            item_discount = _as_decimal(item.get("item_discount", 0))
            line_total = max(line_total - item_discount, Decimal("0.0000"))
            values = [item.get("barcode", ""), item.get("product_name", ""), "", _money_text(price), "", _money_text(line_total), ""]
            for col, value in enumerate(values):
                if col in (2, 4, 6):
                    continue
                cell = QTableWidgetItem(str(value))
                cell.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter if col in (3, 5) else Qt.AlignRight | Qt.AlignVCenter)
                self.cart_table.setItem(row, col, cell)

            qty_spin = QSpinBox()
            qty_spin.setMinimum(1)
            qty_spin.setMaximum(max(_as_int(item.get("stock_quantity"), 999999), 1))
            qty_spin.setValue(qty)
            qty_spin.valueChanged.connect(lambda value, r=row: self.update_quantity(r, value))
            self.cart_table.setCellWidget(row, 2, qty_spin)

            discount_spin = QDoubleSpinBox()
            discount_spin.setMinimum(0)
            discount_spin.setMaximum(999999999)
            discount_spin.setDecimals(2)
            discount_spin.setValue(int(item_discount * Decimal("100")) / 100)
            discount_spin.valueChanged.connect(lambda value, r=row: self.update_item_discount(r, value))
            self.cart_table.setCellWidget(row, 4, discount_spin)

            delete_btn = QPushButton("×")
            delete_btn.setObjectName("dangerButton")
            delete_btn.clicked.connect(lambda checked=False, r=row: self.remove_item(r))
            self.cart_table.setCellWidget(row, 6, delete_btn)
        self.cart_table.blockSignals(False)
        self.calculate_total()

    def update_quantity(self, row: int, value: int) -> None:
        if 0 <= row < len(self.cart_items):
            self.cart_items[row]["quantity"] = int(value)
            price = _as_decimal(self.cart_items[row].get("unit_price"))
            discount = _as_decimal(self.cart_items[row].get("item_discount", 0))
            total_cell = self.cart_table.item(row, 5)
            if total_cell is None:
                total_cell = QTableWidgetItem()
                self.cart_table.setItem(row, 5, total_cell)
            total_cell.setText(_money_text(max((_as_decimal(value) * price) - discount, Decimal("0.0000"))))
            total_cell.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            self.calculate_total()


    def update_item_discount(self, row: int, value: object) -> None:
        if 0 <= row < len(self.cart_items):
            discount = _as_decimal(str(value))
            qty = _as_decimal(self.cart_items[row].get("quantity", 1))
            price = _as_decimal(self.cart_items[row].get("unit_price"))
            gross = qty * price
            if discount > gross:
                discount = gross
            self.cart_items[row]["item_discount"] = discount
            total_cell = self.cart_table.item(row, 5)
            if total_cell is None:
                total_cell = QTableWidgetItem()
                self.cart_table.setItem(row, 5, total_cell)
            total_cell.setText(_money_text(max(gross - discount, Decimal("0.0000"))))
            total_cell.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            self.calculate_total()

    def calculate_total(self) -> None:
        subtotal = sum((max((_as_decimal(item.get("quantity", 1)) * _as_decimal(item.get("unit_price"))) - _as_decimal(item.get("item_discount", 0)), Decimal("0.0000")) for item in self.cart_items), Decimal("0.0000"))
        discount = _as_decimal(str(self.discount_input.value()))
        if discount > subtotal:
            discount = subtotal
        final_total = subtotal - discount
        self.sub_total_label.setText(f"المجموع الفرعي: {_money_text(subtotal)}")
        self.discount_label.setText(f"الخصم: {_money_text(discount)}")
        self.total_label.setText(f"الإجمالي النهائي: {_money_text(final_total)}")

    def remove_item(self, row: int) -> None:
        if 0 <= row < len(self.cart_items):
            product_name = str(self.cart_items[row].get("product_name") or "هذا الصنف")
            confirm = QMessageBox.question(
                self,
                "تأكيد الحذف",
                f"هل أنت متأكد من حذف {product_name} من السلة؟",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if confirm != QMessageBox.StandardButton.Yes:
                return
            self.cart_items.pop(row)
            self.render_cart()

    def clear_cart(self) -> None:
        self.cart_items.clear()
        self.discount_input.setValue(0)
        self.render_cart()
        self.invoice_number.setText("تلقائي عند الحفظ")

    def _cart_for_service(self) -> list[dict[str, Any]]:
        return [
            {
                "product_id": item.get("product_id"),
                "product_name": item.get("product_name"),
                "name": item.get("product_name"),
                "barcode": item.get("barcode"),
                "quantity": _as_int(item.get("quantity"), 1),
                "unit_price": _as_decimal(item.get("unit_price")),
                "sale_price": _as_decimal(item.get("unit_price")),
                "cost_price": _as_decimal(item.get("cost_price")),
                "commission_percent": _as_decimal(item.get("commission_percent")),
                "item_discount": _as_decimal(item.get("item_discount", 0)),
                "discount_amount": _as_decimal(item.get("item_discount", 0)),
            }
            for item in self.cart_items
        ]

    def _validate_before_save(self) -> bool:
        """Validate required UI fields before the request reaches the data layer."""
        customer_name = self.customer_name.text().strip()
        phone = self.customer_phone.text().strip()
        if phone and not all(ch.isdigit() or ch in "+- " for ch in phone):
            QMessageBox.warning(self, "رقم هاتف غير صحيح", "رقم الهاتف يجب أن يحتوي على أرقام ورموز + - فقط.")
            return False
        if not self.cart_items:
            QMessageBox.warning(self, "تنبيه", "السلة فارغة!")
            return False
        if self.employee_selector.currentData() is None and self.employee_selector.count() > 1:
            QMessageBox.warning(self, "تنبيه", "يرجى اختيار الموظف قبل حفظ الفاتورة.")
            return False
        for item in self.cart_items:
            if item.get("product_id") in (None, ""):
                QMessageBox.warning(self, "بيانات صنف ناقصة", "يوجد صنف بدون رقم منتج صالح.")
                return False
            if _as_decimal(item.get("quantity", 0)) <= 0:
                QMessageBox.warning(self, "كمية غير صحيحة", "كل الكميات يجب أن تكون أكبر من صفر.")
                return False
            if _as_decimal(item.get("unit_price", 0)) < 0:
                QMessageBox.warning(self, "سعر غير صحيح", "سعر الصنف لا يمكن أن يكون سالباً.")
                return False
            gross = _as_decimal(item.get("quantity", 1)) * _as_decimal(item.get("unit_price", 0))
            if _as_decimal(item.get("item_discount", 0)) > gross:
                QMessageBox.warning(self, "خصم صنف غير صحيح", "خصم الصنف لا يمكن أن يتجاوز إجمالي الصنف.")
                return False
        if not customer_name:
            self.customer_name.setText("زبون عابر")
        return True

    def save_sale(self) -> None:
        if not self._validate_before_save():
            return
        invoice_subtotal = sum((max((_as_decimal(i.get("quantity", 1)) * _as_decimal(i.get("unit_price"))) - _as_decimal(i.get("item_discount", 0)), Decimal("0.0000")) for i in self.cart_items), Decimal("0.0000"))
        if _as_decimal(str(self.discount_input.value())) >= invoice_subtotal:
            QMessageBox.warning(self, "خصم غير صحيح", "الخصم لا يمكن أن يساوي أو يتجاوز قيمة الفاتورة.")
            return

        employee_id = self.employee_selector.currentData()
        customer_id = self.customer_selector.currentData()
        payment_method = self.payment_method.currentText()
        cart = self._cart_for_service()

        try:
            if hasattr(self.bridge, "complete_sale"):
                invoice = self.bridge.complete_sale(
                    cart,
                    employee_id,
                    customer_id,
                    payment_method,
                    _as_decimal(str(self.discount_input.value())),
                    "",
                    _row_get(self.current_user, "id") if self.current_user else None,
                    "amount",
                )
                self.invoice_number.setText(str(invoice))
                QMessageBox.information(self, "تم بنجاح", f"تم حفظ الفاتورة رقم: {invoice}")
                self.clear_cart()
                return

            sale_data = {
                "customer_id": customer_id,
                "customer_name": self.customer_name.text() or "زبون عابر",
                "customer_phone": self.customer_phone.text(),
                "employee_id": employee_id,
                "payment_method": payment_method,
                "discount_amount": _as_decimal(str(self.discount_input.value())),
                "items": cart,
            }
            result = self.bridge.execute_sale_process(sale_data)
            if getattr(result, "success", False):
                invoice = getattr(result, "invoice_number", None) or getattr(result, "record_id", None) or getattr(result, "result", None) or "تم"
                self.invoice_number.setText(str(invoice))
                QMessageBox.information(self, "تم بنجاح", f"تم حفظ الفاتورة رقم: {invoice}")
                self.clear_cart()
            else:
                QMessageBox.critical(self, "خطأ في الحفظ", str(getattr(result, "error_message", "تعذر حفظ الفاتورة")))
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشل حفظ الفاتورة: {exc}")
