from __future__ import annotations

import csv
from datetime import date, datetime
from pathlib import Path
from typing import Any
from decimal import Decimal, InvalidOperation

from PySide6.QtCore import QDate, Qt
from services.domain.calculations import format_currency
from PySide6.QtWidgets import (
    QDateEdit,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
    QHeaderView,
)


def _row_get(row: dict[str, Any], *names: str, default: Any = "") -> Any:
    for name in names:
        if isinstance(row, dict) and name in row and row.get(name) is not None:
            return row.get(name)
    return default


def _parse_date(value: Any) -> date | None:
    text = str(value or "").strip()
    if not text:
        return None
    for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%Y/%m/%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(text[:19], fmt).date()
        except ValueError:
            continue
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).date()
    except ValueError:
        return None


class ReportsScreen(QWidget):
    """Modern reports screen with working date filters and export support."""

    def __init__(self, bridge=None, parent=None):
        super().__init__(parent)
        self.setLayoutDirection(Qt.RightToLeft)
        self.bridge = bridge
        self.current_rows: list[list[str]] = []
        self._build_ui()
        self.refresh()

    def _records(self, table: str, order_by: str) -> list[dict[str, Any]]:
        if self.bridge and hasattr(self.bridge, "get_records"):
            return list(self.bridge.get_records(table, order_by=order_by) or [])
        return []

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(12)

        card = QFrame()
        card.setObjectName("Card")
        card_layout = QVBoxLayout(card)
        card_layout.setSpacing(10)

        header = QHBoxLayout()
        title = QLabel("📊 التقارير")
        title.setObjectName("sectionTitle")
        subtitle = QLabel("تقارير المبيعات والدفعات مع فلترة بين تاريخين وتصدير ملف خارجي.")
        subtitle.setObjectName("mutedText")
        subtitle.setWordWrap(True)
        header.addWidget(title)
        header.addWidget(subtitle, 1)
        card_layout.addLayout(header)

        filters = QHBoxLayout()
        filters.addWidget(QLabel("من:"))
        self.date_from = QDateEdit()
        self.date_from.setCalendarPopup(True)
        self.date_from.setDisplayFormat("yyyy-MM-dd")
        self.date_from.setDate(QDate.currentDate().addDays(-30))
        filters.addWidget(self.date_from)

        filters.addWidget(QLabel("إلى:"))
        self.date_to = QDateEdit()
        self.date_to.setCalendarPopup(True)
        self.date_to.setDisplayFormat("yyyy-MM-dd")
        self.date_to.setDate(QDate.currentDate())
        filters.addWidget(self.date_to)

        refresh_btn = QPushButton("تطبيق الفلتر")
        refresh_btn.clicked.connect(self.refresh)
        export_csv_btn = QPushButton("تصدير Excel/CSV")
        export_csv_btn.clicked.connect(self.export_csv)
        export_html_btn = QPushButton("تصدير HTML للطباعة")
        export_html_btn.clicked.connect(self.export_html)
        filters.addWidget(refresh_btn)
        filters.addWidget(export_csv_btn)
        filters.addWidget(export_html_btn)
        filters.addStretch()
        card_layout.addLayout(filters)

        self.summary = QLabel("المبيعات: 0 | الدفعات: 0 | الإجمالي: 0")
        self.summary.setObjectName("StatLabel")
        self.summary.setAlignment(Qt.AlignRight)
        card_layout.addWidget(self.summary)

        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["النوع", "الرقم", "العميل", "المبلغ", "طريقة الدفع", "التاريخ"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setWordWrap(True)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        card_layout.addWidget(self.table, 1)
        layout.addWidget(card, 1)

    def _in_range(self, raw_date: Any) -> bool:
        value = _parse_date(raw_date)
        if value is None:
            return True
        start = self.date_from.date().toPython()
        end = self.date_to.date().toPython()
        return start <= value <= end

    def refresh(self) -> None:
        try:
            sales = [row for row in self._records("sales", "created_at DESC") if self._in_range(_row_get(row, "created_at", "date", default=""))]
            payments = [row for row in self._records("payments", "created_at DESC") if self._in_range(_row_get(row, "created_at", "payment_date", default=""))]
            rows: list[list[str]] = []
            total_amount = Decimal("0.00")
            for row in sales[:500]:
                amount = _row_get(row, "total", "net_amount", "total_amount", default="0")
                try:
                    total_amount += Decimal(str(amount or 0))
                except (InvalidOperation, ValueError):
                    pass
                rows.append([
                    "بيع",
                    str(_row_get(row, "invoice_no", "invoice_number", "id", default="")),
                    str(_row_get(row, "customer_name", "customer_id", default="")),
                    format_currency(amount),
                    str(_row_get(row, "payment_method", "payment_type", default="")),
                    str(_row_get(row, "created_at", "date", default="")),
                ])
            for row in payments[:500]:
                amount = _row_get(row, "amount", default="0")
                rows.append([
                    "دفعة",
                    str(_row_get(row, "receipt_no", "reference_number", "id", default="")),
                    str(_row_get(row, "customer_name", "customer_id", default="")),
                    format_currency(amount),
                    str(_row_get(row, "payment_method", "payment_type", default="")),
                    str(_row_get(row, "created_at", "payment_date", default="")),
                ])

            self.current_rows = rows
            self.summary.setText(f"المبيعات: {len(sales)} | الدفعات: {len(payments)} | إجمالي المبيعات: {format_currency(total_amount)}")
            self.table.setRowCount(len(rows))
            for r, values in enumerate(rows):
                for c, value in enumerate(values):
                    text = str(value if value is not None else "")
                    item = QTableWidgetItem(text)
                    item.setToolTip(text)
                    if c in (3,):
                        item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                    else:
                        item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                    self.table.setItem(r, c, item)
            self.table.resizeRowsToContents()
        except Exception as exc:
            QMessageBox.warning(self, "تعذر تحميل التقارير", str(exc))

    def export_csv(self) -> None:
        if not self.current_rows:
            QMessageBox.information(self, "لا توجد بيانات", "لا توجد صفوف لتصديرها.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "تصدير التقرير", "sales_report.csv", "CSV Files (*.csv)")
        if not path:
            return
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["النوع", "الرقم", "العميل", "المبلغ", "طريقة الدفع", "التاريخ"])
            writer.writerows(self.current_rows)
        QMessageBox.information(self, "تم التصدير", f"تم حفظ التقرير في:\n{path}")

    def export_html(self) -> None:
        if not self.current_rows:
            QMessageBox.information(self, "لا توجد بيانات", "لا توجد صفوف لتصديرها.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "تصدير HTML", "sales_report.html", "HTML Files (*.html)")
        if not path:
            return
        headers = ["النوع", "الرقم", "العميل", "المبلغ", "طريقة الدفع", "التاريخ"]
        def esc(value: Any) -> str:
            return str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        rows_html = "\n".join("<tr>" + "".join(f"<td>{esc(cell)}</td>" for cell in row) + "</tr>" for row in self.current_rows)
        html = f"""<!doctype html><html lang=\"ar\" dir=\"rtl\"><meta charset=\"utf-8\"><title>تقرير المبيعات</title>
<style>body{{font-family:Tahoma,Arial;margin:24px}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #ddd;padding:8px}}th{{background:#f2f3f5}}</style>
<h1>تقرير المبيعات والدفعات</h1><p>{self.summary.text()}</p><table><thead><tr>{''.join(f'<th>{h}</th>' for h in headers)}</tr></thead><tbody>{rows_html}</tbody></table></html>"""
        Path(path).write_text(html, encoding="utf-8")
        QMessageBox.information(self, "تم التصدير", f"تم حفظ التقرير في:\n{path}")
