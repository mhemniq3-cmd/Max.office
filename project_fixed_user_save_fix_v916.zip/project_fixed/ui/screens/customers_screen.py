from __future__ import annotations

from ._data_screen import DataTableScreen


class CustomersScreen(DataTableScreen):
    title = "👤 العملاء والديون"
    subtitle = "عرض العملاء وبيانات الاتصال. يمكن تسجيل الدفعات من مسار العملاء الأساسي، وتظهر في التقارير والمدفوعات العامة."
    table_name = "customers"
    order_by = "name ASC"
    columns = [
        ("المعرف", ("id",)),
        ("الاسم", ("name", "customer_name")),
        ("الهاتف", ("phone", "mobile")),
        ("العنوان", ("address",)),
        ("نشط", ("active",)),
        ("تاريخ الإضافة", ("created_at",)),
    ]
