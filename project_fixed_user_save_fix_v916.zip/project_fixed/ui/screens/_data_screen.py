from __future__ import annotations

from typing import Any
from decimal import Decimal, InvalidOperation

from services.domain.calculations import format_currency

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
    QHeaderView,
)




def is_numeric_value(value: Any) -> bool:
    try:
        Decimal(str(value).replace(",", ""))
        return value not in (None, "")
    except (InvalidOperation, ValueError, TypeError):
        return False


def display_value_for_column(label: str, value: Any) -> str:
    text = str(value if value is not None else "")
    money_markers = ("السعر", "المبلغ", "الإجمالي", "الرصيد", "دين", "مدفوع", "ربح", "كلفة")
    if any(marker in label for marker in money_markers) and is_numeric_value(value):
        return format_currency(value)
    return text

def row_value(row: Any, *names: str, default: Any = "") -> Any:
    for name in names:
        if isinstance(row, dict) and name in row:
            return row.get(name, default)
        try:
            return row[name]
        except Exception:
            pass
        if hasattr(row, name):
            return getattr(row, name)
    return default


class DataTableScreen(QWidget):
    """Small RTL data screen used by modern inventory/customers/reports pages.

    It never opens SQLite directly. Reads are routed through the provided bridge
    so the UI remains separated from the data layer.
    """

    title = ""
    subtitle = ""
    table_name = ""
    order_by = "id DESC"
    columns: list[tuple[str, tuple[str, ...]]] = []

    def __init__(self, bridge=None, parent=None):
        super().__init__(parent)
        self.setLayoutDirection(Qt.RightToLeft)
        self.bridge = bridge
        self.rows: list[dict[str, Any]] = []
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(12)

        card = QFrame()
        card.setObjectName("Card")
        card_layout = QVBoxLayout(card)
        card_layout.setSpacing(10)

        header = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel(self.title)
        title.setObjectName("sectionTitle")
        title.setAlignment(Qt.AlignRight)
        subtitle = QLabel(self.subtitle)
        subtitle.setObjectName("mutedText")
        subtitle.setWordWrap(True)
        subtitle.setAlignment(Qt.AlignRight)
        title_box.addWidget(title)
        title_box.addWidget(subtitle)

        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("بحث سريع...")
        self.search_box.textChanged.connect(self.apply_filter)
        self.refresh_button = QPushButton("تحديث")
        self.refresh_button.clicked.connect(self.refresh)

        header.addLayout(title_box, 1)
        header.addWidget(self.search_box)
        header.addWidget(self.refresh_button)
        card_layout.addLayout(header)

        self.table = QTableWidget()
        self.table.setColumnCount(len(self.columns))
        self.table.setHorizontalHeaderLabels([label for label, _ in self.columns])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        card_layout.addWidget(self.table, 1)

        layout.addWidget(card, 1)

    def _records(self) -> list[dict[str, Any]]:
        if not self.bridge or not hasattr(self.bridge, "get_records"):
            return []
        return list(self.bridge.get_records(self.table_name, order_by=self.order_by) or [])

    def refresh(self) -> None:
        try:
            self.rows = [dict(r) for r in self._records()]
            self.apply_filter()
        except Exception as exc:
            QMessageBox.warning(self, "تعذر التحديث", str(exc))

    def apply_filter(self) -> None:
        term = self.search_box.text().strip().lower() if hasattr(self, "search_box") else ""
        rows = self.rows
        if term:
            rows = [row for row in rows if term in " ".join(str(v or "") for v in row.values()).lower()]
        self.table.setRowCount(len(rows))
        for row_idx, row in enumerate(rows):
            for col_idx, (_label, keys) in enumerate(self.columns):
                value = row_value(row, *keys)
                label = self.columns[col_idx][0]
                text = display_value_for_column(label, value)
                item = QTableWidgetItem(text)
                item.setToolTip(str(value if value is not None else ""))
                if is_numeric_value(value):
                    item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                else:
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.table.setItem(row_idx, col_idx, item)
        self.table.resizeRowsToContents()
