from __future__ import annotations

from ._data_screen import DataTableScreen


class InventoryScreen(DataTableScreen):
    title = "📦 المخزون والمنتجات"
    subtitle = "عرض المنتجات والكميات والأسعار من قاعدة البيانات عبر الجسر الآمن. شاشة البيع تُحدّث الكمية تلقائياً عند حفظ الفاتورة."
    table_name = "products"
    order_by = "name ASC"
    columns = [
        ("المعرف", ("id",)),
        ("الباركود", ("barcode",)),
        ("المنتج", ("name", "product_name")),
        ("السعر", ("sale_price", "sell_price", "unit_price")),
        ("الكمية", ("quantity", "stock_quantity", "current_stock")),
        ("الحد الأدنى", ("min_quantity", "min_stock")),
        ("نشط", ("active",)),
    ]
