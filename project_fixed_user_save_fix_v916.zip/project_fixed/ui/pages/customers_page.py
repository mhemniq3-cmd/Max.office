from ui.ui_common import *

class CustomersPage(QWidget):
    def __init__(self, service: AppService, notify):
        super().__init__(); self.service = service; self.notify = notify; self.customer_id: int | None = None; self.rows = []
        self.build(); self.refresh()

    def build(self):
        root = QHBoxLayout(self)
        left = QFrame(); left.setObjectName('surface'); left_l = QVBoxLayout(left)
        self.table = Table(['الزبون', 'الهاتف', 'آجل', 'دفعات', 'الرصيد'])
        self.table.doubleClicked.connect(self.load_selected)
        customers_title = QLabel('👥 الزبائن والديون'); customers_title.setObjectName('sectionTitle')
        left_l.addWidget(customers_title); left_l.addWidget(self.table, 1)
        right = QFrame(); right.setObjectName('surface'); right.setFixedWidth(340)
        r_l = QVBoxLayout(right); form = QFormLayout()
        self.name = QLineEdit(); self.phone = QLineEdit(); self.address = QLineEdit()
        self.credit_limit = QDoubleSpinBox(); self.credit_limit.setMaximum(999999999); self.credit_limit.setDecimals(0)
        self.due_days = QSpinBox(); self.due_days.setMaximum(3650)
        self.payment = QDoubleSpinBox(); self.payment.setMaximum(999999999); self.payment.setDecimals(0)
        self.payment_note = QLineEdit()
        form.addRow('اسم الزبون', self.name); form.addRow('الهاتف', self.phone); form.addRow('العنوان', self.address); form.addRow('حد الدين', self.credit_limit); form.addRow('أيام الاستحقاق', self.due_days); form.addRow('دفعة', self.payment); form.addRow('ملاحظة الدفعة', self.payment_note)
        save = QPushButton('حفظ الزبون'); save.setObjectName('primaryButton'); save.clicked.connect(self.save_customer)
        pay = QPushButton('تسجيل دفعة'); pay.setObjectName('successButton'); pay.clicked.connect(self.add_payment)
        new = QPushButton('جديد'); new.clicked.connect(self.clear)
        statement = QPushButton('طباعة كشف حساب'); statement.setObjectName('primaryButton'); statement.clicked.connect(self.print_statement)
        statement_pdf = QPushButton('📄 كشف حساب PDF'); statement_pdf.setObjectName('primaryButton'); statement_pdf.clicked.connect(self.print_statement_pdf)
        customer_form_title = QLabel('بيانات الزبون'); customer_form_title.setObjectName('sectionTitle')
        r_l.addWidget(customer_form_title); r_l.addLayout(form); r_l.addWidget(save); r_l.addWidget(pay); r_l.addWidget(statement); r_l.addWidget(statement_pdf); r_l.addWidget(new); r_l.addStretch()
        root.addWidget(left, 1); root.addWidget(right)

    def refresh(self):
        self.rows = self.service.debt_rows(); self.table.setRowCount(len(self.rows))
        for r, row in enumerate(self.rows):
            vals = [row['name'], row['phone'] or '', money(row['credit_sales']), money(row['payments']), money(row['balance'])]
            for c, v in enumerate(vals): self.table.put(r, c, v, row['id'] if c == 0 else None)

    def load_selected(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.rows): return
        c = self.rows[row]; self.customer_id = c['id']; self.name.setText(c['name']); self.phone.setText(c['phone'] or ''); self.address.clear(); self.credit_limit.setValue(float(c['credit_limit'] or 0)); self.due_days.setValue(int(c['due_days'] or 0))

    def clear(self):
        self.customer_id = None; self.name.clear(); self.phone.clear(); self.address.clear(); self.credit_limit.setValue(0); self.due_days.setValue(0); self.payment.setValue(0); self.payment_note.clear()

    def save_customer(self):
        try: self.service.save_customer(self.name.text(), self.phone.text(), self.address.text(), self.customer_id, self.credit_limit.value(), self.due_days.value())
        except Exception as exc: QMessageBox.warning(self, 'تعذر الحفظ', str(exc)); return
        self.clear(); self.refresh(); self.notify('تم حفظ الزبون')

    def add_payment(self):
        if not self.customer_id: QMessageBox.warning(self, 'تنبيه', 'اختر الزبون أولاً'); return
        try: payment_id = self.service.add_payment(self.customer_id, self.payment.value(), self.payment_note.text())
        except Exception as exc: QMessageBox.warning(self, 'تعذر تسجيل الدفعة', str(exc)); return
        
        if QMessageBox.question(self, 'طباعة', 'هل تريد إنشاء وصل قبض؟') == QMessageBox.Yes:
            try:
                path = self.service.print_payment_receipt_html(payment_id); QMessageBox.information(self, 'تم', f'تم إنشاء وصل القبض:\n{path}')
            except Exception as exc:
                QMessageBox.warning(self, 'تعذر الطباعة', str(exc))
        self.payment.setValue(0); self.payment_note.clear(); self.refresh(); self.notify('تم تسجيل الدفعة')


    def print_statement_pdf(self):
        if not self.customer_id:
            QMessageBox.warning(self, 'تنبيه', 'اختر الزبون أولاً'); return
        rows = self.service.customer_statement(self.customer_id)
        bal = 0.0; data = []
        for row in rows:
            bal += float(row['debit']) - float(row['credit'])
            data.append([row['created_at'], row['kind'], row['ref'], money(row['debit']), money(row['credit']), money(bal), row['note']])
        path = rows_to_pdf('كشف حساب زبون', ['التاريخ','النوع','المرجع','مدين','دائن','الرصيد','ملاحظة'], data, f'customer_statement_{self.customer_id}')
        QMessageBox.information(self, 'تم', f'تم إنشاء كشف الحساب PDF:\n{path}')

    def print_statement(self):
        if not self.customer_id: QMessageBox.warning(self, 'تنبيه', 'اختر الزبون أولاً'); return
        if StatementPreviewDialog(self.service, self.customer_id, self).exec() != QDialog.Accepted:
            return
        try:
            path = self.service.print_customer_statement_html(self.customer_id)
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر إنشاء كشف الحساب', str(exc)); return
        QMessageBox.information(self, 'تم', f'تم إنشاء كشف الحساب:\n{path}')
