from ui.ui_common import *

class ProductsPage(QWidget):
    def __init__(self, service: AppService, notify, current_user=None):
        super().__init__()
        self.service = service
        self.notify = notify
        self.current_user = current_user
        self.cart: list[dict] = []
        self.product_rows = []
        self.build()
        self.refresh_all()

    def build(self):
        root = QHBoxLayout(self)
        root.setSpacing(16)
        root.setContentsMargins(6, 6, 6, 6)

        left = QFrame()
        left.setObjectName('surface')
        left_l = QVBoxLayout(left)
        left_l.setSpacing(10)
        products_title = QLabel('📦 قائمة المنتجات')
        products_title.setObjectName('sectionTitle')
        self.search = QLineEdit()
        self.search.setPlaceholderText('بحث عن منتج بالاسم أو الباركود أو الصنف...')
        self.search.textChanged.connect(self.refresh)
        self.table = Table(['الباركود', 'المنتج', 'الصنف', 'شراء', 'بيع', 'كمية', 'تنبيه', 'عمولة'])
        self.table.doubleClicked.connect(self.load_selected)
        left_l.addWidget(products_title)
        left_l.addWidget(self.search)
        left_l.addWidget(self.table, 1)

        # الجهة اليمنى أصبحت داخل ScrollArea حتى لا تتداخل الحقول على الشاشات الصغيرة.
        right_scroll = QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_scroll.setFrameShape(QFrame.NoFrame)
        right_scroll.setObjectName('cleanScroll')
        right_scroll.setMinimumWidth(560)
        right_scroll.setMaximumWidth(720)

        right = QFrame()
        right.setObjectName('surface')
        form_l = QVBoxLayout(right)
        form_l.setContentsMargins(18, 16, 18, 16)
        form_l.setSpacing(14)

        product_form_title = QLabel('🧾 بيانات المنتج')
        product_form_title.setObjectName('sectionTitle')
        hint = QLabel('لإضافة منتج بالباركود: ضع المؤشر في خانة الباركود ثم امسح الكود بجهاز الباركود. إذا كان المنتج موجودًا ستظهر بياناته، وإذا كان جديدًا سيحاول النظام جلب الاسم والصنف إن توفر، ثم أكمل السعر والكمية واضغط حفظ.')
        hint.setObjectName('noticeBox')
        hint.setWordWrap(True)

        self.barcode = QLineEdit()
        self.barcode.setPlaceholderText('امسح باركود المنتج هنا ثم اضغط Enter...')
        self.barcode.returnPressed.connect(self.handle_product_barcode_scan)
        self.name = QLineEdit()
        self.name.setPlaceholderText('مثال: حليب كامل الدسم 1 لتر')
        self.category = QLineEdit()
        self.category.setPlaceholderText('مثال: مواد غذائية / مشروبات')

        self.cost = QDoubleSpinBox(); self.cost.setMaximum(999999999); self.cost.setDecimals(0); self.cost.setButtonSymbols(QSpinBox.NoButtons)
        self.price = QDoubleSpinBox(); self.price.setMaximum(999999999); self.price.setDecimals(0); self.price.setButtonSymbols(QSpinBox.NoButtons)
        self.qty = QSpinBox(); self.qty.setMaximum(9999999); self.qty.setButtonSymbols(QSpinBox.NoButtons)
        self.min_qty = QSpinBox(); self.min_qty.setMaximum(9999999); self.min_qty.setValue(5); self.min_qty.setButtonSymbols(QSpinBox.NoButtons)
        self.comm = QDoubleSpinBox(); self.comm.setRange(0, 100); self.comm.setDecimals(2); self.comm.setSuffix(' %'); self.comm.setButtonSymbols(QSpinBox.NoButtons)

        for w in (self.barcode, self.name, self.category, self.cost, self.price, self.qty, self.min_qty, self.comm):
            w.setMinimumHeight(42)

        # قسم بيانات التعريف - ترتيب عمودي واضح بدون ضغط أو تداخل.
        identity = QFrame(); identity.setObjectName('innerCard')
        identity_l = QVBoxLayout(identity); identity_l.setContentsMargins(14, 14, 14, 14); identity_l.setSpacing(10)
        identity_title = QLabel('بيانات التعريف')
        identity_title.setObjectName('smallSectionTitle')
        identity_l.addWidget(identity_title)
        identity_form = QFormLayout()
        identity_form.setLabelAlignment(Qt.AlignRight)
        identity_form.setFormAlignment(Qt.AlignRight)
        identity_form.setHorizontalSpacing(18)
        identity_form.setVerticalSpacing(14)
        identity_form.addRow('الباركود', self.barcode)
        identity_form.addRow('اسم المنتج', self.name)
        identity_form.addRow('الصنف', self.category)
        identity_l.addLayout(identity_form)

        # قسم الأسعار والمخزون - عمودان واضحان مع مسافات ثابتة.
        numbers = QFrame(); numbers.setObjectName('innerCard')
        numbers_l = QVBoxLayout(numbers); numbers_l.setContentsMargins(14, 14, 14, 14); numbers_l.setSpacing(10)
        numbers_title = QLabel('الأسعار والمخزون')
        numbers_title.setObjectName('smallSectionTitle')
        numbers_l.addWidget(numbers_title)
        numbers_grid = QGridLayout(); numbers_grid.setHorizontalSpacing(16); numbers_grid.setVerticalSpacing(14)
        price_fields = [
            ('سعر الشراء', self.cost, 0, 1),
            ('سعر البيع', self.price, 0, 0),
            ('الكمية الحالية', self.qty, 1, 1),
            ('حد التنبيه', self.min_qty, 1, 0),
            ('نسبة عمولة الموظف', self.comm, 2, 0),
        ]
        for label_text, widget, row, col in price_fields:
            label = QLabel(label_text); label.setObjectName('formLabel')
            numbers_grid.addWidget(label, row * 2, col)
            numbers_grid.addWidget(widget, row * 2 + 1, col)
        numbers_grid.setColumnStretch(0, 1)
        numbers_grid.setColumnStretch(1, 1)
        numbers_l.addLayout(numbers_grid)

        # الأزرار - مرتبة على 3 صفوف ولا تضغط الحقول.
        actions = QFrame(); actions.setObjectName('innerCard')
        actions_l = QVBoxLayout(actions); actions_l.setContentsMargins(14, 14, 14, 14); actions_l.setSpacing(10)
        actions_title = QLabel('عمليات المنتج')
        actions_title.setObjectName('smallSectionTitle')
        actions_l.addWidget(actions_title)
        save = QPushButton('💾 حفظ المنتج')
        save.setObjectName('primaryButton')
        save.clicked.connect(self.save)
        clear = QPushButton('➕ منتج جديد')
        clear.clicked.connect(self.clear)
        delete = QPushButton('🗑 تعطيل المنتج')
        delete.setObjectName('dangerButton')
        delete.clicked.connect(self.deactivate)
        barcode_btn = QPushButton('🏷 توليد باركود')
        barcode_btn.clicked.connect(self.generate_barcode)
        labels_btn = QPushButton('🖨 طباعة ملصقات باركود')
        labels_btn.clicked.connect(self.print_labels)
        buttons_grid = QGridLayout(); buttons_grid.setSpacing(10)
        buttons_grid.addWidget(save, 0, 0); buttons_grid.addWidget(clear, 0, 1)
        buttons_grid.addWidget(barcode_btn, 1, 0); buttons_grid.addWidget(labels_btn, 1, 1)
        buttons_grid.addWidget(delete, 2, 0, 1, 2)
        actions_l.addLayout(buttons_grid)

        inventory = QFrame(); inventory.setObjectName('innerCard')
        inventory_l = QVBoxLayout(inventory); inventory_l.setContentsMargins(14, 14, 14, 14); inventory_l.setSpacing(10)
        inventory_title = QLabel('جرد / تعديل المخزون')
        inventory_title.setObjectName('smallSectionTitle')
        self.adjust_qty = QSpinBox(); self.adjust_qty.setMaximum(9999999); self.adjust_qty.setButtonSymbols(QSpinBox.NoButtons); self.adjust_qty.setMinimumHeight(42)
        self.adjust_note = QLineEdit(); self.adjust_note.setPlaceholderText('سبب التعديل / الجرد'); self.adjust_note.setMinimumHeight(42)
        adjust_btn = QPushButton('⚠ تعديل كمية المخزون')
        adjust_btn.setObjectName('warningButton')
        adjust_btn.clicked.connect(self.adjust_inventory)
        inventory_form = QFormLayout(); inventory_form.setLabelAlignment(Qt.AlignRight); inventory_form.setHorizontalSpacing(18); inventory_form.setVerticalSpacing(14)
        inventory_form.addRow('الكمية الجديدة', self.adjust_qty)
        inventory_form.addRow('ملاحظة', self.adjust_note)
        inventory_l.addWidget(inventory_title); inventory_l.addLayout(inventory_form); inventory_l.addWidget(adjust_btn)

        form_l.addWidget(product_form_title)
        form_l.addWidget(hint)
        form_l.addWidget(identity)
        form_l.addWidget(numbers)
        form_l.addWidget(actions)
        form_l.addWidget(inventory)
        form_l.addStretch()
        right_scroll.setWidget(right)

        root.addWidget(left, 1)
        root.addWidget(right_scroll)

    def handle_product_barcode_scan(self):
        code = self.barcode.text().strip()
        if not code:
            return
        p = self.service.get_product_by_barcode(code)
        if p:
            self.product_id = p['id']
            self.name.setText(p['name'])
            self.category.setText(p['category'] or '')
            self.cost.setValue(float(p['cost_price']))
            self.price.setValue(float(p['sale_price']))
            self.qty.setValue(int(p['quantity']))
            self.adjust_qty.setValue(int(p['quantity']))
            self.min_qty.setValue(int(p['min_quantity']))
            self.comm.setValue(float(p['commission_percent']))
            self.notify('تم العثور على المنتج وملء بياناته تلقائياً')
            return

        # Barcode is new: try online lookup for product name/category.
        try:
            info = self.service.lookup_barcode_online(code)
        except Exception:
            info = None
        self.product_id = None
        if info:
            self.name.setText(info.get('name', ''))
            self.category.setText(info.get('category', ''))
            self.name.setFocus()
            self.notify('تم جلب اسم المنتج من الباركود. أكمل السعر والكمية ثم اضغط حفظ')
        else:
            self.name.setFocus()
            self.notify('باركود جديد: لم تتوفر معلومات تلقائية، أكمل بيانات المادة ثم اضغط حفظ')

    def refresh_all(self):
        # تحديث قائمة المنتجات وتهيئة الحقول بدون كسر تشغيل الصفحة.
        self.refresh()
        if not hasattr(self, 'product_id'):
            self.product_id = None

    def refresh(self):
        self.rows = self.service.list_products(self.search.text())
        self.table.setRowCount(len(self.rows))
        for r, p in enumerate(self.rows):
            values = [p['barcode'] or '', p['name'], p['category'] or '', money(p['cost_price']), money(p['sale_price']), p['quantity'], p['min_quantity'], f"{p['commission_percent']}%"]
            for c, v in enumerate(values):
                self.table.put(r, c, v, p['id'] if c == 0 else None)

    def load_selected(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.rows):
            return
        p = self.rows[row]
        self.product_id = p['id']
        self.barcode.setText(p['barcode'] or '')
        self.name.setText(p['name'])
        self.category.setText(p['category'] or '')
        self.cost.setValue(float(p['cost_price']))
        self.price.setValue(float(p['sale_price']))
        self.qty.setValue(int(p['quantity']))
        self.adjust_qty.setValue(int(p['quantity']))
        self.min_qty.setValue(int(p['min_quantity']))
        self.comm.setValue(float(p['commission_percent']))

    def clear(self):
        self.product_id = None
        for w in (self.barcode, self.name, self.category):
            w.clear()
        self.cost.setValue(0)
        self.price.setValue(0)
        self.qty.setValue(0)
        self.adjust_qty.setValue(0)
        self.min_qty.setValue(5)
        self.comm.setValue(0)
        self.barcode.setFocus()

    def save(self):
        try:
            self.service.save_product({'barcode': self.barcode.text(), 'name': self.name.text(), 'category': self.category.text(), 'cost_price': self.cost.value(), 'sale_price': self.price.value(), 'quantity': self.qty.value(), 'min_quantity': self.min_qty.value(), 'commission_percent': self.comm.value()}, self.product_id)
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر الحفظ', str(exc))
            return
        self.clear()
        self.refresh()
        self.notify('تم حفظ المنتج')

    def generate_barcode(self):
        if not self.product_id:
            QMessageBox.warning(self, 'تنبيه', 'اختر منتجاً أولاً')
            return
        try:
            code = self.service.generate_barcode_value(self.product_id)
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر التوليد', str(exc))
            return
        self.barcode.setText(code)
        self.refresh()
        self.notify('تم توليد الباركود')

    def print_labels(self):
        try:
            path = self.service.print_barcode_labels_html()
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر الطباعة', str(exc))
            return
        QMessageBox.information(self, 'تم', f'تم إنشاء ملف الملصقات:\n{path}')

    def adjust_inventory(self):
        if not self.product_id:
            QMessageBox.warning(self, 'تنبيه', 'اختر منتجاً أولاً')
            return
        try:
            self.service.adjust_inventory(self.product_id, self.adjust_qty.value(), self.adjust_note.text())
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر التعديل', str(exc))
            return
        self.refresh()
        self.notify('تم تعديل المخزون')

    def deactivate(self):
        if not self.product_id:
            return
        if QMessageBox.question(self, 'تأكيد', 'تعطيل هذا المنتج؟') == QMessageBox.Yes:
            self.service.deactivate_product(self.product_id)
            self.clear()
            self.refresh()
            self.notify('تم تعطيل المنتج')
