from ui.ui_common import *

class ReportsPage(QWidget):
    def __init__(self, service: AppService, notify=None):
        super().__init__(); self.service = service; self.notify = notify
        layout = QVBoxLayout(self)
        title = QLabel('📊 التقارير الإدارية المتقدمة'); title.setObjectName('sectionTitle')
        self.tabs = QTabWidget(); layout.addWidget(title); layout.addWidget(self.tabs, 1)
        sales_tab = QWidget(); sl = QVBoxLayout(sales_tab); actions = QHBoxLayout()
        pdf_all = QPushButton('📄 تقرير الفواتير PDF'); pdf_all.setObjectName('primaryButton'); pdf_all.clicked.connect(self.export_sales_pdf)
        pdf_invoice = QPushButton('🧾 الفاتورة المحددة PDF'); pdf_invoice.setObjectName('primaryButton'); pdf_invoice.clicked.connect(self.export_selected_invoice_pdf)
        actions.addWidget(pdf_all); actions.addWidget(pdf_invoice); actions.addStretch(); sl.addLayout(actions)
        self.table = Table(['الفاتورة', 'التاريخ', 'المستخدم', 'موظف العمولة', 'الزبون', 'الدفع', 'الصافي', 'الربح', 'عمولة الموظف'])
        self.table.cellClicked.connect(self.copy_invoice_no); sl.addWidget(self.table, 1); self.tabs.addTab(sales_tab, 'الفواتير')
        adv = QWidget(); al=QVBoxLayout(adv); top=QHBoxLayout(); self.report_kind=QComboBox(); self.report_kind.addItems(['مبيعات يومية','مبيعات شهرية','أرباح','منتجات راكدة','الأكثر مبيعاً','أفضل موظف','الديون المتأخرة','المرتجعات حسب السبب','حركة المخزون']); run=QPushButton('عرض التقرير'); run.setObjectName('primaryButton'); run.clicked.connect(self.refresh_advanced); pdf=QPushButton('PDF للتقرير الحالي'); pdf.setObjectName('primaryButton'); pdf.clicked.connect(self.export_advanced_pdf); top.addWidget(self.report_kind); top.addWidget(run); top.addWidget(pdf); top.addStretch(); self.advanced_table=Table(['البند','القيمة 1','القيمة 2','القيمة 3','القيمة 4']); al.addLayout(top); al.addWidget(self.advanced_table,1); self.tabs.addTab(adv,'تقارير إدارية')

    def copy_invoice_no(self, row: int, col: int):
        if col != 0:
            return
        item = self.table.item(row, 0)
        if not item:
            return
        QApplication.clipboard().setText(item.text())
        if self.notify:
            self.notify(f'تم نسخ رقم الفاتورة: {item.text()}')


    def export_sales_pdf(self):
        rows = self.service.list_sales()
        data = [[s['invoice_no'], s['created_at'], s['user_name'], s['employee'], s['customer'], s['payment_method'], money(s['total']), money(s['total_profit']), money(s['total_commission'])] for s in rows]
        path = rows_to_pdf('تقرير الفواتير والمبيعات', ['الفاتورة','التاريخ','المستخدم','موظف العمولة','الزبون','الدفع','الصافي','الربح','العمولة'], data, 'sales_report')
        QMessageBox.information(self, 'تم', f'تم إنشاء تقرير PDF:\n{path}')

    def export_selected_invoice_pdf(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, 'تنبيه', 'اختر فاتورة أولاً')
            return
        invoice = self.table.item(row, 0).text()
        try:
            sale, items = self.service.invoice_details(invoice)
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر إنشاء PDF', str(exc)); return
        data = [[i['product_name'], i['quantity'], money(i['unit_price']), money(i['line_total'])] for i in items]
        path = rows_to_pdf(f'فاتورة بيع {invoice}', ['المادة','الكمية','السعر','الإجمالي'], data + [['', '', 'الصافي', money(sale['total'])]], 'invoice_'+invoice)
        QMessageBox.information(self, 'تم', f'تم إنشاء PDF الفاتورة:\n{path}')

    def refresh_advanced(self):
        mapping={'مبيعات يومية':'daily_sales','مبيعات شهرية':'monthly_sales','أرباح':'monthly_sales','منتجات راكدة':'stale_products','الأكثر مبيعاً':'top_products','أفضل موظف':'best_employees','الديون المتأخرة':'overdue_debts','المرتجعات حسب السبب':'returns_reason','حركة المخزون':'inventory_movements'}
        key=mapping.get(self.report_kind.currentText(),'daily_sales'); rows=self.service.management_report(key)
        self.advanced_table.setRowCount(len(rows))
        for r,x in enumerate(rows):
            vals=list(dict(x).values())[:5]
            while len(vals)<5: vals.append('')
            for c,v in enumerate(vals): self.advanced_table.put(r,c,money(v) if isinstance(v,float) else v)
    def export_advanced_pdf(self):
        self.refresh_advanced(); data=[]
        for r in range(self.advanced_table.rowCount()): data.append([self.advanced_table.item(r,c).text() if self.advanced_table.item(r,c) else '' for c in range(self.advanced_table.columnCount())])
        path=rows_to_pdf(self.report_kind.currentText(), ['البند','القيمة 1','القيمة 2','القيمة 3','القيمة 4'], data, 'advanced_report'); QMessageBox.information(self,'تم',f'تم إنشاء PDF:\n{path}')

    def refresh(self):
        rows = self.service.list_sales(); self.table.setRowCount(len(rows))
        for r, s in enumerate(rows):
            vals = [s['invoice_no'], s['created_at'], s['user_name'], s['employee'], s['customer'], s['payment_method'], money(s['total']), money(s['total_profit']), money(s['total_commission'])]
            for c, v in enumerate(vals): self.table.put(r, c, v)
