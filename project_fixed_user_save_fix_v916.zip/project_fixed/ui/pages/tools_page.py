from ui.ui_common import *

class ToolsPage(QWidget):
    def __init__(self, service: AppService, notify, current_user=None):
        super().__init__(); self.service = service; self.notify = notify; self.current_user = current_user
        root = QVBoxLayout(self)
        title = QLabel('⚙ الأدوات والإدارة المتقدمة')
        title.setObjectName('sectionTitle')
        root.addWidget(title)
        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 1)
        self.build_settings_tab(); self.build_logs_tab(); self.build_audit_tab(); self.build_inventory_tab(); self.build_inventory_count_tab(); self.build_branches_tab(); self.build_commission_tab(); self.build_goals_tab(); self.build_suspended_tab(); self.build_backup_tab()

    def build_settings_tab(self):
        tab = QWidget(); layout = QVBoxLayout(tab); form = QFormLayout()
        self.company_name = QLineEdit(); self.company_phone = QLineEdit(); self.company_address = QLineEdit()
        self.currency = QLineEdit(); self.tax = QLineEdit(); self.footer = QLineEdit()
        self.printer_name = QComboBox()
        self.printer_name.setEditable(False)
        self.printer_name.setPlaceholderText('اضغط لاختيار طابعة من الطابعات النشطة')
        self.refresh_printers_btn = QPushButton('عرض الطابعات النشطة')
        self.refresh_printers_btn.clicked.connect(self.show_printer_list)
        printer_row = QHBoxLayout(); printer_row.addWidget(self.printer_name, 1); printer_row.addWidget(self.refresh_printers_btn)
        for label, w in [('اسم المحل', self.company_name), ('الهاتف', self.company_phone), ('العنوان', self.company_address), ('العملة', self.currency), ('الضريبة %', self.tax), ('نص أسفل الفاتورة', self.footer)]:
            w.setMinimumWidth(250)
            form.addRow(label, w)
        form.addRow('الطابعة الافتراضية', printer_row)
        save = QPushButton('حفظ إعدادات الشركة والطابعة'); save.setObjectName('primaryButton'); save.clicked.connect(self.save_settings)
        note = QLabel('اختيار الطابعة يُحفظ داخل النظام لاستخدامه في الطباعة والتقارير. إذا لم تظهر الطابعة اضغط تحديث قائمة الطابعات.')
        note.setObjectName('noticeBox'); note.setWordWrap(True)
        layout.addLayout(form); layout.addWidget(note); layout.addWidget(save); layout.addStretch(); self.tabs.addTab(tab, 'إعدادات الشركة')
        self.load_printers()
        self.load_settings()

    def show_printer_list(self):
        self.load_printers()
        self.printer_name.showPopup()

    def load_printers(self):
        current = self.printer_name.currentText() if hasattr(self, 'printer_name') else ''
        self.printer_name.clear()
        printers = []
        if QPrinterInfo is not None:
            try:
                printers = [p.printerName() for p in QPrinterInfo.availablePrinters()]
                default = QPrinterInfo.defaultPrinter()
                if default and default.printerName() and default.printerName() not in printers:
                    printers.insert(0, default.printerName())
            except Exception:
                printers = []
        if not printers:
            printers = ['الطابعة الافتراضية في Windows']
        self.printer_name.addItems(printers)
        if current:
            idx = self.printer_name.findText(current)
            if idx >= 0:
                self.printer_name.setCurrentIndex(idx)
            else:
                self.printer_name.addItem(current)
                self.printer_name.setCurrentText(current)

    def load_settings(self):
        st = self.service.get_settings()
        self.company_name.setText(st.get('company_name','')); self.company_phone.setText(st.get('company_phone','')); self.company_address.setText(st.get('company_address',''))
        self.currency.setText(st.get('currency','د.ع')); self.tax.setText(st.get('tax_percent','0')); self.footer.setText(st.get('invoice_footer',''))
        saved_printer = st.get('printer_name','')
        if saved_printer:
            idx = self.printer_name.findText(saved_printer)
            if idx >= 0:
                self.printer_name.setCurrentIndex(idx)
            else:
                self.printer_name.addItem(saved_printer)
                self.printer_name.setCurrentText(saved_printer)

    def save_settings(self):
        self.service.save_settings({'company_name': self.company_name.text(), 'company_phone': self.company_phone.text(), 'company_address': self.company_address.text(), 'currency': self.currency.text(), 'tax_percent': self.tax.text(), 'invoice_footer': self.footer.text(), 'printer_name': self.printer_name.currentText()})
        self.notify('تم حفظ إعدادات الشركة والطابعة')

    def build_logs_tab(self):
        tab = QWidget(); layout = QVBoxLayout(tab); self.logs_table = Table(['الوقت', 'المستخدم', 'العملية', 'التفاصيل']); layout.addWidget(self.logs_table, 1); self.tabs.addTab(tab, 'سجل العمليات')

    def build_inventory_tab(self):
        tab = QWidget(); layout = QVBoxLayout(tab); self.inv_table = Table(['الوقت', 'المنتج', 'النوع', 'التغيير', 'قبل', 'بعد', 'المرجع', 'ملاحظة']); layout.addWidget(self.inv_table, 1); self.tabs.addTab(tab, 'حركة المخزون')


    def build_inventory_count_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(24, 24, 24, 24)
        box = QFrame(); box.setObjectName('surface')
        box_l = QVBoxLayout(box)
        title = QLabel('🚧 الجرد المتقدم - قيد التطوير')
        title.setObjectName('sectionTitle')
        msg = QLabel('''تم تعطيل هذه الخاصية مؤقتًا لحين إعادة بناء نظام الجرد بشكل أدق، حتى لا تؤثر أي عملية جرد غير مكتملة على كميات المخزون أو الحسابات.

سيتم تطويرها لاحقًا لدعم: فرق الجرد، التالف، اعتماد الجرد بصلاحية مدير، وربط الكمية بكل مخزن وفرع.''')
        msg.setObjectName('noticeBox')
        msg.setWordWrap(True)
        layout.addStretch(1)
        box_l.addWidget(title)
        box_l.addWidget(msg)
        box_l.addStretch(1)
        layout.addWidget(box)
        layout.addStretch(1)
        self.tabs.addTab(tab, 'جرد متقدم')

    def build_branches_tab(self):
        tab = QWidget(); layout = QVBoxLayout(tab)
        top_layouts = QVBoxLayout()
        top_layouts.setSpacing(16)

        b_card = QFrame(); b_card.setObjectName('surface')
        branch_form = QFormLayout(b_card)
        self.branch_name = QLineEdit(); self.branch_name.setPlaceholderText('اسم الفرع'); self.branch_name.setMinimumWidth(200)
        self.branch_addr = QLineEdit(); self.branch_addr.setPlaceholderText('العنوان')
        self.branch_phone = QLineEdit(); self.branch_phone.setPlaceholderText('الهاتف')
        save_b = QPushButton('حفظ فرع'); save_b.setObjectName('primaryButton'); save_b.clicked.connect(self.save_branch)
        branch_form.addRow('اسم الفرع', self.branch_name)
        branch_form.addRow('العنوان', self.branch_addr)
        branch_form.addRow('الهاتف', self.branch_phone)
        branch_form.addRow('', save_b)

        w_card = QFrame(); w_card.setObjectName('surface')
        wh_form = QFormLayout(w_card)
        self.wh_name = QLineEdit(); self.wh_name.setPlaceholderText('اسم المخزن'); self.wh_name.setMinimumWidth(200)
        self.wh_branch = QComboBox()
        self.wh_addr = QLineEdit(); self.wh_addr.setPlaceholderText('عنوان المخزن')
        save_w = QPushButton('حفظ مخزن'); save_w.setObjectName('primaryButton'); save_w.clicked.connect(self.save_warehouse)
        wh_form.addRow('اسم المخزن', self.wh_name)
        wh_form.addRow('الفرع', self.wh_branch)
        wh_form.addRow('العنوان', self.wh_addr)
        wh_form.addRow('', save_w)

        top_layouts.addWidget(b_card)
        top_layouts.addWidget(w_card)

        self.branch_table = Table(['الفروع / المخازن','الفرع','العنوان'])
        layout.addLayout(top_layouts)
        layout.addWidget(self.branch_table, 1)
        self.tabs.addTab(tab, 'الفروع والمخازن')

    def save_branch(self):
        try: self.service.save_branch(self.branch_name.text(), self.branch_addr.text(), self.branch_phone.text())
        except Exception as exc: QMessageBox.warning(self, 'تعذر الحفظ', str(exc)); return
        self.branch_name.clear(); self.branch_addr.clear(); self.branch_phone.clear(); self.refresh(); self.notify('تم حفظ الفرع')

    def save_warehouse(self):
        try: self.service.save_warehouse(self.wh_name.text(), self.wh_branch.currentData(), self.wh_addr.text())
        except Exception as exc: QMessageBox.warning(self, 'تعذر الحفظ', str(exc)); return
        self.wh_name.clear(); self.wh_addr.clear(); self.refresh(); self.notify('تم حفظ المخزن')

    def save_inventory_count(self):
        if self.count_product.currentData() is None:
            QMessageBox.warning(self, 'تنبيه', 'لا يوجد منتج محدد'); return
        try:
            self.service.record_inventory_count(self.count_product.currentData(), self.count_qty.value(), self.damage_qty.value(), self.count_branch.currentData(), self.count_warehouse.currentData(), self.count_note.text())
        except Exception as exc: QMessageBox.warning(self, 'تعذر الجرد', str(exc)); return
        self.count_note.clear(); self.refresh(); self.notify('تم حفظ الجرد وتحديث المخزون')

    def build_commission_tab(self):
        tab = QWidget(); layout = QVBoxLayout(tab)
        pdf = QPushButton('📄 تقرير العمولات PDF'); pdf.setObjectName('primaryButton'); pdf.clicked.connect(self.export_commission_pdf)
        self.comm_table = Table(['الموظف', 'المبيعات', 'العمولة', 'عمولة مرتجعة', 'صافي العمولة'])
        layout.addWidget(pdf); layout.addWidget(self.comm_table, 1); self.tabs.addTab(tab, 'عمولات الموظفين')

    def export_commission_pdf(self):
        reps = self.service.commission_report(); data=[]
        for row in reps:
            net = float(row['commission'] or 0) - float(row['returned_commission'] or 0)
            data.append([row['employee'], money(row['sales']), money(row['commission']), money(row['returned_commission']), money(net)])
        path = rows_to_pdf('تقرير عمولات الموظفين', ['الموظف','المبيعات','العمولة','عمولة مرتجعة','صافي العمولة'], data, 'commission_report')
        QMessageBox.information(self, 'تم', f'تم إنشاء تقرير العمولات PDF:\n{path}')

    def build_audit_tab(self):
        tab=QWidget(); layout=QVBoxLayout(tab); self.audit_table=Table(['الوقت','المستخدم','العملية','التفاصيل']); layout.addWidget(self.audit_table,1); self.tabs.addTab(tab,'سجل التدقيق')

    def build_goals_tab(self):
        tab = QWidget()
        main = QVBoxLayout(tab)
        main.setContentsMargins(8, 8, 8, 8)
        main.setSpacing(10)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setObjectName('pageScroll')
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(14)

        header = QLabel('🏆 نظام الأهداف والمكافآت الاحترافي')
        header.setObjectName('sectionTitle')
        note = QLabel('نظام مختصر للأهداف: إذا كان الهدف مبلغاً يظهر بالدينار، وإذا كان الهدف قطعاً أو فواتير يظهر بالعدد تلقائياً. يظهر الهدف في الرئيسية كشريط تحفيزي للموظفين.')
        note.setObjectName('noticeBox')
        note.setWordWrap(True)
        layout.addWidget(header)
        layout.addWidget(note)

        cards = QGridLayout()
        cards.setSpacing(10)
        self.goals_total_card = MetricCard('عدد الأهداف النشطة', '0', 'primary')
        self.goals_done_card = MetricCard('أهداف مكتملة', '0', 'success')
        self.goals_bonus_card = MetricCard('مكافآت مستحقة', '0', 'warning')
        cards.addWidget(self.goals_total_card, 0, 0)
        cards.addWidget(self.goals_done_card, 0, 1)
        cards.addWidget(self.goals_bonus_card, 0, 2)
        layout.addLayout(cards)

        form_card = QFrame()
        form_card.setObjectName('surface')
        fl = QVBoxLayout(form_card)
        fl.setContentsMargins(16, 16, 16, 16)
        fl.setSpacing(12)
        ftitle = QLabel('إضافة هدف جديد')
        ftitle.setObjectName('miniTitle')
        fl.addWidget(ftitle)

        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(10)

        def add_field(row, col, label, widget):
            lab = QLabel(label)
            lab.setObjectName('formLabel')
            lab.setMinimumWidth(110)
            widget.setMinimumHeight(40)
            widget.setMinimumWidth(180)
            grid.addWidget(lab, row, col * 2, Qt.AlignRight)
            grid.addWidget(widget, row, col * 2 + 1)
            return lab

        self.goal_employee = QComboBox()
        self.goal_period = QComboBox(); self.goal_period.addItems(['يومي', 'أسبوعي', 'شهري', 'ربع سنوي', 'سنوي'])
        self.goal_type = QComboBox(); self.goal_type.addItems(['مبيعات', 'أرباح', 'عدد فواتير', 'عدد منتجات مباعة', 'تحصيل ديون', 'بيع منتج معين', 'تقليل المرتجعات'])
        self.goal_reward_type = QComboBox(); self.goal_reward_type.addItems(['مبلغ ثابت', 'نسبة من المبيعات', 'نسبة من الأرباح', 'مكافأة متدرجة'])
        self.goal_product = QComboBox()
        self.goal_scope = QComboBox(); self.goal_scope.addItems(['موظف', 'فريق / فرع'])
        self.goal_bonus_120 = QDoubleSpinBox(); self.goal_bonus_120.setMaximum(999999999); self.goal_bonus_120.setDecimals(0); self.goal_bonus_120.setPrefix('120% د.ع ')
        self.goal_bonus_150 = QDoubleSpinBox(); self.goal_bonus_150.setMaximum(999999999); self.goal_bonus_150.setDecimals(0); self.goal_bonus_150.setPrefix('150% د.ع ')
        self.goal_reward_rate = QDoubleSpinBox(); self.goal_reward_rate.setMaximum(100); self.goal_reward_rate.setDecimals(2); self.goal_reward_rate.setSuffix(' %')
        self.goal_start = QLineEdit(); self.goal_start.setPlaceholderText('يومي: 2026-04-30 / شهري: 2026-04')
        self.goal_target = QDoubleSpinBox(); self.goal_target.setMaximum(999999999); self.goal_target.setDecimals(0); self.goal_target.setPrefix('د.ع ')
        self.goal_bonus = QDoubleSpinBox(); self.goal_bonus.setMaximum(999999999); self.goal_bonus.setDecimals(0); self.goal_bonus.setPrefix('د.ع ')
        self.goal_note = QLineEdit(); self.goal_note.setPlaceholderText('ملاحظة اختيارية مثل: هدف رمضان / هدف الفرع')
        self.goal_type.currentTextChanged.connect(self.update_goal_target_mode)

        add_field(0, 0, 'الموظف', self.goal_employee)
        add_field(0, 1, 'نوع الهدف', self.goal_type)
        self.goal_target_label = add_field(1, 0, 'هدف المبلغ', self.goal_target)
        add_field(1, 1, 'الفترة', self.goal_period)
        add_field(2, 0, 'بداية الفترة', self.goal_start)
        add_field(2, 1, 'منتج محدد', self.goal_product)
        add_field(3, 0, 'نوع المكافأة', self.goal_reward_type)
        add_field(3, 1, 'مكافأة 100%', self.goal_bonus)
        add_field(4, 0, 'نسبة المكافأة', self.goal_reward_rate)
        add_field(4, 1, 'مكافأة 120%', self.goal_bonus_120)
        add_field(5, 0, 'مكافأة 150%', self.goal_bonus_150)
        add_field(5, 1, 'النطاق', self.goal_scope)
        note_label = QLabel('ملاحظة')
        note_label.setObjectName('formLabel')
        grid.addWidget(note_label, 6, 0, Qt.AlignRight)
        grid.addWidget(self.goal_note, 6, 1, 1, 3)
        grid.setColumnStretch(1, 1)
        grid.setColumnStretch(3, 1)
        fl.addLayout(grid)

        btns = QGridLayout()
        btns.setSpacing(8)
        save = QPushButton('💾 حفظ الهدف'); save.setObjectName('successButton'); save.clicked.connect(self.save_goal)
        delete = QPushButton('⛔ تعطيل الهدف المحدد'); delete.setObjectName('dangerButton'); delete.clicked.connect(self.delete_goal)
        clear = QPushButton('مسح الحقول'); clear.clicked.connect(self.clear_goal_form)
        today = QPushButton('تاريخ اليوم'); today.clicked.connect(self.set_goal_today)
        month = QPushButton('الشهر الحالي'); month.clicked.connect(self.set_goal_month)
        export = QPushButton('📄 تقرير أهداف PDF'); export.setObjectName('primaryButton'); export.clicked.connect(self.export_goals_pdf)
        btns.addWidget(save, 0, 0, 1, 2)
        btns.addWidget(today, 0, 2)
        btns.addWidget(month, 0, 3)
        btns.addWidget(clear, 1, 0, 1, 2)
        btns.addWidget(export, 1, 2, 1, 2)
        fl.addLayout(btns)
        layout.addWidget(form_card)

        table_card = QFrame()
        table_card.setObjectName('surface')
        tl = QVBoxLayout(table_card)
        tl.setContentsMargins(12, 12, 12, 12)
        ttitle = QLabel('متابعة الأهداف')
        ttitle.setObjectName('miniTitle')
        self.selected_goal_id = None
        self.goals_table = Table(['الموظف','نوع الهدف','الفترة','الهدف','المحقق','التقدم','المتبقي','المكافأة','الحالة'])
        self.goals_table.setMinimumHeight(320)
        self.goals_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.goals_table.horizontalHeader().setSectionResizeMode(8, QHeaderView.Stretch)
        self.goals_table.itemSelectionChanged.connect(self.on_goal_selected)
        tl.addWidget(ttitle)
        tl.addWidget(self.goals_table, 1)
        layout.addWidget(table_card, 1)

        scroll.setWidget(page)
        main.addWidget(scroll, 1)
        self.tabs.addTab(tab, 'أهداف الموظفين')
        self.update_goal_target_mode()

    def update_goal_target_mode(self):
        goal_type = self.goal_type.currentText() if hasattr(self, 'goal_type') else 'مبيعات'
        if not hasattr(self, 'goal_target'):
            return
        self.goal_target.setPrefix('')
        self.goal_target.setSuffix('')
        if is_count_goal(goal_type):
            self.goal_target.setDecimals(0)
            self.goal_target.setSingleStep(1)
            self.goal_target.setSuffix(' ' + goal_value_unit(goal_type))
            if hasattr(self, 'goal_target_label'):
                self.goal_target_label.setText('هدف العدد')
        else:
            self.goal_target.setDecimals(0)
            self.goal_target.setSingleStep(1000)
            self.goal_target.setPrefix('د.ع ')
            if hasattr(self, 'goal_target_label'):
                self.goal_target_label.setText('هدف المبلغ')
        if hasattr(self, 'goal_product'):
            self.goal_product.setEnabled(goal_type == 'بيع منتج معين')

    def set_goal_today(self):
        from datetime import date
        self.goal_start.setText(date.today().isoformat())
        self.goal_period.setCurrentText('يومي')

    def set_goal_month(self):
        from datetime import date
        self.goal_start.setText(date.today().strftime('%Y-%m'))
        self.goal_period.setCurrentText('شهري')

    def clear_goal_form(self):
        self.goal_start.clear(); self.goal_target.setValue(0); self.goal_bonus.setValue(0); self.goal_bonus_120.setValue(0); self.goal_bonus_150.setValue(0); self.goal_reward_rate.setValue(0); self.goal_note.clear()

    def save_goal(self):
        try:
            self.service.save_employee_goal(self.goal_employee.currentData(), self.goal_period.currentText(), self.goal_start.text(), self.goal_target.value(), self.goal_bonus.value(), self.goal_note.text(), self.goal_type.currentText(), self.goal_scope.currentText(), self.goal_product.currentData(), self.goal_reward_type.currentText(), self.goal_reward_rate.value(), self.goal_bonus_120.value(), self.goal_bonus_150.value())
        except Exception as exc:
            QMessageBox.warning(self,'تعذر الحفظ',str(exc)); return
        self.clear_goal_form(); self.refresh(); self.notify('تم حفظ هدف الموظف')

    def on_goal_selected(self):
        if not hasattr(self, 'goals_table'):
            return
        row = self.goals_table.currentRow()
        item = self.goals_table.item(row, 0) if row >= 0 else None
        self.selected_goal_id = item.data(Qt.UserRole) if item else None

    def delete_goal(self):
        goal_id = getattr(self, 'selected_goal_id', None)
        if not goal_id:
            QMessageBox.warning(self, 'اختر هدفاً', 'اختر هدفاً من جدول المتابعة ثم اضغط تعطيل الهدف المحدد.')
            return
        if QMessageBox.question(self, 'تأكيد تعطيل الهدف', 'هل تريد تعطيل الهدف المحدد؟ سيختفي من الرئيسية ومن جدول الأهداف النشطة، ويبقى محفوظاً كسجل سابق.') != QMessageBox.Yes:
            return
        try:
            self.service.delete_employee_goal(goal_id)
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر تعطيل الهدف', str(exc)); return
        self.selected_goal_id = None
        self.refresh()
        self.notify('تم تعطيل الهدف المحدد')

    def export_goals_pdf(self):
        if not hasattr(self, 'goals_table'):
            return
        data = []
        for r in range(self.goals_table.rowCount()):
            data.append([self.goals_table.item(r, c).text() if self.goals_table.item(r, c) else '' for c in range(self.goals_table.columnCount())])
        path = rows_to_pdf('تقرير الأهداف والمكافآت الاحترافي', ['الموظف','نوع الهدف','الفترة','الهدف','المحقق','التقدم','المتبقي','المكافأة','الحالة'], data, 'professional_employee_goals_report')
        QMessageBox.information(self, 'تم', f'تم إنشاء تقرير أهداف الموظفين PDF:\n{path}')

    def build_suspended_tab(self):
        tab = QWidget(); layout = QVBoxLayout(tab); self.hold_table = Table(['رقم التعليق', 'المستخدم', 'الزبون', 'الدفع', 'الخصم', 'التاريخ']); layout.addWidget(self.hold_table, 1); self.tabs.addTab(tab, 'الفواتير المعلقة')

    def build_backup_tab(self):
        tab = QWidget(); layout = QVBoxLayout(tab)
        backup = QPushButton('إنشاء نسخة احتياطية من قاعدة البيانات'); backup.setObjectName('primaryButton'); backup.clicked.connect(self.backup)
        restore = QPushButton('استرجاع نسخة احتياطية'); restore.setObjectName('dangerButton'); restore.clicked.connect(self.restore)
        labels = QPushButton('طباعة جميع ملصقات الباركود'); labels.setObjectName('primaryButton'); labels.clicked.connect(self.print_labels)
        auto = QPushButton('اختبار النسخ الاحتياطي التلقائي اليومي'); auto.setObjectName('warningButton'); auto.clicked.connect(self.test_auto_backup)

        gbox = QFrame(); gbox.setObjectName('card')
        gform = QFormLayout(gbox)
        self.gdrive_enabled = QCheckBox('تفعيل النسخ إلى Google Drive')
        self.gdrive_path = QLineEdit(); self.gdrive_path.setPlaceholderText('اختر مجلد Google Drive مثل G:/My Drive أو C:/Users/Max/My Drive')
        self.gdrive_path.setMinimumWidth(300)
        browse = QPushButton('اختيار مجلد Google Drive'); browse.clicked.connect(self.choose_google_drive_folder)
        save_gdrive = QPushButton('حفظ إعدادات Google Drive'); save_gdrive.setObjectName('primaryButton'); save_gdrive.clicked.connect(self.save_google_drive_settings)
        test_gdrive = QPushButton('اختبار مجلد Google Drive'); test_gdrive.setObjectName('warningButton'); test_gdrive.clicked.connect(self.test_google_drive_folder)
        row = QHBoxLayout(); row.addWidget(self.gdrive_path, 1); row.addWidget(browse)
        self.gdrive_status = QLabel('')
        self.gdrive_status.setWordWrap(True)
        gform.addRow('', self.gdrive_enabled)
        gform.addRow('مجلد Google Drive', row)
        gform.addRow('', save_gdrive)
        gform.addRow('', test_gdrive)
        gform.addRow('حالة آخر نسخ', self.gdrive_status)

        note = QLabel('يمكنك استخدام Google Drive for Desktop واختيار مجلد My Drive. سيحفظ النظام نسخة محلية داخل backups ثم ينسخها إلى مجلد Google Drive المختار ليتم رفعها تلقائياً.')
        note.setObjectName('noticeBox'); note.setWordWrap(True)
        layout.addWidget(backup); layout.addWidget(restore); layout.addWidget(auto); layout.addWidget(gbox); layout.addWidget(labels); layout.addWidget(note); layout.addStretch(); self.tabs.addTab(tab, 'نسخ وباركود')
        self.load_google_drive_settings()

    def refresh(self):
        logs = self.service.list_activity_logs(); self.logs_table.setRowCount(len(logs))
        for r, row in enumerate(logs):
            for c, v in enumerate([row['created_at'], row['username'] or '', row['action'], row['details'] or '']): self.logs_table.put(r, c, v)
        if hasattr(self, 'audit_table'):
            audit = self.service.audit_rows(); self.audit_table.setRowCount(len(audit))
            for r, row in enumerate(audit):
                for c, v in enumerate([row['created_at'], row['username'] or '', row['action'], row['details'] or '']): self.audit_table.put(r, c, v)
        if hasattr(self, 'goal_employee'):
            cur_goal = self.goal_employee.currentData(); self.goal_employee.clear()
            if self.service.is_admin_user(self.current_user):
                employees_for_goals = self.service.list_employees()
            else:
                emp = self.service.employee_for_user(self.current_user)
                employees_for_goals = [emp] if emp else []
            for e in employees_for_goals:
                self.goal_employee.addItem(e['name'], e['id'])
            if not self.service.is_admin_user(self.current_user) and self.goal_employee.count() == 0:
                self.goal_employee.addItem('لا يوجد موظف مرتبط بهذا المستخدم', None)
            if hasattr(self, 'goal_product'):
                cur_prod = self.goal_product.currentData(); self.goal_product.clear(); self.goal_product.addItem('بدون منتج محدد', None)
                for p in self.service.list_products(''):
                    self.goal_product.addItem(f"{p['name']} - {p['barcode'] or ''}", p['id'])
                if cur_prod is not None:
                    idxp = self.goal_product.findData(cur_prod)
                    if idxp >= 0: self.goal_product.setCurrentIndex(idxp)
            if cur_goal is not None:
                idx = self.goal_employee.findData(cur_goal)
                if idx >= 0: self.goal_employee.setCurrentIndex(idx)
            goals = self.service.employee_goal_rows(self.current_user); self.goals_table.setRowCount(len(goals))
            done_count = 0; bonus_total = 0.0
            for r, g in enumerate(goals):
                target = float(g['target_sales'] or 0)
                achieved = float(g['achieved'] or 0)
                ratio = (achieved / target * 100) if target > 0 else 0
                remaining = max(target - achieved, 0)
                done = ratio >= 100
                status = '✅ مكتمل' if done else ('⚠️ قريب' if ratio >= 80 else 'قيد المتابعة')
                if done:
                    done_count += 1; bonus_total += float(g.get('reward_amount', g.get('bonus_amount', 0)) or 0)
                goal_type = g.get('goal_type','مبيعات')
                display_type = goal_type + (f" | {g.get('product_name')}" if goal_type == 'بيع منتج معين' and g.get('product_name') else '')
                vals = [
                    g.get('employee',''),
                    display_type,
                    f"{g.get('period_type','')} - {g.get('period_start','')}",
                    format_goal_value(target, goal_type),
                    format_goal_value(achieved, goal_type),
                    f'{ratio:.1f}%',
                    format_goal_value(remaining, goal_type),
                    money(g.get('reward_amount', g.get('bonus_amount', 0))),
                    g.get('status_text', status),
                ]
                for c, v in enumerate(vals):
                    self.goals_table.put(r, c, v, g.get('id') if c == 0 else None)
            if hasattr(self, 'goals_total_card'):
                self.goals_total_card.set_value(str(len(goals)))
                self.goals_done_card.set_value(str(done_count))
                self.goals_bonus_card.set_value(money(bonus_total))
        inv = self.service.inventory_movements(); self.inv_table.setRowCount(len(inv))
        for r, row in enumerate(inv):
            vals = [row['created_at'], row['product_name'], row['movement_type'], row['quantity_change'], row['old_quantity'], row['new_quantity'], row['ref_no'] or '', row['note'] or '']
            for c, v in enumerate(vals): self.inv_table.put(r, c, v)
        reps = self.service.commission_report(); self.comm_table.setRowCount(len(reps))
        for r, row in enumerate(reps):
            net = float(row['commission'] or 0) - float(row['returned_commission'] or 0)
            vals = [row['employee'], money(row['sales']), money(row['commission']), money(row['returned_commission']), money(net)]
            for c, v in enumerate(vals): self.comm_table.put(r, c, v)
        holds = self.service.list_suspended_sales(); self.hold_table.setRowCount(len(holds))
        for r, row in enumerate(holds):
            vals = [row['hold_no'], row['username'], row['customer'], row['payment_method'] or '', money(row['discount_amount']), row['created_at']]
            for c, v in enumerate(vals): self.hold_table.put(r, c, v)
        if hasattr(self, 'count_product'):
            current_product = self.count_product.currentData()
            self.count_product.clear()
            for p in self.service.list_products(''):
                self.count_product.addItem(f"{p['name']} | مخزون: {p['quantity']}", p['id'])
            self.count_branch.clear()
            for b in self.service.list_branches():
                self.count_branch.addItem(b['name'], b['id'])
            self.count_warehouse.clear()
            for w in self.service.list_warehouses():
                self.count_warehouse.addItem(f"{w['branch_name']} / {w['name']}", w['id'])
            counts = self.service.inventory_count_rows()
            self.count_table.setRowCount(len(counts))
            for r, row in enumerate(counts):
                vals = [row['created_at'], row['product_name'], row['branch_name'], row['warehouse_name'], row['system_quantity'], row['counted_quantity'], row['damaged_quantity'], row['difference'], row['note'] or '']
                for c, v in enumerate(vals): self.count_table.put(r, c, v)
        if hasattr(self, 'branch_table'):
            branches = self.service.list_branches(); whs = self.service.list_warehouses(); rows2=[]
            for b in branches: rows2.append([b['name'], 'فرع', b['address'] or ''])
            for w in whs: rows2.append([w['name'], w['branch_name'], w['address'] or ''])
            self.branch_table.setRowCount(len(rows2))
            for r, vals in enumerate(rows2):
                for c, v in enumerate(vals): self.branch_table.put(r, c, v)
            if hasattr(self, 'wh_branch'):
                cur = self.wh_branch.currentData(); self.wh_branch.clear()
                for b in branches: self.wh_branch.addItem(b['name'], b['id'])

    def backup(self):
        path = self.service.backup_database()
        st = self.service.get_settings()
        gstatus = st.get('last_google_drive_backup_status', '')
        self.notify(f'تم إنشاء نسخة احتياطية: {path}')
        extra = f'\n\nGoogle Drive: {gstatus}' if gstatus else ''
        QMessageBox.information(self, 'تم', f'تم إنشاء النسخة الاحتياطية:\n{path}{extra}')
        if hasattr(self, 'gdrive_status'):
            self.gdrive_status.setText(gstatus)

    def load_google_drive_settings(self):
        st = self.service.get_settings()
        if hasattr(self, 'gdrive_enabled'):
            self.gdrive_enabled.setChecked(str(st.get('google_drive_backup_enabled','0')) in ('1','true','True','نعم'))
            self.gdrive_path.setText(st.get('google_drive_backup_path',''))
            self.gdrive_status.setText(st.get('last_google_drive_backup_status',''))

    def choose_google_drive_folder(self):
        folder = QFileDialog.getExistingDirectory(self, 'اختيار مجلد Google Drive')
        if folder:
            self.gdrive_path.setText(folder)

    def save_google_drive_settings(self):
        self.service.save_settings({
            'google_drive_backup_enabled': '1' if self.gdrive_enabled.isChecked() else '0',
            'google_drive_backup_path': self.gdrive_path.text().strip(),
        }, self.current_user.get('id') if self.current_user else None)
        self.notify('تم حفظ إعدادات Google Drive')
        QMessageBox.information(self, 'تم', 'تم حفظ إعدادات النسخ إلى Google Drive')

    def test_google_drive_folder(self):
        self.save_google_drive_settings()
        ok, msg = self.service.test_google_drive_backup()
        self.gdrive_status.setText(msg)
        QMessageBox.information(self, 'نتيجة الاختبار' if ok else 'خطأ', msg)

    def test_auto_backup(self):
        ok, msg = self.service.auto_backup_if_due()
        if ok:
            QMessageBox.information(self, 'تم', f'تم إنشاء النسخة الاحتياطية التلقائية:\n{msg}')
        else:
            QMessageBox.information(self, 'معلومة', msg)

    def restore(self):
        path, _ = QFileDialog.getOpenFileName(self, 'اختر نسخة احتياطية', '', 'SQLite DB (*.db);;All Files (*)')
        if not path: return
        if QMessageBox.question(self, 'تأكيد', 'سيتم استبدال قاعدة البيانات الحالية. هل أنت متأكد؟') != QMessageBox.Yes: return
        try: self.service.restore_database(path)
        except Exception as exc: QMessageBox.warning(self, 'تعذر الاسترجاع', str(exc)); return
        QMessageBox.information(self, 'تم', 'تم استرجاع النسخة. أغلق البرنامج وافتحه من جديد.')

    def print_labels(self):
        try: path = self.service.print_barcode_labels_html()
        except Exception as exc: QMessageBox.warning(self, 'تعذر الطباعة', str(exc)); return
        QMessageBox.information(self, 'تم', f'تم إنشاء ملف الملصقات:\n{path}')
