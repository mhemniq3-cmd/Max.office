from ui.ui_common import *
from ui.dialogs.inventory_alerts_dialog import InventoryAlertsDialog
try:
    from PySide6.QtCharts import QChart, QChartView, QLineSeries, QPieSeries, QValueAxis, QDateTimeAxis, QBarSet, QStackedBarSeries, QBarCategoryAxis
    from PySide6.QtCore import QDateTime
    from PySide6.QtGui import QPainter, QColor, QPen, QFont, QBrush, QLinearGradient
except ImportError:
    QChart = None


class DashboardMetricCard(QFrame):
    def __init__(self, title: str, value: str, icon_char: str, accent_color_name: str):
        super().__init__()
        self.setObjectName('metricCard')
        self.setProperty('accent', accent_color_name)
        self.title_text = title
        self.icon_char = icon_char
        self.accent_color_name = accent_color_name
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(12)
        
        text_layout = QVBoxLayout()
        text_layout.setSpacing(4)
        text_layout.setContentsMargins(0, 0, 0, 0)
        
        self.title_lbl = QLabel(title)
        self.title_lbl.setObjectName('metricTitle')
        
        self.val_lbl = QLabel(value)
        self.val_lbl.setObjectName('metricValue')
        self.val_lbl.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        
        text_layout.addWidget(self.title_lbl)
        text_layout.addWidget(self.val_lbl)
        
        self.badge = QFrame()
        self.badge.setFixedSize(48, 48)
        
        badge_layout = QVBoxLayout(self.badge)
        badge_layout.setContentsMargins(0, 0, 0, 0)
        badge_layout.setAlignment(Qt.AlignCenter)
        
        self.icon_lbl = QLabel(icon_char)
        self.icon_lbl.setStyleSheet("font-size: 22px; background: transparent; border: none; color: #FFFFFF;")
        self.icon_lbl.setAlignment(Qt.AlignCenter)
        badge_layout.addWidget(self.icon_lbl)
        
        layout.addLayout(text_layout, 1)
        layout.addWidget(self.badge)
        
        self.update_card_styles(False)
        
    def set_value(self, value: str) -> None:
        self.val_lbl.setText(value)
        
    def enterEvent(self, event):
        self.update_card_styles(True)
        super().enterEvent(event)
        
    def leaveEvent(self, event):
        self.update_card_styles(False)
        super().leaveEvent(event)
        
    def update_card_styles(self, hovered: bool):
        try:
            from ui.theme_manager import current_brand_theme, current_appearance_mode, effective_mode
            brand = current_brand_theme()
            
            # Vibrant neon metallic linear gradients for a premium 3D look
            gradient_map = {
                'primary': "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #2563EB, stop:0.5 #3B82F6, stop:1 #1D4ED8)",
                'success': "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #059669, stop:0.5 #10B981, stop:1 #047857)",
                'warning': "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #D97706, stop:0.5 #F59E0B, stop:1 #B45309)",
                'purple': "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #7C3AED, stop:0.5 #8B5CF6, stop:1 #6D28D9)",
                'danger': "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #DC2626, stop:0.5 #EF4444, stop:1 #B91C1C)",
                'cyan': "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #0891B2, stop:0.5 #06B6D4, stop:1 #0369A1)",
                'blue': "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #4F46E5, stop:0.5 #6366F1, stop:1 #3730A3)"
            }
            
            grad_css = gradient_map.get(self.accent_color_name, gradient_map['primary'])
            
            # Gloss overlay CSS
            border_color = "rgba(255, 255, 255, 0.95)" if hovered else "rgba(255, 255, 255, 0.3)"
            shadow = "margin-top: -4px; margin-bottom: 4px;" if hovered else ""
            
            self.setStyleSheet(f"""
                QFrame#metricCard {{
                    background: {grad_css};
                    border: 1px solid {border_color};
                    border-top: 1.5px solid rgba(255, 255, 255, 0.5);
                    border-bottom: 1.5px solid rgba(0, 0, 0, 0.35);
                    border-radius: 16px;
                    {shadow}
                }}
            """)
            
            self.badge.setStyleSheet("""
                QFrame {
                    background-color: rgba(255, 255, 255, 0.22);
                    border-radius: 24px;
                    border: none;
                }
            """)
            
            self.title_lbl.setStyleSheet("font-size: 13px; font-weight: bold; color: rgba(255, 255, 255, 0.9); background: transparent; border: none;")
            self.val_lbl.setStyleSheet("font-size: 22px; font-weight: 900; color: #FFFFFF; background: transparent; border: none;")
            self.icon_lbl.setStyleSheet("font-size: 22px; color: #FFFFFF; background: transparent; border: none;")
        except Exception as e:
            print("Error styling MetricCard:", e)
            
    def hex_to_rgb_str(self, hex_color: str) -> str:
        hex_color = hex_color.lstrip('#')
        if len(hex_color) == 6:
            r = int(hex_color[0:2], 16)
            g = int(hex_color[2:4], 16)
            b = int(hex_color[4:6], 16)
            return f"{r},{g},{b}"
        return "22,93,255"


class SmartAlertItem(QFrame):
    def __init__(self, text: str):
        super().__init__()
        self.setFrameShape(QFrame.StyledPanel)
        
        if "تجاوز" in text or "نافد" in text:
            color_type = "danger"
            icon = "🚨"
        elif "تنبيه" in text or "منخفض" in text:
            color_type = "warning"
            icon = "⚠️"
        else:
            color_type = "info"
            icon = "🌟"
            
        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)
        
        self.icon_lbl = QLabel(icon)
        self.icon_lbl.setStyleSheet("font-size: 18px; background: transparent; border: none;")
        self.icon_lbl.setAlignment(Qt.AlignCenter)
        
        self.text_lbl = QLabel(text)
        self.text_lbl.setWordWrap(True)
        self.text_lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        
        layout.addWidget(self.icon_lbl)
        layout.addWidget(self.text_lbl, 1)
        
        self.update_styles(color_type)
        
    def enterEvent(self, event):
        self.apply_hover_styles(True)
        super().enterEvent(event)
        
    def leaveEvent(self, event):
        self.apply_hover_styles(False)
        super().leaveEvent(event)
        
    def update_styles(self, color_type: str):
        self.color_type = color_type
        self.apply_hover_styles(False)
        
    def apply_hover_styles(self, hovered: bool):
        try:
            from ui.theme_manager import current_appearance_mode, effective_mode
            is_dark = effective_mode(current_appearance_mode()) == 'dark'
            
            if self.color_type == "danger":
                accent_color = "#EF4444"
                bg = "rgba(239, 68, 68, 0.12)" if is_dark else "rgba(239, 68, 68, 0.08)"
                border_color = "rgba(239, 68, 68, 0.4)" if hovered else "rgba(239, 68, 68, 0.2)"
                text_color = "#FECACA" if is_dark else "#991B1B"
            elif self.color_type == "warning":
                accent_color = "#F59E0B"
                bg = "rgba(245, 158, 11, 0.12)" if is_dark else "rgba(245, 158, 11, 0.08)"
                border_color = "rgba(245, 158, 11, 0.4)" if hovered else "rgba(245, 158, 11, 0.2)"
                text_color = "#FEF3C7" if is_dark else "#92400E"
            else:
                accent_color = "#10B981"
                bg = "rgba(16, 185, 129, 0.12)" if is_dark else "rgba(16, 185, 129, 0.08)"
                border_color = "rgba(16, 185, 129, 0.4)" if hovered else "rgba(16, 185, 129, 0.2)"
                text_color = "#D1FAE5" if is_dark else "#065F46"
                
            hover_shadow = "margin-top: -1px; margin-bottom: 1px;" if hovered else ""
            
            self.setStyleSheet(f"""
                QFrame {{
                    background-color: {bg};
                    border: 1px solid {border_color};
                    border-right: 4px solid {accent_color};
                    border-radius: 8px;
                    {hover_shadow}
                }}
            """)
            self.text_lbl.setStyleSheet(f"font-size: 12px; font-weight: bold; color: {text_color}; background: transparent; border: none;")
        except Exception as e:
            print("Error styling SmartAlertItem:", e)


class SmartAlertsEmptyState(QFrame):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 24, 16, 24)
        layout.setSpacing(8)
        layout.setAlignment(Qt.AlignCenter)
        
        icon_lbl = QLabel("✅")
        icon_lbl.setStyleSheet("font-size: 26px; background: transparent; border: none;")
        icon_lbl.setAlignment(Qt.AlignCenter)
        
        msg_lbl = QLabel("جميع الأنظمة تعمل بشكل ممتاز!")
        msg_lbl.setStyleSheet("font-size: 13px; font-weight: bold; background: transparent; border: none;")
        msg_lbl.setAlignment(Qt.AlignCenter)
        
        sub_lbl = QLabel("لا توجد تنبيهات أو نواقص نشطة حالياً.")
        sub_lbl.setStyleSheet("font-size: 11px; background: transparent; border: none;")
        sub_lbl.setAlignment(Qt.AlignCenter)
        
        layout.addWidget(icon_lbl)
        layout.addWidget(msg_lbl)
        layout.addWidget(sub_lbl)
        
        self.update_styles()
        
    def update_styles(self):
        try:
            from ui.theme_manager import current_appearance_mode, effective_mode
            is_dark = effective_mode(current_appearance_mode()) == 'dark'
            
            bg = "rgba(16, 185, 129, 0.06)"
            border = "rgba(16, 185, 129, 0.2)"
            color = "#A7F3D0" if is_dark else "#059669"
            sub_color = "#9CA3AF" if is_dark else "#6B7280"
            
            self.setStyleSheet(f"""
                QFrame {{
                    background-color: {bg};
                    border: 1px dashed {border};
                    border-radius: 10px;
                }}
                QLabel {{
                    color: {color};
                }}
            """)
        except Exception:
            pass


class DashboardPage(QWidget):
    def __init__(self, service: AppService, current_user=None):
        super().__init__()
        self.service = service
        self.current_user = current_user
        
        # Extensible Metric Card Manager Dictionary
        self.metric_cards = {}
        
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        content_widget = QWidget()
        scroll.setWidget(content_widget)
        
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(scroll)

        layout = QVBoxLayout(content_widget)
        layout.setSpacing(16)
        layout.setContentsMargins(12, 12, 12, 12)

        # 1. Cyber Cosmos Hero Banner (Obsidian to purple galaxy gradient)
        self.hero = QFrame()
        self.hero.setObjectName('heroCard')
        hero_l = QHBoxLayout(self.hero)
        hero_l.setContentsMargins(24, 20, 24, 20)
        
        title_container = QWidget()
        title_container.setStyleSheet("background: transparent;")
        title_v_l = QVBoxLayout(title_container)
        title_v_l.setContentsMargins(0, 0, 0, 0)
        title_v_l.setSpacing(4)
        
        title = QLabel('✦ نظام ماكس للمبيعات ✦')
        title.setObjectName('heroTitle')
        subtitle = QLabel('لوحة قيادة احترافية لمراقبة المبيعات، العمولات، المرتجعات، الديون، والمخزون')
        subtitle.setObjectName('heroSubtitle')
        title_v_l.addWidget(title)
        title_v_l.addWidget(subtitle)
        
        hero_l.addWidget(title_container, 1)
        
        # Shortcuts layout with glassmorphic styling
        self.actions_layout = QHBoxLayout()
        self.actions_layout.setSpacing(8)
        self.actions_layout.setContentsMargins(0, 0, 0, 0)
        
        btn_style = """
            QPushButton {
                background-color: rgba(255, 255, 255, 0.12);
                color: #FFFFFF;
                border: 1px solid rgba(255, 255, 255, 0.2);
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: 900;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.22);
                border: 1px solid rgba(255, 255, 255, 0.45);
            }
            QPushButton:pressed {
                background-color: rgba(255, 255, 255, 0.07);
                border: 1px solid rgba(255, 255, 255, 0.15);
            }
        """
        
        shortcuts = [
            ('sales', '🧾 بيع جديد'),
            ('touch_pos', '🖥 كاشير لمس'),
            ('products', '📦 المنتجات'),
            ('reports', '📊 التقارير')
        ]
        
        for key, text in shortcuts:
            if self.user_can(key):
                btn = QPushButton(text)
                btn.setStyleSheet(btn_style)
                btn.setCursor(Qt.PointingHandCursor)
                btn.clicked.connect(lambda checked=False, k=key: self.navigate_to_page(k))
                self.actions_layout.addWidget(btn)
                
        actions_container = QWidget()
        actions_container.setStyleSheet("background: transparent;")
        actions_container.setLayout(self.actions_layout)
        hero_l.addWidget(actions_container)
        
        layout.addWidget(self.hero)

        # 2. Employee Goals ticker
        self.goal_messages = []
        self.goal_index = 0
        self.goal_bar = QFrame()
        self.goal_bar.setObjectName('goalTickerFrame')
        goal_l = QHBoxLayout(self.goal_bar)
        goal_l.setContentsMargins(14, 10, 14, 10)
        goal_l.setSpacing(10)
        goal_title = QLabel('🎯 أهداف الموظفين')
        goal_title.setObjectName('goalTickerTitle')
        self.goal_ticker = QLabel('لا توجد أهداف نشطة حالياً')
        self.goal_ticker.setObjectName('goalTickerText')
        self.goal_ticker.setWordWrap(True)
        goal_l.addWidget(goal_title)
        goal_l.addWidget(self.goal_ticker, 1)
        self.goal_details_btn = QPushButton('عرض كل الأهداف')
        self.goal_details_btn.setObjectName('primaryButton')
        self.goal_details_btn.clicked.connect(self.show_all_goals)
        goal_l.addWidget(self.goal_details_btn)
        layout.addWidget(self.goal_bar)
        
        self.goal_timer = QTimer(self)
        self.goal_timer.timeout.connect(self.rotate_goal_message)
        self.goal_timer.start(4500)

        # 3. Dynamic metric cards layout
        self.cards_grid = QGridLayout()
        self.cards_grid.setSpacing(14)
        
        # Register standard default cards (Extensible API)
        self.register_metric_card('sales', 'مبيعات اليوم', '📊', 'primary')
        self.register_metric_card('profit', 'أرباح اليوم', '📈', 'success')
        self.register_metric_card('invoices', 'فواتير اليوم', '🧾', 'warning')
        self.register_metric_card('debt', 'الديون المعلقة', '💸', 'blue')
        self.register_metric_card('commission', 'عمولات الموظفين', '💼', 'purple')
        self.register_metric_card('returns', 'مرتجعات اليوم', '🔄', 'danger')
        self.register_metric_card('low_stock', 'منخفض المخزون', '⚠️', 'cyan')
        
        self.layout_metric_cards()
        layout.addLayout(self.cards_grid)

        # 4. Charts Section in Frosted Glass Panel containers
        if QChart is not None:
            charts_layout = QHBoxLayout()
            charts_layout.setSpacing(14)
            
            # Trend Chart
            self.trend_frame = QFrame()
            self.trend_frame.setObjectName('surface')
            trend_l = QVBoxLayout(self.trend_frame)
            trend_l.setContentsMargins(14, 14, 14, 14)
            
            self.trend_chart_view = QChartView()
            self.trend_chart_view.setRenderHint(QPainter.Antialiasing)
            self.trend_chart_view.setMinimumHeight(350)
            self.trend_chart = QChart()
            self.trend_chart.setTitle("المبيعات والأرباح (آخر 7 أيام)")
            self.trend_chart.setAnimationOptions(QChart.SeriesAnimations)
            self.trend_chart.setBackgroundRoundness(8)
            self.trend_chart.layout().setContentsMargins(0, 0, 0, 0)
            
            self.trend_chart_view.setChart(self.trend_chart)
            trend_l.addWidget(self.trend_chart_view)
            charts_layout.addWidget(self.trend_frame, 2)
            
            # Pie Chart
            self.pie_frame = QFrame()
            self.pie_frame.setObjectName('surface')
            pie_l = QVBoxLayout(self.pie_frame)
            pie_l.setContentsMargins(14, 14, 14, 14)
            
            self.pie_chart_view = QChartView()
            self.pie_chart_view.setRenderHint(QPainter.Antialiasing)
            self.pie_chart_view.setMinimumHeight(350)
            self.pie_chart = QChart()
            self.pie_chart.setTitle("أفضل المنتجات (30 يوم)")
            self.pie_chart.setAnimationOptions(QChart.SeriesAnimations)
            self.pie_chart.setBackgroundRoundness(8)
            self.pie_chart.layout().setContentsMargins(0, 0, 0, 0)
            
            self.pie_chart_view.setChart(self.pie_chart)
            pie_l.addWidget(self.pie_chart_view)
            charts_layout.addWidget(self.pie_frame, 1)
            
            layout.addLayout(charts_layout)

        # 5. Lower Section: Recent Invoices & Smart Alerts List
        lower = QHBoxLayout()
        lower.setSpacing(14)
        
        self.recent_box = QFrame()
        self.recent_box.setObjectName('surface')
        recent_l = QVBoxLayout(self.recent_box)
        recent_l.setContentsMargins(16, 16, 16, 16)
        recent_title = QLabel('🧾 آخر الفواتير')
        recent_title.setObjectName('sectionTitle')
        self.recent = Table(['الفاتورة', 'الزبون', 'الدفع', 'الصافي', 'التاريخ'])
        recent_l.addWidget(recent_title)
        recent_l.addWidget(self.recent, 1)

        self.alerts_box = QFrame()
        self.alerts_box.setObjectName('surface')
        alerts_l = QVBoxLayout(self.alerts_box)
        alerts_l.setContentsMargins(16, 16, 16, 16)
        alerts_title = QLabel('⚡ التنبيهات الذكية')
        alerts_title.setObjectName('sectionTitle')
        
        self.best_product = QLabel('أفضل منتج اليوم: -')
        self.best_product.setObjectName('noticeBox')
        
        # Scroll area for dynamic alerts list
        self.alerts_scroll = QScrollArea()
        self.alerts_scroll.setWidgetResizable(True)
        self.alerts_scroll.setFrameShape(QFrame.NoFrame)
        self.alerts_scroll.setStyleSheet("background: transparent;")
        
        self.alerts_container = QWidget()
        self.alerts_container.setStyleSheet("background: transparent;")
        self.alerts_layout = QVBoxLayout(self.alerts_container)
        self.alerts_layout.setContentsMargins(0, 0, 0, 0)
        self.alerts_layout.setSpacing(6)
        self.alerts_layout.addStretch()
        self.alerts_scroll.setWidget(self.alerts_container)
        
        self.inventory_alerts_btn = QPushButton('📦 تفاصيل المخزون والنواقص')
        self.inventory_alerts_btn.setObjectName('primaryButton')
        self.inventory_alerts_btn.clicked.connect(self.open_inventory_alerts)
        
        alerts_l.addWidget(alerts_title)
        alerts_l.addWidget(self.best_product)
        alerts_l.addWidget(self.alerts_scroll, 1)
        alerts_l.addWidget(self.inventory_alerts_btn)
        
        lower.addWidget(self.recent_box, 2)
        lower.addWidget(self.alerts_box, 1)
        layout.addLayout(lower)
        
        layout.addStretch()

    # Dynamic registration API for future dashboard features
    def register_metric_card(self, key: str, label: str, icon: str, accent: str, initial_value: str = "0"):
        card = DashboardMetricCard(label, initial_value, icon, accent)
        self.metric_cards[key] = card
        
    def layout_metric_cards(self):
        while self.cards_grid.count() > 0:
            item = self.cards_grid.takeAt(0)
            if item.widget():
                item.widget().hide()
                
        for i, (key, card) in enumerate(self.metric_cards.items()):
            row = i // 4
            col = i % 4
            self.cards_grid.addWidget(card, row, col)
            card.show()

    def navigate_to_page(self, page_name: str):
        parent = self.parent()
        while parent is not None:
            if hasattr(parent, 'show_page'):
                parent.show_page(page_name)
                break
            parent = parent.parent()

    def user_can(self, key: str) -> bool:
        if not self.current_user: return True
        from ui.ui_common import PAGE_PERMISSION
        perm = PAGE_PERMISSION.get(key)
        return bool(self.current_user.get(perm, True)) if perm else True

    def hex_to_rgb_str(self, hex_color: str) -> str:
        hex_color = hex_color.lstrip('#')
        if len(hex_color) == 6:
            r = int(hex_color[0:2], 16)
            g = int(hex_color[2:4], 16)
            b = int(hex_color[4:6], 16)
            return f"{r},{g},{b}"
        return "22,93,255"

    def apply_brand_styles(self):
        try:
            from ui.theme_manager import current_brand_theme, current_appearance_mode, effective_mode
            brand = current_brand_theme()
            is_dark = effective_mode(current_appearance_mode()) == 'dark'
            
            primary = brand.get('primary', '#165DFF')
            
            # Deep cosmic background gradient
            self.hero.setStyleSheet("""
                QFrame#heroCard {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #1E1B4B, stop:0.5 #311042, stop:1 #0F172A);
                    border: 1px solid rgba(255, 255, 255, 0.15);
                    border-radius: 16px;
                }
                QLabel#heroTitle {
                    color: #FBBF24;
                    font-size: 22px;
                    font-weight: 900;
                    background: transparent;
                }
                QLabel#heroSubtitle {
                    color: rgba(255, 255, 255, 0.85);
                    font-size: 13px;
                    background: transparent;
                }
            """)
            
            # Glassmorphism goals ticker
            self.goal_bar.setStyleSheet(f"""
                QFrame#goalTickerFrame {{
                    background-color: rgba({self.hex_to_rgb_str(primary)}, 0.08);
                    border: 1px solid rgba({self.hex_to_rgb_str(primary)}, 0.25);
                    border-radius: 12px;
                }}
                QLabel#goalTickerTitle {{
                    color: {brand.get('accent', '#FF7D00')};
                    font-weight: 900;
                    background: transparent;
                }}
                QLabel#goalTickerText {{
                    color: {"#E5E7EB" if is_dark else "#1F2937"};
                    font-size: 13px;
                    background: transparent;
                    font-weight: bold;
                }}
            """)
            
            # Frosted glass styling for lower widgets
            if is_dark:
                frosted_css = """
                    QFrame#surface {
                        background-color: rgba(17, 24, 39, 0.65);
                        border: 1px solid rgba(255, 255, 255, 0.08);
                        border-radius: 16px;
                    }
                """
            else:
                frosted_css = """
                    QFrame#surface {
                        background-color: rgba(255, 255, 255, 0.8);
                        border: 1px solid rgba(0, 0, 0, 0.08);
                        border-radius: 16px;
                    }
                """
            self.recent_box.setStyleSheet(frosted_css)
            self.alerts_box.setStyleSheet(frosted_css)
            if hasattr(self, 'trend_frame'):
                self.trend_frame.setStyleSheet(frosted_css)
            if hasattr(self, 'pie_frame'):
                self.pie_frame.setStyleSheet(frosted_css)
                
            for card in self.metric_cards.values():
                card.update_card_styles(False)
        except Exception as e:
            print("Error in apply_brand_styles:", e)

    def refresh(self) -> None:
        data = self.service.dashboard()
        
        # Populate dynamic registered metric cards safely
        if 'sales' in self.metric_cards:
            self.metric_cards['sales'].set_value(money(data['sales']))
        if 'profit' in self.metric_cards:
            self.metric_cards['profit'].set_value(money(data['profit']))
        if 'invoices' in self.metric_cards:
            self.metric_cards['invoices'].set_value(str(data['invoices']))
        if 'commission' in self.metric_cards:
            self.metric_cards['commission'].set_value(money(data['commission']))
        if 'returns' in self.metric_cards:
            self.metric_cards['returns'].set_value(money(data['returns_amount']))
        if 'low_stock' in self.metric_cards:
            self.metric_cards['low_stock'].set_value(str(data['low_stock']))
        if 'debt' in self.metric_cards:
            self.metric_cards['debt'].set_value(money(data['total_debt']))
            
        self.best_product.setText(f"أفضل منتج اليوم: {data['best_product']}")
        
        # Recent sales
        sales = self.service.list_sales(8)
        self.recent.setRowCount(len(sales))
        for r, sale in enumerate(sales):
            vals = [sale['invoice_no'], sale['customer'], sale['payment_method'], money(sale['total']), sale['created_at']]
            for c, v in enumerate(vals):
                self.recent.put(r, c, v)
                
        # Smart alerts
        while self.alerts_layout.count() > 1:
            child = self.alerts_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
                
        alerts = self.service.smart_alerts()
        if alerts:
            for item in alerts:
                self.alerts_layout.insertWidget(self.alerts_layout.count() - 1, SmartAlertItem(item))
        else:
            self.alerts_layout.insertWidget(self.alerts_layout.count() - 1, SmartAlertsEmptyState())
            
        self.refresh_goal_ticker()
        self.refresh_charts()
        self.apply_brand_styles()

    def refresh_charts(self):
        if QChart is None: return
        
        try:
            from ui.theme_manager import current_brand_theme, current_appearance_mode, effective_mode
            brand = current_brand_theme()
            is_dark = effective_mode(current_appearance_mode()) == 'dark'
            
            primary_hex = brand.get('primary', '#165DFF')
            secondary_hex = brand.get('secondary', '#00B42A')
            
            primary_color = QColor(primary_hex)
            secondary_color = QColor(secondary_hex)
            
            chart_theme = QChart.ChartThemeDark if is_dark else QChart.ChartThemeLight
            self.trend_chart.setTheme(chart_theme)
            self.pie_chart.setTheme(chart_theme)
            
            # Make chart backgrounds transparent for holographic effect
            self.trend_chart.setBackgroundBrush(QBrush(QColor(0, 0, 0, 0)))
            self.pie_chart.setBackgroundBrush(QBrush(QColor(0, 0, 0, 0)))
            
            text_color = QColor(229, 231, 235) if is_dark else QColor(15, 23, 42)
            grid_color = QColor(55, 65, 81) if is_dark else QColor(229, 230, 235)
            
            title_font = QFont("Tajawal", 11, QFont.Bold)
            self.trend_chart.setTitleBrush(text_color)
            self.trend_chart.setTitleFont(title_font)
            self.pie_chart.setTitleBrush(text_color)
            self.pie_chart.setTitleFont(title_font)
            
            for legend in [self.trend_chart.legend(), self.pie_chart.legend()]:
                legend.setLabelColor(text_color)
                legend.setFont(QFont("Tajawal", 9))
                
            # Trend Chart Data
            trend_data = self.service.dashboard_chart_sales_trend()
            self.trend_chart.removeAllSeries()
            for axis in list(self.trend_chart.axes()):
                self.trend_chart.removeAxis(axis)
                
            if trend_data:
                sales_series = QLineSeries()
                sales_series.setName("المبيعات")
                pen = QPen(primary_color)
                pen.setWidth(3)
                sales_series.setPen(pen)
                sales_series.setPointsVisible(True)
                
                profit_series = QLineSeries()
                profit_series.setName("الأرباح")
                p_pen = QPen(secondary_color)
                p_pen.setWidth(3)
                profit_series.setPen(p_pen)
                profit_series.setPointsVisible(True)
                
                max_sales = 0
                for row in trend_data:
                    dt = QDateTime.fromString(row['date'], "yyyy-MM-dd")
                    dt_msecs = dt.toMSecsSinceEpoch()
                    s = float(row['sales'] or 0)
                    p = float(row['profit'] or 0)
                    sales_series.append(dt_msecs, s)
                    profit_series.append(dt_msecs, p)
                    max_sales = max(max_sales, s, p)
                
                self.trend_chart.addSeries(sales_series)
                self.trend_chart.addSeries(profit_series)
                
                axis_x = QDateTimeAxis()
                axis_x.setFormat("MM-dd")
                axis_x.setTitleText("التاريخ")
                axis_x.setTitleBrush(text_color)
                axis_x.setLabelsBrush(text_color)
                axis_x.setGridLineColor(grid_color)
                axis_x.setTickCount(min(len(trend_data), 7))
                self.trend_chart.addAxis(axis_x, Qt.AlignBottom)
                sales_series.attachAxis(axis_x)
                profit_series.attachAxis(axis_x)
                
                axis_y = QValueAxis()
                axis_y.setTitleText("المبيعات / الأرباح")
                axis_y.setTitleBrush(text_color)
                axis_y.setLabelsBrush(text_color)
                axis_y.setGridLineColor(grid_color)
                axis_y.setRange(0, max_sales * 1.1 if max_sales > 0 else 1000)
                axis_y.setLabelFormat("%d")
                self.trend_chart.addAxis(axis_y, Qt.AlignLeft)
                sales_series.attachAxis(axis_y)
                profit_series.attachAxis(axis_y)
        except Exception as e:
            print("Error loading trend chart:", e)
            
        # Pie Chart Data
        try:
            top_products = self.service.dashboard_chart_top_products()
            self.pie_chart.removeAllSeries()
            
            if top_products:
                series = QPieSeries()
                series.setHoleSize(0.35)
                
                colors = [
                    QColor(brand.get('primary', '#165DFF')),
                    QColor(brand.get('secondary', '#00B42A')),
                    QColor(brand.get('accent', '#FF7D00')),
                    QColor('#8B5CF6'),
                    QColor(brand.get('danger', '#dc2626')),
                ]
                
                for i, row in enumerate(top_products):
                    name = row['product_name']
                    if len(name) > 15:
                        name = name[:15] + "..."
                    qty = float(row['qty'] or 0)
                    slice_ = series.append(name, qty)
                    slice_.setBrush(colors[i % len(colors)])
                    slice_.setLabelVisible(True)
                    slice_.setLabelColor(text_color)
                    
                self.pie_chart.addSeries(series)
        except Exception as e:
            print("Error loading pie chart:", e)

    def refresh_goal_ticker(self) -> None:
        messages = []
        try:
            goals = self.service.employee_goal_rows(self.current_user)
        except Exception:
            goals = []
        for g in goals[:8]:
            target = float(g.get('target_sales', 0) or 0)
            achieved = float(g.get('achieved', 0) or 0)
            ratio = float(g.get('ratio', 0) or 0)
            remaining = float(g.get('remaining', 0) or 0)
            reward = float(g.get('reward_amount', 0) or 0)
            goal_type = g.get('goal_type', 'مبيعات')
            period = g.get('period_type', '')
            product_part = f" | المنتج: {g.get('product_name')}" if goal_type == 'بيع منتج معين' and g.get('product_name') else ''
            if ratio >= 100:
                msg = f"🎉 {g['employee']} حقق هدف {goal_type}{product_part} ({period}) بنسبة {ratio:.1f}% - مكافأة {money(reward)}"
            elif ratio >= 80:
                msg = f"🔥 {g['employee']} قريب من هدف {goal_type}{product_part}: {ratio:.1f}% - المتبقي {format_goal_value(remaining, goal_type)}"
            else:
                msg = f"🎯 {g['employee']} | هدف {goal_type}{product_part} ({period}) | المحقق {format_goal_value(achieved, goal_type)} من {format_goal_value(target, goal_type)}"
            messages.append(msg)
        self.goal_messages = messages or ['لا توجد أهداف نشطة حالياً. أضف هدفاً من الأدوات > أهداف الموظفين ليظهر هنا للموظفين.']
        self.goal_index = min(self.goal_index, len(self.goal_messages) - 1)
        self.goal_ticker.setText(self.goal_messages[self.goal_index])

    def show_all_goals(self) -> None:
        try:
            goals = self.service.employee_goal_rows(self.current_user)
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر عرض الأهداف', str(exc))
            return
        dlg = QDialog(self)
        dlg.setWindowTitle('أهداف الموظفين' if self.service.is_admin_user(self.current_user) else 'أهدافي')
        dlg.resize(980, 520)
        lay = QVBoxLayout(dlg)
        note = QLabel('قائمة جميع الأهداف النشطة.' if self.service.is_admin_user(self.current_user) else 'هذه أهدافك فقط. لا تظهر أهداف المدير أو باقي الموظفين.')
        note.setObjectName('noticeBox')
        note.setWordWrap(True)
        lay.addWidget(note)
        table = Table(['الموظف', 'نوع الهدف', 'المنتج', 'الفترة', 'الهدف', 'المحقق', 'المتبقي', 'المكافأة', 'الحالة'])
        table.setRowCount(len(goals))
        for r, g in enumerate(goals):
            goal_type = g.get('goal_type', 'مبيعات')
            vals = [
                g.get('employee', ''),
                goal_type,
                g.get('product_name') or '-',
                f"{g.get('period_type','')} - {g.get('period_start','')}",
                format_goal_value(g.get('target_sales', 0), goal_type),
                format_goal_value(g.get('achieved', 0), goal_type),
                format_goal_value(g.get('remaining', 0), goal_type),
                money(g.get('reward_amount', 0)),
                g.get('status_text', ''),
            ]
            for c, v in enumerate(vals):
                table.put(r, c, v)
        lay.addWidget(table, 1)
        close = QPushButton('إغلاق')
        close.clicked.connect(dlg.accept)
        lay.addWidget(close)
        dlg.exec()

    def rotate_goal_message(self) -> None:
        if not getattr(self, 'goal_messages', None):
            return
        self.goal_index = (self.goal_index + 1) % len(self.goal_messages)
        self.goal_ticker.setText(self.goal_messages[self.goal_index])

    def open_inventory_alerts(self):
        dlg = InventoryAlertsDialog(self.service, self)
        dlg.exec()
