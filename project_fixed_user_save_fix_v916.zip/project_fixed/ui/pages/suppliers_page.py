from ui.ui_common import *

class SuppliersPage(QWidget):
    def __init__(self, service: AppService, notify, current_user=None):
        super().__init__(); self.service=service; self.notify=notify; self.current_user=current_user; self.supplier_id=None; self.purchase_items=[]; self.build(); self.refresh()
    def build(self):
        root=QVBoxLayout(self); title=QLabel('🚚 الموردون والمشتريات'); title.setObjectName('sectionTitle'); root.addWidget(title)
        tabs=QTabWidget(); root.addWidget(tabs,1)
        t=QWidget(); l=QHBoxLayout(t); left=QFrame(); left.setObjectName('surface'); ll=QVBoxLayout(left); right=QFrame(); right.setObjectName('surface'); right.setFixedWidth(360); rl=QVBoxLayout(right)
        self.sup_table=Table(['المورد','الهاتف','العنوان','الرصيد']); self.sup_table.doubleClicked.connect(self.load_supplier); ll.addWidget(self.sup_table,1)
        self.sup_name=QLineEdit(); self.sup_phone=QLineEdit(); self.sup_addr=QLineEdit(); self.sup_note=QLineEdit(); form=QFormLayout(); form.addRow('اسم المورد',self.sup_name); form.addRow('الهاتف',self.sup_phone); form.addRow('العنوان',self.sup_addr); form.addRow('ملاحظة',self.sup_note)
        save=QPushButton('حفظ مورد'); save.setObjectName('primaryButton'); save.clicked.connect(self.save_supplier); pay=QPushButton('تسديد مورد'); pay.setObjectName('successButton'); pay.clicked.connect(self.pay_supplier); stmt=QPushButton('كشف حساب مورد PDF'); stmt.setObjectName('primaryButton'); stmt.clicked.connect(self.supplier_statement_pdf)
        rl.addLayout(form); rl.addWidget(save); rl.addWidget(pay); rl.addWidget(stmt); rl.addStretch(); l.addWidget(left,1); l.addWidget(right); tabs.addTab(t,'الموردون والديون')
        p=QWidget(); pl=QVBoxLayout(p); form2=QHBoxLayout(); self.purchase_supplier=QComboBox(); self.purchase_product=QComboBox(); self.p_qty=QSpinBox(); self.p_qty.setMaximum(9999999); self.p_qty.setValue(1); self.p_cost=QDoubleSpinBox(); self.p_cost.setMaximum(999999999); self.p_cost.setDecimals(0); self.p_paid=QDoubleSpinBox(); self.p_paid.setMaximum(999999999); self.p_paid.setDecimals(0); self.p_payment=QComboBox(); self.p_payment.addItems(['نقدي','آجل','تحويل']); self.p_note=QLineEdit(); self.p_note.setPlaceholderText('ملاحظة')
        add=QPushButton('إضافة مادة'); add.clicked.connect(self.add_purchase_item); savep=QPushButton('حفظ فاتورة شراء وإدخال المخزون'); savep.setObjectName('successButton'); savep.clicked.connect(self.save_purchase)
        for w in [QLabel('المورد'),self.purchase_supplier,QLabel('المنتج'),self.purchase_product,QLabel('الكمية'),self.p_qty,QLabel('الكلفة'),self.p_cost,add]: form2.addWidget(w)
        self.purchase_table=Table(['المنتج','الكمية','الكلفة','الإجمالي']); bottom=QHBoxLayout(); bottom.addWidget(QLabel('المدفوع')); bottom.addWidget(self.p_paid); bottom.addWidget(self.p_payment); bottom.addWidget(self.p_note); bottom.addWidget(savep); pl.addLayout(form2); pl.addWidget(self.purchase_table,1); pl.addLayout(bottom); tabs.addTab(p,'فاتورة شراء')
        h=QWidget(); hl=QVBoxLayout(h); self.purchases_table=Table(['الفاتورة','التاريخ','المورد','المستخدم','الإجمالي','المدفوع','الدفع']); hl.addWidget(self.purchases_table,1); tabs.addTab(h,'سجل المشتريات')
    def refresh(self): self.refresh_suppliers(); self.refresh_purchase_lists(); self.refresh_purchases()
    def refresh_suppliers(self):
        self.suppliers=self.service.supplier_debt_rows(); self.sup_table.setRowCount(len(self.suppliers))
        for r,s in enumerate(self.suppliers):
            for c,v in enumerate([s['name'],s['phone'] or '', s['address'] or '', money(s['balance'])]): self.sup_table.put(r,c,v,s['id'] if c==0 else None)
    def refresh_purchase_lists(self):
        self.purchase_supplier.clear()
        for s in self.service.list_suppliers(): self.purchase_supplier.addItem(s['name'],s['id'])
        self.purchase_product.clear()
        for p in self.service.list_products(''): self.purchase_product.addItem(f"{p['name']} - {money(p['cost_price'])}",p['id'])
    def refresh_purchases(self):
        rows=self.service.list_purchases(); self.purchases_table.setRowCount(len(rows))
        for r,p in enumerate(rows):
            for c,v in enumerate([p['purchase_no'],p['created_at'],p['supplier'],p['user_name'],money(p['total']),money(p['paid_amount']),p['payment_method']]): self.purchases_table.put(r,c,v)
    def load_supplier(self):
        row=self.sup_table.currentRow()
        if row<0: return
        sid=self.sup_table.item(row,0).data(Qt.UserRole); self.supplier_id=sid; sup=next((s for s in self.service.list_suppliers() if s['id']==sid),None)
        if sup: self.sup_name.setText(sup['name']); self.sup_phone.setText(sup['phone'] or ''); self.sup_addr.setText(sup['address'] or ''); self.sup_note.setText(sup['note'] or '')
    def save_supplier(self):
        try: self.service.save_supplier(self.sup_name.text(),self.sup_phone.text(),self.sup_addr.text(),self.sup_note.text(),self.supplier_id)
        except Exception as exc: QMessageBox.warning(self,'تعذر الحفظ',str(exc)); return
        self.supplier_id=None; self.sup_name.clear(); self.sup_phone.clear(); self.sup_addr.clear(); self.sup_note.clear(); self.refresh(); self.notify('تم حفظ المورد')
    def pay_supplier(self):
        if not self.supplier_id: QMessageBox.warning(self,'تنبيه','اختر مورداً'); return
        amount,ok=QInputDialog.getDouble(self,'تسديد مورد','المبلغ:',0,0,999999999,0)
        if not ok or amount<=0: return
        try: self.service.add_supplier_payment(self.supplier_id,amount,'تسديد من صفحة الموردين',self.current_user['id'] if self.current_user else None)
        except Exception as exc: QMessageBox.warning(self,'تعذر التسديد',str(exc)); return
        self.refresh(); self.notify('تم تسجيل تسديد المورد')
    def add_purchase_item(self):
        pid=self.purchase_product.currentData(); qty=self.p_qty.value(); cost=self.p_cost.value()
        if not pid or cost<=0: QMessageBox.warning(self,'تنبيه','اختر المنتج والكلفة'); return
        name=self.purchase_product.currentText().split(' - ')[0]; self.purchase_items.append({'product_id':pid,'product_name':name,'quantity':qty,'unit_cost':cost}); self.refresh_purchase_cart()
    def refresh_purchase_cart(self):
        self.purchase_table.setRowCount(len(self.purchase_items))
        for r,it in enumerate(self.purchase_items):
            for c,v in enumerate([it['product_name'],it['quantity'],money(it['unit_cost']),money(it['quantity']*it['unit_cost'])]): self.purchase_table.put(r,c,v)
    def save_purchase(self):
        try: pno=self.service.create_purchase(self.purchase_supplier.currentData(),self.purchase_items,self.p_paid.value(),self.p_payment.currentText(),0,self.p_note.text(),self.current_user['id'] if self.current_user else None)
        except Exception as exc: QMessageBox.warning(self,'تعذر حفظ الشراء',str(exc)); return
        self.purchase_items.clear(); self.p_paid.setValue(0); self.p_note.clear(); self.refresh_purchase_cart(); self.refresh(); QMessageBox.information(self,'تم',f'تم حفظ فاتورة الشراء {pno}')
    def supplier_statement_pdf(self):
        if not self.supplier_id: QMessageBox.warning(self,'تنبيه','اختر مورداً'); return
        rows=self.service.supplier_statement(self.supplier_id); bal=0; data=[]
        for x in rows: bal+=x['debit']-x['credit']; data.append([x['created_at'],x['kind'],x['ref'],money(x['debit']),money(x['credit']),money(bal),x['note']])
        path=rows_to_pdf('كشف حساب مورد',['التاريخ','النوع','المرجع','مدين','دائن','الرصيد','ملاحظة'],data,'supplier_statement'); QMessageBox.information(self,'تم',f'تم إنشاء PDF:\n{path}')
