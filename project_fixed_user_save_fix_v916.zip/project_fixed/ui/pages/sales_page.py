from ui.ui_common import *



def request_manager_approval(parent: QWidget, error_message: str) -> dict | None:
    """Ask for a manager one-time approval for a sensitive sale."""
    dlg = QDialog(parent)
    dlg.setWindowTitle('موافقة مدير مطلوبة')
    dlg.resize(460, 260)
    lay = QVBoxLayout(dlg)
    msg = QLabel('هذه العملية تحتاج موافقة مدير بسبب خصم كبير أو بيع بأقل من التكلفة.\n' + str(error_message or ''))
    msg.setWordWrap(True)
    msg.setObjectName('warningBox')
    lay.addWidget(msg)
    form = QFormLayout()
    username = QLineEdit()
    username.setPlaceholderText('اسم مستخدم المدير')
    password = QLineEdit()
    password.setPlaceholderText('كلمة مرور المدير')
    password.setEchoMode(QLineEdit.Password)
    reason = QLineEdit()
    reason.setPlaceholderText('سبب الموافقة - مثال: عرض خاص للزبون')
    form.addRow('المدير', username)
    form.addRow('كلمة المرور', password)
    form.addRow('السبب', reason)
    lay.addLayout(form)
    buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    buttons.button(QDialogButtonBox.Ok).setText('اعتماد العملية')
    buttons.button(QDialogButtonBox.Cancel).setText('إلغاء')
    buttons.accepted.connect(dlg.accept)
    buttons.rejected.connect(dlg.reject)
    lay.addWidget(buttons)
    if dlg.exec() != QDialog.Accepted:
        return None
    return {
        'username': username.text().strip(),
        'password': password.text(),
        'reason': reason.text().strip() or 'موافقة مدير على خصم خاص / أقل من التكلفة',
        'details': {'source': 'sales_page'},
    }


def _safe_get(row, key, default=None):
    if row is None:
        return default
    if isinstance(row, dict):
        return row.get(key, default)
    try:
        return row[key]
    except Exception:
        return default


class SaleInvoiceTab(QWidget):
    def __init__(self, parent_page):
        super().__init__()
        self.page = parent_page
        self.service = parent_page.service
        self.notify = parent_page.notify
        self.current_user = parent_page.current_user
        
        self.cart = []
        self.customer_rows = []
        
        self.build()
        self.refresh_people()

    def build(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)
        root.setSpacing(10)

        # ══════ LEFT: Cart Table ══════
        cart_frame = QFrame()
        cart_frame.setObjectName('surface')
        cart_l = QVBoxLayout(cart_frame)
        cart_l.setContentsMargins(10, 10, 10, 10)
        cart_l.setSpacing(6)

        cart_header = QLabel('🧾 سلة المشتريات')
        cart_header.setObjectName('sectionTitle')
        self.cart_table = Table(['المنتج', 'كمية', 'سعر الوحدة', 'الإجمالي', 'العمولة'])

        cart_actions = QHBoxLayout()
        cart_actions.setSpacing(6)
        self.remove_btn = QPushButton('🗑 حذف')
        self.remove_btn.setObjectName('dangerButton')
        self.remove_btn.setMinimumHeight(32)
        self.remove_btn.clicked.connect(self.remove_selected)
        self.clear_btn = QPushButton('🔄 مسح')
        self.clear_btn.setMinimumHeight(32)
        self.clear_btn.clicked.connect(self.clear_cart)
        self.preview_btn = QPushButton('👁 معاينة')
        self.preview_btn.setObjectName('primaryButton')
        self.preview_btn.setMinimumHeight(32)
        self.preview_btn.clicked.connect(lambda: self.show_invoice_preview(False))
        cart_actions.addWidget(self.remove_btn)
        cart_actions.addWidget(self.clear_btn)
        cart_actions.addStretch()
        cart_actions.addWidget(self.preview_btn)

        cart_l.addWidget(cart_header)
        cart_l.addWidget(self.cart_table, 1)
        cart_l.addLayout(cart_actions)

        # ══════ RIGHT: Controls Column (NO scroll - everything visible) ══════
        right_col = QVBoxLayout()
        right_col.setSpacing(6)

        # ── Single compact card for all invoice fields ──
        card = QFrame()
        card.setObjectName('surface')
        card.setFixedWidth(320)
        card_l = QVBoxLayout(card)
        card_l.setContentsMargins(10, 8, 10, 8)
        card_l.setSpacing(4)

        user_text = (self.current_user['full_name'] or self.current_user['username']) if self.current_user else '-'
        self.user_label = QLabel(f'👤 {user_text}')
        self.user_label.setObjectName('noticeBox')
        card_l.addWidget(self.user_label)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        form.setVerticalSpacing(4)
        form.setHorizontalSpacing(8)

        self.employee = QComboBox()
        self.employee.setMinimumHeight(30)
        self.customer_search = QLineEdit()
        self.customer_search.setPlaceholderText('🔍 بحث زبون...')
        self.customer_search.setMinimumHeight(30)
        self.customer_search.textChanged.connect(self.filter_customers)
        self.customer = QComboBox()
        self.customer.setMinimumHeight(30)
        self.customer.currentIndexChanged.connect(self.update_customer_info)
        self.payment = QComboBox()
        self.payment.addItems(['نقدي', 'بطاقة', 'تحويل', 'آجل'])
        self.payment.setMinimumHeight(30)
        self.payment.currentIndexChanged.connect(self.update_customer_info)
        self.price_level = QComboBox()
        self.price_level.setMinimumHeight(30)
        self.price_level.addItem('تلقائي', None)
        self.price_level.currentIndexChanged.connect(lambda *_: self.refresh_cart())
        self.note = QLineEdit()
        self.note.setPlaceholderText('ملاحظة...')
        self.note.setMinimumHeight(30)

        form.addRow('الموظف', self.employee)
        form.addRow('بحث', self.customer_search)
        form.addRow('الزبون', self.customer)
        form.addRow('الدفع', self.payment)
        form.addRow('السعر', self.price_level)
        form.addRow('ملاحظة', self.note)
        card_l.addLayout(form)

        # Customer tools row
        cust_row = QHBoxLayout()
        cust_row.setSpacing(4)
        self.add_customer_btn = QPushButton('➕ زبون')
        self.add_customer_btn.setObjectName('primaryButton')
        self.add_customer_btn.setMinimumHeight(28)
        self.add_customer_btn.clicked.connect(self.add_quick_customer)
        self.fav_customer_btn = QPushButton('⭐ المميزين')
        self.fav_customer_btn.setObjectName('warningButton')
        self.fav_customer_btn.setMinimumHeight(28)
        self.fav_customer_btn.clicked.connect(self.load_favorite_customers)
        cust_row.addWidget(self.add_customer_btn)
        cust_row.addWidget(self.fav_customer_btn)
        card_l.addLayout(cust_row)

        self.customer_info = QLabel('💰 دين: 0 د.ع')
        self.customer_info.setObjectName('noticeBox')
        self.customer_info.setWordWrap(True)
        card_l.addWidget(self.customer_info)

        # Quantity + Discount inline row (inside same card)
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setFrameShadow(QFrame.Sunken)
        card_l.addWidget(sep)

        qty_row = QHBoxLayout()
        qty_row.setSpacing(6)
        self.qty = QSpinBox()
        self.qty.setRange(1, 99999)
        self.qty.setValue(1)
        self.qty.setMinimumHeight(32)
        self.qty.setPrefix('الكمية: ')
        self.discount = QDoubleSpinBox()
        self.discount.setRange(0, 999999999)
        self.discount.setDecimals(0)
        self.discount.setMinimumHeight(32)
        self.discount.setPrefix('خصم: ')
        self.discount.valueChanged.connect(self.refresh_cart)
        self.discount_type = QComboBox()
        self.discount_type.addItem('مبلغ', 'amount')
        self.discount_type.addItem('%', 'percent')
        self.discount_type.setMinimumHeight(32)
        self.discount_type.setMaximumWidth(70)
        self.discount_type.currentIndexChanged.connect(self.refresh_cart)
        qty_row.addWidget(self.qty, 2)
        qty_row.addWidget(self.discount, 2)
        qty_row.addWidget(self.discount_type, 1)
        card_l.addLayout(qty_row)

        # ── Total (pinned, always visible) ──
        self.total_label = QLabel('الصافي: 0 د.ع')
        self.total_label.setObjectName('bigTotal')
        self.total_label.setMinimumHeight(40)

        # ── Action Buttons (pinned, always visible) ──
        self.complete_btn = QPushButton('✅ حفظ البيع')
        self.complete_btn.setObjectName('successButton')
        self.complete_btn.setMinimumHeight(44)
        self.complete_btn.setCursor(Qt.PointingHandCursor)
        self.complete_btn.clicked.connect(self.complete_sale)
        self.suspend_btn = QPushButton('⏸ تعليق')
        self.suspend_btn.setObjectName('warningButton')
        self.suspend_btn.setMinimumHeight(36)
        self.suspend_btn.setCursor(Qt.PointingHandCursor)
        self.suspend_btn.clicked.connect(self.suspend_current_sale)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(6)
        btn_row.addWidget(self.complete_btn, 3)
        btn_row.addWidget(self.suspend_btn, 1)

        # ── Assemble right column ──
        right_col.addWidget(card, 1)
        right_col.addWidget(self.total_label)
        right_col.addLayout(btn_row)

        # ── Final assembly ──
        root.addWidget(cart_frame, 5)
        root.addLayout(right_col)

    def _wrap_layout(self, layout):
        w = QWidget()
        w.setLayout(layout)
        return w

    def refresh_people(self):
        self.employee.clear()
        current_emp_id = None
        current_name = ''
        if self.current_user:
            try:
                current_emp_id, current_name = self.service.ensure_employee_for_user(self.current_user)
            except Exception:
                current_emp_id = None
        if current_emp_id:
            self.employee.addItem(f'المستخدم الحالي: {current_name}', current_emp_id)
        for e in self.service.list_employees():
            if current_emp_id and e['id'] == current_emp_id:
                continue
            self.employee.addItem(f"موظف: {e['name']}", e['id'])
        self.reload_customer_rows()

    def reload_customer_rows(self):
        rows = list(self.service.list_customers())
        try:
            fav_ids = [int(r['id']) for r in self.service.favorite_customers_for_pos(20)]
        except Exception:
            fav_ids = []
        rows.sort(key=lambda r: (0 if int(_safe_get(r, 'id', 0)) in fav_ids else 1, str(_safe_get(r, 'name', ''))))
        self.customer_rows = rows
        self.filter_customers()

    def filter_customers(self):
        term = self.customer_search.text().strip().lower()
        current_id = self.customer.currentData()
        self.customer.blockSignals(True)
        self.customer.clear()
        for c in self.customer_rows:
            name = str(_safe_get(c, 'name', ''))
            phone = str(_safe_get(c, 'phone', '') or '')
            if term and term not in name.lower() and term not in phone.lower():
                continue
            self.customer.addItem(name, _safe_get(c, 'id'))
        if current_id:
            idx = self.customer.findData(current_id)
            if idx >= 0:
                self.customer.setCurrentIndex(idx)
        self.customer.blockSignals(False)
        self.update_customer_info()

    def load_favorite_customers(self):
        try:
            self.customer_rows = list(self.service.favorite_customers_for_pos(30))
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر عرض العملاء المميزين', str(exc))
            return
        self.customer_search.clear()
        self.filter_customers()
        self.notify('تم عرض العملاء الأكثر شراءً أولاً')

    def add_quick_customer(self):
        name, ok = QInputDialog.getText(self, 'إضافة زبون سريع', 'اسم الزبون:')
        if not ok or not name.strip():
            return
        phone, _ = QInputDialog.getText(self, 'إضافة زبون سريع', 'رقم الهاتف اختياري:')
        try:
            self.service.save_customer(name.strip(), phone.strip(), '')
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر إضافة الزبون', str(exc))
            return
        
        # Reload for this tab
        self.reload_customer_rows()
        # Optionally, notify the page to reload all tabs?
        # self.page.refresh_all_tabs_people()
        
        self.customer_search.setText(name.strip())
        self.notify(f'تمت إضافة الزبون {name.strip()}')

    def update_customer_info(self):
        cid = self.customer.currentData()
        try:
            balance = self.service.customer_balance_for_pos(cid)
        except Exception:
            balance = 0.0
        text = f'دين الزبون الحالي: {money(balance)}'
        if self.payment.currentText() == 'آجل' and self.cart:
            text += f' | بعد هذه الفاتورة: {money(balance + max(self.current_subtotal() - self.current_discount_amount(), 0))}'
        self.customer_info.setText(text)

    def current_subtotal(self):
        return sum(item['quantity'] * item['unit_price'] for item in self.cart)

    def current_discount_amount(self):
        subtotal = self.current_subtotal()
        value = float(self.discount.value() or 0)
        if self.discount_type.currentData() == 'percent':
            return subtotal * value / 100
        return value

    def validate_discount(self):
        subtotal = self.current_subtotal()
        value = float(self.discount.value() or 0)
        if not self.cart:
            return True
        if self.discount_type.currentData() == 'percent' and value > 100:
            QMessageBox.warning(self, 'خصم غير صحيح', 'نسبة الخصم لا يمكن أن تكون أكبر من 100%')
            return False
        discount_amount = self.current_discount_amount()
        if discount_amount > subtotal:
            QMessageBox.warning(self, 'خصم غير صحيح', f'قيمة الخصم أكبر من إجمالي الفاتورة.\nإجمالي الفاتورة: {money(subtotal)}\nالخصم المدخل: {money(discount_amount)}')
            return False
        if discount_amount >= subtotal and subtotal > 0:
            QMessageBox.warning(self, 'خصم غير صحيح', 'الخصم لا يمكن أن يساوي أو يتجاوز قيمة الفاتورة')
            return False
        return True

    def refresh_cart(self):
        self.cart_table.setRowCount(len(self.cart))
        subtotal = 0.0
        commission = 0.0
        for item in self.cart:
            line = item['quantity'] * item['unit_price']
            subtotal += line
        discount_amount = self.current_discount_amount() if subtotal else 0.0
        discount_ratio = (discount_amount / subtotal) if subtotal else 0.0
        for r, item in enumerate(self.cart):
            line = item['quantity'] * item['unit_price']
            line_net = max(line - (line * discount_ratio), 0)
            item_comm = line_net * item['commission_percent'] / 100
            commission += item_comm
            for c, v in enumerate([item['product_name'], item['quantity'], money(item['unit_price']), money(line), money(item_comm)]):
                self.cart_table.put(r, c, v)
        total = max(subtotal - discount_amount, 0)
        self.total_label.setText(f'الإجمالي: {money(subtotal)}\nالخصم: {money(discount_amount)}\nالصافي: {money(total)}\nعمولة الموظف: {money(commission)}')
        self.update_customer_info()

    def remove_selected(self):
        row = self.cart_table.currentRow()
        if 0 <= row < len(self.cart):
            self.cart.pop(row)
            self.refresh_cart()

    def clear_cart(self):
        self.cart.clear()
        self.discount.setValue(0)
        self.note.clear()
        self.payment.setCurrentText('نقدي')
        self.discount_type.setCurrentIndex(0)
        self.refresh_cart()

    def show_invoice_preview(self, for_confirm=True):
        if not self.cart:
            QMessageBox.information(self, 'الفاتورة فارغة', 'أضف منتجاً واحداً على الأقل قبل المعاينة.')
            return False
        if not self.validate_discount():
            return False
        try:
            preview = self.service.sale_preview_payload(self.cart, self.customer.currentData(), self.payment.currentText(), self.discount.value(), self.discount_type.currentData())
        except Exception:
            preview = None
        dlg = QDialog(self)
        dlg.setWindowTitle('معاينة الفاتورة قبل الحفظ والطباعة')
        dlg.resize(760, 560)
        lay = QVBoxLayout(dlg)
        note = QLabel('راجع تفاصيل الفاتورة قبل الحفظ. يمكنك إغلاق النافذة والعودة لتعديل الكمية أو الخصم أو الزبون.')
        note.setObjectName('noticeBox')
        note.setWordWrap(True)
        lay.addWidget(note)
        table = Table(['المنتج', 'الكمية', 'السعر', 'الإجمالي'])
        table.setRowCount(len(self.cart))
        for r, item in enumerate(self.cart):
            vals = [item['product_name'], item['quantity'], money(item['unit_price']), money(item['quantity'] * item['unit_price'])]
            for c, v in enumerate(vals):
                table.put(r, c, v)
        lay.addWidget(table, 1)
        subtotal = self.current_subtotal()
        disc = self.current_discount_amount()
        total = max(subtotal - disc, 0)
        customer_name = self.customer.currentText() or 'زبون عام'
        after_debt = ''
        if preview and self.payment.currentText() == 'آجل':
            after_debt = f"\nدين الزبون بعد الفاتورة: {money(preview.get('customer_balance_after', 0))}"
        totals = QLabel(f"الزبون: {customer_name}\nطريقة الدفع: {self.payment.currentText()}\nالإجمالي: {money(subtotal)}\nالخصم: {money(disc)}\nالصافي: {money(total)}{after_debt}")
        totals.setObjectName('bigTotal')
        lay.addWidget(totals)
        buttons = QHBoxLayout()
        ok_btn = QPushButton('تأكيد ومتابعة')
        ok_btn.setObjectName('successButton')
        cancel_btn = QPushButton('عودة للتعديل')
        cancel_btn.setObjectName('warningButton')
        ok_btn.clicked.connect(dlg.accept)
        cancel_btn.clicked.connect(dlg.reject)
        buttons.addWidget(cancel_btn)
        if for_confirm:
            buttons.addWidget(ok_btn)
        lay.addLayout(buttons)
        if for_confirm:
            return dlg.exec() == QDialog.Accepted
        dlg.exec()
        return False

    def complete_sale(self):
        if not self.validate_discount():
            return
        if not self.show_invoice_preview(True):
            return
        try:
            inv = self.service.complete_sale(
                self.cart, self.employee.currentData(), self.customer.currentData(), self.payment.currentText(),
                self.discount.value(), self.note.text(), self.current_user['id'] if self.current_user else None, self.discount_type.currentData(),
            )
        except PermissionError as exc:
            approval = request_manager_approval(self, str(exc))
            if not approval:
                QMessageBox.warning(self, 'تعذر حفظ البيع', str(exc))
                return
            try:
                inv = self.service.complete_sale(
                    self.cart, self.employee.currentData(), self.customer.currentData(), self.payment.currentText(),
                    self.discount.value(), self.note.text(), self.current_user['id'] if self.current_user else None, self.discount_type.currentData(),
                    manager_approval=approval,
                )
            except Exception as approval_exc:
                QMessageBox.warning(self, 'تعذر اعتماد البيع', str(approval_exc))
                return
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر حفظ البيع', str(exc))
            return
        QMessageBox.information(self, 'تم البيع', f'تم حفظ الفاتورة بنجاح\n{inv}')
        if QMessageBox.question(self, 'طباعة', 'هل تريد إنشاء/طباعة الفاتورة الآن؟') == QMessageBox.Yes:
            try:
                path = self.service.print_invoice_html(inv)
                QMessageBox.information(self, 'تم إنشاء الفاتورة', f'تم إنشاء ملف الفاتورة:\n{path}')
            except Exception as exc:
                QMessageBox.warning(self, 'تعذر الطباعة', str(exc))
        self.clear_cart()
        self.page.refresh_all()
        self.notify(f'تم حفظ الفاتورة {inv}')

    def suspend_current_sale(self):
        if not self.validate_discount():
            return
        try:
            hold = self.service.suspend_sale(self.cart, self.employee.currentData(), self.customer.currentData(), self.payment.currentText(), self.discount.value(), self.note.text(), self.current_user['id'] if self.current_user else None)
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر التعليق', str(exc))
            return
        self.clear_cart()
        self.notify(f'تم تعليق الفاتورة {hold}')
        QMessageBox.information(self, 'تم', f'تم تعليق الفاتورة:\n{hold}')


class SalesPage(QWidget):
    def __init__(self, service: AppService, notify, current_user=None):
        super().__init__()
        self.service = service
        self.notify = notify
        self.current_user = current_user
        self.product_rows = []
        self.quick_rows = []
        self.tabs_count = 0
        
        self.build()
        self.refresh_all()

    def build(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(12)

        # ──── LEFT PANEL: Products + Barcode + Quick Buttons ────
        left = QFrame()
        left.setObjectName('surface')
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(12, 12, 12, 12)
        left_layout.setSpacing(8)

        lbl = QLabel('📦 المنتجات')
        lbl.setObjectName('sectionTitle')

        self.barcode_scan = QLineEdit()
        self.barcode_scan.setPlaceholderText('📷 امسح باركود المنتج هنا ثم Enter...')
        self.barcode_scan.setMinimumHeight(38)
        self.barcode_scan.returnPressed.connect(self.scan_barcode_add)

        self.search = QLineEdit()
        self.search.setPlaceholderText('🔍 بحث بالاسم أو الباركود أو الصنف...')
        self.search.setMinimumHeight(38)
        self.search.textChanged.connect(self.refresh_products)

        self.products = Table(['المنتج', 'السعر', 'المخزون', 'الصنف'])
        self.products.doubleClicked.connect(self.add_selected_product)

        # Quick sale buttons section
        quick_box = QFrame()
        quick_box.setObjectName('innerCard')
        quick_l = QVBoxLayout(quick_box)
        quick_l.setContentsMargins(10, 8, 10, 8)
        quick_l.setSpacing(6)
        quick_head = QHBoxLayout()
        quick_title = QLabel('⚡ بيع سريع')
        quick_title.setObjectName('smallSectionTitle')
        self.quick_manage_btn = QPushButton('⚙ إدارة')
        self.quick_manage_btn.setObjectName('primaryButton')
        self.quick_manage_btn.setMaximumWidth(80)
        self.quick_manage_btn.setMinimumHeight(28)
        self.quick_manage_btn.clicked.connect(self.manage_quick_sale_buttons)
        quick_head.addWidget(quick_title)
        quick_head.addStretch()
        quick_head.addWidget(self.quick_manage_btn)
        self.quick_grid = QGridLayout()
        self.quick_grid.setSpacing(6)
        quick_l.addLayout(quick_head)
        quick_l.addLayout(self.quick_grid)

        left_layout.addWidget(lbl)
        left_layout.addWidget(self.barcode_scan)
        left_layout.addWidget(self.search)
        left_layout.addWidget(quick_box)
        left_layout.addWidget(self.products, 1)

        # ──── RIGHT PANEL: TabWidget for invoices ────
        right_container = QWidget()
        right_layout = QVBoxLayout(right_container)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(6)

        tab_header = QHBoxLayout()
        tab_header.setSpacing(10)
        tab_lbl = QLabel('🧾 فواتير المبيعات')
        tab_lbl.setObjectName('sectionTitle')
        self.new_tab_btn = QPushButton('➕ فاتورة جديدة')
        self.new_tab_btn.setObjectName('successButton')
        self.new_tab_btn.setMinimumHeight(36)
        self.new_tab_btn.setCursor(Qt.PointingHandCursor)
        self.new_tab_btn.clicked.connect(self.add_new_invoice_tab)
        tab_header.addWidget(tab_lbl)
        tab_header.addStretch()
        tab_header.addWidget(self.new_tab_btn)

        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.setDocumentMode(True)
        self.tabs.tabCloseRequested.connect(self.close_invoice_tab)

        right_layout.addLayout(tab_header)
        right_layout.addWidget(self.tabs, 1)

        root.addWidget(left, 3)
        root.addWidget(right_container, 7)

        # Add initial tab
        self.add_new_invoice_tab()

    def get_active_tab(self):
        return self.tabs.currentWidget()

    def add_new_invoice_tab(self):
        self.tabs_count += 1
        new_tab = SaleInvoiceTab(self)
        idx = self.tabs.addTab(new_tab, f"فاتورة #{self.tabs_count}")
        self.tabs.setCurrentIndex(idx)

    def close_invoice_tab(self, index):
        if self.tabs.count() <= 1:
            QMessageBox.information(self, 'تنبيه', 'لا يمكن إغلاق آخر فاتورة مفتوحة.')
            return
        
        tab = self.tabs.widget(index)
        if tab and tab.cart:
            reply = QMessageBox.question(self, 'تأكيد الإغلاق', 'تحتوي الفاتورة على منتجات. هل أنت متأكد من إغلاقها ومسح البيانات؟')
            if reply != QMessageBox.Yes:
                return
                
        self.tabs.removeTab(index)
        if tab:
            tab.deleteLater()

    # --- Proxy methods for legacy patches ---
    def complete_sale(self, *args, **kwargs):
        tab = self.get_active_tab()
        if tab: return tab.complete_sale(*args, **kwargs)

    def refresh_cart(self, *args, **kwargs):
        tab = self.get_active_tab()
        if tab: return tab.refresh_cart(*args, **kwargs)

    def refresh_all(self):
        try:
            self.service.ensure_v40_pos_schema()
        except Exception:
            pass
        self.refresh_products()
        self.refresh_quick_sale_buttons()
        # Refresh people in all tabs
        for i in range(self.tabs.count()):
            tab = self.tabs.widget(i)
            if hasattr(tab, 'refresh_people'):
                tab.refresh_people()

    def refresh_products(self):
        self.product_rows = self.service.list_products(self.search.text())
        self.products.setRowCount(len(self.product_rows))
        for r, p in enumerate(self.product_rows):
            self.products.put(r, 0, p['name'], p['id'])
            self.products.put(r, 1, money(p['sale_price']))
            self.products.put(r, 2, p['quantity'])
            self.products.put(r, 3, p['category'] or '')

    def refresh_quick_sale_buttons(self):
        try:
            self.quick_rows = list(self.service.list_quick_sale_products(True))
        except Exception:
            self.quick_rows = []
        while self.quick_grid.count():
            item = self.quick_grid.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        if not self.quick_rows:
            lbl = QLabel('لا توجد أزرار مخصصة بعد. اختر منتجاً ثم اضغط إدارة لإضافته.')
            lbl.setObjectName('mutedText')
            lbl.setWordWrap(True)
            self.quick_grid.addWidget(lbl, 0, 0, 1, 3)
            return
        for i, p in enumerate(self.quick_rows[:12]):
            btn = QPushButton(f"{_safe_get(p, 'name', '')}\n{money(_safe_get(p, 'sale_price', 0))}")
            btn.setObjectName('successButton')
            btn.setMinimumHeight(54)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda checked=False, pid=_safe_get(p, 'id'): self.add_quick_product_to_cart(pid))
            self.quick_grid.addWidget(btn, i // 3, i % 3)

    def add_quick_product_to_cart(self, product_id):
        if not product_id:
            QMessageBox.warning(self, 'زر غير صحيح', 'لم يتم العثور على رقم المنتج المرتبط بهذا الزر.')
            return
        try:
            p = self.service.get_product_for_pos(int(product_id))
        except Exception:
            p = None
        if not p:
            QMessageBox.warning(self, 'المنتج غير متاح', 'هذا المنتج غير موجود أو معطل. افتح إدارة أزرار البيع السريع وحدّث القائمة.')
            self.refresh_quick_sale_buttons()
            return
        self.add_product_to_active_tab(p, 1)

    def scan_barcode_add(self):
        code = self.barcode_scan.text().strip()
        if not code:
            return
        p = self.service.get_product_by_barcode(code)
        if not p:
            QMessageBox.warning(self, 'باركود غير موجود', f'لا يوجد منتج بهذا الباركود:\n{code}')
            self.search.setText(code)
            self.barcode_scan.selectAll()
            return
        
        tab = self.get_active_tab()
        qty = tab.qty.value() if tab else 1
        self.add_product_to_active_tab(p, qty, from_barcode=True)

    def add_selected_product(self):
        row = self.products.currentRow()
        if row < 0 or row >= len(self.product_rows):
            return
            
        tab = self.get_active_tab()
        qty = tab.qty.value() if tab else 1
        self.add_product_to_active_tab(self.product_rows[row], qty)

    def add_product_to_active_tab(self, p, qty=1, from_barcode=False):
        tab = self.get_active_tab()
        if not tab:
            QMessageBox.warning(self, 'لا توجد فاتورة', 'الرجاء فتح فاتورة جديدة أولاً.')
            return

        qty = int(qty)
        available = int(_safe_get(p, 'quantity', 0) or 0)
        if available < qty:
            QMessageBox.warning(self, 'مخزون غير كاف', f"المتوفر من {_safe_get(p, 'name', '')} هو {available}")
            if from_barcode:
                self.barcode_scan.selectAll()
            return
        pid = int(_safe_get(p, 'id'))
        
        for item in tab.cart:
            if item['product_id'] == pid:
                if available < item['quantity'] + qty:
                    QMessageBox.warning(self, 'مخزون غير كاف', 'الكمية المطلوبة أكبر من المخزون')
                    if from_barcode:
                        self.barcode_scan.selectAll()
                    return
                item['quantity'] += qty
                tab.refresh_cart()
                if from_barcode:
                    self.barcode_scan.clear()
                self.notify(f"تمت زيادة كمية {_safe_get(p, 'name', '')} في {self.tabs.tabText(self.tabs.currentIndex())}")
                return
                
        tab.cart.append({
            'product_id': pid, 'product_name': _safe_get(p, 'name', ''), 'quantity': qty,
            'cost_price': float(_safe_get(p, 'cost_price', 0) or 0), 'unit_price': float(_safe_get(p, 'sale_price', 0) or 0),
            'commission_percent': float(_safe_get(p, 'commission_percent', 0) or 0),
        })
        tab.refresh_cart()
        if from_barcode:
            self.barcode_scan.clear()
        self.notify(f"تمت إضافة {_safe_get(p, 'name', '')} إلى {self.tabs.tabText(self.tabs.currentIndex())}")

    def manage_quick_sale_buttons(self):
        # (Same implementation as before, abbreviated here for saving space if needed, 
        # but I will keep it full to ensure nothing is lost)
        dlg = QDialog(self)
        dlg.setWindowTitle('إدارة أزرار البيع السريع')
        dlg.resize(980, 620)
        lay = QVBoxLayout(dlg)

        help_lbl = QLabel('اختر المنتج من القائمة داخل هذه النافذة ثم اضغط إضافة. الأزرار المفعلة تظهر مباشرة في صفحة البيع وتضيف المنتج للفاتورة بضغطة واحدة.')
        help_lbl.setObjectName('noticeBox')
        help_lbl.setWordWrap(True)
        lay.addWidget(help_lbl)

        selector_box = QFrame()
        selector_box.setObjectName('surface')
        selector_l = QHBoxLayout(selector_box)
        selector_l.setContentsMargins(10, 10, 10, 10)
        selector_l.setSpacing(8)
        self.quick_manage_search = QLineEdit()
        self.quick_manage_search.setPlaceholderText('بحث عن منتج لإضافته كزر بيع سريع...')
        self.quick_manage_product = QComboBox()
        self.quick_manage_product.setMinimumWidth(360)
        selector_l.addWidget(QLabel('المنتج'))
        selector_l.addWidget(self.quick_manage_product, 2)
        selector_l.addWidget(self.quick_manage_search, 1)
        lay.addWidget(selector_box)

        top = QHBoxLayout()
        add_btn = QPushButton('➕ إضافة كزر بيع سريع')
        add_btn.setObjectName('successButton')
        remove_btn = QPushButton('تعطيل الزر المحدد')
        remove_btn.setObjectName('dangerButton')
        up_btn = QPushButton('رفع')
        down_btn = QPushButton('خفض')
        refresh_btn = QPushButton('تحديث')
        top.addWidget(add_btn)
        top.addWidget(remove_btn)
        top.addWidget(up_btn)
        top.addWidget(down_btn)
        top.addWidget(refresh_btn)
        top.addStretch()
        lay.addLayout(top)

        table = Table(['ID', 'المنتج', 'السعر', 'المخزون', 'الترتيب'])
        lay.addWidget(table, 1)

        product_rows = []

        def fill_products():
            nonlocal product_rows
            term = self.quick_manage_search.text().strip()
            try:
                product_rows = list(self.service.list_products(term))
            except Exception:
                product_rows = []
            current = self.quick_manage_product.currentData()
            self.quick_manage_product.blockSignals(True)
            self.quick_manage_product.clear()
            for p in product_rows:
                label = f"{_safe_get(p, 'name', '')} | {money(_safe_get(p, 'sale_price', 0))} | المخزون: {_safe_get(p, 'quantity', 0)}"
                self.quick_manage_product.addItem(label, _safe_get(p, 'id'))
            if current:
                idx = self.quick_manage_product.findData(current)
                if idx >= 0:
                    self.quick_manage_product.setCurrentIndex(idx)
            self.quick_manage_product.blockSignals(False)

        def fill():
            rows = list(self.service.list_quick_sale_products(True))
            table.setRowCount(len(rows))
            table._rows = rows
            for r, p in enumerate(rows):
                vals = [_safe_get(p, 'id'), _safe_get(p, 'name'), money(_safe_get(p, 'sale_price', 0)), _safe_get(p, 'quantity'), _safe_get(p, 'sort_order')]
                for c, v in enumerate(vals):
                    table.put(r, c, v, _safe_get(p, 'id') if c == 0 else None)

        def selected_product_id():
            row = table.currentRow()
            if row < 0 or row >= len(getattr(table, '_rows', [])):
                return None
            return _safe_get(table._rows[row], 'id')

        def add_selected():
            pid = self.quick_manage_product.currentData()
            if not pid:
                QMessageBox.information(dlg, 'اختر منتجاً', 'اختر منتجاً من قائمة المنتج أولاً.')
                return
            try:
                self.service.add_quick_sale_product(pid, self.current_user['id'] if self.current_user else None)
                fill()
                self.refresh_quick_sale_buttons()
                self.notify('تمت إضافة زر بيع سريع')
            except Exception as exc:
                QMessageBox.warning(dlg, 'تعذر الإضافة', str(exc))

        def remove_selected():
            pid = selected_product_id()
            if not pid:
                QMessageBox.information(dlg, 'اختر زراً', 'اختر زر بيع سريع من الجدول أولاً.')
                return
            try:
                self.service.remove_quick_sale_product(pid, self.current_user['id'] if self.current_user else None)
                fill()
                self.refresh_quick_sale_buttons()
                self.notify('تم تعطيل زر البيع السريع')
            except Exception as exc:
                QMessageBox.warning(dlg, 'تعذر التعطيل', str(exc))

        def move(direction):
            pid = selected_product_id()
            if not pid:
                QMessageBox.information(dlg, 'اختر زراً', 'اختر زر بيع سريع من الجدول أولاً.')
                return
            try:
                self.service.move_quick_sale_product(pid, direction)
                fill()
                self.refresh_quick_sale_buttons()
            except Exception as exc:
                QMessageBox.warning(dlg, 'تعذر الترتيب', str(exc))

        self.quick_manage_search.textChanged.connect(fill_products)
        add_btn.clicked.connect(add_selected)
        remove_btn.clicked.connect(remove_selected)
        up_btn.clicked.connect(lambda: move('up'))
        down_btn.clicked.connect(lambda: move('down'))
        refresh_btn.clicked.connect(lambda: (fill_products(), fill()))
        fill_products()
        fill()
        close = QPushButton('إغلاق')
        close.clicked.connect(dlg.accept)
        lay.addWidget(close)
        dlg.exec()
