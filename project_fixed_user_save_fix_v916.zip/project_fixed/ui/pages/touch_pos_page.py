from ui.ui_common import *
from ui.pages.sales_page import request_manager_approval

class TouchPOSPage(QWidget):
    def __init__(self, service: AppService, notify, current_user=None):
        super().__init__(); self.service=service; self.notify=notify; self.current_user=current_user; self.cart=[]; self.product_rows=[]; self.build(); self.refresh()
    def build(self):
        root=QHBoxLayout(self); root.setSpacing(12)
        left=QFrame(); left.setObjectName('surface'); ll=QVBoxLayout(left)
        title=QLabel('🖥 شاشة كاشير لمس'); title.setObjectName('sectionTitle')
        self.category=QComboBox(); self.category.currentIndexChanged.connect(self.refresh_products)
        self.search=QLineEdit(); self.search.setPlaceholderText('بحث سريع أو باركود...'); self.search.textChanged.connect(self.refresh_products)
        self.cards=QTableWidget(0,4); self.cards.setObjectName('touchGrid'); self.cards.verticalHeader().hide(); self.cards.horizontalHeader().hide(); self.cards.setEditTriggers(QAbstractItemView.NoEditTriggers); self.cards.cellDoubleClicked.connect(self.add_card)
        ll.addWidget(title); ll.addWidget(self.category); ll.addWidget(self.search); ll.addWidget(self.cards,1)
        right=QFrame(); right.setObjectName('surface'); right.setFixedWidth(380); rl=QVBoxLayout(right)
        self.cart_table=Table(['المادة','كمية','الإجمالي']); self.discount=QDoubleSpinBox(); self.discount.setMaximum(999999999); self.discount.setDecimals(0); self.discount.valueChanged.connect(self.refresh_cart)
        self.employee=QComboBox(); self.customer=QComboBox(); self.payment=QComboBox(); self.payment.addItems(['نقدي','بطاقة','تحويل','آجل'])
        self.total=QLabel('الصافي: 0 د.ع'); self.total.setObjectName('bigTotal')
        sell=QPushButton('✅ بيع سريع'); sell.setObjectName('successButton'); sell.clicked.connect(self.complete)
        hold=QPushButton('⏸ تعليق'); hold.setObjectName('warningButton'); hold.clicked.connect(self.suspend)
        ret=QPushButton('↩ مرتجع'); ret.setObjectName('dangerButton'); ret.clicked.connect(lambda: self.notify('افتح صفحة المرتجعات لإتمام العملية'))
        clear=QPushButton('مسح'); clear.clicked.connect(self.clear)
        form=QFormLayout(); form.addRow('موظف العمولة', self.employee); form.addRow('الزبون', self.customer); form.addRow('الدفع', self.payment); form.addRow('الخصم', self.discount)
        rl.addWidget(QLabel('فاتورة اللمس')); rl.addWidget(self.cart_table,1); rl.addLayout(form); rl.addWidget(self.total); rl.addWidget(sell); rl.addWidget(hold); rl.addWidget(ret); rl.addWidget(clear)
        root.addWidget(left,1); root.addWidget(right)
    def refresh(self): self.refresh_people(); self.refresh_products(); self.refresh_cart()
    def refresh_people(self):
        self.employee.clear(); emp_id=None
        if self.current_user:
            try: emp_id, name = self.service.ensure_employee_for_user(self.current_user); self.employee.addItem(f'المستخدم الحالي: {name}', emp_id)
            except Exception as exc:
                log_exception(exc)
        for e in self.service.list_employees():
            if emp_id and e['id']==emp_id: continue
            self.employee.addItem(e['name'], e['id'])
        self.customer.clear()
        for c in self.service.list_customers(): self.customer.addItem(c['name'], c['id'])
        cats=['كل التصنيفات']+sorted({(p['category'] or 'بدون صنف') for p in self.service.list_products('')})
        cur=self.category.currentText(); self.category.blockSignals(True); self.category.clear(); self.category.addItems(cats); self.category.setCurrentText(cur if cur in cats else cats[0]); self.category.blockSignals(False)
    def refresh_products(self):
        rows=self.service.list_products(self.search.text()); cat=self.category.currentText()
        if cat and cat!='كل التصنيفات': rows=[p for p in rows if (p['category'] or 'بدون صنف')==cat]
        self.product_rows=rows; cols=4; self.cards.setColumnCount(cols); self.cards.setRowCount((len(rows)+cols-1)//cols)
        for r in range(self.cards.rowCount()):
            self.cards.setRowHeight(r,95)
            for c in range(cols): self.cards.setColumnWidth(c,190); self.cards.setItem(r,c,QTableWidgetItem(''))
        for i,p in enumerate(rows):
            item=QTableWidgetItem(f"{p['name']}\n{money(p['sale_price'])}\nالمخزون: {p['quantity']}"); item.setData(Qt.UserRole,i); item.setTextAlignment(Qt.AlignCenter); self.cards.setItem(i//cols,i%cols,item)
    def add_card(self,row,col):
        item=self.cards.item(row,col)
        if not item or item.data(Qt.UserRole) is None: return
        p=self.product_rows[item.data(Qt.UserRole)]
        if p['quantity']<=0: QMessageBox.warning(self,'نفاد','هذا المنتج نافد'); return
        for it in self.cart:
            if it['product_id']==p['id']: it['quantity']+=1; self.refresh_cart(); return
        self.cart.append({'product_id':p['id'],'product_name':p['name'],'quantity':1,'cost_price':float(p['cost_price']),'unit_price':float(p['sale_price']),'commission_percent':float(p['commission_percent'])}); self.refresh_cart()
    def subtotal(self):
        return sum(it['quantity']*it['unit_price'] for it in self.cart)
    def validate_discount(self):
        subtotal = self.subtotal()
        discount = float(self.discount.value() or 0)
        if not self.cart:
            return True
        if discount > subtotal:
            QMessageBox.warning(self,'خصم غير صحيح',f'قيمة الخصم أكبر من إجمالي الفاتورة.\nإجمالي الفاتورة: {money(subtotal)}\nالخصم المدخل: {money(discount)}')
            return False
        if discount >= subtotal and subtotal > 0:
            QMessageBox.warning(self,'خصم غير صحيح','الخصم لا يمكن أن يساوي أو يتجاوز قيمة الفاتورة')
            return False
        return True
    def refresh_cart(self):
        self.cart_table.setRowCount(len(self.cart)); subtotal=0
        for r,it in enumerate(self.cart):
            line=it['quantity']*it['unit_price']; subtotal+=line
            for c,v in enumerate([it['product_name'], it['quantity'], money(line)]): self.cart_table.put(r,c,v)
        discount = float(self.discount.value() or 0)
        self.total.setText(f'الإجمالي: {money(subtotal)}\nالخصم: {money(discount)}\nالصافي: {money(max(subtotal-discount,0))}')
    def clear(self): self.cart.clear(); self.discount.setValue(0); self.refresh_cart(); self.refresh_products()
    def complete(self):
        if not self.validate_discount(): return
        try:
            inv=self.service.complete_sale(self.cart,self.employee.currentData(),self.customer.currentData(),self.payment.currentText(),self.discount.value(),'بيع لمس',self.current_user['id'] if self.current_user else None,'amount')
        except PermissionError as exc:
            approval = request_manager_approval(self, str(exc))
            if not approval:
                QMessageBox.warning(self,'تعذر البيع',str(exc)); return
            try:
                inv=self.service.complete_sale(self.cart,self.employee.currentData(),self.customer.currentData(),self.payment.currentText(),self.discount.value(),'بيع لمس',self.current_user['id'] if self.current_user else None,'amount', manager_approval=approval)
            except Exception as approval_exc:
                QMessageBox.warning(self,'تعذر اعتماد البيع',str(approval_exc)); return
        except Exception as exc:
            QMessageBox.warning(self,'تعذر البيع',str(exc)); return
        QMessageBox.information(self,'تم',f'تم حفظ الفاتورة {inv}'); self.clear(); self.refresh(); self.notify(f'تم حفظ فاتورة لمس {inv}')
    def suspend(self):
        if not self.validate_discount(): return
        try: hold=self.service.suspend_sale(self.cart,self.employee.currentData(),self.customer.currentData(),self.payment.currentText(),self.discount.value(),'تعليق من شاشة لمس',self.current_user['id'] if self.current_user else None)
        except Exception as exc: QMessageBox.warning(self,'تعذر التعليق',str(exc)); return
        self.clear(); QMessageBox.information(self,'تم',f'تم تعليق الفاتورة {hold}')
