from ui.ui_common import *

class ReturnsPage(QWidget):
    def __init__(self, service: AppService, notify, current_user=None):
        super().__init__(); self.service = service; self.notify = notify; self.current_user = current_user; self.sale = None; self.items = []
        self.build(); self.refresh()

    def build(self):
        root = QVBoxLayout(self); root.setSpacing(12)
        top = QFrame(); top.setObjectName('surface'); top_l = QHBoxLayout(top)
        self.invoice = QLineEdit(); self.invoice.setPlaceholderText('اكتب رقم الفاتورة مثل MAX-...')
        search = QPushButton('🔍 بحث عن الفاتورة'); search.setObjectName('primaryButton'); search.clicked.connect(self.search_invoice)
        self.info = QLabel('ابحث عن الفاتورة لإظهار المواد القابلة للإرجاع')
        self.info.setObjectName('noticeBox')
        top_l.addWidget(self.info, 2); top_l.addWidget(search); top_l.addWidget(self.invoice, 2)
        middle = QHBoxLayout()
        left = QFrame(); left.setObjectName('surface'); left_l = QVBoxLayout(left)
        title = QLabel('↩ مواد الفاتورة')
        title.setObjectName('sectionTitle')
        self.items_table = Table(['المادة', 'المباع', 'راجع سابقاً', 'المتبقي', 'السعر'])
        self.items_table.doubleClicked.connect(self.set_max_return_qty)
        form = QHBoxLayout()
        self.return_qty = QSpinBox(); self.return_qty.setRange(1, 999999)
        self.reason = QLineEdit(); self.reason.setPlaceholderText('سبب الإرجاع / ملاحظة')
        self.refund_method = QComboBox(); self.refund_method.addItems(['نقدي', 'رصيد للزبون', 'استبدال'])
        ret_item = QPushButton('إرجاع المادة المحددة'); ret_item.setObjectName('dangerButton'); ret_item.clicked.connect(self.return_selected)
        ret_full = QPushButton('إرجاع كامل الفاتورة'); ret_full.setObjectName('dangerButton'); ret_full.clicked.connect(self.return_full)
        form.addWidget(ret_full); form.addWidget(ret_item); form.addWidget(self.refund_method); form.addWidget(self.reason); form.addWidget(QLabel('الكمية')); form.addWidget(self.return_qty)
        left_l.addWidget(title); left_l.addWidget(self.items_table, 1); left_l.addLayout(form)
        right = QFrame(); right.setObjectName('surface'); right_l = QVBoxLayout(right)
        r_title = QLabel('سجل المرتجعات')
        r_title.setObjectName('sectionTitle')
        self.returns_table = Table(['رقم الإرجاع', 'الفاتورة', 'المادة', 'الكمية', 'المبلغ', 'الموظف', 'المستخدم', 'التاريخ'])
        right_l.addWidget(r_title); right_l.addWidget(self.returns_table, 1)
        middle.addWidget(left, 3); middle.addWidget(right, 4)
        root.addWidget(top); root.addLayout(middle, 1)

    def search_invoice(self):
        try:
            self.sale, self.items = self.service.find_sale_for_return(self.invoice.text())
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر البحث', str(exc)); return
        self.info.setText(f"الفاتورة: {self.sale['invoice_no']} | الموظف: {self.sale['employee']} | الزبون: {self.sale['customer']} | الصافي الحالي: {money(self.sale['total'])}")
        self.items_table.setRowCount(len(self.items))
        for r, item in enumerate(self.items):
            vals = [item['product_name'], item['quantity'], item['returned_qty'], item['remaining_qty'], money(item['unit_price'])]
            for c, v in enumerate(vals): self.items_table.put(r, c, v, item['id'] if c == 0 else None)
        self.set_max_return_qty()

    def set_max_return_qty(self):
        row = self.items_table.currentRow()
        if 0 <= row < len(self.items):
            remaining = int(self.items[row]['remaining_qty'])
            self.return_qty.setMaximum(max(remaining, 1)); self.return_qty.setValue(max(1, remaining))

    def return_selected(self):
        row = self.items_table.currentRow()
        if row < 0 or row >= len(self.items):
            QMessageBox.warning(self, 'تنبيه', 'اختر مادة من الفاتورة أولاً'); return
        try:
            ret = self.service.return_item(self.items[row]['id'], self.return_qty.value(), self.reason.text(), self.current_user['id'] if self.current_user else None, self.refund_method.currentText())
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر الإرجاع', str(exc)); return
        
        if QMessageBox.question(self, 'طباعة', 'هل تريد إنشاء وصل مرتجع؟') == QMessageBox.Yes:
            try:
                path = self.service.print_return_html(ret); QMessageBox.information(self, 'تم', f'تم إنشاء وصل المرتجع:\n{path}')
            except Exception as exc:
                QMessageBox.warning(self, 'تعذر الطباعة', str(exc))
        self.notify(f'تم تسجيل المرتجع {ret}'); self.search_invoice(); self.refresh()

    def return_full(self):
        if not self.sale:
            QMessageBox.warning(self, 'تنبيه', 'ابحث عن فاتورة أولاً'); return
        if QMessageBox.question(self, 'تأكيد', 'هل تريد إرجاع كل المواد المتبقية في هذه الفاتورة؟') != QMessageBox.Yes:
            return
        try:
            nums = self.service.return_full_sale(self.sale['id'], self.reason.text(), self.current_user['id'] if self.current_user else None, self.refund_method.currentText())
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر الإرجاع', str(exc)); return
        self.notify(f'تم تسجيل {len(nums)} مرتجع'); self.search_invoice(); self.refresh()

    def refresh(self):
        rows = self.service.list_returns()
        self.returns_table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            vals = [row['return_no'], row['invoice_no'], row['product_name'], row['quantity'], money(row['amount']), row['employee'], row['created_by'], row['created_at']]
            for c, v in enumerate(vals): self.returns_table.put(r, c, v)
