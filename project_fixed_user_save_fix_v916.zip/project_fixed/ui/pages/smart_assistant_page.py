from ui.ui_common import *

class SmartAssistantPage(QWidget):
    """Local AI-like assistant: deterministic analysis, no internet required."""
    def __init__(self, service: AppService, notify, current_user=None):
        super().__init__()
        self.service = service
        self.notify = notify
        self.current_user = current_user
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        title = QLabel('🤖 المساعد الذكي المحلي')
        title.setObjectName('sectionTitle')
        subtitle = QLabel('تحليل ذكي يعمل داخل البرنامج بدون إنترنت: مبيعات، مخزون، أرباح، موظفون، وتنبيهات رقابية.')
        subtitle.setObjectName('noticeBox')
        subtitle.setWordWrap(True)
        root.addWidget(title)
        root.addWidget(subtitle)

        actions = QHBoxLayout()
        buttons = [
            ('تقرير يومي ذكي', self.run_daily_summary),
            ('توقع المخزون', self.run_stock_forecast),
            ('اقتراح شراء', self.run_purchase_suggestions),
            ('منتجات راكدة', self.run_stale_products),
            ('تحليل الأرباح', self.run_profit_analysis),
            ('أداء الموظفين', self.run_employee_analysis),
            ('كشف أخطاء/تلاعب', self.run_anomaly_scan),
            ('تقرير شامل', self.run_full_report),
        ]
        for text, fn in buttons:
            b = QPushButton(text)
            b.setObjectName('primaryButton')
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(fn)
            actions.addWidget(b)
        root.addLayout(actions)

        self.tabs = QTabWidget()
        self.output = QTextEdit(); self.output.setReadOnly(True); self.output.setMinimumHeight(220)
        self.table = Table(['البند', 'القيمة 1', 'القيمة 2', 'الحالة/الملاحظة'])
        tab_text = QWidget(); t_l = QVBoxLayout(tab_text); t_l.addWidget(self.output)
        tab_table = QWidget(); tb_l = QVBoxLayout(tab_table); tb_l.addWidget(self.table)
        self.tabs.addTab(tab_text, 'التحليل النصي')
        self.tabs.addTab(tab_table, 'نتائج جدولية')
        root.addWidget(self.tabs, 1)
        self.refresh()

    def refresh(self):
        self.run_full_report()

    def set_output(self, text: str):
        self.output.setPlainText(text)
        self.tabs.setCurrentIndex(0)

    def fill_table(self, headers: list[str], rows: list[list[object]]):
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, val in enumerate(row):
                self.table.put(r, c, val)
        self.tabs.setCurrentIndex(1)

    def run_daily_summary(self):
        try:
            self.set_output(self.service.ai_daily_summary())
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر التحليل', str(exc))

    def run_full_report(self):
        try:
            self.set_output(self.service.ai_full_report())
        except Exception as exc:
            self.set_output(f'تعذر إنشاء التقرير الذكي: {exc}')

    def run_stock_forecast(self):
        try:
            rows = self.service.ai_stock_forecast()
            self.fill_table(['المنتج', 'المتوفر', 'مبيع 30 يوم', 'أيام متوقعة', 'الحالة', 'مقترح شراء'],
                            [[r['name'], f"{r['quantity']:.0f}", f"{r['sold_30']:.0f}", r['days_left'], r['risk'], r['suggested']] for r in rows])
            self.output.setPlainText('توقع المخزون يعتمد على مبيعات آخر 30 يوم. المنتجات الأخطر تظهر أولاً.')
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر التحليل', str(exc))

    def run_purchase_suggestions(self):
        try:
            rows = self.service.ai_purchase_suggestions()
            self.fill_table(['المنتج', 'الباركود', 'المتوفر', 'مبيع 30 يوم', 'الحالة', 'اشترِ تقريباً'],
                            [[r['name'], r['barcode'], f"{r['quantity']:.0f}", f"{r['sold_30']:.0f}", r['risk'], r['suggested']] for r in rows])
            self.output.setPlainText('اقتراح الشراء تقديري، ويعتمد على الحركة السابقة ولا يغني عن قرار المدير.')
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر التحليل', str(exc))

    def run_stale_products(self):
        try:
            rows = self.service.ai_stale_products()
            self.fill_table(['المنتج', 'الصنف', 'الكمية', 'سعر البيع', 'آخر بيع'],
                            [[r['name'], r['category'], r['quantity'], money(r['sale_price']), r['last_sale']] for r in rows])
            self.output.setPlainText('المنتجات الراكدة هي التي لم تُبع منذ فترة طويلة أو لا تظهر لها حركة بيع.')
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر التحليل', str(exc))

    def run_profit_analysis(self):
        try:
            p = self.service.ai_profit_analysis()
            rows = [
                ['المبيعات الصافية', money(p.get('net_sales', p.get('net_sales_total', 0))), '', ''],
                ['الربح قبل المصاريف', money(p.get('gross_profit', 0)), '', ''],
                ['المصاريف', money(p.get('expenses', p.get('expense_total', 0))), '', ''],
                ['صافي الربح', money(p.get('net_profit', 0)), '', 'راجع السعر والمصاريف إذا كان منخفضاً'],
            ]
            self.fill_table(['البند', 'القيمة', 'مقارنة', 'ملاحظة'], rows)
            self.output.setPlainText('تحليل الأرباح يوضح أثر الخصومات والمرتجعات والمصاريف على صافي الربح.')
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر التحليل', str(exc))

    def run_employee_analysis(self):
        try:
            rows = self.service.ai_employee_analysis()
            self.fill_table(['الموظف', 'الفواتير', 'المبيعات آخر 30 يوم', 'العمولة', 'المرتجعات', 'ملاحظة'],
                            [[r['name'], r['invoices'], money(r['total']), money(r['commission']), money(r['returns_total']), r['note']] for r in rows])
            self.output.setPlainText('تحليل أداء الموظفين يساعدك بمراجعة المبيعات والعمولات والمرتجعات.')
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر التحليل', str(exc))

    def run_anomaly_scan(self):
        try:
            alerts = self.service.ai_anomaly_alerts()
            self.set_output('مؤشرات تحتاج مراجعة:\n' + '\n'.join('• ' + a for a in alerts))
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر الفحص', str(exc))
