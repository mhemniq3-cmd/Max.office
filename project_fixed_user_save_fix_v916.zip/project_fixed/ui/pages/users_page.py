from ui.ui_common import *

try:
    import shiboken6
except Exception:  # pragma: no cover - PySide may be unavailable in tests
    shiboken6 = None


class UsersPage(QWidget):
    """Modern, role-template based user-management screen."""

    def __init__(self, service: AppService, notify):
        super().__init__()
        self.service = service
        self.notify = notify
        self.user_id: int | None = None
        self.rows = []
        self.checks: dict[str, QCheckBox] = {}
        self.build()
        self.refresh()

    def build(self):
        root = QHBoxLayout(self)
        root.setSpacing(14)
        root.setContentsMargins(10, 10, 10, 10)

        left = QFrame(); left.setObjectName('surface')
        left_l = QVBoxLayout(left)
        left_l.setContentsMargins(14, 14, 14, 14)
        title = QLabel('👤 إدارة المستخدمين والصلاحيات')
        title.setObjectName('sectionTitle')
        subtitle = QLabel('اختر دور المستخدم ليتم تطبيق قالب آمن تلقائياً: كاشير، موظف مبيعات، أو مدير.')
        subtitle.setObjectName('mutedText')
        self.table = Table(['المستخدم', 'الاسم الكامل', 'الدور', 'خصم', 'حد الخصم', 'أقل من التكلفة', 'أدوات', 'الحالة'])
        self.table.doubleClicked.connect(self.load_selected)
        left_l.addWidget(title)
        left_l.addWidget(subtitle)
        left_l.addWidget(self.table, 1)

        right_scroll = QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_scroll.setFixedWidth(560)
        right_scroll.setObjectName('cleanScroll')
        right = QFrame(); right.setObjectName('surface')
        right_scroll.setWidget(right)
        r_l = QVBoxLayout(right)
        r_l.setContentsMargins(16, 16, 16, 16)
        r_l.setSpacing(12)

        account_box = self._card('🟢 البيانات الأساسية')
        account_l = account_box.layout()
        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        form.setFormAlignment(Qt.AlignTop)
        form.setHorizontalSpacing(14)
        form.setVerticalSpacing(10)
        self.username = QLineEdit(); self.username.setPlaceholderText('مثال: cashier1')
        self.full_name = QLineEdit(); self.full_name.setPlaceholderText('الاسم الكامل')
        self.password = QLineEdit(); self.password.setEchoMode(QLineEdit.Password); self.password.setPlaceholderText('مطلوبة عند الإضافة، اختيارية عند التعديل')
        self.role = QComboBox(); self.role.addItems(self.service.roles()); self.role.currentTextChanged.connect(self.apply_role_permissions)
        form.addRow('اسم الدخول', self.username)
        form.addRow('الاسم الكامل', self.full_name)
        form.addRow('كلمة المرور', self.password)
        form.addRow('نوع الحساب', self.role)
        account_l.addLayout(form)

        price_box = self._card('🔵 رؤية الأسعار والأرباح')
        price_l = QGridLayout()
        price_l.setHorizontalSpacing(12); price_l.setVerticalSpacing(8)
        self._add_check(price_l, 'can_view_cost', 'عرض سعر التكلفة', 0, 0)
        self._add_check(price_l, 'can_view_profit', 'عرض الأرباح والهامش', 0, 1)
        self._add_check(price_l, 'can_reports', 'عرض التقارير', 1, 0)
        self._add_check(price_l, 'can_products', 'عرض المنتجات', 1, 1)
        price_box.layout().addLayout(price_l)

        discount_box = self._card('🟡 نظام الخصومات الذكي')
        discount_l = QGridLayout()
        discount_l.setHorizontalSpacing(12); discount_l.setVerticalSpacing(8)
        self._add_check(discount_l, 'can_discount', 'السماح بتطبيق الخصم', 0, 0)
        self._add_check(discount_l, 'can_discount_limit', 'خصم خاص / موافقة مدير', 0, 1)
        self._add_check(discount_l, 'can_discount_below_cost', 'السماح بالبيع بأقل من التكلفة', 1, 0, 1, 2)
        self.max_discount_percent = QDoubleSpinBox()
        self.max_discount_percent.setRange(0, 100)
        self.max_discount_percent.setDecimals(2)
        self.max_discount_percent.setSuffix(' %')
        self.max_discount_percent.setSingleStep(1)
        discount_l.addWidget(QLabel('الحد الأقصى للخصم'), 2, 0)
        discount_l.addWidget(self.max_discount_percent, 2, 1)
        note = QLabel('مثال: الكاشير 10%، موظف المبيعات 15%، المدير 100%. لا يسمح بالبيع بأقل من التكلفة إلا لمن يملك الصلاحية الخاصة.')
        note.setObjectName('noticeBox'); note.setWordWrap(True)
        discount_box.layout().addLayout(discount_l)
        discount_box.layout().addWidget(note)

        admin_box = self._card('🔴 الصلاحيات الإدارية')
        admin_l = QGridLayout()
        admin_l.setHorizontalSpacing(12); admin_l.setVerticalSpacing(8)
        admin_keys = [
            ('can_sales', 'شاشة المبيعات'),
            ('can_touch_pos', 'كاشير لمس'),
            ('can_customers', 'الزبائن'),
            ('can_returns', 'المرتجعات'),
            ('can_product_add', 'إضافة منتج'),
            ('can_product_edit', 'تعديل منتج'),
            ('can_product_delete', 'حذف منتج'),
            ('can_inventory', 'المخزون والجرد'),
            ('can_tools', 'قائمة الأدوات'),
            ('can_settings', 'الإعدادات'),
            ('can_backup', 'نسخ احتياطي'),
            ('can_restore', 'استعادة نسخة'),
            ('can_users', 'إدارة المستخدمين'),
            ('can_audit', 'سجل التدقيق'),
            ('can_price_edit', 'تعديل السعر'),
            ('can_quantity_edit', 'تعديل الكمية'),
            ('can_return_full', 'إرجاع كامل'),
            ('can_print', 'طباعة'),
            ('can_suppliers', 'الموردون'),
            ('can_purchases', 'المشتريات'),
            ('can_goals', 'أهداف الموظفين'),
            ('can_dashboard', 'الرئيسية'),
        ]
        row = col = 0
        for key, label in admin_keys:
            if key in self.checks:
                continue
            self._add_check(admin_l, key, label, row, col)
            col += 1
            if col >= 2:
                col = 0; row += 1
        admin_box.layout().addLayout(admin_l)

        actions = QFrame(); actions.setObjectName('subCard')
        actions_l = QGridLayout(actions)
        save = QPushButton('💾 حفظ الإعدادات'); save.setObjectName('primaryButton'); save.clicked.connect(self.save)
        new = QPushButton('➕ مستخدم جديد'); new.setObjectName('successButton'); new.clicked.connect(self.clear)
        apply_template = QPushButton('🔄 تطبيق القالب على هذا المستخدم'); apply_template.setObjectName('warningButton'); apply_template.clicked.connect(self.apply_role_permissions)
        apply_all = QPushButton('🔄 تطبيق الإعدادات الافتراضية على جميع المستخدمين'); apply_all.setObjectName('warningButton'); apply_all.clicked.connect(self.apply_all_templates)
        deactivate = QPushButton('⛔ تعطيل المستخدم'); deactivate.setObjectName('dangerButton'); deactivate.clicked.connect(self.deactivate)
        actions_l.addWidget(save, 0, 0, 1, 2)
        actions_l.addWidget(new, 1, 0)
        actions_l.addWidget(deactivate, 1, 1)
        actions_l.addWidget(apply_template, 2, 0, 1, 2)
        actions_l.addWidget(apply_all, 3, 0, 1, 2)

        hint = QLabel('الحماية الفعلية مرتبطة بهذه القيم: إذا أوقفت الخصم فلن يقبل أي خصم، وإذا سمحت به فهو مقيد بالنسبة ولا ينزل تحت التكلفة إلا للمدير.')
        hint.setObjectName('noticeBox'); hint.setWordWrap(True)

        r_l.addWidget(account_box)
        r_l.addWidget(price_box)
        r_l.addWidget(discount_box)
        r_l.addWidget(admin_box)
        r_l.addWidget(hint)
        r_l.addWidget(actions)
        r_l.addStretch()
        root.addWidget(left, 1)
        root.addWidget(right_scroll)
        self.apply_role_permissions()

    def _card(self, title: str) -> QFrame:
        frame = QFrame(); frame.setObjectName('subCard')
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)
        lbl = QLabel(title); lbl.setObjectName('miniTitle')
        layout.addWidget(lbl)
        return frame

    def _add_check(self, layout: QGridLayout, key: str, label: str, row: int, col: int, rowspan: int = 1, colspan: int = 1):
        cb = QCheckBox(label)
        cb.setMinimumHeight(28)
        self.checks[key] = cb
        layout.addWidget(cb, row, col, rowspan, colspan)
        return cb

    def _is_live_widget(self, widget) -> bool:
        if widget is None:
            return False
        try:
            if shiboken6 is not None and not shiboken6.isValid(widget):
                return False
            # A harmless call that raises RuntimeError when the wrapped C++
            # object was already deleted by Qt/layout rebuilding patches.
            widget.objectName()
            return True
        except RuntimeError:
            return False
        except Exception:
            return False

    def _live_checks(self):
        live = {}
        dead = []
        for key, cb in list(self.checks.items()):
            if self._is_live_widget(cb):
                live[key] = cb
            else:
                dead.append(key)
        for key in dead:
            self.checks.pop(key, None)
        return live

    def _safe_set_check(self, key: str, value: bool) -> None:
        cb = self._live_checks().get(key)
        if cb is not None:
            cb.setChecked(bool(value))

    def _role_template(self):
        if hasattr(self.service, 'role_template'):
            return self.service.role_template(self.role.currentText())
        return {'permissions': self.service.role_permissions(self.role.currentText()), 'max_discount_percent': 10, 'can_discount_below_cost': 0}

    def apply_role_permissions(self):
        template = self._role_template()
        perms = template.get('permissions', {})
        for key, cb in self._live_checks().items():
            cb.setChecked(bool(perms.get(key, 0)))
        self.max_discount_percent.setValue(float(template.get('max_discount_percent', 0) or 0))
        self._safe_set_check('can_discount_below_cost', bool(template.get('can_discount_below_cost', perms.get('can_discount_below_cost', 0))))

    def refresh(self):
        self.rows = self.service.list_users()
        self.table.setRowCount(len(self.rows))
        for r, u in enumerate(self.rows):
            vals = [
                u['username'],
                u['full_name'] or '',
                u['role'],
                'نعم' if u['can_discount'] else 'لا',
                f"{float(u['max_discount_percent'] or 0):.0f}%" if 'max_discount_percent' in u.keys() else '—',
                'نعم' if ('can_discount_below_cost' in u.keys() and u['can_discount_below_cost']) else 'لا',
                'نعم' if u['can_tools'] else 'لا',
                'نشط' if u['active'] else 'معطل',
            ]
            for c, v in enumerate(vals):
                self.table.put(r, c, v, u['id'] if c == 0 else None)

    def load_selected(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.rows):
            return
        u = self.rows[row]
        self.user_id = u['id']
        self.username.setText(u['username'])
        self.full_name.setText(u['full_name'] or '')
        self.password.clear()
        self.role.blockSignals(True)
        self.role.setCurrentText(u['role'] if u['role'] in [self.role.itemText(i) for i in range(self.role.count())] else 'كاشير')
        self.role.blockSignals(False)
        for key, cb in self._live_checks().items():
            cb.setChecked(bool(u[key]) if key in u.keys() else False)
        if 'max_discount_percent' in u.keys():
            self.max_discount_percent.setValue(float(u['max_discount_percent'] or 0))
        else:
            self.max_discount_percent.setValue(float(self._role_template().get('max_discount_percent', 0) or 0))

    def clear(self):
        self.user_id = None
        self.username.clear()
        self.full_name.clear()
        self.password.clear()
        self.role.setCurrentText('كاشير')
        self.apply_role_permissions()

    def save(self):
        try:
            data = {
                'username': self.username.text(),
                'full_name': self.full_name.text(),
                'password': self.password.text(),
                'role': self.role.currentText(),
                'max_discount_percent': self.max_discount_percent.value(),
            }
            for key, cb in self._live_checks().items():
                data[key] = cb.isChecked()
            self.service.save_user(data, self.user_id)
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر الحفظ', str(exc))
            return
        self.clear()
        self.refresh()
        self.notify('تم حفظ المستخدم')

    def apply_all_templates(self):
        if QMessageBox.question(self, 'تأكيد', 'تطبيق قوالب الصلاحيات الافتراضية على جميع المستخدمين الحاليين؟') != QMessageBox.Yes:
            return
        try:
            count = self.service.apply_default_role_templates_to_users()
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر التطبيق', str(exc))
            return
        self.refresh()
        self.notify(f'تم تحديث {count} مستخدم')

    def deactivate(self):
        if not self.user_id:
            return
        if QMessageBox.question(self, 'تأكيد', 'تعطيل هذا المستخدم؟') != QMessageBox.Yes:
            return
        try:
            self.service.deactivate_user(self.user_id)
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر التعطيل', str(exc))
            return
        self.clear()
        self.refresh()
        self.notify('تم تعطيل المستخدم')
