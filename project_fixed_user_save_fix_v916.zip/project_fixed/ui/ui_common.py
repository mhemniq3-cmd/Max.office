from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from PySide6.QtCore import Qt, QTimer
try:
    from PySide6.QtPrintSupport import QPrinterInfo, QPrinter
except Exception:
    QPrinterInfo = None
    QPrinter = None
from PySide6.QtGui import QTextDocument
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QInputDialog,
    QTabWidget,
    QDoubleSpinBox,
    QFormLayout,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from database import money
from services.app_service import AppService
from services.error_logger import log_exception


PERM_LABELS = {
    'can_dashboard': 'الرئيسية',
    'can_sales': 'البيع',
    'can_products': 'المنتجات',
    'can_customers': 'الزبائن',
    'can_returns': 'المرتجعات',
    'can_reports': 'التقارير',
    'can_users': 'المستخدمون',
    'can_tools': 'الأدوات',
    'can_product_add': 'إضافة منتج',
    'can_product_edit': 'تعديل منتج',
    'can_product_delete': 'حذف منتج',
    'can_view_cost': 'عرض التكلفة',
    'can_view_profit': 'عرض الربح',
    'can_return_full': 'إرجاع كامل',
    'can_discount': 'خصم',
    'can_print': 'طباعة',
    'can_backup': 'نسخ احتياطي',
    'can_restore': 'استرجاع نسخة',
    'can_settings': 'الإعدادات',
    'can_inventory': 'جرد ومخزون',
    'can_suppliers': 'الموردون',
    'can_purchases': 'المشتريات',
    'can_touch_pos': 'كاشير لمس',
    'can_price_edit': 'تعديل السعر',
    'can_quantity_edit': 'تعديل الكمية',
    'can_discount_limit': 'خصم خاص / موافقة مدير',
    'can_discount_below_cost': 'السماح بالبيع بأقل من التكلفة',
    'can_goals': 'أهداف الموظفين',
    'can_audit': 'سجل التدقيق',
}

PAGE_PERMISSION = {
    'dashboard': 'can_dashboard',
    'sales': 'can_sales',
    'products': 'can_products',
    'customers': 'can_customers',
    'returns': 'can_returns',
    'reports': 'can_reports',
    'users': 'can_users',
    'tools': 'can_tools',
    'touch_pos': 'can_touch_pos',
    'suppliers': 'can_suppliers',
    'ai': 'can_reports',
}

COUNT_GOAL_TYPES = {'عدد فواتير', 'عدد منتجات مباعة', 'بيع منتج معين'}

def goal_value_unit(goal_type: str) -> str:
    goal_type = goal_type or ''
    if goal_type == 'عدد فواتير':
        return 'فاتورة'
    if goal_type in ('عدد منتجات مباعة', 'بيع منتج معين'):
        return 'قطعة'
    return 'د.ع'

def is_count_goal(goal_type: str) -> bool:
    return (goal_type or '') in COUNT_GOAL_TYPES

def format_goal_value(value, goal_type: str) -> str:
    try:
        v = float(value or 0)
    except Exception:
        v = 0.0
    if is_count_goal(goal_type):
        unit = goal_value_unit(goal_type)
        if abs(v - int(v)) < 0.0001:
            return f'{int(v):,} {unit}'
        return f'{v:,.2f} {unit}'
    return money(v)


class Table(QTableWidget):
    def __init__(self, headers: list[str], parent: QWidget | None = None):
        super().__init__(0, len(headers), parent)
        self.setHorizontalHeaderLabels(headers)
        self.setAlternatingRowColors(True)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setSelectionMode(QAbstractItemView.SingleSelection)
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.verticalHeader().setVisible(False)
        self.horizontalHeader().setStretchLastSection(True)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.setWordWrap(False)
        self.setShowGrid(False)

    def put(self, row: int, col: int, text: object, data: object | None = None) -> QTableWidgetItem:
        item = QTableWidgetItem(str(text))
        item.setTextAlignment(Qt.AlignCenter)
        if data is not None:
            item.setData(Qt.UserRole, data)
        self.setItem(row, col, item)
        return item


class MetricCard(QFrame):
    def __init__(self, title: str, value: str = '0', accent_class: str = 'primary'):
        super().__init__()
        self.setObjectName('metricCard')
        self.setProperty('accent', accent_class)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        self.title = QLabel(title)
        self.title.setObjectName('metricTitle')
        self.value = QLabel(value)
        self.value.setObjectName('metricValue')
        self.value.setAlignment(Qt.AlignRight)
        layout.addWidget(self.title)
        layout.addWidget(self.value)

    def set_value(self, value: str) -> None:
        self.value.setText(value)



def export_pdf_from_html(title: str, html_body: str, base_name: str) -> Path:
    """Create a PDF report using Qt printer engine, preserving Arabic text."""
    out = Path('exports') / 'pdf'
    out.mkdir(parents=True, exist_ok=True)
    safe = ''.join(ch if ch.isalnum() or ch in ('_', '-') else '_' for ch in base_name)[:80]
    path = out / f'{safe}.pdf'
    if QPrinter is None:
        # Fallback: keep content as HTML if PDF engine is not available.
        html_path = out / f'{safe}.html'
        html_path.write_text(html_body, encoding='utf-8')
        return html_path
    doc = QTextDocument()
    doc.setHtml(html_body)
    printer = QPrinter(QPrinter.HighResolution)
    printer.setOutputFormat(QPrinter.PdfFormat)
    printer.setOutputFileName(str(path))
    doc.print_(printer)
    return path


def rows_to_pdf(title: str, headers: list[str], rows: list[list[object]], base_name: str) -> Path:
    head = ''.join(f'<th>{h}</th>' for h in headers)
    body_rows = ''.join('<tr>' + ''.join(f'<td>{str(v)}</td>' for v in row) + '</tr>' for row in rows)
    html = f"""<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'>
    <style>body{{font-family:Tahoma,Arial;margin:28px;color:#111}}h1{{color:#0f4c81;text-align:center}}table{{width:100%;border-collapse:collapse;margin-top:16px}}td,th{{border:1px solid #d7dde8;padding:8px;text-align:center}}th{{background:#eef6ff;color:#0f172a}}.muted{{color:#64748b;text-align:center}}</style>
    </head><body><h1>{title}</h1><p class='muted'>تقرير صادر من نظام ماكس للمبيعات</p><table><tr>{head}</tr>{body_rows}</table></body></html>"""
    return export_pdf_from_html(title, html, base_name)

