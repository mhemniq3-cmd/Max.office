from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, Optional

try:
    from config import asset_path as _config_asset_path
except Exception:  # pragma: no cover
    _config_asset_path = None

# Appearance modes: kept backward-compatible with earlier patches.
LIGHT_KEY = 'light'
DARK_KEY = 'dark'
AUTO_KEY = 'auto'
DEFAULT_MODE = LIGHT_KEY
FIXED_THEME_KEY = LIGHT_KEY
MODE_FILE = 'ui_mode.txt'
BRAND_FILE = 'ui_brand_theme.json'
LIGHT_STYLE_FILE = 'style_modern_clean.qss'
DARK_STYLE_FILE = 'style_dark_mode_v43.qss'

APPEARANCE_MODES = {
    LIGHT_KEY: ('الوضع الفاتح', LIGHT_STYLE_FILE),
    DARK_KEY: ('الوضع الداكن', DARK_STYLE_FILE),
    AUTO_KEY: ('تلقائي حسب النظام', None),
}
THEMES = {
    'classic_fixed': ('المظهر الافتراضي', LIGHT_STYLE_FILE),
    LIGHT_KEY: ('الوضع الفاتح', LIGHT_STYLE_FILE),
    DARK_KEY: ('الوضع الداكن', DARK_STYLE_FILE),
    AUTO_KEY: ('تلقائي حسب النظام', None),
}
ALIASES = {
    'classic_fixed': LIGHT_KEY,
    'modern_blue': LIGHT_KEY,
    'default': LIGHT_KEY,
    'fixed': LIGHT_KEY,
    'dark_pos': DARK_KEY,
    'dark': DARK_KEY,
    'light': LIGHT_KEY,
    'auto': AUTO_KEY,
}

PRESETS: Dict[str, Dict[str, str]] = {
    'ocean': {
        'name': 'أزرق احترافي',
        'primary': '#165DFF',
        'secondary': '#00B42A',
        'accent': '#FF7D00',
        'danger': '#dc2626',
    },
    'emerald': {
        'name': 'أخضر تجاري',
        'primary': '#059669',
        'secondary': '#0f766e',
        'accent': '#10b981',
        'danger': '#dc2626',
    },
    'royal': {
        'name': 'بنفسجي فاخر',
        'primary': '#7c3aed',
        'secondary': '#4338ca',
        'accent': '#a855f7',
        'danger': '#dc2626',
    },
    'gold': {
        'name': 'ذهبي مؤسسي',
        'primary': '#b45309',
        'secondary': '#92400e',
        'accent': '#f59e0b',
        'danger': '#dc2626',
    },
}
DEFAULT_BRAND_THEME: Dict[str, Any] = {
    'preset': 'ocean',
    'primary': PRESETS['ocean']['primary'],
    'secondary': PRESETS['ocean']['secondary'],
    'accent': PRESETS['ocean']['accent'],
    'danger': PRESETS['ocean']['danger'],
    'font_family': 'Tajawal, Segoe UI, Tahoma, Arial',
    'font_size': 13,
    'density': 'comfortable',
    'radius': 16,
}
DENSITY_TOKENS = {
    'compact': {'name': 'مضغوط للشاشات الصغيرة', 'padding': 6, 'input_height': 24, 'button_height': 26, 'table_padding': 5},
    'comfortable': {'name': 'مريح افتراضي', 'padding': 9, 'input_height': 30, 'button_height': 28, 'table_padding': 8},
    'spacious': {'name': 'واسع للشاشات الكبيرة', 'padding': 12, 'input_height': 36, 'button_height': 34, 'table_padding': 11},
}
_HEX_RE = re.compile(r'^#[0-9a-fA-F]{6}$')


def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _settings_dir(root: Path | None = None) -> Path:
    base = root or project_root()
    path = base / 'settings'
    path.mkdir(parents=True, exist_ok=True)
    return path


def _normalize_mode(mode: Optional[str]) -> str:
    key = (mode or DEFAULT_MODE).strip().lower()
    return ALIASES.get(key, key if key in APPEARANCE_MODES else DEFAULT_MODE)


def _read_mode(root: Path | None = None) -> str:
    try:
        path = _settings_dir(root) / MODE_FILE
        if path.exists():
            return _normalize_mode(path.read_text(encoding='utf-8').strip())
    except Exception:
        pass
    return DEFAULT_MODE


def current_appearance_mode(root: Path | None = None) -> str:
    return _read_mode(root)


def selected_theme(root: Path | None = None) -> str:
    return current_appearance_mode(root)


def current_theme_key(root: Path | None = None) -> str:
    return current_appearance_mode(root)


def set_appearance_mode(mode: str, root: Path | None = None) -> str:
    key = _normalize_mode(mode)
    try:
        settings = _settings_dir(root)
        (settings / MODE_FILE).write_text(key, encoding='utf-8')
        old = settings / 'ui_theme.txt'
        if old.exists():
            old.unlink()
    except Exception:
        pass
    return key


def set_theme_key(theme: str, root: Path | None = None) -> str:
    return set_appearance_mode(theme, root)


def _system_prefers_dark() -> bool:
    if sys.platform.startswith('win'):
        try:
            import winreg
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r'Software\Microsoft\Windows\CurrentVersion\Themes\Personalize',
            )
            val, _ = winreg.QueryValueEx(key, 'AppsUseLightTheme')
            return int(val) == 0
        except Exception:
            return False
    return os.environ.get('MAX_SALES_FORCE_DARK', '').strip() == '1'


def effective_mode(mode: str | None = None, root: Path | None = None) -> str:
    key = _normalize_mode(mode or current_appearance_mode(root))
    if key == AUTO_KEY:
        return DARK_KEY if _system_prefers_dark() else LIGHT_KEY
    return key


def theme_label(theme: str | None = None) -> str:
    key = _normalize_mode(theme or current_appearance_mode())
    return APPEARANCE_MODES.get(key, APPEARANCE_MODES[LIGHT_KEY])[0]


def theme_path(root: Path | str | None = None, theme: str | None = None) -> Path:
    root_path = Path(root) if root is not None else project_root()
    mode = effective_mode(theme, root_path)
    filename = DARK_STYLE_FILE if mode == DARK_KEY else LIGHT_STYLE_FILE
    candidates = []
    if _config_asset_path is not None and root is None:
        candidates.extend([_config_asset_path(filename), _config_asset_path(LIGHT_STYLE_FILE), _config_asset_path('style.qss')])
    candidates.extend([root_path / 'assets' / filename, root_path / 'assets' / LIGHT_STYLE_FILE, root_path / 'assets' / 'style.qss'])
    for path in candidates:
        if path.exists():
            return path
    return candidates[0]


def _valid_hex(value: Any, fallback: str) -> str:
    text = str(value or '').strip()
    return text if _HEX_RE.match(text) else fallback


def _clamp_int(value: Any, fallback: int, low: int, high: int) -> int:
    try:
        n = int(value)
    except Exception:
        n = fallback
    return max(low, min(high, n))


def normalize_brand_theme(data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    raw = dict(DEFAULT_BRAND_THEME)
    if data:
        preset = str(data.get('preset') or raw['preset']).strip().lower()
        if preset in PRESETS:
            raw.update({k: v for k, v in PRESETS[preset].items() if k != 'name'})
            raw['preset'] = preset
        raw.update({k: v for k, v in data.items() if v is not None})
    density = str(raw.get('density') or 'comfortable').strip().lower()
    if density not in DENSITY_TOKENS:
        density = 'comfortable'
    return {
        'preset': str(raw.get('preset') or 'ocean'),
        'primary': _valid_hex(raw.get('primary'), DEFAULT_BRAND_THEME['primary']),
        'secondary': _valid_hex(raw.get('secondary'), DEFAULT_BRAND_THEME['secondary']),
        'accent': _valid_hex(raw.get('accent'), DEFAULT_BRAND_THEME['accent']),
        'danger': _valid_hex(raw.get('danger'), DEFAULT_BRAND_THEME['danger']),
        'font_family': str(raw.get('font_family') or DEFAULT_BRAND_THEME['font_family']).strip(),
        'font_size': _clamp_int(raw.get('font_size'), DEFAULT_BRAND_THEME['font_size'], 11, 18),
        'density': density,
        'radius': _clamp_int(raw.get('radius'), DEFAULT_BRAND_THEME['radius'], 8, 28),
    }


def current_brand_theme(root: Path | str | None = None) -> Dict[str, Any]:
    root_path = Path(root) if root is not None else project_root()
    path = _settings_dir(root_path) / BRAND_FILE
    try:
        if path.exists():
            return normalize_brand_theme(json.loads(path.read_text(encoding='utf-8')))
    except Exception:
        pass
    return normalize_brand_theme()


def save_brand_theme(data: Dict[str, Any], root: Path | str | None = None) -> Dict[str, Any]:
    root_path = Path(root) if root is not None else project_root()
    normalized = normalize_brand_theme(data)
    try:
        (_settings_dir(root_path) / BRAND_FILE).write_text(
            json.dumps(normalized, ensure_ascii=False, indent=2),
            encoding='utf-8',
        )
    except Exception:
        pass
    return normalized


def reset_brand_theme(root: Path | str | None = None) -> Dict[str, Any]:
    root_path = Path(root) if root is not None else project_root()
    try:
        path = _settings_dir(root_path) / BRAND_FILE
        if path.exists():
            path.unlink()
    except Exception:
        pass
    return normalize_brand_theme()


def available_brand_presets() -> list[tuple[str, str]]:
    return [(key, value['name']) for key, value in PRESETS.items()]


def available_density_modes() -> list[tuple[str, str]]:
    return [(key, value['name']) for key, value in DENSITY_TOKENS.items()]


def brand_qss(theme: Optional[Dict[str, Any]] = None, dark: bool = False) -> str:
    t = normalize_brand_theme(theme)
    density = DENSITY_TOKENS[t['density']]
    font_family = t['font_family'].replace('"', '').replace("'", '')
    primary, secondary, accent, danger = t['primary'], t['secondary'], t['accent'], t['danger']
    radius = int(t['radius'])
    font_size = int(t['font_size'])
    padding = density['padding']
    input_height = density['input_height']
    button_height = density['button_height']
    table_padding = density['table_padding']
    surface = '#111827' if dark else '#ffffff'
    body = '#0f172a' if dark else '#eef3f8'
    text = '#e5e7eb' if dark else '#0f172a'
    muted = '#94a3b8' if dark else '#64748b'
    border = '#334155' if dark else '#dbe5ef'
    field_bg = '#020617' if dark else '#ffffff'
    field_focus = '#0b1220' if dark else '#fbfdff'
    nav_text = '#f8fafc'
    return f'''
/* MAX SALES Stage 4.1 - Dynamic UX tokens. Generated by ui.theme_manager */
* {{ font-family: "{font_family}"; font-size: {font_size}px; }}
QMainWindow, QWidget#professionalShell, #body, QDialog, QWidget {{ background: {body}; color: {text}; }}
#sidebar {{ background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #061525, stop:0.52 {secondary}, stop:1 {primary}); }}
#brand, #userBadge {{ border-radius: {radius + 2}px; }}
#topbar, #surface, QFrame#surface, QFrame#innerCard, #footerBar {{ background: {surface}; border: 1px solid {border}; border-radius: {radius + 6}px; }}
#topTitle, #heroTitle, #sectionTitle, #smallSectionTitle, #miniTitle {{ color: {text}; }}
#topSubtitle, #pageSubtitle, #mutedText, #metricTitle {{ color: {muted}; }}
QPushButton#navButton {{ color: {nav_text}; border-radius: {radius}px; padding: {padding + 3}px {padding + 7}px; }}
QPushButton#navButton:hover {{ background: rgba(255,255,255,0.14); border: 1px solid rgba(255,255,255,0.22); }}
QPushButton#navButton[active="true"] {{ background: #ffffff; color: {primary}; border: 1px solid #ffffff; }}
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTextEdit, QPlainTextEdit, QDateEdit {{
    background: {field_bg}; color: {text}; border: 1px solid {border}; border-radius: {max(8, radius - 2)}px;
    padding: {padding}px; min-height: {input_height}px; selection-background-color: {primary}; selection-color: #ffffff;
}}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QTextEdit:focus, QPlainTextEdit:focus, QDateEdit:focus {{ border: 1px solid {accent}; background: {field_focus}; }}
QPushButton {{ border-radius: {max(8, radius - 2)}px; padding: {padding + 1}px {padding + 5}px; min-height: {button_height}px; font-weight: 900; }}
QPushButton#primaryButton, QPushButton#appearanceTopButton {{ background: {primary}; color: #ffffff; border: 1px solid {primary}; }}
QPushButton#primaryButton:hover, QPushButton#appearanceTopButton:hover {{ background: {secondary}; border: 1px solid {secondary}; }}
QPushButton#successButton {{ background: {secondary}; color: #ffffff; border: 1px solid {secondary}; }}
QPushButton#dangerButton, QPushButton#alertButton[danger="true"] {{ background: {danger}; color: #ffffff; border: 1px solid {danger}; }}
QPushButton#alertButton {{ background: {accent}; color: #111827; border: 1px solid {accent}; }}
QFrame#metricCard {{ border-radius: {radius + 4}px; }}
QFrame#metricCard[accent="primary"] {{ border-top: 6px solid {primary}; }}
QFrame#metricCard[accent="success"] {{ border-top: 6px solid {secondary}; }}
QFrame#metricCard[accent="cyan"] {{ border-top: 6px solid {accent}; }}
#bigTotal, #heroCard {{ border-radius: {radius + 8}px; }}
#bigTotal {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {primary}, stop:1 {secondary}); color: #ffffff; border: 1px solid {accent}; }}
QTableWidget {{ border-radius: {radius}px; gridline-color: {border}; }}
QTableWidget::item {{ padding: {table_padding}px; }}
QHeaderView::section {{ background: {primary}; color: #ffffff; padding: {padding + 1}px; min-height: {input_height}px; }}
QTabBar::tab:selected {{ background: {primary}; color: #ffffff; }}
#noticeBox, #alertsBox {{ border-radius: {radius + 2}px; border: 1px solid {border}; }}
'''


def style_sheet(root: Path | str | None = None, theme: str | None = None) -> str:
    root_path = Path(root) if root is not None else project_root()
    path = theme_path(root_path, theme)
    base = path.read_text(encoding='utf-8') if path.exists() else ''
    mode = effective_mode(theme, root_path)
    return base + '\n' + brand_qss(current_brand_theme(root_path), dark=(mode == DARK_KEY))


def apply_theme(app=None, root: Path | str | None = None, theme: str | None = None) -> None:
    if app is None or isinstance(app, str):
        try:
            from PySide6.QtWidgets import QApplication
            app = QApplication.instance()
        except Exception:
            app = None
    root_path = Path(root) if root is not None else project_root()
    if app is not None:
        app.setStyleSheet(style_sheet(root_path, theme))


def available_appearance_modes():
    return [(LIGHT_KEY, APPEARANCE_MODES[LIGHT_KEY][0]), (DARK_KEY, APPEARANCE_MODES[DARK_KEY][0]), (AUTO_KEY, APPEARANCE_MODES[AUTO_KEY][0])]
