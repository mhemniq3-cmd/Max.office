from ui.ui_common import *

class InventoryAlertsDialog(QDialog):
    def __init__(self, service, parent=None):
        super().__init__(parent)
        self.service = service
        self.setWindowTitle('تنبيهات المخزون النواقص')
        self.resize(850, 550)
        self.build()
        self.refresh()

    def build(self):
        lay = QVBoxLayout(self)
        
        header = QHBoxLayout()
        title = QLabel('⚠️ المنتجات التي وصلت إلى حد التنبيه أو نفدت')
        title.setObjectName('sectionTitle')
        header.addWidget(title)
        header.addStretch()
        
        self.export_btn = QPushButton('طباعة تقرير النواقص')
        self.export_btn.setObjectName('primaryButton')
        self.export_btn.clicked.connect(self.export_report)
        self.refresh_btn = QPushButton('تحديث')
        self.refresh_btn.clicked.connect(self.refresh)
        header.addWidget(self.export_btn)
        header.addWidget(self.refresh_btn)
        
        lay.addLayout(header)
        
        self.table = Table(['الباركود', 'المنتج', 'الصنف', 'الكمية الحالية', 'حد التنبيه', 'الحالة'])
        lay.addWidget(self.table, 1)
        
        close_btn = QPushButton('إغلاق')
        close_btn.clicked.connect(self.accept)
        lay.addWidget(close_btn, alignment=Qt.AlignRight)

    def refresh(self):
        try:
            items = self.service.low_inventory_details()
        except Exception as exc:
            QMessageBox.warning(self, 'خطأ', str(exc))
            return
            
        self.table.setRowCount(len(items))
        self.table._items = items
        
        for r, item in enumerate(items):
            qty = int(item['quantity'] or 0)
            status = 'نفد تماماً' if qty <= 0 else 'منخفض'
            
            for c, v in enumerate([
                item['barcode'] or '-',
                item['name'],
                item['category'] or '-',
                str(qty),
                str(item['min_quantity'] or 0),
                status
            ]):
                cell = self.table.put(r, c, v)
                
                # Apply colors
                if qty <= 0:
                    cell.setForeground(QColor(220, 38, 38)) # Red
                else:
                    cell.setForeground(QColor(217, 119, 6)) # Orange/Yellow

    def export_report(self):
        items = getattr(self.table, '_items', [])
        if not items:
            QMessageBox.information(self, 'تنبيه', 'لا توجد بيانات لطباعتها')
            return
            
        headers = ['الباركود', 'المنتج', 'الصنف', 'الكمية الحالية', 'حد التنبيه']
        rows = []
        for item in items:
            rows.append([
                item['barcode'] or '-',
                item['name'],
                item['category'] or '-',
                str(item['quantity'] or 0),
                str(item['min_quantity'] or 0)
            ])
            
        try:
            path = rows_to_pdf('تقرير نواقص المخزون', headers, rows, 'inventory_alerts')
            QMessageBox.information(self, 'تم التصدير', f'تم حفظ التقرير بنجاح في:\n{path}')
        except Exception as exc:
            QMessageBox.warning(self, 'خطأ في التصدير', str(exc))
