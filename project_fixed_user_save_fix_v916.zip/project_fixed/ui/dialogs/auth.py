from ui.ui_common import *

from PySide6.QtCore import QSize
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QSizePolicy, QBoxLayout, QSpacerItem


LOGIN_SUPPORT_TEXT = 'إذا واجهت أي مشكلة يرجى التواصل مع الدعم الفني 07805245980'
LOGIN_COPYRIGHT_TEXT = '© PY : MOHIMEN MAX'


class LoginDialog(QDialog):
    """Modern teal login screen for MAX Sales.

    This dialog intentionally changes only the visual login layer. Authentication,
    password policy, and the rest of the system remain handled by AppService.
    """

    def __init__(self, service: AppService):
        super().__init__()
        self.service = service
        self.user = None
        self._maximized = False
        self._normal_geometry = None

        self.setWindowTitle('نظام ماكس للمبيعات')
        self.setObjectName('modernLoginDialog')
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setModal(True)
        self.setMinimumSize(1100, 680)
        self.resize(1320, 780)
        self.setLayoutDirection(Qt.RightToLeft)

        self._build_ui()
        self._apply_style()
        QTimer.singleShot(0, self._open_best_size)
        QTimer.singleShot(0, self.username.setFocus)

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_title_bar())

        body = QFrame()
        body.setObjectName('loginBody')
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)

        main = QFrame()
        main.setObjectName('loginMainArea')
        main_layout = QHBoxLayout(main)
        main_layout.setContentsMargins(54, 42, 54, 30)
        main_layout.setSpacing(42)
        main_layout.setDirection(QBoxLayout.LeftToRight)

        main_layout.addWidget(self._build_brand_panel(), 11)
        main_layout.addWidget(self._build_login_card(), 10)

        body_layout.addWidget(main, 1)
        body_layout.addWidget(self._build_footer())
        root.addWidget(body, 1)

    def _build_title_bar(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName('loginTitleBar')
        bar.setFixedHeight(58)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(18, 0, 18, 0)
        layout.setSpacing(12)
        layout.setDirection(QBoxLayout.LeftToRight)

        logo = QLabel('M')
        logo.setObjectName('loginSmallLogo')
        logo.setAlignment(Qt.AlignCenter)
        logo.setFixedSize(32, 32)
        title = QLabel('نظام ماكس للمبيعات')
        title.setObjectName('loginTitleBarText')
        title.setAlignment(Qt.AlignVCenter | Qt.AlignLeft)

        layout.addWidget(logo)
        layout.addWidget(title)
        layout.addStretch(1)

        self.min_btn = QPushButton('—')
        self.max_btn = QPushButton('□')
        self.close_btn = QPushButton('×')
        for btn in (self.min_btn, self.max_btn, self.close_btn):
            btn.setObjectName('loginWindowButton')
            btn.setFixedSize(42, 36)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFocusPolicy(Qt.NoFocus)
        self.close_btn.setObjectName('loginCloseButton')
        self.min_btn.clicked.connect(self.showMinimized)
        self.max_btn.clicked.connect(self._toggle_maximized)
        self.close_btn.clicked.connect(self.reject)
        layout.addWidget(self.min_btn)
        layout.addWidget(self.max_btn)
        layout.addWidget(self.close_btn)
        return bar

    def _build_brand_panel(self) -> QWidget:
        panel = QFrame()
        panel.setObjectName('loginBrandPanel')
        panel.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(20, 16, 20, 10)
        layout.setSpacing(10)

        layout.addStretch(1)

        logo = self._build_hero_logo()
        layout.addWidget(logo, 0, Qt.AlignHCenter)

        title = QLabel('نظام ماكس للمبيعات')
        title.setObjectName('loginBrandTitle')
        title.setAlignment(Qt.AlignCenter)
        title.setWordWrap(True)
        layout.addWidget(title)

        subtitle = QLabel('حل متكامل لإدارة المبيعات والمخزون والعملاء')
        subtitle.setObjectName('loginBrandSubtitle')
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        illustration = self._build_illustration()
        layout.addWidget(illustration, 0, Qt.AlignCenter)
        layout.addStretch(1)
        return panel

    def _build_hero_logo(self) -> QWidget:
        box = QFrame()
        box.setObjectName('loginHeroLogoBox')
        box.setFixedSize(172, 172)
        layout = QVBoxLayout(box)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(0)

        mark = QLabel('M')
        mark.setObjectName('loginBigLogo')
        mark.setAlignment(Qt.AlignCenter)
        layout.addWidget(mark, 1)

        accent = QLabel('↗')
        accent.setObjectName('loginLogoAccent')
        accent.setAlignment(Qt.AlignCenter)
        accent.setParent(box)
        accent.move(112, 18)
        accent.raise_()
        return box

    def _build_illustration(self) -> QWidget:
        box = QFrame()
        box.setObjectName('loginIllustration')
        box.setFixedSize(430, 220)
        layout = QHBoxLayout(box)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(14)
        layout.setDirection(QBoxLayout.LeftToRight)

        cart = QLabel('🛒')
        cart.setObjectName('loginIllustrationIcon')
        cart.setAlignment(Qt.AlignCenter)
        cart.setFixedSize(78, 78)
        layout.addWidget(cart, 0, Qt.AlignBottom)

        monitor = QFrame()
        monitor.setObjectName('loginMonitor')
        monitor_layout = QVBoxLayout(monitor)
        monitor_layout.setContentsMargins(12, 10, 12, 10)
        monitor_layout.setSpacing(7)
        chart = QLabel('▁ ▃ ▅ ▇   ◔')
        chart.setObjectName('loginChartText')
        chart.setAlignment(Qt.AlignCenter)
        lines = QLabel('━━━━━━\n━━━━\n━━━━━━━━')
        lines.setObjectName('loginMutedLines')
        lines.setAlignment(Qt.AlignCenter)
        monitor_layout.addWidget(chart)
        monitor_layout.addWidget(lines)
        layout.addWidget(monitor, 1)

        right = QVBoxLayout()
        right.setSpacing(8)
        for txt in ('▰▰', '▰▰▰'):
            b = QLabel(txt)
            b.setObjectName('loginBoxIcon')
            b.setAlignment(Qt.AlignCenter)
            b.setFixedSize(72, 42)
            right.addWidget(b)
        receipt = QLabel('▤\n▤\n▤')
        receipt.setObjectName('loginReceiptIcon')
        receipt.setAlignment(Qt.AlignCenter)
        receipt.setFixedSize(72, 64)
        right.addWidget(receipt)
        layout.addLayout(right)
        return box

    def _build_login_card(self) -> QWidget:
        outer = QWidget()
        outer_layout = QVBoxLayout(outer)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.addStretch(1)

        card = QFrame()
        card.setObjectName('loginCard')
        card.setMaximumWidth(620)
        card.setMinimumWidth(500)
        # QGraphicsDropShadowEffect disabled: causes 0xC0000005 crash on PySide6 6.11+
        # card.setGraphicsEffect(QGraphicsDropShadowEffect(card))

        layout = QVBoxLayout(card)
        layout.setContentsMargins(50, 38, 50, 38)
        layout.setSpacing(16)

        avatar = QLabel('●')
        avatar.setObjectName('loginAvatar')
        avatar.setAlignment(Qt.AlignCenter)
        avatar.setFixedSize(74, 74)
        layout.addWidget(avatar, 0, Qt.AlignHCenter)

        layout.addSpacing(10)

        user_label = QLabel('اسم المستخدم')
        user_label.setObjectName('loginFieldLabel')
        user_label.setAlignment(Qt.AlignRight)
        self.username = QLineEdit()
        self.username.setObjectName('loginLineEdit')
        self.username.setPlaceholderText('أدخل اسم المستخدم')
        self.username.setMinimumHeight(56)
        self.username.setClearButtonEnabled(True)
        self.username.returnPressed.connect(self.try_login)
        layout.addWidget(user_label)
        layout.addWidget(self.username)

        pass_label = QLabel('كلمة المرور')
        pass_label.setObjectName('loginFieldLabel')
        pass_label.setAlignment(Qt.AlignRight)
        self.password = QLineEdit()
        self.password.setObjectName('loginLineEdit')
        self.password.setPlaceholderText('أدخل كلمة المرور')
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setMinimumHeight(56)
        self.password.returnPressed.connect(self.try_login)
        layout.addSpacing(8)
        layout.addWidget(pass_label)
        layout.addWidget(self.password)

        show_row = QHBoxLayout()
        show_row.setDirection(QBoxLayout.LeftToRight)
        eye = QLabel('◉')
        eye.setObjectName('loginEyeIcon')
        eye.setFixedWidth(28)
        self.show_password = QCheckBox('إظهار كلمة المرور')
        self.show_password.setObjectName('loginCheckBox')
        self.show_password.setCursor(Qt.PointingHandCursor)
        self.show_password.toggled.connect(self._toggle_password)
        show_row.addWidget(eye)
        show_row.addWidget(self.show_password)
        show_row.addStretch(1)
        layout.addLayout(show_row)

        self.login_button = QPushButton('تسجيل الدخول   ↵')
        self.login_button.setObjectName('loginPrimaryButton')
        self.login_button.setMinimumHeight(62)
        self.login_button.setCursor(Qt.PointingHandCursor)
        self.login_button.clicked.connect(self.try_login)
        layout.addSpacing(8)
        layout.addWidget(self.login_button)

        outer_layout.addWidget(card, 0, Qt.AlignCenter)
        outer_layout.addStretch(1)
        return outer

    def _build_footer(self) -> QWidget:
        footer = QFrame()
        footer.setObjectName('loginFooter')
        footer.setFixedHeight(92)
        layout = QVBoxLayout(footer)
        layout.setContentsMargins(18, 8, 18, 8)
        layout.setSpacing(6)

        support = QLabel('☏  ' + LOGIN_SUPPORT_TEXT)
        support.setObjectName('loginSupportText')
        support.setAlignment(Qt.AlignCenter)
        copyright_label = QLabel(LOGIN_COPYRIGHT_TEXT)
        copyright_label.setObjectName('loginCopyrightText')
        copyright_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(support)
        layout.addWidget(copyright_label)
        return footer

    def _apply_style(self) -> None:
        self.setStyleSheet(r'''
        QDialog#modernLoginDialog {
            background: #eef4f6;
            color: #102a2d;
            font-family: "Segoe UI", "Tahoma", "Arial";
            font-size: 14px;
        }
        QFrame#loginTitleBar {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0f3439, stop:1 #10242b);
            border-top-left-radius: 14px;
            border-top-right-radius: 14px;
        }
        QLabel#loginSmallLogo {
            background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #12a3a5, stop:1 #0c6c72);
            color: white;
            border: 2px solid rgba(255,255,255,0.35);
            border-radius: 8px;
            font-size: 17px;
            font-weight: 900;
        }
        QLabel#loginTitleBarText {
            color: white;
            font-size: 17px;
            font-weight: 800;
        }
        QPushButton#loginWindowButton, QPushButton#loginCloseButton {
            background: transparent;
            color: white;
            border: none;
            font-size: 24px;
            font-weight: 400;
        }
        QPushButton#loginWindowButton:hover {
            background: rgba(255,255,255,0.12);
            border-radius: 8px;
        }
        QPushButton#loginCloseButton:hover {
            background: #dc2626;
            border-radius: 8px;
        }
        QFrame#loginBody {
            background: #f7fafb;
            border-bottom-left-radius: 14px;
            border-bottom-right-radius: 14px;
        }
        QFrame#loginMainArea {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #ffffff, stop:0.58 #f7fafb, stop:1 #eef7f7);
            border: none;
        }
        QFrame#loginBrandPanel {
            background: transparent;
            border: none;
        }
        QFrame#loginHeroLogoBox {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #f7ffff, stop:1 #e6f6f7);
            border: 2px solid rgba(12, 108, 114, 0.12);
            border-radius: 34px;
        }
        QLabel#loginBigLogo {
            color: #0b6f75;
            font-size: 86px;
            font-weight: 900;
        }
        QLabel#loginLogoAccent {
            color: #0aa2a3;
            font-size: 44px;
            font-weight: 900;
            background: transparent;
        }
        QLabel#loginBrandTitle {
            color: #11383d;
            font-size: 38px;
            font-weight: 900;
        }
        QLabel#loginBrandSubtitle {
            color: #53676b;
            font-size: 18px;
            font-weight: 600;
        }
        QFrame#loginIllustration {
            background: rgba(255,255,255,0.52);
            border: 1px solid rgba(9, 123, 125, 0.10);
            border-radius: 22px;
        }
        QLabel#loginIllustrationIcon {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #13aaa7, stop:1 #057477);
            color: white;
            border-radius: 24px;
            font-size: 36px;
        }
        QFrame#loginMonitor {
            background: white;
            border: 2px solid #25484f;
            border-radius: 12px;
        }
        QLabel#loginChartText {
            color: #07898b;
            font-size: 24px;
            font-weight: 800;
        }
        QLabel#loginMutedLines {
            color: #9fb0b4;
            font-size: 16px;
        }
        QLabel#loginBoxIcon {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #18a3a1, stop:1 #056b70);
            color: white;
            border-radius: 10px;
            font-size: 18px;
            font-weight: 900;
        }
        QLabel#loginReceiptIcon {
            background: #ffffff;
            color: #9aa6aa;
            border: 1px solid #dbe5e7;
            border-radius: 10px;
            font-size: 18px;
        }
        QFrame#loginCard {
            background: rgba(255,255,255,0.97);
            border: 1px solid #d7e3e5;
            border-radius: 24px;
        }
        QLabel#loginAvatar {
            color: #057a7c;
            background: #ecf8f8;
            border: 2px solid #07898b;
            border-radius: 37px;
            font-size: 42px;
            font-weight: 900;
        }
        QLabel#loginFieldLabel {
            color: #111827;
            font-size: 17px;
            font-weight: 800;
            padding-right: 4px;
        }
        QLineEdit#loginLineEdit {
            background: #ffffff;
            color: #0f172a;
            border: 2px solid #cbd8dc;
            border-radius: 12px;
            padding: 12px 18px;
            font-size: 17px;
            selection-background-color: #0d9488;
            selection-color: white;
        }
        QLineEdit#loginLineEdit:focus {
            border: 2px solid #0d9488;
            background: #ffffff;
        }
        QLineEdit#loginLineEdit::placeholder {
            color: #8b99a1;
        }
        QLabel#loginEyeIcon {
            color: #07898b;
            font-size: 22px;
            font-weight: 800;
        }
        QCheckBox#loginCheckBox {
            color: #111827;
            font-size: 15px;
            font-weight: 700;
            spacing: 9px;
        }
        QCheckBox#loginCheckBox::indicator {
            width: 18px;
            height: 18px;
            border: 2px solid #94a3b8;
            border-radius: 4px;
            background: #ffffff;
        }
        QCheckBox#loginCheckBox::indicator:checked {
            background: #0d9488;
            border-color: #0d9488;
        }
        QPushButton#loginPrimaryButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0f766e, stop:1 #059e9a);
            color: white;
            border: none;
            border-radius: 14px;
            font-size: 25px;
            font-weight: 900;
        }
        QPushButton#loginPrimaryButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0d9488, stop:1 #10aaa6);
        }
        QPushButton#loginPrimaryButton:pressed {
            background: #0f766e;
        }
        QFrame#loginFooter {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #067574, stop:1 #0b8786);
            border-bottom-left-radius: 14px;
            border-bottom-right-radius: 14px;
        }
        QLabel#loginSupportText {
            color: white;
            font-size: 17px;
            font-weight: 700;
        }
        QLabel#loginCopyrightText {
            color: rgba(255,255,255,0.92);
            font-size: 15px;
            font-weight: 800;
            letter-spacing: 0.5px;
        }
        QMessageBox QLabel {
            color: #111827;
        }
        ''')

    def _open_best_size(self) -> None:
        screen = self.screen() or QApplication.primaryScreen()
        if screen is None:
            return
        geo = screen.availableGeometry()
        width = max(self.minimumWidth(), int(geo.width() * 0.90))
        height = max(self.minimumHeight(), int(geo.height() * 0.88))
        width = min(width, geo.width())
        height = min(height, geo.height())
        x = geo.x() + (geo.width() - width) // 2
        y = geo.y() + (geo.height() - height) // 2
        self.setGeometry(x, y, width, height)

    def _toggle_password(self, checked: bool) -> None:
        self.password.setEchoMode(QLineEdit.Normal if checked else QLineEdit.Password)

    def _toggle_maximized(self) -> None:
        if self._maximized:
            if self._normal_geometry is not None:
                self.setGeometry(self._normal_geometry)
            self._maximized = False
            self.max_btn.setText('□')
            return
        self._normal_geometry = self.geometry()
        screen = QApplication.primaryScreen()
        if screen is not None:
            self.setGeometry(screen.availableGeometry().adjusted(24, 24, -24, -24))
        else:
            self.showMaximized()
        self._maximized = True
        self.max_btn.setText('❐')

    def try_login(self):
        user = self.service.authenticate(self.username.text().strip(), self.password.text())
        if not user:
            QMessageBox.warning(self, 'تعذر تسجيل الدخول', 'اسم المستخدم أو كلمة المرور غير صحيحة')
            self.password.clear()
            self.password.setFocus()
            return
        self.user = user
        self.accept()


class ChangePasswordDialog(QDialog):
    def __init__(self, service: AppService, user):
        super().__init__()
        self.service = service
        self.user = user
        self.setWindowTitle('تغيير كلمة مرور المدير')
        self.setMinimumWidth(430)
        layout = QVBoxLayout(self)
        title = QLabel('🔐 يجب تغيير كلمة المرور الافتراضية')
        title.setObjectName('sectionTitle')
        info = QLabel('لا يمكن استخدام النظام بكلمة المرور الافتراضية. اكتب كلمة مرور قوية من 8 أحرف على الأقل ثم تابع.')
        info.setObjectName('noticeBox'); info.setWordWrap(True)
        form = QFormLayout()
        self.old = QLineEdit(); self.old.setPlaceholderText('كلمة المرور الحالية'); self.old.setEchoMode(QLineEdit.Password)
        self.new = QLineEdit(); self.new.setEchoMode(QLineEdit.Password)
        self.confirm = QLineEdit(); self.confirm.setEchoMode(QLineEdit.Password)
        form.addRow('كلمة المرور الحالية', self.old)
        form.addRow('كلمة المرور الجديدة', self.new)
        form.addRow('تأكيد الجديدة', self.confirm)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText('حفظ')
        buttons.button(QDialogButtonBox.Cancel).setText('خروج')
        buttons.accepted.connect(self.save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(title); layout.addWidget(info); layout.addLayout(form); layout.addWidget(buttons)

    def save(self):
        if self.new.text() != self.confirm.text():
            QMessageBox.warning(self, 'تنبيه', 'كلمة المرور الجديدة غير متطابقة')
            return
        try:
            self.service.change_password(self.user['id'], self.old.text(), self.new.text())
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر التغيير', str(exc)); return
        QMessageBox.information(self, 'تم', 'تم تغيير كلمة المرور بنجاح')
        self.accept()
