from ui.ui_common import *

class AccessDeniedDialog(QDialog):
    def __init__(self, page_title: str, current_user=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle('صلاحية مطلوبة')
        self.setModal(True)
        self.setMinimumWidth(460)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(12)

        title = QLabel('🔒 هذا الزر خاص بالمدير فقط')
        title.setObjectName('lockedTitle')
        title.setAlignment(Qt.AlignCenter)

        role = current_user['role'] if current_user and 'role' in current_user.keys() else 'غير معروف'
        message = QLabel(f'لا تملك صلاحية فتح قسم: {page_title}\nالدور الحالي: {role}\nراجع المدير لتعديل الصلاحيات من صفحة المستخدمين والصلاحيات.')
        message.setObjectName('lockedMessage')
        message.setAlignment(Qt.AlignCenter)
        message.setWordWrap(True)

        ok = QPushButton('حسناً')
        ok.setObjectName('primaryButton')
        ok.clicked.connect(self.accept)

        layout.addWidget(title)
        layout.addWidget(message)
        layout.addWidget(ok)
