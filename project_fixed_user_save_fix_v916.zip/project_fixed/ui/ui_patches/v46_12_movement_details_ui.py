from __future__ import annotations

import json
from typing import Any

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

_ORIG_REFRESH_CENTER = getattr(ToolsPage, 'v4517414_refresh_center', None)
_ORIG_INSTALL = getattr(ToolsPage, '__init__', None)


def _money_text(value: Any) -> str:
    try:
        number = float(value or 0)
    except Exception:
        number = 0.0
    if abs(number - int(number)) < 0.001:
        return f'{int(number):,}'
    return f'{number:,.2f}'


def _text(value: Any) -> str:
    return '' if value is None else str(value)


def _make_enhanced_headers(table: QTableWidget) -> None:
    headers = ['الوقت', 'الأهمية', 'العملية', 'المادة', 'البائع/الموظف', 'الكمية', 'الإجمالي', 'التفاصيل']
    try:
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.setSelectionBehavior(QAbstractItemView.SelectRows)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.horizontalHeader().setStretchLastSection(True)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    except Exception:
        pass


def _fill_enhanced_table(table: QTableWidget, rows: list[dict[str, Any]]) -> None:
    _make_enhanced_headers(table)
    table.setRowCount(len(rows))
    for r, row in enumerate(rows):
        item_or_products = row.get('product_names') or row.get('record_type') or ''
        seller = row.get('seller_or_employee') or row.get('employee_name') or row.get('seller_name') or row.get('user_name') or ''
        total = row.get('sale_total') if row.get('sale_total') not in (None, '') else row.get('line_total', '')
        vals = [
            row.get('operation_time') or row.get('event_time') or '',
            row.get('severity') or '',
            row.get('action') or '',
            item_or_products,
            seller,
            row.get('sold_quantity') or '',
            _money_text(total) if total not in (None, '') else '',
            row.get('operation_summary') or row.get('description') or '',
        ]
        for c, v in enumerate(vals):
            if hasattr(table, 'put'):
                item = table.put(r, c, v, row.get('id') if c == 0 else None)
            else:
                item = QTableWidgetItem(str(v))
                if c == 0 and row.get('id') is not None:
                    item.setData(Qt.UserRole, row.get('id'))
                item.setTextAlignment(Qt.AlignCenter)
                table.setItem(r, c, item)
            tip = row.get('items_summary') or row.get('description') or ''
            if tip:
                item.setToolTip(str(tip))


def _selected_id_from_any_table(page: ToolsPage) -> int | None:
    candidates = []
    if hasattr(page, 'v4517414_stack'):
        candidates.append(page.v4517414_stack.currentWidget())
    for name in ('v4517414_daily_table', 'v4517414_sensitive_table', 'v4517414_fraud_table'):
        if hasattr(page, name):
            candidates.append(getattr(page, name))
    for table in candidates:
        if isinstance(table, QTableWidget):
            row = table.currentRow()
            if row >= 0:
                item = table.item(row, 0)
                if item:
                    try:
                        return int(item.data(Qt.UserRole))
                    except Exception:
                        pass
    return None


def _add_field(layout: QFormLayout, label: str, value: Any) -> None:
    txt = QLabel(_text(value) or '-')
    txt.setWordWrap(True)
    layout.addRow(QLabel(label), txt)


def _simple_table(headers: list[str], rows: list[list[Any]], min_height: int = 120) -> Table:
    table = Table(headers)
    table.setMinimumHeight(min_height)
    table.setRowCount(len(rows))
    for r, row in enumerate(rows):
        for c, value in enumerate(row):
            table.put(r, c, value)
    return table


def _format_jsonish(value: Any) -> str:
    text = _text(value).strip()
    if not text:
        return ''
    try:
        parsed = json.loads(text)
        return json.dumps(parsed, ensure_ascii=False, indent=2)
    except Exception:
        return text


def _show_details_dialog(page: ToolsPage, movement_id: int | None = None) -> None:
    mid = movement_id or _selected_id_from_any_table(page)
    if mid is None:
        QMessageBox.information(page, 'تفاصيل العملية', 'اختر عملية من السجل أولاً.')
        return
    try:
        data = page.service.get_unified_movement_details(int(mid)) if hasattr(page.service, 'get_unified_movement_details') else {}
    except Exception as exc:
        QMessageBox.warning(page, 'تعذر فتح التفاصيل', str(exc))
        return
    if not data:
        QMessageBox.information(page, 'تفاصيل العملية', 'لا توجد تفاصيل لهذه العملية.')
        return

    dlg = QDialog(page)
    dlg.setWindowTitle('تفاصيل العملية')
    dlg.resize(920, 720)
    root = QVBoxLayout(dlg)

    title = QLabel(f"🧾 {data.get('action') or 'عملية'}")
    title.setObjectName('sectionTitle')
    title.setWordWrap(True)
    root.addWidget(title)

    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    body = QWidget()
    lay = QVBoxLayout(body)
    lay.setSpacing(12)

    form = QFormLayout()
    _add_field(form, 'الوقت', data.get('operation_time') or data.get('event_time'))
    _add_field(form, 'الأهمية', data.get('severity'))
    _add_field(form, 'القسم', data.get('module'))
    _add_field(form, 'المستخدم', data.get('user_name'))
    _add_field(form, 'البائع / الموظف', data.get('seller_or_employee') or data.get('employee_name') or data.get('seller_name'))
    _add_field(form, 'رقم الفاتورة', data.get('invoice_no') or (data.get('sale') or {}).get('invoice_no'))
    _add_field(form, 'الزبون', data.get('customer_name') or (data.get('sale') or {}).get('customer_name'))
    _add_field(form, 'طريقة الدفع', data.get('payment_method') or (data.get('sale') or {}).get('payment_method'))
    _add_field(form, 'عدد القطع', data.get('sold_quantity'))
    _add_field(form, 'الإجمالي', _money_text(data.get('sale_total') or (data.get('sale') or {}).get('total')))
    _add_field(form, 'الوصف', data.get('description'))
    lay.addLayout(form)

    sale = data.get('sale') or {}
    if sale:
        sale_rows = [
            ['المجموع قبل الخصم', _money_text(sale.get('subtotal'))],
            ['الخصم', _money_text(sale.get('discount_amount'))],
            ['الضريبة', _money_text(sale.get('tax_amount'))],
            ['الصافي', _money_text(sale.get('total'))],
            ['الحالة', sale.get('status') or 'completed'],
            ['ملاحظة الفاتورة', sale.get('note') or ''],
        ]
        lay.addWidget(QLabel('ملخص الفاتورة'))
        lay.addWidget(_simple_table(['البند', 'القيمة'], sale_rows, 170))

    items = data.get('items') or []
    if items:
        item_rows = []
        for item in items:
            item_rows.append([
                item.get('product_name') or '',
                item.get('quantity') or '',
                _money_text(item.get('unit_price')),
                _money_text(item.get('line_total')),
                _money_text(item.get('profit_amount')),
                _money_text(item.get('commission_amount')),
            ])
        lay.addWidget(QLabel('المواد داخل العملية'))
        lay.addWidget(_simple_table(['المادة', 'الكمية', 'سعر الوحدة', 'الإجمالي', 'الربح', 'العمولة'], item_rows, 220))

    related = data.get('related_movements') or []
    if related:
        rel_rows = [[r.get('event_time',''), r.get('user_name',''), r.get('action',''), r.get('description','')] for r in related[:30]]
        lay.addWidget(QLabel('الحركات المرتبطة بنفس العملية'))
        lay.addWidget(_simple_table(['الوقت', 'المستخدم', 'العملية', 'التفاصيل'], rel_rows, 180))

    notes = data.get('manager_notes_history') or []
    if notes:
        lay.addWidget(QLabel('ملاحظات المدير'))
        note_box = QTextEdit('\n'.join(notes))
        note_box.setReadOnly(True)
        note_box.setMinimumHeight(110)
        lay.addWidget(note_box)

    old_new = []
    if data.get('old_values'):
        old_new.append(['قبل', _format_jsonish(data.get('old_values'))])
    if data.get('new_values'):
        old_new.append(['بعد', _format_jsonish(data.get('new_values'))])
    if old_new:
        lay.addWidget(QLabel('بيانات التدقيق الأصلية'))
        audit_box = QTextEdit('\n\n'.join(f'{k}:\n{v}' for k, v in old_new))
        audit_box.setReadOnly(True)
        audit_box.setMinimumHeight(160)
        lay.addWidget(audit_box)

    scroll.setWidget(body)
    root.addWidget(scroll, 1)

    buttons = QHBoxLayout()
    note_btn = QPushButton('إضافة ملاحظة مدير')
    close_btn = QPushButton('إغلاق')
    note_btn.clicked.connect(lambda: _add_note_from_dialog(page, dlg, int(mid)))
    close_btn.clicked.connect(dlg.accept)
    buttons.addWidget(note_btn)
    buttons.addStretch(1)
    buttons.addWidget(close_btn)
    root.addLayout(buttons)
    dlg.exec()


def _add_note_from_dialog(page: ToolsPage, dlg: QDialog, movement_id: int) -> None:
    note, ok = QInputDialog.getText(page, 'ملاحظة المدير', 'اكتب ملاحظة على هذه العملية:')
    if not ok or not str(note).strip():
        return
    try:
        page.service.add_movement_manager_note(int(movement_id), str(note).strip())
        if hasattr(page, 'v4517414_refresh_center'):
            page.v4517414_refresh_center()
        QMessageBox.information(page, 'تم الحفظ', 'تمت إضافة ملاحظة المدير.')
        dlg.accept()
        _show_details_dialog(page, int(movement_id))
    except Exception as exc:
        QMessageBox.warning(page, 'تعذر الحفظ', str(exc))


def _connect_double_clicks(page: ToolsPage) -> None:
    for name in ('v4517414_daily_table', 'v4517414_sensitive_table', 'v4517414_fraud_table'):
        table = getattr(page, name, None)
        if isinstance(table, QTableWidget) and not getattr(table, '_v4612_details_connected', False):
            table.itemDoubleClicked.connect(lambda item, p=page: _show_details_dialog(p, None))
            table._v4612_details_connected = True


def _refresh_center_enhanced(page: ToolsPage) -> None:
    try:
        if not hasattr(page, 'v4517414_stack'):
            if _ORIG_REFRESH_CENTER:
                return _ORIG_REFRESH_CENTER(page)
            return
        summary = page.service.movement_summary() if hasattr(page.service, 'movement_summary') else {}
        cards = getattr(page, 'v4517414_cards', {})
        for key, card in cards.items():
            if key == 'top_user':
                tu = summary.get('top_user') or {}
                card.set_value(f"{tu.get('name','') or '-'} ({tu.get('c',0)})")
            elif key == 'last_fraud':
                lf = summary.get('last_fraud') or {}
                card.set_value((lf.get('action') or '-')[:28])
            else:
                card.set_value(str(summary.get(key, 0)))
        if hasattr(page, 'v4517414_summary_table'):
            rows = [
                ['حركات اليوم', summary.get('today_total', 0)],
                ['الحركات الحساسة اليوم', summary.get('sensitive_total', 0)],
                ['الخصومات اليوم', summary.get('discount_total', 0)],
                ['الحذف/التعطيل اليوم', summary.get('delete_total', 0)],
                ['المرتجعات اليوم', summary.get('return_total', 0)],
                ['الحركات غير المقروءة', summary.get('unread_total', 0)],
            ]
            page.v4517414_summary_table.setRowCount(len(rows))
            for r, row in enumerate(rows):
                page.v4517414_summary_table.put(r, 0, row[0])
                page.v4517414_summary_table.put(r, 1, row[1])

        def filters(mode: str) -> dict[str, Any]:
            return {
                'mode': mode,
                'term': page.v4517414_search.text().strip() if hasattr(page, 'v4517414_search') else '',
                'severity': page.v4517414_severity.currentText() if hasattr(page, 'v4517414_severity') else 'الكل',
                'module': page.v4517414_module.currentText() if hasattr(page, 'v4517414_module') else 'كل الأقسام',
            }

        daily = page.service.list_unified_movements(500, **filters('daily')) if hasattr(page.service, 'list_unified_movements') else []
        sens = page.service.list_unified_movements(500, **filters('sensitive')) if hasattr(page.service, 'list_unified_movements') else []
        fraud = page.service.list_unified_movements(500, **filters('fraud')) if hasattr(page.service, 'list_unified_movements') else []
        _fill_enhanced_table(page.v4517414_daily_table, daily)
        _fill_enhanced_table(page.v4517414_sensitive_table, sens)
        _fill_enhanced_table(page.v4517414_fraud_table, fraud)
        _connect_double_clicks(page)
    except Exception as exc:
        log_exception(exc, 'v46.12 enhanced movement refresh')
        try:
            QMessageBox.warning(page, 'تعذر تحديث سجل الحركات', str(exc))
        except Exception:
            pass


def _tools_init(self, *args, **kwargs):
    if _ORIG_INSTALL:
        _ORIG_INSTALL(self, *args, **kwargs)
    try:
        _connect_double_clicks(self)
        if hasattr(self, 'v4517414_refresh_center'):
            self.v4517414_refresh_center()
    except Exception as exc:
        log_exception(exc, 'v46.12 tools init')


ToolsPage.__init__ = _tools_init
ToolsPage.v4517414_refresh_center = _refresh_center_enhanced
ToolsPage.v4612_show_movement_details = _show_details_dialog
