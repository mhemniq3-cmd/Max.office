from __future__ import annotations

from pathlib import Path

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage
from services.error_logger import log_exception

_ORIG_INIT = ToolsPage.__init__
_ORIG_REFRESH = ToolsPage.refresh


def _current_user_id(page: ToolsPage):
    try:
        if isinstance(page.current_user, dict):
            return page.current_user.get('id')
        return page.current_user['id'] if page.current_user else None
    except Exception:
        return None


def _selected_shift_id(page: ToolsPage):
    try:
        r = page.shift_table.currentRow()
        if r < 0:
            return None
        item = page.shift_table.item(r, 0)
        return int(item.data(Qt.UserRole) or item.text()) if item else None
    except Exception:
        return None


def _metric(title: str, value: str = '0'):
    try:
        return MetricCard(title, value, 'primary')
    except Exception:
        box = QFrame(); box.setObjectName('surface')
        lay = QVBoxLayout(box)
        lab = QLabel(title); lab.setObjectName('miniTitle')
        val = QLabel(value); val.setObjectName('sectionTitle')
        lay.addWidget(lab); lay.addWidget(val)
        box.value_label = val
        def set_value(v): val.setText(str(v))
        box.set_value = set_value
        return box


def _build_cashier_shift_tab(self: ToolsPage):
    tab = QWidget()
    root = QVBoxLayout(tab)
    root.setContentsMargins(10, 10, 10, 10)
    root.setSpacing(10)

    header = QLabel('💵 فتح / إغلاق شفت الكاشير')
    header.setObjectName('sectionTitle')
    note = QLabel('تابع صندوق الكاشير بدقة: مبلغ البداية، المبيعات النقدية، الدفعات، المرتجعات، المصاريف، المبلغ المتوقع، المبلغ الفعلي، وفرق الصندوق.')
    note.setObjectName('noticeBox')
    note.setWordWrap(True)
    root.addWidget(header)
    root.addWidget(note)

    top = QHBoxLayout(); top.setSpacing(10)
    form = QFrame(); form.setObjectName('surface')
    fl = QGridLayout(form); fl.setContentsMargins(14, 14, 14, 14); fl.setSpacing(10)
    self.shift_opening_cash = QDoubleSpinBox(); self.shift_opening_cash.setMaximum(999999999); self.shift_opening_cash.setDecimals(0); self.shift_opening_cash.setSuffix(' د.ع')
    self.shift_counted_cash = QDoubleSpinBox(); self.shift_counted_cash.setMaximum(999999999); self.shift_counted_cash.setDecimals(0); self.shift_counted_cash.setSuffix(' د.ع')
    self.shift_note = QLineEdit(); self.shift_note.setPlaceholderText('ملاحظة اختيارية')
    open_btn = QPushButton('فتح شفت جديد'); open_btn.setObjectName('primaryButton'); open_btn.clicked.connect(self.open_cashier_shift_ui)
    close_btn = QPushButton('إغلاق الشفت'); close_btn.setObjectName('dangerButton'); close_btn.clicked.connect(self.close_cashier_shift_ui)
    refresh_btn = QPushButton('تحديث'); refresh_btn.setObjectName('primaryButton'); refresh_btn.clicked.connect(self.refresh_cashier_shift_ui)
    report_btn = QPushButton('تقرير الشفت'); report_btn.setObjectName('primaryButton'); report_btn.clicked.connect(self.show_selected_shift_report_ui)
    fl.addWidget(QLabel('مبلغ بداية الصندوق'), 0, 0); fl.addWidget(self.shift_opening_cash, 0, 1)
    fl.addWidget(QLabel('المبلغ الموجود فعلياً'), 1, 0); fl.addWidget(self.shift_counted_cash, 1, 1)
    fl.addWidget(QLabel('ملاحظة'), 2, 0); fl.addWidget(self.shift_note, 2, 1)
    fl.addWidget(open_btn, 3, 0); fl.addWidget(close_btn, 3, 1)
    fl.addWidget(refresh_btn, 4, 0); fl.addWidget(report_btn, 4, 1)
    top.addWidget(form, 1)

    status = QFrame(); status.setObjectName('surface')
    sl = QVBoxLayout(status); sl.setContentsMargins(14, 14, 14, 14)
    self.shift_status_label = QLabel('لا يوجد شفت مفتوح')
    self.shift_status_label.setObjectName('sectionTitle')
    self.shift_details_label = QLabel('')
    self.shift_details_label.setObjectName('mutedText')
    self.shift_details_label.setWordWrap(True)
    sl.addWidget(self.shift_status_label)
    sl.addWidget(self.shift_details_label)
    top.addWidget(status, 1)
    root.addLayout(top)

    cards = QGridLayout(); cards.setSpacing(10)
    self.shift_opening_card = _metric('مبلغ البداية', '0 د.ع')
    self.shift_cash_sales_card = _metric('المبيعات النقدية', '0 د.ع')
    self.shift_credit_sales_card = _metric('المبيعات الآجلة', '0 د.ع')
    self.shift_payments_card = _metric('دفعات الزبائن', '0 د.ع')
    self.shift_returns_card = _metric('المرتجعات النقدية', '0 د.ع')
    self.shift_expenses_card = _metric('المصاريف', '0 د.ع')
    self.shift_expected_card = _metric('المتوقع بالصندوق', '0 د.ع')
    self.shift_diff_card = _metric('فرق الصندوق', '0 د.ع')
    for i, card in enumerate([self.shift_opening_card, self.shift_cash_sales_card, self.shift_credit_sales_card, self.shift_payments_card, self.shift_returns_card, self.shift_expenses_card, self.shift_expected_card, self.shift_diff_card]):
        cards.addWidget(card, i // 4, i % 4)
    root.addLayout(cards)

    self.shift_table = Table(['رقم', 'الكاشير', 'فتح', 'إغلاق', 'البداية', 'المتوقع', 'المعدود', 'الفرق', 'الحالة'])
    root.addWidget(self.shift_table, 1)
    self.tabs.addTab(tab, 'شفت الكاشير')


def _open_cashier_shift_ui(self: ToolsPage):
    try:
        sid = self.service.open_cashier_shift(self.shift_opening_cash.value(), self.shift_note.text(), _current_user_id(self))
        self.shift_note.clear()
        self.notify(f'تم فتح شفت الكاشير رقم {sid}')
        self.refresh_cashier_shift_ui()
    except Exception as exc:
        log_exception(exc, 'open cashier shift ui')
        QMessageBox.warning(self, 'تعذر فتح الشفت', str(exc))


def _close_cashier_shift_ui(self: ToolsPage):
    if QMessageBox.question(self, 'تأكيد', 'هل تريد إغلاق الشفت الحالي؟') != QMessageBox.Yes:
        return
    try:
        res = self.service.close_cashier_shift(self.shift_counted_cash.value(), self.shift_note.text(), _current_user_id(self))
        self.shift_note.clear()
        self.notify(f"تم إغلاق الشفت. الفرق: {money(res.get('cash_difference', 0))}")
        self.refresh_cashier_shift_ui()
    except Exception as exc:
        log_exception(exc, 'close cashier shift ui')
        QMessageBox.warning(self, 'تعذر إغلاق الشفت', str(exc))


def _fill_shift_cards(self: ToolsPage, s: dict):
    self.shift_opening_card.set_value(money(s.get('opening_cash', 0)))
    self.shift_cash_sales_card.set_value(money(s.get('cash_sales', 0)))
    self.shift_credit_sales_card.set_value(money(s.get('credit_sales', 0)))
    self.shift_payments_card.set_value(money(s.get('customer_payments', 0)))
    self.shift_returns_card.set_value(money(s.get('returns_amount', 0)))
    self.shift_expenses_card.set_value(money(s.get('expenses_amount', 0)))
    self.shift_expected_card.set_value(money(s.get('expected_cash', 0)))
    self.shift_diff_card.set_value(money(s.get('cash_difference', 0)))


def _refresh_cashier_shift_ui(self: ToolsPage):
    try:
        self.service.ensure_v41_shift_schema()
        summary = self.service.shift_financial_summary(user_id=_current_user_id(self))
        _fill_shift_cards(self, summary)
        if summary.get('open'):
            self.shift_status_label.setText('✅ يوجد شفت مفتوح')
            self.shift_details_label.setText(f"رقم الشفت: {summary.get('shift_id')} | فتح: {summary.get('opened_at')} | الفواتير: {summary.get('invoice_count')}")
        else:
            self.shift_status_label.setText('لا يوجد شفت مفتوح')
            self.shift_details_label.setText('افتح شفت جديد قبل بداية عمل الكاشير لتتبع الصندوق بدقة.')
        rows = self.service.list_cashier_shifts('', 200)
        self.shift_table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            vals = [row['id'], row['username'], row['opened_at'], row['closed_at'] or '-', money(row['opening_cash']), money(row['expected_cash']), money(row['counted_cash'] or 0), money(row['cash_difference'] or 0), row['status']]
            for c, v in enumerate(vals):
                self.shift_table.put(r, c, v)
            try:
                self.shift_table.item(r, 0).setData(Qt.UserRole, int(row['id']))
            except Exception:
                pass
    except Exception as exc:
        log_exception(exc, 'refresh cashier shift ui')


def _show_selected_shift_report_ui(self: ToolsPage):
    shift_id = _selected_shift_id(self)
    try:
        if shift_id is None:
            cur = self.service.current_cashier_shift(_current_user_id(self))
            shift_id = cur['id'] if cur else None
        if not shift_id:
            QMessageBox.information(self, 'تنبيه', 'لا يوجد شفت محدد أو مفتوح')
            return
        html = self.service.cashier_shift_report_html(int(shift_id))
        out = Path('exports') / 'shift_reports'
        out.mkdir(parents=True, exist_ok=True)
        path = out / f'cashier_shift_{shift_id}.html'
        path.write_text(html, encoding='utf-8')
        try:
            import webbrowser
            webbrowser.open(str(path.resolve()))
        except Exception:
            pass
        QMessageBox.information(self, 'تم', f'تم إنشاء تقرير الشفت:\n{path}')
    except Exception as exc:
        log_exception(exc, 'shift report ui')
        QMessageBox.warning(self, 'تعذر إنشاء التقرير', str(exc))


def _init_v41(self: ToolsPage, service, notify, current_user=None):
    _ORIG_INIT(self, service, notify, current_user)
    try:
        self.build_cashier_shift_tab()
        self.refresh_cashier_shift_ui()
    except Exception as exc:
        log_exception(exc, 'init v41 cashier shift ui')


def _refresh_v41(self: ToolsPage):
    _ORIG_REFRESH(self)
    if hasattr(self, 'shift_table'):
        self.refresh_cashier_shift_ui()


ToolsPage.build_cashier_shift_tab = _build_cashier_shift_tab
ToolsPage.open_cashier_shift_ui = _open_cashier_shift_ui
ToolsPage.close_cashier_shift_ui = _close_cashier_shift_ui
ToolsPage.refresh_cashier_shift_ui = _refresh_cashier_shift_ui
ToolsPage.show_selected_shift_report_ui = _show_selected_shift_report_ui
ToolsPage.__init__ = _init_v41
ToolsPage.refresh = _refresh_v41
