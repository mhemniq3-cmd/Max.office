from __future__ import annotations

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

_ORIG_TOOLS_INIT = ToolsPage.__init__
_ORIG_TOOLS_REFRESH = getattr(ToolsPage, 'refresh', None)


def _clear_layout(layout):
    while layout and layout.count():
        item = layout.takeAt(0)
        w = item.widget()
        if w:
            w.setParent(None)
        child = item.layout()
        if child:
            _clear_layout(child)


def _find_or_create_log_tab(page: ToolsPage):
    if not hasattr(page, 'tabs'):
        return None
    idx = -1
    for i in range(page.tabs.count()):
        title = (page.tabs.tabText(i) or '').strip()
        if 'سجل الحركات' in title or 'سجل العمليات' in title:
            idx = i
            break
    if idx < 0:
        tab = QWidget()
        page.tabs.addTab(tab, 'سجل الحركات')
        idx = page.tabs.count() - 1
    else:
        tab = page.tabs.widget(idx)
        page.tabs.setTabText(idx, 'سجل الحركات')
    return tab


def _make_filter_bar(page: ToolsPage):
    wrap = QFrame(); wrap.setObjectName('surface')
    lay = QHBoxLayout(wrap); lay.setContentsMargins(10, 8, 10, 8); lay.setSpacing(8)
    page.v4517414_search = QLineEdit(); page.v4517414_search.setPlaceholderText('بحث: فاتورة، منتج، زبون، مستخدم، عملية...')
    page.v4517414_search.setMinimumHeight(38)
    page.v4517414_severity = QComboBox(); page.v4517414_severity.setMinimumHeight(38)
    page.v4517414_severity.addItems(['الكل', 'عادي', 'مهم', 'حساس', 'خطر', 'warning'])
    page.v4517414_module = QComboBox(); page.v4517414_module.setMinimumHeight(38)
    page.v4517414_module.addItems(['كل الأقسام', 'المبيعات', 'المخزون والمنتجات', 'الزبائن والديون', 'القسائم والخصومات', 'الأمان والاحتيال', 'السجلات والصلاحيات', 'النظام'])
    refresh = QPushButton('تحديث'); refresh.setObjectName('primaryButton'); refresh.setMinimumHeight(38)
    refresh.clicked.connect(page.v4517414_refresh_center)
    mark = QPushButton('تحديد كمقروء'); mark.setMinimumHeight(38)
    mark.clicked.connect(page.v4517414_mark_selected_read)
    export = QPushButton('تصدير CSV'); export.setMinimumHeight(38)
    export.clicked.connect(page.v4517414_export_csv)
    note = QPushButton('ملاحظة مدير'); note.setMinimumHeight(38)
    note.clicked.connect(page.v4517414_add_note)
    lay.addWidget(export); lay.addWidget(note); lay.addWidget(mark); lay.addWidget(refresh)
    lay.addWidget(page.v4517414_severity); lay.addWidget(page.v4517414_module); lay.addWidget(page.v4517414_search, 1)
    page.v4517414_search.returnPressed.connect(page.v4517414_refresh_center)
    page.v4517414_severity.currentTextChanged.connect(lambda *_: page.v4517414_refresh_center())
    page.v4517414_module.currentTextChanged.connect(lambda *_: page.v4517414_refresh_center())
    return wrap


def _metric_card(title: str, value: str = '0'):
    card = MetricCard(title, value)
    card.setMinimumHeight(82)
    return card


def _build_summary_area(page: ToolsPage):
    holder = QWidget(); lay = QVBoxLayout(holder); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(10)
    grid = QGridLayout(); grid.setSpacing(10)
    page.v4517414_cards = {
        'today_total': _metric_card('حركات اليوم'),
        'sensitive_total': _metric_card('حركات حساسة'),
        'discount_total': _metric_card('خصومات'),
        'delete_total': _metric_card('حذف/تعطيل'),
        'return_total': _metric_card('مرتجعات'),
        'unread_total': _metric_card('غير مقروء'),
        'top_user': _metric_card('أكثر مستخدم'),
        'last_fraud': _metric_card('آخر احتيال'),
    }
    keys = list(page.v4517414_cards.keys())
    for i, key in enumerate(keys):
        grid.addWidget(page.v4517414_cards[key], i // 4, i % 4)
    lay.addLayout(grid)
    page.v4517414_summary_table = Table(['المؤشر', 'القيمة'])
    page.v4517414_summary_table.setMinimumHeight(220)
    lay.addWidget(page.v4517414_summary_table, 1)
    return holder


def _make_table(headers):
    t = Table(headers)
    t.setMinimumHeight(360)
    try:
        t.horizontalHeader().setStretchLastSection(True)
    except Exception:
        pass
    return t


def _selected_movement_id(page: ToolsPage):
    table = page.v4517414_stack.currentWidget() if hasattr(page, 'v4517414_stack') else None
    if not isinstance(table, QTableWidget):
        return None
    row = table.currentRow()
    if row < 0:
        return None
    item = table.item(row, 0)
    if not item:
        return None
    mid = item.data(Qt.UserRole)
    try:
        return int(mid)
    except Exception:
        return None


def _fill_table(table: QTableWidget, rows: list[dict]):
    table.setRowCount(len(rows))
    for r, row in enumerate(rows):
        status = '✓' if int(row.get('is_read') or 0) else '●'
        rec = f"{row.get('record_type','') or ''} {row.get('record_id','') or ''}".strip()
        vals = [
            row.get('event_time', ''),
            status,
            row.get('severity', ''),
            row.get('module', ''),
            row.get('user_name', ''),
            row.get('action', ''),
            rec,
            row.get('description', ''),
        ]
        for c, v in enumerate(vals):
            item = table.put(r, c, v, row.get('id') if c == 0 else None)
            if row.get('severity') in ('خطر', 'warning'):
                item.setToolTip('حركة خطرة أو تحتاج متابعة')
            elif row.get('is_sensitive'):
                item.setToolTip('حركة حساسة')


def _current_filters(page: ToolsPage, mode: str):
    return {
        'mode': mode,
        'term': page.v4517414_search.text().strip() if hasattr(page, 'v4517414_search') else '',
        'severity': page.v4517414_severity.currentText() if hasattr(page, 'v4517414_severity') else 'الكل',
        'module': page.v4517414_module.currentText() if hasattr(page, 'v4517414_module') else 'كل الأقسام',
    }


def _refresh_center(page: ToolsPage):
    try:
        if not hasattr(page, 'v4517414_stack'):
            return
        if hasattr(page.service, 'sync_unified_movements'):
            page.service.sync_unified_movements(limit=1500, days=45)
        summary = page.service.movement_summary() if hasattr(page.service, 'movement_summary') else {}
        cards = getattr(page, 'v4517414_cards', {})
        for key, card in cards.items():
            if key == 'top_user':
                tu = summary.get('top_user') or {}
                card.set_value(f"{tu.get('name','') or '-'} ({tu.get('c',0)})")
            elif key == 'last_fraud':
                lf = summary.get('last_fraud') or {}
                card.set_value((lf.get('action') or '-')[:28])
            else:
                card.set_value(str(summary.get(key, 0)))
        if hasattr(page, 'v4517414_summary_table'):
            rows = [
                ['حركات اليوم', summary.get('today_total', 0)],
                ['الحركات الحساسة اليوم', summary.get('sensitive_total', 0)],
                ['الخصومات اليوم', summary.get('discount_total', 0)],
                ['الحذف/التعطيل اليوم', summary.get('delete_total', 0)],
                ['المرتجعات اليوم', summary.get('return_total', 0)],
                ['الحركات غير المقروءة', summary.get('unread_total', 0)],
                ['أكثر مستخدم حركة', f"{(summary.get('top_user') or {}).get('name','-')} ({(summary.get('top_user') or {}).get('c',0)})"],
                ['آخر تنبيه احتيال', (summary.get('last_fraud') or {}).get('action', '-')],
            ]
            page.v4517414_summary_table.setRowCount(len(rows))
            for r, row in enumerate(rows):
                page.v4517414_summary_table.put(r, 0, row[0]); page.v4517414_summary_table.put(r, 1, row[1])

        if hasattr(page.service, 'list_unified_movements'):
            daily = page.service.list_unified_movements(800, **_current_filters(page, 'daily'))
            sens = page.service.list_unified_movements(800, **_current_filters(page, 'sensitive'))
            fraud = page.service.list_unified_movements(800, **_current_filters(page, 'fraud'))
        else:
            daily = sens = fraud = []
        _fill_table(page.v4517414_daily_table, daily)
        _fill_table(page.v4517414_sensitive_table, sens)
        _fill_table(page.v4517414_fraud_table, fraud)
    except Exception as exc:
        log_exception(exc)
        try:
            QMessageBox.warning(page, 'تعذر تحديث سجل الحركات', str(exc))
        except Exception:
            pass


def _mark_selected_read(page: ToolsPage):
    mid = _selected_movement_id(page)
    try:
        if mid is None:
            page.service.mark_movements_read(all_filtered=True, **_current_filters(page, 'unread'))
        else:
            page.service.mark_movements_read([mid])
        page.v4517414_refresh_center()
        page.notify('تم تحديث حالة القراءة')
    except Exception as exc:
        QMessageBox.warning(page, 'تعذر التحديث', str(exc))


def _add_note(page: ToolsPage):
    mid = _selected_movement_id(page)
    if mid is None:
        QMessageBox.information(page, 'تنبيه', 'اختر حركة أولاً من أحد الجداول')
        return
    note, ok = QInputDialog.getText(page, 'ملاحظة المدير', 'اكتب ملاحظة على هذه الحركة:')
    if not ok:
        return
    try:
        page.service.add_movement_manager_note(mid, note)
        page.v4517414_refresh_center()
        page.notify('تم حفظ ملاحظة المدير')
    except Exception as exc:
        QMessageBox.warning(page, 'تعذر الحفظ', str(exc))


def _export_csv(page: ToolsPage):
    try:
        mode = 'daily'
        if hasattr(page, 'v4517414_tabs'):
            idx = page.v4517414_tabs.currentIndex()
            if idx == 2:
                mode = 'sensitive'
            elif idx == 3:
                mode = 'fraud'
        path = page.service.export_movements_csv(**_current_filters(page, mode))
        QMessageBox.information(page, 'تم التصدير', f'تم تصدير سجل الحركات إلى:\n{path}')
    except Exception as exc:
        QMessageBox.warning(page, 'تعذر التصدير', str(exc))


def _install_movement_center(page: ToolsPage):
    try:
        tab = _find_or_create_log_tab(page)
        if tab is None:
            return
        if getattr(page, '_v4517414_installed', False):
            return
        layout = tab.layout()
        if layout is None:
            layout = QVBoxLayout(tab)
        _clear_layout(layout)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        title = QLabel('🧾 مركز سجل الحركات والرقابة')
        title.setObjectName('sectionTitle')
        desc = QLabel('سجل موحد يمنع التكرار ويجمع البيع، الحذف، التعديل، المخزون، القسائم، الديون، الاحتيال، والتدقيق في شاشة واحدة.')
        desc.setObjectName('noticeBox'); desc.setWordWrap(True)
        layout.addWidget(title); layout.addWidget(desc)
        layout.addWidget(_make_filter_bar(page))

        page.v4517414_tabs = QTabWidget()
        page.v4517414_stack = page.v4517414_tabs
        page.v4517414_daily_table = _make_table(['الوقت', 'الحالة', 'الأهمية', 'القسم', 'المستخدم', 'العملية', 'السجل', 'التفاصيل'])
        page.v4517414_sensitive_table = _make_table(['الوقت', 'الحالة', 'الأهمية', 'القسم', 'المستخدم', 'العملية', 'السجل', 'التفاصيل'])
        page.v4517414_fraud_table = _make_table(['الوقت', 'الحالة', 'الأهمية', 'القسم', 'المستخدم', 'العملية', 'السجل', 'التفاصيل'])
        page.v4517414_tabs.addTab(_build_summary_area(page), 'الملخص')
        page.v4517414_tabs.addTab(page.v4517414_daily_table, 'السجل اليومي')
        page.v4517414_tabs.addTab(page.v4517414_sensitive_table, 'الحركات الحساسة')
        page.v4517414_tabs.addTab(page.v4517414_fraud_table, 'التنبيهات والاحتيال')
        layout.addWidget(page.v4517414_tabs, 1)
        page.v4517414_tabs.currentChanged.connect(lambda *_: page.v4517414_refresh_center())
        page._v4517414_installed = True
    except Exception as exc:
        log_exception(exc)


def _tools_init(self, service, notify, current_user=None):
    _ORIG_TOOLS_INIT(self, service, notify, current_user)
    _install_movement_center(self)
    _refresh_center(self)


def _tools_refresh(self):
    if _ORIG_TOOLS_REFRESH:
        _ORIG_TOOLS_REFRESH(self)
    _install_movement_center(self)
    _refresh_center(self)


ToolsPage.__init__ = _tools_init
ToolsPage.refresh = _tools_refresh
ToolsPage.v4517414_refresh_center = _refresh_center
ToolsPage.v4517414_mark_selected_read = _mark_selected_read
ToolsPage.v4517414_add_note = _add_note
ToolsPage.v4517414_export_csv = _export_csv
