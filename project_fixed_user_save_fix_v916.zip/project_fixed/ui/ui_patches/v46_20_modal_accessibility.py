from PySide6.QtWidgets import QDialog, QApplication
from PySide6.QtCore import QSize

_orig_resize = QDialog.resize
_orig_setMinimumSize = QDialog.setMinimumSize

def _safe_resize(self, *args):
    try:
        screen = QApplication.primaryScreen()
        if screen:
            geom = screen.availableGeometry()
            max_w = int(geom.width() * 0.95)
            max_h = int(geom.height() * 0.90)
            
            if len(args) == 2:
                req_w, req_h = args[0], args[1]
                req_w = min(req_w, max_w)
                req_h = min(req_h, max_h)
                return _orig_resize(self, req_w, req_h)
            elif len(args) == 1 and isinstance(args[0], QSize):
                req_w, req_h = args[0].width(), args[0].height()
                req_w = min(req_w, max_w)
                req_h = min(req_h, max_h)
                return _orig_resize(self, QSize(req_w, req_h))
    except Exception:
        pass
    return _orig_resize(self, *args)


def _safe_setMinimumSize(self, *args):
    try:
        screen = QApplication.primaryScreen()
        if screen:
            geom = screen.availableGeometry()
            max_w = int(geom.width() * 0.95)
            max_h = int(geom.height() * 0.90)
            
            if len(args) == 2:
                req_w, req_h = args[0], args[1]
                req_w = min(req_w, max_w)
                req_h = min(req_h, max_h)
                return _orig_setMinimumSize(self, req_w, req_h)
            elif len(args) == 1 and isinstance(args[0], QSize):
                req_w, req_h = args[0].width(), args[0].height()
                req_w = min(req_w, max_w)
                req_h = min(req_h, max_h)
                return _orig_setMinimumSize(self, QSize(req_w, req_h))
    except Exception:
        pass
    return _orig_setMinimumSize(self, *args)


# Apply accessibility patches globally to all QDialogs
QDialog.resize = _safe_resize
QDialog.setMinimumSize = _safe_setMinimumSize
