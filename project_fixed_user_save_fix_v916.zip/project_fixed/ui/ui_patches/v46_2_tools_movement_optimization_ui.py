from __future__ import annotations

import json

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

try:
    import ui.ui_patches.v45_17_4_14_movement_center_ui as movement_ui
except Exception:  # pragma: no cover
    movement_ui = None

_ORIG_TOOLS_INIT = ToolsPage.__init__
_ORIG_TOOLS_REFRESH = getattr(ToolsPage, 'refresh', None)
_ORIG_MC_INSTALL = getattr(movement_ui, '_install_movement_center', None) if movement_ui else None


def _movement_page_size(page: ToolsPage) -> int:
    try:
        return int(page.v462_page_size.currentText())
    except Exception:
        return 100


def _movement_offset(page: ToolsPage) -> int:
    try:
        return max(0, int(getattr(page, 'v462_movement_offset', 0)))
    except Exception:
        return 0


def _set_movement_status(page: ToolsPage, text: str) -> None:
    try:
        page.v462_status.setText(text)
    except Exception:
        pass


def _optimized_filters(page: ToolsPage, mode: str) -> dict:
    return {
        'mode': mode,
        'term': page.v4517414_search.text().strip() if hasattr(page, 'v4517414_search') else '',
        'severity': page.v4517414_severity.currentText() if hasattr(page, 'v4517414_severity') else 'الكل',
        'module': page.v4517414_module.currentText() if hasattr(page, 'v4517414_module') else 'كل الأقسام',
        'date_from': page.v462_date_from.text().strip() if hasattr(page, 'v462_date_from') else '',
        'date_to': page.v462_date_to.text().strip() if hasattr(page, 'v462_date_to') else '',
        'user_name': page.v462_user_filter.text().strip() if hasattr(page, 'v462_user_filter') else '',
        'record_type': page.v462_record_type.currentText() if hasattr(page, 'v462_record_type') else 'الكل',
        'offset': _movement_offset(page),
    }


def _optimized_filter_bar(page: ToolsPage):
    wrap = QFrame(); wrap.setObjectName('surface')
    outer = QVBoxLayout(wrap); outer.setContentsMargins(10, 8, 10, 8); outer.setSpacing(8)

    first = QHBoxLayout(); first.setSpacing(8)
    page.v4517414_search = QLineEdit(); page.v4517414_search.setPlaceholderText('بحث موحد: فاتورة، منتج، زبون، مستخدم، رقم سجل، تفاصيل...')
    page.v4517414_search.setMinimumHeight(36)
    page.v4517414_severity = QComboBox(); page.v4517414_severity.setMinimumHeight(36)
    page.v4517414_severity.addItems(['الكل', 'عادي', 'مهم', 'حساس', 'خطر', 'warning'])
    page.v4517414_module = QComboBox(); page.v4517414_module.setMinimumHeight(36)
    page.v4517414_module.addItems(['كل الأقسام', 'المبيعات', 'المخزون والمنتجات', 'الزبائن والديون', 'القسائم والخصومات', 'الأمان والاحتيال', 'السجلات والصلاحيات', 'النظام'])
    refresh = QPushButton('تحديث التبويب الحالي'); refresh.setObjectName('primaryButton'); refresh.setMinimumHeight(36)
    refresh.clicked.connect(lambda: page.v4517414_refresh_center())
    sync = QPushButton('مزامنة البيانات'); sync.setMinimumHeight(36)
    sync.clicked.connect(lambda: page.v462_sync_and_refresh())
    mark = QPushButton('تحديد كمقروء'); mark.setMinimumHeight(36)
    mark.clicked.connect(page.v4517414_mark_selected_read)
    export = QPushButton('تصدير CSV'); export.setMinimumHeight(36)
    export.clicked.connect(page.v4517414_export_csv)
    note = QPushButton('ملاحظة مدير'); note.setMinimumHeight(36)
    note.clicked.connect(page.v4517414_add_note)
    first.addWidget(export); first.addWidget(note); first.addWidget(mark); first.addWidget(sync); first.addWidget(refresh)
    first.addWidget(page.v4517414_severity); first.addWidget(page.v4517414_module); first.addWidget(page.v4517414_search, 1)

    second = QHBoxLayout(); second.setSpacing(8)
    page.v462_date_from = QLineEdit(); page.v462_date_from.setPlaceholderText('من تاريخ YYYY-MM-DD')
    page.v462_date_to = QLineEdit(); page.v462_date_to.setPlaceholderText('إلى تاريخ YYYY-MM-DD')
    page.v462_user_filter = QLineEdit(); page.v462_user_filter.setPlaceholderText('فلتر المستخدم')
    page.v462_record_type = QComboBox(); page.v462_record_type.addItems(['الكل', 'sale', 'return', 'product', 'customer', 'settings', 'inventory', 'coupon', 'user'])
    page.v462_page_size = QComboBox(); page.v462_page_size.addItems(['50', '100', '200', '500']); page.v462_page_size.setCurrentText('100')
    prev_btn = QPushButton('السابق'); next_btn = QPushButton('التالي')
    page.v462_status = QLabel('لم يتم التحميل بعد')
    page.v462_status.setObjectName('noticeBox')
    prev_btn.clicked.connect(lambda: page.v462_prev_page())
    next_btn.clicked.connect(lambda: page.v462_next_page())
    for w in (page.v462_date_from, page.v462_date_to, page.v462_user_filter, page.v462_record_type, page.v462_page_size, prev_btn, next_btn):
        try: w.setMinimumHeight(34)
        except Exception: pass
    second.addWidget(next_btn); second.addWidget(prev_btn)
    second.addWidget(QLabel('عدد الصفوف:')); second.addWidget(page.v462_page_size)
    second.addWidget(page.v462_record_type)
    second.addWidget(page.v462_user_filter)
    second.addWidget(page.v462_date_to)
    second.addWidget(page.v462_date_from)
    second.addWidget(page.v462_status, 1)

    outer.addLayout(first); outer.addLayout(second)
    for widget in (page.v4517414_search, page.v462_date_from, page.v462_date_to, page.v462_user_filter):
        widget.returnPressed.connect(lambda: page.v462_reset_and_refresh())
    page.v4517414_severity.currentTextChanged.connect(lambda *_: page.v462_reset_and_refresh())
    page.v4517414_module.currentTextChanged.connect(lambda *_: page.v462_reset_and_refresh())
    page.v462_record_type.currentTextChanged.connect(lambda *_: page.v462_reset_and_refresh())
    page.v462_page_size.currentTextChanged.connect(lambda *_: page.v462_reset_and_refresh())
    return wrap


def _active_movement_mode(page: ToolsPage) -> str | None:
    if not hasattr(page, 'v4517414_tabs'):
        return None
    idx = page.v4517414_tabs.currentIndex()
    if idx == 0:
        return 'summary'
    if idx == 1:
        return 'daily'
    if idx == 2:
        return 'sensitive'
    if idx == 3:
        return 'fraud'
    return 'all'


def _refresh_summary(page: ToolsPage) -> None:
    summary = page.service.movement_summary() if hasattr(page.service, 'movement_summary') else {}
    cards = getattr(page, 'v4517414_cards', {})
    for key, card in cards.items():
        if key == 'top_user':
            tu = summary.get('top_user') or {}
            card.set_value(f"{tu.get('name','') or '-'} ({tu.get('c',0)})")
        elif key == 'last_fraud':
            lf = summary.get('last_fraud') or {}
            card.set_value((lf.get('action') or '-')[:28])
        else:
            card.set_value(str(summary.get(key, 0)))
    if hasattr(page, 'v4517414_summary_table'):
        rows = [
            ['حركات اليوم', summary.get('today_total', 0)],
            ['الحركات الحساسة اليوم', summary.get('sensitive_total', 0)],
            ['الخصومات اليوم', summary.get('discount_total', 0)],
            ['الحذف/التعطيل اليوم', summary.get('delete_total', 0)],
            ['المرتجعات اليوم', summary.get('return_total', 0)],
            ['الحركات غير المقروءة', summary.get('unread_total', 0)],
            ['أكثر مستخدم حركة', f"{(summary.get('top_user') or {}).get('name','-')} ({(summary.get('top_user') or {}).get('c',0)})"],
            ['آخر تنبيه احتيال', (summary.get('last_fraud') or {}).get('action', '-')],
        ]
        page.v4517414_summary_table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            page.v4517414_summary_table.put(r, 0, row[0]); page.v4517414_summary_table.put(r, 1, row[1])
    _set_movement_status(page, 'تم تحديث الملخص فقط')


def _optimized_refresh_center(page: ToolsPage):
    try:
        if not hasattr(page, 'v4517414_stack'):
            return
        mode = _active_movement_mode(page)
        if mode == 'summary' or mode is None:
            _refresh_summary(page)
            return
        table = {
            'daily': getattr(page, 'v4517414_daily_table', None),
            'sensitive': getattr(page, 'v4517414_sensitive_table', None),
            'fraud': getattr(page, 'v4517414_fraud_table', None),
        }.get(mode)
        if table is None:
            return
        limit = _movement_page_size(page)
        rows = page.service.list_unified_movements(limit, **_optimized_filters(page, mode)) if hasattr(page.service, 'list_unified_movements') else []
        movement_ui._fill_table(table, rows) if movement_ui else None
        shown_from = _movement_offset(page) + (1 if rows else 0)
        shown_to = _movement_offset(page) + len(rows)
        _set_movement_status(page, f'يعرض {shown_from}-{shown_to} | التحديث كسول للتبويب الحالي فقط')
    except Exception as exc:
        log_exception(exc)
        try:
            QMessageBox.warning(page, 'تعذر تحديث سجل الحركات', str(exc))
        except Exception:
            pass


def _sync_and_refresh(self: ToolsPage):
    try:
        _set_movement_status(self, 'جاري مزامنة آخر الحركات...')
        if hasattr(self.service, 'sync_unified_movements_light'):
            self.service.sync_unified_movements_light(limit=500, days=14)
        elif hasattr(self.service, 'sync_unified_movements'):
            self.service.sync_unified_movements(limit=500, days=14)
        self.v462_movement_offset = 0
        self.v4517414_refresh_center()
        self.notify('تمت مزامنة سجل الحركات')
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر المزامنة', str(exc))


def _reset_and_refresh(self: ToolsPage):
    self.v462_movement_offset = 0
    self.v4517414_refresh_center()


def _next_page(self: ToolsPage):
    self.v462_movement_offset = _movement_offset(self) + _movement_page_size(self)
    self.v4517414_refresh_center()


def _prev_page(self: ToolsPage):
    self.v462_movement_offset = max(0, _movement_offset(self) - _movement_page_size(self))
    self.v4517414_refresh_center()


def _show_movement_details(self: ToolsPage):
    table = self.v4517414_stack.currentWidget() if hasattr(self, 'v4517414_stack') else None
    if not isinstance(table, QTableWidget):
        return
    row = table.currentRow()
    if row < 0:
        return
    values = {}
    for c in range(table.columnCount()):
        header = table.horizontalHeaderItem(c).text() if table.horizontalHeaderItem(c) else str(c)
        item = table.item(row, c)
        values[header] = item.text() if item else ''
    dlg = QDialog(self); dlg.setWindowTitle('تفاصيل الحركة'); dlg.resize(720, 520)
    lay = QVBoxLayout(dlg)
    text = QTextEdit(); text.setReadOnly(True)
    text.setPlainText(json.dumps(values, ensure_ascii=False, indent=2))
    lay.addWidget(text, 1)
    buttons = QDialogButtonBox(QDialogButtonBox.Close); buttons.rejected.connect(dlg.reject); buttons.accepted.connect(dlg.accept)
    lay.addWidget(buttons)
    dlg.exec()


def _enhance_movement_center(page: ToolsPage) -> None:
    if getattr(page, '_v462_movement_enhanced', False):
        return
    page.v462_movement_offset = 0
    for table_name in ('v4517414_daily_table', 'v4517414_sensitive_table', 'v4517414_fraud_table'):
        table = getattr(page, table_name, None)
        if isinstance(table, QTableWidget):
            table.itemDoubleClicked.connect(lambda *_: page.v462_show_movement_details())
    if hasattr(page, 'v4517414_tabs'):
        page.v4517414_tabs.currentChanged.connect(lambda *_: page.v462_reset_and_refresh())
    page._v462_movement_enhanced = True


def _install_group_headers(page: ToolsPage) -> None:
    """Lightweight organization aid: rename main tabs into clear business groups.

    Full physical nesting would risk breaking old patch references to existing widgets. This
    keeps compatibility while removing ambiguity and duplicate-looking names.
    """
    if getattr(page, '_v462_group_headers_done', False) or not hasattr(page, 'tabs'):
        return
    groups = {
        'سجل الحركات': '📊 لوحة الرقابة - مركز سجل الحركات',
        'سجل التدقيق': '📊 لوحة الرقابة - سجل التدقيق',
        'سجل العمليات': '📊 لوحة الرقابة - سجل العمليات',
        'عمولات الموظفين': '⚙️ إدارة العمليات - العمولات',
        'أهداف الموظفين': '⚙️ إدارة العمليات - الأهداف والمكافآت',
        'الفواتير المعلقة': '⚙️ إدارة العمليات - الفواتير المعلقة',
        'الإغلاق اليومي': '⚙️ إدارة العمليات - الإغلاقات اليومية',
        'حركة المخزون': '📦 المخزون والمستودعات - حركة المخزون',
        'جرد متقدم': '📦 المخزون والمستودعات - الجرد',
        'الفروع والمخازن': '📦 المخزون والمستودعات - الفروع والمستودعات',
        'إعدادات الشركة': '🛡️ الإعدادات والأمان - إعدادات النظام',
        'نسخ وباركود': '🛡️ الإعدادات والأمان - النسخ والباركود',
    }
    for i in range(page.tabs.count()):
        title = page.tabs.tabText(i)
        for old, new in groups.items():
            if old in title and not title.startswith(('📊', '⚙️', '📦', '🛡️')):
                page.tabs.setTabText(i, new)
                break
    page._v462_group_headers_done = True


def _tools_init(self: ToolsPage, service, notify, current_user=None):
    # Patch movement-center globals before earlier wrapped initializers call them.
    if movement_ui is not None:
        movement_ui._make_filter_bar = _optimized_filter_bar
        movement_ui._current_filters = _optimized_filters
        movement_ui._refresh_center = _optimized_refresh_center
    _ORIG_TOOLS_INIT(self, service, notify, current_user)
    _enhance_movement_center(self)
    _install_group_headers(self)


def _tools_refresh(self: ToolsPage):
    # Keep legacy refresh for non-movement tabs, but movement center is optimized and no longer loads 3 large lists.
    if _ORIG_TOOLS_REFRESH:
        _ORIG_TOOLS_REFRESH(self)
    _enhance_movement_center(self)
    _install_group_headers(self)


if movement_ui is not None:
    movement_ui._make_filter_bar = _optimized_filter_bar
    movement_ui._current_filters = _optimized_filters
    movement_ui._refresh_center = _optimized_refresh_center

ToolsPage.__init__ = _tools_init
ToolsPage.refresh = _tools_refresh
ToolsPage.v4517414_refresh_center = _optimized_refresh_center
ToolsPage.v462_sync_and_refresh = _sync_and_refresh
ToolsPage.v462_reset_and_refresh = _reset_and_refresh
ToolsPage.v462_next_page = _next_page
ToolsPage.v462_prev_page = _prev_page
ToolsPage.v462_show_movement_details = _show_movement_details
