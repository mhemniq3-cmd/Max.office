from __future__ import annotations

from PySide6.QtWidgets import QMessageBox, QCheckBox, QWidget, QGridLayout, QLabel, QVBoxLayout, QLineEdit, QPushButton, QHBoxLayout
from ui.ui_common import PERM_LABELS, Table
from ui.pages.products_page import ProductsPage
from ui.pages.users_page import UsersPage
from ui.pages.tools_page import ToolsPage
from services.error_logger import log_exception

V4516_UI_PERMS = {
    'can_barcode_manage': 'إدارة/توليد الباركود',
    'can_scan_barcode': 'استخدام قارئ الباركود',
    'can_view_activity_logs': 'عرض سجل الحركات الكامل',
    'can_export_reports': 'تصدير التقارير',
    'can_print_reports': 'طباعة التقارير',
    'can_delete_records': 'حذف/تعطيل السجلات',
    'can_view_profit': 'عرض الأرباح',
    'can_view_cost': 'عرض التكلفة',
    'can_price_edit': 'تعديل الأسعار',
    'can_quantity_edit': 'تعديل الكميات',
}
PERM_LABELS.update(V4516_UI_PERMS)

_ORIG_USERS_BUILD = UsersPage.build
_ORIG_USERS_LOAD_SELECTED = UsersPage.load_selected
_ORIG_PRODUCTS_GENERATE = ProductsPage.generate_barcode
_ORIG_TOOLS_REFRESH = ToolsPage.refresh


def _add_perm_tab(page: UsersPage):
    if getattr(page, '_v4516_perm_tab_added', False):
        return
    if not hasattr(page, 'perm_tabs') or not hasattr(page, 'checks'):
        return
    tab = QWidget()
    layout = QVBoxLayout(tab)
    note = QLabel('صلاحيات دقيقة للتحكم بما يراه أو يفعله كل مستخدم: الأرباح، التكلفة، تعديل الأسعار، الباركود، الطباعة والتصدير، وسجل الحركات.')
    note.setWordWrap(True)
    note.setObjectName('noticeBox')
    grid_host = QWidget()
    grid = QGridLayout(grid_host)
    grid.setContentsMargins(10, 10, 10, 10)
    grid.setHorizontalSpacing(14)
    grid.setVerticalSpacing(8)
    keys = [
        'can_view_profit', 'can_view_cost', 'can_price_edit', 'can_quantity_edit',
        'can_barcode_manage', 'can_scan_barcode', 'can_print_reports', 'can_export_reports',
        'can_view_activity_logs', 'can_delete_records',
    ]
    for i, key in enumerate(keys):
        cb = page.checks.get(key)
        if cb is None:
            cb = QCheckBox(PERM_LABELS.get(key, key))
            cb.setMinimumHeight(30)
            page.checks[key] = cb
        grid.addWidget(cb, i // 2, i % 2)
    layout.addWidget(note)
    layout.addWidget(grid_host)
    layout.addStretch()
    page.perm_tabs.addTab(tab, 'دقيق ومتقدم')
    page._v4516_perm_tab_added = True


def _users_build(self: UsersPage):
    _ORIG_USERS_BUILD(self)
    _add_perm_tab(self)
    try:
        self.apply_role_permissions()
    except Exception:
        pass


def _users_load_selected(self: UsersPage):
    _ORIG_USERS_LOAD_SELECTED(self)
    try:
        if self.table.currentRow() < 0 or self.table.currentRow() >= len(self.rows):
            return
        u = self.rows[self.table.currentRow()]
        checks = self._live_checks() if hasattr(self, '_live_checks') else dict(self.checks)
        for key, cb in checks.items():
            try:
                cb.setChecked(bool(u[key]))
            except Exception:
                try:
                    cb.setChecked(False)
                except RuntimeError:
                    self.checks.pop(key, None)
    except Exception as exc:
        log_exception(exc, 'v45.16 load permissions')


def _products_generate_barcode(self: ProductsPage):
    """Allow barcode generation before product save as well as for selected products."""
    try:
        code = self.service.generate_barcode_value(getattr(self, 'product_id', None))
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر التوليد', str(exc))
        return
    self.barcode.setText(code)
    try:
        self.refresh()
    except Exception:
        pass
    self.notify('تم توليد الباركود. احفظ المنتج لاستخدامه.' if not getattr(self, 'product_id', None) else 'تم توليد الباركود وتحديث المنتج')


def _tools_refresh(self: ToolsPage):
    try:
        _ORIG_TOOLS_REFRESH(self)
    except Exception as exc:
        log_exception(exc, 'v45.16 tools refresh fallback')
    # Force the visible logs tables to use the new audit trail when available.
    try:
        if hasattr(self, 'logs_table'):
            logs = self.service.list_activity_logs(500)
            self.logs_table.setRowCount(len(logs))
            for r, row in enumerate(logs):
                vals = [row.get('created_at',''), row.get('username',''), row.get('action',''), row.get('details','')]
                for c, v in enumerate(vals):
                    self.logs_table.put(r, c, v)
        if hasattr(self, 'audit_table'):
            logs = self.service.list_activity_logs(500)
            self.audit_table.setRowCount(len(logs))
            for r, row in enumerate(logs):
                vals = [row.get('created_at',''), row.get('username',''), row.get('action',''), row.get('entity_type','') + ' ' + str(row.get('entity_id','')) + ' ' + str(row.get('details',''))]
                for c, v in enumerate(vals):
                    self.audit_table.put(r, c, v)
    except Exception as exc:
        log_exception(exc, 'v45.16 refresh audit tables')


UsersPage.build = _users_build
UsersPage.load_selected = _users_load_selected
ProductsPage.generate_barcode = _products_generate_barcode
ToolsPage.refresh = _tools_refresh
