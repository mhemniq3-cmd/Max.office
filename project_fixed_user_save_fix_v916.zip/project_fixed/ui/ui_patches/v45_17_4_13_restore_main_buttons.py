from __future__ import annotations

# This patch intentionally does not replace MainWindow.show_page.
# It exists as a final marker after v45.17.4.12: main navigation must use the
# stable implementation from main_window_core / earlier patches. The previous
# perceived-speed override caused all sidebar/top buttons to stop opening pages
# on some Windows installs.

from ui.main_window_core import MainWindow
from services.core_common import log_exception

try:
    # If v45.17.4.12 saved an original show_page/refresh_current, restore it.
    import ui.ui_patches.v45_17_4_12_barcode_customers_speed_movements_ui as p12
    original_show = getattr(p12, '_ORIG_MW_SHOW_PAGE', None)
    original_refresh = getattr(p12, '_ORIG_MW_REFRESH', None)
    if callable(original_show):
        MainWindow.show_page = original_show
    if callable(original_refresh):
        MainWindow.refresh_current = original_refresh
except Exception as exc:
    try:
        log_exception(exc)
    except Exception:
        pass
