
from __future__ import annotations

import json
from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

_ORIG_INIT = ToolsPage.__init__
_ORIG_REFRESH = getattr(ToolsPage, 'refresh', None)


def _safe_msg(self, title, exc):
    try:
        QMessageBox.warning(self, title, str(exc))
    except Exception:
        pass


def _tab_exists(self, title: str) -> bool:
    try:
        for i in range(self.tabs.count()):
            if self.tabs.tabText(i) == title:
                return True
    except Exception:
        return False
    return False


def _add_tab_once(self, title: str, widget: QWidget):
    if not _tab_exists(self, title):
        self.tabs.addTab(widget, title)


def _make_btn(text, fn=None, primary=False):
    b = QPushButton(text)
    b.setObjectName('primaryButton' if primary else 'secondaryButton')
    b.setMinimumHeight(38)
    b.setCursor(Qt.PointingHandCursor)
    if fn:
        b.clicked.connect(fn)
    return b


def _polish(widget):
    try:
        for edit in widget.findChildren(QLineEdit):
            edit.setMinimumHeight(36)
            edit.setClearButtonEnabled(True)
        for combo in widget.findChildren(QComboBox):
            combo.setMinimumHeight(36)
        for spin in widget.findChildren(QSpinBox):
            spin.setMinimumHeight(36)
        for spin in widget.findChildren(QDoubleSpinBox):
            spin.setMinimumHeight(36)
        for btn in widget.findChildren(QPushButton):
            btn.setMinimumHeight(max(btn.minimumHeight(), 36))
        for table in widget.findChildren(QTableWidget):
            table.setMinimumHeight(max(table.minimumHeight(), 230))
            table.setAlternatingRowColors(True)
            table.horizontalHeader().setStretchLastSection(True)
    except Exception:
        pass
    return widget


def _build_fraud_tab(self):
    tab = QWidget(); root = QVBoxLayout(tab); root.setSpacing(10)
    note = QLabel('كشف الاحتيال: إرجاعات متكررة، خصومات كبيرة، فواتير صفرية، دخول خارج الدوام، كميات غير طبيعية، وتعديل السعر أكثر من 3 مرات يومياً.')
    note.setWordWrap(True); note.setObjectName('noticeBox'); root.addWidget(note)
    row = QHBoxLayout()
    scan = _make_btn('فحص الآن وتوليد التنبيهات', self.v451745_scan_fraud, True)
    close = _make_btn('إغلاق التنبيه المحدد', self.v451745_resolve_fraud)
    self.v451745_fraud_status = QComboBox(); self.v451745_fraud_status.addItems(['', 'مفتوح', 'مغلق'])
    self.v451745_fraud_status.currentIndexChanged.connect(self.v451745_refresh_fraud)
    row.addWidget(scan); row.addWidget(close); row.addWidget(QLabel('الحالة')); row.addWidget(self.v451745_fraud_status); row.addStretch()
    root.addLayout(row)
    self.v451745_fraud_table = Table(['ID','الخطورة','النمط','العنوان','التفاصيل','المستخدم','الحالة','الوقت'])
    root.addWidget(self.v451745_fraud_table, 1)
    return _polish(tab)


def _build_coupons_tab(self):
    tab = QWidget(); root = QVBoxLayout(tab); root.setSpacing(10)
    note = QLabel('الكوبونات: خصم نسبة، خصم مبلغ، منتج مجاني، أو شحن مجاني. الحقول: code, type, value, min_purchase, max_uses, used_count, expiry_date.')
    note.setWordWrap(True); note.setObjectName('noticeBox'); root.addWidget(note)
    form = QFrame(); form.setObjectName('surface'); grid = QGridLayout(form); grid.setSpacing(10)
    self.v451745_coupon_code = QLineEdit(); self.v451745_coupon_code.setPlaceholderText('مثال: RAMADAN20')
    self.v451745_coupon_type = QComboBox()
    self.v451745_coupon_type.addItem('خصم نسبة', 'percent')
    self.v451745_coupon_type.addItem('خصم مبلغ', 'amount')
    self.v451745_coupon_type.addItem('منتج مجاني', 'free_product')
    self.v451745_coupon_type.addItem('شحن مجاني', 'free_shipping')
    self.v451745_coupon_value = QDoubleSpinBox(); self.v451745_coupon_value.setMaximum(999999999); self.v451745_coupon_value.setDecimals(2)
    self.v451745_coupon_min = QDoubleSpinBox(); self.v451745_coupon_min.setMaximum(999999999); self.v451745_coupon_min.setDecimals(2)
    self.v451745_coupon_max = QSpinBox(); self.v451745_coupon_max.setMaximum(9999999)
    self.v451745_coupon_expiry = QLineEdit(); self.v451745_coupon_expiry.setPlaceholderText('YYYY-MM-DD')
    self.v451745_coupon_active = QCheckBox('نشط'); self.v451745_coupon_active.setChecked(True)
    fields = [
        ('code', self.v451745_coupon_code),
        ('type', self.v451745_coupon_type),
        ('value', self.v451745_coupon_value),
        ('min_purchase', self.v451745_coupon_min),
        ('max_uses', self.v451745_coupon_max),
        ('expiry_date', self.v451745_coupon_expiry),
        ('active', self.v451745_coupon_active),
    ]
    for i, (lab, wid) in enumerate(fields):
        grid.addWidget(QLabel(lab), (i//3)*2, i%3)
        grid.addWidget(wid, (i//3)*2+1, i%3)
    save = _make_btn('حفظ الكوبون', self.v451745_save_coupon, True)
    preview = _make_btn('تجربة الكوبون على 100,000 د.ع', self.v451745_preview_coupon)
    grid.addWidget(save, 6, 0); grid.addWidget(preview, 6, 1)
    root.addWidget(form)
    self.v451745_coupons_table = Table(['ID','الكود','النوع','القيمة','الحد الأدنى','الاستخدام','ينتهي','نشط'])
    root.addWidget(self.v451745_coupons_table, 1)
    return _polish(tab)


def _build_interactive_dashboard_tab(self):
    tab = QWidget(); root = QVBoxLayout(tab); root.setSpacing(10)
    row = QHBoxLayout()
    self.v451745_dash_days = QSpinBox(); self.v451745_dash_days.setRange(1, 365); self.v451745_dash_days.setValue(30); self.v451745_dash_days.setSuffix(' يوم')
    refresh = _make_btn('تحديث لوحة التحكم', self.v451745_refresh_dashboard, True)
    row.addWidget(refresh); row.addWidget(self.v451745_dash_days); row.addStretch()
    root.addLayout(row)
    kpis = QHBoxLayout(); self.v451745_kpi_sales = QLabel('المبيعات: 0'); self.v451745_kpi_profit = QLabel('الربح: 0'); self.v451745_kpi_invoices = QLabel('الفواتير: 0')
    for label in [self.v451745_kpi_sales, self.v451745_kpi_profit, self.v451745_kpi_invoices]:
        label.setObjectName('noticeBox'); label.setMinimumHeight(48); kpis.addWidget(label)
    root.addLayout(kpis)
    tabs = QTabWidget(); root.addWidget(tabs, 1)
    self.v451745_line_table = Table(['اليوم','المبيعات','الربح','الفواتير'])
    self.v451745_payment_table = Table(['طريقة الدفع','الإجمالي','الفواتير'])
    self.v451745_product_table = Table(['المنتج','الكمية','الربح'])
    self.v451745_heat_table = Table(['الساعة','الفواتير','المبيعات'])
    tabs.addTab(self.v451745_line_table, 'مخطط خطي للمبيعات')
    tabs.addTab(self.v451745_payment_table, 'طرق الدفع')
    tabs.addTab(self.v451745_product_table, 'أفضل المنتجات')
    tabs.addTab(self.v451745_heat_table, 'خريطة حرارية للساعات')
    return _polish(tab)


def _build_audit_v2_tab(self):
    tab = QWidget(); root = QVBoxLayout(tab); root.setSpacing(10)
    row = QHBoxLayout()
    self.v451745_audit_table_filter = QLineEdit(); self.v451745_audit_table_filter.setPlaceholderText('فلترة حسب الجدول مثل products أو sales')
    refresh = _make_btn('تحديث سجل التدقيق v2', self.v451745_refresh_audit_v2, True)
    row.addWidget(refresh); row.addWidget(self.v451745_audit_table_filter, 1); root.addLayout(row)
    self.v451745_audit_table = Table(['ID','الجدول','السجل','العملية','المستخدم','IP','السبب','الوقت','قبل','بعد'])
    root.addWidget(self.v451745_audit_table, 1)
    return _polish(tab)


def _init(self, service, notify, current_user=None):
    _ORIG_INIT(self, service, notify, current_user)
    try:
        _add_tab_once(self, 'كشف الاحتيال', _build_fraud_tab(self))
        _add_tab_once(self, 'الكوبونات', _build_coupons_tab(self))
        _add_tab_once(self, 'لوحة تحكم تفاعلية', _build_interactive_dashboard_tab(self))
        _add_tab_once(self, 'سجل التدقيق v2', _build_audit_v2_tab(self))
        self.v451745_refresh_all()
    except Exception as exc:
        log_exception(exc)
        try:
            notify(f'تعذر تحميل أدوات v45.17.4.5: {exc}')
        except Exception:
            pass


def _refresh(self):
    if _ORIG_REFRESH:
        try:
            _ORIG_REFRESH(self)
        except Exception as exc:
            log_exception(exc)
    try:
        self.v451745_refresh_all()
    except Exception as exc:
        log_exception(exc)


def _put_rows(table, rows, fields):
    table.setRowCount(len(rows))
    for r, row in enumerate(rows):
        for c, field in enumerate(fields):
            val = row.get(field, '') if isinstance(row, dict) else row[field]
            table.put(r, c, val)


def _refresh_all(self):
    self.v451745_refresh_fraud()
    self.v451745_refresh_coupons()
    self.v451745_refresh_dashboard()
    self.v451745_refresh_audit_v2()


def _scan_fraud(self):
    try:
        count = len(self.service.fraud_scan_now())
        self.notify(f'تم فحص الاحتيال. تنبيهات جديدة: {count}')
        self.v451745_refresh_fraud()
    except Exception as exc:
        _safe_msg(self, 'تعذر فحص الاحتيال', exc)


def _refresh_fraud(self):
    if not hasattr(self, 'v451745_fraud_table'):
        return
    try:
        status = self.v451745_fraud_status.currentText()
        rows = [dict(r) for r in self.service.list_fraud_alerts(status, 500)]
        self.v451745_fraud_table.setRowCount(len(rows))
        for r, x in enumerate(rows):
            vals = [x.get('id'), x.get('severity'), x.get('rule_code'), x.get('title'), x.get('details'), x.get('user_name'), x.get('status'), x.get('created_at')]
            for c, v in enumerate(vals): self.v451745_fraud_table.put(r, c, v)
    except Exception as exc:
        log_exception(exc)


def _resolve_fraud(self):
    try:
        row = self.v451745_fraud_table.currentRow()
        if row < 0:
            raise ValueError('اختر تنبيه أولاً')
        alert_id = int(self.v451745_fraud_table.item(row, 0).text())
        self.service.resolve_fraud_alert(alert_id, 'إغلاق من الواجهة')
        self.notify('تم إغلاق التنبيه')
        self.v451745_refresh_fraud()
    except Exception as exc:
        _safe_msg(self, 'تعذر إغلاق التنبيه', exc)


def _save_coupon(self):
    try:
        self.service.save_coupon(
            self.v451745_coupon_code.text(),
            self.v451745_coupon_type.currentData(),
            self.v451745_coupon_value.value(),
            self.v451745_coupon_min.value(),
            self.v451745_coupon_max.value(),
            self.v451745_coupon_expiry.text(),
            1 if self.v451745_coupon_active.isChecked() else 0,
        )
        self.notify('تم حفظ الكوبون')
        self.v451745_refresh_coupons()
    except Exception as exc:
        _safe_msg(self, 'تعذر حفظ الكوبون', exc)


def _preview_coupon(self):
    try:
        res = self.service.apply_coupon_preview(self.v451745_coupon_code.text(), 100000)
        QMessageBox.information(self, 'تجربة الكوبون', f"الكود: {res['code']}\nالخصم: {money(res['discount'])}\nالإجمالي بعد الخصم: {money(res['final_total'])}")
    except Exception as exc:
        _safe_msg(self, 'تعذر تجربة الكوبون', exc)


def _refresh_coupons(self):
    if not hasattr(self, 'v451745_coupons_table'):
        return
    try:
        rows = [dict(r) for r in self.service.list_coupons(True)]
        self.v451745_coupons_table.setRowCount(len(rows))
        for r, x in enumerate(rows):
            vals = [x.get('id'), x.get('code'), x.get('type'), x.get('value'), x.get('min_purchase'), f"{x.get('used_count')}/{x.get('max_uses')}", x.get('expiry_date'), 'نعم' if x.get('active') else 'لا']
            for c, v in enumerate(vals): self.v451745_coupons_table.put(r, c, v)
    except Exception as exc:
        log_exception(exc)


def _refresh_dashboard(self):
    if not hasattr(self, 'v451745_line_table'):
        return
    try:
        data = self.service.interactive_dashboard_data(self.v451745_dash_days.value())
        kpi = data.get('kpi', {})
        self.v451745_kpi_sales.setText('المبيعات اليومية: ' + money(kpi.get('sales', 0)))
        self.v451745_kpi_profit.setText('الربح اليومي: ' + money(kpi.get('profit', 0)))
        self.v451745_kpi_invoices.setText('عدد الفواتير: ' + str(kpi.get('invoices', 0)))
        _put_rows(self.v451745_line_table, data.get('line', []), ['day','sales','profit','invoices'])
        _put_rows(self.v451745_payment_table, data.get('payments', []), ['method','total','invoices'])
        _put_rows(self.v451745_product_table, data.get('products', []), ['product_name','qty','profit'])
        _put_rows(self.v451745_heat_table, data.get('heat', []), ['hour','invoices','sales'])
    except Exception as exc:
        log_exception(exc)


def _refresh_audit_v2(self):
    if not hasattr(self, 'v451745_audit_table'):
        return
    try:
        rows = [dict(r) for r in self.service.audit_v2_rows(self.v451745_audit_table_filter.text().strip(), 500)]
        self.v451745_audit_table.setRowCount(len(rows))
        for r, x in enumerate(rows):
            oldv = str(x.get('old_values') or '')[:250]
            newv = str(x.get('new_values') or '')[:250]
            vals = [x.get('id'), x.get('table_name'), x.get('record_id'), x.get('action'), x.get('username') or x.get('user_id'), x.get('ip'), x.get('reason'), x.get('timestamp'), oldv, newv]
            for c, v in enumerate(vals): self.v451745_audit_table.put(r, c, v)
    except Exception as exc:
        log_exception(exc)


ToolsPage.__init__ = _init
ToolsPage.refresh = _refresh
ToolsPage.v451745_refresh_all = _refresh_all
ToolsPage.v451745_scan_fraud = _scan_fraud
ToolsPage.v451745_refresh_fraud = _refresh_fraud
ToolsPage.v451745_resolve_fraud = _resolve_fraud
ToolsPage.v451745_save_coupon = _save_coupon
ToolsPage.v451745_preview_coupon = _preview_coupon
ToolsPage.v451745_refresh_coupons = _refresh_coupons
ToolsPage.v451745_refresh_dashboard = _refresh_dashboard
ToolsPage.v451745_refresh_audit_v2 = _refresh_audit_v2
