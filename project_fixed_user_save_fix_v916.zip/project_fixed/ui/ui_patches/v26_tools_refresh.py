from __future__ import annotations

from pathlib import Path
import html
import os

from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.theme_manager import apply_theme as theme_apply, current_theme_key as theme_current_key, set_theme_key as theme_set_key, theme_label as theme_display_label, theme_path as theme_qss_path
from ui.main_window_core import *
import ui.ui_patches.v11_sales_safety as _prev_v11_sales_safety
globals().update({k: v for k, v in vars(_prev_v11_sales_safety).items() if not k.startswith('__')})
import ui.ui_patches.v20_gdrive_ui as _prev_v20_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v20_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v21_backup_ui as _prev_v21_backup_ui
globals().update({k: v for k, v in vars(_prev_v21_backup_ui).items() if not k.startswith('__')})
import ui.ui_patches.v22_gdrive_ui as _prev_v22_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v22_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v23_tools_reports as _prev_v23_tools_reports
globals().update({k: v for k, v in vars(_prev_v23_tools_reports).items() if not k.startswith('__')})
import ui.ui_patches.v25_lazy_permissions as _prev_v25_lazy_permissions
globals().update({k: v for k, v in vars(_prev_v25_lazy_permissions).items() if not k.startswith('__')})

def _v26_tools_refresh(self):
    try:
        return _orig_tools_refresh_v26(self)
    except PermissionError as exc:
        try:
            self.notify(str(exc))
        except Exception as exc:
            log_exception(exc)
        try:
            QMessageBox.warning(self, 'صلاحية مطلوبة', str(exc))
        except Exception as exc:
            log_exception(exc)
        return None
    except Exception as exc:
        try:
            self.notify('تعذر تحديث بعض أدوات الإدارة')
        except Exception as exc:
            log_exception(exc)
        try:
            QMessageBox.warning(self, 'تعذر تحديث الأدوات', str(exc))
        except Exception as exc:
            log_exception(exc)
        return None

ToolsPage.refresh = _v26_tools_refresh

# ---------------------------------------------------------------------------
# V26 TOOLS PAGE FIX
# The V25 tools page could fail completely when one internal report raised an
# exception (most visibly commission_report()). Refresh is now section-safe.
# ---------------------------------------------------------------------------

def _v26_table_message(table, text):
    try:
        table.setRowCount(1)
        cols = table.columnCount() if hasattr(table, 'columnCount') else 1
        for c in range(cols):
            table.put(0, c, text if c == 0 else '')
    except Exception as exc:
        log_exception(exc)


def _v26_goal_value(row, key, default=0):
    try:
        return row.get(key, default)
    except Exception:
        try:
            return row[key]
        except Exception:
            return default


def _v26_tools_refresh(self):
    warnings = []

    def run(section, fn):
        try:
            fn()
        except Exception as exc:
            warnings.append(f'{section}: {exc}')

    def refresh_logs():
        if not hasattr(self, 'logs_table'):
            return
        logs = self.service.list_activity_logs()
        self.logs_table.setRowCount(len(logs))
        for r, row in enumerate(logs):
            for c, v in enumerate([row['created_at'], row['username'] or '', row['action'], row['details'] or '']):
                self.logs_table.put(r, c, v)

    def refresh_audit():
        if not hasattr(self, 'audit_table'):
            return
        audit = self.service.audit_rows()
        self.audit_table.setRowCount(len(audit))
        for r, row in enumerate(audit):
            for c, v in enumerate([row['created_at'], row['username'] or '', row['action'], row['details'] or '']):
                self.audit_table.put(r, c, v)

    def refresh_goals():
        if not hasattr(self, 'goal_employee'):
            return
        cur_goal = self.goal_employee.currentData()
        self.goal_employee.clear()
        if self.service.is_admin_user(self.current_user):
            employees_for_goals = self.service.list_employees()
        else:
            emp = self.service.employee_for_user(self.current_user)
            employees_for_goals = [emp] if emp else []
        for e in employees_for_goals:
            if e:
                self.goal_employee.addItem(e['name'], e['id'])
        if not self.service.is_admin_user(self.current_user) and self.goal_employee.count() == 0:
            self.goal_employee.addItem('لا يوجد موظف مرتبط بهذا المستخدم', None)
        if hasattr(self, 'goal_product'):
            cur_prod = self.goal_product.currentData()
            self.goal_product.clear()
            self.goal_product.addItem('بدون منتج محدد', None)
            for p in self.service.list_products(''):
                self.goal_product.addItem(f"{p['name']} - {p['barcode'] or ''}", p['id'])
            if cur_prod is not None:
                idxp = self.goal_product.findData(cur_prod)
                if idxp >= 0:
                    self.goal_product.setCurrentIndex(idxp)
        if cur_goal is not None:
            idx = self.goal_employee.findData(cur_goal)
            if idx >= 0:
                self.goal_employee.setCurrentIndex(idx)
        goals = self.service.employee_goal_rows(self.current_user)
        self.goals_table.setRowCount(len(goals))
        done_count = 0
        bonus_total = 0.0
        for r, g in enumerate(goals):
            target = float(_v26_goal_value(g, 'target_sales', 0) or 0)
            achieved = float(_v26_goal_value(g, 'achieved', 0) or 0)
            ratio = (achieved / target * 100) if target > 0 else 0
            remaining = max(target - achieved, 0)
            done = ratio >= 100
            status = '✅ مكتمل' if done else ('⚠️ قريب' if ratio >= 80 else 'قيد المتابعة')
            if done:
                done_count += 1
                bonus_total += float(_v26_goal_value(g, 'reward_amount', _v26_goal_value(g, 'bonus_amount', 0)) or 0)
            goal_type = _v26_goal_value(g, 'goal_type', 'مبيعات')
            product_name = _v26_goal_value(g, 'product_name', '')
            display_type = goal_type + (f' | {product_name}' if goal_type == 'بيع منتج معين' and product_name else '')
            vals = [
                _v26_goal_value(g, 'employee', ''),
                display_type,
                f"{_v26_goal_value(g, 'period_type', '')} - {_v26_goal_value(g, 'period_start', '')}",
                format_goal_value(target, goal_type),
                format_goal_value(achieved, goal_type),
                f'{ratio:.1f}%',
                format_goal_value(remaining, goal_type),
                money(_v26_goal_value(g, 'reward_amount', _v26_goal_value(g, 'bonus_amount', 0))),
                _v26_goal_value(g, 'status_text', status),
            ]
            for c, v in enumerate(vals):
                self.goals_table.put(r, c, v, _v26_goal_value(g, 'id') if c == 0 else None)
        if hasattr(self, 'goals_total_card'):
            self.goals_total_card.set_value(str(len(goals)))
            self.goals_done_card.set_value(str(done_count))
            self.goals_bonus_card.set_value(money(bonus_total))

    def refresh_inventory():
        if not hasattr(self, 'inv_table'):
            return
        inv = self.service.inventory_movements()
        self.inv_table.setRowCount(len(inv))
        for r, row in enumerate(inv):
            vals = [row['created_at'], row['product_name'], row['movement_type'], row['quantity_change'], row['old_quantity'], row['new_quantity'], row['ref_no'] or '', row['note'] or '']
            for c, v in enumerate(vals):
                self.inv_table.put(r, c, v)

    def refresh_commission():
        if not hasattr(self, 'comm_table'):
            return
        reps = self.service.commission_report()
        self.comm_table.setRowCount(len(reps))
        for r, row in enumerate(reps):
            net = float(row['commission'] or 0) - float(row['returned_commission'] or 0)
            vals = [row['employee'], money(row['sales']), money(row['commission']), money(row['returned_commission']), money(net)]
            for c, v in enumerate(vals):
                self.comm_table.put(r, c, v)

    def refresh_holds():
        if not hasattr(self, 'hold_table'):
            return
        holds = self.service.list_suspended_sales()
        self.hold_table.setRowCount(len(holds))
        for r, row in enumerate(holds):
            vals = [row['hold_no'], row['username'], row['customer'], row['payment_method'] or '', money(row['discount_amount']), row['created_at']]
            for c, v in enumerate(vals):
                self.hold_table.put(r, c, v)

    def refresh_count():
        if not hasattr(self, 'count_product'):
            return
        current_product = self.count_product.currentData()
        self.count_product.clear()
        for p in self.service.list_products(''):
            self.count_product.addItem(f"{p['name']} | مخزون: {p['quantity']}", p['id'])
        if current_product is not None:
            idx = self.count_product.findData(current_product)
            if idx >= 0:
                self.count_product.setCurrentIndex(idx)
        self.count_branch.clear()
        for b in self.service.list_branches():
            self.count_branch.addItem(b['name'], b['id'])
        self.count_warehouse.clear()
        for w in self.service.list_warehouses():
            self.count_warehouse.addItem(f"{w['branch_name']} / {w['name']}", w['id'])
        counts = self.service.inventory_count_rows()
        self.count_table.setRowCount(len(counts))
        for r, row in enumerate(counts):
            vals = [row['created_at'], row['product_name'], row['branch_name'], row['warehouse_name'], row['system_quantity'], row['counted_quantity'], row['damaged_quantity'], row['difference'], row['note'] or '']
            for c, v in enumerate(vals):
                self.count_table.put(r, c, v)

    def refresh_branches():
        if not hasattr(self, 'branch_table'):
            return
        branches = self.service.list_branches()
        whs = self.service.list_warehouses()
        rows2 = []
        for b in branches:
            rows2.append([b['name'], 'فرع', b['address'] or ''])
        for w in whs:
            rows2.append([w['name'], w['branch_name'], w['address'] or ''])
        self.branch_table.setRowCount(len(rows2))
        for r, vals in enumerate(rows2):
            for c, v in enumerate(vals):
                self.branch_table.put(r, c, v)
        if hasattr(self, 'wh_branch'):
            cur = self.wh_branch.currentData()
            self.wh_branch.clear()
            for b in branches:
                self.wh_branch.addItem(b['name'], b['id'])
            if cur is not None:
                idx = self.wh_branch.findData(cur)
                if idx >= 0:
                    self.wh_branch.setCurrentIndex(idx)

    def refresh_daily_close():
        if not hasattr(self, 'daily_close_table'):
            return
        rows = self.service.daily_closings()
        self.daily_close_table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            vals = [row['close_date'], row['user_name'], money(row['cash_sales']), money(row['credit_sales']), money(row['returns_amount']), money(row['discounts_amount']), money(row['profit_amount']), row['invoices_count'], money(row['counted_cash']), money(row['cash_difference']), row['note'] or '']
            for c, v in enumerate(vals):
                self.daily_close_table.put(r, c, v)

    run('سجل العمليات', refresh_logs)
    run('سجل التدقيق', refresh_audit)
    run('أهداف الموظفين', refresh_goals)
    run('حركة المخزون', refresh_inventory)
    run('تقرير العمولات', refresh_commission)
    run('الفواتير المعلقة', refresh_holds)
    run('الجرد', refresh_count)
    run('الفروع والمخازن', refresh_branches)
    run('الإغلاق اليومي', refresh_daily_close)

    if hasattr(self, 'health_table') and self.health_table.rowCount() == 0:
        self.health_table.setRowCount(1)
        self.health_table.put(0, 0, 'معلومة')
        self.health_table.put(0, 1, 'اضغط تشغيل فحص النظام الآن')
        self.health_table.put(0, 2, 'سيظهر التقرير هنا')

    if warnings:
        self.notify('تم تحديث الأدوات مع تنبيه: ' + warnings[0])
    else:
        self.notify('تم تحديث الأدوات')


ToolsPage.refresh = _v26_tools_refresh


# ---------------------------------------------------------------------------
# V27 UI: price levels, promotions, Excel import/export, promotion-aware carts
# ---------------------------------------------------------------------------

