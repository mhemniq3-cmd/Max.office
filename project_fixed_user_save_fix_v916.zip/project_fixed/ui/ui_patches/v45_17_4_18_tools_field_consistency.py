from __future__ import annotations

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

try:
    from PySide6.QtWidgets import QDateEdit, QTimeEdit, QDateTimeEdit, QGroupBox, QAbstractSpinBox
except Exception:  # pragma: no cover
    QDateEdit = QTimeEdit = QDateTimeEdit = QGroupBox = QAbstractSpinBox = None

_ORIG_INIT = ToolsPage.__init__
_ORIG_REFRESH = getattr(ToolsPage, 'refresh', None)

TOOLS_FIELD_STYLE = """
ToolsPage, ToolsPage QWidget {
    font-size: 13px;
}
ToolsPage QLineEdit,
ToolsPage QTextEdit,
ToolsPage QPlainTextEdit,
ToolsPage QComboBox,
ToolsPage QSpinBox,
ToolsPage QDoubleSpinBox,
ToolsPage QDateEdit,
ToolsPage QTimeEdit,
ToolsPage QDateTimeEdit {
    background-color: #ffffff;
    color: #111827;
    border: 1px solid #cbd5e1;
    border-radius: 10px;
    padding: 7px 10px;
    selection-background-color: #2563eb;
    selection-color: #ffffff;
}
ToolsPage QLineEdit:focus,
ToolsPage QTextEdit:focus,
ToolsPage QPlainTextEdit:focus,
ToolsPage QComboBox:focus,
ToolsPage QSpinBox:focus,
ToolsPage QDoubleSpinBox:focus,
ToolsPage QDateEdit:focus,
ToolsPage QTimeEdit:focus,
ToolsPage QDateTimeEdit:focus {
    border: 2px solid #2563eb;
    background-color: #ffffff;
    color: #0f172a;
}
ToolsPage QLineEdit:disabled,
ToolsPage QTextEdit:disabled,
ToolsPage QComboBox:disabled,
ToolsPage QSpinBox:disabled,
ToolsPage QDoubleSpinBox:disabled {
    background-color: #f1f5f9;
    color: #64748b;
    border-color: #d8e0ea;
}
ToolsPage QLabel {
    color: #0f172a;
}
ToolsPage QLabel#sectionTitle,
ToolsPage QLabel#miniTitle {
    font-size: 16px;
    font-weight: 800;
    color: #0f172a;
    padding: 4px 0px;
}
ToolsPage QLabel#formLabel {
    min-width: 120px;
    font-weight: 700;
    color: #334155;
}
ToolsPage QPushButton {
    min-height: 36px;
    padding: 8px 13px;
    border-radius: 10px;
    font-weight: 700;
}
ToolsPage QPushButton#primaryButton {
    background-color: #2563eb;
    color: #ffffff;
    border: 1px solid #1d4ed8;
}
ToolsPage QPushButton#navButton {
    background-color: #f8fafc;
    color: #0f172a;
    border: 1px solid #cbd5e1;
}
ToolsPage QPushButton:hover {
    border-color: #2563eb;
}
ToolsPage QTabWidget::pane {
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    background: #ffffff;
    top: -1px;
}
ToolsPage QTabBar::tab {
    min-height: 30px;
    min-width: 92px;
    padding: 8px 14px;
    margin: 2px;
    border-radius: 9px;
    background: #f1f5f9;
    color: #334155;
}
ToolsPage QTabBar::tab:selected {
    background: #2563eb;
    color: #ffffff;
}
ToolsPage QTableWidget {
    background-color: #ffffff;
    color: #111827;
    gridline-color: #e2e8f0;
    alternate-background-color: #f8fafc;
    border: 1px solid #dbe3ef;
    border-radius: 10px;
}
ToolsPage QTableWidget::item {
    padding: 6px;
    color: #111827;
}
ToolsPage QHeaderView::section {
    background-color: #f1f5f9;
    color: #0f172a;
    padding: 8px;
    border: 1px solid #e2e8f0;
    font-weight: 800;
}
ToolsPage QFrame#surface,
ToolsPage QFrame#card,
ToolsPage QGroupBox {
    background: #ffffff;
    color: #111827;
    border: 1px solid #e2e8f0;
    border-radius: 14px;
    padding: 10px;
}
ToolsPage QLabel#noticeBox {
    background: #f8fafc;
    color: #334155;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 10px;
}
"""


def _safe_layout_polish(root_widget: QWidget) -> None:
    for cls in (QVBoxLayout, QHBoxLayout, QGridLayout, QFormLayout):
        try:
            layouts = root_widget.findChildren(cls)
        except Exception:
            layouts = []
        for layout in layouts:
            try:
                m = layout.contentsMargins()
                if m.left() < 8 and m.top() < 8:
                    layout.setContentsMargins(10, 10, 10, 10)
                if layout.spacing() < 8:
                    layout.setSpacing(10)
                if isinstance(layout, QFormLayout):
                    layout.setHorizontalSpacing(max(layout.horizontalSpacing(), 14))
                    layout.setVerticalSpacing(max(layout.verticalSpacing(), 12))
                    layout.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    layout.setFormAlignment(Qt.AlignTop)
                if isinstance(layout, QGridLayout):
                    layout.setHorizontalSpacing(max(layout.horizontalSpacing(), 12))
                    layout.setVerticalSpacing(max(layout.verticalSpacing(), 10))
            except Exception as exc:
                try:
                    log_exception(exc)
                except Exception:
                    pass


def _set_min_width(widget: QWidget, width: int) -> None:
    try:
        if widget.minimumWidth() < width:
            widget.setMinimumWidth(width)
    except Exception:
        pass


def _polish_fields(page: ToolsPage) -> None:
    try:
        old = page.styleSheet() or ''
        marker = '/* v45.17.4.18 tools field consistency */'
        if marker not in old:
            page.setStyleSheet(old + '\n' + marker + '\n' + TOOLS_FIELD_STYLE)
    except Exception as exc:
        try:
            log_exception(exc)
        except Exception:
            pass

    _safe_layout_polish(page)

    # Inputs: readable text, consistent size, and enough width for Arabic values.
    for cls in (QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox):
        try:
            widgets = page.findChildren(cls)
        except Exception:
            widgets = []
        for w in widgets:
            try:
                w.setMinimumHeight(max(w.minimumHeight(), 40))
                _set_min_width(w, 170)
                if isinstance(w, QLineEdit):
                    w.setClearButtonEnabled(True)
                    w.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
                if isinstance(w, QComboBox):
                    w.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
                    w.setMinimumContentsLength(max(getattr(w, 'minimumContentsLength', lambda: 0)(), 12))
                if isinstance(w, (QSpinBox, QDoubleSpinBox)):
                    w.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            except Exception as exc:
                try:
                    log_exception(exc)
                except Exception:
                    pass

    for cls in (QTextEdit,):
        try:
            widgets = page.findChildren(cls)
        except Exception:
            widgets = []
        for w in widgets:
            try:
                w.setMinimumHeight(max(w.minimumHeight(), 110))
                _set_min_width(w, 220)
            except Exception:
                pass

    for cls in (QDateEdit, QTimeEdit, QDateTimeEdit):
        if cls is None:
            continue
        try:
            widgets = page.findChildren(cls)
        except Exception:
            widgets = []
        for w in widgets:
            try:
                w.setMinimumHeight(max(w.minimumHeight(), 40))
                _set_min_width(w, 150)
                w.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            except Exception:
                pass

    for btn in page.findChildren(QPushButton):
        try:
            btn.setMinimumHeight(max(btn.minimumHeight(), 38))
            if btn.minimumWidth() < 110:
                btn.setMinimumWidth(110)
            btn.setCursor(Qt.PointingHandCursor)
        except Exception:
            pass

    for table in page.findChildren(QTableWidget):
        try:
            table.setMinimumHeight(max(table.minimumHeight(), 260))
            table.setAlternatingRowColors(True)
            table.setWordWrap(False)
            table.setTextElideMode(Qt.ElideRight)
            table.verticalHeader().setDefaultSectionSize(max(table.verticalHeader().defaultSectionSize(), 34))
            table.horizontalHeader().setMinimumSectionSize(90)
            table.horizontalHeader().setDefaultSectionSize(max(table.horizontalHeader().defaultSectionSize(), 130))
            table.horizontalHeader().setStretchLastSection(True)
        except Exception as exc:
            try:
                log_exception(exc)
            except Exception:
                pass

    for tabs in page.findChildren(QTabWidget):
        try:
            tabs.setUsesScrollButtons(True)
            tabs.setElideMode(Qt.ElideRight)
            tabs.setDocumentMode(True)
        except Exception:
            pass

    # Run a delayed pass because some older patches add widgets after refresh.
    try:
        if not getattr(page, 'v4517418_delayed_polish_scheduled', False):
            page.v4517418_delayed_polish_scheduled = True
            QTimer.singleShot(250, lambda: _delayed_polish(page))
    except Exception:
        pass


def _delayed_polish(page: ToolsPage) -> None:
    try:
        page.v4517418_delayed_polish_scheduled = False
        _safe_layout_polish(page)
        for w in page.findChildren((QLineEdit if False else QWidget)):
            # The broad pass only ensures existing tooltips do not disappear; actual sizing is above.
            pass
        # Re-run focused sizing without scheduling another timer.
        for cls in (QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox):
            for w in page.findChildren(cls):
                try:
                    w.setMinimumHeight(max(w.minimumHeight(), 40))
                    _set_min_width(w, 170)
                except Exception:
                    pass
    except Exception as exc:
        try:
            log_exception(exc)
        except Exception:
            pass


def _init(self, service, notify, current_user=None):
    _ORIG_INIT(self, service, notify, current_user)
    _polish_fields(self)


def _refresh(self):
    if _ORIG_REFRESH:
        _ORIG_REFRESH(self)
    _polish_fields(self)


ToolsPage.__init__ = _init
ToolsPage.refresh = _refresh
