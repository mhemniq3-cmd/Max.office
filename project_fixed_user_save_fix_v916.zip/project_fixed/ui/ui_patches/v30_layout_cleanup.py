from __future__ import annotations

from pathlib import Path
import html
import os

from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.theme_manager import apply_theme as theme_apply, current_theme_key as theme_current_key, set_theme_key as theme_set_key, theme_label as theme_display_label, theme_path as theme_qss_path
from ui.main_window_core import *
import ui.ui_patches.v11_sales_safety as _prev_v11_sales_safety
globals().update({k: v for k, v in vars(_prev_v11_sales_safety).items() if not k.startswith('__')})
import ui.ui_patches.v20_gdrive_ui as _prev_v20_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v20_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v21_backup_ui as _prev_v21_backup_ui
globals().update({k: v for k, v in vars(_prev_v21_backup_ui).items() if not k.startswith('__')})
import ui.ui_patches.v22_gdrive_ui as _prev_v22_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v22_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v23_tools_reports as _prev_v23_tools_reports
globals().update({k: v for k, v in vars(_prev_v23_tools_reports).items() if not k.startswith('__')})
import ui.ui_patches.v25_lazy_permissions as _prev_v25_lazy_permissions
globals().update({k: v for k, v in vars(_prev_v25_lazy_permissions).items() if not k.startswith('__')})
import ui.ui_patches.v26_tools_refresh as _prev_v26_tools_refresh
globals().update({k: v for k, v in vars(_prev_v26_tools_refresh).items() if not k.startswith('__')})
import ui.ui_patches.v27_pricing_excel_ui as _prev_v27_pricing_excel_ui
globals().update({k: v for k, v in vars(_prev_v27_pricing_excel_ui).items() if not k.startswith('__')})
import ui.ui_patches.v28_professional_ui as _prev_v28_professional_ui
globals().update({k: v for k, v in vars(_prev_v28_professional_ui).items() if not k.startswith('__')})

def _v30_small_label(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName('formLabel')
    return label


def _v30_form_card(title: str) -> tuple[QFrame, QVBoxLayout]:
    card = QFrame(); card.setObjectName('innerCard')
    lay = QVBoxLayout(card); lay.setContentsMargins(14, 14, 14, 14); lay.setSpacing(10)
    ttl = QLabel(title); ttl.setObjectName('smallSectionTitle')
    lay.addWidget(ttl)
    return card, lay


def _v30_sales_init(self, service: AppService, notify, current_user=None):
    QWidget.__init__(self)
    self.service = service
    self.notify = notify
    self.current_user = current_user
    self.product_id = None
    self.rows = []
    self.product_rows = []
    self.cart = []
    self.build()
    self.refresh_all()


def _v30_sales_build(self):
    root = QHBoxLayout(self); root.setContentsMargins(6, 6, 6, 6); root.setSpacing(14)

    left = QFrame(); left.setObjectName('surface')
    left_l = QVBoxLayout(left); left_l.setContentsMargins(14, 14, 14, 14); left_l.setSpacing(10)
    title = QLabel('🛒 البيع السريع'); title.setObjectName('sectionTitle')
    hint = QLabel('امسح الباركود أو ابحث عن المنتج، ثم أضفه إلى الفاتورة. تم ترتيب الحقول لتجنب التداخل على الشاشات الصغيرة.')
    hint.setObjectName('noticeBox'); hint.setWordWrap(True)
    self.barcode_scan = QLineEdit(); self.barcode_scan.setPlaceholderText('امسح باركود المنتج ثم Enter...'); self.barcode_scan.returnPressed.connect(self.scan_barcode_add)
    self.search = QLineEdit(); self.search.setPlaceholderText('بحث بالاسم أو الباركود أو الصنف...'); self.search.textChanged.connect(self.refresh_products)
    self.products = Table(['المنتج', 'السعر/العرض', 'المخزون', 'الصنف']); self.products.doubleClicked.connect(self.add_selected_product)
    left_l.addWidget(title); left_l.addWidget(hint); left_l.addWidget(self.barcode_scan); left_l.addWidget(self.search); left_l.addWidget(self.products, 1)

    center = QFrame(); center.setObjectName('surface')
    center_l = QVBoxLayout(center); center_l.setContentsMargins(14, 14, 14, 14); center_l.setSpacing(10)
    cart_title = QLabel('🧾 الفاتورة الحالية'); cart_title.setObjectName('sectionTitle')
    self.cart_table = Table(['المنتج', 'كمية', 'سعر', 'إجمالي', 'عمولة'])
    actions = QHBoxLayout(); actions.setSpacing(10)
    self.remove_btn = QPushButton('🗑 حذف المحدد'); self.remove_btn.setObjectName('dangerButton'); self.remove_btn.clicked.connect(self.remove_selected)
    self.clear_btn = QPushButton('مسح السلة'); self.clear_btn.clicked.connect(self.clear_cart)
    actions.addWidget(self.remove_btn); actions.addWidget(self.clear_btn)
    center_l.addWidget(cart_title); center_l.addWidget(self.cart_table, 1); center_l.addLayout(actions)

    right_scroll = QScrollArea(); right_scroll.setWidgetResizable(True); right_scroll.setFrameShape(QFrame.NoFrame); right_scroll.setObjectName('cleanScroll')
    right_scroll.setMinimumWidth(390); right_scroll.setMaximumWidth(480)
    right = QFrame(); right.setObjectName('surface')
    right_l = QVBoxLayout(right); right_l.setContentsMargins(16, 16, 16, 16); right_l.setSpacing(12)

    user_text = (self.current_user['full_name'] or self.current_user['username']) if self.current_user else '-'
    self.user_label = QLabel(f'المستخدم الحالي: {user_text}'); self.user_label.setObjectName('noticeBox'); self.user_label.setWordWrap(True)

    people_card, people_l = _v30_form_card('بيانات الفاتورة')
    people_form = QFormLayout(); people_form.setLabelAlignment(Qt.AlignRight); people_form.setVerticalSpacing(12)
    self.employee = QComboBox(); self.customer = QComboBox(); self.payment = QComboBox(); self.payment.addItems(['نقدي','بطاقة','تحويل','آجل'])
    self.price_level = QComboBox(); self.price_level.setMinimumHeight(38); self.price_level.currentIndexChanged.connect(lambda *_: (self.refresh_products(), self.refresh_cart()))
    self.note = QLineEdit(); self.note.setPlaceholderText('ملاحظة اختيارية')
    for w in (self.employee, self.customer, self.payment, self.price_level, self.note): w.setMinimumHeight(38)
    people_form.addRow('موظف العمولة', self.employee)
    people_form.addRow('الزبون', self.customer)
    people_form.addRow('طريقة الدفع', self.payment)
    people_form.addRow('مستوى السعر', self.price_level)
    people_form.addRow('ملاحظة', self.note)
    people_l.addLayout(people_form)

    qty_card, qty_l = _v30_form_card('الكمية والخصم')
    qty_grid = QGridLayout(); qty_grid.setHorizontalSpacing(12); qty_grid.setVerticalSpacing(10)
    self.qty = QSpinBox(); self.qty.setRange(1, 99999); self.qty.setValue(1); self.qty.setMinimumHeight(40)
    self.discount = QDoubleSpinBox(); self.discount.setRange(0, 999999999); self.discount.setDecimals(0); self.discount.setMinimumHeight(40); self.discount.valueChanged.connect(self.refresh_cart)
    self.discount_type = QComboBox(); self.discount_type.addItem('مبلغ', 'amount'); self.discount_type.addItem('نسبة %', 'percent'); self.discount_type.setMinimumHeight(40); self.discount_type.currentIndexChanged.connect(self.refresh_cart)
    qty_grid.addWidget(_v30_small_label('الكمية'), 0, 0); qty_grid.addWidget(_v30_small_label('الخصم'), 0, 1)
    qty_grid.addWidget(self.qty, 1, 0); qty_grid.addWidget(self.discount, 1, 1)
    qty_grid.addWidget(_v30_small_label('نوع الخصم'), 2, 0); qty_grid.addWidget(self.discount_type, 3, 0, 1, 2)
    qty_l.addLayout(qty_grid)

    self.total_label = QLabel('الصافي: 0 د.ع'); self.total_label.setObjectName('bigTotal')
    self.complete_btn = QPushButton('✅ حفظ البيع وإصدار الفاتورة'); self.complete_btn.setObjectName('successButton'); self.complete_btn.clicked.connect(self.complete_sale)
    self.suspend_btn = QPushButton('⏸ تعليق الفاتورة'); self.suspend_btn.setObjectName('warningButton'); self.suspend_btn.clicked.connect(self.suspend_current_sale)
    for b in (self.complete_btn, self.suspend_btn): b.setMinimumHeight(46)

    right_l.addWidget(QLabel('بيانات البيع'))
    right_l.addWidget(self.user_label)
    right_l.addWidget(people_card)
    right_l.addWidget(qty_card)
    right_l.addWidget(self.total_label)
    right_l.addWidget(self.complete_btn)
    right_l.addWidget(self.suspend_btn)
    right_l.addStretch()
    right_scroll.setWidget(right)

    root.addWidget(left, 3); root.addWidget(center, 4); root.addWidget(right_scroll)


# Disabled: SalesPage now has built-in tabbed interface
# SalesPage.__init__ = _v30_sales_init
# SalesPage.build = _v30_sales_build


def _v30_touch_init(self, service: AppService, notify, current_user=None):
    QWidget.__init__(self)
    self.service = service
    self.notify = notify
    self.current_user = current_user
    self.cart = []
    self.product_rows = []
    self.build()
    self.refresh()


def _v30_touch_build(self):
    root = QHBoxLayout(self); root.setContentsMargins(6, 6, 6, 6); root.setSpacing(14)
    left = QFrame(); left.setObjectName('surface')
    ll = QVBoxLayout(left); ll.setContentsMargins(14, 14, 14, 14); ll.setSpacing(10)
    title = QLabel('🖥 كاشير لمس'); title.setObjectName('sectionTitle')
    hint = QLabel('واجهة لمس مبسطة: اختر التصنيف أو ابحث، ثم اضغط مرتين على المنتج لإضافته.')
    hint.setObjectName('noticeBox'); hint.setWordWrap(True)
    filters = QHBoxLayout(); filters.setSpacing(10)
    self.category = QComboBox(); self.category.currentIndexChanged.connect(self.refresh_products); self.category.setMinimumHeight(40)
    self.search = QLineEdit(); self.search.setPlaceholderText('بحث سريع أو باركود...'); self.search.textChanged.connect(self.refresh_products); self.search.setMinimumHeight(40)
    filters.addWidget(self.category, 1); filters.addWidget(self.search, 2)
    self.cards = QTableWidget(0, 4); self.cards.setObjectName('touchGrid'); self.cards.verticalHeader().hide(); self.cards.horizontalHeader().hide(); self.cards.setEditTriggers(QAbstractItemView.NoEditTriggers); self.cards.cellDoubleClicked.connect(self.add_card)
    ll.addWidget(title); ll.addWidget(hint); ll.addLayout(filters); ll.addWidget(self.cards, 1)

    right_scroll = QScrollArea(); right_scroll.setWidgetResizable(True); right_scroll.setFrameShape(QFrame.NoFrame); right_scroll.setMinimumWidth(395); right_scroll.setMaximumWidth(470)
    right = QFrame(); right.setObjectName('surface')
    rl = QVBoxLayout(right); rl.setContentsMargins(14, 14, 14, 14); rl.setSpacing(12)
    self.cart_table = Table(['المادة', 'كمية', 'الإجمالي'])
    self.employee = QComboBox(); self.customer = QComboBox(); self.payment = QComboBox(); self.payment.addItems(['نقدي','بطاقة','تحويل','آجل'])
    self.price_level = QComboBox(); self.price_level.currentIndexChanged.connect(lambda *_: (self.refresh_products(), self.refresh_cart()))
    self.discount = QDoubleSpinBox(); self.discount.setMaximum(999999999); self.discount.setDecimals(0); self.discount.valueChanged.connect(self.refresh_cart)
    for w in (self.employee, self.customer, self.payment, self.price_level, self.discount): w.setMinimumHeight(40)
    form_card, form_l = _v30_form_card('خيارات الفاتورة')
    form = QFormLayout(); form.setVerticalSpacing(12); form.setLabelAlignment(Qt.AlignRight)
    form.addRow('موظف العمولة', self.employee); form.addRow('الزبون', self.customer); form.addRow('طريقة الدفع', self.payment); form.addRow('مستوى السعر', self.price_level); form.addRow('الخصم', self.discount)
    form_l.addLayout(form)
    self.total = QLabel('الصافي: 0 د.ع'); self.total.setObjectName('bigTotal')
    sell = QPushButton('✅ بيع سريع'); sell.setObjectName('successButton'); sell.clicked.connect(self.complete)
    hold = QPushButton('⏸ تعليق'); hold.setObjectName('warningButton'); hold.clicked.connect(self.suspend)
    ret = QPushButton('↩ مرتجع'); ret.setObjectName('dangerButton'); ret.clicked.connect(lambda: self.notify('افتح صفحة المرتجعات لإتمام العملية'))
    clear = QPushButton('مسح'); clear.clicked.connect(self.clear)
    buttons = QGridLayout(); buttons.setSpacing(10)
    buttons.addWidget(sell, 0, 0); buttons.addWidget(hold, 0, 1); buttons.addWidget(ret, 1, 0); buttons.addWidget(clear, 1, 1)
    rl.addWidget(QLabel('فاتورة اللمس'))
    rl.addWidget(self.cart_table, 1)
    rl.addWidget(form_card)
    rl.addWidget(self.total)
    rl.addLayout(buttons)
    right_scroll.setWidget(right)
    root.addWidget(left, 1); root.addWidget(right_scroll)


TouchPOSPage.__init__ = _v30_touch_init
TouchPOSPage.build = _v30_touch_build


def _v30_touch_refresh_people(self):
    self.employee.clear(); emp_id = None
    if self.current_user:
        try:
            emp_id, name = self.service.ensure_employee_for_user(self.current_user)
            self.employee.addItem(f'المستخدم الحالي: {name}', emp_id)
        except Exception as exc:
            log_exception(exc)
    for e in self.service.list_employees():
        if emp_id and e['id'] == emp_id:
            continue
        self.employee.addItem(e['name'], e['id'])
    self.customer.clear()
    for c in self.service.list_customers():
        self.customer.addItem(c['name'], c['id'])
    self.price_level.blockSignals(True); cur_level = self.price_level.currentData(); self.price_level.clear(); self.price_level.addItem('تلقائي حسب الكمية والعروض', None)
    try:
        for lvl in self.service.list_price_levels(True):
            if lvl['name'] != 'مفرد': self.price_level.addItem(lvl['name'], lvl['id'])
    except Exception as exc:
        log_exception(exc)
    if cur_level is not None:
        idx = self.price_level.findData(cur_level)
        if idx >= 0: self.price_level.setCurrentIndex(idx)
    self.price_level.blockSignals(False)
    cats = ['كل التصنيفات'] + sorted({(p['category'] or 'بدون صنف') for p in self.service.list_products('')})
    cur = self.category.currentText(); self.category.blockSignals(True); self.category.clear(); self.category.addItems(cats); self.category.setCurrentText(cur if cur in cats else cats[0]); self.category.blockSignals(False)

TouchPOSPage.refresh_people = _v30_touch_refresh_people


def _v30_tools_build_pricing_tab(self):
    if hasattr(self, 'v30_pricing_tab_built'):
        return
    self.v30_pricing_tab_built = True
    tab = QWidget(); outer = QVBoxLayout(tab); outer.setContentsMargins(8, 8, 8, 8)
    scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame); scroll.setObjectName('cleanScroll')
    content = QWidget(); root = QVBoxLayout(content); root.setSpacing(14)
    note = QLabel('إدارة العروض ومستويات الأسعار بشكل مرتب. قسّمنا الحقول إلى أقسام مستقلة حتى لا تتداخل.')
    note.setWordWrap(True); note.setObjectName('noticeBox'); root.addWidget(note)

    levels_row = QHBoxLayout(); levels_row.setSpacing(14)
    level_box, lf_l = _v30_form_card('1) مستوى سعر جديد')
    lf = QFormLayout(); lf.setLabelAlignment(Qt.AlignRight); lf.setVerticalSpacing(10)
    self.v27_level_name = QLineEdit(); self.v27_level_name.setPlaceholderText('مثال: جملة أو VIP')
    self.v27_level_auto = QCheckBox('تطبيق تلقائي حسب الكمية'); self.v27_level_auto.setChecked(True)
    self.v27_level_default = QCheckBox('افتراضي')
    self.v27_level_order = QSpinBox(); self.v27_level_order.setMaximum(9999); self.v27_level_order.setValue(50)
    save_level = QPushButton('حفظ مستوى السعر'); save_level.setObjectName('primaryButton'); save_level.clicked.connect(self.v27_save_price_level)
    lf.addRow('اسم المستوى', self.v27_level_name); lf.addRow('', self.v27_level_auto); lf.addRow('', self.v27_level_default); lf.addRow('الترتيب', self.v27_level_order); lf_l.addLayout(lf); lf_l.addWidget(save_level)

    prod_box, pf_l = _v30_form_card('2) سعر منتج حسب المستوى')
    pf = QFormLayout(); pf.setLabelAlignment(Qt.AlignRight); pf.setVerticalSpacing(10)
    self.v27_price_product = QComboBox(); self.v27_price_level = QComboBox()
    self.v27_level_price = QDoubleSpinBox(); self.v27_level_price.setMaximum(999999999); self.v27_level_price.setDecimals(0)
    self.v27_level_min = QSpinBox(); self.v27_level_min.setMaximum(999999); self.v27_level_min.setValue(1)
    save_prod_price = QPushButton('حفظ سعر المنتج لهذا المستوى'); save_prod_price.setObjectName('successButton'); save_prod_price.clicked.connect(self.v27_save_product_price_level)
    pf.addRow('المنتج', self.v27_price_product); pf.addRow('المستوى', self.v27_price_level); pf.addRow('السعر', self.v27_level_price); pf.addRow('الحد الأدنى', self.v27_level_min); pf_l.addLayout(pf); pf_l.addWidget(save_prod_price)
    levels_row.addWidget(level_box, 1); levels_row.addWidget(prod_box, 1); root.addLayout(levels_row)

    prices_box, prices_l = _v30_form_card('أسعار المستويات المسجلة')
    self.v27_product_prices_table = Table(['ID','المنتج','المستوى','السعر','الحد','تلقائي'])
    del_price = QPushButton('حذف سعر المستوى المحدد'); del_price.setObjectName('dangerButton'); del_price.clicked.connect(self.v27_delete_product_price_level)
    prices_l.addWidget(self.v27_product_prices_table, 1); prices_l.addWidget(del_price); root.addWidget(prices_box)

    promo_box, promo_l = _v30_form_card('3) إنشاء عرض')
    promo_grid = QGridLayout(); promo_grid.setHorizontalSpacing(12); promo_grid.setVerticalSpacing(10)
    self.v27_promo_name = QLineEdit(); self.v27_promo_name.setPlaceholderText('مثال: خصم رمضان')
    self.v27_promo_scope = QComboBox(); self.v27_promo_scope.addItem('كل المنتجات','all'); self.v27_promo_scope.addItem('منتج محدد','product'); self.v27_promo_scope.addItem('صنف','category')
    self.v27_promo_product = QComboBox(); self.v27_promo_category = QLineEdit(); self.v27_promo_category.setPlaceholderText('اسم الصنف')
    self.v27_promo_type = QComboBox(); self.v27_promo_type.addItem('نسبة %','percent'); self.v27_promo_type.addItem('مبلغ خصم','amount'); self.v27_promo_type.addItem('سعر ثابت','fixed_price'); self.v27_promo_type.addItem('اشتر X واحصل على Y','buy_x_get_y')
    self.v27_promo_value = QDoubleSpinBox(); self.v27_promo_value.setMaximum(999999999); self.v27_promo_value.setDecimals(2)
    self.v27_promo_buy = QSpinBox(); self.v27_promo_buy.setMaximum(999999); self.v27_promo_free = QSpinBox(); self.v27_promo_free.setMaximum(999999)
    self.v27_promo_min = QSpinBox(); self.v27_promo_min.setMaximum(999999); self.v27_promo_min.setValue(1)
    self.v27_promo_start = QLineEdit(); self.v27_promo_start.setPlaceholderText('YYYY-MM-DD')
    self.v27_promo_end = QLineEdit(); self.v27_promo_end.setPlaceholderText('YYYY-MM-DD')
    self.v27_promo_priority = QSpinBox(); self.v27_promo_priority.setMaximum(9999)
    fields = [('اسم العرض', self.v27_promo_name), ('النطاق', self.v27_promo_scope), ('المنتج', self.v27_promo_product), ('الصنف', self.v27_promo_category), ('النوع', self.v27_promo_type), ('القيمة', self.v27_promo_value), ('اشتر X', self.v27_promo_buy), ('مجاني Y', self.v27_promo_free), ('أقل كمية', self.v27_promo_min), ('من تاريخ', self.v27_promo_start), ('إلى تاريخ', self.v27_promo_end), ('الأولوية', self.v27_promo_priority)]
    for idx, (label, widget) in enumerate(fields):
        row = (idx // 3) * 2; col = idx % 3
        promo_grid.addWidget(_v30_small_label(label), row, col); promo_grid.addWidget(widget, row + 1, col)
    save_promo = QPushButton('حفظ العرض'); save_promo.setObjectName('primaryButton'); save_promo.clicked.connect(self.v27_save_promotion)
    promo_l.addLayout(promo_grid); promo_l.addWidget(save_promo); root.addWidget(promo_box)

    promos_box, promos_l = _v30_form_card('العروض المسجلة')
    self.v27_promotions_table = Table(['ID','العرض','النطاق','النوع','القيمة','الفترة','نشط'])
    del_promo = QPushButton('تعطيل العرض المحدد'); del_promo.setObjectName('dangerButton'); del_promo.clicked.connect(self.v27_deactivate_promotion)
    promos_l.addWidget(self.v27_promotions_table, 1); promos_l.addWidget(del_promo); root.addWidget(promos_box)

    excel_box, excel_l = _v30_form_card('Excel')
    excel_row = QHBoxLayout(); excel_row.setSpacing(10)
    ex = QPushButton('تصدير منتجات Excel'); ex.setObjectName('primaryButton'); ex.clicked.connect(self.v27_tools_export_excel)
    im = QPushButton('استيراد منتجات Excel'); im.setObjectName('warningButton'); im.clicked.connect(self.v27_tools_import_excel)
    tm = QPushButton('قالب Excel'); tm.clicked.connect(self.v27_tools_template_excel)
    excel_row.addWidget(ex); excel_row.addWidget(im); excel_row.addWidget(tm); excel_l.addLayout(excel_row); root.addWidget(excel_box)
    root.addStretch()
    scroll.setWidget(content); outer.addWidget(scroll)
    self.tabs.addTab(tab, 'العروض والأسعار')

ToolsPage.build_pricing_tab = _v30_tools_build_pricing_tab


def _v30_user_delete(self):
    if not getattr(self, 'user_id', None):
        QMessageBox.warning(self, 'تنبيه', 'اختر المستخدم أولاً'); return
    if QMessageBox.question(self, 'تأكيد الحذف', 'حذف المستخدم إن لم يكن مرتبطاً بسجلات، أو تعطيله إذا كان مرتبطاً؟') != QMessageBox.Yes:
        return
    try:
        msg = self.service.delete_or_deactivate_user(self.user_id)
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر الحذف', str(exc)); return
    self.clear(); self.refresh(); self.notify(msg); QMessageBox.information(self, 'تم', msg)


def _v30_customer_delete(self):
    if not getattr(self, 'customer_id', None):
        QMessageBox.warning(self, 'تنبيه', 'اختر الزبون أولاً'); return
    if QMessageBox.question(self, 'تأكيد الحذف', 'حذف الزبون إن لم يكن مرتبطاً بفواتير، أو تعطيله إذا كان مرتبطاً؟') != QMessageBox.Yes:
        return
    try:
        msg = self.service.delete_or_deactivate_customer(self.customer_id)
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر الحذف', str(exc)); return
    self.clear(); self.refresh(); self.notify(msg); QMessageBox.information(self, 'تم', msg)


def _v30_product_delete(self):
    if not getattr(self, 'product_id', None):
        QMessageBox.warning(self, 'تنبيه', 'اختر المنتج أولاً'); return
    if QMessageBox.question(self, 'تأكيد الحذف', 'حذف المنتج إن لم يكن مرتبطاً بحركات، أو تعطيله إذا كان مرتبطاً؟') != QMessageBox.Yes:
        return
    try:
        msg = self.service.delete_or_deactivate_product(self.product_id)
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر الحذف', str(exc)); return
    self.clear(); self.refresh(); self.notify(msg); QMessageBox.information(self, 'تم', msg)

UsersPage.delete_user = _v30_user_delete
CustomersPage.delete_customer = _v30_customer_delete
ProductsPage.delete_product = _v30_product_delete

_orig_users_init_v30 = UsersPage.__init__
def _v30_users_init(self, service: AppService, notify):
    _orig_users_init_v30(self, service, notify)
    try:
        btn = QPushButton('🗑 حذف المستخدم')
        btn.setObjectName('dangerButton'); btn.clicked.connect(self.delete_user)
        self.layout().itemAt(1).widget().layout().addWidget(btn)
    except Exception as exc:
        log_exception(exc)
UsersPage.__init__ = _v30_users_init

_orig_customers_init_v30 = CustomersPage.__init__
def _v30_customers_init(self, service: AppService, notify):
    _orig_customers_init_v30(self, service, notify)
    try:
        btn = QPushButton('🗑 حذف الزبون')
        btn.setObjectName('dangerButton'); btn.clicked.connect(self.delete_customer)
        self.layout().itemAt(1).widget().layout().insertWidget(6, btn)
    except Exception as exc:
        log_exception(exc)
CustomersPage.__init__ = _v30_customers_init

_orig_products_init_v30 = ProductsPage.__init__
def _v30_products_init(self, service: AppService, notify, current_user=None):
    _orig_products_init_v30(self, service, notify, current_user)
    try:
        panel = QFrame(); panel.setObjectName('surface'); panel.setMaximumWidth(230)
        lay = QVBoxLayout(panel); lay.setContentsMargins(10,10,10,10); lay.setSpacing(10)
        title = QLabel('حذف آمن'); title.setObjectName('sectionTitle')
        btn = QPushButton('🗑 حذف المنتج')
        btn.setObjectName('dangerButton'); btn.clicked.connect(self.delete_product)
        note = QLabel('يحذف المنتج إذا لم يكن مرتبطاً بحركات، وإلا يتم تعطيله حفاظاً على التقارير.')
        note.setObjectName('noticeBox'); note.setWordWrap(True)
        lay.addWidget(title); lay.addWidget(btn); lay.addWidget(note); lay.addStretch()
        self.layout().addWidget(panel)
    except Exception as exc:
        log_exception(exc)
ProductsPage.__init__ = _v30_products_init


# ---------------------------------------------------------------------------
# V31 Widgets refinement
# - Employee goals use automatic start dates and duration-based expiration.
# - Add separate disable and permanent delete actions for goals.
# - Fill all visible date fields with today's date by default.
# - Keep V28 professional UI, make brand more visible, tidy product delete flow.
# - Expand smart assistant and detailed help guide.
# ---------------------------------------------------------------------------

