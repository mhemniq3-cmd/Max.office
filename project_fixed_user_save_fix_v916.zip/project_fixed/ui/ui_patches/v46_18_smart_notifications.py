from __future__ import annotations

from datetime import datetime
from PySide6.QtCore import Qt, QTimer, QPoint
from PySide6.QtGui import QFont, QColor
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, 
                               QLabel, QPushButton, QScrollArea, QWidget, QFrame)

from ui.main_window_core import MainWindow
from ui.ui_patches.v46_17_analytics_dashboard import StockAlertsDialog
from services.app_core import AppService
from services.error_logger import log_exception

# 1. Extend AppService to include security alerts
_ORIG_SMART_ALERTS = AppService.smart_alerts

def _v46_18_smart_alerts(self: AppService) -> list[str]:
    alerts = _ORIG_SMART_ALERTS(self)
    
    try:
        today = datetime.now().strftime('%Y-%m-%d')
        rows = self.db.conn.execute('''
            SELECT action, description, user_name FROM unified_movement_log 
            WHERE date(event_time) = date(?) 
            AND (action LIKE '%حذف%' OR action LIKE '%إلغاء%' OR action LIKE '%تخطي%' OR description LIKE '%أقل من التكلفة%')
            ORDER BY id DESC LIMIT 5
        ''', (today,)).fetchall()
        
        for r in rows:
            user = r['user_name'] or 'مستخدم'
            action = r['action'] or 'عملية'
            desc = r['description'] or ''
            alerts.append(f"🛡️ تنبيه أمان: قام {user} بـ {action} ({desc})")
    except Exception as exc:
        pass
        
    return alerts

AppService.smart_alerts = _v46_18_smart_alerts


from ui.ui_common import Table

# 2. Notification Legendary UI
class LegendaryAlertsDialog(QDialog):
    def __init__(self, parent, service, text_alerts: list[str]):
        super().__init__(parent)
        self.setWindowTitle("🔔 مركز الإشعارات وتنبيهات المخزون")
        self.setMinimumSize(850, 650)
        self.setStyleSheet("""
            QDialog {
                background-color: #f8fafc;
            }
            QLabel#headerTitle {
                font-size: 24px;
                font-weight: 900;
                color: #0f172a;
            }
            QLabel#subTitle {
                font-size: 16px;
                font-weight: bold;
                color: #dc2626;
                margin-top: 10px;
            }
            QLabel#alertItem {
                font-size: 14px;
                font-weight: bold;
                color: #b91c1c;
                background-color: #fef2f2;
                border: 1px solid #fca5a5;
                border-radius: 6px;
                padding: 8px;
            }
        """)
        
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(24, 24, 24, 24)
        main_layout.setSpacing(16)
        
        # Header
        header = QLabel("🔔 مركز الإشعارات وتنبيهات المخزون")
        header.setObjectName("headerTitle")
        main_layout.addWidget(header)
        
        # General Alerts (Security, Debts)
        non_stock_alerts = [a for a in text_alerts if "منتج" not in a and "المخزون" not in a]
        if non_stock_alerts:
            alerts_title = QLabel("🛡️ تنبيهات الأمان والديون:")
            alerts_title.setObjectName("subTitle")
            main_layout.addWidget(alerts_title)
            
            for a in non_stock_alerts:
                lbl = QLabel(a)
                lbl.setObjectName("alertItem")
                lbl.setWordWrap(True)
                main_layout.addWidget(lbl)
                
        # Stock Table
        stock_title = QLabel("📦 تفاصيل نواقص المخزون:")
        stock_title.setObjectName("subTitle")
        stock_title.setStyleSheet("color: #0f172a;")
        main_layout.addWidget(stock_title)
        
        self.table = Table(["الباركود", "اسم الصنف", "الكمية الحالية", "حد التنبيه", "حالة الخطر"])
        main_layout.addWidget(self.table, 1)
        
        # Close Button
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        close_btn = QPushButton("إغلاق المركز")
        close_btn.setObjectName("dangerButton")
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.clicked.connect(self.close)
        btn_layout.addWidget(close_btn)
        
        main_layout.addLayout(btn_layout)
        
        self.load_stock_data(service)
        
    def load_stock_data(self, service):
        try:
            rows = service.db.conn.execute('''
                SELECT barcode, name, quantity, min_quantity 
                FROM products 
                WHERE COALESCE(active,1)=1 AND quantity <= min_quantity
                ORDER BY quantity ASC
            ''').fetchall()
            
            self.table.setRowCount(len(rows))
            for r, row in enumerate(rows):
                qty = float(row['quantity'] or 0)
                min_qty = float(row['min_quantity'] or 0)
                status = "🔴 نافد تماماً" if qty <= 0 else "🟠 وصل لحد التنبيه"
                
                vals = [
                    str(row['barcode'] or ''),
                    str(row['name'] or ''),
                    str(qty),
                    str(min_qty),
                    status
                ]
                for c, v in enumerate(vals):
                    self.table.put(r, c, v)
        except Exception as exc:
            log_exception(exc, "LegendaryAlertsDialog.load_stock_data")


# 3. MainWindow Integration
_ORIG_MAINWINDOW_BUILD_V4618 = MainWindow.build

def _v46_18_mainwindow_build(self: MainWindow):
    _ORIG_MAINWINDOW_BUILD_V4618(self)
    
    try:
        # Start background timer for notifications
        self.notif_timer = QTimer(self)
        self.notif_timer.timeout.connect(self.check_smart_notifications)
        self.notif_timer.start(30000) # Check every 30 seconds
        
        # Check immediately
        QTimer.singleShot(1000, self.check_smart_notifications)
    except Exception as exc:
        log_exception(exc, "v46_18_mainwindow_build")

def _v46_18_check_smart_notifications(self: MainWindow):
    try:
        if not hasattr(self, 'service') or not self.service: return
        alerts = self.service.smart_alerts()
        self.cached_alerts = alerts
        
        if alerts:
            self.alert_btn.setText(f'🔔 الإشعارات ({len(alerts)})')
            self.alert_btn.setStyleSheet("""
                QPushButton#alertButton {
                    background-color: #fef2f2;
                    border: 2px solid #fca5a5;
                    border-radius: 12px;
                    color: #dc2626;
                    font-weight: bold;
                    padding: 8px 16px;
                }
                QPushButton#alertButton:hover {
                    background-color: #fee2e2;
                }
            """)
        else:
            self.alert_btn.setText('🔔 الإشعارات')
            self.alert_btn.setStyleSheet("")
    except Exception as exc:
        log_exception(exc, "check_smart_notifications")

def _v46_18_show_alerts_dialog(self: MainWindow):
    try:
        alerts = getattr(self, 'cached_alerts', [])
        if not alerts and hasattr(self, 'service') and self.service:
            alerts = self.service.smart_alerts()
            self.cached_alerts = alerts
            
        dlg = LegendaryAlertsDialog(self, self.service, alerts)
        dlg.exec()
    except Exception as exc:
        log_exception(exc, "show_alerts_dialog")

MainWindow.build = _v46_18_mainwindow_build
MainWindow.check_smart_notifications = _v46_18_check_smart_notifications
MainWindow.show_alerts_dialog = _v46_18_show_alerts_dialog
