from __future__ import annotations

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

try:
    from PySide6.QtWidgets import (
        QDateEdit, QTimeEdit, QDateTimeEdit, QPlainTextEdit, QGroupBox,
        QSizePolicy, QAbstractScrollArea, QAbstractSpinBox, QScrollArea, QMenu
    )
except Exception:  # pragma: no cover
    QDateEdit = QTimeEdit = QDateTimeEdit = QPlainTextEdit = QGroupBox = None
    QSizePolicy = QAbstractScrollArea = QAbstractSpinBox = QScrollArea = QMenu = None

_ORIG_INIT = ToolsPage.__init__
_ORIG_REFRESH = getattr(ToolsPage, 'refresh', None)

HARD_TOOLS_QSS = r"""
/* v45.17.4.20 - hard reset for tools fields */
ToolsPage {
    background: #f8fafc;
    color: #111827;
    font-size: 14px;
}
ToolsPage QWidget {
    font-size: 14px;
    color: #111827;
}
ToolsPage QLabel {
    color: #1f2937;
    font-size: 14px;
    font-weight: 700;
    padding: 3px 2px;
    background: transparent;
}
ToolsPage QLabel[formRole="label"] {
    color: #334155;
    font-weight: 900;
    min-width: 145px;
    padding-top: 10px;
}
ToolsPage QLineEdit,
ToolsPage QComboBox,
ToolsPage QSpinBox,
ToolsPage QDoubleSpinBox,
ToolsPage QDateEdit,
ToolsPage QTimeEdit,
ToolsPage QDateTimeEdit {
    background-color: #ffffff;
    color: #111827;
    border: 1px solid #b8c2d1;
    border-radius: 8px;
    padding: 10px 14px;
    min-height: 44px;
    max-height: 44px;
    min-width: 240px;
    selection-background-color: #2563eb;
    selection-color: #ffffff;
}
ToolsPage QLineEdit:focus,
ToolsPage QComboBox:focus,
ToolsPage QSpinBox:focus,
ToolsPage QDoubleSpinBox:focus,
ToolsPage QDateEdit:focus,
ToolsPage QTimeEdit:focus,
ToolsPage QDateTimeEdit:focus,
ToolsPage QTextEdit:focus,
ToolsPage QPlainTextEdit:focus {
    border: 2px solid #2196f3;
    background-color: #ffffff;
    color: #111827;
}
ToolsPage QLineEdit:disabled,
ToolsPage QComboBox:disabled,
ToolsPage QSpinBox:disabled,
ToolsPage QDoubleSpinBox:disabled,
ToolsPage QDateEdit:disabled,
ToolsPage QTimeEdit:disabled,
ToolsPage QDateTimeEdit:disabled,
ToolsPage QTextEdit:disabled,
ToolsPage QPlainTextEdit:disabled {
    background-color: #f1f5f9;
    color: #64748b;
    border-color: #d5dde8;
}
ToolsPage QComboBox::drop-down {
    width: 32px;
    border: 0px;
}
ToolsPage QComboBox::down-arrow {
    width: 12px;
    height: 12px;
}
ToolsPage QComboBox QAbstractItemView {
    background: #ffffff;
    color: #111827;
    selection-background-color: #e0f2fe;
    selection-color: #0f172a;
    border: 1px solid #cbd5e1;
    padding: 4px;
}
ToolsPage QTextEdit,
ToolsPage QPlainTextEdit {
    background-color: #ffffff;
    color: #111827;
    border: 1px solid #b8c2d1;
    border-radius: 8px;
    padding: 10px 14px;
    min-height: 90px;
    min-width: 260px;
    selection-background-color: #2563eb;
    selection-color: #ffffff;
}
ToolsPage QPushButton {
    min-height: 40px;
    min-width: 120px;
    padding: 9px 15px;
    border-radius: 9px;
    font-weight: 800;
    background-color: #f8fafc;
    color: #111827;
    border: 1px solid #cbd5e1;
}
ToolsPage QPushButton:hover {
    background-color: #eff6ff;
    border-color: #2563eb;
}
ToolsPage QPushButton:pressed {
    background-color: #dbeafe;
    color: #111827;
}
ToolsPage QPushButton#primaryButton,
ToolsPage QPushButton[primary="true"] {
    background-color: #2563eb;
    color: #ffffff;
    border: 1px solid #1d4ed8;
}
ToolsPage QFrame#surface,
ToolsPage QFrame#card,
ToolsPage QFrame[formCard="true"],
ToolsPage QGroupBox {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 14px;
    padding: 14px;
    margin-top: 8px;
}
ToolsPage QTableWidget {
    background: #ffffff;
    color: #111827;
    alternate-background-color: #f8fafc;
    gridline-color: #e2e8f0;
    border: 1px solid #dbe3ef;
    border-radius: 10px;
}
ToolsPage QTableWidget::item {
    padding: 8px;
    color: #111827;
}
ToolsPage QHeaderView::section {
    background: #f1f5f9;
    color: #0f172a;
    padding: 9px;
    border: 1px solid #e2e8f0;
    font-weight: 900;
}
ToolsPage QTabWidget::pane {
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    background: #ffffff;
}
ToolsPage QTabBar::tab {
    min-height: 34px;
    min-width: 112px;
    padding: 8px 16px;
    margin: 2px;
    border-radius: 9px;
    background: #f1f5f9;
    color: #334155;
    font-weight: 800;
}
ToolsPage QTabBar::tab:selected {
    background: #2563eb;
    color: #ffffff;
}
ToolsPage QScrollArea,
ToolsPage QAbstractScrollArea {
    background: transparent;
    border: none;
}
QMenu#v4517420ToolsMenu,
QMenu[toolsMenu="true"] {
    background: #ffffff;
    color: #111827;
    border: 1px solid #d0d7e2;
    border-radius: 8px;
    padding: 12px;
    min-width: 340px;
}
QMenu#v4517420ToolsMenu::item,
QMenu[toolsMenu="true"]::item {
    padding: 10px 18px 10px 28px;
    margin: 2px 4px;
    border-radius: 7px;
}
QMenu#v4517420ToolsMenu::item:selected,
QMenu[toolsMenu="true"]::item:selected {
    background: #eef6ff;
    color: #0f172a;
}
QMenu#v4517420ToolsMenu::separator,
QMenu[toolsMenu="true"]::separator {
    height: 1px;
    background: #e5e7eb;
    margin: 8px 6px;
}
"""

FIELD_INLINE_STYLE = (
    "background-color:#ffffff; color:#111827; border:1px solid #b8c2d1; "
    "border-radius:8px; padding:10px 14px; selection-background-color:#2563eb; "
    "selection-color:#ffffff; font-size:14px;"
)
TEXT_INLINE_STYLE = (
    "background-color:#ffffff; color:#111827; border:1px solid #b8c2d1; "
    "border-radius:8px; padding:10px 14px; selection-background-color:#2563eb; "
    "selection-color:#ffffff; font-size:14px;"
)


def _safe_log(exc: Exception) -> None:
    try:
        log_exception(exc)
    except Exception:
        pass


def _apply_layout_reset(root: QWidget) -> None:
    for cls in (QVBoxLayout, QHBoxLayout, QGridLayout, QFormLayout):
        try:
            layouts = root.findChildren(cls)
        except Exception:
            layouts = []
        for layout in layouts:
            try:
                m = layout.contentsMargins()
                layout.setContentsMargins(max(m.left(), 12), max(m.top(), 12), max(m.right(), 12), max(m.bottom(), 12))
                layout.setSpacing(max(layout.spacing(), 12))
                if isinstance(layout, QFormLayout):
                    layout.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
                    layout.setRowWrapPolicy(QFormLayout.WrapLongRows)
                    layout.setHorizontalSpacing(max(layout.horizontalSpacing(), 18))
                    layout.setVerticalSpacing(max(layout.verticalSpacing(), 16))
                    layout.setLabelAlignment(Qt.AlignRight | Qt.AlignTop)
                    layout.setFormAlignment(Qt.AlignTop | Qt.AlignRight)
                    for row in range(layout.rowCount()):
                        lab_item = layout.itemAt(row, QFormLayout.LabelRole)
                        field_item = layout.itemAt(row, QFormLayout.FieldRole)
                        if lab_item and lab_item.widget() and isinstance(lab_item.widget(), QLabel):
                            _polish_label(lab_item.widget())
                        if field_item and field_item.widget():
                            _polish_widget(field_item.widget())
                elif isinstance(layout, QGridLayout):
                    layout.setHorizontalSpacing(max(layout.horizontalSpacing(), 16))
                    layout.setVerticalSpacing(max(layout.verticalSpacing(), 14))
                    cols = max(layout.columnCount(), 1)
                    for col in range(cols):
                        layout.setColumnMinimumWidth(col, max(layout.columnMinimumWidth(col), 120 if col % 2 == 0 else 240))
                        layout.setColumnStretch(col, 1 if col % 2 else 0)
            except Exception as exc:
                _safe_log(exc)


def _polish_label(label: QLabel) -> None:
    try:
        label.setProperty('formRole', 'label')
        label.setMinimumHeight(max(label.minimumHeight(), 28))
        label.setMinimumWidth(max(label.minimumWidth(), 115))
        label.setWordWrap(True)
        label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        label.style().unpolish(label); label.style().polish(label)
    except Exception:
        pass


def _polish_widget(w: QWidget) -> None:
    try:
        if QSizePolicy is not None:
            w.setSizePolicy(QSizePolicy.Expanding, w.sizePolicy().verticalPolicy())
    except Exception:
        pass
    try:
        if isinstance(w, QLineEdit):
            w.setMinimumHeight(44); w.setMaximumHeight(48); w.setMinimumWidth(max(w.minimumWidth(), 240))
            w.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            w.setClearButtonEnabled(True)
            if not w.placeholderText():
                w.setPlaceholderText('اكتب هنا...')
            w.setStyleSheet(FIELD_INLINE_STYLE)
        elif isinstance(w, QComboBox):
            w.setMinimumHeight(44); w.setMaximumHeight(48); w.setMinimumWidth(max(w.minimumWidth(), 240))
            w.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
            w.setMinimumContentsLength(max(w.minimumContentsLength(), 14))
            w.setStyleSheet(FIELD_INLINE_STYLE)
        elif isinstance(w, (QSpinBox, QDoubleSpinBox)):
            w.setMinimumHeight(44); w.setMaximumHeight(48); w.setMinimumWidth(max(w.minimumWidth(), 180))
            w.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            w.setStyleSheet(FIELD_INLINE_STYLE)
            try:
                w.lineEdit().setStyleSheet("background: transparent; color:#111827; border:0; padding:0;")
            except Exception:
                pass
        elif QDateEdit is not None and isinstance(w, (QDateEdit, QTimeEdit, QDateTimeEdit)):
            w.setMinimumHeight(44); w.setMaximumHeight(48); w.setMinimumWidth(max(w.minimumWidth(), 190))
            w.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            w.setStyleSheet(FIELD_INLINE_STYLE)
        elif isinstance(w, (QTextEdit, QPlainTextEdit)):
            w.setMinimumHeight(max(w.minimumHeight(), 90)); w.setMaximumHeight(max(w.maximumHeight(), 160) if w.maximumHeight() < 160 else w.maximumHeight())
            w.setMinimumWidth(max(w.minimumWidth(), 260))
            w.setStyleSheet(TEXT_INLINE_STYLE)
        elif isinstance(w, QLabel):
            _polish_label(w)
    except Exception as exc:
        _safe_log(exc)


def _polish_misc(root: QWidget) -> None:
    for btn in root.findChildren(QPushButton):
        try:
            btn.setMinimumHeight(max(btn.minimumHeight(), 40))
            btn.setMinimumWidth(max(btn.minimumWidth(), 110))
            btn.setCursor(Qt.PointingHandCursor)
        except Exception:
            pass
    for table in root.findChildren(QTableWidget):
        try:
            table.setMinimumHeight(max(table.minimumHeight(), 280))
            table.setAlternatingRowColors(True)
            table.setWordWrap(False)
            table.setTextElideMode(Qt.ElideRight)
            table.verticalHeader().setDefaultSectionSize(max(table.verticalHeader().defaultSectionSize(), 36))
            table.horizontalHeader().setMinimumSectionSize(105)
            table.horizontalHeader().setDefaultSectionSize(max(table.horizontalHeader().defaultSectionSize(), 145))
            table.horizontalHeader().setStretchLastSection(True)
        except Exception as exc:
            _safe_log(exc)
    for tabs in root.findChildren(QTabWidget):
        try:
            tabs.setUsesScrollButtons(True)
            tabs.setElideMode(Qt.ElideRight)
            tabs.setDocumentMode(True)
        except Exception:
            pass
    if QScrollArea is not None:
        for scroll in root.findChildren(QScrollArea):
            try:
                scroll.setWidgetResizable(True)
                scroll.setFrameShape(QFrame.NoFrame)
            except Exception:
                pass
    if QAbstractScrollArea is not None:
        for scroll in root.findChildren(QAbstractScrollArea):
            try:
                scroll.setSizeAdjustPolicy(QAbstractScrollArea.AdjustToContents)
            except Exception:
                pass
    for menu in root.findChildren(QMenu):
        try:
            menu.setObjectName(menu.objectName() or 'v4517420ToolsMenu')
            menu.setProperty('toolsMenu', 'true')
        except Exception:
            pass


def _hard_polish(page: ToolsPage) -> None:
    try:
        marker = '/* v45.17.4.20 hard reset tools fields */'
        old = page.styleSheet() or ''
        if marker not in old:
            page.setStyleSheet(old + '\n' + marker + '\n' + HARD_TOOLS_QSS)
    except Exception as exc:
        _safe_log(exc)
    _apply_layout_reset(page)
    for cls in (QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTextEdit, QPlainTextEdit, QLabel):
        if cls is None:
            continue
        try:
            widgets = page.findChildren(cls)
        except Exception:
            widgets = []
        for w in widgets:
            _polish_widget(w)
    for cls in (QDateEdit, QTimeEdit, QDateTimeEdit):
        if cls is None:
            continue
        try:
            widgets = page.findChildren(cls)
        except Exception:
            widgets = []
        for w in widgets:
            _polish_widget(w)
    _polish_misc(page)
    try:
        QTimer.singleShot(150, lambda: _hard_polish_delayed(page))
        QTimer.singleShot(600, lambda: _hard_polish_delayed(page))
        QTimer.singleShot(1200, lambda: _hard_polish_delayed(page))
    except Exception:
        pass


def _hard_polish_delayed(page: ToolsPage) -> None:
    try:
        _apply_layout_reset(page)
        for cls in (QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTextEdit, QPlainTextEdit, QLabel):
            if cls is None:
                continue
            for w in page.findChildren(cls):
                _polish_widget(w)
        for cls in (QDateEdit, QTimeEdit, QDateTimeEdit):
            if cls is None:
                continue
            for w in page.findChildren(cls):
                _polish_widget(w)
        _polish_misc(page)
    except Exception as exc:
        _safe_log(exc)


def _init(self, service, notify, current_user=None):
    _ORIG_INIT(self, service, notify, current_user)
    _hard_polish(self)


def _refresh(self):
    if _ORIG_REFRESH:
        _ORIG_REFRESH(self)
    _hard_polish(self)


ToolsPage.__init__ = _init
ToolsPage.refresh = _refresh
