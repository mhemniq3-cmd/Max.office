"""v46.10 - Clean and simplify Tools page without deleting legacy tools.

This patch keeps the stable grouped Tools page, but hides rarely-used/advanced
inner tabs by default. A small checkbox can reveal all tools when needed.
No widget is deleted; hidden tools remain in memory and can be restored.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

_ORIG_INIT = ToolsPage.__init__
_ORIG_REFRESH = getattr(ToolsPage, 'refresh', None)

STATE_FILE = Path('settings') / 'tools_simple_ui.json'

GROUP_KEYS = ('audit', 'operations', 'inventory', 'settings')
GROUP_TITLES = {
    'audit': '📊 الرقابة والسجلات',
    'operations': '💰 المبيعات والعمليات',
    'inventory': '📦 المخزون والجرد',
    'settings': '🛡️ الإعدادات والنسخ الاحتياطي',
}

ESSENTIAL_KEYWORDS = {
    'audit': [
        'مركز سجل الحركات', 'سجل الحركات', 'سجل العمليات',
    ],
    'operations': [
        'العمليات السريعة', 'الفواتير المعلقة', 'قائمة جميع الفواتير',
        'الإغلاق اليومي', 'عمولات الموظفين', 'المرتجعات',
    ],
    'inventory': [
        'حركة المخزون', 'جرد', 'الفروع والمخازن', 'باركود', 'الملصقات',
    ],
    'settings': [
        'إعدادات الشركة', 'إعدادات النظام', 'النسخ الاحتياطي', 'نسخ',
        'استعادة', 'المستخدمون', 'المستخدمين', 'صلاحيات', 'Google Drive',
    ],
}

ADVANCED_HINTS = [
    'تجريبي', 'AI', 'ذكي', 'مساعد', 'تحليلات', 'توقع', 'سحابي',
    'أرشفة', 'كشف الاحتيال', 'الحركات الحساسة', 'سلامة', 'فحص النظام',
    'دليل الاستخدام', 'ثيم', 'المظهر', 'عروض الأسعار', 'أوامر التوريد',
    'أهداف الموظفين', 'قسائم', 'كوبونات', 'العروض', 'قواعد الخصم',
    'كشف حساب', 'مورد', 'ديون', 'معاملات', 'الشفت', 'صندوق الكاشير',
]


def _load_show_advanced() -> bool:
    try:
        if STATE_FILE.exists():
            data = json.loads(STATE_FILE.read_text(encoding='utf-8'))
            return bool(data.get('show_advanced_tools', False))
    except Exception:
        pass
    return False


def _save_show_advanced(value: bool) -> None:
    try:
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(
            json.dumps({'show_advanced_tools': bool(value)}, ensure_ascii=False, indent=2),
            encoding='utf-8',
        )
    except Exception:
        pass


def _title_matches(title: str, words: Iterable[str]) -> bool:
    normalized = (title or '').replace('️', '').strip()
    return any(word and word in normalized for word in words)


def _is_essential(group_key: str, title: str) -> bool:
    return _title_matches(title, ESSENTIAL_KEYWORDS.get(group_key, []))


def _is_advanced(title: str) -> bool:
    return _title_matches(title, ADVANCED_HINTS)


def _collect_inner_tabs(inner: QTabWidget) -> list[tuple[str, QWidget]]:
    """Capture the original inner tabs once, without deleting their widgets."""
    existing = getattr(inner, 'v4610_all_tabs', None)
    if existing:
        # Include any tabs added later by other patches.
        known = {id(w) for _, w in existing}
        for i in range(inner.count()):
            widget = inner.widget(i)
            title = inner.tabText(i) or 'أداة'
            if widget is not None and id(widget) not in known:
                existing.append((title, widget))
                known.add(id(widget))
        return existing

    tabs: list[tuple[str, QWidget]] = []
    for i in range(inner.count()):
        widget = inner.widget(i)
        title = inner.tabText(i) or 'أداة'
        if widget is not None and 'فارغ' not in title and 'لا توجد أدوات' not in title:
            tabs.append((title, widget))
    setattr(inner, 'v4610_all_tabs', tabs)
    return tabs


def _rebuild_inner(inner: QTabWidget, group_key: str, show_advanced: bool) -> None:
    all_tabs = _collect_inner_tabs(inner)
    if not all_tabs:
        return

    if show_advanced:
        visible_tabs = all_tabs
    else:
        essentials = [(t, w) for t, w in all_tabs if _is_essential(group_key, t)]
        # Keep at least a small, useful set if a group has custom titles.
        if not essentials:
            essentials = [(t, w) for t, w in all_tabs if not _is_advanced(t)][:5]
        visible_tabs = essentials[:8]

    current_widget = inner.currentWidget()
    inner.blockSignals(True)
    while inner.count():
        inner.removeTab(0)
    for title, widget in visible_tabs:
        inner.addTab(widget, title)
    if current_widget:
        for i in range(inner.count()):
            if inner.widget(i) is current_widget:
                inner.setCurrentIndex(i)
                break
    inner.blockSignals(False)

    try:
        inner.setMovable(False)
        inner.setDocumentMode(True)
        inner.setUsesScrollButtons(True)
    except Exception:
        pass


def _ensure_group_controls(page: ToolsPage, group_key: str, inner: QTabWidget) -> None:
    group_page = inner.parentWidget()
    if not group_page or getattr(group_page, 'v4610_controls_added', False):
        return
    layout = group_page.layout()
    if layout is None:
        return

    bar = QFrame(group_page)
    bar.setObjectName('noticeBox')
    row = QHBoxLayout(bar)
    row.setContentsMargins(10, 6, 10, 6)

    label = QLabel('الوضع المبسط يعرض الأدوات الأساسية فقط. فعّل الخيار لإظهار الأدوات المتقدمة عند الحاجة.')
    label.setWordWrap(True)
    toggle = QCheckBox('إظهار الأدوات المتقدمة')
    toggle.setChecked(_load_show_advanced())
    toggle.setCursor(Qt.PointingHandCursor)

    def on_toggle(value: bool, p=page):
        _save_show_advanced(bool(value))
        _apply_tools_simplify(p)

    toggle.toggled.connect(on_toggle)
    row.addWidget(label, 1)
    row.addWidget(toggle, 0)

    # Put the control directly above the inner tabs.
    idx = -1
    for i in range(layout.count()):
        item = layout.itemAt(i)
        if item and item.widget() is inner:
            idx = i
            break
    if idx >= 0:
        layout.insertWidget(idx, bar)
    else:
        layout.addWidget(bar)
    setattr(group_page, 'v4610_controls_added', True)
    setattr(group_page, 'v4610_toggle', toggle)


def _apply_tools_simplify(page: ToolsPage) -> None:
    if getattr(page, 'v4610_simplifying', False):
        return
    if not hasattr(page, 'tabs') or not isinstance(page.tabs, QTabWidget):
        return
    setattr(page, 'v4610_simplifying', True)
    try:
        show_advanced = _load_show_advanced()
        for group_key in GROUP_KEYS:
            inner = page.findChild(QTabWidget, f'v4517417_inner_{group_key}')
            if inner is None:
                continue
            _ensure_group_controls(page, group_key, inner)
            _rebuild_inner(inner, group_key, show_advanced)

            group_page = inner.parentWidget()
            toggle = getattr(group_page, 'v4610_toggle', None) if group_page else None
            if toggle is not None and toggle.isChecked() != show_advanced:
                toggle.blockSignals(True)
                toggle.setChecked(show_advanced)
                toggle.blockSignals(False)

        if not getattr(page, 'v4610_doc_added', False):
            setattr(page, 'v4610_doc_added', True)
            try:
                page.notify('تم تفعيل وضع الأدوات المبسط: الأدوات الأساسية ظاهرة والمتقدمة مخفية اختيارياً')
            except Exception:
                pass
    finally:
        setattr(page, 'v4610_simplifying', False)


def _tools_init(self, service, notify, current_user=None):
    _ORIG_INIT(self, service, notify, current_user)
    _apply_tools_simplify(self)


def _tools_refresh(self):
    if _ORIG_REFRESH:
        _ORIG_REFRESH(self)
    _apply_tools_simplify(self)


ToolsPage.__init__ = _tools_init
ToolsPage.refresh = _tools_refresh
ToolsPage.v4610_apply_tools_simplify = _apply_tools_simplify
