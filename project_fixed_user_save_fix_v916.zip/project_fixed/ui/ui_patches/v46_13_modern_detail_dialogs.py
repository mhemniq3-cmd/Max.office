from __future__ import annotations

"""v46.13 - Clean, interactive detail dialogs for movements and reports.

This patch intentionally does not rebuild ToolsPage or ReportsPage. It only
replaces double-click/detail behavior with a unified, organized dialog that can
show full operation details, invoice items, related movements, audit values and
manager notes. Reports rows use the same dialog style.
"""

import html
import json
from pathlib import Path
from typing import Any

from database import money
from ui.ui_common import *
from ui.pages.tools_page import ToolsPage
from ui.pages.reports_page import ReportsPage

_ORIG_TOOLS_INIT = getattr(ToolsPage, '__init__', None)
_ORIG_TOOLS_REFRESH_CENTER = getattr(ToolsPage, 'v4517414_refresh_center', None)
_ORIG_REPORTS_INIT = getattr(ReportsPage, '__init__', None)
_ORIG_REPORTS_REFRESH = getattr(ReportsPage, 'refresh', None)
_ORIG_ADVANCED_REFRESH = getattr(ReportsPage, 'refresh_advanced', None)


def _clean(value: Any, default: str = '-') -> str:
    if value is None:
        return default
    text = str(value).strip()
    return text if text else default


def _num(value: Any) -> float:
    try:
        return float(value or 0)
    except Exception:
        return 0.0


def _money(value: Any) -> str:
    try:
        return money(value)
    except Exception:
        n = _num(value)
        if abs(n - int(n)) < 0.001:
            return f'{int(n):,}'
        return f'{n:,.2f}'


def _pretty_json(value: Any) -> str:
    text = '' if value is None else str(value).strip()
    if not text:
        return ''
    try:
        return json.dumps(json.loads(text), ensure_ascii=False, indent=2)
    except Exception:
        return text


def _safe_filename(text: str) -> str:
    keep = []
    for ch in str(text):
        if ch.isalnum() or ch in ('-', '_'):
            keep.append(ch)
        else:
            keep.append('_')
    return ''.join(keep).strip('_')[:80] or 'details'


def _section_title(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName('detailSectionTitle')
    label.setWordWrap(True)
    return label


def _info_card(title: str, value: Any, hint: str = '') -> QFrame:
    card = QFrame()
    card.setObjectName('detailInfoCard')
    lay = QVBoxLayout(card)
    lay.setContentsMargins(14, 10, 14, 10)
    t = QLabel(title)
    t.setObjectName('detailCardTitle')
    v = QLabel(_clean(value))
    v.setObjectName('detailCardValue')
    v.setWordWrap(True)
    lay.addWidget(t)
    lay.addWidget(v)
    if hint:
        h = QLabel(hint)
        h.setObjectName('detailCardHint')
        h.setWordWrap(True)
        lay.addWidget(h)
    return card


def _mini_table(headers: list[str], rows: list[list[Any]], min_height: int = 130) -> Table:
    table = Table(headers)
    table.setMinimumHeight(min_height)
    table.setAlternatingRowColors(True)
    table.setWordWrap(True)
    table.setRowCount(len(rows))
    for r, row in enumerate(rows):
        for c, value in enumerate(row):
            table.put(r, c, _clean(value, ''))
    table.resizeRowsToContents()
    return table


def _html_table(headers: list[str], rows: list[list[Any]]) -> str:
    th = ''.join(f'<th>{html.escape(str(h))}</th>' for h in headers)
    body = []
    for row in rows:
        body.append('<tr>' + ''.join(f'<td>{html.escape(_clean(v, ""))}</td>' for v in row) + '</tr>')
    return f'<table><thead><tr>{th}</tr></thead><tbody>{"".join(body)}</tbody></table>'


def _style_dialog(dlg: QDialog) -> None:
    dlg.setLayoutDirection(Qt.RightToLeft)
    dlg.setStyleSheet('''
        QDialog { background: #f6f7fb; }
        QLabel#detailDialogTitle { font-size: 21px; font-weight: 800; color: #111827; }
        QLabel#detailDialogSubtitle { font-size: 12px; color: #6b7280; }
        QLabel#detailPill { background: #eef2ff; color: #3730a3; border-radius: 12px; padding: 6px 12px; font-weight: 700; }
        QLabel#dangerPill { background: #fee2e2; color: #991b1b; border-radius: 12px; padding: 6px 12px; font-weight: 700; }
        QLabel#detailSectionTitle { font-size: 15px; font-weight: 800; color: #111827; padding: 4px 0; }
        QFrame#detailInfoCard { background: white; border: 1px solid #e5e7eb; border-radius: 14px; }
        QLabel#detailCardTitle { color: #6b7280; font-size: 11px; font-weight: 700; }
        QLabel#detailCardValue { color: #111827; font-size: 17px; font-weight: 800; }
        QLabel#detailCardHint { color: #6b7280; font-size: 11px; }
        QTabWidget::pane { border: 1px solid #e5e7eb; background: white; border-radius: 10px; }
        QTabBar::tab { padding: 8px 18px; margin: 2px; border-radius: 9px; background: #eef2f7; color: #374151; }
        QTabBar::tab:selected { background: #2563eb; color: white; font-weight: 700; }
        QTableWidget { background: white; border: 1px solid #e5e7eb; border-radius: 9px; gridline-color: #eef2f7; }
        QHeaderView::section { background: #f3f4f6; color: #374151; padding: 8px; border: 0; font-weight: 700; }
        QTextEdit { background: white; border: 1px solid #e5e7eb; border-radius: 9px; padding: 8px; }
        QPushButton { padding: 8px 14px; border-radius: 8px; background: #e5e7eb; color: #111827; }
        QPushButton#primaryButton { background: #2563eb; color: white; font-weight: 700; }
        QPushButton#successButton { background: #059669; color: white; font-weight: 700; }
    ''')


class _UnifiedDetailsDialog(QDialog):
    def __init__(self, parent: QWidget | None, title: str, subtitle: str = '', severity: str = '', danger: bool = False):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(1080, 760)
        _style_dialog(self)
        self._html_blocks: list[str] = []
        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(18, 16, 18, 16)
        self.root.setSpacing(12)

        head = QHBoxLayout()
        title_box = QVBoxLayout()
        self.title_label = QLabel(title)
        self.title_label.setObjectName('detailDialogTitle')
        self.title_label.setWordWrap(True)
        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setObjectName('detailDialogSubtitle')
        self.subtitle_label.setWordWrap(True)
        title_box.addWidget(self.title_label)
        title_box.addWidget(self.subtitle_label)
        head.addLayout(title_box, 1)
        if severity:
            pill = QLabel(severity)
            pill.setObjectName('dangerPill' if danger else 'detailPill')
            pill.setAlignment(Qt.AlignCenter)
            head.addWidget(pill, 0)
        self.root.addLayout(head)

        self.card_grid = QGridLayout()
        self.card_grid.setSpacing(10)
        self.root.addLayout(self.card_grid)
        self._card_count = 0

        self.tabs = QTabWidget()
        self.root.addWidget(self.tabs, 1)

        bottom = QHBoxLayout()
        self.copy_btn = QPushButton('نسخ التفاصيل')
        self.copy_btn.setObjectName('primaryButton')
        self.copy_btn.clicked.connect(self.copy_details)
        self.html_btn = QPushButton('حفظ / طباعة HTML')
        self.html_btn.setObjectName('successButton')
        self.html_btn.clicked.connect(self.save_html)
        close_btn = QPushButton('إغلاق')
        close_btn.clicked.connect(self.accept)
        bottom.addWidget(self.copy_btn)
        bottom.addWidget(self.html_btn)
        bottom.addStretch(1)
        bottom.addWidget(close_btn)
        self.root.addLayout(bottom)

    def add_card(self, title: str, value: Any, hint: str = '') -> None:
        idx = self._card_count
        self.card_grid.addWidget(_info_card(title, value, hint), idx // 4, idx % 4)
        self._card_count += 1

    def add_tab_widget(self, title: str, widget: QWidget) -> None:
        self.tabs.addTab(widget, title)

    def add_html(self, block: str) -> None:
        if block:
            self._html_blocks.append(block)

    def details_text(self) -> str:
        parts = [self.title_label.text(), self.subtitle_label.text()]
        for block in self._html_blocks:
            text = block.replace('<br>', '\n').replace('</p>', '\n').replace('</tr>', '\n')
            text = re_sub_html(text)
            if text.strip():
                parts.append(text.strip())
        return '\n\n'.join(p for p in parts if p)

    def copy_details(self) -> None:
        QApplication.clipboard().setText(self.details_text())
        QMessageBox.information(self, 'تم النسخ', 'تم نسخ تفاصيل النافذة إلى الحافظة.')

    def save_html(self) -> None:
        try:
            out = Path('exports') / 'details'
            out.mkdir(parents=True, exist_ok=True)
            path = out / f'{_safe_filename(self.windowTitle())}.html'
            content = self.html_document()
            path.write_text(content, encoding='utf-8')
            QMessageBox.information(self, 'تم الحفظ', f'تم إنشاء ملف التفاصيل:\n{path}')
        except Exception as exc:
            QMessageBox.warning(self, 'تعذر الحفظ', str(exc))

    def html_document(self) -> str:
        body = ''.join(self._html_blocks) or '<p>لا توجد تفاصيل.</p>'
        return f'''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
        <title>{html.escape(self.windowTitle())}</title>
        <style>body{{font-family:Tahoma,Arial,sans-serif;background:#f6f7fb;color:#111827;padding:24px}}
        .box{{background:white;border:1px solid #e5e7eb;border-radius:14px;padding:16px;margin:12px 0}}
        h1{{font-size:24px}} h2{{font-size:18px}} table{{width:100%;border-collapse:collapse;background:white}}
        th,td{{border:1px solid #e5e7eb;padding:8px;text-align:right}} th{{background:#f3f4f6}}</style></head><body>
        <h1>{html.escape(self.title_label.text())}</h1><p>{html.escape(self.subtitle_label.text())}</p>{body}</body></html>'''


def re_sub_html(text: str) -> str:
    import re
    text = re.sub(r'<[^>]+>', ' ', text)
    text = html.unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _details_tab(fields: list[tuple[str, Any]]) -> QWidget:
    page = QWidget()
    lay = QVBoxLayout(page)
    lay.setContentsMargins(12, 12, 12, 12)
    form_rows = [[label, _clean(value)] for label, value in fields]
    lay.addWidget(_mini_table(['الحقل', 'القيمة'], form_rows, 240), 1)
    return page


def _text_tab(text: str) -> QWidget:
    page = QWidget()
    lay = QVBoxLayout(page)
    box = QTextEdit(_clean(text, 'لا توجد بيانات.'))
    box.setReadOnly(True)
    lay.addWidget(box)
    return page


def _movement_id_from_table(page: ToolsPage) -> int | None:
    tables = []
    if hasattr(page, 'v4517414_stack'):
        tables.append(page.v4517414_stack.currentWidget())
    for name in ('v4517414_daily_table', 'v4517414_sensitive_table', 'v4517414_fraud_table'):
        obj = getattr(page, name, None)
        if isinstance(obj, QTableWidget):
            tables.append(obj)
    for table in tables:
        if not isinstance(table, QTableWidget):
            continue
        row = table.currentRow()
        if row < 0:
            continue
        item = table.item(row, 0)
        if not item:
            continue
        try:
            return int(item.data(Qt.UserRole))
        except Exception:
            continue
    return None


def _add_manager_note(parent: QWidget, service: AppService, movement_id: int, dlg: QDialog) -> None:
    note, ok = QInputDialog.getText(parent, 'ملاحظة المدير', 'اكتب ملاحظة مرتبة لهذه العملية:')
    if not ok or not str(note).strip():
        return
    try:
        service.add_movement_manager_note(int(movement_id), str(note).strip())
        QMessageBox.information(parent, 'تم الحفظ', 'تم حفظ ملاحظة المدير على العملية.')
        dlg.accept()
        _show_movement_details(parent, service, movement_id)
    except Exception as exc:
        QMessageBox.warning(parent, 'تعذر الحفظ', str(exc))


def _sale_items_rows(items: list[dict[str, Any]]) -> list[list[Any]]:
    rows: list[list[Any]] = []
    for item in items:
        rows.append([
            item.get('product_name') or item.get('name') or '',
            item.get('quantity') or '',
            _money(item.get('unit_price')),
            _money(item.get('line_total')),
            _money(item.get('profit_amount')),
            _money(item.get('commission_amount')),
        ])
    return rows


def _build_movement_dialog(parent: QWidget, service: AppService, movement_id: int, data: dict[str, Any]) -> _UnifiedDetailsDialog:
    action = data.get('action') or 'عملية'
    sale = data.get('sale') or {}
    items = data.get('items') or []
    invoice_no = data.get('invoice_no') or sale.get('invoice_no') or data.get('record_id') or '-'
    severity = data.get('severity') or ('حساس' if data.get('is_sensitive') else 'عادي')
    danger = str(severity) in ('حساس', 'خطر', 'حرج') or bool(data.get('is_sensitive'))
    subtitle = f"الوقت: {_clean(data.get('operation_time') or data.get('event_time'))} | المستخدم: {_clean(data.get('user_name'))}"
    dlg = _UnifiedDetailsDialog(parent, f'تفاصيل العملية - {action}', subtitle, str(severity), danger)

    seller = data.get('seller_or_employee') or data.get('employee_name') or data.get('seller_name') or data.get('user_name')
    dlg.add_card('رقم الفاتورة / المرجع', invoice_no)
    dlg.add_card('المادة / المواد', data.get('product_names') or (items[0].get('product_name') if items else data.get('record_type')))
    dlg.add_card('البائع / الموظف', seller)
    dlg.add_card('عدد القطع', data.get('sold_quantity') or sum(_num(i.get('quantity')) for i in items) or '-')
    dlg.add_card('إجمالي العملية', _money(data.get('sale_total') or sale.get('total') or data.get('line_total')))
    dlg.add_card('الخصم', _money(sale.get('discount_amount') or data.get('sale_discount')))
    dlg.add_card('الزبون', data.get('customer_name') or sale.get('customer_name') or 'زبون عام')
    dlg.add_card('طريقة الدفع', data.get('payment_method') or sale.get('payment_method') or '-')

    fields = [
        ('وقت العملية', data.get('operation_time') or data.get('event_time')),
        ('الأهمية', severity),
        ('القسم', data.get('module')),
        ('المستخدم', data.get('user_name')),
        ('البائع / الموظف', seller),
        ('رقم الفاتورة', invoice_no),
        ('الزبون', data.get('customer_name') or sale.get('customer_name')),
        ('طريقة الدفع', data.get('payment_method') or sale.get('payment_method')),
        ('عدد القطع', data.get('sold_quantity')),
        ('الوصف', data.get('description')),
        ('نوع السجل', data.get('record_type')),
        ('رقم السجل', data.get('record_id')),
        ('المصدر', data.get('source_table')),
    ]
    dlg.add_tab_widget('الملخص', _details_tab(fields))
    dlg.add_html('<div class="box"><h2>ملخص العملية</h2>' + _html_table(['الحقل', 'القيمة'], [[a, b] for a, b in fields]) + '</div>')

    if sale:
        sale_rows = [
            ['المجموع قبل الخصم', _money(sale.get('subtotal'))],
            ['الخصم', _money(sale.get('discount_amount'))],
            ['الضريبة', _money(sale.get('tax_amount'))],
            ['الصافي', _money(sale.get('total'))],
            ['الربح', _money(sale.get('total_profit'))],
            ['العمولة', _money(sale.get('total_commission'))],
            ['الحالة', sale.get('status') or 'completed'],
            ['ملاحظة الفاتورة', sale.get('note') or ''],
        ]
        dlg.add_tab_widget('الفاتورة', _details_tab([(r[0], r[1]) for r in sale_rows]))
        dlg.add_html('<div class="box"><h2>ملخص الفاتورة</h2>' + _html_table(['البند', 'القيمة'], sale_rows) + '</div>')

    if items:
        rows = _sale_items_rows(items)
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.addWidget(_mini_table(['المادة', 'الكمية', 'سعر الوحدة', 'الإجمالي', 'الربح', 'العمولة'], rows, 260), 1)
        dlg.add_tab_widget('المواد', page)
        dlg.add_html('<div class="box"><h2>المواد داخل العملية</h2>' + _html_table(['المادة', 'الكمية', 'سعر الوحدة', 'الإجمالي', 'الربح', 'العمولة'], rows) + '</div>')

    related = data.get('related_movements') or []
    if related:
        rows = [[r.get('event_time',''), r.get('user_name',''), r.get('action',''), r.get('severity',''), r.get('description','')] for r in related[:80]]
        page = QWidget(); lay = QVBoxLayout(page); lay.setContentsMargins(12, 12, 12, 12)
        lay.addWidget(_mini_table(['الوقت', 'المستخدم', 'العملية', 'الأهمية', 'التفاصيل'], rows, 240), 1)
        dlg.add_tab_widget('حركات مرتبطة', page)
        dlg.add_html('<div class="box"><h2>الحركات المرتبطة</h2>' + _html_table(['الوقت', 'المستخدم', 'العملية', 'الأهمية', 'التفاصيل'], rows) + '</div>')

    audit_parts = []
    if data.get('old_values'):
        audit_parts.append('قبل:\n' + _pretty_json(data.get('old_values')))
    if data.get('new_values'):
        audit_parts.append('بعد:\n' + _pretty_json(data.get('new_values')))
    notes = data.get('manager_notes_history') or []
    if notes:
        audit_parts.append('ملاحظات المدير:\n' + '\n'.join(str(n) for n in notes))
    if audit_parts:
        dlg.add_tab_widget('التدقيق والملاحظات', _text_tab('\n\n'.join(audit_parts)))
        dlg.add_html('<div class="box"><h2>التدقيق والملاحظات</h2><pre>' + html.escape('\n\n'.join(audit_parts)) + '</pre></div>')

    note_btn = QPushButton('إضافة ملاحظة مدير')
    note_btn.setObjectName('primaryButton')
    note_btn.clicked.connect(lambda: _add_manager_note(parent, service, movement_id, dlg))
    dlg.root.itemAt(dlg.root.count() - 1).layout().insertWidget(2, note_btn)
    return dlg


def _show_movement_details(parent: QWidget, service: AppService, movement_id: int | None = None) -> None:
    mid = movement_id
    if mid is None and isinstance(parent, ToolsPage):
        mid = _movement_id_from_table(parent)
    if mid is None:
        QMessageBox.information(parent, 'تفاصيل العملية', 'اختر عملية من السجل أولاً.')
        return
    try:
        data = service.get_unified_movement_details(int(mid)) if hasattr(service, 'get_unified_movement_details') else {}
    except Exception as exc:
        QMessageBox.warning(parent, 'تعذر فتح التفاصيل', str(exc))
        return
    if not data:
        QMessageBox.information(parent, 'تفاصيل العملية', 'لا توجد تفاصيل لهذه العملية.')
        return
    _build_movement_dialog(parent, service, int(mid), dict(data)).exec()


def _reconnect_movement_tables(page: ToolsPage) -> None:
    for name in ('v4517414_daily_table', 'v4517414_sensitive_table', 'v4517414_fraud_table'):
        table = getattr(page, name, None)
        if not isinstance(table, QTableWidget):
            continue
        try:
            table.itemDoubleClicked.disconnect()
        except Exception:
            pass
        table.itemDoubleClicked.connect(lambda item, p=page: _show_movement_details(p, p.service, None))
        table._v4613_modern_details_connected = True


def _tools_init(self: ToolsPage, *args, **kwargs):
    if _ORIG_TOOLS_INIT:
        _ORIG_TOOLS_INIT(self, *args, **kwargs)
    try:
        _reconnect_movement_tables(self)
    except Exception as exc:
        log_exception(exc, 'v46.13 reconnect movement details')


def _tools_refresh_center(self: ToolsPage):
    result = None
    if _ORIG_TOOLS_REFRESH_CENTER:
        result = _ORIG_TOOLS_REFRESH_CENTER(self)
    try:
        _reconnect_movement_tables(self)
    except Exception as exc:
        log_exception(exc, 'v46.13 reconnect after refresh')
    return result


def _invoice_from_report_row(table: QTableWidget) -> str:
    row = table.currentRow()
    if row < 0:
        return ''
    item = table.item(row, 0)
    return item.text().strip() if item else ''


def _report_row_values(table: QTableWidget) -> tuple[list[str], list[str]]:
    row = table.currentRow()
    headers: list[str] = []
    vals: list[str] = []
    if row < 0:
        return headers, vals
    for c in range(table.columnCount()):
        h = table.horizontalHeaderItem(c)
        i = table.item(row, c)
        headers.append(h.text() if h else f'الحقل {c+1}')
        vals.append(i.text() if i else '')
    return headers, vals


def _show_report_details(page: ReportsPage, table: QTableWidget, report_title: str) -> None:
    headers, vals = _report_row_values(table)
    if not headers:
        QMessageBox.information(page, 'تفاصيل التقرير', 'اختر صفاً من التقرير أولاً.')
        return
    invoice = vals[0] if headers and any(k in headers[0] for k in ('فاتورة', 'الفاتورة', 'الرقم')) else ''
    sale: dict[str, Any] = {}
    items: list[dict[str, Any]] = []
    if invoice and hasattr(page.service, 'invoice_details'):
        try:
            s, it = page.service.invoice_details(invoice)
            sale = dict(s or {})
            items = [dict(x) for x in (it or [])]
        except Exception:
            sale, items = {}, []

    dlg = _UnifiedDetailsDialog(page, f'تفاصيل التقرير - {report_title}', f'الصف المحدد: {_clean(invoice or vals[0])}', 'تقرير')
    for h, v in list(zip(headers, vals))[:8]:
        dlg.add_card(h, v)

    row_pairs = list(zip(headers, vals))
    dlg.add_tab_widget('ملخص الصف', _details_tab(row_pairs))
    dlg.add_html('<div class="box"><h2>ملخص صف التقرير</h2>' + _html_table(['الحقل', 'القيمة'], [[h, v] for h, v in row_pairs]) + '</div>')

    if sale:
        sale_rows = [
            ['رقم الفاتورة', sale.get('invoice_no') or invoice],
            ['التاريخ', sale.get('created_at')],
            ['المستخدم', sale.get('user_name') or sale.get('username')],
            ['الموظف', sale.get('employee') or sale.get('employee_name')],
            ['الزبون', sale.get('customer') or sale.get('customer_name') or 'زبون عام'],
            ['طريقة الدفع', sale.get('payment_method')],
            ['المجموع', _money(sale.get('subtotal'))],
            ['الخصم', _money(sale.get('discount_amount'))],
            ['الضريبة', _money(sale.get('tax_amount'))],
            ['الصافي', _money(sale.get('total'))],
            ['الربح', _money(sale.get('total_profit'))],
            ['العمولة', _money(sale.get('total_commission'))],
            ['ملاحظة', sale.get('note') or ''],
        ]
        dlg.add_tab_widget('تفاصيل الفاتورة', _details_tab([(r[0], r[1]) for r in sale_rows]))
        dlg.add_html('<div class="box"><h2>تفاصيل الفاتورة</h2>' + _html_table(['البند', 'القيمة'], sale_rows) + '</div>')
    if items:
        item_rows = _sale_items_rows(items)
        tab = QWidget(); lay = QVBoxLayout(tab); lay.setContentsMargins(12, 12, 12, 12)
        lay.addWidget(_mini_table(['المادة', 'الكمية', 'سعر الوحدة', 'الإجمالي', 'الربح', 'العمولة'], item_rows, 260), 1)
        dlg.add_tab_widget('مواد الفاتورة', tab)
        dlg.add_html('<div class="box"><h2>مواد الفاتورة</h2>' + _html_table(['المادة', 'الكمية', 'سعر الوحدة', 'الإجمالي', 'الربح', 'العمولة'], item_rows) + '</div>')

    dlg.exec()


def _connect_reports(page: ReportsPage) -> None:
    table = getattr(page, 'table', None)
    if isinstance(table, QTableWidget):
        try:
            table.itemDoubleClicked.disconnect()
        except Exception:
            pass
        table.itemDoubleClicked.connect(lambda item, p=page, t=table: _show_report_details(p, t, 'الفواتير والمبيعات'))
        btn = getattr(page, 'v4613_report_details_btn', None)
        if btn is None:
            btn = QPushButton('عرض تفاصيل الصف')
            btn.setObjectName('primaryButton')
            btn.clicked.connect(lambda p=page, t=table: _show_report_details(p, t, 'الفواتير والمبيعات'))
            page.v4613_report_details_btn = btn
            # Add the button to the first report tab action row when possible.
            try:
                first_tab = page.tabs.widget(0)
                layout = first_tab.layout()
                if layout and layout.count() > 0:
                    top = layout.itemAt(0).layout()
                    if top:
                        top.insertWidget(max(0, top.count() - 1), btn)
            except Exception:
                pass
    advanced = getattr(page, 'advanced_table', None)
    if isinstance(advanced, QTableWidget):
        try:
            advanced.itemDoubleClicked.disconnect()
        except Exception:
            pass
        advanced.itemDoubleClicked.connect(lambda item, p=page, t=advanced: _show_report_details(p, t, p.report_kind.currentText() if hasattr(p, 'report_kind') else 'تقرير إداري'))


def _reports_init(self: ReportsPage, *args, **kwargs):
    if _ORIG_REPORTS_INIT:
        _ORIG_REPORTS_INIT(self, *args, **kwargs)
    try:
        _connect_reports(self)
    except Exception as exc:
        log_exception(exc, 'v46.13 reports init')


def _reports_refresh(self: ReportsPage):
    result = None
    if _ORIG_REPORTS_REFRESH:
        result = _ORIG_REPORTS_REFRESH(self)
    try:
        _connect_reports(self)
    except Exception as exc:
        log_exception(exc, 'v46.13 reports refresh')
    return result


def _advanced_refresh(self: ReportsPage):
    result = None
    if _ORIG_ADVANCED_REFRESH:
        result = _ORIG_ADVANCED_REFRESH(self)
    try:
        _connect_reports(self)
    except Exception as exc:
        log_exception(exc, 'v46.13 advanced refresh')
    return result


ToolsPage.__init__ = _tools_init
ToolsPage.v4517414_refresh_center = _tools_refresh_center
ToolsPage.v4613_show_modern_movement_details = _show_movement_details
ReportsPage.__init__ = _reports_init
ReportsPage.refresh = _reports_refresh
ReportsPage.refresh_advanced = _advanced_refresh
ReportsPage.v4613_show_report_details = _show_report_details
