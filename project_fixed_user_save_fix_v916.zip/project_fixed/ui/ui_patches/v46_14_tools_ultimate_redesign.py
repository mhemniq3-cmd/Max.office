from __future__ import annotations

from PySide6.QtCore import Qt, QTimer, QSize, QPropertyAnimation, QPointF
from PySide6.QtGui import QIcon, QFont, QColor, QCursor
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QStackedWidget,
    QScrollArea, QTabWidget, QLabel, QFrame, QPushButton, QGraphicsDropShadowEffect
)

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

_ORIG_INIT = ToolsPage.__init__
_ORIG_REFRESH = getattr(ToolsPage, 'refresh', None)

ULTIMATE_GRID_QSS = """
/* v46.15 - Grid Dashboard Tools Redesign */
QScrollArea#dashboardScroll {
    background: #f1f5f9;
    border: none;
}
QScrollArea#toolContentScroll {
    background: #f1f5f9;
    border: none;
}
QFrame#gridCard {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 20px;
}
QFrame#gridCard:hover {
    background: #f8fafc;
    border: 2px solid #3b82f6;
}
QFrame#toolContentCard {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
}
ToolsPage QPushButton {
    background-color: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 10px;
    padding: 10px 18px;
    font-weight: 800;
    color: #334155;
    min-height: 42px;
}
ToolsPage QPushButton:hover {
    background-color: #e0f2fe;
    border-color: #38bdf8;
    color: #0284c7;
}
ToolsPage QPushButton:pressed {
    background-color: #bae6fd;
}
QPushButton#backBtn {
    background-color: #f1f5f9;
    border: 2px solid #e2e8f0;
    border-radius: 12px;
    font-size: 15px;
    color: #0f172a;
    padding: 8px 24px;
}
QPushButton#backBtn:hover {
    background-color: #e2e8f0;
    border-color: #cbd5e1;
}
"""

TOOL_METADATA = {
    'الشركة': ('🏢', 'ملف الشركة', 'الهوية، اللوجو، ومعلومات التواصل'),
    'المظهر': ('🎨', 'المظهر والهوية', 'الألوان، الوضع الداكن، والخطوط'),
    'الفروع': ('🏪', 'إدارة الفروع', 'المخازن ومواقع العمل'),
    'الموظفين': ('🎯', 'أهداف المبيعات', 'المبيعات المستهدفة للموظفين'),
    'المخزون': ('📦', 'حركة المخزون', 'متابعة الوارد والصادر والصلاحية'),
    'الجرد': ('⚖️', 'تسوية الجرد', 'مطابقة الرصيد الفعلي مع النظام'),
    'الفواتير': ('⏳', 'الفواتير المعلقة', 'مراجعة المبيعات غير المكتملة'),
    'الإغلاق': ('🌙', 'إغلاق اليومية', 'ترحيل الدرج وإقفال حسابات اليوم'),
    'عمولات': ('💸', 'نظام العمولات', 'حساب نسب المبيعات للمناديب'),
    'المستخدمين': ('🧑‍💻', 'حسابات الدخول', 'إدارة وتعديل حسابات المستخدمين'),
    'صلاحيات': ('🛡️', 'صلاحيات الوصول', 'تحديد ما يمكن لكل موظف رؤيته'),
    'النسخ': ('☁️', 'النسخ الاحتياطي', 'تأمين وحفظ بيانات النظام بأمان'),
    'استعادة': ('⏪', 'استعادة البيانات', 'الرجوع لنسخة سابقة عند الطوارئ'),
    'الباركود': ('🏷️', 'طابعات الباركود', 'تخصيص ملصقات وطابعات الباركود'),
    'سجل': ('🕵️', 'سجل المراقبة', 'تتبع حركات النظام والمستخدمين'),
    'الضريبة': ('🧾', 'إعداد الضرائب', 'تكوين نسب الضريبة والقيمة المضافة'),
    'فحص': ('🩺', 'فحص النظام', 'صيانة واكتشاف أخطاء قاعدة البيانات'),
    'دليل': ('📖', 'دليل الاستخدام', 'شرح وتعليمات استخدام النظام'),
    'Drive': ('☁️', 'جوجل درايف', 'المزامنة السحابية الاحتياطية'),
    'عروض': ('📄', 'عروض الأسعار', 'تجهيز وإرسال العروض للعملاء'),
    'توريد': ('🚚', 'أوامر التوريد', 'تتبع ومراجعة أوامر التوريد للمخازن'),
}

CATEGORIES = [
    ('⚙️ إعدادات النظام والمستخدمين', ['الشركة', 'المظهر', 'المستخدمين', 'صلاحيات', 'الضريبة']),
    ('💼 العمليات والمبيعات', ['الإغلاق', 'الفواتير', 'عمولات', 'الموظفين', 'عروض', 'توريد']),
    ('📦 المخازن والجرد', ['المخزون', 'الجرد', 'الفروع']),
    ('🛠️ الصيانة والأدوات', ['النسخ', 'Drive', 'استعادة', 'فحص', 'الباركود', 'سجل', 'دليل']),
]

class GridCard(QFrame):
    def __init__(self, icon_str, title, subtitle, click_callback):
        super().__init__()
        self.click_callback = click_callback
        self.setObjectName("gridCard")
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedSize(280, 160)
        
        # Soft shadow for card
        self._shadow = QGraphicsDropShadowEffect(self)
        self._shadow.setBlurRadius(15)
        self._shadow.setColor(QColor(0, 0, 0, 15))
        self._shadow.setOffset(0, 4)
        self.setGraphicsEffect(self._shadow)
        
        # Animations for Legendary Interactivity
        self.anim_blur = QPropertyAnimation(self._shadow, b"blurRadius")
        self.anim_blur.setDuration(250)
        
        self.anim_offset = QPropertyAnimation(self._shadow, b"offset")
        self.anim_offset.setDuration(250)
        
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        layout.setContentsMargins(16, 24, 16, 24)
        layout.setSpacing(8)
        
        icon_lbl = QLabel(icon_str)
        icon_lbl.setStyleSheet("font-size: 46px; background: transparent;")
        icon_lbl.setAlignment(Qt.AlignCenter)
        
        t_lbl = QLabel(title)
        t_lbl.setStyleSheet("font-size: 19px; font-weight: 900; color: #0f172a; background: transparent;")
        t_lbl.setAlignment(Qt.AlignCenter)
        t_lbl.setWordWrap(True)
        
        s_lbl = QLabel(subtitle)
        s_lbl.setStyleSheet("font-size: 13px; font-weight: 500; color: #64748b; background: transparent;")
        s_lbl.setAlignment(Qt.AlignCenter)
        s_lbl.setWordWrap(True)
        
        layout.addWidget(icon_lbl)
        layout.addWidget(t_lbl)
        layout.addWidget(s_lbl)
        
    def enterEvent(self, event):
        self.anim_blur.stop()
        self.anim_blur.setEndValue(40)
        self.anim_blur.start()
        
        self.anim_offset.stop()
        self.anim_offset.setEndValue(QPointF(0, 12))
        self.anim_offset.start()
        
        self.setStyleSheet("QFrame#gridCard { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #ffffff, stop:1 #f0f9ff); border: 2px solid #3b82f6; border-radius: 20px; }")
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.anim_blur.stop()
        self.anim_blur.setEndValue(15)
        self.anim_blur.start()
        
        self.anim_offset.stop()
        self.anim_offset.setEndValue(QPointF(0, 4))
        self.anim_offset.start()
        
        self.setStyleSheet("") # Revert to QSS
        super().leaveEvent(event)
        
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.click_callback()
        super().mousePressEvent(event)

def extract_all_pages(page: ToolsPage) -> list[tuple[str, QWidget]]:
    results = []
    seen = set()
    if hasattr(page, 'v4517417_grouped_items'):
        for g_key, items in page.v4517417_grouped_items.items():
            for title, w in items:
                if w and id(w) not in seen:
                    seen.add(id(w))
                    results.append((title, w))
    for tw in page.findChildren(QTabWidget):
        for i in range(tw.count()):
            if not tw.isTabVisible(i):
                continue
            child_w = tw.widget(i)
            title = tw.tabText(i)
            if child_w and 'فارغ' not in title and 'أدوات إضافية' not in title:
                if not child_w.findChildren(QTabWidget):
                    if id(child_w) not in seen:
                        seen.add(id(child_w))
                        results.append((title, child_w))
    return results

def apply_grid_dashboard_redesign(self: ToolsPage):
    if getattr(self, 'v4615_grid_applied', False):
        return
    self.v4615_grid_applied = True
    
    pages = extract_all_pages(self)
    if not pages:
        return
        
    for title, w in pages:
        w.setParent(None)
        
    old_layout = self.layout()
    if old_layout:
        QWidget().setLayout(old_layout)
        
    try: del self.tabs
    except Exception: pass
        
    main_layout = QVBoxLayout(self)
    main_layout.setContentsMargins(0, 0, 0, 0)
    main_layout.setSpacing(0)
    
    main_stack = QStackedWidget()
    main_stack.setObjectName('toolsStack')
    main_layout.addWidget(main_stack)
    
    # ----------------------------------------------------
    # Index 0: The Grid Dashboard
    # ----------------------------------------------------
    dash_scroll = QScrollArea()
    dash_scroll.setObjectName('dashboardScroll')
    dash_scroll.setWidgetResizable(True)
    
    dash_container = QWidget()
    dash_layout = QVBoxLayout(dash_container)
    dash_layout.setContentsMargins(64, 48, 64, 48)
    dash_layout.setSpacing(40)
    
    dash_header = QLabel("لوحة الإعدادات والأدوات")
    dash_header.setStyleSheet("font-size: 28px; font-weight: 900; color: #0f172a;")
    dash_layout.addWidget(dash_header)
    
    added_widgets = set()
    used_meta_keys = set()
    
    tool_widgets = [] # Store widgets to add them to stack later
    
    def _create_tool_page(icon_str, title, subtitle_str, w):
        page_container = QWidget()
        pc_layout = QVBoxLayout(page_container)
        pc_layout.setContentsMargins(0, 0, 0, 0)
        pc_layout.setSpacing(0)
        
        # Header Area
        header_widget = QWidget()
        header_widget.setStyleSheet("background: #ffffff; border-bottom: 1px solid #e2e8f0;")
        h_layout = QHBoxLayout(header_widget)
        h_layout.setContentsMargins(32, 16, 32, 16)
        h_layout.setSpacing(24)
        
        back_btn = QPushButton("🔙 رجوع للأدوات")
        back_btn.setObjectName("backBtn")
        back_btn.setCursor(Qt.PointingHandCursor)
        back_btn.clicked.connect(lambda: main_stack.setCurrentIndex(0))
        
        t_lbl = QLabel(f"{icon_str}  {title}")
        t_lbl.setStyleSheet("font-size: 22px; font-weight: 900; color: #0f172a;")
        
        h_layout.addWidget(back_btn)
        h_layout.addWidget(t_lbl)
        h_layout.addStretch()
        
        pc_layout.addWidget(header_widget)
        
        # Content Area
        scroll = QScrollArea()
        scroll.setObjectName("toolContentScroll")
        scroll.setWidgetResizable(True)
        
        inner_container = QWidget()
        ic_layout = QVBoxLayout(inner_container)
        ic_layout.setContentsMargins(32, 32, 32, 32)
        
        content_card = QFrame()
        content_card.setObjectName("toolContentCard")
        
        c_shadow = QGraphicsDropShadowEffect()
        c_shadow.setBlurRadius(30)
        c_shadow.setColor(QColor(0, 0, 0, 15))
        c_shadow.setOffset(0, 10)
        content_card.setGraphicsEffect(c_shadow)
        
        cc_layout = QVBoxLayout(content_card)
        cc_layout.setContentsMargins(24, 24, 24, 24)
        cc_layout.addWidget(w)
        w.setVisible(True)
        
        ic_layout.addWidget(content_card)
        ic_layout.addStretch()
        
        scroll.setWidget(inner_container)
        pc_layout.addWidget(scroll)
        
        return page_container

    # Build Categories
    for cat_name, cat_keywords in CATEGORIES:
        cat_pages = []
        for kw in cat_keywords:
            for title, w in pages:
                if id(w) not in added_widgets and kw in title:
                    cat_pages.append((title, w))
                    added_widgets.add(id(w))
        
        if cat_pages:
            cat_lbl = QLabel(cat_name)
            cat_lbl.setStyleSheet("font-size: 18px; font-weight: bold; color: #2563eb; margin-bottom: 8px;")
            dash_layout.addWidget(cat_lbl)
            
            grid = QGridLayout()
            grid.setSpacing(24)
            grid.setAlignment(Qt.AlignLeft | Qt.AlignTop)
            
            for i, (title, w) in enumerate(cat_pages):
                icon_str = '🧩'
                display_title = title
                subtitle_str = 'أدوات وإعدادات إضافية'
                for k, meta in TOOL_METADATA.items():
                    if k in title and k not in used_meta_keys:
                        icon_str, display_title, subtitle_str = meta
                        used_meta_keys.add(k)
                        break
                        
                page_container = _create_tool_page(icon_str, display_title, subtitle_str, w)
                tool_widgets.append(page_container)
                page_index = len(tool_widgets) # Stack index will be this + 0 (since 0 is dashboard)
                
                card = GridCard(
                    icon_str, display_title, subtitle_str,
                    click_callback=lambda idx=page_index: main_stack.setCurrentIndex(idx)
                )
                
                row = i // 4
                col = i % 4
                grid.addWidget(card, row, col)
                
            dash_layout.addLayout(grid)

    # Build remaining pages
    other_pages = [(title, w) for title, w in pages if id(w) not in added_widgets]
    if other_pages:
        cat_lbl = QLabel('🔖 أدوات إضافية أخرى')
        cat_lbl.setStyleSheet("font-size: 18px; font-weight: bold; color: #2563eb; margin-bottom: 8px;")
        dash_layout.addWidget(cat_lbl)
        
        grid = QGridLayout()
        grid.setSpacing(24)
        grid.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        
        for i, (title, w) in enumerate(other_pages):
            icon_str = '🧩'
            display_title = title
            subtitle_str = 'أدوات وإعدادات إضافية'
            for k, meta in TOOL_METADATA.items():
                if k in title and k not in used_meta_keys:
                    icon_str, display_title, subtitle_str = meta
                    used_meta_keys.add(k)
                    break
            
            page_container = _create_tool_page(icon_str, display_title, subtitle_str, w)
            tool_widgets.append(page_container)
            page_index = len(tool_widgets)
            
            card = GridCard(
                icon_str, display_title, subtitle_str,
                click_callback=lambda idx=page_index: main_stack.setCurrentIndex(idx)
            )
            
            row = i // 4
            col = i % 4
            grid.addWidget(card, row, col)
            
        dash_layout.addLayout(grid)

    dash_layout.addStretch()
    dash_scroll.setWidget(dash_container)
    
    # Add everything to stack
    main_stack.addWidget(dash_scroll) # Index 0
    for pw in tool_widgets:
        main_stack.addWidget(pw)
        
    main_stack.setCurrentIndex(0)
    self.setStyleSheet((self.styleSheet() or '') + ULTIMATE_GRID_QSS)

def _tools_init(self, service, notify, current_user=None):
    _ORIG_INIT(self, service, notify, current_user)
    apply_grid_dashboard_redesign(self)
    
def _tools_refresh(self):
    if _ORIG_REFRESH:
        _ORIG_REFRESH(self)

ToolsPage.__init__ = _tools_init
ToolsPage.refresh = _tools_refresh
