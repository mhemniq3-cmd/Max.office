from __future__ import annotations

from ui.ui_common import *
from ui.main_window_core import MainWindow

_ORIG_INIT = MainWindow.__init__
_ORIG_RESIZE = getattr(MainWindow, 'resizeEvent', None)
_ORIG_TOGGLE_FOCUS = None
try:
    # v45.17.4.9 installs Ctrl+F11 via a module-level function. Importing it is safe here
    # because this patch is loaded after v45.17.4.9 in ui_patches.__init__.
    from ui.ui_patches import v45_17_4_9_ui_productivity_tools as _v451749
    _ORIG_TOGGLE_FOCUS = getattr(_v451749, '_toggle_focus', None)
except Exception:
    _ORIG_TOGGLE_FOCUS = None


def _sidebar(window: MainWindow):
    try:
        return window.findChild(QFrame, 'sidebar')
    except Exception:
        return None


def _remove_old_top_focus_button(window: MainWindow) -> None:
    """Remove the large topbar focus button added in v45.17.4.9."""
    try:
        top = window.findChild(QFrame, 'topbar')
        if top is None:
            return
        for btn in top.findChildren(QPushButton):
            text = btn.text() or ''
            tip = btn.toolTip() or ''
            if 'تركيز' in text or 'تركيز' in tip or 'Ctrl+F11' in tip:
                btn.setVisible(False)
                btn.setParent(None)
                btn.deleteLater()
    except Exception as exc:
        log_exception(exc)


def _move_focus_arrow(window: MainWindow) -> None:
    try:
        btn = getattr(window, '_v4517410_sidebar_arrow', None)
        if btn is None:
            return
        # Floating small arrow at the upper-right of the app, outside the regular topbar flow.
        size_w, size_h = 38, 34
        margin = 10
        btn.setGeometry(max(0, window.width() - size_w - margin), 10, size_w, size_h)
        btn.raise_()
    except Exception as exc:
        log_exception(exc)


def _sync_arrow_state(window: MainWindow) -> None:
    try:
        btn = getattr(window, '_v4517410_sidebar_arrow', None)
        sidebar = _sidebar(window)
        if btn is None or sidebar is None:
            return
        hidden = sidebar.isHidden()
        btn.setText('☰' if hidden else '◀')
        btn.setToolTip('إظهار القائمة الجانبية' if hidden else 'إخفاء القائمة الجانبية')
    except Exception as exc:
        log_exception(exc)


def _toggle_sidebar(window: MainWindow) -> None:
    try:
        sidebar = _sidebar(window)
        if sidebar is None:
            return
        hidden = not sidebar.isHidden()
        sidebar.setHidden(hidden)
        _sync_arrow_state(window)
        try:
            window.notify('تم إخفاء القائمة الجانبية' if hidden else 'تم إظهار القائمة الجانبية')
        except Exception:
            pass
    except Exception as exc:
        log_exception(exc)


def _install_focus_arrow(window: MainWindow) -> None:
    try:
        if getattr(window, '_v4517410_focus_arrow_installed', False):
            _move_focus_arrow(window)
            _sync_arrow_state(window)
            return
        btn = QPushButton(window)
        btn.setObjectName('floatingSidebarToggle')
        btn.setCursor(Qt.PointingHandCursor)
        btn.setFixedSize(38, 34)
        btn.setText('◀')
        btn.setToolTip('إخفاء القائمة الجانبية')
        btn.setStyleSheet('''
            QPushButton#floatingSidebarToggle {
                background: #111827;
                color: #ffffff;
                border: 1px solid #334155;
                border-radius: 15px;
                font-size: 17px;
                font-weight: 900;
                padding: 0px;
            }
            QPushButton#floatingSidebarToggle:hover {
                background: #2563eb;
                border-color: #60a5fa;
            }
        ''')
        btn.clicked.connect(lambda: _toggle_sidebar(window))
        window._v4517410_sidebar_arrow = btn
        window._v4517410_focus_arrow_installed = True
        _move_focus_arrow(window)
        _sync_arrow_state(window)
        btn.show()
    except Exception as exc:
        log_exception(exc)


def _patch_old_shortcut_behavior() -> None:
    """Keep Ctrl+F11 working, but make it use the same simple arrow/sidebar toggle."""
    try:
        if _ORIG_TOGGLE_FOCUS is not None:
            _v451749._toggle_focus = _toggle_sidebar
    except Exception as exc:
        log_exception(exc)


def _mw_init(self, *args, **kwargs):
    _ORIG_INIT(self, *args, **kwargs)
    _remove_old_top_focus_button(self)
    _install_focus_arrow(self)
    _patch_old_shortcut_behavior()
    try:
        self.notify('تم نقل وضع التركيز إلى زر سهم صغير أعلى يمين الواجهة')
    except Exception:
        pass


def _resize_event(self, event):
    if _ORIG_RESIZE:
        _ORIG_RESIZE(self, event)
    else:
        super(MainWindow, self).resizeEvent(event)
    _move_focus_arrow(self)


MainWindow.__init__ = _mw_init
MainWindow.resizeEvent = _resize_event
