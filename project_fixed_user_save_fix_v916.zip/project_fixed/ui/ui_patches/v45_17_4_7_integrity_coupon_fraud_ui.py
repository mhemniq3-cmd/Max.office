from __future__ import annotations

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

_ORIG_INIT = ToolsPage.__init__
_ORIG_REFRESH = getattr(ToolsPage, 'refresh', None)


def _tab_exists(self, title: str) -> bool:
    try:
        return any(self.tabs.tabText(i) == title for i in range(self.tabs.count()))
    except Exception:
        return False


def _btn(text, fn=None, primary=False):
    b = QPushButton(text)
    b.setObjectName('primaryButton' if primary else 'secondaryButton')
    b.setMinimumHeight(38)
    b.setCursor(Qt.PointingHandCursor)
    if fn:
        b.clicked.connect(fn)
    return b


def _put_rows(table, rows, fields):
    table.setRowCount(len(rows))
    for r, row in enumerate(rows):
        d = dict(row) if not isinstance(row, dict) else row
        for c, field in enumerate(fields):
            table.put(r, c, d.get(field, ''))


def _build_integrity_tab(self):
    tab = QWidget(); root = QVBoxLayout(tab); root.setSpacing(10)
    note = QLabel('فحص سلامة سجل التدقيق بالتوقيع التسلسلي. أي حذف أو تعديل مباشر من قاعدة البيانات يكسر السلسلة ويظهر هنا.')
    note.setWordWrap(True); note.setObjectName('noticeBox'); root.addWidget(note)
    row = QHBoxLayout(); root.addLayout(row)
    row.addWidget(_btn('فحص سلامة سجل التدقيق', self.v451747_check_audit_chain, True))
    row.addWidget(_btn('تحديث قواعد الاحتيال من قاعدة البيانات', self.v451747_reload_fraud_rules))
    row.addStretch()
    self.v451747_integrity_result = QLabel('لم يتم الفحص بعد')
    self.v451747_integrity_result.setObjectName('noticeBox')
    self.v451747_integrity_result.setWordWrap(True)
    root.addWidget(self.v451747_integrity_result)
    return tab


def _build_coupon_perf_tab(self):
    tab = QWidget(); root = QVBoxLayout(tab); root.setSpacing(10)
    note = QLabel('تقرير أداء القسائم: إجمالي الخصومات، مبيعات القسيمة، نسبة الخصم من المبيعات، وعدد العملاء الجدد.')
    note.setWordWrap(True); note.setObjectName('noticeBox'); root.addWidget(note)
    row = QHBoxLayout(); root.addLayout(row)
    row.addWidget(_btn('تحديث تقرير القسائم', self.v451747_refresh_coupon_perf, True))
    row.addWidget(_btn('تصدير CSV', self.v451747_export_coupon_perf))
    row.addStretch()
    self.v451747_coupon_perf_table = Table(['ID','الكود','النوع','الاستخدام','إجمالي الخصم','مبيعات القسيمة','نسبة الخصم %','عملاء جدد','آخر تحديث'])
    root.addWidget(self.v451747_coupon_perf_table, 1)
    return tab


def _build_fraud_summary_tab(self):
    tab = QWidget(); root = QVBoxLayout(tab); root.setSpacing(10)
    note = QLabel('ملخصات شهرية جاهزة لتقارير الاحتيال. تستخدم بدلاً من فحص كل السجلات عند طلب فترة طويلة.')
    note.setWordWrap(True); note.setObjectName('noticeBox'); root.addWidget(note)
    row = QHBoxLayout(); root.addLayout(row)
    row.addWidget(_btn('تحديث الملخصات', self.v451747_refresh_fraud_summary, True))
    row.addStretch()
    self.v451747_fraud_summary_table = Table(['الشهر','كل التنبيهات','المفتوحة','العالية','المغلقة','آخر تحديث'])
    root.addWidget(self.v451747_fraud_summary_table, 1)
    return tab


def _init(self, service, notify, current_user=None):
    _ORIG_INIT(self, service, notify, current_user)
    try:
        if hasattr(self, 'tabs'):
            if not _tab_exists(self, 'سلامة التدقيق'):
                self.tabs.addTab(_build_integrity_tab(self), 'سلامة التدقيق')
            if not _tab_exists(self, 'أداء القسائم'):
                self.tabs.addTab(_build_coupon_perf_tab(self), 'أداء القسائم')
            if not _tab_exists(self, 'ملخصات الاحتيال'):
                self.tabs.addTab(_build_fraud_summary_tab(self), 'ملخصات الاحتيال')
            self.v451747_refresh_all()
    except Exception as exc:
        log_exception(exc)
        try:
            notify(f'تعذر تحميل أدوات v45.17.4.7: {exc}')
        except Exception:
            pass


def _refresh(self):
    if _ORIG_REFRESH:
        try:
            _ORIG_REFRESH(self)
        except Exception as exc:
            log_exception(exc)
    try:
        self.v451747_refresh_all()
    except Exception as exc:
        log_exception(exc)


def _refresh_all(self):
    self.v451747_refresh_coupon_perf()
    self.v451747_refresh_fraud_summary()


def _check_audit_chain(self):
    try:
        res = self.service.verify_audit_chain()
        if res.get('ok'):
            self.v451747_integrity_result.setText(f"✅ سجل التدقيق سليم. عدد السجلات المفحوصة: {res.get('checked')}\nآخر توقيع: {res.get('last_hash')}")
        else:
            self.v451747_integrity_result.setText(f"⚠️ يوجد تلاعب أو كسر في سلسلة التدقيق: {res.get('errors')}")
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر فحص التدقيق', str(exc))


def _reload_fraud_rules(self):
    try:
        rules = self.service.reload_fraud_rules_cache(True)
        self.notify(f'تم تحديث قواعد الاحتيال فورياً. العدد: {len(rules)}')
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر تحديث القواعد', str(exc))


def _refresh_coupon_perf(self):
    if not hasattr(self, 'v451747_coupon_perf_table'):
        return
    try:
        rows = [dict(r) for r in self.service.coupon_performance_report(True)]
        _put_rows(self.v451747_coupon_perf_table, rows, ['coupon_id','code_mask','type','used_count','total_discount','sales_total','discount_to_sales_pct','new_customers','refreshed_at'])
    except Exception as exc:
        log_exception(exc)


def _export_coupon_perf(self):
    try:
        path = self.service.export_coupon_performance_csv()
        QMessageBox.information(self, 'تصدير القسائم', f'تم التصدير:\n{path}')
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر التصدير', str(exc))


def _refresh_fraud_summary(self):
    if not hasattr(self, 'v451747_fraud_summary_table'):
        return
    try:
        rows = [dict(r) for r in self.service.fraud_report_fast()]
        _put_rows(self.v451747_fraud_summary_table, rows, ['period','total_alerts','open_alerts','high_alerts','closed_alerts','refreshed_at'])
    except Exception as exc:
        log_exception(exc)


ToolsPage.__init__ = _init
ToolsPage.refresh = _refresh
ToolsPage.v451747_refresh_all = _refresh_all
ToolsPage.v451747_check_audit_chain = _check_audit_chain
ToolsPage.v451747_reload_fraud_rules = _reload_fraud_rules
ToolsPage.v451747_refresh_coupon_perf = _refresh_coupon_perf
ToolsPage.v451747_export_coupon_perf = _export_coupon_perf
ToolsPage.v451747_refresh_fraud_summary = _refresh_fraud_summary
