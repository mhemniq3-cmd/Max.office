from __future__ import annotations

import json
from datetime import date, timedelta

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

try:
    from PySide6.QtCore import QObject, QThread, Signal, QDate
    from PySide6.QtWidgets import QDateEdit
except Exception:  # pragma: no cover
    QObject = object
    QThread = None
    Signal = None
    QDate = None
    QDateEdit = None

try:
    import ui.ui_patches.v45_17_4_14_movement_center_ui as movement_ui
except Exception:  # pragma: no cover
    movement_ui = None

_ORIG_INIT = ToolsPage.__init__
_ORIG_REFRESH = getattr(ToolsPage, 'refresh', None)

GROUPS_4 = [
    ('monitoring', '📊 لوحة الرقابة'),
    ('operations', '⚙️ إدارة العمليات'),
    ('inventory', '📦 المخزون والمستودعات'),
    ('security', '🛡️ الإعدادات والأمان'),
]


def _today_qdate():
    return QDate.currentDate() if QDate is not None else None


def _date_text(widget) -> str:
    try:
        if QDateEdit is not None and isinstance(widget, QDateEdit):
            if not widget.date().isValid():
                return ''
            return widget.date().toString('yyyy-MM-dd')
        return widget.text().strip()
    except Exception:
        return ''


def _set_date(widget, value: date | None) -> None:
    try:
        if QDateEdit is not None and isinstance(widget, QDateEdit):
            if value is None:
                widget.clear()
            else:
                widget.setDate(QDate(value.year, value.month, value.day))
        elif hasattr(widget, 'setText'):
            widget.setText(value.isoformat() if value else '')
    except Exception:
        pass


def _date_widget(placeholder: str):
    if QDateEdit is not None:
        w = QDateEdit()
        w.setCalendarPopup(True)
        w.setDisplayFormat('yyyy-MM-dd')
        w.setSpecialValueText(placeholder)
        w.setMinimumDate(QDate(2000, 1, 1))
        w.setMaximumDate(QDate(2100, 12, 31))
        w.setDate(_today_qdate())
        return w
    w = QLineEdit()
    w.setPlaceholderText(placeholder)
    return w


def _selected_movement_id(page: ToolsPage):
    table = page.v4517414_stack.currentWidget() if hasattr(page, 'v4517414_stack') else None
    if not isinstance(table, QTableWidget):
        return None
    row = table.currentRow()
    if row < 0:
        return None
    item = table.item(row, 0)
    if not item:
        return None
    try:
        return int(item.data(Qt.UserRole))
    except Exception:
        return None


def _movement_page_size(page: ToolsPage) -> int:
    try:
        return int(page.v462_page_size.currentText())
    except Exception:
        return 100


def _movement_offset(page: ToolsPage) -> int:
    try:
        return max(0, int(getattr(page, 'v462_movement_offset', 0)))
    except Exception:
        return 0


def _active_movement_mode(page: ToolsPage) -> str | None:
    if not hasattr(page, 'v4517414_tabs'):
        return None
    idx = page.v4517414_tabs.currentIndex()
    return {0: 'summary', 1: 'daily', 2: 'sensitive', 3: 'fraud'}.get(idx, 'all')


def _set_movement_status(page: ToolsPage, text: str) -> None:
    try:
        page.v462_status.setText(text)
    except Exception:
        pass


def _populate_movement_filter_options(page: ToolsPage) -> None:
    try:
        current_user = page.v462_user_filter.currentText() if isinstance(page.v462_user_filter, QComboBox) else ''
        page.v462_user_filter.blockSignals(True)
        page.v462_user_filter.clear()
        page.v462_user_filter.addItem('كل المستخدمين')
        if hasattr(page.service, 'movement_active_users'):
            page.v462_user_filter.addItems(page.service.movement_active_users())
        if current_user:
            idx = page.v462_user_filter.findText(current_user)
            if idx >= 0:
                page.v462_user_filter.setCurrentIndex(idx)
        page.v462_user_filter.blockSignals(False)
    except Exception:
        pass
    try:
        current_type = page.v462_record_type.currentText()
        page.v462_record_type.blockSignals(True)
        page.v462_record_type.clear()
        page.v462_record_type.addItem('كل الأنواع')
        defaults = ['sale', 'return', 'product', 'customer', 'settings', 'inventory', 'coupon', 'user']
        seen = set()
        for t in defaults + (page.service.movement_record_types() if hasattr(page.service, 'movement_record_types') else []):
            if t and t not in seen:
                seen.add(t)
                page.v462_record_type.addItem(t)
        idx = page.v462_record_type.findText(current_type)
        if idx >= 0:
            page.v462_record_type.setCurrentIndex(idx)
        page.v462_record_type.blockSignals(False)
    except Exception:
        pass


def _optimized_filters_v463(page: ToolsPage, mode: str) -> dict:
    user_name = ''
    try:
        if isinstance(page.v462_user_filter, QComboBox):
            user_name = page.v462_user_filter.currentText().strip()
            if user_name == 'كل المستخدمين':
                user_name = ''
        else:
            user_name = page.v462_user_filter.text().strip()
    except Exception:
        user_name = ''
    return {
        'mode': mode,
        'term': page.v4517414_search.text().strip() if hasattr(page, 'v4517414_search') else '',
        'severity': page.v4517414_severity.currentText() if hasattr(page, 'v4517414_severity') else 'الكل',
        'module': page.v4517414_module.currentText() if hasattr(page, 'v4517414_module') else 'كل الأقسام',
        'date_from': _date_text(page.v462_date_from) if hasattr(page, 'v462_date_from') else '',
        'date_to': _date_text(page.v462_date_to) if hasattr(page, 'v462_date_to') else '',
        'user_name': user_name,
        'record_type': page.v462_record_type.currentText() if hasattr(page, 'v462_record_type') else 'كل الأنواع',
        'offset': _movement_offset(page),
    }


def _set_quick_range(page: ToolsPage, days: int | None = None, month: bool = False) -> None:
    today = date.today()
    if month:
        start = today.replace(day=1)
        end = today
    elif days is None:
        start = today
        end = today
    else:
        start = today - timedelta(days=days)
        end = today
    _set_date(page.v462_date_from, start)
    _set_date(page.v462_date_to, end)
    page.v462_reset_and_refresh()


def _clear_dates(page: ToolsPage) -> None:
    if QDateEdit is not None and isinstance(page.v462_date_from, QDateEdit):
        # QDateEdit has no true null state in all Qt versions; use a wide range instead.
        page.v462_date_from.setDate(QDate(2000, 1, 1))
        page.v462_date_to.setDate(QDate.currentDate())
    else:
        page.v462_date_from.clear(); page.v462_date_to.clear()
    page.v462_reset_and_refresh()


def _filter_bar_v463(page: ToolsPage):
    wrap = QFrame(); wrap.setObjectName('surface')
    outer = QVBoxLayout(wrap); outer.setContentsMargins(10, 8, 10, 8); outer.setSpacing(8)

    first = QHBoxLayout(); first.setSpacing(8)
    page.v4517414_search = QLineEdit(); page.v4517414_search.setPlaceholderText('بحث موحد: فاتورة، منتج، زبون، مستخدم، رقم سجل، تفاصيل...')
    page.v4517414_search.setMinimumHeight(36)
    page.v4517414_severity = QComboBox(); page.v4517414_severity.setMinimumHeight(36)
    page.v4517414_severity.addItems(['الكل', 'عادي', 'مهم', 'حساس', 'خطر', 'warning'])
    page.v4517414_module = QComboBox(); page.v4517414_module.setMinimumHeight(36)
    page.v4517414_module.addItems(['كل الأقسام', 'المبيعات', 'المخزون والمنتجات', 'الزبائن والديون', 'القسائم والخصومات', 'الأمان والاحتيال', 'السجلات والصلاحيات', 'النظام'])
    refresh = QPushButton('تحديث التبويب الحالي'); refresh.setObjectName('primaryButton'); refresh.setMinimumHeight(36)
    refresh.clicked.connect(lambda: page.v4517414_refresh_center())
    sync = QPushButton('مزامنة بالخلفية'); sync.setMinimumHeight(36)
    sync.clicked.connect(lambda: page.v463_sync_background())
    mark = QPushButton('تحديد كمقروء'); mark.setMinimumHeight(36)
    mark.clicked.connect(page.v4517414_mark_selected_read)
    export = QPushButton('تصدير CSV'); export.setMinimumHeight(36)
    export.clicked.connect(page.v4517414_export_csv)
    note = QPushButton('ملاحظة مدير'); note.setMinimumHeight(36)
    note.clicked.connect(page.v4517414_add_note)
    for w in (export, note, mark, sync, refresh, page.v4517414_severity, page.v4517414_module):
        first.addWidget(w)
    first.addWidget(page.v4517414_search, 1)

    second = QHBoxLayout(); second.setSpacing(8)
    page.v462_date_from = _date_widget('من تاريخ')
    page.v462_date_to = _date_widget('إلى تاريخ')
    page.v462_user_filter = QComboBox(); page.v462_user_filter.setEditable(False)
    page.v462_record_type = QComboBox()
    page.v462_page_size = QComboBox(); page.v462_page_size.addItems(['50', '100', '200', '500']); page.v462_page_size.setCurrentText('100')
    prev_btn = QPushButton('السابق'); next_btn = QPushButton('التالي')
    page.v462_status = QLabel('لم يتم التحميل بعد')
    page.v462_status.setObjectName('noticeBox')
    prev_btn.clicked.connect(lambda: page.v462_prev_page())
    next_btn.clicked.connect(lambda: page.v462_next_page())
    for w in (page.v462_date_from, page.v462_date_to, page.v462_user_filter, page.v462_record_type, page.v462_page_size, prev_btn, next_btn):
        try: w.setMinimumHeight(34)
        except Exception: pass
    second.addWidget(next_btn); second.addWidget(prev_btn)
    second.addWidget(QLabel('عدد الصفوف:')); second.addWidget(page.v462_page_size)
    second.addWidget(QLabel('نوع السجل:')); second.addWidget(page.v462_record_type)
    second.addWidget(QLabel('المستخدم:')); second.addWidget(page.v462_user_filter)
    second.addWidget(QLabel('إلى:')); second.addWidget(page.v462_date_to)
    second.addWidget(QLabel('من:')); second.addWidget(page.v462_date_from)
    second.addWidget(page.v462_status, 1)

    third = QHBoxLayout(); third.setSpacing(8)
    today_btn = QPushButton('اليوم')
    week_btn = QPushButton('آخر أسبوع')
    month_btn = QPushButton('الشهر الحالي')
    all_btn = QPushButton('كل المدة')
    today_btn.clicked.connect(lambda: _set_quick_range(page, None))
    week_btn.clicked.connect(lambda: _set_quick_range(page, 7))
    month_btn.clicked.connect(lambda: _set_quick_range(page, month=True))
    all_btn.clicked.connect(lambda: _clear_dates(page))
    for w in (all_btn, month_btn, week_btn, today_btn):
        w.setMinimumHeight(32)
        third.addWidget(w)
    third.addStretch(1)

    outer.addLayout(first); outer.addLayout(second); outer.addLayout(third)
    for widget in (page.v4517414_search,):
        widget.returnPressed.connect(lambda: page.v462_reset_and_refresh())
    for combo in (page.v4517414_severity, page.v4517414_module, page.v462_record_type, page.v462_page_size, page.v462_user_filter):
        combo.currentTextChanged.connect(lambda *_: page.v462_reset_and_refresh())
    if QDateEdit is not None:
        page.v462_date_from.dateChanged.connect(lambda *_: page.v462_reset_and_refresh())
        page.v462_date_to.dateChanged.connect(lambda *_: page.v462_reset_and_refresh())
    _populate_movement_filter_options(page)
    return wrap


class _MovementSyncWorker(QObject):
    finished = Signal(int) if Signal is not None else None
    failed = Signal(str) if Signal is not None else None

    def __init__(self, service):
        super().__init__()
        self.service = service

    def run(self):
        try:
            if hasattr(self.service, 'sync_unified_movements_light'):
                count = self.service.sync_unified_movements_light(limit=500, days=14)
            elif hasattr(self.service, 'sync_unified_movements'):
                count = self.service.sync_unified_movements(limit=500, days=14)
            else:
                count = 0
            self.finished.emit(int(count or 0))
        except Exception as exc:
            self.failed.emit(str(exc))


def _sync_background(self: ToolsPage):
    if QThread is None or Signal is None:
        return self.v462_sync_and_refresh()
    if getattr(self, '_v463_sync_running', False):
        _set_movement_status(self, 'المزامنة تعمل حالياً في الخلفية...')
        return
    self._v463_sync_running = True
    _set_movement_status(self, 'جاري المزامنة في الخلفية دون تجميد الواجهة...')
    thread = QThread(self)
    worker = _MovementSyncWorker(self.service)
    worker.moveToThread(thread)
    thread.started.connect(worker.run)

    def ok(count):
        self._v463_sync_running = False
        _populate_movement_filter_options(self)
        self.v462_movement_offset = 0
        self.v4517414_refresh_center()
        _set_movement_status(self, f'اكتملت المزامنة في الخلفية ({count} حركة)')
        try: self.notify('تمت مزامنة سجل الحركات في الخلفية')
        except Exception: pass
        thread.quit(); worker.deleteLater(); thread.deleteLater()

    def bad(message):
        self._v463_sync_running = False
        _set_movement_status(self, 'تعذرت المزامنة الخلفية')
        QMessageBox.warning(self, 'تعذر المزامنة', message)
        thread.quit(); worker.deleteLater(); thread.deleteLater()

    worker.finished.connect(ok)
    worker.failed.connect(bad)
    self._v463_sync_thread = thread
    self._v463_sync_worker = worker
    thread.start()


def _refresh_summary(page: ToolsPage) -> None:
    summary = page.service.movement_summary() if hasattr(page.service, 'movement_summary') else {}
    cards = getattr(page, 'v4517414_cards', {})
    for key, card in cards.items():
        if key == 'top_user':
            tu = summary.get('top_user') or {}
            card.set_value(f"{tu.get('name','') or '-'} ({tu.get('c',0)})")
        elif key == 'last_fraud':
            lf = summary.get('last_fraud') or {}
            card.set_value((lf.get('action') or '-')[:28])
        else:
            card.set_value(str(summary.get(key, 0)))
    if hasattr(page, 'v4517414_summary_table'):
        rows = [
            ['حركات اليوم', summary.get('today_total', 0)],
            ['الحركات الحساسة اليوم', summary.get('sensitive_total', 0)],
            ['الخصومات اليوم', summary.get('discount_total', 0)],
            ['الحذف/التعطيل اليوم', summary.get('delete_total', 0)],
            ['المرتجعات اليوم', summary.get('return_total', 0)],
            ['الحركات غير المقروءة', summary.get('unread_total', 0)],
            ['أكثر مستخدم حركة', f"{(summary.get('top_user') or {}).get('name','-')} ({(summary.get('top_user') or {}).get('c',0)})"],
            ['آخر تنبيه احتيال', (summary.get('last_fraud') or {}).get('action', '-')],
        ]
        page.v4517414_summary_table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            page.v4517414_summary_table.put(r, 0, row[0]); page.v4517414_summary_table.put(r, 1, row[1])
    _set_movement_status(page, 'تم تحديث الملخص فقط')


def _refresh_center_v463(page: ToolsPage):
    try:
        if not hasattr(page, 'v4517414_stack'):
            return
        _populate_movement_filter_options(page)
        mode = _active_movement_mode(page)
        if mode == 'summary' or mode is None:
            _refresh_summary(page)
            return
        table = {
            'daily': getattr(page, 'v4517414_daily_table', None),
            'sensitive': getattr(page, 'v4517414_sensitive_table', None),
            'fraud': getattr(page, 'v4517414_fraud_table', None),
        }.get(mode)
        if table is None:
            return
        limit = _movement_page_size(page)
        rows = page.service.list_unified_movements(limit, **_optimized_filters_v463(page, mode)) if hasattr(page.service, 'list_unified_movements') else []
        if movement_ui is not None:
            movement_ui._fill_table(table, rows)
        shown_from = _movement_offset(page) + (1 if rows else 0)
        shown_to = _movement_offset(page) + len(rows)
        _set_movement_status(page, f'يعرض {shown_from}-{shown_to} | تحميل كسول + Caching قصير')
    except Exception as exc:
        log_exception(exc)
        try:
            QMessageBox.warning(page, 'تعذر تحديث سجل الحركات', str(exc))
        except Exception:
            pass


def _show_movement_details_v463(self: ToolsPage):
    mid = _selected_movement_id(self)
    if mid is None:
        return
    details = self.service.get_unified_movement_details(mid) if hasattr(self.service, 'get_unified_movement_details') else {}
    related = self.service.related_unified_movements(mid) if hasattr(self.service, 'related_unified_movements') else []
    dlg = QDialog(self); dlg.setWindowTitle('تفاصيل الحركة والحركات المرتبطة'); dlg.resize(860, 640)
    lay = QVBoxLayout(dlg)
    text = QTextEdit(); text.setReadOnly(True)
    payload = {'تفاصيل الحركة': details, 'الحركات المرتبطة': related}
    text.setPlainText(json.dumps(payload, ensure_ascii=False, indent=2, default=str))
    lay.addWidget(text, 1)
    buttons = QDialogButtonBox(QDialogButtonBox.Close); buttons.rejected.connect(dlg.reject); buttons.accepted.connect(dlg.accept)
    lay.addWidget(buttons)
    dlg.exec()


def _group_for_title_4(title: str) -> str:
    t = (title or '').replace('️', '')
    if any(k in t for k in ['سجل الحركات', 'سجل العمليات', 'سجل التدقيق', 'احتيال', 'تدقيق', 'سلامة', 'لوحة الرقابة']):
        return 'monitoring'
    if any(k in t for k in ['مخزون', 'المخزون', 'منتج', 'منتجات', 'جرد', 'فرع', 'فروع', 'مخزن', 'مخازن', 'مستودع', 'باركود', 'DataMatrix', 'QR', 'أسعار']):
        return 'inventory'
    if any(k in t for k in ['إعداد', 'نسخ', 'استعادة', 'أمان', 'حماية', 'مستخدم', 'صلاحيات', 'مظهر', 'ثيم', 'هوية', 'دليل', 'مساعدة', 'النظام', 'Google Drive']):
        return 'security'
    return 'operations'


_EMPTY_TOOL_TITLES = {'فارغ', 'لا توجد أدوات', 'لا توجد ادوات'}


def _is_empty_tool_placeholder(title: str, widget: QWidget | None = None) -> bool:
    text = (title or '').strip()
    if text in _EMPTY_TOOL_TITLES:
        return True
    try:
        if isinstance(widget, QLabel) and 'لا توجد' in widget.text():
            return True
    except Exception:
        pass
    return False


def _leaf_tabs_from(widget: QWidget) -> list[tuple[str, QWidget]]:
    """Extract real tool tabs from any nested grouped page.

    Older patches used several different inner QTabWidget object names
    (v4517417_inner_*, toolsInnerTabs, and v463_inner_*).  The previous
    implementation only recognized two names, so in some installations it
    rebuilt the four groups with only the placeholder "فارغ" tab.  This
    routine recursively extracts real leaf tabs from any nested QTabWidget
    and explicitly ignores empty placeholders.
    """
    leaves: list[tuple[str, QWidget]] = []
    try:
        candidates = [child for child in widget.findChildren(QTabWidget)
                      if child is not None and child is not widget]
    except Exception:
        candidates = []
    # Prefer named inner tab widgets, but fall back to any nested QTabWidget.
    named = []
    for child in candidates:
        try:
            name = child.objectName() or ''
        except Exception:
            name = ''
        if (name.startswith('v4517417_inner_') or name.startswith('v463_inner_')
                or name in ('toolsInnerTabs', 'toolsCategoryTabs')):
            named.append(child)
    for inner in named or candidates:
        while inner.count():
            title = (inner.tabText(0) or 'أداة').strip()
            child = inner.widget(0)
            inner.removeTab(0)
            if child is None or _is_empty_tool_placeholder(title, child):
                continue
            nested = _leaf_tabs_from(child)
            if nested:
                leaves.extend(nested)
            else:
                leaves.append((title, child))
        if leaves:
            break
    return leaves


def _make_group_page_4(page: ToolsPage, key: str, items: list[tuple[str, QWidget]]) -> QWidget:
    wrap = QWidget(); wrap.setObjectName(f'v463_group_{key}')
    lay = QVBoxLayout(wrap); lay.setContentsMargins(10, 10, 10, 10); lay.setSpacing(10)
    title = dict(GROUPS_4)[key]
    header = QLabel(title); header.setObjectName('sectionTitle')
    lay.addWidget(header)
    note_text = {
        'monitoring': 'مركز موحد للرقابة، سجل الحركات، سجل العمليات، التدقيق، والتنبيهات.',
        'operations': 'كل أدوات التشغيل اليومي: العمولات، الأهداف، الفواتير، الكاشير، التقارير التشغيلية والاختصارات.',
        'inventory': 'إدارة المخزون، الجرد، الفروع، المستودعات، الباركود، وأسعار المنتجات.',
        'security': 'إعدادات النظام، النسخ الاحتياطي، المستخدمون، الصلاحيات، المظهر، والمساعدة.',
    }.get(key, '')
    note = QLabel(note_text); note.setObjectName('noticeBox'); note.setWordWrap(True)
    lay.addWidget(note)
    inner = QTabWidget(); inner.setObjectName(f'v463_inner_{key}')
    inner.setDocumentMode(True); inner.setMovable(False)
    for item_title, item_widget in sorted(items, key=lambda x: x[0]):
        inner.addTab(item_widget, item_title)
    if not items:
        empty = QLabel('لا توجد أدوات في هذه المجموعة حالياً.'); empty.setObjectName('noticeBox'); empty.setAlignment(Qt.AlignCenter)
        inner.addTab(empty, 'فارغ')
    lay.addWidget(inner, 1)
    return wrap


def _has_real_v463_group_items(page: ToolsPage) -> bool:
    try:
        if page.tabs.count() != len(GROUPS_4):
            return False
        expected = {title for _, title in GROUPS_4}
        actual = {page.tabs.tabText(i) for i in range(page.tabs.count())}
        if actual != expected:
            return False
        real_count = 0
        for i in range(page.tabs.count()):
            group = page.tabs.widget(i)
            for inner in group.findChildren(QTabWidget):
                name = inner.objectName() or ''
                if not name.startswith('v463_inner_'):
                    continue
                for j in range(inner.count()):
                    if not _is_empty_tool_placeholder(inner.tabText(j), inner.widget(j)):
                        real_count += 1
        return real_count > 0
    except Exception:
        return False


def _restore_tabs(tab_widget: QTabWidget, items: list[tuple[str, QWidget]]) -> None:
    try:
        while tab_widget.count():
            tab_widget.removeTab(0)
        for title, widget in items:
            if widget is not None:
                tab_widget.addTab(widget, title or 'أداة')
    except Exception as exc:
        log_exception(exc)


def _regroup_tools_4(page: ToolsPage):
    if not hasattr(page, 'tabs') or not isinstance(page.tabs, QTabWidget):
        return
    try:
        # Do not destructively rebuild a healthy four-group layout on every refresh.
        if _has_real_v463_group_items(page):
            return

        top_items: list[tuple[str, QWidget]] = []
        leaves: list[tuple[str, QWidget]] = []
        while page.tabs.count():
            title = (page.tabs.tabText(0) or 'أداة').strip()
            widget = page.tabs.widget(0)
            page.tabs.removeTab(0)
            if widget is None or _is_empty_tool_placeholder(title, widget):
                continue
            top_items.append((title, widget))
            extracted = _leaf_tabs_from(widget)
            if extracted:
                leaves.extend(extracted)
            else:
                leaves.append((title, widget))

        # Safety net: never replace the tools page with four empty groups.
        real_leaves = [(t, w) for t, w in leaves if w is not None and not _is_empty_tool_placeholder(t, w)]
        if not real_leaves:
            _restore_tabs(page.tabs, top_items)
            page._v463_grouped_tools = False
            try:
                page.notify('تم إلغاء تجميع الأدوات مؤقتاً لأن النظام لم يجد أدوات فعلية داخل المجموعات.')
            except Exception:
                pass
            return

        buckets = {key: [] for key, _ in GROUPS_4}
        seen = set()
        for title, widget in real_leaves:
            clean = title.strip() or 'أداة'
            sig = (clean, id(widget))
            if sig in seen:
                continue
            seen.add(sig)
            buckets[_group_for_title_4(clean)].append((clean, widget))
        page.tabs.setDocumentMode(True)
        page.tabs.setMovable(False)
        for key, group_title in GROUPS_4:
            page.tabs.addTab(_make_group_page_4(page, key, buckets.get(key, [])), group_title)
        page._v463_grouped_tools = True
    except Exception as exc:
        log_exception(exc)


def _enhance_movement_center_v463(page: ToolsPage) -> None:
    page.v462_movement_offset = getattr(page, 'v462_movement_offset', 0)
    for table_name in ('v4517414_daily_table', 'v4517414_sensitive_table', 'v4517414_fraud_table'):
        table = getattr(page, table_name, None)
        if isinstance(table, QTableWidget) and not getattr(table, '_v463_double_click', False):
            table.itemDoubleClicked.connect(lambda *_: page.v462_show_movement_details())
            table._v463_double_click = True
    if hasattr(page, 'v4517414_tabs') and not getattr(page.v4517414_tabs, '_v463_lazy_bound', False):
        page.v4517414_tabs.currentChanged.connect(lambda *_: page.v462_reset_and_refresh())
        page.v4517414_tabs._v463_lazy_bound = True


def _reset_and_refresh(self: ToolsPage):
    self.v462_movement_offset = 0
    self.v4517414_refresh_center()


def _next_page(self: ToolsPage):
    self.v462_movement_offset = _movement_offset(self) + _movement_page_size(self)
    self.v4517414_refresh_center()


def _prev_page(self: ToolsPage):
    self.v462_movement_offset = max(0, _movement_offset(self) - _movement_page_size(self))
    self.v4517414_refresh_center()


def _tools_init(self: ToolsPage, service, notify, current_user=None):
    if movement_ui is not None:
        movement_ui._make_filter_bar = _filter_bar_v463
        movement_ui._current_filters = _optimized_filters_v463
        movement_ui._refresh_center = _refresh_center_v463
    _ORIG_INIT(self, service, notify, current_user)
    _enhance_movement_center_v463(self)
    _regroup_tools_4(self)


def _tools_refresh(self: ToolsPage):
    if _ORIG_REFRESH:
        _ORIG_REFRESH(self)
    _enhance_movement_center_v463(self)
    _regroup_tools_4(self)


if movement_ui is not None:
    movement_ui._make_filter_bar = _filter_bar_v463
    movement_ui._current_filters = _optimized_filters_v463
    movement_ui._refresh_center = _refresh_center_v463

ToolsPage.__init__ = _tools_init
ToolsPage.refresh = _tools_refresh
ToolsPage.v4517414_refresh_center = _refresh_center_v463
ToolsPage.v462_reset_and_refresh = _reset_and_refresh
ToolsPage.v462_next_page = _next_page
ToolsPage.v462_prev_page = _prev_page
ToolsPage.v462_show_movement_details = _show_movement_details_v463
ToolsPage.v463_sync_background = _sync_background
