from __future__ import annotations

from PySide6.QtWidgets import QLabel, QMessageBox, QPushButton, QTabWidget, QVBoxLayout, QWidget, QHBoxLayout, QCheckBox, QLineEdit, QInputDialog
from ui.ui_common import Table, PERM_LABELS
from ui.pages.tools_page import ToolsPage
from ui.pages.smart_assistant_page import SmartAssistantPage
from database import money
from services.error_logger import log_exception

V34_PERMS = {
    'can_view_cost': 'رؤية سعر التكلفة',
    'can_view_profit': 'رؤية الربح',
    'can_price_edit': 'تعديل السعر',
    'can_discount': 'تعديل الخصم',
    'can_register_return': 'تسجيل مرتجع',
    'can_cancel_invoice': 'إلغاء فاتورة',
    'can_reprint_invoice': 'إعادة طباعة فاتورة',
    'can_repay_debt': 'تسديد دين',
    'can_adjust_product_qty': 'تعديل كمية منتج',
    'can_disable_product': 'حذف/تعطيل منتج',
    'can_reports': 'رؤية التقارير',
    'can_view_activity_logs': 'رؤية سجل العمليات',
    'can_manage_offers': 'إدارة العروض',
    'can_users': 'إدارة المستخدمين',
    'can_settings': 'تعديل الإعدادات',
    'can_backup': 'فتح النسخ الاحتياطي',
    'can_restore': 'استرجاع نسخة احتياطية',
}
PERM_LABELS.update(V34_PERMS)

# Make the existing promotions status tab more professional and add stopped/statistics tabs.
_orig_t_promos = getattr(ToolsPage, 'add_promo_status_tab', None)
_orig_t_refresh_promos = getattr(ToolsPage, 'v33_refresh_promos', None)


def _v34_add_promo_status_tab(self):
    tab = QWidget(); lay = QVBoxLayout(tab)
    note = QLabel('لوحة احترافية للعروض: النشطة، القادمة، المنتهية، المتوقفة، وإحصائيات استخدام العرض والخصم الناتج عنه.')
    note.setWordWrap(True); note.setObjectName('noticeBox')
    top = QHBoxLayout()
    refresh = QPushButton('تحديث العروض'); refresh.clicked.connect(self.v34_refresh_promos)
    stats = QPushButton('تحديث إحصائيات الاستخدام'); stats.setObjectName('primaryButton'); stats.clicked.connect(self.v34_refresh_offer_stats)
    top.addWidget(refresh); top.addWidget(stats); top.addStretch()
    self.promo_tables = {}
    self.promos_tabs = QTabWidget()
    specs = [
        ('active', 'العروض النشطة'),
        ('upcoming', 'العروض القادمة'),
        ('expired', 'العروض المنتهية'),
        ('stopped', 'العروض المتوقفة'),
    ]
    for key, label in specs:
        table = Table(['ID','العرض','النطاق','النوع','القيمة','من','إلى','الحالة','كوبون','مدير فقط'])
        self.promo_tables[key] = table
        self.promos_tabs.addTab(table, label)
    self.offer_stats_table = Table(['العرض','النطاق','مرات الاستخدام','فواتير','الكمية','إجمالي خصم العرض','ربح الفواتير','أكثر المنتجات استفادة'])
    self.promos_tabs.addTab(self.offer_stats_table, 'إحصائيات الاستخدام')
    lay.addWidget(note); lay.addLayout(top); lay.addWidget(self.promos_tabs, 1)
    self.tabs.addTab(tab, 'لوحة العروض')
    self.v34_refresh_promos(); self.v34_refresh_offer_stats()


def _v34_refresh_promos(self):
    try:
        data = self.service.promotions_by_status()
        for key, rows in data.items():
            table = self.promo_tables.get(key)
            if table is None:
                continue
            table.setRowCount(len(rows))
            for r, p in enumerate(rows):
                typ = p.get('promo_type','')
                if typ == 'buy_x_get_y':
                    value = f"اشتر {p.get('buy_qty',0)} واحصل على {p.get('free_qty',0)}"
                elif typ == 'percent':
                    value = f"{p.get('discount_value',0)}%"
                elif typ == 'amount':
                    value = money(p.get('discount_value',0))
                elif typ == 'fixed_price':
                    value = f"سعر ثابت {money(p.get('discount_value',0))}"
                else:
                    value = str(p.get('discount_value',''))
                vals = [
                    p.get('id',''), p.get('name',''), p.get('scope_label') or p.get('scope_type',''), typ,
                    value, p.get('start_date') or '-', p.get('end_date') or '-',
                    'نشط' if p.get('active') else 'متوقف', p.get('coupon_code') or '-', 'نعم' if p.get('manager_only') else 'لا'
                ]
                for c, v in enumerate(vals):
                    table.put(r, c, v, p.get('id') if c == 0 else None)
    except Exception as exc:
        log_exception(exc)
        QMessageBox.warning(self, 'تعذر تحديث العروض', self.service.user_message(exc) if hasattr(self.service,'user_message') else str(exc))


def _v34_refresh_offer_stats(self):
    try:
        rows = self.service.promotion_usage_stats()
        self.offer_stats_table.setRowCount(len(rows))
        for r, item in enumerate(rows):
            products = item.get('products') or []
            top = '، '.join([f"{p.get('product_name','')} ({int(p.get('qty') or 0)})" for p in products[:3]]) or '-'
            vals = [
                item.get('name') or '-', item.get('scope_label') or '-',
                item.get('used_lines') or 0, item.get('used_invoices') or 0, int(item.get('total_qty') or 0),
                money(item.get('total_discount') or 0), money(item.get('total_profit') or 0), top
            ]
            for c, v in enumerate(vals):
                self.offer_stats_table.put(r, c, v)
    except Exception as exc:
        log_exception(exc)
        QMessageBox.warning(self, 'تعذر تحديث الإحصائيات', self.service.user_message(exc) if hasattr(self.service,'user_message') else str(exc))

ToolsPage.add_promo_status_tab = _v34_add_promo_status_tab
ToolsPage.v34_refresh_promos = _v34_refresh_promos
ToolsPage.v34_refresh_offer_stats = _v34_refresh_offer_stats
# Keep old name callable because V33 init calls v33_refresh_promos in some flows.
ToolsPage.v33_refresh_promos = _v34_refresh_promos

# V33.4 carry-over: risk review must not list zero-balance debt rows.
def _row_value(row, key, default=''):
    try:
        if hasattr(row, 'get'):
            return row.get(key, default)
        return row[key]
    except Exception:
        return default


def _smart_risk_review_no_zero_debts(self):
    try:
        alerts = []
        try:
            alerts.extend(self.service.ai_anomaly_alerts())
        except Exception as exc:
            log_exception(exc)
        try:
            stock = self.service.ai_stock_forecast()[:8]
        except Exception as exc:
            log_exception(exc); stock = []
        try:
            all_debts = self.service.debt_rows()
            debts = []
            for d in all_debts:
                try:
                    if float(_row_value(d, 'balance', 0) or 0) > 0.0001:
                        debts.append(d)
                except Exception:
                    pass
            debts = debts[:8]
        except Exception as exc:
            log_exception(exc); debts = []
        text = ['مراجعة ذكية مختصرة للمخاطر:']
        text += ['• ' + a for a in alerts[:12]] if alerts else ['• لا توجد مؤشرات خطرة واضحة حالياً حسب الفحص المحلي.']
        if stock:
            text.append('\nمنتجات تحتاج متابعة:')
            for r in stock[:6]:
                try: qty = float(_row_value(r, 'quantity', 0) or 0)
                except Exception: qty = 0.0
                text.append(f"• {_row_value(r,'name','منتج')} | المتوفر {qty:.0f} | الحالة: {_row_value(r,'risk','-')} | مقترح شراء: {_row_value(r,'suggested',0)}")
        if debts:
            text.append('\nديون تحتاج متابعة:')
            for d in debts[:6]:
                text.append(f"• {_row_value(d,'name','زبون')} | الرصيد: {money(_row_value(d,'balance',0))} | الاستحقاق: {_row_value(d,'due_date','') or '-'}")
        self.set_output('\n'.join(text))
    except Exception as exc:
        log_exception(exc)
        QMessageBox.warning(self, 'تعذر التحليل', 'تعذر إنشاء مراجعة المخاطر الذكية. تم تسجيل التفاصيل في logs/error.log')

SmartAssistantPage.v31_risk_review = _smart_risk_review_no_zero_debts
