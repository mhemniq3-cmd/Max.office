from __future__ import annotations

from ui.ui_common import *
from PySide6.QtCore import QDateTime
from ui.main_window_core import MainWindow
from ui.dialogs.access_denied import AccessDeniedDialog
from ui.pages.sales_page import SalesPage, _safe_get
from ui.pages.customers_page import CustomersPage
from ui.pages.tools_page import ToolsPage

_ORIG_SALES_INIT = SalesPage.__init__
_ORIG_SALES_SCAN = SalesPage.scan_barcode_add
_ORIG_CUSTOMERS_INIT = CustomersPage.__init__
_ORIG_CUSTOMERS_LOAD = CustomersPage.load_selected
# v45.17.4.13: do NOT override MainWindow.show_page or refresh_current.
# The v45.17.4.12 optimization caused all main buttons to stop responding on some machines.
_ORIG_MW_SHOW_PAGE = getattr(MainWindow, 'show_page', None)
_ORIG_MW_REFRESH = getattr(MainWindow, 'refresh_current', None)
_ORIG_TOOLS_REFRESH = getattr(ToolsPage, 'v4517411_refresh_movement_log', None)


def _v4517412_money(value) -> str:
    try:
        return money(value)
    except Exception:
        return f'{value}'


# ---------------------------------------------------------------------------
# 1) Barcode scanner: add product to cart automatically.
# ---------------------------------------------------------------------------

def _v4517412_install_barcode_auto_add(self: SalesPage) -> None:
    try:
        if getattr(self, '_v4517412_barcode_auto_installed', False):
            return
        self._v4517412_barcode_busy = False
        self._v4517412_last_barcode = ''
        self._v4517412_last_barcode_time = 0
        self._v4517412_barcode_timer = QTimer(self)
        self._v4517412_barcode_timer.setSingleShot(True)
        self._v4517412_barcode_timer.timeout.connect(lambda: self.v4517412_scan_barcode_auto(False))
        self.barcode_scan.textChanged.connect(lambda _txt: self._v4517412_barcode_timer.start(220))
        self.barcode_scan.setPlaceholderText('امسح الباركود فقط: سيضاف المنتج للسلة تلقائياً...')
        self.barcode_scan.setMinimumHeight(max(self.barcode_scan.minimumHeight(), 42))
        self.barcode_scan.setClearButtonEnabled(True)
        self.barcode_scan.setFocus()
        self._v4517412_barcode_auto_installed = True
    except Exception as exc:
        log_exception(exc)


def _v4517412_sales_init(self: SalesPage, service, notify, current_user=None):
    _ORIG_SALES_INIT(self, service, notify, current_user)
    _v4517412_install_barcode_auto_add(self)


def _v4517412_scan_barcode_auto(self: SalesPage, from_enter: bool = True):
    code = self.barcode_scan.text().strip() if hasattr(self, 'barcode_scan') else ''
    if not code:
        return
    # Most USB/Bluetooth scanners end with Enter, but some only type quickly.
    # This guard prevents double add when Enter and textChanged timer fire together.
    now_ms = QDateTime.currentMSecsSinceEpoch()
    if getattr(self, '_v4517412_barcode_busy', False):
        return
    if code == getattr(self, '_v4517412_last_barcode', '') and now_ms - int(getattr(self, '_v4517412_last_barcode_time', 0)) < 900:
        self.barcode_scan.clear()
        return
    self._v4517412_barcode_busy = True
    self._v4517412_last_barcode = code
    self._v4517412_last_barcode_time = now_ms
    try:
        p = self.service.get_product_by_barcode(code)
        if not p:
            if from_enter:
                QMessageBox.warning(self, 'باركود غير موجود', f'لا يوجد منتج بهذا الباركود:\n{code}')
            self.search.setText(code)
            self.barcode_scan.selectAll()
            return
        # A scan = one unit. Repeated scans increase quantity one by one.
        self.add_product_to_active_tab(p, 1, from_barcode=True)
        self.barcode_scan.setFocus()
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر إضافة الباركود', str(exc))
        self.barcode_scan.selectAll()
    finally:
        QTimer.singleShot(120, lambda: setattr(self, '_v4517412_barcode_busy', False))


# ---------------------------------------------------------------------------
# 2) Customers & debts: cleaner professional panel.
# ---------------------------------------------------------------------------

def _v4517412_install_customer_ui(self: CustomersPage) -> None:
    try:
        if getattr(self, '_v4517412_customer_ui_installed', False):
            return
        self._v4517412_all_rows = []
        self._v4517412_filtered_rows = []

        parent = self.table.parentWidget()
        layout = parent.layout() if parent else None
        if layout is None:
            return

        self.v4517412_summary = QFrame()
        self.v4517412_summary.setObjectName('noticeBox')
        cards = QGridLayout(self.v4517412_summary)
        cards.setContentsMargins(10, 10, 10, 10)
        cards.setHorizontalSpacing(8)
        cards.setVerticalSpacing(8)
        self.v4517412_card_customers = QLabel('الزبائن\n0')
        self.v4517412_card_debtors = QLabel('عليهم دين\n0')
        self.v4517412_card_balance = QLabel('إجمالي الدين\n0 د.ع')
        self.v4517412_card_payments = QLabel('الدفعات\n0 د.ع')
        for i, card in enumerate([self.v4517412_card_customers, self.v4517412_card_debtors, self.v4517412_card_balance, self.v4517412_card_payments]):
            card.setAlignment(Qt.AlignCenter)
            card.setMinimumHeight(58)
            card.setStyleSheet('QLabel{background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:8px;font-weight:700;}')
            cards.addWidget(card, i // 2, i % 2)

        search_row = QHBoxLayout()
        self.v4517412_customer_search = QLineEdit()
        self.v4517412_customer_search.setPlaceholderText('بحث في الزبائن، الهاتف، الرصيد...')
        self.v4517412_customer_search.setMinimumHeight(40)
        self.v4517412_customer_search.setClearButtonEnabled(True)
        self.v4517412_customer_search.textChanged.connect(self.v4517412_apply_customer_filter)
        self.v4517412_customer_filter = QComboBox()
        self.v4517412_customer_filter.setMinimumHeight(40)
        self.v4517412_customer_filter.addItems(['كل الزبائن', 'عليهم دين', 'بدون دين', 'تجاوزوا حد الدين'])
        self.v4517412_customer_filter.currentTextChanged.connect(lambda *_: self.v4517412_apply_customer_filter())
        search_row.addWidget(self.v4517412_customer_filter)
        search_row.addWidget(self.v4517412_customer_search, 1)

        self.v4517412_selected_info = QLabel('اختر زبوناً لعرض ملخص سريع عن الدين والدفعات.')
        self.v4517412_selected_info.setObjectName('noticeBox')
        self.v4517412_selected_info.setWordWrap(True)

        # Insert after title, before table.
        layout.insertWidget(1, self.v4517412_summary)
        layout.insertLayout(2, search_row)
        layout.insertWidget(3, self.v4517412_selected_info)
        self.table.setAlternatingRowColors(True)
        self.table.setMinimumHeight(max(self.table.minimumHeight(), 420))
        try:
            self.table.horizontalHeader().setStretchLastSection(True)
        except Exception:
            pass
        self._v4517412_customer_ui_installed = True
    except Exception as exc:
        log_exception(exc)


def _v4517412_customers_init(self: CustomersPage, service, notify):
    _ORIG_CUSTOMERS_INIT(self, service, notify)
    _v4517412_install_customer_ui(self)
    self.refresh()


def _v4517412_apply_customer_filter(self: CustomersPage):
    try:
        term = self.v4517412_customer_search.text().strip().lower() if hasattr(self, 'v4517412_customer_search') else ''
        mode = self.v4517412_customer_filter.currentText() if hasattr(self, 'v4517412_customer_filter') else 'كل الزبائن'
        rows = list(getattr(self, '_v4517412_all_rows', self.rows or []))
        filtered = []
        for row in rows:
            balance = float(row.get('balance') or 0)
            credit_limit = float(row.get('credit_limit') or 0)
            if mode == 'عليهم دين' and balance <= 0:
                continue
            if mode == 'بدون دين' and balance > 0:
                continue
            if mode == 'تجاوزوا حد الدين' and not (credit_limit > 0 and balance > credit_limit):
                continue
            hay = ' '.join(str(row.get(k) or '') for k in ('name', 'phone', 'credit_sales', 'payments', 'balance')).lower()
            if term and term not in hay:
                continue
            filtered.append(row)
        self.rows = filtered
        self._v4517412_filtered_rows = filtered
        self.table.setRowCount(len(filtered))
        for r, row in enumerate(filtered):
            vals = [row.get('name',''), row.get('phone') or '', _v4517412_money(row.get('credit_sales',0)), _v4517412_money(row.get('payments',0)), _v4517412_money(row.get('balance',0))]
            for c, v in enumerate(vals):
                self.table.put(r, c, v, row.get('id') if c == 0 else None)
            if float(row.get('balance') or 0) > float(row.get('credit_limit') or 0) > 0:
                for c in range(self.table.columnCount()):
                    it = self.table.item(r, c)
                    if it:
                        it.setBackground(Qt.GlobalColor.yellow)
        self.v4517412_update_summary(rows)
    except Exception as exc:
        log_exception(exc)


def _v4517412_update_summary(self: CustomersPage, rows: list[dict]):
    try:
        total_credit = sum(float(r.get('credit_sales') or 0) for r in rows)
        total_payments = sum(float(r.get('payments') or 0) for r in rows)
        total_balance = sum(float(r.get('balance') or 0) for r in rows)
        debtors = len([r for r in rows if float(r.get('balance') or 0) > 0])
        self.v4517412_card_customers.setText(f'الزبائن\n{len(rows)}')
        self.v4517412_card_debtors.setText(f'عليهم دين\n{debtors}')
        self.v4517412_card_balance.setText(f'إجمالي الدين\n{_v4517412_money(total_balance)}')
        self.v4517412_card_payments.setText(f'الدفعات\n{_v4517412_money(total_payments)}')
    except Exception:
        pass


def _v4517412_customers_refresh(self: CustomersPage):
    try:
        if not getattr(self, '_v4517412_customer_ui_installed', False):
            _v4517412_install_customer_ui(self)
        rows = list(self.service.debt_rows())
        self._v4517412_all_rows = rows
        self.v4517412_apply_customer_filter()
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر تحديث الزبائن والديون', str(exc))


def _v4517412_customers_load_selected(self: CustomersPage):
    _ORIG_CUSTOMERS_LOAD(self)
    try:
        row = self.table.currentRow()
        if row < 0 or row >= len(self.rows):
            return
        c = self.rows[row]
        balance = float(c.get('balance') or 0)
        credit_limit = float(c.get('credit_limit') or 0)
        status = 'ضمن الحد' if not credit_limit or balance <= credit_limit else 'متجاوز حد الدين'
        self.v4517412_selected_info.setText(
            f"الزبون المحدد: {c.get('name','')}\n"
            f"الهاتف: {c.get('phone') or '-'} | الرصيد: {_v4517412_money(balance)} | حد الدين: {_v4517412_money(credit_limit)} | الحالة: {status}"
        )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 3) Faster navigation: show page first, refresh shortly after.
# ---------------------------------------------------------------------------

def _v4517412_show_page(self: MainWindow, key: str):
    titles = {
        'dashboard': 'الرئيسية', 'sales': 'البيع السريع', 'products': 'المنتجات والمخزون',
        'touch_pos': 'كاشير لمس', 'customers': 'الزبائن والديون', 'suppliers': 'الموردون والمشتريات',
        'returns': 'المرتجعات والمواد الراجعة', 'reports': 'التقارير', 'users': 'المستخدمون والصلاحيات',
        'ai': 'المساعد الذكي', 'tools': 'الأدوات'
    }
    try:
        if not self.user_can(key):
            self.notify('محاولة دخول لقسم مقفل: هذا الزر يحتاج صلاحية')
            AccessDeniedDialog(titles.get(key, 'هذه الصفحة'), self.current_user, self).exec()
            return
        page = self.pages.get(key)
        if page is None:
            return
        self.stack.setCurrentWidget(page)
        self.title.setText(titles.get(key, key))
        for k, b in self.buttons.items():
            b.setProperty('active', k == key)
            b.style().unpolish(b); b.style().polish(b)
        self.notify('جاري فتح الصفحة...')
        # Display immediately, then refresh. This removes perceived lag from heavy pages.
        QTimer.singleShot(20, self.refresh_current)
    except Exception as exc:
        log_exception(exc)
        try:
            _ORIG_MW_SHOW_PAGE(self, key)
        except Exception:
            pass


def _v4517412_refresh_current(self: MainWindow):
    try:
        page = self.stack.currentWidget()
        page_key = ''
        for k, p in self.pages.items():
            if p is page:
                page_key = k
                break
        now_ms = QDateTime.currentMSecsSinceEpoch()
        last_key = getattr(self, '_v4517412_last_refresh_key', '')
        last_ms = int(getattr(self, '_v4517412_last_refresh_ms', 0))
        # Avoid double refresh when clicking several buttons quickly.
        if page_key == last_key and now_ms - last_ms < 900:
            return
        self._v4517412_last_refresh_key = page_key
        self._v4517412_last_refresh_ms = now_ms
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            if hasattr(page, 'refresh'):
                page.refresh()  # type: ignore[attr-defined]
            if isinstance(page, SalesPage):
                page.refresh_all()
        finally:
            QApplication.restoreOverrideCursor()
        self.notify('تم التحديث')
    except Exception as exc:
        QApplication.restoreOverrideCursor()
        log_exception(exc)
        self.notify('تعذر تحديث الصفحة بالكامل، راجع سجل الأخطاء')


# ---------------------------------------------------------------------------
# 4) Movement log UI: clearer title + use de-duplicated service rows.
# ---------------------------------------------------------------------------

def _v4517412_refresh_movement_log(self: ToolsPage):
    if _ORIG_TOOLS_REFRESH:
        _ORIG_TOOLS_REFRESH(self)
    try:
        if hasattr(self, 'logs_table'):
            self.logs_table.setToolTip('تم تحسين هذا السجل لإخفاء التكرار الناتج من تسجيل التطبيق + Triggers قاعدة البيانات.')
        if hasattr(self, 'v4517411_movement_search'):
            self.v4517411_movement_search.setPlaceholderText('بحث بدون تكرار: مستخدم، عملية، جدول، رقم سجل...')
    except Exception:
        pass


SalesPage.__init__ = _v4517412_sales_init
SalesPage.scan_barcode_add = lambda self: self.v4517412_scan_barcode_auto(True)
SalesPage.v4517412_scan_barcode_auto = _v4517412_scan_barcode_auto
CustomersPage.__init__ = _v4517412_customers_init
CustomersPage.refresh = _v4517412_customers_refresh
CustomersPage.v4517412_apply_customer_filter = _v4517412_apply_customer_filter
CustomersPage.v4517412_update_summary = _v4517412_update_summary
CustomersPage.load_selected = _v4517412_customers_load_selected
# MainWindow.show_page and refresh_current intentionally left unchanged in v45.17.4.13.
ToolsPage.v4517411_refresh_movement_log = _v4517412_refresh_movement_log
