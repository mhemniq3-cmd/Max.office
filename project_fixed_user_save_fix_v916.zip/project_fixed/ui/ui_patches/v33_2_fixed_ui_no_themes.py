from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QLabel, QPushButton, QWidget

from services.error_logger import log_exception
from ui.main_window_core import MainWindow


def _v332_cleanup_window(self):
    """Remove theme switching UI and clean header/brand labels after all previous patches."""
    try:
        # Remove/hide the old theme button created by V28. The feature is disabled in V33.2.
        btn = getattr(self, 'theme_button', None)
        if btn is not None:
            try:
                btn.setMenu(None)
            except Exception:
                pass
            btn.setText('')
            btn.setToolTip('')
            btn.setVisible(False)
            btn.setEnabled(False)
            btn.setFixedSize(0, 0)
            btn.setObjectName('themeButtonDisabled')
    except Exception as exc:
        log_exception(exc)
    try:
        # Sidebar logo: only this text should remain.
        for lab in self.findChildren(QLabel):
            name = lab.objectName()
            if name == 'brandMark':
                lab.setText('نظام ماكس للمبيعات')
                lab.setAlignment(Qt.AlignCenter)
                lab.setWordWrap(True)
            elif name == 'brandSub':
                lab.setText('')
                lab.setVisible(False)
            elif name == 'sidebarHint':
                lab.setText('النظام التجاري لإدارة البيع والمخزون')
            elif name == 'topSubtitle':
                text = lab.text() or ''
                if 'V28' in text or 'V32' in text or 'SQLite' in text or 'Widgets' in text:
                    lab.setText('إدارة البيع، المخزون، الزبائن، التقارير، والنسخ الاحتياطي')
        # Legacy single QLabel brand fallback.
        for lab in self.findChildren(QLabel):
            if lab.objectName() == 'brand' and hasattr(lab, 'setText'):
                lab.setText('نظام ماكس للمبيعات')
    except Exception as exc:
        log_exception(exc)


_orig_build_v332 = MainWindow.build

def _v332_build(self):
    _orig_build_v332(self)
    _v332_cleanup_window(self)


def _v332_no_theme_toggle(self):
    try:
        self.notify('تم إلغاء خاصية تغيير الثيمات. النظام يستخدم مظهرًا ثابتًا ومنسقًا.')
    except Exception:
        pass


MainWindow.build = _v332_build
MainWindow.v28_toggle_theme = _v332_no_theme_toggle
MainWindow.v332_cleanup_window = _v332_cleanup_window

# Compatibility markers for final check:
# V33.2 no selectable themes themeButtonDisabled نظام ماكس للمبيعات style_classic_fixed.qss QComboBox QAbstractItemView
