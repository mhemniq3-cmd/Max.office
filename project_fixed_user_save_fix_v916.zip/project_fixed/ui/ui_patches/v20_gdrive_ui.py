from __future__ import annotations

from pathlib import Path
import html
import os

from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.theme_manager import apply_theme as theme_apply, current_theme_key as theme_current_key, set_theme_key as theme_set_key, theme_label as theme_display_label, theme_path as theme_qss_path
from ui.main_window_core import *
import ui.ui_patches.v11_sales_safety as _prev_v11_sales_safety
globals().update({k: v for k, v in vars(_prev_v11_sales_safety).items() if not k.startswith('__')})

def _tools_load_google_drive_settings_v20(self):
    cfg = self.service.load_google_drive_backup_settings() if hasattr(self.service, 'load_google_drive_backup_settings') else self.service.get_settings()
    if hasattr(self, 'gdrive_enabled'):
        self.gdrive_enabled.setChecked(str(cfg.get('google_drive_backup_enabled','0')) in ('1','true','True','نعم','yes','on'))
        self.gdrive_path.setText(str(cfg.get('google_drive_backup_path','') or ''))
        self.gdrive_status.setText(str(cfg.get('last_google_drive_backup_status','') or ''))


def _tools_choose_google_drive_folder_v20(self):
    folder = QFileDialog.getExistingDirectory(self, 'اختيار مجلد Google Drive')
    if folder:
        self.gdrive_path.setText(folder)
        # Save immediately so the choice remains after closing the program.
        self.save_google_drive_settings(show_message=False)
        self.notify('تم اختيار وحفظ مجلد Google Drive')


def _tools_save_google_drive_settings_v20(self, show_message=True):
    path = self.gdrive_path.text().strip() if hasattr(self, 'gdrive_path') else ''
    enabled = bool(self.gdrive_enabled.isChecked()) if hasattr(self, 'gdrive_enabled') else False
    if hasattr(self.service, 'save_google_drive_backup_settings'):
        self.service.save_google_drive_backup_settings(enabled, path, self.current_user.get('id') if self.current_user else None)
    else:
        self.service.save_settings({
            'google_drive_backup_enabled': '1' if enabled else '0',
            'google_drive_backup_path': path,
        }, self.current_user.get('id') if self.current_user else None)
    self.load_google_drive_settings()
    self.notify('تم حفظ إعدادات Google Drive')
    if show_message:
        QMessageBox.information(self, 'تم', 'تم حفظ إعدادات النسخ إلى Google Drive')


def _tools_test_google_drive_folder_v20(self):
    path = self.gdrive_path.text().strip() if hasattr(self, 'gdrive_path') else ''
    # Save the current visible value first, then test the same value directly.
    self.save_google_drive_settings(show_message=False)
    if hasattr(self.service, 'test_google_drive_backup_path'):
        ok, msg = self.service.test_google_drive_backup_path(path)
    else:
        ok, msg = self.service.test_google_drive_backup()
    self.gdrive_status.setText(msg)
    QMessageBox.information(self if ok else self, 'نتيجة الاختبار' if ok else 'خطأ في اختبار Google Drive', msg)

ToolsPage.load_google_drive_settings = _tools_load_google_drive_settings_v20
ToolsPage.choose_google_drive_folder = _tools_choose_google_drive_folder_v20
ToolsPage.save_google_drive_settings = _tools_save_google_drive_settings_v20
ToolsPage.test_google_drive_folder = _tools_test_google_drive_folder_v20

# ================================================================
# V21 BACKUP & BARCODE UI RESTRUCTURE
# Clear separation between local backup, Google Drive backup, restore,
# and barcode labels. Uses the V21 service methods as a single source.
# ================================================================

import os as _v21_os
import subprocess as _v21_subprocess


