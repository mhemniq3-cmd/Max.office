from __future__ import annotations

from pathlib import Path
import html
import os

from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.theme_manager import apply_theme as theme_apply, current_theme_key as theme_current_key, set_theme_key as theme_set_key, theme_label as theme_display_label, theme_path as theme_qss_path
from ui.main_window_core import *
import ui.ui_patches.v11_sales_safety as _prev_v11_sales_safety
globals().update({k: v for k, v in vars(_prev_v11_sales_safety).items() if not k.startswith('__')})
import ui.ui_patches.v20_gdrive_ui as _prev_v20_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v20_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v21_backup_ui as _prev_v21_backup_ui
globals().update({k: v for k, v in vars(_prev_v21_backup_ui).items() if not k.startswith('__')})
import ui.ui_patches.v22_gdrive_ui as _prev_v22_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v22_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v23_tools_reports as _prev_v23_tools_reports
globals().update({k: v for k, v in vars(_prev_v23_tools_reports).items() if not k.startswith('__')})

def _v25_sales_refresh_products(self):
    self.product_rows = self.service.list_products_for_sale(self.search.text()) if hasattr(self.service, 'list_products_for_sale') else self.service.list_products(self.search.text())
    self.products.setRowCount(len(self.product_rows))
    for r, p in enumerate(self.product_rows):
        self.products.put(r, 0, p['name'], p['id']); self.products.put(r, 1, money(p['sale_price']))
        self.products.put(r, 2, p['quantity']); self.products.put(r, 3, p['category'] or '')


def _v25_sales_scan_barcode_add(self):
    code = self.barcode_scan.text().strip()
    if not code:
        return
    p = self.service.get_product_by_barcode(code)
    if not p:
        QMessageBox.warning(self, 'باركود غير موجود', f'لا يوجد منتج بهذا الباركود:\n{code}')
        self.search.setText(code); self.barcode_scan.selectAll(); return
    qty = self.qty.value()
    if p['quantity'] < qty:
        QMessageBox.warning(self, 'مخزون غير كاف', f"المتوفر من {p['name']} هو {p['quantity']}")
        self.barcode_scan.selectAll(); return
    for item in self.cart:
        if item['product_id'] == p['id']:
            if p['quantity'] < item['quantity'] + qty:
                QMessageBox.warning(self, 'مخزون غير كاف', 'الكمية المطلوبة أكبر من المخزون')
                self.barcode_scan.selectAll(); return
            item['quantity'] += qty; self.refresh_cart(); self.barcode_scan.clear(); self.notify(f"تمت إضافة {p['name']} بالباركود"); return
    self.cart.append({'product_id': p['id'], 'product_name': p['name'], 'quantity': qty, 'unit_price': float(p['sale_price']), 'commission_percent': float(p.get('commission_percent', 0) or 0)})
    self.refresh_cart(); self.barcode_scan.clear(); self.notify(f"تمت إضافة {p['name']} بالباركود")


def _v25_sales_add_selected_product(self):
    row = self.products.currentRow()
    if row < 0 or row >= len(self.product_rows):
        return
    p = self.product_rows[row]
    qty = self.qty.value()
    if p['quantity'] < qty:
        QMessageBox.warning(self, 'مخزون غير كاف', f"المتوفر من {p['name']} هو {p['quantity']}"); return
    for item in self.cart:
        if item['product_id'] == p['id']:
            if p['quantity'] < item['quantity'] + qty:
                QMessageBox.warning(self, 'مخزون غير كاف', 'الكمية المطلوبة أكبر من المخزون'); return
            item['quantity'] += qty; self.refresh_cart(); return
    self.cart.append({'product_id': p['id'], 'product_name': p['name'], 'quantity': qty, 'unit_price': float(p['sale_price']), 'commission_percent': float(p.get('commission_percent', 0) or 0)})
    self.refresh_cart()


# Disabled: SalesPage uses tabbed architecture, qty/cart are in SaleInvoiceTab
# SalesPage.refresh_products = _v25_sales_refresh_products
# SalesPage.scan_barcode_add = _v25_sales_scan_barcode_add
# SalesPage.add_selected_product = _v25_sales_add_selected_product


# Touch POS product cards also use the public sale view so cost stays private.
def _v25_touch_refresh_products(self):
    cats = ['كل التصنيفات'] + sorted({(p['category'] or 'بدون صنف') for p in (self.service.list_products_for_sale('') if hasattr(self.service, 'list_products_for_sale') else self.service.list_products(''))})
    current = self.category.currentText() if hasattr(self, 'category') else ''
    self.category.blockSignals(True); self.category.clear(); self.category.addItems(cats); self.category.setCurrentText(current if current in cats else 'كل التصنيفات'); self.category.blockSignals(False)
    rows = self.service.list_products_for_sale(self.search.text()) if hasattr(self.service, 'list_products_for_sale') else self.service.list_products(self.search.text())
    cat = self.category.currentText()
    if cat and cat != 'كل التصنيفات':
        rows = [p for p in rows if (p['category'] or 'بدون صنف') == cat]
    self.products = rows
    # Reuse the existing card builder logic where available.
    if hasattr(self, 'grid'):
        while self.grid.count():
            item = self.grid.takeAt(0)
            w = item.widget()
            if w: w.deleteLater()
        for idx, p in enumerate(rows):
            btn = QPushButton(f"{p['name']}\n{money(p['sale_price'])}\nالمتوفر: {p['quantity']}")
            btn.setMinimumHeight(92); btn.setObjectName('productCard'); btn.clicked.connect(lambda checked=False, prod=p: self.add_product(prod))
            self.grid.addWidget(btn, idx // 3, idx % 3)


def _v25_touch_add_product(self, p):
    if p['quantity'] <= 0:
        QMessageBox.warning(self, 'نفاد المخزون', 'هذا المنتج غير متوفر'); return
    for item in self.cart:
        if item['product_id'] == p['id']:
            if p['quantity'] < item['quantity'] + 1:
                QMessageBox.warning(self, 'مخزون غير كاف', 'الكمية المطلوبة أكبر من المخزون'); return
            item['quantity'] += 1; self.refresh_cart(); return
    self.cart.append({'product_id': p['id'], 'product_name': p['name'], 'quantity': 1, 'unit_price': float(p['sale_price']), 'commission_percent': float(p.get('commission_percent', 0) or 0)})
    self.refresh_cart()


try:
    TouchPOSPage.refresh_products = _v25_touch_refresh_products
    TouchPOSPage.add_product = _v25_touch_add_product
except Exception as exc:
    log_exception(exc)


# Lazy MainWindow build: restricted pages are not instantiated until an allowed
# user opens them. This prevents pages such as UsersPage from calling protected
# service methods during cashier login.
def _v25_mainwindow_build(self):
    root = QWidget(); self.setCentralWidget(root)
    main = QHBoxLayout(root); main.setContentsMargins(0, 0, 0, 0); main.setSpacing(0)
    sidebar = QFrame(); sidebar.setObjectName('sidebar'); sidebar.setFixedWidth(230)
    s_l = QVBoxLayout(sidebar); s_l.setContentsMargins(16, 18, 16, 18); s_l.setSpacing(8)
    brand = QLabel('✦ MAX SALES ✦\nماكس للمبيعات')
    brand.setObjectName('brand'); brand.setAlignment(Qt.AlignCenter); s_l.addWidget(brand)
    user_name = (self.current_user['full_name'] or self.current_user['username']) if self.current_user else 'بدون مستخدم'
    user_role = self.current_user['role'] if self.current_user and 'role' in self.current_user.keys() else 'بدون دور'
    user_label = QLabel(f'👤 {user_name}\n🛡 {user_role}')
    user_label.setObjectName('userBadge'); user_label.setAlignment(Qt.AlignCenter); s_l.addWidget(user_label)
    hint_label = QLabel('الأقسام المقفلة لن تُفتح إلا بصلاحية مناسبة')
    hint_label.setObjectName('sidebarHint'); hint_label.setAlignment(Qt.AlignCenter); s_l.addWidget(hint_label)
    nav_items = [
        ('dashboard', '🏠 الرئيسية'), ('sales', '🛒 البيع'), ('touch_pos', '🖥 كاشير لمس'), ('products', '📦 المنتجات'),
        ('customers', '👥 الزبائن والديون'), ('suppliers', '🚚 الموردون'), ('returns', '↩ المرتجعات'), ('reports', '📊 التقارير'),
        ('users', '🔐 المستخدمون'), ('ai', '🤖 المساعد الذكي'), ('tools', '⚙ الأدوات'),
    ]
    for key, text in nav_items:
        btn = QPushButton(text); btn.setObjectName('navButton'); btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(lambda checked=False, k=key: self.show_page(k))
        allowed = self.user_can(key)
        btn.setProperty('locked', not allowed)
        btn.setToolTip('لا تملك صلاحية فتح هذا القسم' if not allowed else 'فتح الصفحة')
        if not allowed and '🔒' not in text:
            btn.setText(f'🔒 {text}')
        self.buttons[key] = btn
        s_l.addWidget(btn)
    s_l.addStretch()
    logout_btn = QPushButton('🚪 تسجيل الخروج')
    logout_btn.setObjectName('dangerButton'); logout_btn.setCursor(Qt.PointingHandCursor); logout_btn.clicked.connect(self.logout)
    s_l.addWidget(logout_btn)

    body = QFrame(); body.setObjectName('body')
    b_l = QVBoxLayout(body); b_l.setContentsMargins(16, 14, 16, 8); b_l.setSpacing(12)
    top = QFrame(); top.setObjectName('topbar')
    t_l = QHBoxLayout(top)
    self.title = QLabel(''); self.title.setObjectName('topTitle')
    self.clock = QLabel(''); self.clock.setObjectName('clock')
    refresh = QPushButton('⟳ تحديث'); refresh.setObjectName('primaryButton'); refresh.setCursor(Qt.PointingHandCursor); refresh.clicked.connect(self.refresh_current)
    self.alert_btn = QPushButton('🔔 الإشعارات'); self.alert_btn.setObjectName('alertButton'); self.alert_btn.setCursor(Qt.PointingHandCursor); self.alert_btn.clicked.connect(self.show_alerts_dialog)
    t_l.addWidget(self.clock); t_l.addWidget(refresh); t_l.addWidget(self.alert_btn); t_l.addStretch(); t_l.addWidget(self.title)
    self.stack = QStackedWidget(); self.status = QLabel('جاهز'); self.status.setObjectName('status')
    b_l.addWidget(top); b_l.addWidget(self.stack, 1); b_l.addWidget(self.status)
    self.page_factories = {
        'dashboard': lambda: DashboardPage(self.service, self.current_user),
        'sales': lambda: SalesPage(self.service, self.notify, self.current_user),
        'touch_pos': lambda: TouchPOSPage(self.service, self.notify, self.current_user),
        'products': lambda: ProductsPage(self.service, self.notify, self.current_user),
        'customers': lambda: CustomersPage(self.service, self.notify),
        'suppliers': lambda: SuppliersPage(self.service, self.notify, self.current_user),
        'returns': lambda: ReturnsPage(self.service, self.notify, self.current_user),
        'reports': lambda: ReportsPage(self.service, self.notify),
        'users': lambda: UsersPage(self.service, self.notify),
        'ai': lambda: SmartAssistantPage(self.service, self.notify, self.current_user),
        'tools': lambda: ToolsPage(self.service, self.notify, self.current_user),
    }
    self.pages = {}
    main.addWidget(sidebar); main.addWidget(body, 1)


def _v25_mainwindow_ensure_page(self, key: str):
    if key in self.pages:
        return self.pages[key]
    factory = getattr(self, 'page_factories', {}).get(key)
    if not factory:
        raise KeyError(key)
    page = factory()
    self.pages[key] = page
    self.stack.addWidget(page)
    return page


def _v25_mainwindow_show_page(self, key: str):
    titles = {'dashboard': 'الرئيسية', 'sales': 'البيع السريع', 'products': 'المنتجات والمخزون', 'touch_pos': 'كاشير لمس', 'customers': 'الزبائن والديون', 'suppliers': 'الموردون والمشتريات', 'returns': 'المرتجعات والمواد الراجعة', 'reports': 'التقارير', 'users': 'المستخدمون والصلاحيات', 'ai': 'المساعد الذكي', 'tools': 'الأدوات'}
    if not self.user_can(key):
        self.notify('محاولة دخول لقسم مقفل: لا تملك الصلاحية المناسبة')
        AccessDeniedDialog(titles.get(key, 'هذه الصفحة'), self.current_user, self).exec(); return
    try:
        page = self._v25_ensure_page(key)
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر فتح الصفحة', str(exc)); return
    self.stack.setCurrentWidget(page); self.title.setText(titles[key])
    for k, b in self.buttons.items():
        b.setProperty('active', k == key); b.style().unpolish(b); b.style().polish(b)
    self.refresh_current()


def _v25_mainwindow_refresh_current(self):
    page = self.stack.currentWidget()
    if not page:
        return
    try:
        if hasattr(page, 'refresh'):
            page.refresh()  # type: ignore[attr-defined]
        if isinstance(page, SalesPage):
            page.refresh_all()
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر التحديث', str(exc)); return
    self.notify('تم التحديث')


def _v25_mainwindow_close_event(self, event):
    try:
        if hasattr(self.service, 'backup_on_close_if_enabled'):
            self.service.backup_on_close_if_enabled()
    except Exception as exc:
        log_exception(exc)
    try:
        self.service.db.close()
    except Exception as exc:
        log_exception(exc)
    event.accept()


MainWindow.build = _v25_mainwindow_build
MainWindow._v25_ensure_page = _v25_mainwindow_ensure_page
MainWindow.show_page = _v25_mainwindow_show_page
MainWindow.refresh_current = _v25_mainwindow_refresh_current
MainWindow.closeEvent = _v25_mainwindow_close_event

# V25.2: Correct TouchPOS patch for its QTableWidget card layout.
def _v252_touch_refresh_people(self):
    self.employee.clear(); emp_id = None
    if self.current_user:
        try:
            emp_id, name = self.service.ensure_employee_for_user(self.current_user)
            if emp_id:
                self.employee.addItem(f'المستخدم الحالي: {name}', emp_id)
        except Exception as exc:
            log_exception(exc)
    for e in self.service.list_employees():
        if emp_id and e['id'] == emp_id:
            continue
        self.employee.addItem(e['name'], e['id'])
    self.customer.clear()
    for c in self.service.list_customers():
        self.customer.addItem(c['name'], c['id'])
    rows = self.service.list_products_for_sale('') if hasattr(self.service, 'list_products_for_sale') else self.service.list_products('')
    cats = ['كل التصنيفات'] + sorted({(p['category'] or 'بدون صنف') for p in rows})
    cur = self.category.currentText()
    self.category.blockSignals(True); self.category.clear(); self.category.addItems(cats); self.category.setCurrentText(cur if cur in cats else cats[0]); self.category.blockSignals(False)


def _v252_touch_refresh_products(self):
    rows = self.service.list_products_for_sale(self.search.text()) if hasattr(self.service, 'list_products_for_sale') else self.service.list_products(self.search.text())
    cat = self.category.currentText()
    if cat and cat != 'كل التصنيفات':
        rows = [p for p in rows if (p['category'] or 'بدون صنف') == cat]
    self.product_rows = rows
    cols = 4
    self.cards.setColumnCount(cols); self.cards.setRowCount((len(rows)+cols-1)//cols)
    for r in range(self.cards.rowCount()):
        self.cards.setRowHeight(r, 95)
        for c in range(cols):
            self.cards.setColumnWidth(c, 190); self.cards.setItem(r, c, QTableWidgetItem(''))
    for i, p in enumerate(rows):
        item = QTableWidgetItem(f"{p['name']}\n{money(p['sale_price'])}\nالمخزون: {p['quantity']}")
        item.setData(Qt.UserRole, i); item.setTextAlignment(Qt.AlignCenter); self.cards.setItem(i//cols, i%cols, item)


def _v252_touch_add_card(self, row, col):
    item = self.cards.item(row, col)
    if not item or item.data(Qt.UserRole) is None:
        return
    p = self.product_rows[item.data(Qt.UserRole)]
    if p['quantity'] <= 0:
        QMessageBox.warning(self, 'نفاد', 'هذا المنتج نافد'); return
    for it in self.cart:
        if it['product_id'] == p['id']:
            if p['quantity'] < it['quantity'] + 1:
                QMessageBox.warning(self, 'مخزون غير كاف', 'الكمية المطلوبة أكبر من المخزون'); return
            it['quantity'] += 1; self.refresh_cart(); return
    self.cart.append({'product_id': p['id'], 'product_name': p['name'], 'quantity': 1, 'unit_price': float(p['sale_price']), 'commission_percent': float(p.get('commission_percent', 0) or 0)})
    self.refresh_cart()

try:
    TouchPOSPage.refresh_people = _v252_touch_refresh_people
    TouchPOSPage.refresh_products = _v252_touch_refresh_products
    TouchPOSPage.add_card = _v252_touch_add_card
except Exception as exc:
    log_exception(exc)

# ---------------------------------------------------------------------------
# V26 UI TOOLS REPAIR
# Keep the Tools page usable even if one optional management widget cannot be
# refreshed because of a missing permission or an empty optional subsystem.
# ---------------------------------------------------------------------------

_orig_tools_refresh_v26 = ToolsPage.refresh

