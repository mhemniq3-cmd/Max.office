from __future__ import annotations

from pathlib import Path
import html
import os

from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.theme_manager import apply_theme as theme_apply, current_theme_key as theme_current_key, set_theme_key as theme_set_key, theme_label as theme_display_label, theme_path as theme_qss_path
from ui.main_window_core import *
import ui.ui_patches.v11_sales_safety as _prev_v11_sales_safety
globals().update({k: v for k, v in vars(_prev_v11_sales_safety).items() if not k.startswith('__')})
import ui.ui_patches.v20_gdrive_ui as _prev_v20_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v20_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v21_backup_ui as _prev_v21_backup_ui
globals().update({k: v for k, v in vars(_prev_v21_backup_ui).items() if not k.startswith('__')})
import ui.ui_patches.v22_gdrive_ui as _prev_v22_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v22_gdrive_ui).items() if not k.startswith('__')})

def _v23_html_direct_print(self, html_path: Path):
    if QPrinter is None:
        QMessageBox.warning(self, 'الطباعة غير متاحة', 'مكتبة الطباعة غير متاحة في هذه البيئة. تم إنشاء ملف HTML بدلاً من الطباعة المباشرة.')
        return False
    path = Path(html_path)
    if not path.exists():
        QMessageBox.warning(self, 'ملف غير موجود', 'تعذر العثور على ملف الطباعة.')
        return False
    html_text = path.read_text(encoding='utf-8')
    doc = QTextDocument(); doc.setHtml(html_text)
    printer = QPrinter(QPrinter.HighResolution)
    st = self.service.get_settings() if hasattr(self, 'service') else {}
    printer_name = st.get('printer_name', '')
    if printer_name and printer_name != 'الطابعة الافتراضية في Windows':
        try: printer.setPrinterName(printer_name)
        except Exception as exc:
            log_exception(exc)
    try:
        doc.print_(printer)
        QMessageBox.information(self, 'تم', f'تم إرسال المستند للطابعة:\n{printer_name or "الطابعة الافتراضية"}')
        return True
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر الطباعة', str(exc))
        return False


def _v23_build_direct_print_tab(self):
    tab = QWidget(); layout = QVBoxLayout(tab)
    title = QLabel('🖨 الطباعة المباشرة الاحترافية')
    title.setObjectName('miniTitle')
    note = QLabel('اختر الطابعة الافتراضية من إعدادات الشركة. هذه الصفحة تطبع المستندات مباشرة أو تنشئ ملف HTML عند تعذر الطباعة.')
    note.setObjectName('noticeBox'); note.setWordWrap(True)
    form = QFormLayout()
    self.v23_print_invoice = QLineEdit(); self.v23_print_invoice.setPlaceholderText('رقم فاتورة البيع مثل INV أو MAX...')
    self.v23_print_return = QLineEdit(); self.v23_print_return.setPlaceholderText('رقم المرتجع مثل RET...')
    self.v23_print_payment = QSpinBox(); self.v23_print_payment.setMaximum(999999999)
    self.v23_print_purchase = QLineEdit(); self.v23_print_purchase.setPlaceholderText('رقم فاتورة الشراء مثل PUR...')
    self.v23_print_date = QLineEdit(); self.v23_print_date.setPlaceholderText('YYYY-MM-DD للتقرير اليومي')
    self.v23_paper_size = QComboBox(); self.v23_paper_size.addItems(['80mm', '58mm', 'A4'])
    form.addRow('حجم الورق', self.v23_paper_size)
    form.addRow('فاتورة بيع', self.v23_print_invoice)
    form.addRow('وصل مرتجع', self.v23_print_return)
    form.addRow('رقم وصل قبض', self.v23_print_payment)
    form.addRow('فاتورة شراء', self.v23_print_purchase)
    form.addRow('تاريخ التقرير اليومي', self.v23_print_date)
    btns = QGridLayout()
    b1=QPushButton('طباعة فاتورة البيع'); b1.setObjectName('primaryButton'); b1.clicked.connect(self.v23_print_invoice_now)
    b2=QPushButton('طباعة وصل المرتجع'); b2.setObjectName('primaryButton'); b2.clicked.connect(self.v23_print_return_now)
    b3=QPushButton('طباعة وصل قبض'); b3.setObjectName('primaryButton'); b3.clicked.connect(self.v23_print_payment_now)
    b4=QPushButton('طباعة فاتورة شراء'); b4.setObjectName('primaryButton'); b4.clicked.connect(self.v23_print_purchase_now)
    b5=QPushButton('طباعة التقرير اليومي'); b5.setObjectName('successButton'); b5.clicked.connect(self.v23_print_daily_now)
    btns.addWidget(b1,0,0); btns.addWidget(b2,0,1); btns.addWidget(b3,1,0); btns.addWidget(b4,1,1); btns.addWidget(b5,2,0,1,2)
    layout.addWidget(title); layout.addWidget(note); layout.addLayout(form); layout.addLayout(btns); layout.addStretch()
    self.tabs.addTab(tab, 'الطباعة المباشرة')


def _v23_print_invoice_now(self):
    inv = self.v23_print_invoice.text().strip()
    if not inv: QMessageBox.warning(self,'تنبيه','اكتب رقم الفاتورة'); return
    try: path = self.service.print_invoice_html(inv)
    except Exception as exc: QMessageBox.warning(self,'تعذر الطباعة',str(exc)); return
    _v23_html_direct_print(self, path)

def _v23_print_return_now(self):
    no = self.v23_print_return.text().strip()
    if not no: QMessageBox.warning(self,'تنبيه','اكتب رقم المرتجع'); return
    try: path = self.service.print_return_html(no)
    except Exception as exc: QMessageBox.warning(self,'تعذر الطباعة',str(exc)); return
    _v23_html_direct_print(self, path)

def _v23_print_payment_now(self):
    pid = self.v23_print_payment.value()
    if pid <= 0: QMessageBox.warning(self,'تنبيه','اكتب رقم وصل القبض'); return
    try: path = self.service.print_payment_receipt_html(pid)
    except Exception as exc: QMessageBox.warning(self,'تعذر الطباعة',str(exc)); return
    _v23_html_direct_print(self, path)

def _v23_print_purchase_now(self):
    no = self.v23_print_purchase.text().strip()
    if not no: QMessageBox.warning(self,'تنبيه','اكتب رقم فاتورة الشراء'); return
    try: path = self.service.print_purchase_html(no)
    except Exception as exc: QMessageBox.warning(self,'تعذر الطباعة',str(exc)); return
    _v23_html_direct_print(self, path)

def _v23_print_daily_now(self):
    d = self.v23_print_date.text().strip()
    try: path = self.service.print_daily_report_html(d)
    except Exception as exc: QMessageBox.warning(self,'تعذر الطباعة',str(exc)); return
    _v23_html_direct_print(self, path)


def _v23_build_expenses_tab(self):
    tab=QWidget(); layout=QVBoxLayout(tab)
    title=QLabel('💸 المصاريف وصافي الربح'); title.setObjectName('miniTitle')
    form=QGridLayout()
    self.expense_type=QLineEdit(); self.expense_type.setPlaceholderText('إيجار، كهرباء، رواتب، نقل...')
    self.expense_amount=QDoubleSpinBox(); self.expense_amount.setMaximum(999999999999); self.expense_amount.setDecimals(0)
    self.expense_date=QLineEdit(); self.expense_date.setPlaceholderText('YYYY-MM-DD')
    self.expense_note=QLineEdit(); self.expense_note.setPlaceholderText('ملاحظة اختيارية')
    form.addWidget(QLabel('نوع المصروف'),0,0); form.addWidget(self.expense_type,0,1)
    form.addWidget(QLabel('المبلغ'),0,2); form.addWidget(self.expense_amount,0,3)
    form.addWidget(QLabel('التاريخ'),1,0); form.addWidget(self.expense_date,1,1)
    form.addWidget(QLabel('الملاحظة'),1,2); form.addWidget(self.expense_note,1,3)
    save=QPushButton('حفظ مصروف'); save.setObjectName('successButton'); save.clicked.connect(self.v23_save_expense)
    refresh=QPushButton('تحديث التقرير'); refresh.setObjectName('primaryButton'); refresh.clicked.connect(self.v23_refresh_expenses)
    pdf=QPushButton('تصدير PDF'); pdf.clicked.connect(self.v23_export_expenses_pdf)
    btns=QHBoxLayout(); btns.addWidget(save); btns.addWidget(refresh); btns.addWidget(pdf); btns.addStretch()
    self.expenses_table=Table(['التاريخ','النوع','المبلغ','المستخدم','الملاحظة'])
    self.expenses_summary=QLabel('') ; self.expenses_summary.setObjectName('noticeBox')
    layout.addWidget(title); layout.addLayout(form); layout.addLayout(btns); layout.addWidget(self.expenses_summary); layout.addWidget(self.expenses_table,1)
    self.tabs.addTab(tab,'المصاريف والأرباح')


def _v23_save_expense(self):
    try:
        uid = self.current_user.get('id') if self.current_user else None
        self.service.save_expense(self.expense_type.text(), self.expense_amount.value(), self.expense_date.text(), self.expense_note.text(), uid)
    except Exception as exc:
        QMessageBox.warning(self,'تعذر حفظ المصروف',str(exc)); return
    self.expense_type.clear(); self.expense_amount.setValue(0); self.expense_note.clear(); self.v23_refresh_expenses(); self.notify('تم حفظ المصروف')


def _v23_refresh_expenses(self):
    rows=self.service.list_expenses(limit=500)
    self.expenses_table.setRowCount(len(rows))
    for r,x in enumerate(rows):
        vals=[x['expense_date'], x['expense_type'], money(x['amount']), x['user_name'] or '', x['note'] or '']
        for c,v in enumerate(vals): self.expenses_table.put(r,c,v)
    p=self.service.profit_summary()
    self.expenses_summary.setText(f"المبيعات الصافية: {money(p['net_sales'])} | إجمالي المصاريف: {money(p['expenses'])} | صافي الربح بعد المصاريف: {money(p['net_profit'])}")


def _v23_export_expenses_pdf(self):
    rows=[]
    for r in range(self.expenses_table.rowCount()): rows.append([self.expenses_table.item(r,c).text() if self.expenses_table.item(r,c) else '' for c in range(self.expenses_table.columnCount())])
    path=rows_to_pdf('تقرير المصاريف', ['التاريخ','النوع','المبلغ','المستخدم','الملاحظة'], rows, 'expenses_report')
    QMessageBox.information(self,'تم',f'تم إنشاء التقرير:\n{path}')


def _v23_build_cashier_tab(self):
    tab=QWidget(); layout=QVBoxLayout(tab)
    title=QLabel('💰 تقرير صندوق الكاشير'); title.setObjectName('miniTitle')
    top=QHBoxLayout(); self.cashier_date=QLineEdit(); self.cashier_date.setPlaceholderText('YYYY-MM-DD أو اتركه لتاريخ اليوم')
    run=QPushButton('عرض تقرير الصندوق'); run.setObjectName('primaryButton'); run.clicked.connect(self.v23_refresh_cashier)
    pdf=QPushButton('تصدير PDF'); pdf.clicked.connect(self.v23_export_cashier_pdf)
    top.addWidget(QLabel('التاريخ')); top.addWidget(self.cashier_date); top.addWidget(run); top.addWidget(pdf); top.addStretch()
    self.cashier_table=Table(['البند','القيمة'])
    layout.addWidget(title); layout.addLayout(top); layout.addWidget(self.cashier_table,1)
    self.tabs.addTab(tab,'صندوق الكاشير')


def _v23_refresh_cashier(self):
    data=self.service.cashier_report(self.cashier_date.text())
    rows=[('مبيعات نقدية', money(data['cash_sales'])),('بيع آجل', money(data['credit_sales'])),('دفعات زبائن', money(data['customer_payments'])),('مرتجعات نقدية', money(data['cash_returns'])),('صافي الصندوق', money(data['expected_cash'])),('عدد الفواتير', data['invoices']),('عدد المرتجعات', data['returns_count'])]
    self.cashier_table.setRowCount(len(rows))
    for r,(a,b) in enumerate(rows): self.cashier_table.put(r,0,a); self.cashier_table.put(r,1,b)


def _v23_export_cashier_pdf(self):
    self.v23_refresh_cashier(); rows=[]
    for r in range(self.cashier_table.rowCount()): rows.append([self.cashier_table.item(r,c).text() if self.cashier_table.item(r,c) else '' for c in range(2)])
    path=rows_to_pdf('تقرير صندوق الكاشير', ['البند','القيمة'], rows, 'cashier_report')
    QMessageBox.information(self,'تم',f'تم إنشاء التقرير:\n{path}')


def _v23_build_health_tab(self):
    tab=QWidget(); layout=QVBoxLayout(tab)
    title=QLabel('🩺 فحص سلامة النظام'); title.setObjectName('miniTitle')
    note=QLabel('يفحص الفواتير، المخزون، الباركودات، الديون، العمولات، الخصومات، والنسخ الاحتياطي.')
    note.setObjectName('noticeBox'); note.setWordWrap(True)
    btn=QPushButton('فحص سلامة النظام الآن'); btn.setObjectName('dangerButton'); btn.clicked.connect(self.v23_run_health)
    self.health_table=Table(['النوع','الفحص','التفاصيل'])
    layout.addWidget(title); layout.addWidget(note); layout.addWidget(btn); layout.addWidget(self.health_table,1)
    self.tabs.addTab(tab,'فحص النظام')


def _v23_run_health(self):
    rows=self.service.system_health_check()
    self.health_table.setRowCount(len(rows))
    for r,x in enumerate(rows):
        self.health_table.put(r,0,x['level']); self.health_table.put(r,1,x['item']); self.health_table.put(r,2,x['details'])
    self.notify('تم فحص سلامة النظام')


def _v23_build_advanced_settings_tab(self):
    tab=QWidget(); layout=QVBoxLayout(tab); form=QFormLayout()
    st=self.service.get_settings()
    self.set_max_keep=QSpinBox(); self.set_max_keep.setRange(1,60); self.set_max_keep.setValue(int(st.get('max_backup_keep','7') or 7))
    self.set_open_backup=QCheckBox('إنشاء نسخة تلقائية عند فتح البرنامج'); self.set_open_backup.setChecked(str(st.get('auto_backup_on_open','1')) in ('1','true','True','نعم'))
    self.set_close_backup=QCheckBox('إنشاء نسخة تلقائية عند إغلاق البرنامج'); self.set_close_backup.setChecked(str(st.get('auto_backup_on_close','1')) in ('1','true','True','نعم'))
    self.set_cashier_limit=QDoubleSpinBox(); self.set_cashier_limit.setMaximum(100); self.set_cashier_limit.setValue(float(st.get('max_discount_cashier_percent','5') or 5))
    self.set_sales_limit=QDoubleSpinBox(); self.set_sales_limit.setMaximum(100); self.set_sales_limit.setValue(float(st.get('max_discount_sales_percent','10') or 10))
    form.addRow('عدد النسخ المحفوظة', self.set_max_keep)
    form.addRow('', self.set_open_backup)
    form.addRow('', self.set_close_backup)
    form.addRow('حد خصم الكاشير %', self.set_cashier_limit)
    form.addRow('حد خصم موظف المبيعات %', self.set_sales_limit)
    save=QPushButton('حفظ الإعدادات المتقدمة'); save.setObjectName('successButton'); save.clicked.connect(self.v23_save_advanced_settings)
    layout.addLayout(form); layout.addWidget(save); layout.addStretch(); self.tabs.addTab(tab,'إعدادات متقدمة')


def _v23_save_advanced_settings(self):
    self.service.save_settings({'max_backup_keep':self.set_max_keep.value(),'auto_backup_on_open':'1' if self.set_open_backup.isChecked() else '0','auto_backup_on_close':'1' if self.set_close_backup.isChecked() else '0','max_discount_cashier_percent':self.set_cashier_limit.value(),'max_discount_sales_percent':self.set_sales_limit.value()})
    self.notify('تم حفظ الإعدادات المتقدمة')


def _v23_build_help_tab(self):
    tab=QWidget(); layout=QVBoxLayout(tab)
    title=QLabel('❔ المساعدة ودليل الاستخدام'); title.setObjectName('miniTitle')
    txt=QTextEdit(); txt.setReadOnly(True); txt.setHtml('''<div dir="rtl" style="font-family:Tahoma; font-size:14px">
    <h2>دليل سريع لنظام ماكس للمبيعات</h2>
    <h3>كيف أضيف منتج؟</h3><p>افتح المنتجات، امسح الباركود أو اكتب البيانات، أدخل السعر والكمية ثم اضغط حفظ المنتج.</p>
    <h3>كيف أبيع؟</h3><p>افتح البيع أو كاشير اللمس، ابحث بالاسم أو امسح الباركود، أضف المادة، راجع الفاتورة ثم أتمم البيع.</p>
    <h3>كيف أعمل مرتجع؟</h3><p>افتح المرتجعات، اكتب رقم الفاتورة، اختر المادة والكمية، اكتب السبب ثم احفظ المرتجع.</p>
    <h3>كيف أضيف زبون؟</h3><p>افتح الزبائن والديون، أدخل الاسم والهاتف وحد الدين ثم اضغط حفظ.</p>
    <h3>كيف أطبع فاتورة؟</h3><p>من التقارير اختر الفاتورة أو من تبويب الطباعة المباشرة اكتب رقم الفاتورة واضغط طباعة.</p>
    <h3>كيف أسترجع نسخة احتياطية؟</h3><p>من الأدوات > نسخ وباركود اختر استرجاع نسخة. سيأخذ النظام نسخة قبل الاسترجاع لحماية البيانات.</p>
    </div>''')
    layout.addWidget(title); layout.addWidget(txt,1); self.tabs.addTab(tab,'المساعدة')


def _v23_restore_safe(self):
    path,_=QFileDialog.getOpenFileName(self,'اختر نسخة احتياطية','','Database (*.db);;All Files (*)')
    if not path: return
    if QMessageBox.question(self,'تأكيد الاسترجاع','سيتم إنشاء نسخة احتياطية قبل الاسترجاع ثم استبدال قاعدة البيانات. هل تريد المتابعة؟') != QMessageBox.Yes:
        return
    try: self.service.restore_database_safe(path)
    except Exception as exc: QMessageBox.warning(self,'تعذر الاسترجاع',str(exc)); return
    QMessageBox.information(self,'تم','تم استرجاع النسخة. أعد تشغيل البرنامج الآن.')

# Patch restore to use safe restore.
ToolsPage.restore = _v23_restore_safe

_old_tools_init_v23 = ToolsPage.__init__
def _v23_tools_init(self, service: AppService, notify, current_user=None):
    _old_tools_init_v23(self, service, notify, current_user)
    try: _v23_build_direct_print_tab(self)
    except Exception as exc:
        log_exception(exc)
    try: _v23_build_cashier_tab(self)
    except Exception as exc:
        log_exception(exc)
    try: _v23_build_expenses_tab(self)
    except Exception as exc:
        log_exception(exc)
    try: _v23_build_health_tab(self)
    except Exception as exc:
        log_exception(exc)
    try: _v23_build_advanced_settings_tab(self)
    except Exception as exc:
        log_exception(exc)
    try: _v23_build_help_tab(self)
    except Exception as exc:
        log_exception(exc)

ToolsPage.__init__ = _v23_tools_init
ToolsPage.v23_print_invoice_now = _v23_print_invoice_now
ToolsPage.v23_print_return_now = _v23_print_return_now
ToolsPage.v23_print_payment_now = _v23_print_payment_now
ToolsPage.v23_print_purchase_now = _v23_print_purchase_now
ToolsPage.v23_print_daily_now = _v23_print_daily_now
ToolsPage.v23_save_expense = _v23_save_expense
ToolsPage.v23_refresh_expenses = _v23_refresh_expenses
ToolsPage.v23_export_expenses_pdf = _v23_export_expenses_pdf
ToolsPage.v23_refresh_cashier = _v23_refresh_cashier
ToolsPage.v23_export_cashier_pdf = _v23_export_cashier_pdf
ToolsPage.v23_run_health = _v23_run_health
ToolsPage.v23_save_advanced_settings = _v23_save_advanced_settings


def _v23_reports_build_archive_tab(self):
    tab=QWidget(); layout=QVBoxLayout(tab)
    top=QGridLayout()
    self.archive_from=QLineEdit(); self.archive_from.setPlaceholderText('من تاريخ YYYY-MM-DD')
    self.archive_to=QLineEdit(); self.archive_to.setPlaceholderText('إلى تاريخ YYYY-MM-DD')
    self.archive_employee=QLineEdit(); self.archive_employee.setPlaceholderText('الموظف')
    self.archive_customer=QLineEdit(); self.archive_customer.setPlaceholderText('الزبون')
    self.archive_product=QLineEdit(); self.archive_product.setPlaceholderText('المنتج')
    self.archive_payment=QComboBox(); self.archive_payment.addItems(['','نقدي','آجل','بطاقة'])
    self.archive_op=QComboBox(); self.archive_op.addItems(['','بيع','مرتجع','مصروف'])
    run=QPushButton('تطبيق الفلاتر'); run.setObjectName('primaryButton'); run.clicked.connect(self.v23_refresh_archive)
    pdf=QPushButton('تصدير التقرير'); pdf.clicked.connect(self.v23_export_archive_pdf)
    direct=QPushButton('طباعة التقرير'); direct.clicked.connect(self.v23_print_archive_pdf)
    widgets=[('من',self.archive_from),('إلى',self.archive_to),('الموظف',self.archive_employee),('الزبون',self.archive_customer),('المنتج',self.archive_product),('طريقة الدفع',self.archive_payment),('نوع العملية',self.archive_op)]
    for i,(lab,w) in enumerate(widgets): top.addWidget(QLabel(lab), i//2, (i%2)*2); top.addWidget(w, i//2, (i%2)*2+1)
    top.addWidget(run,4,0); top.addWidget(pdf,4,1); top.addWidget(direct,4,2)
    self.archive_table=Table(['النوع','الرقم','التاريخ','الموظف','الزبون','الدفع/التصنيف','المبلغ','الربح','التفاصيل'])
    layout.addLayout(top); layout.addWidget(self.archive_table,1); self.tabs.addTab(tab,'أرشفة وفلاتر')


def _v23_refresh_archive(self):
    rows=self.service.filtered_operations(self.archive_from.text(), self.archive_to.text(), self.archive_employee.text(), self.archive_customer.text(), self.archive_product.text(), self.archive_payment.currentText(), '', self.archive_op.currentText())
    self.archive_table.setRowCount(len(rows))
    for r,x in enumerate(rows):
        vals=[x.get('op',''),x.get('ref',''),x.get('created_at',''),x.get('employee',''),x.get('customer',''),x.get('payment_method',''),money(x.get('amount',0)),money(x.get('profit',0)),x.get('details','')]
        for c,v in enumerate(vals): self.archive_table.put(r,c,v)


def _v23_export_archive_pdf(self):
    self.v23_refresh_archive(); rows=[]
    for r in range(self.archive_table.rowCount()): rows.append([self.archive_table.item(r,c).text() if self.archive_table.item(r,c) else '' for c in range(self.archive_table.columnCount())])
    path=rows_to_pdf('تقرير الأرشفة والفلاتر', ['النوع','الرقم','التاريخ','الموظف','الزبون','الدفع/التصنيف','المبلغ','الربح','التفاصيل'], rows, 'archive_filtered_report')
    QMessageBox.information(self,'تم',f'تم إنشاء التقرير:\n{path}')
    return path


def _v23_print_archive_pdf(self):
    path=self.v23_export_archive_pdf()
    if path:
        QMessageBox.information(self,'تنبيه','تم إنشاء التقرير PDF. يمكنك طباعته من الملف الناتج.')

_old_reports_init_v23 = ReportsPage.__init__
def _v23_reports_init(self, service: AppService, notify=None):
    _old_reports_init_v23(self, service, notify)
    try: _v23_reports_build_archive_tab(self)
    except Exception as exc:
        log_exception(exc)

ReportsPage.__init__ = _v23_reports_init
ReportsPage.v23_refresh_archive = _v23_refresh_archive
ReportsPage.v23_export_archive_pdf = _v23_export_archive_pdf
ReportsPage.v23_print_archive_pdf = _v23_print_archive_pdf

# ================================================================
# V25 UI readiness patch
# Lazy page construction for limited users, sale product list without cost
# exposure, and automatic backup-on-close support.
# ================================================================


