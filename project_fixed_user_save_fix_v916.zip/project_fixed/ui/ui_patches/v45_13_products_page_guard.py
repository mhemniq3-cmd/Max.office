from __future__ import annotations

"""V45.13 UI guardrails for the products page.

No visual redesign. Only safer defaults and clearer refresh behavior.
"""

from ui.ui_common import QMessageBox
from ui.pages.products_page import ProductsPage

_old_build = ProductsPage.build
_old_clear = ProductsPage.clear
_old_save = ProductsPage.save
_old_refresh = ProductsPage.refresh


def _v4513_build(self: ProductsPage):
    _old_build(self)
    try:
        self.qty.setMinimum(1)
        self.qty.setValue(1)
        self.adjust_qty.setMinimum(0)
        self.min_qty.setMinimum(0)
        self.price.setMinimum(1)
        self.cost.setMinimum(0)
        self.comm.setRange(0, 100)
        self.search.setPlaceholderText('بحث جزئي: الاسم، الباركود، الصنف...')
    except Exception:
        pass


def _v4513_clear(self: ProductsPage):
    _old_clear(self)
    try:
        self.qty.setMinimum(1)
        self.qty.setValue(1)
        self.adjust_qty.setValue(0)
        self.min_qty.setMinimum(0)
        self.min_qty.setValue(0)
        self.price.setMinimum(1)
        self.cost.setMinimum(0)
    except Exception:
        pass


def _v4513_save(self: ProductsPage):
    try:
        # Guard before calling the service so the message is immediate and clear.
        if not (self.name.text() or '').strip():
            QMessageBox.warning(self, 'بيانات ناقصة', 'اسم المنتج مطلوب')
            return
        if float(self.price.value()) <= 0:
            QMessageBox.warning(self, 'بيانات ناقصة', 'سعر البيع يجب أن يكون أكبر من صفر')
            return
        if not getattr(self, 'product_id', None) and int(self.qty.value()) <= 0:
            QMessageBox.warning(self, 'بيانات ناقصة', 'لا يمكن إضافة مادة جديدة بكمية صفر')
            return
    except Exception:
        pass
    _old_save(self)
    try:
        self.refresh()
    except Exception:
        pass


def _v4513_refresh(self: ProductsPage):
    _old_refresh(self)
    try:
        # The table already shows active products including low/out-of-stock ones.
        # Add a tiny visual hint in the quantity cell without changing the layout.
        for r, p in enumerate(getattr(self, 'rows', []) or []):
            status = ''
            try:
                qty = int(p['quantity'] or 0)
                minq = int(p['min_quantity'] or 0)
                if qty <= 0:
                    status = ' نافد'
                elif qty <= minq:
                    status = ' منخفض'
            except Exception:
                status = ''
            if status:
                item = self.table.item(r, 5)
                if item and status not in item.text():
                    item.setText(f"{item.text()} -{status}")
    except Exception:
        pass


ProductsPage.build = _v4513_build
ProductsPage.clear = _v4513_clear
ProductsPage.save = _v4513_save
ProductsPage.refresh = _v4513_refresh
