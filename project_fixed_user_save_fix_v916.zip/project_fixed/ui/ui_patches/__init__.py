"""Versioned UI patch modules for the PySide6 Widgets interface.

v45.8 restores the original v44 visual layout by disabling the later
sidebar/home redesign patches. The smart archive/security/AI tools patch is
kept because it adds functionality without replacing the original sidebar.
"""

PATCH_MODULES = [
    'ui.ui_patches.v11_sales_safety',
    'ui.ui_patches.v20_gdrive_ui',
    'ui.ui_patches.v21_backup_ui',
    'ui.ui_patches.v22_gdrive_ui',
    'ui.ui_patches.v23_tools_reports',
    'ui.ui_patches.v25_lazy_permissions',
    'ui.ui_patches.v26_tools_refresh',
    'ui.ui_patches.v27_pricing_excel_ui',
    'ui.ui_patches.v28_professional_ui',
    'ui.ui_patches.v30_layout_cleanup',
    'ui.ui_patches.v31_goals_help_dates',
    'ui.ui_patches.v33_commercial_ui',
    'ui.ui_patches.v33_2_fixed_ui_no_themes',
    'ui.ui_patches.v34_permissions_offers_ui',
    'ui.ui_patches.v36_remote_dashboard_ui',
    'ui.ui_patches.v37_cloud_sync_ui',
    'ui.ui_patches.v38_user_guide_ui',
    'ui.ui_patches.v40_1_pos_quick_grid_fix',
    'ui.ui_patches.v41_cashier_shift_ui',
    'ui.ui_patches.v43_dark_mode_ui',
    'ui.ui_patches.v45_smart_archive_security_ui',
    'ui.ui_patches.v45_10_rtl_dialog_stability',
    'ui.ui_patches.v45_13_products_page_guard',
    'ui.ui_patches.v45_14_products_page_compat',
    'ui.ui_patches.v45_16_permissions_barcode_ui',
    'ui.ui_patches.v45_17_advanced_business_tools_ui',
    'ui.ui_patches.v45_17_4_2_session_timeout',
    'ui.ui_patches.v45_17_4_4_barcode_ai_ui',
    'ui.ui_patches.v45_17_4_5_fraud_coupons_dashboard_audit_ui',
    'ui.ui_patches.v45_17_4_7_integrity_coupon_fraud_ui',
    'ui.ui_patches.v45_17_4_9_ui_productivity_tools',
    'ui.ui_patches.v45_17_4_10_focus_arrow_toggle',
    'ui.ui_patches.v45_17_4_11_tools_topbar_movement_log',
    'ui.ui_patches.v45_17_4_12_barcode_customers_speed_movements_ui',
    'ui.ui_patches.v45_17_4_13_restore_main_buttons',
    'ui.ui_patches.v45_17_4_14_movement_center_ui',
    'ui.ui_patches.v45_17_4_17_tools_final_order',
    'ui.ui_patches.v45_17_4_18_tools_field_consistency',
    'ui.ui_patches.v45_17_4_22_tools_light_performance_layout',
    'ui.ui_patches.v46_customer_theme_ux',
    'ui.ui_patches.v46_1_reports_dashboard_payment_ui_fix',
    'ui.ui_patches.v46_2_tools_movement_optimization_ui',
    # Disabled in v46.4: this patch performed deep regrouping of ToolsPage
    # and could leave the Tools page completely blank on some installations.
    # Its service-layer features remain enabled through services/service_patches/v46_3_tools_movement_completion.py.
    # 'ui.ui_patches.v46_3_tools_movement_completion_ui',
    'ui.ui_patches.v46_10_tools_simplify_clean',
    'ui.ui_patches.v46_11_tools_clean_focus',
    'ui.ui_patches.v46_12_movement_details_ui',
    'ui.ui_patches.v46_13_modern_detail_dialogs',
    'ui.ui_patches.v46_14_tools_ultimate_redesign',
    # Disabled: tabbed sales interface is now built directly into SalesPage
    # 'ui.ui_patches.v46_16_sales_multitabs',
    'ui.ui_patches.v46_17_analytics_dashboard',
    'ui.ui_patches.v46_18_smart_notifications',
    'ui.ui_patches.v46_20_modal_accessibility',
]

def apply_all_patches():
    import importlib
    for module_name in PATCH_MODULES:
        importlib.import_module(module_name)
