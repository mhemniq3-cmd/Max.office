from __future__ import annotations

from pathlib import Path
import html
import os

from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.theme_manager import apply_theme as theme_apply, current_theme_key as theme_current_key, set_theme_key as theme_set_key, theme_label as theme_display_label, theme_path as theme_qss_path
from ui.main_window_core import *
import ui.ui_patches.v11_sales_safety as _prev_v11_sales_safety
globals().update({k: v for k, v in vars(_prev_v11_sales_safety).items() if not k.startswith('__')})
import ui.ui_patches.v20_gdrive_ui as _prev_v20_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v20_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v21_backup_ui as _prev_v21_backup_ui
globals().update({k: v for k, v in vars(_prev_v21_backup_ui).items() if not k.startswith('__')})
import ui.ui_patches.v22_gdrive_ui as _prev_v22_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v22_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v23_tools_reports as _prev_v23_tools_reports
globals().update({k: v for k, v in vars(_prev_v23_tools_reports).items() if not k.startswith('__')})
import ui.ui_patches.v25_lazy_permissions as _prev_v25_lazy_permissions
globals().update({k: v for k, v in vars(_prev_v25_lazy_permissions).items() if not k.startswith('__')})
import ui.ui_patches.v26_tools_refresh as _prev_v26_tools_refresh
globals().update({k: v for k, v in vars(_prev_v26_tools_refresh).items() if not k.startswith('__')})
import ui.ui_patches.v27_pricing_excel_ui as _prev_v27_pricing_excel_ui
globals().update({k: v for k, v in vars(_prev_v27_pricing_excel_ui).items() if not k.startswith('__')})
import ui.ui_patches.v28_professional_ui as _prev_v28_professional_ui
globals().update({k: v for k, v in vars(_prev_v28_professional_ui).items() if not k.startswith('__')})
import ui.ui_patches.v30_layout_cleanup as _prev_v30_layout_cleanup
globals().update({k: v for k, v in vars(_prev_v30_layout_cleanup).items() if not k.startswith('__')})
import ui.ui_patches.v31_goals_help_dates as _prev_v31_goals_help_dates
globals().update({k: v for k, v in vars(_prev_v31_goals_help_dates).items() if not k.startswith('__')})

def _v32_theme_key() -> str:
    path = _v28_project_root() / 'settings' / 'ui_theme.txt'
    try:
        value = path.read_text(encoding='utf-8').strip() or 'modern_blue'
    except Exception:
        value = 'modern_blue'
    value = _V32_ALIASES.get(value, value)
    return value if value in _V32_THEMES else 'modern_blue'


def _v32_theme_label(key: str | None = None) -> str:
    key = key or _v32_theme_key()
    return _V32_THEMES.get(key, _V32_THEMES['modern_blue'])[0]


def _v32_theme_path(key: str | None = None) -> Path:
    key = key or _v32_theme_key()
    file_name = _V32_THEMES.get(key, _V32_THEMES['modern_blue'])[1]
    return _v28_project_root() / 'assets' / file_name


def _v32_apply_theme(key: str) -> None:
    key = _V32_ALIASES.get(key, key)
    if key not in _V32_THEMES:
        key = 'modern_blue'
    app = QApplication.instance()
    if app:
        path = _v32_theme_path(key)
        if path.exists():
            app.setStyleSheet(path.read_text(encoding='utf-8'))
    try:
        settings_dir = _v28_project_root() / 'settings'
        settings_dir.mkdir(parents=True, exist_ok=True)
        (settings_dir / 'ui_theme.txt').write_text(key, encoding='utf-8')
    except Exception as exc:
        log_exception(exc)


def _v32_theme_file(mode: str) -> Path:
    mode = _V32_ALIASES.get(mode, mode)
    return _v32_theme_path(mode if mode in _V32_THEMES else _v32_theme_key())


def _v32_theme_mode() -> str:
    return _v32_theme_key()


def _v32_apply_compat(mode: str) -> None:
    _v32_apply_theme(mode)

# Override the old V28 helper names because V28/V31 callbacks resolve globals at runtime.
_v28_theme_file = _v32_theme_file
_v28_theme_mode = _v32_theme_mode
_v28_apply_theme = _v32_apply_compat


def _v32_make_theme_menu(self) -> QMenu:
    menu = QMenu(self)
    menu.setObjectName('themeMenu')
    for key, (label, _file) in _V32_THEMES.items():
        action = menu.addAction(label)
        action.setCheckable(True)
        action.setChecked(key == _v32_theme_key())
        action.triggered.connect(lambda checked=False, k=key: self.v32_select_theme(k))
    return menu


def _v32_select_theme(self, key: str):
    _v32_apply_theme(key)
    try:
        self.theme_button.setText('🎨')
        self.theme_button.setToolTip('الثيم الحالي: ' + _v32_theme_label(key) + ' — اضغط لتغيير المظهر')
        self.theme_button.setMenu(self.v32_make_theme_menu())
    except Exception as exc:
        log_exception(exc)
    try:
        self.notify('تم تطبيق الثيم: ' + _v32_theme_label(key))
    except Exception as exc:
        log_exception(exc)


def _v32_setup_theme_button(self):
    try:
        try:
            self.theme_button.clicked.disconnect()
        except Exception as exc:
            log_exception(exc)
        self.theme_button.setText('🎨')
        self.theme_button.setFixedSize(34, 34)
        self.theme_button.setToolTip('اختيار ثيم النظام من جوار النسخ الاحتياطي — الثيم الحالي: ' + _v32_theme_label())
        self.theme_button.setMenu(self.v32_make_theme_menu())
    except Exception as exc:
        log_exception(exc)


_orig_mainwindow_build_v32 = MainWindow.build

def _v32_mainwindow_build(self):
    _orig_mainwindow_build_v32(self)
    self.v32_setup_theme_button()
    try:
        for lab in self.findChildren(QLabel):
            if lab.objectName() == 'sidebarHint':
                lab.setText('V32 ثيمات متعددة - غيّر المظهر من أيقونة 🎨 الصغيرة في زاوية الشريط العلوي')
            elif lab.objectName() == 'topSubtitle':
                text = lab.text()
                if 'SQLite Local' in text:
                    lab.setText('V32 Multi Theme  |  Widgets UI  |  SQLite Local')
    except Exception as exc:
        log_exception(exc)


MainWindow.build = _v32_mainwindow_build
MainWindow.v32_make_theme_menu = _v32_make_theme_menu
MainWindow.v32_select_theme = _v32_select_theme
MainWindow.v32_setup_theme_button = _v32_setup_theme_button

# Extend the detailed help tab with the new theme chooser explanation.
_orig_v31_build_help_tab_for_v32 = globals().get('_v23_build_help_tab')

def _v32_build_help_tab(self):
    try:
        _orig_v31_build_help_tab_for_v32(self)
        try:
            idx = self.tabs.indexOf(self.tabs.findChild(QWidget, ''))
        except Exception:
            idx = -1
        # Add a separate concise appearance tab so the long help remains readable.
        tab = QWidget(); layout = QVBoxLayout(tab)
        title = QLabel('🎨 المظهر والثيمات'); title.setObjectName('miniTitle')
        text = QTextEdit(); text.setReadOnly(True)
        text.setHtml('''<div dir="rtl" style="font-family:Tahoma; font-size:14px; line-height:1.8">
        <h2>ثيمات النظام V32</h2>
        <p>يمكن تغيير شكل النظام من أيقونة <b>🎨</b> الصغيرة في زاوية الشريط العلوي. الاختيار يُحفظ تلقائياً ويُطبّق عند التشغيل القادم.</p>
        <ul>
          <li><b>ماكس أزرق احترافي:</b> الثيم الافتراضي للإدارة والتقارير والاستخدام العام.</li>
          <li><b>ماكس ليلي للكاشير:</b> مناسب لشاشة البيع والاستخدام الليلي والكاشير.</li>
          <li><b>ماكس ذهبي فاخر:</b> مناسب لمحلات الملابس، العطور، الهواتف، والإكسسوارات.</li>
          <li><b>ماكس أخضر تجاري:</b> مناسب للبقالة، السوبرماركت، الصيدليات، والمخازن.</li>
          <li><b>ماكس بسيط وهادئ:</b> مظهر مريح للعين للمكاتب والاستخدام الطويل.</li>
        </ul>
        <p>تغيير الثيم لا يغير قاعدة البيانات ولا البيع ولا الصلاحيات؛ هو مظهر فقط.</p>
        </div>''')
        layout.addWidget(title); layout.addWidget(text, 1)
        self.tabs.addTab(tab, 'المظهر والثيمات')
    except Exception:
        # Fallback to the original help tab if anything unexpected happens.
        if _orig_v31_build_help_tab_for_v32:
            _orig_v31_build_help_tab_for_v32(self)

globals()['_v23_build_help_tab'] = _v32_build_help_tab


# ---------------------------------------------------------------------------
# V32.2 compact theme icon placement + organized Tools workspace
# ---------------------------------------------------------------------------

