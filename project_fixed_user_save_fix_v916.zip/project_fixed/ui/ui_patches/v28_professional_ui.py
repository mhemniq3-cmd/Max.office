from __future__ import annotations

from pathlib import Path
import html
import os

from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.theme_manager import apply_theme as theme_apply, current_theme_key as theme_current_key, set_theme_key as theme_set_key, theme_label as theme_display_label, theme_path as theme_qss_path
from ui.main_window_core import *
import ui.ui_patches.v11_sales_safety as _prev_v11_sales_safety
globals().update({k: v for k, v in vars(_prev_v11_sales_safety).items() if not k.startswith('__')})
import ui.ui_patches.v20_gdrive_ui as _prev_v20_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v20_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v21_backup_ui as _prev_v21_backup_ui
globals().update({k: v for k, v in vars(_prev_v21_backup_ui).items() if not k.startswith('__')})
import ui.ui_patches.v22_gdrive_ui as _prev_v22_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v22_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v23_tools_reports as _prev_v23_tools_reports
globals().update({k: v for k, v in vars(_prev_v23_tools_reports).items() if not k.startswith('__')})
import ui.ui_patches.v25_lazy_permissions as _prev_v25_lazy_permissions
globals().update({k: v for k, v in vars(_prev_v25_lazy_permissions).items() if not k.startswith('__')})
import ui.ui_patches.v26_tools_refresh as _prev_v26_tools_refresh
globals().update({k: v for k, v in vars(_prev_v26_tools_refresh).items() if not k.startswith('__')})
import ui.ui_patches.v27_pricing_excel_ui as _prev_v27_pricing_excel_ui
globals().update({k: v for k, v in vars(_prev_v27_pricing_excel_ui).items() if not k.startswith('__')})

# V28 PROFESSIONAL UI -------------------------------------------------------
def _v28_project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _v28_theme_file(mode: str) -> Path:
    root = _v28_project_root()
    return root / 'assets' / ('style_dark.qss' if mode == 'dark' else 'style.qss')


def _v28_theme_mode() -> str:
    path = _v28_project_root() / 'settings' / 'ui_theme.txt'
    try:
        value = path.read_text(encoding='utf-8').strip()
    except Exception:
        value = ''
    return 'dark' if value == 'dark' else 'light'


def _v28_apply_theme(mode: str) -> None:
    mode = 'dark' if mode == 'dark' else 'light'
    app = QApplication.instance()
    if not app:
        return
    style_path = _v28_theme_file(mode)
    if style_path.exists():
        app.setStyleSheet(style_path.read_text(encoding='utf-8'))
    settings_dir = _v28_project_root() / 'settings'
    try:
        settings_dir.mkdir(parents=True, exist_ok=True)
        (settings_dir / 'ui_theme.txt').write_text(mode, encoding='utf-8')
    except Exception as exc:
        log_exception(exc)


def _v28_row_value(row, key: str, default=''):
    try:
        if row is not None and key in row.keys():
            return row[key]
    except Exception as exc:
        log_exception(exc)
    return default


def _v28_user_can_flag(user, flag: str) -> bool:
    try:
        return bool(user and flag in user.keys() and user[flag])
    except Exception:
        return False


def _v28_mainwindow_build(self):
    root = QWidget(); root.setObjectName('professionalShell'); self.setCentralWidget(root)
    main = QHBoxLayout(root); main.setContentsMargins(0, 0, 0, 0); main.setSpacing(0)

    sidebar = QFrame(); sidebar.setObjectName('sidebar'); sidebar.setFixedWidth(252)
    s_l = QVBoxLayout(sidebar); s_l.setContentsMargins(18, 18, 18, 18); s_l.setSpacing(9)

    brand = QFrame(); brand.setObjectName('brand')
    brand_l = QVBoxLayout(brand); brand_l.setContentsMargins(14, 12, 14, 12); brand_l.setSpacing(4)
    brand_mark = QLabel('MAX SALES PRO'); brand_mark.setObjectName('brandMark'); brand_mark.setAlignment(Qt.AlignCenter)
    brand_sub = QLabel('نظام مبيعات ومخزون احترافي'); brand_sub.setObjectName('brandSub'); brand_sub.setAlignment(Qt.AlignCenter)
    brand_l.addWidget(brand_mark); brand_l.addWidget(brand_sub)
    s_l.addWidget(brand)

    user_name = _v28_row_value(self.current_user, 'full_name') or _v28_row_value(self.current_user, 'username', 'بدون مستخدم')
    user_role = _v28_row_value(self.current_user, 'role', 'بدون دور')
    user_badge = QFrame(); user_badge.setObjectName('userBadge')
    user_l = QVBoxLayout(user_badge); user_l.setContentsMargins(10, 8, 10, 8); user_l.setSpacing(6)
    user_title = QLabel(f'👤 {user_name}'); user_title.setObjectName('userName'); user_title.setAlignment(Qt.AlignCenter)
    role_chip = QLabel(f'🛡 {user_role}'); role_chip.setObjectName('roleChip'); role_chip.setAlignment(Qt.AlignCenter)
    user_l.addWidget(user_title); user_l.addWidget(role_chip)
    s_l.addWidget(user_badge)

    hint_label = QLabel('واجهة V28 احترافية - الأقسام المقفلة تظهر بقفل')
    hint_label.setObjectName('sidebarHint'); hint_label.setWordWrap(True); hint_label.setAlignment(Qt.AlignCenter)
    s_l.addWidget(hint_label)

    nav_items = [
        ('dashboard', '🏠 الرئيسية'), ('sales', '🛒 البيع السريع'), ('touch_pos', '🖥 كاشير لمس'), ('products', '📦 المنتجات والمخزون'),
        ('customers', '👥 الزبائن والديون'), ('suppliers', '🚚 الموردون والمشتريات'), ('returns', '↩ المرتجعات'), ('reports', '📊 التقارير'),
        ('users', '🔐 المستخدمون'), ('ai', '🤖 المساعد الذكي'), ('tools', '⚙ الأدوات'),
    ]
    for key, text in nav_items:
        btn = QPushButton(text); btn.setObjectName('navButton'); btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(lambda checked=False, k=key: self.show_page(k))
        allowed = self.user_can(key)
        btn.setProperty('locked', not allowed)
        btn.setToolTip('لا تملك صلاحية فتح هذا القسم' if not allowed else 'فتح الصفحة')
        if not allowed:
            btn.setText(f'🔒 {text}')
        self.buttons[key] = btn
        s_l.addWidget(btn)
    s_l.addStretch()
    logout_btn = QPushButton('🚪 تسجيل الخروج')
    logout_btn.setObjectName('dangerButton'); logout_btn.setCursor(Qt.PointingHandCursor); logout_btn.clicked.connect(self.logout)
    s_l.addWidget(logout_btn)

    body = QFrame(); body.setObjectName('body')
    b_l = QVBoxLayout(body); b_l.setContentsMargins(18, 16, 18, 12); b_l.setSpacing(12)

    top = QFrame(); top.setObjectName('topbar')
    t_l = QHBoxLayout(top); t_l.setContentsMargins(16, 12, 16, 12); t_l.setSpacing(10)
    title_box = QVBoxLayout(); title_box.setSpacing(2)
    self.title = QLabel(''); self.title.setObjectName('topTitle')
    self.top_subtitle = QLabel('لوحة تشغيل موحدة للبيع، المخزون، الديون، العروض، والتقارير')
    self.top_subtitle.setObjectName('topSubtitle')
    title_box.addWidget(self.title); title_box.addWidget(self.top_subtitle)
    self.clock = QLabel(''); self.clock.setObjectName('clock')

    backup_btn = QPushButton('💾 نسخة احتياطية')
    backup_btn.setObjectName('primaryButton'); backup_btn.setCursor(Qt.PointingHandCursor)
    backup_btn.clicked.connect(self.v28_quick_backup)
    backup_btn.setVisible(_v28_user_can_flag(self.current_user, 'can_backup') or _v28_row_value(self.current_user, 'role') == 'مدير')
    refresh = QPushButton('⟳ تحديث')
    refresh.setObjectName('primaryButton'); refresh.setCursor(Qt.PointingHandCursor); refresh.clicked.connect(self.refresh_current)
    self.theme_button = QPushButton('🎨')
    self.theme_button.setObjectName('themeButton'); self.theme_button.setFixedSize(34, 34)
    self.theme_button.setCursor(Qt.PointingHandCursor); self.theme_button.clicked.connect(self.v28_toggle_theme)
    self.alert_btn = QPushButton('🔔 الإشعارات')
    self.alert_btn.setObjectName('alertButton'); self.alert_btn.setCursor(Qt.PointingHandCursor); self.alert_btn.clicked.connect(self.show_alerts_dialog)

    t_l.addLayout(title_box, 1)
    t_l.addWidget(backup_btn)
    t_l.addWidget(self.theme_button)
    t_l.addWidget(refresh)
    t_l.addWidget(self.alert_btn)
    t_l.addWidget(self.clock)

    self.stack = QStackedWidget()
    footer = QFrame(); footer.setObjectName('footerBar')
    footer_l = QHBoxLayout(footer); footer_l.setContentsMargins(14, 8, 14, 8); footer_l.setSpacing(8)
    self.status = QLabel('جاهز للعمل'); self.status.setObjectName('status')
    footer_info = QLabel('V28 Professional UI  |  SQLite Local  |  RTL Arabic')
    footer_info.setObjectName('topSubtitle')
    footer_l.addWidget(self.status, 1); footer_l.addWidget(footer_info)

    b_l.addWidget(top); b_l.addWidget(self.stack, 1); b_l.addWidget(footer)

    self.page_factories = {
        'dashboard': lambda: DashboardPage(self.service, self.current_user),
        'sales': lambda: SalesPage(self.service, self.notify, self.current_user),
        'touch_pos': lambda: TouchPOSPage(self.service, self.notify, self.current_user),
        'products': lambda: ProductsPage(self.service, self.notify, self.current_user),
        'customers': lambda: CustomersPage(self.service, self.notify),
        'suppliers': lambda: SuppliersPage(self.service, self.notify, self.current_user),
        'returns': lambda: ReturnsPage(self.service, self.notify, self.current_user),
        'reports': lambda: ReportsPage(self.service, self.notify),
        'users': lambda: UsersPage(self.service, self.notify),
        'ai': lambda: SmartAssistantPage(self.service, self.notify, self.current_user),
        'tools': lambda: ToolsPage(self.service, self.notify, self.current_user),
    }
    self.pages = {}
    main.addWidget(sidebar); main.addWidget(body, 1)


def _v28_toggle_theme(self):
    mode = 'dark' if _v28_theme_mode() == 'light' else 'light'
    _v28_apply_theme(mode)
    try:
        self.theme_button.setText('🌙 الوضع الليلي' if mode == 'light' else '☀ الوضع الفاتح')
    except Exception as exc:
        log_exception(exc)
    self.notify('تم تغيير المظهر إلى الوضع الليلي' if mode == 'dark' else 'تم تغيير المظهر إلى الوضع الفاتح')


def _v28_quick_backup(self):
    try:
        path = self.service.backup_database()
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر النسخ الاحتياطي', str(exc))
        return
    QMessageBox.information(self, 'تم النسخ الاحتياطي', f'تم إنشاء نسخة احتياطية بنجاح:\n{path}')
    self.notify('تم إنشاء نسخة احتياطية')


MainWindow.build = _v28_mainwindow_build
MainWindow.v28_toggle_theme = _v28_toggle_theme
MainWindow.v28_quick_backup = _v28_quick_backup


# ---------------------------------------------------------------------------
# V30 Widgets-only cleanup: remove QML path, keep V28 professional look,
# tidy Sales / Touch POS / Offers tabs and add safe delete buttons.
# ---------------------------------------------------------------------------

