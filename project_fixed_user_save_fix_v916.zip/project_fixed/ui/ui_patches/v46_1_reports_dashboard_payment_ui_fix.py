from __future__ import annotations

"""UI hotfix for Stage 4.1.1.

Keeps dashboard and reports compatible with both legacy row aliases
(`customer`, `employee`) and modern domain aliases (`customer_name`,
`employee_name`). It also auto-populates the default advanced report when the
reports page is opened.
"""

from database import money
from ui.pages.dashboard_page import DashboardPage
from ui.pages.reports_page import ReportsPage


def _pick(row, *names, default=''):
    for name in names:
        try:
            value = row.get(name) if hasattr(row, 'get') else row[name]
        except Exception:
            continue
        if value not in (None, ''):
            return value
    return default


def _v461_dashboard_refresh(self: DashboardPage) -> None:
    data = self.service.dashboard()
    self.sales.set_value(money(data.get('sales', 0)))
    self.profit.set_value(money(data.get('profit', 0)))
    self.invoices.set_value(str(data.get('invoices', 0)))
    self.commission.set_value(money(data.get('commission', 0)))
    self.returns.set_value(money(data.get('returns_amount', 0)))
    self.low.set_value(str(data.get('low_stock', 0)))
    self.best_product.setText(f"أفضل منتج اليوم: {data.get('best_product') or '-'}")
    sales = self.service.list_sales(8)
    self.recent.setRowCount(len(sales))
    for r, sale in enumerate(sales):
        vals = [
            _pick(sale, 'invoice_no', 'receipt_no'),
            _pick(sale, 'customer', 'customer_name', default='زبون عام'),
            _pick(sale, 'payment_method', default='-'),
            money(_pick(sale, 'total', default=0)),
            _pick(sale, 'created_at', default=''),
        ]
        for c, v in enumerate(vals):
            self.recent.put(r, c, v)
    alerts = self.service.smart_alerts()
    self.alerts.setText('\n'.join(f'• {item}' for item in alerts) if alerts else 'لا توجد تنبيهات حالياً. النظام يعمل بشكل جيد.')
    self.refresh_goal_ticker()


def _v461_reports_refresh(self: ReportsPage):
    rows = self.service.list_sales()
    self.table.setRowCount(len(rows))
    for r, s in enumerate(rows):
        vals = [
            _pick(s, 'invoice_no', 'receipt_no'),
            _pick(s, 'created_at'),
            _pick(s, 'user_name', 'username', default='-'),
            _pick(s, 'employee', 'employee_name', default='-'),
            _pick(s, 'customer', 'customer_name', default='زبون عام'),
            _pick(s, 'payment_method', default='-'),
            money(_pick(s, 'total', default=0)),
            money(_pick(s, 'total_profit', default=0)),
            money(_pick(s, 'total_commission', default=0)),
        ]
        for c, v in enumerate(vals):
            self.table.put(r, c, v)
    try:
        self.refresh_advanced()
    except Exception:
        pass


def _v461_export_sales_pdf(self: ReportsPage):
    from ui.ui_common import rows_to_pdf, QMessageBox
    rows = self.service.list_sales()
    data = [[
        _pick(s, 'invoice_no', 'receipt_no'),
        _pick(s, 'created_at'),
        _pick(s, 'user_name', 'username', default='-'),
        _pick(s, 'employee', 'employee_name', default='-'),
        _pick(s, 'customer', 'customer_name', default='زبون عام'),
        _pick(s, 'payment_method', default='-'),
        money(_pick(s, 'total', default=0)),
        money(_pick(s, 'total_profit', default=0)),
        money(_pick(s, 'total_commission', default=0)),
    ] for s in rows]
    path = rows_to_pdf('تقرير الفواتير والمبيعات', ['الفاتورة','التاريخ','المستخدم','موظف العمولة','الزبون','الدفع','الصافي','الربح','العمولة'], data, 'sales_report')
    QMessageBox.information(self, 'تم', f'تم إنشاء تقرير PDF:\n{path}')


DashboardPage.refresh = _v461_dashboard_refresh
ReportsPage.refresh = _v461_reports_refresh
ReportsPage.export_sales_pdf = _v461_export_sales_pdf
