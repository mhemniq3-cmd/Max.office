from __future__ import annotations

from datetime import datetime
from PySide6.QtCore import Qt, QMargins, QPropertyAnimation, QEasingCurve, QParallelAnimationGroup, QTimer
from PySide6.QtGui import QFont, QColor, QPainter, QPen
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, 
                               QLabel, QFrame, QScrollArea, QSizePolicy, QDialog, QPushButton, QProgressBar, QGraphicsOpacityEffect)
from PySide6.QtCharts import QChart, QChartView, QLineSeries, QPieSeries, QValueAxis, QCategoryAxis, QBarSeries, QBarSet

from database import money
from ui.main_window_core import MainWindow
from ui.ui_common import Table
from services.error_logger import log_exception

class KPICard(QFrame):
    def __init__(self, title, value, icon, color1, color2, click_callback=None):
        super().__init__()
        self.click_callback = click_callback
        if self.click_callback:
            self.setCursor(Qt.PointingHandCursor)
        self.setObjectName("kpiCard")
        self.setStyleSheet(f"""
            QFrame#kpiCard {{
                background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 {color1}, stop:1 {color2});
                border-radius: 20px;
                border: none;
            }}
            QLabel#kpiTitle {{
                color: rgba(255, 255, 255, 0.9);
                font-size: 18px;
                font-weight: bold;
                background: transparent;
            }}
            QLabel#kpiValue {{
                color: #ffffff;
                font-size: 34px;
                font-weight: 900;
                background: transparent;
            }}
            QLabel#kpiIcon {{
                font-size: 56px;
                background: transparent;
                color: rgba(255, 255, 255, 0.3);
            }}
        """)
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        
        text_layout = QVBoxLayout()
        t_lbl = QLabel(title)
        t_lbl.setObjectName("kpiTitle")
        
        self.v_lbl = QLabel(value)
        self.v_lbl.setObjectName("kpiValue")
        
        text_layout.addWidget(t_lbl)
        text_layout.addWidget(self.v_lbl)
        text_layout.addStretch()
        
        i_lbl = QLabel(icon)
        i_lbl.setObjectName("kpiIcon")
        i_lbl.setAlignment(Qt.AlignCenter)
        
        layout.addLayout(text_layout)
        layout.addWidget(i_lbl)

    def set_value(self, val):
        self.v_lbl.setText(val)

    def mousePressEvent(self, event):
        if getattr(self, 'click_callback', None) and event.button() == Qt.LeftButton:
            # Subtle click feedback
            self.setStyleSheet(self.styleSheet().replace("stop:1", "stop:0.8"))
            QTimer.singleShot(150, lambda: self.setStyleSheet(self.styleSheet().replace("stop:0.8", "stop:1")))
            self.click_callback()
        super().mousePressEvent(event)

class GoalProgress(QFrame):
    def __init__(self):
        super().__init__()
        self.setStyleSheet("background: transparent; border: none;")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        header_layout = QHBoxLayout()
        title = QLabel("🎯 الهدف اليومي للمبيعات")
        title.setStyleSheet("font-weight: bold; color: #64748b; font-size: 15px;")
        self.lbl_ratio = QLabel("0 / 0")
        self.lbl_ratio.setStyleSheet("font-weight: 900; color: #0f172a; font-size: 15px;")
        
        header_layout.addWidget(title)
        header_layout.addStretch()
        header_layout.addWidget(self.lbl_ratio)
        
        self.bar = QProgressBar()
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(14)
        self.bar.setStyleSheet("""
            QProgressBar {
                background-color: #e2e8f0;
                border-radius: 7px;
                border: none;
            }
            QProgressBar::chunk {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #3b82f6, stop:1 #8b5cf6);
                border-radius: 7px;
            }
        """)
        
        layout.addLayout(header_layout)
        layout.addWidget(self.bar)
        
    def update_goal(self, current, target):
        self.bar.setMaximum(target)
        self.bar.setValue(min(int(current), int(target)))
        self.lbl_ratio.setText(f"{money(current)} / {money(target)}")

class LiveTransactionRow(QFrame):
    def __init__(self, inv_no, customer, time, total):
        super().__init__()
        self.setStyleSheet("""
            QFrame {
                background: #f8fafc; border-radius: 12px; border: 1px solid #e2e8f0;
            }
            QFrame:hover { background: #f1f5f9; border: 1px solid #cbd5e1; }
        """)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        
        icon = QLabel("🧾")
        icon.setStyleSheet("font-size: 24px; background: transparent; border: none;")
        
        info_layout = QVBoxLayout()
        cust_lbl = QLabel(customer)
        cust_lbl.setStyleSheet("font-weight: bold; color: #0f172a; font-size: 14px; border: none; background: transparent;")
        inv_lbl = QLabel(f"فاتورة #{inv_no} • {time}")
        inv_lbl.setStyleSheet("color: #64748b; font-size: 12px; border: none; background: transparent;")
        info_layout.addWidget(cust_lbl)
        info_layout.addWidget(inv_lbl)
        
        total_lbl = QLabel(money(total))
        total_lbl.setStyleSheet("font-weight: 900; color: #10b981; font-size: 16px; border: none; background: transparent;")
        
        layout.addWidget(icon)
        layout.addLayout(info_layout)
        layout.addStretch()
        layout.addWidget(total_lbl)

class StockAlertsDialog(QDialog):
    def __init__(self, parent, service):
        super().__init__(parent)
        self.setWindowTitle("📦 تفاصيل نواقص المخزون")
        self.setMinimumSize(800, 500)
        self.setStyleSheet("""
            QDialog {
                background-color: #f8fafc;
            }
            QLabel#headerTitle {
                font-size: 24px;
                font-weight: 900;
                color: #0f172a;
            }
        """)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)
        
        header = QLabel("📦 تفاصيل الأصناف الناقصة أو التي وصلت لحد التنبيه")
        header.setObjectName("headerTitle")
        layout.addWidget(header)
        
        self.table = Table(["الباركود", "اسم الصنف", "الكمية الحالية", "حد التنبيه", "حالة الخطر"])
        layout.addWidget(self.table, 1)
        
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        close_btn = QPushButton("إغلاق نافذة النواقص")
        close_btn.setObjectName("dangerButton")
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.clicked.connect(self.close)
        btn_layout.addWidget(close_btn)
        
        layout.addLayout(btn_layout)
        
        self.load_data(service)
        
    def load_data(self, service):
        try:
            rows = service.db.conn.execute('''
                SELECT barcode, name, quantity, min_quantity 
                FROM products 
                WHERE COALESCE(active,1)=1 AND quantity <= min_quantity
                ORDER BY quantity ASC
            ''').fetchall()
            
            self.table.setRowCount(len(rows))
            for r, row in enumerate(rows):
                qty = float(row['quantity'] or 0)
                min_qty = float(row['min_quantity'] or 0)
                status = "🔴 نافد تماماً" if qty <= 0 else "🟠 وصل لحد التنبيه"
                
                vals = [
                    str(row['barcode'] or ''),
                    str(row['name'] or ''),
                    str(qty),
                    str(min_qty),
                    status
                ]
                for c, v in enumerate(vals):
                    self.table.put(r, c, v)
        except Exception as exc:
            log_exception(exc, "StockAlertsDialog.load_data")

class AnalyticsDashboardPage(QWidget):
    def __init__(self, service, current_user):
        super().__init__()
        self.service = service
        self.current_user = current_user
        
        self.setStyleSheet("background-color: #f8fafc;")
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("border: none; background: transparent;")
        
        container = QWidget()
        container.setStyleSheet("background: transparent;")
        layout = QVBoxLayout(container)
        layout.setContentsMargins(32, 32, 32, 32)
        layout.setSpacing(24)
        
        # 1. Header & Goal Progress
        header_row = QHBoxLayout()
        try:
            u_name = self.current_user['name'] if self.current_user else 'مدير النظام'
        except Exception:
            u_name = 'مدير النظام'
        
        welcome = QLabel(f"مرحباً بك يا {u_name} 👋\nإليك نظرة سريعة على أداء أرباحك ومبيعاتك اليوم.")
        welcome.setStyleSheet("font-size: 24px; font-weight: 900; color: #0f172a;")
        
        self.goal_widget = GoalProgress()
        self.goal_widget.setFixedWidth(350)
        
        header_row.addWidget(welcome)
        header_row.addStretch()
        header_row.addWidget(self.goal_widget)
        layout.addLayout(header_row)
        
        # 2. KPI Cards (Legendary Gradients)
        kpi_layout = QGridLayout()
        kpi_layout.setSpacing(20)
        
        self.kpi_sales = KPICard("المبيعات اليوم", "0", "💰", "#0284c7", "#38bdf8")
        self.kpi_profit = KPICard("الأرباح اليوم", "0", "📈", "#059669", "#34d399")
        self.kpi_invoices = KPICard("فواتير اليوم", "0", "🧾", "#7c3aed", "#a78bfa")
        self.kpi_stock = KPICard("تنبيهات المخزون", "0", "⚠️", "#e11d48", "#fb7185", click_callback=self.show_stock_alerts)
        
        kpi_layout.addWidget(self.kpi_sales, 0, 0)
        kpi_layout.addWidget(self.kpi_profit, 0, 1)
        kpi_layout.addWidget(self.kpi_invoices, 0, 2)
        kpi_layout.addWidget(self.kpi_stock, 0, 3)
        layout.addLayout(kpi_layout)
        
        # 3. Middle Area (Line Chart + Live Feed)
        mid_row = QHBoxLayout()
        mid_row.setSpacing(24)
        
        # Line Chart
        self.line_chart_view = QChartView()
        self.line_chart_view.setRenderHint(QPainter.Antialiasing)
        self.line_chart_view.setStyleSheet("background: #ffffff; border-radius: 16px; border: 1px solid #e2e8f0;")
        self.line_chart_view.setMinimumHeight(380)
        mid_row.addWidget(self.line_chart_view, 2)
        
        # Live Transactions Feed
        feed_container = QFrame()
        feed_container.setStyleSheet("background: #ffffff; border-radius: 16px; border: 1px solid #e2e8f0;")
        feed_container.setFixedWidth(380)
        feed_layout = QVBoxLayout(feed_container)
        feed_layout.setContentsMargins(20, 20, 20, 20)
        
        f_title = QLabel("⏱️ أحدث المبيعات المباشرة")
        f_title.setStyleSheet("font-weight: 900; font-size: 18px; color: #0f172a; border: none;")
        feed_layout.addWidget(f_title)
        
        self.feed_list_layout = QVBoxLayout()
        self.feed_list_layout.setSpacing(10)
        feed_layout.addLayout(self.feed_list_layout)
        feed_layout.addStretch()
        
        mid_row.addWidget(feed_container)
        layout.addLayout(mid_row)
        
        # 4. Bottom Area (Pie Chart)
        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(24)
        
        self.pie_chart_view = QChartView()
        self.pie_chart_view.setRenderHint(QPainter.Antialiasing)
        self.pie_chart_view.setStyleSheet("background: #ffffff; border-radius: 16px; border: 1px solid #e2e8f0;")
        self.pie_chart_view.setMinimumHeight(380)
        bottom_row.addWidget(self.pie_chart_view, 1)
        
        # Add a placeholder for future bar chart or just let Pie take full width if we don't have bar
        layout.addLayout(bottom_row)
        
        scroll.setWidget(container)
        main_layout.addWidget(scroll)
        
        # 5. Entrance Animation
        self.effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self.effect)
        self.anim = QPropertyAnimation(self.effect, b"opacity")
        self.anim.setDuration(700)
        self.anim.setStartValue(0)
        self.anim.setEndValue(1)
        self.anim.setEasingCurve(QEasingCurve.InOutQuad)
        self.anim.start()
        
        self.refresh()
        
    def show_stock_alerts(self):
        try:
            dlg = StockAlertsDialog(self, self.service)
            dlg.exec()
        except Exception as exc:
            log_exception(exc, "AnalyticsDashboardPage.show_stock_alerts")
            
    def refresh(self):
        try:
            # 1. Update KPIs
            data = self.service.dashboard()
            sales_today = float(data.get('sales', 0))
            self.kpi_sales.set_value(money(sales_today))
            self.kpi_profit.set_value(money(data.get('profit', 0)))
            self.kpi_invoices.set_value(str(data.get('invoices', 0)))
            self.kpi_stock.set_value(str(data.get('low_stock', 0)))
            
            # 2. Update Goal Progress
            # Calculate dynamic target (e.g. 10000 or 150% of avg sales)
            target = 10000.0 # Default fallback
            try:
                avg = self.service.db.conn.execute("SELECT AVG(daily_sum) FROM (SELECT SUM(total) as daily_sum FROM sales GROUP BY date(created_at) LIMIT 30)").fetchone()[0]
                if avg and float(avg) > 0:
                    target = float(avg) * 1.1 # 10% more than average
                else:
                    target = 5000.0
            except Exception:
                pass
            
            # Make sure target is rounded and sensible
            target = max(500, round(target / 500) * 500) 
            self.goal_widget.update_goal(sales_today, target)
            
            # 3. Update Charts
            self.build_line_chart()
            self.build_pie_chart()
            
            # 4. Update Live Feed
            self.update_live_feed()
            
        except Exception as exc:
            log_exception(exc, "AnalyticsDashboardPage.refresh")
            
    def update_live_feed(self):
        # Clear existing
        for i in reversed(range(self.feed_list_layout.count())): 
            w = self.feed_list_layout.itemAt(i).widget()
            if w: w.deleteLater()
            
        try:
            today = datetime.now().strftime('%Y-%m-%d')
            rows = self.service.db.conn.execute('''
                SELECT s.invoice_no, s.total, strftime('%H:%M', s.created_at) as t, COALESCE(c.name, 'زبون عام') as customer
                FROM sales s LEFT JOIN customers c ON s.customer_id = c.id
                WHERE COALESCE(s.status,'completed')='completed' AND date(s.created_at) = date(?)
                ORDER BY s.id DESC LIMIT 5
            ''', (today,)).fetchall()
            
            if not rows:
                lbl = QLabel("لم يتم تسجيل أي مبيعات اليوم بعد.")
                lbl.setStyleSheet("color: #94a3b8; font-weight: bold;")
                self.feed_list_layout.addWidget(lbl)
            else:
                for row in rows:
                    w = LiveTransactionRow(row['invoice_no'], row['customer'], row['t'], float(row['total'] or 0))
                    self.feed_list_layout.addWidget(w)
        except Exception as exc:
            log_exception(exc, "AnalyticsDashboardPage.update_live_feed")
            
    def build_line_chart(self):
        chart = QChart()
        chart.setTitle("أداء المبيعات في آخر 7 أيام 📊")
        chart.setTitleFont(QFont("Arial", 16, QFont.Bold))
        chart.setAnimationOptions(QChart.SeriesAnimations)
        chart.setBackgroundRoundness(0)
        chart.layout().setContentsMargins(0,0,0,0)
        
        series = QLineSeries()
        series.setName("المبيعات الإجمالية")
        pen = QPen(QColor("#0ea5e9"))
        pen.setWidth(4)
        series.setPen(pen)
        
        try:
            rows = self.service.db.conn.execute("""
                SELECT strftime('%Y-%m-%d', created_at) as d, SUM(total) as s
                FROM sales
                WHERE created_at >= date('now', '-7 days')
                GROUP BY d
                ORDER BY d ASC
            """).fetchall()
            
            categories = []
            max_val = 0
            for i, row in enumerate(rows):
                val = float(row['s'] or 0)
                series.append(i, val)
                categories.append(row['d'][-5:]) # MM-DD
                if val > max_val:
                    max_val = val
                    
            if not rows:
                series.append(0, 0)
                categories.append("لا يوجد")
                
            chart.addSeries(series)
            
            axisX = QCategoryAxis()
            for i, c in enumerate(categories):
                axisX.append(c, i)
            axisX.setLabelsPosition(QCategoryAxis.AxisLabelsPositionOnValue)
            
            grid_pen = QPen(QColor("#e2e8f0"))
            grid_pen.setStyle(Qt.DashLine)
            axisX.setGridLinePen(grid_pen)
            
            chart.addAxis(axisX, Qt.AlignBottom)
            series.attachAxis(axisX)
            
            axisY = QValueAxis()
            axisY.setLabelFormat("%.0f")
            axisY.setRange(0, max_val * 1.2 if max_val > 0 else 100)
            axisY.setGridLinePen(grid_pen)
            chart.addAxis(axisY, Qt.AlignLeft)
            series.attachAxis(axisY)
            
        except Exception as exc:
            log_exception(exc, "build_line_chart")
            
        self.line_chart_view.setChart(chart)
        
    def build_pie_chart(self):
        chart = QChart()
        chart.setTitle("المنتجات الأكثر مبيعاً 🔥")
        chart.setTitleFont(QFont("Arial", 16, QFont.Bold))
        chart.setAnimationOptions(QChart.SeriesAnimations)
        chart.setBackgroundRoundness(0)
        chart.layout().setContentsMargins(0,0,0,0)
        
        series = QPieSeries()
        series.setHoleSize(0.4) # Donut chart!
        
        try:
            rows = self.service.db.conn.execute("""
                SELECT p.name, SUM(si.quantity) as qty
                FROM sale_items si
                JOIN products p ON p.id = si.product_id
                GROUP BY p.name
                ORDER BY qty DESC
                LIMIT 5
            """).fetchall()
            
            colors = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"]
            for i, row in enumerate(rows):
                slice = series.append(str(row['name']), float(row['qty'] or 0))
                slice.setLabelVisible(True)
                slice.setColor(QColor(colors[i % len(colors)]))
                # Explode the top product
                if i == 0:
                    slice.setExploded(True)
                    slice.setExplodeDistanceFactor(0.1)
                
            if not rows:
                series.append("لا يوجد مبيعات", 1)
                
        except Exception as exc:
            log_exception(exc, "build_pie_chart")
            
        chart.addSeries(series)
        self.pie_chart_view.setChart(chart)

_ORIG_MAINWINDOW_BUILD_V4617 = MainWindow.build

def _v46_17_mainwindow_build(self: MainWindow):
    _ORIG_MAINWINDOW_BUILD_V4617(self)
    try:
        self.page_factories['dashboard'] = lambda: AnalyticsDashboardPage(self.service, self.current_user)
        if 'dashboard' in self.pages:
            del self.pages['dashboard']
    except Exception as exc:
        log_exception(exc, "v46_17_mainwindow_build")

MainWindow.build = _v46_17_mainwindow_build
