from __future__ import annotations

from pathlib import Path

from ui.ui_common import *
from PySide6.QtWidgets import QButtonGroup, QRadioButton
from ui.pages.tools_page import ToolsPage
from ui import theme_manager
from services.error_logger import log_exception

_ORIG_TOOLS_INIT = ToolsPage.__init__


def _project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _current_user_id(page):
    try:
        if isinstance(page.current_user, dict):
            return page.current_user.get('id')
        return page.current_user['id'] if page.current_user else None
    except Exception:
        return None


def _mode_label(mode: str) -> str:
    return dict(theme_manager.available_appearance_modes()).get(mode, mode)


def _tools_init_v43(self, service, notify, current_user=None):
    _ORIG_TOOLS_INIT(self, service, notify, current_user)
    try:
        self.build_v43_appearance_tab()
    except Exception as exc:
        log_exception(exc, 'build V43 appearance tab')


def _build_v43_appearance_tab(self: ToolsPage):
    tab = QWidget()
    root = QVBoxLayout(tab)
    root.setContentsMargins(18, 18, 18, 18)
    root.setSpacing(12)

    title = QLabel('🌓 المظهر والوضع الداكن')
    title.setObjectName('sectionTitle')
    note = QLabel('اختر مظهر النظام: فاتح، داكن، أو تلقائي حسب إعدادات Windows. يتم حفظ الاختيار وتطبيقه فورياً بدون إعادة تشغيل قدر الإمكان.')
    note.setObjectName('noticeBox')
    note.setWordWrap(True)
    root.addWidget(title)
    root.addWidget(note)

    box = QFrame(); box.setObjectName('surface')
    form = QVBoxLayout(box)
    form.setContentsMargins(16, 16, 16, 16)
    form.setSpacing(10)

    self.v43_mode_group = QButtonGroup(self)
    self.v43_mode_buttons = {}
    current = theme_manager.current_appearance_mode(_project_root())
    effective = theme_manager.effective_mode(current, _project_root())
    for mode, label in theme_manager.available_appearance_modes():
        rb = QRadioButton(label)
        rb.setObjectName('appearanceRadio')
        rb.setChecked(mode == current)
        self.v43_mode_group.addButton(rb)
        self.v43_mode_buttons[mode] = rb
        form.addWidget(rb)

    self.v43_status = QLabel(f'الحالي: {_mode_label(current)} | المطبق فعلياً: {_mode_label(effective)}')
    self.v43_status.setObjectName('noticeBox')
    self.v43_status.setWordWrap(True)
    form.addWidget(self.v43_status)

    row = QHBoxLayout(); row.setSpacing(8)
    apply_btn = QPushButton('تطبيق المظهر الآن'); apply_btn.setObjectName('primaryButton'); apply_btn.clicked.connect(self.v43_apply_appearance_mode)
    light_btn = QPushButton('فاتح سريع'); light_btn.clicked.connect(lambda: self.v43_set_and_apply('light'))
    dark_btn = QPushButton('داكن سريع'); dark_btn.clicked.connect(lambda: self.v43_set_and_apply('dark'))
    auto_btn = QPushButton('تلقائي'); auto_btn.clicked.connect(lambda: self.v43_set_and_apply('auto'))
    row.addWidget(auto_btn); row.addWidget(dark_btn); row.addWidget(light_btn); row.addWidget(apply_btn)
    form.addLayout(row)

    root.addWidget(box)
    details = QLabel('ملاحظة: هذا ليس نظام ثيمات قديم؛ هو فقط وضع قراءة مريح بثلاث حالات ثابتة، ويعالج ألوان الحقول والجداول والقوائم المنسدلة.')
    details.setObjectName('mutedText')
    details.setWordWrap(True)
    root.addWidget(details)
    root.addStretch(1)
    self.tabs.addTab(tab, 'المظهر')


def _selected_mode(self: ToolsPage) -> str:
    for mode, rb in getattr(self, 'v43_mode_buttons', {}).items():
        if rb.isChecked():
            return mode
    return theme_manager.current_appearance_mode(_project_root())


def _v43_set_and_apply(self: ToolsPage, mode: str):
    try:
        btn = getattr(self, 'v43_mode_buttons', {}).get(mode)
        if btn:
            btn.setChecked(True)
        self.v43_apply_appearance_mode()
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر تطبيق المظهر', str(exc))
        log_exception(exc, 'V43 quick appearance apply')


def _v43_apply_appearance_mode(self: ToolsPage):
    try:
        mode = _selected_mode(self)
        root = _project_root()
        saved = theme_manager.set_appearance_mode(mode, root)
        theme_manager.apply_theme(root=root, theme=saved)
        effective = theme_manager.effective_mode(saved, root)
        if hasattr(self, 'service') and hasattr(self.service, 'save_settings'):
            try:
                self.service.save_settings({'ui_mode': saved})
            except Exception:
                pass
        try:
            uid = _current_user_id(self)
            if hasattr(self.service, 'audit_detail'):
                self.service.audit_detail(uid, 'تغيير المظهر', 'ui_settings', 'ui_mode', {'ui_mode': theme_manager.current_appearance_mode(root)}, {'ui_mode': saved}, f'تم تغيير المظهر إلى {_mode_label(saved)}', 'low')
        except Exception:
            pass
        self.v43_status.setText(f'الحالي: {_mode_label(saved)} | المطبق فعلياً: {_mode_label(effective)}')
        self.notify('تم تطبيق المظهر: ' + _mode_label(saved))
    except Exception as exc:
        log_exception(exc, 'V43 apply appearance mode')
        QMessageBox.warning(self, 'تعذر تطبيق المظهر', str(exc))


ToolsPage.__init__ = _tools_init_v43
ToolsPage.build_v43_appearance_tab = _build_v43_appearance_tab
ToolsPage.v43_apply_appearance_mode = _v43_apply_appearance_mode
ToolsPage.v43_set_and_apply = _v43_set_and_apply

# V43 markers: Light Dark Auto style_dark_mode_v43.qss ui_mode.txt appearanceRadio المظهر والوضع الداكن

# V43.1: make appearance access visible from the top bar even if the Tools tab is grouped/hidden.
from ui.main_window_core import MainWindow

_ORIG_MAINWINDOW_BUILD_V431 = MainWindow.build


def _v431_build_with_appearance_button(self: MainWindow):
    _ORIG_MAINWINDOW_BUILD_V431(self)
    try:
        if getattr(self, 'appearance_button', None) is not None:
            return
        btn = QPushButton('✨ المظهر')
        btn.setObjectName('appearanceTopButton')
        btn.setCursor(Qt.PointingHandCursor)
        btn.setToolTip('تخصيص ألوان وواجهة النظام')
        btn.setStyleSheet("""
            QPushButton#appearanceTopButton {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #ffffff, stop:1 #f8fafc);
                border: 1px solid #cbd5e1;
                border-radius: 8px;
                color: #1e293b;
                font-size: 14px;
                font-weight: 900;
                padding: 6px 14px;
            }
            QPushButton#appearanceTopButton:hover {
                background-color: #e0f2fe;
                border-color: #38bdf8;
                color: #0284c7;
            }
        """)
        btn.clicked.connect(self.v431_open_appearance_dialog)
        self.appearance_button = btn
        try:
            layout = self.alert_btn.parentWidget().layout()
            idx = layout.indexOf(self.alert_btn)
            if idx >= 0:
                layout.insertWidget(idx + 1, btn)
            else:
                layout.addWidget(btn)
        except Exception:
            pass
    except Exception as exc:
        log_exception(exc, 'V43.1 add appearance top button')


def _v431_open_appearance_dialog(self: MainWindow):
    try:
        dlg = QDialog(self)
        dlg.setWindowTitle('المظهر والوضع الداكن')
        dlg.setMinimumWidth(460)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(20, 20, 20, 20)
        lay.setSpacing(12)

        title = QLabel('🌓 المظهر والوضع الداكن')
        title.setObjectName('sectionTitle')
        note = QLabel('اختر مظهر النظام: فاتح، داكن، أو تلقائي. يتم حفظ الاختيار وتطبيقه فوراً قدر الإمكان.')
        note.setObjectName('noticeBox')
        note.setWordWrap(True)
        lay.addWidget(title)
        lay.addWidget(note)

        root = _project_root()
        current = theme_manager.current_appearance_mode(root)
        buttons = {}
        group = QButtonGroup(dlg)
        box = QFrame(); box.setObjectName('surface')
        box_l = QVBoxLayout(box); box_l.setContentsMargins(14, 14, 14, 14); box_l.setSpacing(8)
        for mode, label in theme_manager.available_appearance_modes():
            rb = QRadioButton(label)
            rb.setObjectName('appearanceRadio')
            rb.setChecked(mode == current)
            group.addButton(rb)
            buttons[mode] = rb
            box_l.addWidget(rb)
        status = QLabel(f'الحالي: {_mode_label(current)} | المطبق فعلياً: {_mode_label(theme_manager.effective_mode(current, root))}')
        status.setObjectName('noticeBox')
        status.setWordWrap(True)
        box_l.addWidget(status)
        lay.addWidget(box)

        row = QHBoxLayout(); row.setSpacing(8)
        close = QPushButton('إغلاق'); close.clicked.connect(dlg.accept)
        apply = QPushButton('تطبيق المظهر الآن'); apply.setObjectName('primaryButton')

        def selected():
            for m, rb in buttons.items():
                if rb.isChecked():
                    return m
            return current

        def do_apply():
            try:
                mode = selected()
                saved = theme_manager.set_appearance_mode(mode, root)
                theme_manager.apply_theme(root=root, theme=saved)
                effective = theme_manager.effective_mode(saved, root)
                try:
                    if hasattr(self.service, 'save_settings'):
                        self.service.save_settings({'ui_mode': saved})
                except Exception:
                    pass
                status.setText(f'الحالي: {_mode_label(saved)} | المطبق فعلياً: {_mode_label(effective)}')
                self.notify('تم تطبيق المظهر: ' + _mode_label(saved))
            except Exception as exc:
                log_exception(exc, 'V43.1 apply appearance dialog')
                QMessageBox.warning(dlg, 'تعذر تطبيق المظهر', str(exc))

        apply.clicked.connect(do_apply)
        row.addWidget(close)
        row.addWidget(apply)
        lay.addLayout(row)
        dlg.exec()
    except Exception as exc:
        log_exception(exc, 'V43.1 open appearance dialog')
        QMessageBox.warning(self, 'تعذر فتح المظهر', str(exc))


MainWindow.build = _v431_build_with_appearance_button
MainWindow.v431_open_appearance_dialog = _v431_open_appearance_dialog

# V43.1 marker: visible topbar appearance button زر المظهر أعلى الشاشة
