from __future__ import annotations

"""V45.10 UI stability polish for the restored v44 design.

Non-invasive fixes:
- enforce RTL layout on major windows/dialogs
- keep dialogs application-modal so they do not open behind the main window
- make tables resize safely on smaller screens
- show clearer errors for page refresh failures instead of silent crashes
"""

from ui.ui_common import *
from ui.main_window_core import MainWindow


def _apply_widget_stability(widget: QWidget) -> None:
    try:
        widget.setLayoutDirection(Qt.RightToLeft)
        widget.setMinimumWidth(max(widget.minimumWidth(), 0))
        if isinstance(widget, QDialog):
            widget.setWindowModality(Qt.ApplicationModal)
            widget.setAttribute(Qt.WA_DeleteOnClose, True)
        for table in widget.findChildren(QTableWidget):
            table.setAlternatingRowColors(True)
            table.setWordWrap(False)
            table.horizontalHeader().setStretchLastSection(True)
            table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    except Exception as exc:
        log_exception(exc)


_prev_show_page_v4510 = MainWindow.show_page


def _v4510_show_page(self: MainWindow, key: str):
    _prev_show_page_v4510(self, key)
    try:
        page = self.pages.get(key)
        if page:
            _apply_widget_stability(page)
    except Exception as exc:
        log_exception(exc)


MainWindow.show_page = _v4510_show_page


_prev_refresh_current_v4510 = MainWindow.refresh_current


def _v4510_refresh_current(self: MainWindow):
    try:
        return _prev_refresh_current_v4510(self)
    except PermissionError as exc:
        self.notify(str(exc))
        QMessageBox.warning(self, 'صلاحية غير كافية', str(exc))
    except ValueError as exc:
        self.notify(str(exc))
        QMessageBox.warning(self, 'تنبيه', str(exc))
    except Exception as exc:
        log_exception(exc)
        self.notify('حدث خطأ أثناء تحديث الصفحة. راجع ملف السجل logs/app_errors.log')
        QMessageBox.critical(self, 'خطأ غير متوقع', 'حدث خطأ أثناء تحديث الصفحة وتم تسجيله في ملف السجل.')


MainWindow.refresh_current = _v4510_refresh_current


_prev_show_alerts_v4510 = MainWindow.show_alerts_dialog


def _v4510_show_alerts_dialog(self: MainWindow):
    try:
        return _prev_show_alerts_v4510(self)
    finally:
        for dlg in self.findChildren(QDialog):
            _apply_widget_stability(dlg)


MainWindow.show_alerts_dialog = _v4510_show_alerts_dialog
