from __future__ import annotations

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

try:
    from PySide6.QtWidgets import QDateEdit, QTimeEdit, QDateTimeEdit, QPlainTextEdit, QSizePolicy, QMenu
except Exception:  # pragma: no cover
    QDateEdit = QTimeEdit = QDateTimeEdit = QPlainTextEdit = QSizePolicy = QMenu = None

_ORIG_INIT = ToolsPage.__init__
_ORIG_REFRESH = getattr(ToolsPage, 'refresh', None)

LIGHT_TOOLS_QSS = r'''
/* v45.17.4.22 - light performance tools layout: no hard reset, no broad all-widget reset */
ToolsPage QLineEdit,
ToolsPage QComboBox,
ToolsPage QSpinBox,
ToolsPage QDoubleSpinBox,
ToolsPage QDateEdit,
ToolsPage QTimeEdit,
ToolsPage QDateTimeEdit {
    background: #ffffff;
    color: #111827;
    border: 1px solid #b8c2d1;
    border-radius: 8px;
    padding: 8px 12px;
    min-height: 38px;
    selection-background-color: #2563eb;
    selection-color: #ffffff;
}
ToolsPage QTextEdit,
ToolsPage QPlainTextEdit {
    background: #ffffff;
    color: #111827;
    border: 1px solid #b8c2d1;
    border-radius: 8px;
    padding: 8px 12px;
    min-height: 78px;
    selection-background-color: #2563eb;
    selection-color: #ffffff;
}
ToolsPage QLineEdit:focus,
ToolsPage QComboBox:focus,
ToolsPage QSpinBox:focus,
ToolsPage QDoubleSpinBox:focus,
ToolsPage QDateEdit:focus,
ToolsPage QTimeEdit:focus,
ToolsPage QDateTimeEdit:focus,
ToolsPage QTextEdit:focus,
ToolsPage QPlainTextEdit:focus {
    border: 1px solid #2563eb;
    background: #ffffff;
    color: #111827;
}
ToolsPage QLabel {
    color: #1f2937;
    background: transparent;
}
ToolsPage QPushButton {
    min-height: 34px;
    padding: 7px 12px;
}
ToolsPage QTableWidget {
    background: #ffffff;
    color: #111827;
    alternate-background-color: #f8fafc;
    gridline-color: #e2e8f0;
}
ToolsPage QHeaderView::section {
    background: #f1f5f9;
    color: #0f172a;
    padding: 7px;
    border: 1px solid #e2e8f0;
    font-weight: 800;
}
ToolsPage QTabBar::tab {
    min-height: 28px;
    padding: 7px 12px;
    margin: 2px;
}
QMenu[toolsMenu="true"] {
    background: #ffffff;
    color: #111827;
    border: 1px solid #d0d7e2;
    border-radius: 8px;
    padding: 8px;
    min-width: 320px;
}
QMenu[toolsMenu="true"]::item {
    padding: 8px 16px 8px 24px;
    margin: 1px 3px;
    border-radius: 6px;
}
QMenu[toolsMenu="true"]::item:selected {
    background: #eef6ff;
    color: #0f172a;
}
QMenu[toolsMenu="true"]::separator {
    height: 1px;
    background: #e5e7eb;
    margin: 6px 5px;
}
'''


def _safe_log(exc: Exception) -> None:
    try:
        log_exception(exc)
    except Exception:
        pass


def _light_polish_widget(w: QWidget) -> None:
    try:
        if QSizePolicy is not None and not isinstance(w, (QPushButton, QLabel)):
            w.setSizePolicy(QSizePolicy.Expanding, w.sizePolicy().verticalPolicy())
    except Exception:
        pass
    try:
        if isinstance(w, QLineEdit):
            if w.minimumHeight() < 38:
                w.setMinimumHeight(38)
            if w.minimumWidth() < 190:
                w.setMinimumWidth(190)
            w.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            w.setClearButtonEnabled(True)
            if not w.placeholderText():
                w.setPlaceholderText('اكتب هنا...')
        elif isinstance(w, QComboBox):
            if w.minimumHeight() < 38:
                w.setMinimumHeight(38)
            if w.minimumWidth() < 190:
                w.setMinimumWidth(190)
            w.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        elif isinstance(w, (QSpinBox, QDoubleSpinBox)):
            if w.minimumHeight() < 38:
                w.setMinimumHeight(38)
            if w.minimumWidth() < 150:
                w.setMinimumWidth(150)
            w.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        elif QDateEdit is not None and isinstance(w, (QDateEdit, QTimeEdit, QDateTimeEdit)):
            if w.minimumHeight() < 38:
                w.setMinimumHeight(38)
            if w.minimumWidth() < 160:
                w.setMinimumWidth(160)
            w.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        elif isinstance(w, QTextEdit) or (QPlainTextEdit is not None and isinstance(w, QPlainTextEdit)):
            if w.minimumHeight() < 78:
                w.setMinimumHeight(78)
            if w.minimumWidth() < 220:
                w.setMinimumWidth(220)
    except Exception as exc:
        _safe_log(exc)


def _light_polish_layouts(page: ToolsPage) -> None:
    # Keep this intentionally light: no repeated full reset, no inline stylesheet per field.
    for cls in (QFormLayout, QGridLayout, QHBoxLayout, QVBoxLayout):
        try:
            layouts = page.findChildren(cls)
        except Exception:
            layouts = []
        for layout in layouts:
            try:
                if layout.spacing() < 8:
                    layout.setSpacing(8)
                if isinstance(layout, QFormLayout):
                    layout.setHorizontalSpacing(max(layout.horizontalSpacing(), 12))
                    layout.setVerticalSpacing(max(layout.verticalSpacing(), 10))
                    layout.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)
                    layout.setRowWrapPolicy(QFormLayout.WrapLongRows)
                    layout.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
                elif isinstance(layout, QGridLayout):
                    layout.setHorizontalSpacing(max(layout.horizontalSpacing(), 10))
                    layout.setVerticalSpacing(max(layout.verticalSpacing(), 10))
            except Exception as exc:
                _safe_log(exc)


def _light_polish_misc(page: ToolsPage) -> None:
    for btn in page.findChildren(QPushButton):
        try:
            if btn.minimumHeight() < 34:
                btn.setMinimumHeight(34)
            btn.setCursor(Qt.PointingHandCursor)
        except Exception:
            pass
    for table in page.findChildren(QTableWidget):
        try:
            table.setAlternatingRowColors(True)
            table.setWordWrap(False)
            table.setTextElideMode(Qt.ElideRight)
            table.verticalHeader().setDefaultSectionSize(max(table.verticalHeader().defaultSectionSize(), 32))
            table.horizontalHeader().setMinimumSectionSize(90)
            table.horizontalHeader().setStretchLastSection(True)
        except Exception as exc:
            _safe_log(exc)
    for tabs in page.findChildren(QTabWidget):
        try:
            tabs.setUsesScrollButtons(True)
            tabs.setElideMode(Qt.ElideRight)
        except Exception:
            pass
    if QMenu is not None:
        for menu in page.findChildren(QMenu):
            try:
                menu.setProperty('toolsMenu', 'true')
            except Exception:
                pass


def _light_polish(page: ToolsPage) -> None:
    try:
        marker = '/* v45.17.4.22 light performance tools layout */'
        old = page.styleSheet() or ''
        if marker not in old:
            page.setStyleSheet(old + '\n' + marker + '\n' + LIGHT_TOOLS_QSS)
    except Exception as exc:
        _safe_log(exc)
    _light_polish_layouts(page)
    for cls in (QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTextEdit):
        try:
            widgets = page.findChildren(cls)
        except Exception:
            widgets = []
        for w in widgets:
            _light_polish_widget(w)
    if QPlainTextEdit is not None:
        for w in page.findChildren(QPlainTextEdit):
            _light_polish_widget(w)
    if QDateEdit is not None:
        for cls in (QDateEdit, QTimeEdit, QDateTimeEdit):
            try:
                widgets = page.findChildren(cls)
            except Exception:
                widgets = []
            for w in widgets:
                _light_polish_widget(w)
    _light_polish_misc(page)


def _init(self, service, notify, current_user=None):
    _ORIG_INIT(self, service, notify, current_user)
    _light_polish(self)
    try:
        QTimer.singleShot(250, lambda: _light_polish(self))
    except Exception:
        pass


def _refresh(self):
    if _ORIG_REFRESH:
        _ORIG_REFRESH(self)
    _light_polish(self)


ToolsPage.__init__ = _init
ToolsPage.refresh = _refresh
