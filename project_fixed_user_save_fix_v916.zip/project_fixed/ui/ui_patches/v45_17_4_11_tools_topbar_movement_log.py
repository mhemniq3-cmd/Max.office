from __future__ import annotations

from ui.ui_common import *
from ui.main_window_core import MainWindow
from ui.pages.tools_page import ToolsPage

_ORIG_MW_INIT = MainWindow.__init__
_ORIG_RESIZE = getattr(MainWindow, 'resizeEvent', None)
_ORIG_TOOLS_INIT = ToolsPage.__init__
_ORIG_TOOLS_REFRESH = getattr(ToolsPage, 'refresh', None)


def _remove_topbar_tools_button(window: MainWindow) -> None:
    """Remove only the topbar Tools drop-down, not the main Tools page button."""
    try:
        top = window.findChild(QFrame, 'topbar')
        if top is None:
            return
        for btn in list(top.findChildren(QPushButton)):
            text = (btn.text() or '').strip()
            tip = (btn.toolTip() or '').strip()
            has_menu = btn.menu() is not None
            if ('الأدوات' in text or 'قائمة أدوات' in tip) and has_menu:
                btn.setVisible(False)
                btn.setParent(None)
                btn.deleteLater()
    except Exception as exc:
        log_exception(exc)


def _remove_sidebar_movement_button(window: MainWindow) -> None:
    """Remove the extra movement log button from main sidebar; it stays inside Tools."""
    try:
        sidebar = window.findChild(QFrame, 'sidebar')
        if sidebar is None:
            return
        for btn in list(sidebar.findChildren(QPushButton)):
            text = (btn.text() or '').strip()
            # Do not touch the regular Tools page button; remove only explicit movement log button.
            if 'سجل الحركات' in text:
                btn.setVisible(False)
                btn.setParent(None)
                btn.deleteLater()
    except Exception as exc:
        log_exception(exc)


def _ensure_tools_has_movement_log(page: ToolsPage) -> None:
    try:
        if not hasattr(page, 'tabs'):
            return
        idx = -1
        for i in range(page.tabs.count()):
            title = page.tabs.tabText(i).strip()
            if title in ('سجل العمليات', 'سجل الحركات') or 'سجل الحركات' in title or 'سجل العمليات' in title:
                idx = i
                break
        if idx < 0:
            tab = QWidget()
            layout = QVBoxLayout(tab)
            layout.setContentsMargins(10, 10, 10, 10)
            layout.setSpacing(8)
            page.tabs.addTab(tab, 'سجل الحركات')
            idx = page.tabs.count() - 1
        else:
            tab = page.tabs.widget(idx)
            page.tabs.setTabText(idx, 'سجل الحركات')
            layout = tab.layout()
            if layout is None:
                layout = QVBoxLayout(tab)
        if getattr(page, '_v4517411_movement_ui_installed', False):
            return

        # Remove/replace old 4-column table if present, but keep widget alive safely by detaching.
        old = getattr(page, 'logs_table', None)
        if old is not None:
            try:
                old.setParent(None)
            except Exception:
                pass

        title = QLabel('📜 سجل الحركات الشامل')
        title.setObjectName('sectionTitle')
        note = QLabel('يعرض حركات النظام من جميع المصادر: سجل العمليات، التدقيق، المخزون، الاحتيال، القسائم، والفواتير. استخدم البحث لتتبع أي عملية بسرعة.')
        note.setObjectName('noticeBox')
        note.setWordWrap(True)

        filters = QHBoxLayout()
        page.v4517411_movement_search = QLineEdit()
        page.v4517411_movement_search.setPlaceholderText('بحث في المستخدم، العملية، الجدول، التفاصيل...')
        page.v4517411_movement_search.setMinimumHeight(38)
        page.v4517411_movement_source = QComboBox()
        page.v4517411_movement_source.setMinimumHeight(38)
        page.v4517411_movement_source.addItems(['كل المصادر', 'activity_logs', 'audit_trail', 'audit_logs', 'inventory_movements', 'fraud_alerts', 'db_trigger'])
        refresh = QPushButton('تحديث سجل الحركات')
        refresh.setObjectName('primaryButton')
        refresh.setMinimumHeight(38)
        refresh.clicked.connect(page.v4517411_refresh_movement_log)
        filters.addWidget(refresh)
        filters.addWidget(page.v4517411_movement_source)
        filters.addWidget(page.v4517411_movement_search, 1)

        page.logs_table = Table(['الوقت', 'المصدر', 'المستخدم', 'العملية', 'الجدول/السجل', 'التفاصيل'])
        page.logs_table.setObjectName('systemMovementsTable')
        page.logs_table.setMinimumHeight(380)
        try:
            page.logs_table.horizontalHeader().setStretchLastSection(True)
        except Exception:
            pass

        # Clear existing layout content to avoid duplicate hidden empty areas.
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None)
        layout.addWidget(title)
        layout.addWidget(note)
        layout.addLayout(filters)
        layout.addWidget(page.logs_table, 1)
        page.v4517411_movement_search.returnPressed.connect(page.v4517411_refresh_movement_log)
        page.v4517411_movement_source.currentTextChanged.connect(lambda *_: page.v4517411_refresh_movement_log())
        page._v4517411_movement_ui_installed = True
    except Exception as exc:
        log_exception(exc)


def _refresh_movement_log(page: ToolsPage) -> None:
    try:
        if not hasattr(page, 'logs_table'):
            return
        term = ''
        src = ''
        if hasattr(page, 'v4517411_movement_search'):
            term = page.v4517411_movement_search.text().strip()
        if hasattr(page, 'v4517411_movement_source'):
            s = page.v4517411_movement_source.currentText().strip()
            src = '' if s == 'كل المصادر' else s
        if hasattr(page.service, 'list_system_movements'):
            rows = page.service.list_system_movements(1000, term, src)
        else:
            rows = page.service.list_activity_logs(1000, term)
        page.logs_table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            try:
                table_ref = f"{row.get('table_name','') or ''} {row.get('record_id','') or ''}".strip()
                vals = [
                    row.get('event_time') or row.get('created_at') or '',
                    row.get('source') or '',
                    row.get('username') or '',
                    row.get('action') or '',
                    table_ref,
                    row.get('details') or '',
                ]
            except Exception:
                vals = ['', '', '', '', '', str(row)]
            for c, v in enumerate(vals):
                page.logs_table.put(r, c, v)
    except Exception as exc:
        log_exception(exc)


def _mw_init(self, *args, **kwargs):
    _ORIG_MW_INIT(self, *args, **kwargs)
    _remove_topbar_tools_button(self)
    _remove_sidebar_movement_button(self)
    try:
        self.notify('تم نقل سجل الحركات إلى داخل الأدوات وإزالة قائمة الأدوات من الشريط العلوي')
    except Exception:
        pass


def _resize_event(self, event):
    if _ORIG_RESIZE:
        _ORIG_RESIZE(self, event)
    else:
        super(MainWindow, self).resizeEvent(event)
    _remove_topbar_tools_button(self)
    _remove_sidebar_movement_button(self)


def _tools_init(self, service, notify, current_user=None):
    _ORIG_TOOLS_INIT(self, service, notify, current_user)
    _ensure_tools_has_movement_log(self)
    _refresh_movement_log(self)


def _tools_refresh(self):
    if _ORIG_TOOLS_REFRESH:
        _ORIG_TOOLS_REFRESH(self)
    _ensure_tools_has_movement_log(self)
    _refresh_movement_log(self)


MainWindow.__init__ = _mw_init
MainWindow.resizeEvent = _resize_event
ToolsPage.__init__ = _tools_init
ToolsPage.refresh = _tools_refresh
ToolsPage.v4517411_refresh_movement_log = _refresh_movement_log
