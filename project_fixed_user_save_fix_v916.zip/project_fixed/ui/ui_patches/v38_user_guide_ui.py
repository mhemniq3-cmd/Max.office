"""V38: full end-user guide inside Tools page."""
from pathlib import Path
import webbrowser

from ui.ui_common import *
from services.error_logger import log_exception
from ui.pages.tools_page import ToolsPage

GUIDE_MD_PATH = Path('docs/دليل_استخدام_نظام_ماكس_للمبيعات.md')
GUIDE_HTML_PATH = Path('docs/دليل_استخدام_نظام_ماكس_للمبيعات.html')

GUIDE_HTML = r'''
<div dir="rtl" style="font-family:Tahoma, Arial; font-size:14px; line-height:1.85; color:#111827">
<h2 style="color:#0f766e">دليل استخدام نظام ماكس للمبيعات</h2>
<p>هذا الدليل يشرح أهم خطوات تشغيل النظام اليومية للمدير والكاشير والمحاسب.</p>

<h3>1) طريقة إضافة منتج</h3>
<ol>
<li>افتح صفحة <b>المنتجات والمخزون</b>.</li>
<li>اضغط <b>منتج جديد</b> إذا كانت الحقول تحتوي بيانات قديمة.</li>
<li>أدخل الاسم، الباركود، الصنف، سعر التكلفة، سعر البيع، الكمية، الحد الأدنى، وتاريخ الانتهاء عند الحاجة.</li>
<li>اضغط <b>حفظ المنتج</b>.</li>
</ol>
<p><b>ملاحظة:</b> إذا كان المنتج مرتبطًا بحركات، يتم تعطيله بدل حذفه للحفاظ على التقارير.</p>

<h3>2) طريقة البيع</h3>
<ol>
<li>افتح <b>البيع السريع</b> أو <b>كاشير لمس</b>.</li>
<li>امسح الباركود أو ابحث باسم المنتج.</li>
<li>اختر الزبون وطريقة الدفع ومستوى السعر عند الحاجة.</li>
<li>راجع الكمية والخصم والإجمالي.</li>
<li>اضغط <b>إتمام البيع</b>.</li>
</ol>
<p>النظام يمنع بيع كمية أكبر من المخزون، ويطبق العروض ومستويات الأسعار تلقائيًا.</p>

<h3>3) طريقة المرتجع</h3>
<ol>
<li>افتح صفحة <b>المرتجعات</b>.</li>
<li>اكتب رقم الفاتورة أو اختر الفاتورة من التقارير.</li>
<li>اختر المنتج والكمية المراد إرجاعها.</li>
<li>اكتب سبب المرتجع ثم اضغط حفظ.</li>
</ol>
<p>يتم إرجاع الكمية إلى المخزون وعكس الربح والعمولة حسب الفاتورة.</p>

<h3>4) طريقة الديون</h3>
<ul>
<li>البيع الآجل يضيف دينًا على الزبون تلقائيًا.</li>
<li>من صفحة الزبائن والديون يمكن تسجيل دفعة للزبون.</li>
<li>لا يسمح النظام بدفعة أكبر من الدين أو بدفعة عندما يكون الدين صفرًا.</li>
<li>يمكن طباعة أو تصدير كشف حساب الزبون عند الحاجة.</li>
</ul>

<h3>5) طريقة العروض</h3>
<ul>
<li>افتح <b>الأدوات → لوحة العروض والأسعار</b>.</li>
<li>أضف مستويات أسعار مثل مفرد، جملة، VIP.</li>
<li>اربط أسعارًا خاصة بالمنتج حسب المستوى والكمية.</li>
<li>أنشئ عروضًا على منتج، صنف، فترة محددة، خصم كمية، أو اشترِ X واحصل على Y.</li>
<li>تابع العروض النشطة والقادمة والمنتهية والمتوقفة وإحصائيات الاستخدام.</li>
</ul>

<h3>6) طريقة النسخ الاحتياطي</h3>
<ul>
<li>من الأدوات اضغط <b>إنشاء نسخة احتياطية</b>.</li>
<li>يمكن تفعيل نسخة يومية ونسخة عند الإغلاق.</li>
<li>اختبر سلامة النسخة قبل الاعتماد عليها.</li>
<li>احتفظ بنسخة خارج الجهاز بشكل دوري.</li>
</ul>

<h3>7) طريقة المزامنة السحابية</h3>
<ol>
<li>افتح <b>الأدوات → مزامنة سحابية</b>.</li>
<li>ضع رابط السيرفر الذي ينتهي بـ <code>/api/sync</code>.</li>
<li>ضع معرف المحل واسم المحل ومفتاح API.</li>
<li>اضغط <b>حفظ الإعدادات</b> ثم <b>إرسال الآن</b>.</li>
<li>بعد نجاح الإرسال اضغط <b>تشغيل تلقائي</b>.</li>
</ol>
<p>المزامنة ترسل ملخصات فقط، ولا ترسل كلمات المرور أو قاعدة البيانات كاملة.</p>

<h3>8) طريقة استخدام لوحة Render</h3>
<ul>
<li>افتح رابط Render الرئيسي بدون <code>/api/sync</code>.</li>
<li>سجّل الدخول باسم المدير وكلمة المرور التي وضعتها في Render.</li>
<li>تأكد من ضبط المتغيرات: <code>MAX_SALES_CLOUD_API_KEY</code> و <code>MAX_SALES_CLOUD_ADMIN_USER</code> و <code>MAX_SALES_CLOUD_ADMIN_PASSWORD</code> و <code>MAX_SALES_CLOUD_TIMEZONE=Asia/Baghdad</code>.</li>
<li>إذا ظهرت رسالة Service waking up، انتظر قليلًا ثم حدّث الصفحة.</li>
</ul>

<h3>9) صلاحيات المستخدمين</h3>
<ul>
<li>أنشئ أدوارًا مثل: مدير، كاشير، محاسب، مخزن، مشرف، مستخدم تقارير فقط.</li>
<li>لا تعطِ الكاشير صلاحية رؤية التكلفة أو الربح.</li>
<li>اجعل إلغاء الفاتورة، إعادة الطباعة، استرجاع النسخة، وإدارة العروض بصلاحية مدير أو مشرف.</li>
<li>راجع سجل العمليات عند حدوث أي مشكلة.</li>
</ul>

<h3>10) الدعم الفني</h3>
<p>إذا واجهت أي مشكلة يرجى التواصل مع الدعم الفني <b>07805245980</b></p>
<p><b>© PY : MOHIMEN MAX</b></p>
</div>
'''


def _v38_open_guide_file(self):
    try:
        path = GUIDE_HTML_PATH if GUIDE_HTML_PATH.exists() else GUIDE_MD_PATH
        if not path.exists():
            QMessageBox.warning(self, 'الدليل غير موجود', 'لم يتم العثور على ملف دليل الاستخدام داخل مجلد docs.')
            return
        webbrowser.open(path.resolve().as_uri())
    except Exception as exc:
        log_exception(exc)
        QMessageBox.warning(self, 'تعذر فتح الدليل', 'تعذر فتح ملف دليل الاستخدام. تم تسجيل التفاصيل في logs/error.log')


def _v38_add_user_guide_tab(self):
    try:
        if not hasattr(self, 'tabs'):
            return
        for i in range(self.tabs.count()):
            if self.tabs.tabText(i) == 'دليل الاستخدام الكامل':
                return
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)
        header = QLabel('📘 دليل استخدام نظام ماكس للمبيعات')
        header.setObjectName('sectionTitle')
        note = QLabel('دليل مختصر وواضح لأهم العمليات اليومية. يوجد أيضًا ملف HTML وMarkdown داخل مجلد docs يمكن إرساله أو طباعته للمستخدم.')
        note.setWordWrap(True)
        note.setObjectName('noticeBox')
        btns = QHBoxLayout()
        open_btn = QPushButton('فتح ملف الدليل في المتصفح')
        open_btn.setObjectName('primaryButton')
        open_btn.clicked.connect(lambda: _v38_open_guide_file(self))
        btns.addWidget(open_btn)
        btns.addStretch(1)
        txt = QTextEdit()
        txt.setReadOnly(True)
        txt.setHtml(GUIDE_HTML)
        layout.addWidget(header)
        layout.addWidget(note)
        layout.addLayout(btns)
        layout.addWidget(txt, 1)
        self.tabs.addTab(tab, 'دليل الاستخدام الكامل')
    except Exception as exc:
        log_exception(exc)


_old_tools_init_v38 = ToolsPage.__init__

def _v38_tools_init(self, service: AppService, notify, current_user=None):
    _old_tools_init_v38(self, service, notify, current_user)
    _v38_add_user_guide_tab(self)


ToolsPage.__init__ = _v38_tools_init
ToolsPage.v38_open_guide_file = _v38_open_guide_file
