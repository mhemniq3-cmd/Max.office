from __future__ import annotations

from ui.ui_common import *
from ui.main_window_core import MainWindow
from ui.pages.tools_page import ToolsPage
from PySide6.QtCore import QSettings, QByteArray
from PySide6.QtGui import QShortcut, QKeySequence, QAction
from PySide6.QtWidgets import QMenu, QToolTip

_ORIG_MW_INIT = MainWindow.__init__
_ORIG_UPDATE_ALERT = MainWindow.update_alert_button
_ORIG_TOOLS_INIT = ToolsPage.__init__
_ORIG_TOOLS_REFRESH = getattr(ToolsPage, 'refresh', None)
_ORIG_TABLE_INIT = Table.__init__
_ORIG_TABLE_PUT = Table.put

_SETTINGS_ORG = 'MaxSales'
_SETTINGS_APP = 'MaxSalesQtPro'


def _settings() -> QSettings:
    return QSettings(_SETTINGS_ORG, _SETTINGS_APP)


def _safe_key(text: str) -> str:
    text = ''.join(ch if ch.isalnum() else '_' for ch in str(text or ''))
    return text[:120] or 'table'


def _table_key(table: QTableWidget) -> str:
    try:
        name = table.objectName() or ''
        headers = []
        for i in range(table.columnCount()):
            item = table.horizontalHeaderItem(i)
            headers.append(item.text() if item else str(i))
        return 'tables/' + _safe_key(name + '_' + '_'.join(headers))
    except Exception:
        return 'tables/unknown'


def _save_table_state(table: QTableWidget) -> None:
    try:
        st = _settings()
        key = _table_key(table)
        st.setValue(key + '/header', table.horizontalHeader().saveState())
        st.setValue(key + '/sortColumn', table.horizontalHeader().sortIndicatorSection())
        sort_order = table.horizontalHeader().sortIndicatorOrder()
        st.setValue(key + '/sortOrder', sort_order.value if hasattr(sort_order, 'value') else int(sort_order))
    except Exception as exc:
        log_exception(exc)


def _restore_table_state(table: QTableWidget) -> None:
    try:
        st = _settings()
        key = _table_key(table)
        state = st.value(key + '/header')
        if isinstance(state, QByteArray) and not state.isEmpty():
            table.horizontalHeader().restoreState(state)
        col = st.value(key + '/sortColumn')
        order = st.value(key + '/sortOrder')
        if col is not None:
            try:
                table.sortItems(int(col), Qt.SortOrder(int(order or 0)))
            except Exception:
                pass
    except Exception as exc:
        log_exception(exc)


def _table_init(self, headers, parent=None):
    _ORIG_TABLE_INIT(self, headers, parent)
    try:
        self.setSortingEnabled(True)
        self.horizontalHeader().setSectionsMovable(True)
        self.horizontalHeader().sectionMoved.connect(lambda *args, t=self: _save_table_state(t))
        self.horizontalHeader().sectionResized.connect(lambda *args, t=self: _save_table_state(t))
        self.horizontalHeader().sortIndicatorChanged.connect(lambda *args, t=self: _save_table_state(t))
        QTimer.singleShot(0, lambda t=self: _restore_table_state(t))
    except Exception as exc:
        log_exception(exc)


def _table_put(self, row, col, text, data=None):
    item = _ORIG_TABLE_PUT(self, row, col, text, data)
    try:
        # Keep Arabic tables readable after repeated refreshes.
        self.setMinimumHeight(max(self.minimumHeight(), 250))
        self.setAlternatingRowColors(True)
    except Exception:
        pass
    return item


def _find_tab_index(tabs: QTabWidget, names: tuple[str, ...]) -> int:
    wanted = [n.strip() for n in names if n]
    for i in range(tabs.count()):
        title = tabs.tabText(i).strip()
        if title in wanted:
            return i
    for i in range(tabs.count()):
        title = tabs.tabText(i).strip()
        if any(w in title for w in wanted):
            return i
    return -1


def _show_tools_tab(window: MainWindow, *names: str) -> None:
    try:
        window.show_page('tools')
        page = window.pages.get('tools')
        if page and hasattr(page, 'tabs'):
            idx = _find_tab_index(page.tabs, tuple(names))
            if idx >= 0:
                page.tabs.setCurrentIndex(idx)
    except Exception as exc:
        log_exception(exc)


def _new_invoice(window: MainWindow) -> None:
    try:
        window.show_page('sales')
        page = window.pages.get('sales')
        for method in ('new_invoice', 'clear_sale', 'clear_cart', 'reset_form'):
            if hasattr(page, method):
                getattr(page, method)()
                break
        window.notify('فاتورة جديدة')
    except Exception as exc:
        log_exception(exc)


def _save_current(window: MainWindow) -> None:
    try:
        page = window.stack.currentWidget()
        for method in ('save', 'save_current', 'save_product', 'save_customer', 'save_settings', 'complete_sale'):
            if hasattr(page, method):
                getattr(page, method)()
                window.notify('تم تنفيذ الحفظ من الاختصار')
                return
        window.notify('لا توجد عملية حفظ متاحة في هذه الصفحة')
    except Exception as exc:
        QMessageBox.warning(window, 'تعذر الحفظ', str(exc))


def _print_current(window: MainWindow) -> None:
    try:
        page = window.stack.currentWidget()
        for method in ('print_current', 'print_invoice', 'print_report', 'export_pdf', 'export_receipt_pdf'):
            if hasattr(page, method):
                getattr(page, method)()
                window.notify('تم تنفيذ أمر الطباعة')
                return
        _show_tools_tab(window, 'طباعة وأرشفة', 'الطباعة المباشرة', 'طباعة الفواتير والأرشفة')
    except Exception as exc:
        QMessageBox.warning(window, 'تعذر الطباعة', str(exc))


def _toggle_focus(window: MainWindow) -> None:
    try:
        sidebar = window.findChild(QFrame, 'sidebar')
        if sidebar is not None:
            hidden = not sidebar.isHidden()
            sidebar.setHidden(hidden)
            window.notify('تم تفعيل وضع التركيز' if hidden else 'تم إلغاء وضع التركيز')
    except Exception as exc:
        log_exception(exc)


def _build_tools_menu(window: MainWindow) -> QMenu:
    menu = QMenu(window)
    menu.setTitle('الأدوات')
    groups = [
        ('⚡ الإجراءات السريعة', [
            ('فاتورة جديدة', lambda: _new_invoice(window)),
            ('طباعة', lambda: _print_current(window)),
            ('تصدير / تقارير', lambda: _show_tools_tab(window, 'تقارير قوية', 'أداء القسائم')),
        ]),
        ('🎁 القسائم والخصومات', [
            ('الكوبونات', lambda: _show_tools_tab(window, 'الكوبونات')),
            ('العروض المتقدمة', lambda: _show_tools_tab(window, 'العروض المتقدمة')),
            ('تقارير الخصومات', lambda: _show_tools_tab(window, 'أداء القسائم', 'تقارير قوية')),
        ]),
        ('🛡️ الأمان والحماية', [
            ('سجل الحركات', lambda: _show_tools_tab(window, 'سجل الحركات', 'سجل العمليات')),
            ('سجل التدقيق', lambda: _show_tools_tab(window, 'سجل التدقيق', 'سجل التدقيق v2')),
            ('كشف الاحتيال', lambda: _show_tools_tab(window, 'كشف الاحتيال', 'ملخصات الاحتيال')),
            ('سلامة التدقيق', lambda: _show_tools_tab(window, 'سلامة التدقيق')),
        ]),
        ('📊 التقارير والتحليل', [
            ('لوحة تحكم تفاعلية', lambda: _show_tools_tab(window, 'لوحة تحكم تفاعلية')),
            ('تنبيهات ذكية', lambda: _show_tools_tab(window, 'تنبيهات ذكية')),
            ('AI Assistant', lambda: window.show_page('ai')),
        ]),
        ('⚙️ الإعدادات والصيانة', [
            ('إعدادات الشركة', lambda: _show_tools_tab(window, 'إعدادات الشركة')),
            ('النسخ الاحتياطي والباركود', lambda: _show_tools_tab(window, 'نسخ وباركود', 'باركود متقدم')),
            ('صحة النظام', lambda: _show_tools_tab(window, 'فحص النظام', 'صحة النظام')),
        ]),
    ]
    for group_title, actions in groups:
        group_menu = menu.addMenu(group_title)
        for label, callback in actions:
            action = QAction(label, group_menu)
            action.triggered.connect(callback)
            group_menu.addAction(action)
    return menu


def _add_top_tools_menu(window: MainWindow) -> None:
    try:
        if getattr(window, '_v451749_tools_menu_installed', False):
            return
        top = window.findChild(QFrame, 'topbar')
        if top is None or top.layout() is None:
            return
        btn = QPushButton('⚙️ الأدوات')
        btn.setObjectName('primaryButton')
        btn.setCursor(Qt.PointingHandCursor)
        btn.setMenu(_build_tools_menu(window))
        btn.setToolTip('قائمة أدوات متدرجة ومنظمة')
        top.layout().insertWidget(2, btn)
        window._v451749_tools_menu_installed = True
    except Exception as exc:
        log_exception(exc)


def _add_movement_log_button(window: MainWindow) -> None:
    try:
        if getattr(window, '_v451749_movement_button_installed', False):
            return
        sidebar = window.findChild(QFrame, 'sidebar')
        if sidebar is None or sidebar.layout() is None:
            return
        btn = QPushButton('📜 سجل الحركات')
        btn.setObjectName('navButton')
        btn.setCursor(Qt.PointingHandCursor)
        btn.setToolTip('فتح سجل الحركات والعمليات')
        btn.clicked.connect(lambda: _show_tools_tab(window, 'سجل الحركات', 'سجل العمليات'))
        layout = sidebar.layout()
        insert_at = max(0, layout.count() - 2)
        layout.insertWidget(insert_at, btn)
        window._v451749_movement_button_installed = True
    except Exception as exc:
        log_exception(exc)


def _install_shortcuts(window: MainWindow) -> None:
    try:
        if getattr(window, '_v451749_shortcuts_installed', False):
            return
        shortcuts = [
            ('Ctrl+N', lambda: _new_invoice(window)),
            ('Ctrl+S', lambda: _save_current(window)),
            ('Ctrl+P', lambda: _print_current(window)),
            ('F5', window.refresh_current),
            ('Alt+A', lambda: _show_tools_tab(window, 'إعدادات الشركة')),
            ('Ctrl+F11', lambda: _toggle_focus(window)),
        ]
        window._v451749_shortcuts = []
        for seq, callback in shortcuts:
            sc = QShortcut(QKeySequence(seq), window)
            sc.activated.connect(callback)
            window._v451749_shortcuts.append(sc)
        window._v451749_shortcuts_installed = True
    except Exception as exc:
        log_exception(exc)


def _add_focus_button(window: MainWindow) -> None:
    try:
        top = window.findChild(QFrame, 'topbar')
        if top is None or top.layout() is None or getattr(window, '_v451749_focus_btn_installed', False):
            return
        btn = QPushButton('◱ تركيز')
        btn.setObjectName('secondaryButton')
        btn.setCursor(Qt.PointingHandCursor)
        btn.setToolTip('إخفاء القائمة الجانبية للشاشات الصغيرة - Ctrl+F11')
        btn.clicked.connect(lambda: _toggle_focus(window))
        top.layout().insertWidget(3, btn)
        window._v451749_focus_btn_installed = True
    except Exception as exc:
        log_exception(exc)


def _unread_security_count(window: MainWindow) -> int:
    try:
        count = 0
        for table, field in [('fraud_alerts', 'status'), ('system_notifications', 'read_at')]:
            exists = window.service.db.one("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
            if not exists:
                continue
            if table == 'fraud_alerts':
                row = window.service.db.one("SELECT COUNT(*) c FROM fraud_alerts WHERE COALESCE(status,'open') IN ('open','جديد','مفتوح')")
            else:
                row = window.service.db.one("SELECT COUNT(*) c FROM system_notifications WHERE read_at IS NULL")
            count += int(row['c'] or 0)
        return count
    except Exception:
        return 0


def _mw_init(self, *args, **kwargs):
    _ORIG_MW_INIT(self, *args, **kwargs)
    _install_shortcuts(self)
    _add_top_tools_menu(self)
    _add_movement_log_button(self)
    _add_focus_button(self)
    try:
        self.notify('اختصارات مفعلة: Ctrl+N فاتورة، Ctrl+S حفظ، Ctrl+P طباعة، F5 تحديث، Alt+A أدوات، Ctrl+F11 تركيز')
    except Exception:
        pass


def _update_alert_button(self):
    _ORIG_UPDATE_ALERT(self)
    try:
        sec = _unread_security_count(self)
        if sec:
            current = self.alert_btn.text()
            self.alert_btn.setText(f'{current}  🛡 {sec}')
            self.alert_btn.setProperty('danger', True)
            self.alert_btn.style().unpolish(self.alert_btn)
            self.alert_btn.style().polish(self.alert_btn)
        tools_btn = self.buttons.get('tools') if hasattr(self, 'buttons') else None
        if tools_btn is not None:
            base = tools_btn.text().split('  ●')[0]
            tools_btn.setText(f'{base}  ●{sec}' if sec else base)
            tools_btn.setProperty('danger', bool(sec))
            tools_btn.style().unpolish(tools_btn)
            tools_btn.style().polish(tools_btn)
    except Exception as exc:
        log_exception(exc)


def _polish_tools_layout(page: ToolsPage) -> None:
    try:
        for tabs in page.findChildren(QTabWidget):
            tabs.setDocumentMode(True)
            tabs.setMovable(False)
        for edit in page.findChildren(QLineEdit):
            edit.setMinimumHeight(max(edit.minimumHeight(), 36))
            edit.setClearButtonEnabled(True)
        for combo in page.findChildren(QComboBox):
            combo.setMinimumHeight(max(combo.minimumHeight(), 36))
        for spin in page.findChildren(QDoubleSpinBox):
            spin.setMinimumHeight(max(spin.minimumHeight(), 36))
        for spin in page.findChildren(QSpinBox):
            spin.setMinimumHeight(max(spin.minimumHeight(), 36))
        for btn in page.findChildren(QPushButton):
            btn.setMinimumHeight(max(btn.minimumHeight(), 36))
            btn.setCursor(Qt.PointingHandCursor)
        for table in page.findChildren(QTableWidget):
            table.setMinimumHeight(max(table.minimumHeight(), 260))
        for form in page.findChildren(QFormLayout):
            form.setHorizontalSpacing(max(form.horizontalSpacing(), 12))
            form.setVerticalSpacing(max(form.verticalSpacing(), 10))
            form.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
    except Exception as exc:
        log_exception(exc)


def _rename_or_add_movement_tab(page: ToolsPage) -> None:
    try:
        if not hasattr(page, 'tabs'):
            return
        log_idx = _find_tab_index(page.tabs, ('سجل العمليات',))
        movement_idx = _find_tab_index(page.tabs, ('سجل الحركات',))
        if log_idx >= 0 and movement_idx < 0:
            page.tabs.setTabText(log_idx, 'سجل الحركات')
    except Exception as exc:
        log_exception(exc)


def _tools_init(self, service, notify, current_user=None):
    _ORIG_TOOLS_INIT(self, service, notify, current_user)
    _rename_or_add_movement_tab(self)
    _polish_tools_layout(self)


def _tools_refresh(self):
    if _ORIG_TOOLS_REFRESH:
        _ORIG_TOOLS_REFRESH(self)
    _rename_or_add_movement_tab(self)
    _polish_tools_layout(self)


Table.__init__ = _table_init
Table.put = _table_put
MainWindow.__init__ = _mw_init
MainWindow.update_alert_button = _update_alert_button
ToolsPage.__init__ = _tools_init
ToolsPage.refresh = _tools_refresh
