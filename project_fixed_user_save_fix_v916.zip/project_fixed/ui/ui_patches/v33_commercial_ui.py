from __future__ import annotations

import os, subprocess, sys
from datetime import date
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QBrush
from PySide6.QtWidgets import QCheckBox, QComboBox, QDialog, QFormLayout, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QScrollArea, QSpinBox, QDoubleSpinBox, QTabWidget, QVBoxLayout, QWidget, QFrame, QInputDialog

from database import money
from ui.ui_common import Table, MetricCard, PERM_LABELS
from ui.pages.products_page import ProductsPage
from ui.pages.reports_page import ReportsPage
from ui.pages.tools_page import ToolsPage
from ui.pages.users_page import UsersPage
from ui.main_window_core import MainWindow
from services.error_logger import log_exception

EXTRA_PERMS = {'can_reprint_invoice':'إعادة طباعة فاتورة','can_cancel_invoice':'إلغاء فاتورة','can_receive_debt_payment':'تسديد دين','can_manage_promotions':'إدارة العروض'}
PERM_LABELS.update(EXTRA_PERMS)

def friendly(page, exc):
    try: return page.service.user_message(exc)
    except Exception: log_exception(exc); return str(exc) or 'حدث خطأ. تم تسجيل التفاصيل.'

# Products page: filters + row colors + safe disable

def p_build(self):
    root=QHBoxLayout(self); root.setSpacing(14); root.setContentsMargins(8,8,8,8)
    left=QFrame(); left.setObjectName('surface'); ll=QVBoxLayout(left); ll.setContentsMargins(14,14,14,14)
    title=QLabel('📦 المنتجات والمخزون'); title.setObjectName('sectionTitle')
    filters=QFrame(); filters.setObjectName('innerCard'); fl=QGridLayout(filters)
    self.search=QLineEdit(); self.search.setPlaceholderText('بحث بالاسم أو الباركود أو الصنف...')
    self.category_filter=QComboBox(); self.category_filter.addItem('كل التصنيفات','')
    self.stock_filter=QComboBox(); self.stock_filter.addItems(['المنتجات النشطة','منتجات ناقصة','نافدة من المخزون','قاربت على الانتهاء','منتهية الصلاحية','معطلة','الكل'])
    self.low_only=QCheckBox('منتجات ناقصة'); self.expired_only=QCheckBox('منتجات منتهية')
    for w in (self.search,self.category_filter,self.stock_filter,self.low_only,self.expired_only):
        try: w.currentIndexChanged.connect(self.refresh)
        except Exception: pass
    self.search.textChanged.connect(self.refresh)
    self.low_only.stateChanged.connect(lambda: (self.stock_filter.setCurrentText('منتجات ناقصة') if self.low_only.isChecked() else self.refresh()))
    self.expired_only.stateChanged.connect(lambda: (self.stock_filter.setCurrentText('منتهية الصلاحية') if self.expired_only.isChecked() else self.refresh()))
    fl.addWidget(QLabel('بحث'),0,0); fl.addWidget(self.search,0,1,1,3); fl.addWidget(QLabel('الصنف'),1,0); fl.addWidget(self.category_filter,1,1); fl.addWidget(QLabel('الحالة'),1,2); fl.addWidget(self.stock_filter,1,3); fl.addWidget(self.low_only,2,1); fl.addWidget(self.expired_only,2,2)
    self.table=Table(['الباركود','المنتج','الصنف','شراء','بيع','كمية','تنبيه','انتهاء','الحالة']); self.table.doubleClicked.connect(self.load_selected)
    ll.addWidget(title); ll.addWidget(filters); ll.addWidget(self.table,1)
    right_scroll=QScrollArea(); right_scroll.setWidgetResizable(True); right_scroll.setFixedWidth(500)
    right=QFrame(); right.setObjectName('surface'); right_scroll.setWidget(right); rl=QVBoxLayout(right); rl.setContentsMargins(16,16,16,16)
    self.barcode=QLineEdit(); self.barcode.setPlaceholderText('باركود'); self.barcode.returnPressed.connect(self.handle_product_barcode_scan)
    self.name=QLineEdit(); self.category=QLineEdit()
    self.cost=QDoubleSpinBox(); self.cost.setMaximum(999999999); self.cost.setDecimals(0); self.cost.setButtonSymbols(QSpinBox.NoButtons)
    self.price=QDoubleSpinBox(); self.price.setMaximum(999999999); self.price.setDecimals(0); self.price.setButtonSymbols(QSpinBox.NoButtons)
    self.qty=QSpinBox(); self.qty.setMaximum(9999999); self.qty.setButtonSymbols(QSpinBox.NoButtons)
    self.min_qty=QSpinBox(); self.min_qty.setMaximum(9999999); self.min_qty.setValue(5); self.min_qty.setButtonSymbols(QSpinBox.NoButtons)
    self.comm=QDoubleSpinBox(); self.comm.setRange(0,100); self.comm.setDecimals(2); self.comm.setSuffix(' %'); self.comm.setButtonSymbols(QSpinBox.NoButtons)
    self.adjust_qty=QSpinBox(); self.adjust_qty.setMaximum(9999999); self.adjust_note=QLineEdit(); self.adjust_note.setPlaceholderText('سبب تعديل المخزون')
    form=QFormLayout(); form.setLabelAlignment(Qt.AlignRight)
    for label,w in [('الباركود',self.barcode),('اسم المنتج',self.name),('الصنف',self.category),('شراء',self.cost),('بيع',self.price),('كمية',self.qty),('حد التنبيه',self.min_qty),('عمولة',self.comm)]: form.addRow(label,w)
    grid=QGridLayout();
    b_save=QPushButton('💾 حفظ'); b_save.setObjectName('primaryButton'); b_save.clicked.connect(self.save)
    b_new=QPushButton('➕ جديد'); b_new.clicked.connect(self.clear)
    b_del=QPushButton('🗑 تعطيل المنتج'); b_del.setObjectName('dangerButton'); b_del.clicked.connect(self.deactivate)
    b_lbl=QPushButton('🏷 طباعة باركود'); b_lbl.clicked.connect(self.print_labels)
    b_bar=QPushButton('توليد باركود'); b_bar.clicked.connect(self.generate_barcode)
    b_adj=QPushButton('⚠ تعديل المخزون'); b_adj.setObjectName('warningButton'); b_adj.clicked.connect(self.adjust_inventory)
    b_imp=QPushButton('⬆ استيراد Excel'); b_imp.clicked.connect(getattr(self,'import_excel',lambda: QMessageBox.information(self,'Excel','استيراد Excel متاح من تبويب العروض والأسعار.')))
    b_exp=QPushButton('⬇ تصدير Excel'); b_exp.clicked.connect(getattr(self,'export_excel',lambda: QMessageBox.information(self,'Excel','تصدير Excel متاح من تبويب العروض والأسعار.')))
    for i,b in enumerate([b_save,b_new,b_del,b_imp,b_exp,b_lbl,b_bar]): grid.addWidget(b,i//2,i%2)
    grid.addWidget(QLabel('الكمية الجديدة'),4,0); grid.addWidget(self.adjust_qty,4,1); grid.addWidget(QLabel('ملاحظة'),5,0); grid.addWidget(self.adjust_note,5,1); grid.addWidget(b_adj,6,0,1,2)
    rl.addLayout(form); rl.addLayout(grid); rl.addStretch(); root.addWidget(left,1); root.addWidget(right_scroll); self.product_id=None

def p_state(self):
    return {'المنتجات النشطة':'active','منتجات ناقصة':'low','نافدة من المخزون':'out','قاربت على الانتهاء':'expiring','منتهية الصلاحية':'expired','معطلة':'inactive','الكل':'all'}.get(self.stock_filter.currentText(),'active')

def p_load_categories(self):
    if getattr(self,'_cats_loaded',False): return
    self._cats_loaded=True; self.category_filter.blockSignals(True); self.category_filter.clear(); self.category_filter.addItem('كل التصنيفات','')
    try:
        for c in self.service.product_categories(): self.category_filter.addItem(c,c)
    except Exception as exc: log_exception(exc)
    self.category_filter.blockSignals(False)

def p_refresh(self):
    try:
        p_load_categories(self); rows=self.service.list_products(self.search.text(), self.category_filter.currentData() or '', p_state(self)); self.rows=rows; self.table.setRowCount(len(rows))
        for r,p in enumerate(rows):
            vals=[p.get('barcode') or '',p.get('name') or '',p.get('category') or '',money(p.get('cost_price',0)),money(p.get('sale_price',0)),p.get('quantity',0),p.get('min_quantity',0),p.get('expiry_date') or '-','نشط' if p.get('active',1) else 'معطل']
            expired=bool(p.get('expiry_date') and str(p.get('expiry_date')) < date.today().isoformat()); low=bool(p.get('active',1) and int(p.get('quantity') or 0) <= int(p.get('min_quantity') or 0)); inactive=not bool(p.get('active',1))
            bg=QColor('#E5E7EB') if inactive else QColor('#FECACA') if expired else QColor('#FEF3C7') if low else None
            for c,v in enumerate(vals):
                it=self.table.put(r,c,v,p.get('id') if c==0 else None)
                if bg: it.setBackground(QBrush(bg))
    except Exception as exc: QMessageBox.warning(self,'تعذر تحديث المنتجات',friendly(self,exc))

def p_save(self):
    try:
        self.service.save_product({'barcode':self.barcode.text(),'name':self.name.text(),'category':self.category.text(),'cost_price':self.cost.value(),'sale_price':self.price.value(),'quantity':self.qty.value(),'min_quantity':self.min_qty.value(),'commission_percent':self.comm.value()}, self.product_id)
        self.clear(); self._cats_loaded=False; self.refresh(); self.notify('تم حفظ المنتج')
    except Exception as exc: QMessageBox.warning(self,'تعذر حفظ المنتج',friendly(self,exc))

def p_deactivate(self):
    if not self.product_id: return
    reason,ok=QInputDialog.getText(self,'سبب التعطيل','اكتب سبب تعطيل المنتج:')
    if not ok: return
    try: msg=self.service.delete_or_deactivate_product(self.product_id, reason=reason); self.clear(); self.refresh(); self.notify(msg)
    except Exception as exc: QMessageBox.warning(self,'تعذر التعطيل',friendly(self,exc))
ProductsPage.build=p_build; ProductsPage.refresh=p_refresh; ProductsPage.save=p_save; ProductsPage.deactivate=p_deactivate

# Extra user permissions + safe deactivate reason
_orig_users_build=UsersPage.build
def u_build(self):
    _orig_users_build(self)
    try:
        tab=QWidget(); grid=QGridLayout(tab); row=col=0
        for k,label in EXTRA_PERMS.items():
            cb=QCheckBox(label); self.checks[k]=cb; grid.addWidget(cb,row,col); col+=1
            if col>=2: row+=1; col=0
        self.perm_tabs.addTab(tab,'صلاحيات تجارية')
    except Exception as exc: log_exception(exc)
def u_deact(self):
    if not self.user_id: return
    reason,ok=QInputDialog.getText(self,'سبب التعطيل','اكتب سبب تعطيل المستخدم:')
    if not ok: return
    try: msg=self.service.delete_or_deactivate_user(self.user_id, reason=reason); self.clear(); self.refresh(); self.notify(msg)
    except Exception as exc: QMessageBox.warning(self,'تعذر التعطيل',friendly(self,exc))
UsersPage.build=u_build; UsersPage.deactivate=u_deact

# Daily report tab
_orig_reports_init=ReportsPage.__init__
def r_init(self, service, notify=None):
    _orig_reports_init(self, service, notify); tab=QWidget(); lay=QVBoxLayout(tab); top=QHBoxLayout(); self.daily_date=QLineEdit(date.today().isoformat())
    b_show=QPushButton('عرض'); b_show.setObjectName('primaryButton'); b_show.clicked.connect(self.refresh_daily_report)
    b_html=QPushButton('طباعة PDF/HTML'); b_html.clicked.connect(self.export_daily_report_html)
    b_xls=QPushButton('تصدير Excel'); b_xls.setObjectName('successButton'); b_xls.clicked.connect(self.export_daily_report_excel)
    top.addWidget(QLabel('التاريخ')); top.addWidget(self.daily_date); top.addWidget(b_show); top.addWidget(b_html); top.addWidget(b_xls); top.addStretch()
    self.daily_cards=[MetricCard(x) for x in ['إجمالي المبيعات','عدد الفواتير','صافي الربح','المصاريف','المرتجعات','الدفعات المستلمة']]
    cards=QGridLayout();
    for i,c in enumerate(self.daily_cards): cards.addWidget(c,i//3,i%3)
    self.daily_top_products=Table(['المنتج','الكمية','الإجمالي']); self.daily_best_cashier=Table(['الكاشير','الفواتير','المبيعات'])
    bottom=QHBoxLayout(); bottom.addWidget(self.daily_top_products,1); bottom.addWidget(self.daily_best_cashier,1)
    lay.addLayout(top); lay.addLayout(cards); lay.addLayout(bottom,1); self.tabs.addTab(tab,'تقرير يومي احترافي')
    try: self.refresh_daily_report()
    except Exception as exc: log_exception(exc)
def r_refresh(self):
    try:
        r=self.service.daily_business_report(self.daily_date.text().strip()); vals=[money(r['sales_total']),str(r['invoice_count']),money(r['net_profit']),money(r['expenses']),money(r['returns']),money(r['payments_received'])]
        for card,val in zip(self.daily_cards, vals): card.set_value(val)
        self.daily_top_products.setRowCount(len(r['top_products']))
        for i,x in enumerate(r['top_products']):
            for c,v in enumerate([x['product_name'],x['qty'],money(x['total'])]): self.daily_top_products.put(i,c,v)
        self.daily_best_cashier.setRowCount(len(r['best_cashiers']))
        for i,x in enumerate(r['best_cashiers']):
            for c,v in enumerate([x['cashier'],x['invoices'],money(x['total'])]): self.daily_best_cashier.put(i,c,v)
    except Exception as exc: QMessageBox.warning(self,'تعذر التقرير',friendly(self,exc))
def r_html(self):
    try: QMessageBox.information(self,'تم',f"تم إنشاء التقرير:\n{self.service.export_daily_report_html(self.daily_date.text().strip())}")
    except Exception as exc: QMessageBox.warning(self,'تعذر التصدير',friendly(self,exc))
def r_xls(self):
    try: QMessageBox.information(self,'تم',f"تم إنشاء Excel:\n{self.service.export_daily_report_excel(self.daily_date.text().strip())}")
    except Exception as exc: QMessageBox.warning(self,'تعذر التصدير',friendly(self,exc))
ReportsPage.__init__=r_init; ReportsPage.refresh_daily_report=r_refresh; ReportsPage.export_daily_report_html=r_html; ReportsPage.export_daily_report_excel=r_xls

# Tools: backup health + promotion states
_orig_tools_init=ToolsPage.__init__
def t_init(self, service, notify, current_user=None):
    _orig_tools_init(self, service, notify, current_user); self.add_backup_health_tab(); self.add_promo_status_tab()
def t_backup_tab(self):
    tab=QWidget(); lay=QVBoxLayout(tab); self.backup_health_label=QLabel(''); self.backup_health_label.setObjectName('noticeBox'); self.backup_health_label.setWordWrap(True)
    row=QHBoxLayout(); b_make=QPushButton('إنشاء نسخة الآن'); b_make.clicked.connect(self.v33_make_backup); b_test=QPushButton('اختبار سلامة آخر نسخة'); b_test.clicked.connect(self.v33_test_backup); b_open=QPushButton('فتح مجلد النسخ'); b_open.clicked.connect(self.v33_open_backups)
    row.addWidget(b_make); row.addWidget(b_test); row.addWidget(b_open); row.addStretch(); self.auto_close=QCheckBox('نسخة عند الإغلاق'); self.daily_backup=QCheckBox('نسخة يومية'); b_save=QPushButton('حفظ إعدادات النسخ'); b_save.clicked.connect(self.v33_save_backup_settings)
    lay.addWidget(self.backup_health_label); lay.addLayout(row); lay.addWidget(self.auto_close); lay.addWidget(self.daily_backup); lay.addWidget(b_save); lay.addStretch(); self.tabs.addTab(tab,'صحة النسخ الاحتياطي'); self.v33_refresh_backup()
def t_refresh_backup(self):
    try:
        h=self.service.backup_health(); self.backup_health_label.setText(f"{h['message']}\nآخر نسخة: {h.get('last') or '-'}"); st=self.service.get_settings(); self.auto_close.setChecked(st.get('auto_backup_on_close','1')=='1'); self.daily_backup.setChecked(st.get('daily_backup_enabled','1')=='1')
    except Exception as exc: self.backup_health_label.setText(friendly(self,exc))
def t_make(self):
    try: QMessageBox.information(self,'تم',f"تم إنشاء نسخة:\n{self.service.backup_database()}"); self.v33_refresh_backup()
    except Exception as exc: QMessageBox.warning(self,'تعذر النسخ',friendly(self,exc))
def t_test(self):
    ok,msg=self.service.test_backup_integrity(); (QMessageBox.information if ok else QMessageBox.warning)(self,'فحص النسخة',msg)
def t_open(self):
    p=Path('backups').resolve(); p.mkdir(exist_ok=True)
    try:
        if sys.platform.startswith('win'): os.startfile(str(p))
        elif sys.platform=='darwin': subprocess.Popen(['open',str(p)])
        else: subprocess.Popen(['xdg-open',str(p)])
    except Exception as exc: QMessageBox.warning(self,'تعذر فتح المجلد',friendly(self,exc))
def t_save(self):
    try: self.service.save_settings({'auto_backup_on_close':'1' if self.auto_close.isChecked() else '0','daily_backup_enabled':'1' if self.daily_backup.isChecked() else '0'}); self.notify('تم حفظ إعدادات النسخ')
    except Exception as exc: QMessageBox.warning(self,'تعذر الحفظ',friendly(self,exc))
def t_promos(self):
    tab=QWidget(); lay=QVBoxLayout(tab); b=QPushButton('تحديث'); b.clicked.connect(self.v33_refresh_promos); self.promo_tables={}; self.promos_tabs=QTabWidget()
    for k,l in [('active','العروض النشطة'),('upcoming','العروض القادمة'),('expired','العروض المنتهية')]:
        table=Table(['العرض','النطاق','النوع','القيمة','من','إلى','الحالة']); self.promo_tables[k]=table; self.promos_tabs.addTab(table,l)
    lay.addWidget(b); lay.addWidget(self.promos_tabs,1); self.tabs.addTab(tab,'حالة العروض'); self.v33_refresh_promos()
def t_refresh_promos(self):
    try:
        for k,rows in self.service.promotions_by_status().items():
            table=self.promo_tables[k]; table.setRowCount(len(rows))
            for r,p in enumerate(rows):
                vals=[p.get('name',''),p.get('scope_type',''),p.get('promo_type',''),p.get('discount_value') or f"{p.get('buy_qty',0)}+{p.get('free_qty',0)}",p.get('start_date') or '-',p.get('end_date') or '-','نشط' if p.get('active') else 'معطل']
                for c,v in enumerate(vals): table.put(r,c,v)
    except Exception as exc: QMessageBox.warning(self,'تعذر تحديث العروض',friendly(self,exc))
ToolsPage.__init__=t_init; ToolsPage.add_backup_health_tab=t_backup_tab; ToolsPage.v33_refresh_backup=t_refresh_backup; ToolsPage.v33_make_backup=t_make; ToolsPage.v33_test_backup=t_test; ToolsPage.v33_open_backups=t_open; ToolsPage.v33_save_backup_settings=t_save; ToolsPage.add_promo_status_tab=t_promos; ToolsPage.v33_refresh_promos=t_refresh_promos

# backup on close
_orig_close=MainWindow.closeEvent
def close_event(self,event):
    try: self.service.backup_on_close_if_enabled()
    except Exception as exc: log_exception(exc)
    _orig_close(self,event)
MainWindow.closeEvent=close_event
