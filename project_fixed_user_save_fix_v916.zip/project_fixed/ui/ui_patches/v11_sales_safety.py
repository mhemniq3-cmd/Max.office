from __future__ import annotations

from pathlib import Path
import html
import os

from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.theme_manager import apply_theme as theme_apply, current_theme_key as theme_current_key, set_theme_key as theme_set_key, theme_label as theme_display_label, theme_path as theme_qss_path
from ui.main_window_core import *

def _v11_sale_review_text(page, touch: bool = False) -> str:
    subtotal = 0.0
    for item in page.cart:
        subtotal += float(item.get('quantity', 0)) * float(item.get('unit_price', 0))
    discount = float(page.discount.value() or 0)
    if not touch and hasattr(page, 'current_discount_amount'):
        discount = float(page.current_discount_amount() or 0)
    net = max(subtotal - discount, 0)
    employee = page.employee.currentText() if hasattr(page, 'employee') else '-'
    customer = page.customer.currentText() if hasattr(page, 'customer') else '-'
    payment = page.payment.currentText() if hasattr(page, 'payment') else '-'
    return (f'راجع بيانات البيع قبل الحفظ:\n\n'
            f'عدد المواد: {len(page.cart)}\n'
            f'الإجمالي قبل الخصم: {money(subtotal)}\n'
            f'الخصم: {money(discount)}\n'
            f'الصافي قبل الضريبة: {money(net)}\n'
            f'طريقة الدفع: {payment}\n'
            f'الزبون: {customer}\n'
            f'موظف العمولة: {employee}\n\n'
            f'هل تريد تأكيد البيع؟')

_orig_sales_complete_sale_v11 = SalesPage.complete_sale

def _sales_complete_sale_v11(self):
    if not self.cart:
        QMessageBox.warning(self, 'تنبيه', 'السلة فارغة')
        return
    if QMessageBox.question(self, 'مراجعة قبل البيع', _v11_sale_review_text(self, False)) != QMessageBox.Yes:
        return
    return _orig_sales_complete_sale_v11(self)

SalesPage.complete_sale = _sales_complete_sale_v11

_orig_touch_complete_v11 = TouchPOSPage.complete

def _touch_complete_v11(self):
    if not self.cart:
        QMessageBox.warning(self, 'تنبيه', 'السلة فارغة')
        return
    if QMessageBox.question(self, 'مراجعة قبل البيع', _v11_sale_review_text(self, True)) != QMessageBox.Yes:
        return
    return _orig_touch_complete_v11(self)

TouchPOSPage.complete = _touch_complete_v11

_orig_tools_init_v11 = ToolsPage.__init__

def _tools_init_v11(self, service: AppService, notify, current_user=None):
    _orig_tools_init_v11(self, service, notify, current_user)
    self.build_safety_core_tab()
    self.build_daily_close_tab()
    self.refresh()

ToolsPage.__init__ = _tools_init_v11


def _tools_build_safety_core_tab_v11(self):
    tab = QWidget(); layout = QVBoxLayout(tab)
    title = QLabel('🛡 فحص صحة النظام ومنع الأخطاء')
    title.setObjectName('sectionTitle')
    info = QLabel('يفحص هذا القسم الفواتير، الخصومات، المرتجعات، المخزون، الديون، والباركودات لاكتشاف الأخطاء قبل أن تكبر.')
    info.setWordWrap(True); info.setObjectName('noticeBox')
    run = QPushButton('تشغيل فحص النظام الآن')
    run.setObjectName('warningButton')
    run.clicked.connect(self.run_safety_health_check)
    self.health_table = Table(['المستوى', 'المشكلة', 'التفاصيل'])
    layout.addWidget(title); layout.addWidget(info); layout.addWidget(run); layout.addWidget(self.health_table, 1)
    self.tabs.addTab(tab, '🛡 فحص النظام')

ToolsPage.build_safety_core_tab = _tools_build_safety_core_tab_v11


def _tools_run_safety_health_check_v11(self):
    rows = self.service.system_health_check()
    self.health_table.setRowCount(len(rows))
    for r, row in enumerate(rows):
        vals = [row.get('level',''), row.get('title',''), row.get('details','')]
        for c, v in enumerate(vals):
            self.health_table.put(r, c, v)
    self.notify('تم فحص صحة النظام')

ToolsPage.run_safety_health_check = _tools_run_safety_health_check_v11


def _tools_build_daily_close_tab_v11(self):
    tab = QWidget(); layout = QVBoxLayout(tab)
    title = QLabel('📌 الإغلاق اليومي للمحاسبة')
    title.setObjectName('sectionTitle')
    form = QHBoxLayout()
    from datetime import datetime as _dt
    self.close_date = QLineEdit(_dt.now().strftime('%Y-%m-%d'))
    self.close_date.setPlaceholderText('YYYY-MM-DD')
    self.counted_cash = QDoubleSpinBox(); self.counted_cash.setMaximum(999999999999); self.counted_cash.setDecimals(0)
    self.close_note = QLineEdit(); self.close_note.setPlaceholderText('ملاحظة الإغلاق')
    summary = QPushButton('عرض ملخص اليوم'); summary.setObjectName('primaryButton'); summary.clicked.connect(self.show_daily_close_summary)
    close = QPushButton('إغلاق اليوم'); close.setObjectName('dangerButton'); close.clicked.connect(self.close_daily_accounting)
    for w in [QLabel('التاريخ'), self.close_date, QLabel('النقد المعدود'), self.counted_cash, self.close_note, summary, close]:
        form.addWidget(w)
    self.daily_close_table = Table(['التاريخ','المستخدم','مبيعات نقدية','مبيعات آجلة','مرتجعات','خصومات','أرباح','فواتير','النقد المعدود','فرق الصندوق','ملاحظة'])
    layout.addWidget(title); layout.addLayout(form); layout.addWidget(self.daily_close_table, 1)
    self.tabs.addTab(tab, '📌 إغلاق يومي')

ToolsPage.build_daily_close_tab = _tools_build_daily_close_tab_v11


def _tools_show_daily_close_summary_v11(self):
    data = self.service.daily_close_summary(self.close_date.text())
    QMessageBox.information(self, 'ملخص اليوم',
        f"التاريخ: {data['date']}\n"
        f"عدد الفواتير: {data['invoices']}\n"
        f"مبيعات نقدية: {money(data['cash_sales'])}\n"
        f"مبيعات آجلة: {money(data['credit_sales'])}\n"
        f"المرتجعات: {money(data['returns_amount'])}\n"
        f"الخصومات: {money(data['discounts'])}\n"
        f"الأرباح: {money(data['profit'])}\n"
        f"الصندوق المتوقع: {money(data['expected_cash'])}")

ToolsPage.show_daily_close_summary = _tools_show_daily_close_summary_v11


def _tools_close_daily_accounting_v11(self):
    if QMessageBox.question(self, 'تأكيد الإغلاق', 'بعد الإغلاق لن يستطيع الموظفون تعديل أو إرجاع عمليات هذا اليوم إلا بصلاحية مدير. هل تريد المتابعة؟') != QMessageBox.Yes:
        return
    try:
        self.service.close_day(self.close_date.text(), self.counted_cash.value(), self.close_note.text())
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر الإغلاق', str(exc)); return
    self.close_note.clear(); self.refresh(); self.notify('تم إغلاق اليوم المحاسبي')

ToolsPage.close_daily_accounting = _tools_close_daily_accounting_v11

_orig_tools_refresh_v11 = ToolsPage.refresh

def _tools_refresh_v11(self):
    _orig_tools_refresh_v11(self)
    if hasattr(self, 'daily_close_table'):
        rows = self.service.daily_closings()
        self.daily_close_table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            vals = [row['close_date'], row['user_name'], money(row['cash_sales']), money(row['credit_sales']), money(row['returns_amount']), money(row['discounts_amount']), money(row['profit_amount']), row['invoices_count'], money(row['counted_cash']), money(row['cash_difference']), row['note'] or '']
            for c, v in enumerate(vals): self.daily_close_table.put(r, c, v)
    if hasattr(self, 'health_table') and self.health_table.rowCount() == 0:
        # Do not run full checks on every refresh; show a friendly placeholder.
        self.health_table.setRowCount(1)
        self.health_table.put(0, 0, 'معلومة'); self.health_table.put(0, 1, 'اضغط تشغيل فحص النظام الآن'); self.health_table.put(0, 2, 'سيظهر التقرير هنا')

ToolsPage.refresh = _tools_refresh_v11

# ================================================================
# V20 GOOGLE DRIVE UI SETTINGS FIX
# Makes the selected folder persist immediately and tests the path typed
# in the field directly. This avoids stale DB reads in the UI.
# ================================================================

