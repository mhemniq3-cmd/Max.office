from __future__ import annotations

"""V45.14 UI compatibility for the products page.

Keeps the v44/v33 look. Fixes the quantity defaults and protects refresh/load
against sqlite3.Row/dict differences.
"""

from ui.ui_common import QMessageBox
from ui.pages.products_page import ProductsPage

_old_build = ProductsPage.build
_old_clear = ProductsPage.clear
_old_save = ProductsPage.save
_old_refresh = ProductsPage.refresh
_old_load_selected = ProductsPage.load_selected


def _get(row, key, default=None):
    if row is None:
        return default
    if isinstance(row, dict):
        return row.get(key, default)
    try:
        return row[key]
    except Exception:
        try:
            return row.get(key, default)
        except Exception:
            return default


def _v4514_build(self: ProductsPage):
    _old_build(self)
    try:
        # Existing products may legitimately have zero stock, so the field must
        # allow 0 when loading/editing. New-product save still blocks quantity 0.
        self.qty.setMinimum(0)
        if not getattr(self, 'product_id', None):
            self.qty.setValue(1)
        self.adjust_qty.setMinimum(0)
        self.min_qty.setMinimum(0)
        self.price.setMinimum(0)
        self.cost.setMinimum(0)
        self.comm.setRange(0, 100)
        self.search.setPlaceholderText('بحث جزئي: الاسم، الباركود، الصنف...')
    except Exception:
        pass


def _v4514_clear(self: ProductsPage):
    _old_clear(self)
    try:
        self.product_id = None
        self.qty.setMinimum(0)
        self.qty.setValue(1)
        self.adjust_qty.setMinimum(0)
        self.adjust_qty.setValue(0)
        self.min_qty.setMinimum(0)
        self.min_qty.setValue(0)
        self.price.setMinimum(0)
        self.cost.setMinimum(0)
    except Exception:
        pass


def _v4514_save(self: ProductsPage):
    try:
        if not (self.name.text() or '').strip():
            QMessageBox.warning(self, 'بيانات ناقصة', 'اسم المنتج مطلوب')
            return
        if float(self.price.value()) <= 0:
            QMessageBox.warning(self, 'بيانات ناقصة', 'سعر البيع يجب أن يكون أكبر من صفر')
            return
        if not getattr(self, 'product_id', None) and int(self.qty.value()) <= 0:
            QMessageBox.warning(self, 'بيانات ناقصة', 'لا يمكن إضافة مادة جديدة بكمية صفر. أدخل كمية افتتاحية أكبر من صفر.')
            return
    except Exception:
        pass
    _old_save(self)
    try:
        self.refresh()
    except Exception:
        pass


def _v4514_refresh(self: ProductsPage):
    _old_refresh(self)
    try:
        # Old commercial refresh stores rows in self.rows. Now they are dicts,
        # but keep this fallback for any custom database call that returns Row.
        self.rows = [dict(r) if hasattr(r, 'keys') and not isinstance(r, dict) else r for r in (getattr(self, 'rows', []) or [])]
        for r, p in enumerate(self.rows):
            qty = int(_get(p, 'quantity', 0) or 0)
            minq = int(_get(p, 'min_quantity', 0) or 0)
            status = 'نافد' if qty <= 0 else 'منخفض' if qty <= minq else ''
            if status:
                item = self.table.item(r, 5)
                if item and status not in item.text():
                    item.setText(f"{item.text()} - {status}")
    except Exception:
        pass


def _v4514_load_selected(self: ProductsPage):
    try:
        row = self.table.currentRow()
        rows = getattr(self, 'rows', []) or []
        if row < 0 or row >= len(rows):
            return
        p = rows[row]
        self.product_id = _get(p, 'id')
        self.barcode.setText(str(_get(p, 'barcode', '') or ''))
        self.name.setText(str(_get(p, 'name', '') or ''))
        self.category.setText(str(_get(p, 'category', '') or ''))
        self.cost.setValue(float(_get(p, 'cost_price', 0) or 0))
        self.price.setValue(float(_get(p, 'sale_price', 0) or 0))
        self.qty.setMinimum(0)
        self.qty.setValue(int(_get(p, 'quantity', 0) or 0))
        self.adjust_qty.setValue(int(_get(p, 'quantity', 0) or 0))
        self.min_qty.setValue(int(_get(p, 'min_quantity', 0) or 0))
        self.comm.setValue(float(_get(p, 'commission_percent', 0) or 0))
    except Exception:
        _old_load_selected(self)


ProductsPage.build = _v4514_build
ProductsPage.clear = _v4514_clear
ProductsPage.save = _v4514_save
ProductsPage.refresh = _v4514_refresh
ProductsPage.load_selected = _v4514_load_selected
