from __future__ import annotations

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

try:
    from PySide6.QtWidgets import QDateEdit, QTimeEdit, QDateTimeEdit, QGroupBox, QPlainTextEdit, QAbstractSpinBox, QSizePolicy, QMenu
except Exception:  # pragma: no cover
    QDateEdit = QTimeEdit = QDateTimeEdit = QGroupBox = QPlainTextEdit = QAbstractSpinBox = QSizePolicy = QMenu = None

_ORIG_INIT = ToolsPage.__init__
_ORIG_REFRESH = getattr(ToolsPage, 'refresh', None)

HTML_LIKE_TOOLS_QSS = r"""
/* v45.17.4.19 - HTML-like form group layout for tools */
ToolsPage {
    background: #f8fafc;
    color: #111827;
    font-size: 13px;
}
ToolsPage QWidget {
    font-size: 13px;
}
ToolsPage QLabel {
    color: #1f2937;
    font-weight: 600;
    padding: 2px 2px;
}
ToolsPage QLabel[formRole="label"] {
    color: #334155;
    font-weight: 800;
    min-width: 135px;
    padding-top: 8px;
}
ToolsPage QLineEdit,
ToolsPage QComboBox,
ToolsPage QSpinBox,
ToolsPage QDoubleSpinBox,
ToolsPage QDateEdit,
ToolsPage QTimeEdit,
ToolsPage QDateTimeEdit {
    min-height: 42px;
    min-width: 220px;
    background: #ffffff;
    color: #0f172a;
    border: 1px solid #cbd5e1;
    border-radius: 10px;
    padding: 8px 12px;
    selection-background-color: #2563eb;
    selection-color: #ffffff;
}
ToolsPage QLineEdit:hover,
ToolsPage QComboBox:hover,
ToolsPage QSpinBox:hover,
ToolsPage QDoubleSpinBox:hover,
ToolsPage QDateEdit:hover,
ToolsPage QTimeEdit:hover,
ToolsPage QDateTimeEdit:hover {
    border-color: #94a3b8;
}
ToolsPage QLineEdit:focus,
ToolsPage QComboBox:focus,
ToolsPage QSpinBox:focus,
ToolsPage QDoubleSpinBox:focus,
ToolsPage QDateEdit:focus,
ToolsPage QTimeEdit:focus,
ToolsPage QDateTimeEdit:focus {
    border: 2px solid #2563eb;
    background: #ffffff;
    color: #0f172a;
}
ToolsPage QTextEdit,
ToolsPage QPlainTextEdit {
    min-height: 115px;
    min-width: 260px;
    background: #ffffff;
    color: #0f172a;
    border: 1px solid #cbd5e1;
    border-radius: 10px;
    padding: 10px 12px;
    selection-background-color: #2563eb;
    selection-color: #ffffff;
}
ToolsPage QTextEdit:focus,
ToolsPage QPlainTextEdit:focus {
    border: 2px solid #2563eb;
}
ToolsPage QLineEdit:disabled,
ToolsPage QComboBox:disabled,
ToolsPage QSpinBox:disabled,
ToolsPage QDoubleSpinBox:disabled,
ToolsPage QTextEdit:disabled,
ToolsPage QPlainTextEdit:disabled {
    background: #f1f5f9;
    color: #64748b;
    border-color: #d8e0ea;
}
ToolsPage QFrame#surface,
ToolsPage QFrame#card,
ToolsPage QGroupBox {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 14px;
    padding: 14px;
    margin-top: 8px;
}
ToolsPage QGroupBox::title {
    color: #0f172a;
    font-weight: 900;
    padding: 0 8px;
    subcontrol-origin: margin;
    subcontrol-position: top right;
}
ToolsPage QPushButton {
    min-height: 40px;
    min-width: 118px;
    padding: 8px 14px;
    border-radius: 10px;
    font-weight: 800;
    color: #0f172a;
    background: #f8fafc;
    border: 1px solid #cbd5e1;
}
ToolsPage QPushButton:hover {
    border-color: #2563eb;
    background: #eef6ff;
}
ToolsPage QPushButton:pressed {
    background: #dbeafe;
}
ToolsPage QPushButton#primaryButton {
    background: #2563eb;
    border-color: #1d4ed8;
    color: #ffffff;
}
ToolsPage QTableWidget {
    background: #ffffff;
    color: #111827;
    alternate-background-color: #f8fafc;
    gridline-color: #e2e8f0;
    border: 1px solid #dbe3ef;
    border-radius: 10px;
}
ToolsPage QTableWidget::item {
    padding: 7px;
    color: #111827;
}
ToolsPage QHeaderView::section {
    background: #f1f5f9;
    color: #0f172a;
    padding: 9px;
    border: 1px solid #e2e8f0;
    font-weight: 900;
}
ToolsPage QTabWidget::pane {
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    background: #ffffff;
    top: -1px;
}
ToolsPage QTabBar::tab {
    min-height: 32px;
    min-width: 105px;
    padding: 8px 16px;
    margin: 2px;
    border-radius: 9px;
    background: #f1f5f9;
    color: #334155;
    font-weight: 800;
}
ToolsPage QTabBar::tab:selected {
    background: #2563eb;
    color: #ffffff;
}
ToolsPage QScrollArea {
    border: none;
    background: transparent;
}
QMenu#v4517419ToolsMenu,
QMenu[toolsMenu="true"] {
    background: #ffffff;
    color: #111827;
    border: 1px solid #e8e8e8;
    border-radius: 8px;
    padding: 12px;
    min-width: 320px;
}
QMenu#v4517419ToolsMenu::item,
QMenu[toolsMenu="true"]::item {
    padding: 9px 18px 9px 28px;
    margin: 2px 4px;
    border-radius: 7px;
}
QMenu#v4517419ToolsMenu::item:selected,
QMenu[toolsMenu="true"]::item:selected {
    background: #eef6ff;
    color: #0f172a;
}
QMenu#v4517419ToolsMenu::separator,
QMenu[toolsMenu="true"]::separator {
    height: 1px;
    background: #e5e7eb;
    margin: 8px 6px;
}
"""


def _safe_log(exc: Exception) -> None:
    try:
        log_exception(exc)
    except Exception:
        pass


def _mark_labels_and_fix_layouts(root: QWidget) -> None:
    for cls in (QFormLayout, QGridLayout, QHBoxLayout, QVBoxLayout):
        try:
            layouts = root.findChildren(cls)
        except Exception:
            layouts = []
        for layout in layouts:
            try:
                layout.setContentsMargins(max(layout.contentsMargins().left(), 12),
                                          max(layout.contentsMargins().top(), 12),
                                          max(layout.contentsMargins().right(), 12),
                                          max(layout.contentsMargins().bottom(), 12))
                layout.setSpacing(max(layout.spacing(), 12))
                if isinstance(layout, QFormLayout):
                    layout.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
                    layout.setRowWrapPolicy(QFormLayout.WrapLongRows)
                    layout.setHorizontalSpacing(max(layout.horizontalSpacing(), 16))
                    layout.setVerticalSpacing(max(layout.verticalSpacing(), 14))
                    layout.setLabelAlignment(Qt.AlignRight | Qt.AlignTop)
                    layout.setFormAlignment(Qt.AlignTop | Qt.AlignRight)
                    for row in range(layout.rowCount()):
                        label_item = layout.itemAt(row, QFormLayout.LabelRole)
                        field_item = layout.itemAt(row, QFormLayout.FieldRole)
                        if label_item and label_item.widget() and isinstance(label_item.widget(), QLabel):
                            label_item.widget().setProperty('formRole', 'label')
                            label_item.widget().style().unpolish(label_item.widget())
                            label_item.widget().style().polish(label_item.widget())
                        if field_item and field_item.widget():
                            _polish_single_field(field_item.widget())
                elif isinstance(layout, QGridLayout):
                    layout.setHorizontalSpacing(max(layout.horizontalSpacing(), 14))
                    layout.setVerticalSpacing(max(layout.verticalSpacing(), 14))
                    for col in range(max(layout.columnCount(), 1)):
                        layout.setColumnStretch(col, 1)
            except Exception as exc:
                _safe_log(exc)


def _polish_single_field(w: QWidget) -> None:
    try:
        if QSizePolicy is not None:
            w.setSizePolicy(QSizePolicy.Expanding, w.sizePolicy().verticalPolicy())
    except Exception:
        pass
    try:
        if isinstance(w, (QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox)):
            w.setMinimumHeight(max(w.minimumHeight(), 42))
            w.setMinimumWidth(max(w.minimumWidth(), 220))
            if isinstance(w, QLineEdit):
                w.setClearButtonEnabled(True)
                w.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
                if not w.placeholderText():
                    w.setPlaceholderText('اكتب هنا...')
            elif isinstance(w, QComboBox):
                w.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
                w.setMinimumContentsLength(max(w.minimumContentsLength(), 14))
            else:
                w.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        elif isinstance(w, (QTextEdit, QPlainTextEdit)):
            w.setMinimumHeight(max(w.minimumHeight(), 115))
            w.setMaximumHeight(max(w.maximumHeight(), 220) if w.maximumHeight() < 220 else w.maximumHeight())
            w.setMinimumWidth(max(w.minimumWidth(), 260))
        elif QDateEdit is not None and isinstance(w, (QDateEdit, QTimeEdit, QDateTimeEdit)):
            w.setMinimumHeight(max(w.minimumHeight(), 42))
            w.setMinimumWidth(max(w.minimumWidth(), 180))
            w.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    except Exception as exc:
        _safe_log(exc)


def _polish_buttons_tables_tabs(root: QWidget) -> None:
    for btn in root.findChildren(QPushButton):
        try:
            btn.setMinimumHeight(max(btn.minimumHeight(), 40))
            btn.setMinimumWidth(max(btn.minimumWidth(), 118))
            btn.setCursor(Qt.PointingHandCursor)
        except Exception:
            pass
    for table in root.findChildren(QTableWidget):
        try:
            table.setMinimumHeight(max(table.minimumHeight(), 285))
            table.setAlternatingRowColors(True)
            table.setWordWrap(False)
            table.setTextElideMode(Qt.ElideRight)
            table.verticalHeader().setDefaultSectionSize(max(table.verticalHeader().defaultSectionSize(), 36))
            table.horizontalHeader().setMinimumSectionSize(100)
            table.horizontalHeader().setDefaultSectionSize(max(table.horizontalHeader().defaultSectionSize(), 140))
            table.horizontalHeader().setStretchLastSection(True)
        except Exception as exc:
            _safe_log(exc)
    for tabs in root.findChildren(QTabWidget):
        try:
            tabs.setUsesScrollButtons(True)
            tabs.setElideMode(Qt.ElideRight)
            tabs.setDocumentMode(True)
        except Exception:
            pass


def _polish_all_fields(page: ToolsPage) -> None:
    try:
        marker = '/* v45.17.4.19 html-like tools layout */'
        old = page.styleSheet() or ''
        if marker not in old:
            page.setStyleSheet(old + '\n' + marker + '\n' + HTML_LIKE_TOOLS_QSS)
    except Exception as exc:
        _safe_log(exc)
    _mark_labels_and_fix_layouts(page)
    for cls in (QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTextEdit, QPlainTextEdit):
        if cls is None:
            continue
        for w in page.findChildren(cls):
            _polish_single_field(w)
    for cls in (QDateEdit, QTimeEdit, QDateTimeEdit):
        if cls is None:
            continue
        for w in page.findChildren(cls):
            _polish_single_field(w)
    _polish_buttons_tables_tabs(page)
    try:
        QTimer.singleShot(350, lambda: _delayed(page))
        QTimer.singleShot(900, lambda: _delayed(page))
    except Exception:
        pass


def _delayed(page: ToolsPage) -> None:
    try:
        _mark_labels_and_fix_layouts(page)
        for cls in (QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTextEdit, QPlainTextEdit):
            if cls is None:
                continue
            for w in page.findChildren(cls):
                _polish_single_field(w)
        for cls in (QDateEdit, QTimeEdit, QDateTimeEdit):
            if cls is None:
                continue
            for w in page.findChildren(cls):
                _polish_single_field(w)
        _polish_buttons_tables_tabs(page)
    except Exception as exc:
        _safe_log(exc)


def _tag_tools_menus(page: ToolsPage) -> None:
    try:
        for menu in page.findChildren(QMenu):
            menu.setObjectName(menu.objectName() or 'v4517419ToolsMenu')
            menu.setProperty('toolsMenu', 'true')
    except Exception:
        pass


def _init(self, service, notify, current_user=None):
    _ORIG_INIT(self, service, notify, current_user)
    _tag_tools_menus(self)
    _polish_all_fields(self)


def _refresh(self):
    if _ORIG_REFRESH:
        _ORIG_REFRESH(self)
    _tag_tools_menus(self)
    _polish_all_fields(self)


ToolsPage.__init__ = _init
ToolsPage.refresh = _refresh
