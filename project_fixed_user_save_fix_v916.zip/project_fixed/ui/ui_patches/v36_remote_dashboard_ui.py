from ui.ui_common import *

from services.remote_dashboard import get_remote_dashboard_manager
from ui.pages.tools_page import ToolsPage


_old_tools_init_v36 = ToolsPage.__init__


def _tools_init_v36(self, service, notify, current_user=None):
    _old_tools_init_v36(self, service, notify, current_user)
    try:
        self.build_remote_dashboard_tab()
    except Exception as exc:
        log_exception(exc, 'build remote dashboard tab')


def _manager(self):
    return get_remote_dashboard_manager(self.service.db.path)


def _build_remote_dashboard_tab(self):
    tab = QWidget()
    layout = QVBoxLayout(tab)
    layout.setContentsMargins(20, 20, 20, 20)
    layout.setSpacing(14)

    title = QLabel('🌐 لوحة التحكم عن بعد من المتصفح')
    title.setObjectName('sectionTitle')
    layout.addWidget(title)

    note = QLabel('هذه الخاصية تفتح لوحة ويب مدمجة داخل النظام بدون برامج خارجية. يمكن استخدامها من نفس الجهاز أو من أجهزة داخل نفس الشبكة حسب الإعداد. لا تفتحها على الإنترنت مباشرة إلا إذا كنت تعرف إعدادات الحماية جيداً.')
    note.setObjectName('noticeBox')
    note.setWordWrap(True)
    layout.addWidget(note)

    form_box = QFrame(); form_box.setObjectName('surface')
    form = QFormLayout(form_box)
    form.setContentsMargins(18, 18, 18, 18)
    form.setSpacing(12)

    self.remote_local_only = QCheckBox('السماح من نفس الجهاز فقط 127.0.0.1')
    self.remote_local_only.setChecked(True)
    self.remote_port = QSpinBox(); self.remote_port.setRange(1024, 65535); self.remote_port.setValue(8765)
    self.remote_user = QLineEdit(); self.remote_user.setText('admin')
    self.remote_password = QLineEdit(); self.remote_password.setEchoMode(QLineEdit.Password)
    self.remote_password.setPlaceholderText('كلمة مرور لوحة الويب')
    self.remote_show_pass = QCheckBox('إظهار كلمة المرور')
    self.remote_show_pass.toggled.connect(lambda checked: self.remote_password.setEchoMode(QLineEdit.Normal if checked else QLineEdit.Password))

    form.addRow('نطاق الوصول', self.remote_local_only)
    form.addRow('المنفذ', self.remote_port)
    form.addRow('اسم الدخول', self.remote_user)
    form.addRow('كلمة المرور', self.remote_password)
    form.addRow('', self.remote_show_pass)
    layout.addWidget(form_box)

    self.remote_status = QLabel('الحالة: متوقفة')
    self.remote_status.setObjectName('noticeBox')
    self.remote_status.setWordWrap(True)
    layout.addWidget(self.remote_status)

    buttons = QHBoxLayout()
    self.remote_start_btn = QPushButton('تشغيل اللوحة')
    self.remote_start_btn.setObjectName('primaryButton')
    self.remote_stop_btn = QPushButton('إيقاف اللوحة')
    self.remote_save_btn = QPushButton('حفظ الإعدادات')
    self.remote_reset_pass_btn = QPushButton('توليد كلمة مرور جديدة')
    self.remote_open_btn = QPushButton('فتح في المتصفح')
    for b in (self.remote_start_btn, self.remote_stop_btn, self.remote_save_btn, self.remote_reset_pass_btn, self.remote_open_btn):
        b.setMinimumHeight(38)
        buttons.addWidget(b)
    layout.addLayout(buttons)

    help_text = QLabel('ملاحظة: إذا اخترت السماح من الشبكة، سيظهر رابط يبدأ بعنوان جهازك داخل الشبكة. يجب أن يكون الهاتف أو الحاسبة الثانية على نفس شبكة الواي فاي/الراوتر.')
    help_text.setWordWrap(True)
    help_text.setObjectName('mutedLabel')
    layout.addWidget(help_text)
    layout.addStretch(1)

    self.remote_start_btn.clicked.connect(self.remote_dashboard_start)
    self.remote_stop_btn.clicked.connect(self.remote_dashboard_stop)
    self.remote_save_btn.clicked.connect(self.remote_dashboard_save)
    self.remote_reset_pass_btn.clicked.connect(self.remote_dashboard_reset_password)
    self.remote_open_btn.clicked.connect(self.remote_dashboard_open)

    self.tabs.addTab(tab, 'لوحة تحكم ويب')
    self.remote_dashboard_load()


def _remote_dashboard_load(self):
    mgr = _manager(self)
    cfg = mgr.config
    self.remote_local_only.setChecked(str(cfg.get('host', '127.0.0.1')) in ('127.0.0.1', 'localhost'))
    self.remote_port.setValue(int(cfg.get('port') or 8765))
    self.remote_user.setText(str(cfg.get('username') or 'admin'))
    self.remote_password.setText(str(cfg.get('password') or ''))
    self.remote_dashboard_update_status()


def _remote_dashboard_update_status(self):
    mgr = _manager(self)
    if mgr.is_running():
        self.remote_status.setText(f'الحالة: تعمل الآن\nالرابط: {mgr.url()}\nاسم الدخول: {mgr.config.get("username", "admin")}')
    else:
        host = '127.0.0.1' if self.remote_local_only.isChecked() else '0.0.0.0'
        shown = '127.0.0.1' if host == '127.0.0.1' else 'عنوان الجهاز داخل الشبكة'
        self.remote_status.setText(f'الحالة: متوقفة\nبعد التشغيل سيكون الرابط على: http://{shown}:{self.remote_port.value()}')


def _remote_dashboard_save(self):
    try:
        host = '127.0.0.1' if self.remote_local_only.isChecked() else '0.0.0.0'
        _manager(self).configure(host, self.remote_port.value(), self.remote_user.text(), self.remote_password.text())
        self.notify('تم حفظ إعدادات لوحة التحكم')
        self.remote_dashboard_update_status()
    except Exception as exc:
        log_exception(exc, 'save remote dashboard settings')
        QMessageBox.warning(self, 'تعذر الحفظ', str(exc))


def _remote_dashboard_start(self):
    try:
        self.remote_dashboard_save()
        _manager(self).start()
        self.remote_dashboard_update_status()
        QMessageBox.information(self, 'تم التشغيل', f'تم تشغيل لوحة التحكم:\n{_manager(self).url()}\n\nاسم الدخول: {_manager(self).config.get("username", "admin")}')
    except Exception as exc:
        log_exception(exc, 'start remote dashboard')
        QMessageBox.warning(self, 'تعذر التشغيل', str(exc))


def _remote_dashboard_stop(self):
    try:
        _manager(self).stop()
        self.remote_dashboard_update_status()
        self.notify('تم إيقاف لوحة التحكم')
    except Exception as exc:
        log_exception(exc, 'stop remote dashboard')
        QMessageBox.warning(self, 'تعذر الإيقاف', str(exc))


def _remote_dashboard_reset_password(self):
    try:
        password = _manager(self).reset_password()
        self.remote_password.setText(password)
        self.remote_dashboard_update_status()
        QMessageBox.information(self, 'كلمة مرور جديدة', f'كلمة مرور لوحة الويب الجديدة:\n{password}')
    except Exception as exc:
        log_exception(exc, 'reset remote dashboard password')
        QMessageBox.warning(self, 'تعذر التوليد', str(exc))


def _remote_dashboard_open(self):
    try:
        import webbrowser
        webbrowser.open(_manager(self).url())
    except Exception as exc:
        log_exception(exc, 'open remote dashboard browser')
        QMessageBox.warning(self, 'تعذر الفتح', str(exc))


ToolsPage.__init__ = _tools_init_v36
ToolsPage.build_remote_dashboard_tab = _build_remote_dashboard_tab
ToolsPage.remote_dashboard_load = _remote_dashboard_load
ToolsPage.remote_dashboard_update_status = _remote_dashboard_update_status
ToolsPage.remote_dashboard_save = _remote_dashboard_save
ToolsPage.remote_dashboard_start = _remote_dashboard_start
ToolsPage.remote_dashboard_stop = _remote_dashboard_stop
ToolsPage.remote_dashboard_reset_password = _remote_dashboard_reset_password
ToolsPage.remote_dashboard_open = _remote_dashboard_open
