from __future__ import annotations

from ui.ui_common import *
from ui.pages.smart_assistant_page import SmartAssistantPage
from ui.pages.tools_page import ToolsPage

_ORIG_TOOLS_INIT = ToolsPage.__init__
_ORIG_TOOLS_REFRESH = getattr(ToolsPage, 'refresh', None)


def _clear_layout(layout):
    while layout.count():
        item = layout.takeAt(0)
        w = item.widget()
        child = item.layout()
        if w is not None:
            w.setParent(None)
        elif child is not None:
            _clear_layout(child)


def _make_button(text, fn=None, primary=False):
    b = QPushButton(text)
    b.setObjectName('primaryButton' if primary else 'secondaryButton')
    b.setCursor(Qt.PointingHandCursor)
    b.setMinimumHeight(38)
    if fn:
        b.clicked.connect(fn)
    return b


def _smart_init(self, service, notify, current_user=None):
    QWidget.__init__(self)
    self.service = service
    self.notify = notify
    self.current_user = current_user
    root = QVBoxLayout(self)
    root.setContentsMargins(12, 12, 12, 12)
    root.setSpacing(10)

    title = QLabel('🤖 المساعد الذكي AI Assistant')
    title.setObjectName('sectionTitle')
    note = QLabel('مساعد محلي داخل النظام: توقع المبيعات، اقتراح الشراء، مراجعة الأسعار، أسئلة شائعة، وتحليل الملاحظات النصية بدون إنترنت.')
    note.setObjectName('noticeBox')
    note.setWordWrap(True)
    root.addWidget(title)
    root.addWidget(note)

    self.ai_tabs = QTabWidget()
    root.addWidget(self.ai_tabs, 1)

    # Forecast tab
    forecast = QWidget(); fl = QVBoxLayout(forecast); fl.setSpacing(8)
    row = QHBoxLayout(); self.ai_days = QSpinBox(); self.ai_days.setRange(14, 365); self.ai_days.setValue(90); self.ai_days.setSuffix(' يوم')
    row.addWidget(_make_button('تحديث توقع المبيعات', self.ai_refresh_forecast, True)); row.addWidget(self.ai_days); row.addStretch()
    self.ai_forecast_table = Table(['المنتج','المخزون','مبيع الفترة','توقع 30 يوم','شراء مقترح','الخطر'])
    fl.addLayout(row); fl.addWidget(self.ai_forecast_table, 1)
    self.ai_tabs.addTab(forecast, 'توقع المبيعات')

    # Prices tab
    prices = QWidget(); pl = QVBoxLayout(prices); pr = QHBoxLayout()
    self.ai_margin = QDoubleSpinBox(); self.ai_margin.setRange(0, 200); self.ai_margin.setValue(10); self.ai_margin.setSuffix(' % هامش/منافسة')
    pr.addWidget(_make_button('اقتراح أسعار', self.ai_refresh_prices, True)); pr.addWidget(self.ai_margin); pr.addStretch()
    self.ai_price_table = Table(['المنتج','التكلفة','السعر الحالي','السعر المقترح','مبيعات','الملاحظة'])
    pl.addLayout(pr); pl.addWidget(self.ai_price_table, 1)
    self.ai_tabs.addTab(prices, 'اقتراح أسعار')

    # Chat tab
    chat = QWidget(); cl = QVBoxLayout(chat)
    cr = QHBoxLayout(); self.ai_question = QLineEdit(); self.ai_question.setPlaceholderText('اسأل: ماذا أشتري؟ كيف أطبع باركود؟ ما المنتجات الراكدة؟')
    cr.addWidget(_make_button('اسأل', self.ai_ask, True)); cr.addWidget(self.ai_question, 1)
    self.ai_answer = QTextEdit(); self.ai_answer.setReadOnly(True); self.ai_answer.setMinimumHeight(220)
    cl.addLayout(cr); cl.addWidget(self.ai_answer, 1)
    self.ai_tabs.addTab(chat, 'روبوت محادثة')

    # Notes tab
    notes = QWidget(); nl = QVBoxLayout(notes)
    self.ai_notes = QTextEdit(); self.ai_notes.setPlaceholderText('اكتب ملاحظات العملاء أو مشاكل المخزون أو السوق هنا ليحللها المساعد...')
    self.ai_notes_result = QTextEdit(); self.ai_notes_result.setReadOnly(True)
    nl.addWidget(QLabel('الملاحظات النصية'))
    nl.addWidget(self.ai_notes, 1)
    nl.addWidget(_make_button('تحليل الملاحظات', self.ai_analyze_notes, True))
    nl.addWidget(self.ai_notes_result, 1)
    self.ai_tabs.addTab(notes, 'تحليل الملاحظات')

    self.ai_refresh_forecast()


def _ai_refresh_forecast(self):
    try:
        rows = self.service.ai_sales_forecast(self.ai_days.value())
        self.ai_forecast_table.setRowCount(len(rows[:150]))
        for r, x in enumerate(rows[:150]):
            vals = [x.get('product_name'), x.get('current_stock'), x.get('sold_qty'), x.get('forecast_30_days'), x.get('suggested_purchase_qty'), x.get('risk')]
            for c, v in enumerate(vals): self.ai_forecast_table.put(r, c, v)
        self.notify('تم تحديث توقع المبيعات')
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر توقع المبيعات', str(exc))


def _ai_refresh_prices(self):
    try:
        rows = self.service.ai_price_suggestions(self.ai_margin.value())
        self.ai_price_table.setRowCount(len(rows[:150]))
        for r, x in enumerate(rows[:150]):
            vals = [x.get('product_name'), money(x.get('cost_price')), money(x.get('current_price')), money(x.get('suggested_price')), x.get('sold_qty'), x.get('note')]
            for c, v in enumerate(vals): self.ai_price_table.put(r, c, v)
        self.notify('تم تحديث اقتراحات الأسعار')
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر اقتراح الأسعار', str(exc))


def _ai_ask(self):
    try:
        self.ai_answer.setPlainText(self.service.ai_faq_answer(self.ai_question.text()))
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر إجابة المساعد', str(exc))


def _ai_analyze_notes(self):
    try:
        self.ai_notes_result.setPlainText(self.service.ai_notes_analysis(self.ai_notes.toPlainText()))
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر تحليل الملاحظات', str(exc))


def _smart_refresh(self):
    if hasattr(self, 'ai_forecast_table'):
        self.ai_refresh_forecast()


def _build_advanced_barcode_tab(self):
    tab = QWidget(); root = QVBoxLayout(tab); root.setSpacing(10)
    intro = QLabel('نظام الباركود المتقدم: QR للفواتير، DataMatrix اختياري، ملصقات مباشرة، ودعم قارئ USB/Bluetooth كإدخال لوحة مفاتيح.')
    intro.setObjectName('noticeBox'); intro.setWordWrap(True); root.addWidget(intro)

    sub = QTabWidget(); root.addWidget(sub, 1)

    # Invoice QR
    inv = QWidget(); il = QVBoxLayout(inv); ir = QHBoxLayout()
    self.v451744_invoice_no = QLineEdit(); self.v451744_invoice_no.setPlaceholderText('رقم الفاتورة لإنشاء QR')
    ir.addWidget(_make_button('إنشاء QR للفاتورة', self.v451744_make_invoice_qr, True)); ir.addWidget(self.v451744_invoice_no, 1)
    self.v451744_invoice_qr_text = QTextEdit(); self.v451744_invoice_qr_text.setReadOnly(True)
    il.addLayout(ir); il.addWidget(self.v451744_invoice_qr_text, 1)
    sub.addTab(inv, 'QR الفواتير')

    # Labels
    lab = QWidget(); ll = QVBoxLayout(lab); lr = QHBoxLayout()
    self.v451744_label_term = QLineEdit(); self.v451744_label_term.setPlaceholderText('بحث بالاسم/الباركود/الصنف أو اتركه فارغاً')
    self.v451744_label_type = QComboBox(); self.v451744_label_type.addItem('QR Code', 'qr'); self.v451744_label_type.addItem('DataMatrix 2D', 'datamatrix')
    self.v451744_copies = QSpinBox(); self.v451744_copies.setRange(1, 20); self.v451744_copies.setValue(1); self.v451744_copies.setSuffix(' نسخة')
    lr.addWidget(_make_button('إنشاء ملصقات وطباعة', self.v451744_print_labels, True)); lr.addWidget(self.v451744_copies); lr.addWidget(self.v451744_label_type); lr.addWidget(self.v451744_label_term, 1)
    self.v451744_label_table = Table(['المنتج','الباركود','الصنف','السعر','المخزون'])
    ll.addLayout(lr); ll.addWidget(self.v451744_label_table, 1)
    sub.addTab(lab, 'ملصقات مباشرة')

    # Scanner
    scan = QWidget(); sl = QVBoxLayout(scan); sr = QHBoxLayout()
    self.v451744_scan_input = QLineEdit(); self.v451744_scan_input.setPlaceholderText('ضع المؤشر هنا ثم امسح قارئ الباركود USB/Bluetooth')
    self.v451744_scan_input.returnPressed.connect(self.v451744_scan_lookup)
    sr.addWidget(_make_button('بحث بالباركود', self.v451744_scan_lookup, True)); sr.addWidget(self.v451744_scan_input, 1)
    self.v451744_scan_result = QTextEdit(); self.v451744_scan_result.setReadOnly(True)
    sl.addLayout(sr); sl.addWidget(self.v451744_scan_result, 1)
    sub.addTab(scan, 'قارئ USB/Bluetooth')

    return tab


def _v451744_make_invoice_qr(self):
    inv = self.v451744_invoice_no.text().strip()
    try:
        payload = self.service.invoice_qr_payload(inv)
        self.v451744_invoice_qr_text.setPlainText('محتوى QR:\n' + payload + '\n\nتم توليد QR داخلياً ويُستخدم أيضاً في قوالب الفاتورة المتقدمة.')
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر إنشاء QR', str(exc))


def _v451744_print_labels(self):
    try:
        rows = self.service.barcode_label_rows(self.v451744_label_term.text().strip())
        self.v451744_label_table.setRowCount(len(rows[:300]))
        for r, x in enumerate(rows[:300]):
            vals = [x.get('name'), x.get('barcode'), x.get('category'), money(x.get('sale_price')), x.get('quantity')]
            for c, v in enumerate(vals): self.v451744_label_table.put(r, c, v)
        path = self.service.print_barcode_labels_direct(self.v451744_label_term.text().strip(), self.v451744_label_type.currentData(), self.v451744_copies.value())
        QMessageBox.information(self, 'تم إنشاء الملصقات', f'تم إنشاء ملف الملصقات القابل للطباعة:\n{path}')
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر إنشاء الملصقات', str(exc))


def _v451744_scan_lookup(self):
    code = self.v451744_scan_input.text().strip()
    try:
        p = self.service.barcode_scan_lookup(code)
        if not p:
            self.v451744_scan_result.setPlainText('لم يتم العثور على منتج بهذا الباركود.')
        else:
            self.v451744_scan_result.setPlainText(f"المنتج: {p.get('name')}\nالباركود: {p.get('barcode')}\nالصنف: {p.get('category','')}\nالسعر: {money(p.get('sale_price'))}\nالمخزون: {p.get('quantity')}")
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر البحث', str(exc))


def _add_tools_tab_once(self, attr, title, builder):
    if hasattr(self, attr):
        return
    widget = builder()
    setattr(self, attr, widget)
    self.tabs.addTab(widget, title)


def _tools_init(self, service, notify, current_user=None):
    _ORIG_TOOLS_INIT(self, service, notify, current_user)
    try:
        _add_tools_tab_once(self, 'v451744_barcode_tab', 'باركود متقدم', lambda: _build_advanced_barcode_tab(self))
        # Rename the old AI tools tab if it exists; the main AI page is fully replaced below.
        for i in range(self.tabs.count()):
            if self.tabs.tabText(i) == 'AI أعمق':
                self.tabs.setTabText(i, 'AI مساعد قديم/تقارير')
    except Exception as exc:
        log_exception(exc)
        try: notify(f'تعذر بناء باركود متقدم: {exc}')
        except Exception: pass


def _tools_refresh(self):
    if _ORIG_TOOLS_REFRESH:
        try: _ORIG_TOOLS_REFRESH(self)
        except Exception as exc: log_exception(exc)
    try:
        if hasattr(self, 'v451744_label_table'):
            rows = self.service.barcode_label_rows('')[:100]
            self.v451744_label_table.setRowCount(len(rows))
            for r, x in enumerate(rows):
                for c, v in enumerate([x.get('name'), x.get('barcode'), x.get('category'), money(x.get('sale_price')), x.get('quantity')]):
                    self.v451744_label_table.put(r, c, v)
    except Exception as exc:
        log_exception(exc)


SmartAssistantPage.__init__ = _smart_init
SmartAssistantPage.refresh = _smart_refresh
SmartAssistantPage.ai_refresh_forecast = _ai_refresh_forecast
SmartAssistantPage.ai_refresh_prices = _ai_refresh_prices
SmartAssistantPage.ai_ask = _ai_ask
SmartAssistantPage.ai_analyze_notes = _ai_analyze_notes

ToolsPage.__init__ = _tools_init
ToolsPage.refresh = _tools_refresh
ToolsPage.v451744_make_invoice_qr = _v451744_make_invoice_qr
ToolsPage.v451744_print_labels = _v451744_print_labels
ToolsPage.v451744_scan_lookup = _v451744_scan_lookup
