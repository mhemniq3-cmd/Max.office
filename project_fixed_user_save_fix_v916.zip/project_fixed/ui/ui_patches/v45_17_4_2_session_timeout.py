from __future__ import annotations

"""V45.17.4.2 session timeout patch.

Adds a 30-minute inactivity timeout without changing the v45.17.4 layout.
"""

from datetime import datetime, timedelta

from PySide6.QtCore import QEvent, QTimer
from PySide6.QtWidgets import QApplication, QMessageBox

from ui.main_window_core import MainWindow
from services.error_logger import log_exception

_ORIG_INIT = MainWindow.__init__
_ORIG_CLOSE = MainWindow.closeEvent

SESSION_TIMEOUT_MINUTES = 30


def _mark_activity(self):
    try:
        self._v451742_last_activity = datetime.now()
    except Exception:
        pass


def _check_session_timeout(self):
    try:
        last = getattr(self, '_v451742_last_activity', datetime.now())
        if datetime.now() - last >= timedelta(minutes=SESSION_TIMEOUT_MINUTES):
            try:
                self.service.log('انتهاء جلسة', 'تم تسجيل الخروج تلقائياً بعد 30 دقيقة من عدم النشاط', self.current_user['id'] if self.current_user else None)
            except Exception:
                pass
            QMessageBox.information(self, 'انتهاء الجلسة', 'تم إغلاق الجلسة تلقائياً بعد 30 دقيقة من عدم النشاط.')
            try:
                self.service.db.close()
            except Exception as exc:
                log_exception(exc, 'إغلاق قاعدة البيانات بعد انتهاء الجلسة')
            QApplication.quit()
    except Exception as exc:
        log_exception(exc, 'فحص انتهاء الجلسة')


def _event_filter(self, obj, event):
    try:
        if event.type() in (
            QEvent.MouseButtonPress,
            QEvent.MouseButtonRelease,
            QEvent.MouseMove,
            QEvent.KeyPress,
            QEvent.KeyRelease,
            QEvent.Wheel,
            QEvent.TouchBegin,
            QEvent.TouchUpdate,
        ):
            _mark_activity(self)
    except Exception:
        pass
    return False


def _init(self, service, current_user=None):
    _ORIG_INIT(self, service, current_user)
    try:
        _mark_activity(self)
        app = QApplication.instance()
        if app is not None:
            app.installEventFilter(self)
        self._v451742_session_timer = QTimer(self)
        self._v451742_session_timer.timeout.connect(lambda: _check_session_timeout(self))
        self._v451742_session_timer.start(60_000)
    except Exception as exc:
        log_exception(exc, 'تفعيل انتهاء الجلسة')


def _close_event(self, event):
    try:
        app = QApplication.instance()
        if app is not None:
            app.removeEventFilter(self)
    except Exception:
        pass
    return _ORIG_CLOSE(self, event)


MainWindow.__init__ = _init
MainWindow.eventFilter = _event_filter
MainWindow.closeEvent = _close_event
