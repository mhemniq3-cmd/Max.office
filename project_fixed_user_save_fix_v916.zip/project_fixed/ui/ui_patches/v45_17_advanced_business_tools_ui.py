from __future__ import annotations

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

_ORIG_INIT = ToolsPage.__init__
_ORIG_REFRESH = getattr(ToolsPage, 'refresh', None)


def _safe_msg(self, title, exc):
    try:
        msg = self.service.user_message(exc) if hasattr(self.service, 'user_message') else str(exc)
    except Exception:
        msg = str(exc)
    QMessageBox.warning(self, title, msg)


def _add_tab_once(self, attr, title, builder):
    if hasattr(self, attr):
        return
    tab = builder()
    setattr(self, attr, tab)
    self.tabs.addTab(tab, title)


def _build_v45_17_offers_tab(self):
    tab = QWidget(); root = QVBoxLayout(tab)
    note = QLabel('نظام العروض المتقدم: خصم منتج/مجموعة، اشتر X واحصل على Y، كوبونات، مدة صلاحية، ومنع الخصم الكبير إلا بصلاحية مدير.')
    note.setWordWrap(True); note.setObjectName('noticeBox'); root.addWidget(note)
    form = QFrame(); form.setObjectName('surface'); grid = QGridLayout(form)
    self.v4517_offer_name = QLineEdit(); self.v4517_offer_name.setPlaceholderText('اسم العرض')
    self.v4517_offer_scope = QComboBox(); self.v4517_offer_scope.addItem('كل المنتجات','all'); self.v4517_offer_scope.addItem('منتج محدد','product'); self.v4517_offer_scope.addItem('مجموعة/صنف','category')
    self.v4517_offer_product = QComboBox(); self.v4517_offer_category = QLineEdit(); self.v4517_offer_category.setPlaceholderText('اسم المجموعة')
    self.v4517_offer_type = QComboBox(); self.v4517_offer_type.addItem('نسبة خصم','percent'); self.v4517_offer_type.addItem('مبلغ خصم','amount'); self.v4517_offer_type.addItem('سعر ثابت','fixed_price'); self.v4517_offer_type.addItem('اشتر X واحصل على Y','buy_x_get_y')
    self.v4517_offer_value = QDoubleSpinBox(); self.v4517_offer_value.setMaximum(999999999); self.v4517_offer_value.setDecimals(2)
    self.v4517_offer_buy = QSpinBox(); self.v4517_offer_buy.setMaximum(99999); self.v4517_offer_buy.setValue(2)
    self.v4517_offer_free = QSpinBox(); self.v4517_offer_free.setMaximum(99999); self.v4517_offer_free.setValue(1)
    self.v4517_offer_min = QSpinBox(); self.v4517_offer_min.setMaximum(99999); self.v4517_offer_min.setValue(1)
    self.v4517_offer_coupon = QLineEdit(); self.v4517_offer_coupon.setPlaceholderText('اختياري مثل RAMADAN10')
    self.v4517_offer_start = QLineEdit(); self.v4517_offer_start.setPlaceholderText('YYYY-MM-DD')
    self.v4517_offer_end = QLineEdit(); self.v4517_offer_end.setPlaceholderText('YYYY-MM-DD')
    self.v4517_offer_manager = QCheckBox('يتطلب موافقة/صلاحية مدير')
    self.v4517_offer_priority = QSpinBox(); self.v4517_offer_priority.setMaximum(9999); self.v4517_offer_priority.setValue(50)
    save = QPushButton('حفظ العرض المتقدم بدل زر العروض القديم'); save.setObjectName('primaryButton'); save.clicked.connect(self.v4517_save_offer)
    fields = [('اسم العرض', self.v4517_offer_name), ('النطاق', self.v4517_offer_scope), ('المنتج', self.v4517_offer_product), ('المجموعة', self.v4517_offer_category), ('نوع العرض', self.v4517_offer_type), ('القيمة', self.v4517_offer_value), ('اشتر X', self.v4517_offer_buy), ('مجاني Y', self.v4517_offer_free), ('أقل كمية', self.v4517_offer_min), ('كوبون', self.v4517_offer_coupon), ('من تاريخ', self.v4517_offer_start), ('إلى تاريخ', self.v4517_offer_end), ('الأولوية', self.v4517_offer_priority), ('حماية المدير', self.v4517_offer_manager)]
    for i,(label,widget) in enumerate(fields):
        grid.addWidget(QLabel(label), (i//3)*2, i%3); grid.addWidget(widget, (i//3)*2+1, i%3)
    grid.addWidget(save, 10, 0, 1, 3)
    root.addWidget(form)
    self.v4517_offers_table = Table(['ID','العرض','النطاق','النوع','القيمة','الكوبون','الفترة','مدير','نشط'])
    root.addWidget(self.v4517_offers_table, 1)
    refresh = QPushButton('تحديث العروض'); refresh.clicked.connect(self.v4517_refresh_all); root.addWidget(refresh)
    return tab


def _build_v45_17_alerts_tab(self):
    tab = QWidget(); root = QVBoxLayout(tab)
    row = QHBoxLayout(); gen = QPushButton('توليد/تحديث التنبيهات الذكية'); gen.setObjectName('warningButton'); gen.clicked.connect(self.v4517_generate_alerts)
    close_btn = QPushButton('إغلاق التنبيه المحدد'); close_btn.clicked.connect(self.v4517_resolve_alert)
    row.addWidget(gen); row.addWidget(close_btn); root.addLayout(row)
    self.v4517_alerts_table = Table(['ID','الخطورة','النوع','العنوان','التفاصيل','الحالة','الوقت'])
    root.addWidget(self.v4517_alerts_table, 1)
    return tab


def _build_v45_17_reports_tab(self):
    tab = QWidget(); root = QVBoxLayout(tab)
    filters = QHBoxLayout(); self.v4517_rep_from = QLineEdit(); self.v4517_rep_from.setPlaceholderText('من YYYY-MM-DD'); self.v4517_rep_to = QLineEdit(); self.v4517_rep_to.setPlaceholderText('إلى YYYY-MM-DD')
    btn = QPushButton('تحديث التقارير المتقدمة'); btn.setObjectName('primaryButton'); btn.clicked.connect(self.v4517_refresh_reports)
    filters.addWidget(btn); filters.addWidget(self.v4517_rep_to); filters.addWidget(self.v4517_rep_from); root.addLayout(filters)
    self.v4517_reports_tabs = QTabWidget(); root.addWidget(self.v4517_reports_tabs, 1)
    self.v4517_report_tables = {}
    defs = [('daily_profit','ربح يومي/ضريبة', ['الفترة','الفواتير','المبيعات','الربح','الضريبة','الخصومات']), ('most_profit_products','الأكثر ربحاً', ['المنتج','الكمية','المبيعات','الربح']), ('best_selling_products','الأكثر مبيعاً', ['المنتج','الكمية','المبيعات','الربح']), ('least_selling_products','الأقل مبيعاً', ['المنتج','مباع','المخزون']), ('customer_debts','ديون العملاء', ['العميل','الهاتف','الدين']), ('supplier_debts','ديون الموردين', ['المورد','الهاتف','الدين']), ('employee_report','الموظفين', ['الموظف','الفواتير','المبيعات','الربح']), ('discount_report','الخصومات', ['الفاتورة','الوقت','قبل الخصم','الخصم','الكوبون','المستخدم'])]
    for key,title,headers in defs:
        t = Table(headers); self.v4517_report_tables[key]=t; self.v4517_reports_tabs.addTab(t, title)
    return tab


def _build_v45_17_print_archive_tab(self):
    tab = QWidget(); root = QVBoxLayout(tab)
    box = QFrame(); box.setObjectName('surface'); form = QFormLayout(box)
    self.v4517_invoice_no = QLineEdit(); self.v4517_invoice_no.setPlaceholderText('رقم الفاتورة لإعادة الطباعة أو الحفظ')
    self.v4517_template = QComboBox(); self.v4517_template.addItems(['80mm','A4','compact'])
    preview = QPushButton('حفظ نسخة قابلة للطباعة / PDF تلقائي'); preview.setObjectName('primaryButton'); preview.clicked.connect(self.v4517_save_invoice_print)
    archive = QPushButton('أرشفة الفاتورة المحددة'); archive.clicked.connect(self.v4517_archive_invoice)
    form.addRow('رقم الفاتورة', self.v4517_invoice_no); form.addRow('القالب', self.v4517_template); form.addRow('', preview); form.addRow('', archive)
    root.addWidget(box)
    search_row = QHBoxLayout(); self.v4517_archive_term = QLineEdit(); self.v4517_archive_term.setPlaceholderText('بحث بالاسم، الهاتف، الرقم، التاريخ، المبلغ'); search = QPushButton('بحث في الأرشيف'); search.clicked.connect(self.v4517_refresh_archive)
    search_row.addWidget(search); search_row.addWidget(self.v4517_archive_term); root.addLayout(search_row)
    self.v4517_archive_table = Table(['ID','النوع','الرقم','الطرف','الهاتف','المبلغ','المسار','الوقت'])
    root.addWidget(self.v4517_archive_table, 1)
    return tab


def _build_v45_17_ai_tab(self):
    tab = QWidget(); root = QVBoxLayout(tab)
    row = QHBoxLayout(); self.v4517_ai_q = QLineEdit(); self.v4517_ai_q.setPlaceholderText('اسأل: ما أكثر منتج ربحاً؟ ما المنتجات الراكدة؟ ماذا أشتري؟')
    ask = QPushButton('اسأل المساعد الذكي'); ask.setObjectName('primaryButton'); ask.clicked.connect(self.v4517_ask_ai)
    analyze = QPushButton('تحديث تحليل AI'); analyze.clicked.connect(self.v4517_refresh_ai)
    row.addWidget(ask); row.addWidget(analyze); row.addWidget(self.v4517_ai_q, 1); root.addLayout(row)
    self.v4517_ai_answer = QTextEdit(); self.v4517_ai_answer.setReadOnly(True); self.v4517_ai_answer.setMinimumHeight(90); root.addWidget(self.v4517_ai_answer)
    self.v4517_ai_table = Table(['المنتج','المخزون','مباع 90 يوم','توقع 30 يوم','اقتراح شراء','ملاحظة'])
    root.addWidget(self.v4517_ai_table, 1)
    return tab


def _v4517_save_offer(self):
    try:
        self.service.save_advanced_offer({'name': self.v4517_offer_name.text(), 'scope_type': self.v4517_offer_scope.currentData(), 'product_id': self.v4517_offer_product.currentData(), 'category': self.v4517_offer_category.text(), 'promo_type': self.v4517_offer_type.currentData(), 'discount_value': self.v4517_offer_value.value(), 'buy_qty': self.v4517_offer_buy.value(), 'free_qty': self.v4517_offer_free.value(), 'min_quantity': self.v4517_offer_min.value(), 'coupon_code': self.v4517_offer_coupon.text(), 'start_date': self.v4517_offer_start.text(), 'end_date': self.v4517_offer_end.text(), 'manager_only': self.v4517_offer_manager.isChecked(), 'priority': self.v4517_offer_priority.value(), 'active': 1}, user_id=(self.current_user or {}).get('id') if isinstance(self.current_user, dict) else None)
    except Exception as exc:
        _safe_msg(self, 'تعذر حفظ العرض', exc); return
    self.v4517_offer_name.clear(); self.v4517_refresh_all(); self.notify('تم حفظ العرض المتقدم')


def _v4517_generate_alerts(self):
    try: self.service.generate_smart_alerts(user_id=(self.current_user or {}).get('id') if isinstance(self.current_user, dict) else None)
    except Exception as exc: _safe_msg(self, 'تعذر توليد التنبيهات', exc); return
    self.v4517_refresh_alerts(); self.notify('تم تحديث التنبيهات')


def _v4517_resolve_alert(self):
    row = self.v4517_alerts_table.currentRow(); item = self.v4517_alerts_table.item(row,0) if row>=0 else None
    if not item: return
    try: self.service.resolve_smart_alert(item.data(Qt.UserRole), user_id=(self.current_user or {}).get('id') if isinstance(self.current_user, dict) else None)
    except Exception as exc: _safe_msg(self, 'تعذر إغلاق التنبيه', exc); return
    self.v4517_refresh_alerts()


def _v4517_save_invoice_print(self):
    inv = self.v4517_invoice_no.text().strip()
    if not inv: QMessageBox.warning(self,'تنبيه','اكتب رقم الفاتورة أولاً'); return
    try: path = self.service.save_invoice_pdf_auto(inv, self.v4517_template.currentText())
    except Exception as exc: _safe_msg(self, 'تعذر حفظ الفاتورة', exc); return
    QMessageBox.information(self, 'تم', f'تم حفظ نسخة الفاتورة:\n{path}')


def _v4517_archive_invoice(self):
    inv = self.v4517_invoice_no.text().strip()
    if not inv: QMessageBox.warning(self,'تنبيه','اكتب رقم الفاتورة أولاً'); return
    try: self.service.archive_sale_invoice(inv, user_id=(self.current_user or {}).get('id') if isinstance(self.current_user, dict) else None)
    except Exception as exc: _safe_msg(self, 'تعذر الأرشفة', exc); return
    self.v4517_refresh_archive(); self.notify('تمت الأرشفة')


def _v4517_ask_ai(self):
    try: ans = self.service.ask_ai_assistant_deep(self.v4517_ai_q.text())
    except Exception as exc: _safe_msg(self, 'تعذر تحليل السؤال', exc); return
    self.v4517_ai_answer.setPlainText(ans)


def _v4517_refresh_offers(self):
    if not hasattr(self, 'v4517_offers_table'): return
    self.v4517_offer_product.clear(); self.v4517_offer_product.addItem('بدون', None)
    try:
        for p in self.service.list_products(''):
            self.v4517_offer_product.addItem(f"{p['name']} | {p.get('barcode','') if hasattr(p,'get') else p['barcode']}", p['id'])
    except Exception: pass
    try: rows = self.service.list_advanced_offers(False)
    except Exception: rows = []
    self.v4517_offers_table.setRowCount(len(rows))
    for r,p in enumerate(rows):
        scope = 'كل المنتجات' if p.get('scope_type')=='all' else (p.get('product_name') if p.get('scope_type')=='product' else p.get('category',''))
        vals = [p.get('id'), p.get('name'), scope, p.get('promo_type'), p.get('discount_value'), p.get('coupon_code',''), f"{p.get('start_date') or ''} → {p.get('end_date') or ''}", 'نعم' if p.get('manager_only') else 'لا', 'نعم' if p.get('active') else 'لا']
        for c,v in enumerate(vals): self.v4517_offers_table.put(r,c,v,p.get('id') if c==0 else None)


def _v4517_refresh_alerts(self):
    if not hasattr(self, 'v4517_alerts_table'): return
    try: rows = self.service.list_smart_alerts('open')
    except Exception: rows = []
    self.v4517_alerts_table.setRowCount(len(rows))
    for r,a in enumerate(rows):
        vals = [a.get('id'), a.get('severity'), a.get('alert_type'), a.get('title'), a.get('message'), a.get('status'), a.get('created_at')]
        for c,v in enumerate(vals): self.v4517_alerts_table.put(r,c,v,a.get('id') if c==0 else None)


def _fill_table(table, rows, key):
    table.setRowCount(len(rows))
    for r,row in enumerate(rows):
        if key == 'daily_profit': vals=[row.get('period'), row.get('invoices'), money(row.get('sales')), money(row.get('profit')), money(row.get('tax')), money(row.get('discounts'))]
        elif key in ('most_profit_products','best_selling_products'): vals=[row.get('product_name'), row.get('qty'), money(row.get('amount')), money(row.get('profit'))]
        elif key == 'least_selling_products': vals=[row.get('product_name'), row.get('qty'), row.get('stock')]
        elif key in ('customer_debts','supplier_debts'): vals=[row.get('name'), row.get('phone'), money(row.get('balance'))]
        elif key == 'employee_report': vals=[row.get('name'), row.get('invoices'), money(row.get('sales')), money(row.get('profit'))]
        else: vals=[row.get('invoice_no'), row.get('created_at'), money(row.get('subtotal')), money(row.get('discount_amount')), row.get('coupon_code') or '', row.get('username') or '']
        for c,v in enumerate(vals): table.put(r,c,v)


def _v4517_refresh_reports(self):
    if not hasattr(self, 'v4517_report_tables'): return
    try: data = self.service.advanced_reports(self.v4517_rep_from.text().strip(), self.v4517_rep_to.text().strip())
    except Exception as exc: _safe_msg(self, 'تعذر تحديث التقارير', exc); return
    for key, table in self.v4517_report_tables.items(): _fill_table(table, data.get(key, []), key)


def _v4517_refresh_archive(self):
    if not hasattr(self, 'v4517_archive_table'): return
    try: rows = self.service.search_document_archive(self.v4517_archive_term.text().strip())
    except Exception: rows = []
    self.v4517_archive_table.setRowCount(len(rows))
    for r,d in enumerate(rows):
        vals=[d.get('id'), d.get('doc_type'), d.get('doc_no'), d.get('party_name'), d.get('phone'), money(d.get('amount')), d.get('file_path'), d.get('created_at')]
        for c,v in enumerate(vals): self.v4517_archive_table.put(r,c,v,d.get('id') if c==0 else None)


def _v4517_refresh_ai(self):
    if not hasattr(self, 'v4517_ai_table'): return
    try: data = self.service.advanced_ai_analysis(90)
    except Exception as exc: _safe_msg(self, 'تعذر تحليل الذكاء', exc); return
    rows = data.get('forecasts', [])[:100]
    self.v4517_ai_table.setRowCount(len(rows))
    stale = {x['product_id'] for x in data.get('stagnant_products', [])}
    for r,x in enumerate(rows):
        note = 'راكد - اقترح عرض' if x.get('product_id') in stale else ('يحتاج شراء' if x.get('suggested_purchase_qty') else '')
        vals=[x.get('product_name'), x.get('current_stock'), x.get('sold_qty'), x.get('forecast_30_days'), x.get('suggested_purchase_qty'), note]
        for c,v in enumerate(vals): self.v4517_ai_table.put(r,c,v)


def _v4517_refresh_all(self):
    _v4517_refresh_offers(self); _v4517_refresh_alerts(self); _v4517_refresh_reports(self); _v4517_refresh_archive(self); _v4517_refresh_ai(self)


def _init(self, service, notify, current_user=None):
    _ORIG_INIT(self, service, notify, current_user)
    try:
        _add_tab_once(self, 'v4517_offers_tab', 'العروض المتقدمة', lambda: _build_v45_17_offers_tab(self))
        _add_tab_once(self, 'v4517_alerts_tab', 'تنبيهات ذكية', lambda: _build_v45_17_alerts_tab(self))
        _add_tab_once(self, 'v4517_reports_tab', 'تقارير قوية', lambda: _build_v45_17_reports_tab(self))
        _add_tab_once(self, 'v4517_print_archive_tab', 'طباعة وأرشفة', lambda: _build_v45_17_print_archive_tab(self))
        _add_tab_once(self, 'v4517_ai_tab', 'AI أعمق', lambda: _build_v45_17_ai_tab(self))
        self.v4517_refresh_all()
    except Exception as exc:
        log_exception(exc)
        try: notify(f'تعذر بناء أدوات v45.17: {exc}')
        except Exception: pass


def _refresh(self):
    if _ORIG_REFRESH:
        try: _ORIG_REFRESH(self)
        except Exception as exc: log_exception(exc)
    try: self.v4517_refresh_all()
    except Exception as exc: log_exception(exc)


ToolsPage.__init__ = _init
ToolsPage.refresh = _refresh
ToolsPage.v4517_save_offer = _v4517_save_offer
ToolsPage.v4517_generate_alerts = _v4517_generate_alerts
ToolsPage.v4517_resolve_alert = _v4517_resolve_alert
ToolsPage.v4517_save_invoice_print = _v4517_save_invoice_print
ToolsPage.v4517_archive_invoice = _v4517_archive_invoice
ToolsPage.v4517_ask_ai = _v4517_ask_ai
ToolsPage.v4517_refresh_offers = _v4517_refresh_offers
ToolsPage.v4517_refresh_alerts = _v4517_refresh_alerts
ToolsPage.v4517_refresh_reports = _v4517_refresh_reports
ToolsPage.v4517_refresh_archive = _v4517_refresh_archive
ToolsPage.v4517_refresh_ai = _v4517_refresh_ai
ToolsPage.v4517_refresh_all = _v4517_refresh_all
