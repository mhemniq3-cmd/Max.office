from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QTabWidget, QPushButton, QMessageBox

from ui.pages.sales_page import SalesPage
from ui.pages.touch_pos_page import TouchPOSPage
from ui.main_window_core import MainWindow
from services.error_logger import log_exception

class SalesMultiTabWrapper(QWidget):
    def __init__(self, service, notify, current_user):
        super().__init__()
        self.service = service
        self.notify = notify
        self.current_user = current_user
        
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        
        self.layout.addWidget(self.tabs)
        
        self.add_btn = QPushButton("➕ فاتورة جديدة (مبيعات)")
        self.add_btn.setObjectName("primaryButton")
        self.add_btn.setCursor(Qt.PointingHandCursor)
        self.add_btn.clicked.connect(self.add_new_sale_tab)
        self.tabs.setCornerWidget(self.add_btn)
        
        self.tab_count = 0
        self.add_new_sale_tab()
        
    def add_new_sale_tab(self):
        self.tab_count += 1
        try:
            page = SalesPage(self.service, self.notify, self.current_user)
            if hasattr(page, 'refresh_all'):
                page.refresh_all()
            idx = self.tabs.addTab(page, f"🧾 فاتورة {self.tab_count}")
            self.tabs.setCurrentIndex(idx)
        except Exception as exc:
            log_exception(exc, "SalesMultiTab add_new_sale_tab")
        
    def close_tab(self, index):
        try:
            w = self.tabs.widget(index)
            if hasattr(w, 'cart') and w.cart:
                res = QMessageBox.question(self, "تأكيد الإغلاق", "هذه الفاتورة تحتوي على أصناف. هل أنت متأكد من إغلاقها؟")
                if res != QMessageBox.Yes:
                    return
            
            self.tabs.removeTab(index)
            w.deleteLater()
            
            if self.tabs.count() == 0:
                self.add_new_sale_tab()
        except Exception as exc:
            log_exception(exc, "SalesMultiTab close_tab")
            
    def refresh_all(self):
        try:
            for i in range(self.tabs.count()):
                w = self.tabs.widget(i)
                if hasattr(w, 'refresh_all'):
                    w.refresh_all()
        except Exception:
            pass


class TouchPOSMultiTabWrapper(QWidget):
    def __init__(self, service, notify, current_user):
        super().__init__()
        self.service = service
        self.notify = notify
        self.current_user = current_user
        
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        
        self.layout.addWidget(self.tabs)
        
        self.add_btn = QPushButton("➕ كاشير جديد (لمس)")
        self.add_btn.setObjectName("primaryButton")
        self.add_btn.setCursor(Qt.PointingHandCursor)
        self.add_btn.clicked.connect(self.add_new_sale_tab)
        self.tabs.setCornerWidget(self.add_btn)
        
        self.tab_count = 0
        self.add_new_sale_tab()
        
    def add_new_sale_tab(self):
        self.tab_count += 1
        try:
            page = TouchPOSPage(self.service, self.notify, self.current_user)
            if hasattr(page, 'refresh_all'):
                page.refresh_all()
            elif hasattr(page, 'refresh_products'):
                page.refresh_products()
                
            idx = self.tabs.addTab(page, f"🖥 كاشير {self.tab_count}")
            self.tabs.setCurrentIndex(idx)
        except Exception as exc:
            log_exception(exc, "TouchPOSMultiTab add_new_sale_tab")
        
    def close_tab(self, index):
        try:
            w = self.tabs.widget(index)
            if hasattr(w, 'cart') and w.cart:
                res = QMessageBox.question(self, "تأكيد الإغلاق", "هذه الفاتورة تحتوي على أصناف. هل أنت متأكد من إغلاقها؟")
                if res != QMessageBox.Yes:
                    return
            
            self.tabs.removeTab(index)
            w.deleteLater()
            
            if self.tabs.count() == 0:
                self.add_new_sale_tab()
        except Exception as exc:
            log_exception(exc, "TouchPOSMultiTab close_tab")
            
    def refresh_all(self):
        try:
            for i in range(self.tabs.count()):
                w = self.tabs.widget(i)
                if hasattr(w, 'refresh_all'):
                    w.refresh_all()
                elif hasattr(w, 'refresh_products'):
                    w.refresh_products()
        except Exception:
            pass


_ORIG_MAINWINDOW_BUILD_V4616 = MainWindow.build

def _v46_16_mainwindow_build(self: MainWindow):
    _ORIG_MAINWINDOW_BUILD_V4616(self)
    try:
        # Override the factories to use the MultiTab Wrappers
        self.page_factories['sales'] = lambda: SalesMultiTabWrapper(self.service, self.notify, self.current_user)
        self.page_factories['touch_pos'] = lambda: TouchPOSMultiTabWrapper(self.service, self.notify, self.current_user)
        
        # If pages were already created by previous patches (like lazy permissions patch), clear them so they are recreated!
        if 'sales' in self.pages:
            del self.pages['sales']
        if 'touch_pos' in self.pages:
            del self.pages['touch_pos']
            
    except Exception as exc:
        log_exception(exc, "v46_16_mainwindow_build")


# Intercept show_page to ensure refresh_all is called properly on our wrappers
_ORIG_SHOW_PAGE_V4616 = MainWindow.show_page

def _v46_16_show_page(self: MainWindow, page_name: str):
    _ORIG_SHOW_PAGE_V4616(self, page_name)
    try:
        page = self.pages.get(page_name)
        if isinstance(page, (SalesMultiTabWrapper, TouchPOSMultiTabWrapper)):
            page.refresh_all()
    except Exception as exc:
        log_exception(exc, "v46_16_show_page refresh")

MainWindow.build = _v46_16_mainwindow_build
MainWindow.show_page = _v46_16_show_page
