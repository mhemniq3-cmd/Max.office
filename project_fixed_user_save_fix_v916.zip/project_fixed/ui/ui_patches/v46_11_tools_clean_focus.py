"""v46.11 - Focused clean Tools page.

A stricter simplification layer for the Tools page:
- Keep the four stable main groups.
- Show only a small set of daily/essential tools as direct inner tabs.
- Move every other tool into one clear tab: "أدوات إضافية".
- Do not delete widgets or functions; opening an extra tool creates a temporary tab.
"""
from __future__ import annotations

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

_ORIG_INIT = ToolsPage.__init__
_ORIG_REFRESH = getattr(ToolsPage, 'refresh', None)

GROUP_KEYS = ('audit', 'operations', 'inventory', 'settings')

ESSENTIAL_ORDER = {
    'audit': [
        'مركز سجل الحركات',
        'سجل الحركات',
    ],
    'operations': [
        'العمليات السريعة',
        'قائمة جميع الفواتير',
        'الفواتير المعلقة',
        'الإغلاق اليومي',
        'عمولات الموظفين',
    ],
    'inventory': [
        'حركة المخزون',
        'الجرد',
        'جرد',
        'الفروع والمخازن',
        'باركود',
        'الملصقات',
    ],
    'settings': [
        'إعدادات الشركة',
        'إعدادات النظام',
        'النسخ الاحتياطي',
        'استعادة',
        'المستخدمون',
        'المستخدمين',
        'صلاحيات',
    ],
}

GROUP_NOTES = {
    'audit': 'يعرض هذا القسم أدوات الرقابة اليومية فقط. بقية أدوات التدقيق موجودة في أدوات إضافية.',
    'operations': 'أدوات العمل اليومي الأكثر استخداماً. بقية الأدوات التشغيلية موجودة في أدوات إضافية.',
    'inventory': 'أدوات المخزون الأساسية فقط لتقليل التزاحم.',
    'settings': 'إعدادات النظام والنسخ والصلاحيات الأساسية فقط.',
}


def _norm(text: str) -> str:
    return (text or '').replace('️', '').strip()


def _matches(title: str, keys: list[str]) -> bool:
    t = _norm(title)
    return any(k and k in t for k in keys)


def _collect_all(inner: QTabWidget) -> list[tuple[str, QWidget]]:
    existing = getattr(inner, 'v4611_all_tabs', None)
    if existing:
        known = {id(w) for _, w in existing}
        for i in range(inner.count()):
            w = inner.widget(i)
            title = inner.tabText(i) or 'أداة'
            if w is not None and id(w) not in known and 'أدوات إضافية' not in title:
                existing.append((title, w))
                known.add(id(w))
        return existing

    source = getattr(inner, 'v4610_all_tabs', None)
    tabs: list[tuple[str, QWidget]] = []
    if source:
        tabs.extend([(t, w) for t, w in source if w is not None])
    else:
        for i in range(inner.count()):
            w = inner.widget(i)
            title = inner.tabText(i) or 'أداة'
            if w is not None and 'فارغ' not in title and 'لا توجد أدوات' not in title and 'أدوات إضافية' not in title:
                tabs.append((title, w))
    # Deduplicate by widget identity, preserving order.
    result: list[tuple[str, QWidget]] = []
    seen: set[int] = set()
    for title, w in tabs:
        if id(w) in seen:
            continue
        seen.add(id(w))
        result.append((_norm(title) or 'أداة', w))
    setattr(inner, 'v4611_all_tabs', result)
    return result


def _pick_essential(group_key: str, all_tabs: list[tuple[str, QWidget]]) -> tuple[list[tuple[str, QWidget]], list[tuple[str, QWidget]]]:
    chosen: list[tuple[str, QWidget]] = []
    used: set[int] = set()
    for key in ESSENTIAL_ORDER.get(group_key, []):
        for title, w in all_tabs:
            if id(w) in used:
                continue
            if key in _norm(title):
                # Avoid showing both "الجرد" and another duplicate title when they point to similar labels.
                chosen.append((title, w))
                used.add(id(w))
                break
    # Keep a very small fallback if titles are custom.
    if not chosen:
        for title, w in all_tabs[:4]:
            chosen.append((title, w))
            used.add(id(w))
    # Limit direct tools for a calm UI.
    chosen = chosen[:5]
    used = {id(w) for _, w in chosen}
    extras = [(t, w) for t, w in all_tabs if id(w) not in used]
    return chosen, extras


def _make_extra_page(page: ToolsPage, inner: QTabWidget, extras: list[tuple[str, QWidget]]) -> QWidget:
    wrap = QWidget()
    root = QVBoxLayout(wrap)
    root.setContentsMargins(14, 14, 14, 14)
    root.setSpacing(10)

    title = QLabel('أدوات إضافية')
    title.setObjectName('sectionTitle')
    root.addWidget(title)

    note = QLabel('هذه أدوات أقل استخداماً أو إدارية متقدمة. اضغط على أي أداة لفتحها مؤقتاً دون إرباك القائمة الرئيسية.')
    note.setObjectName('noticeBox')
    note.setWordWrap(True)
    root.addWidget(note)

    search = QLineEdit()
    search.setPlaceholderText('بحث داخل الأدوات الإضافية...')
    search.setClearButtonEnabled(True)
    root.addWidget(search)

    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    content = QWidget()
    vbox = QVBoxLayout(content)
    vbox.setContentsMargins(4, 4, 4, 4)
    vbox.setSpacing(6)
    buttons: list[tuple[str, QPushButton]] = []

    def open_extra(tool_title: str, widget: QWidget) -> None:
        # If already open, activate it.
        for i in range(inner.count()):
            if inner.widget(i) is widget:
                inner.setCurrentIndex(i)
                return
        idx = max(0, inner.count() - 1)
        inner.insertTab(idx, widget, tool_title)
        inner.setCurrentIndex(idx)
        try:
            page.notify(f'تم فتح: {tool_title}')
        except Exception:
            pass

    for tool_title, widget in extras:
        btn = QPushButton('• ' + tool_title)
        btn.setMinimumHeight(40)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setObjectName('navButton')
        btn.clicked.connect(lambda checked=False, t=tool_title, w=widget: open_extra(t, w))
        vbox.addWidget(btn)
        buttons.append((tool_title, btn))
    vbox.addStretch(1)
    scroll.setWidget(content)
    root.addWidget(scroll, 1)

    def filter_buttons(text: str) -> None:
        q = _norm(text).lower()
        for tool_title, btn in buttons:
            btn.setVisible(not q or q in _norm(tool_title).lower())

    search.textChanged.connect(filter_buttons)
    return wrap


def _hide_old_simplify_controls(page: ToolsPage) -> None:
    for frame in page.findChildren(QFrame, 'noticeBox'):
        try:
            if getattr(frame.parentWidget(), 'v4610_controls_added', False):
                frame.hide()
        except Exception:
            pass
    for chk in page.findChildren(QCheckBox):
        try:
            if 'إظهار الأدوات المتقدمة' in (chk.text() or ''):
                chk.hide()
        except Exception:
            pass


def _ensure_group_note(group_page: QWidget, group_key: str, inner: QTabWidget) -> None:
    if getattr(group_page, 'v4611_note_added', False):
        return
    layout = group_page.layout()
    if layout is None:
        return
    note = QLabel(GROUP_NOTES.get(group_key, ''))
    note.setObjectName('noticeBox')
    note.setWordWrap(True)
    idx = -1
    for i in range(layout.count()):
        item = layout.itemAt(i)
        if item and item.widget() is inner:
            idx = i
            break
    if idx >= 0:
        layout.insertWidget(idx, note)
    else:
        layout.addWidget(note)
    setattr(group_page, 'v4611_note_added', True)


def _rebuild_group(page: ToolsPage, group_key: str, inner: QTabWidget) -> None:
    if getattr(inner, 'v4611_rebuilding', False):
        return
    setattr(inner, 'v4611_rebuilding', True)
    try:
        all_tabs = _collect_all(inner)
        if not all_tabs:
            return
        essentials, extras = _pick_essential(group_key, all_tabs)

        current = inner.currentWidget()
        inner.blockSignals(True)
        while inner.count():
            inner.removeTab(0)
        for title, widget in essentials:
            inner.addTab(widget, title)
        if extras:
            inner.addTab(_make_extra_page(page, inner, extras), 'أدوات إضافية')
        if current:
            for i in range(inner.count()):
                if inner.widget(i) is current:
                    inner.setCurrentIndex(i)
                    break
        else:
            inner.setCurrentIndex(0)
        inner.blockSignals(False)
        inner.setDocumentMode(True)
        inner.setMovable(False)
        inner.setUsesScrollButtons(True)
        group_page = inner.parentWidget()
        if group_page is not None:
            _ensure_group_note(group_page, group_key, inner)
    finally:
        setattr(inner, 'v4611_rebuilding', False)


def _apply_focused_clean_tools(page: ToolsPage) -> None:
    if getattr(page, 'v4611_applying', False):
        return
    if not hasattr(page, 'tabs') or not isinstance(page.tabs, QTabWidget):
        return
    setattr(page, 'v4611_applying', True)
    try:
        _hide_old_simplify_controls(page)
        for group_key in GROUP_KEYS:
            inner = page.findChild(QTabWidget, f'v4517417_inner_{group_key}')
            if inner is not None:
                _rebuild_group(page, group_key, inner)
        if not getattr(page, 'v4611_notified', False):
            setattr(page, 'v4611_notified', True)
            try:
                page.notify('تم تبسيط الأدوات: الأدوات الأساسية مباشرة، والباقي داخل أدوات إضافية')
            except Exception:
                pass
    finally:
        setattr(page, 'v4611_applying', False)


def _tools_init(self, service, notify, current_user=None):
    _ORIG_INIT(self, service, notify, current_user)
    _apply_focused_clean_tools(self)


def _tools_refresh(self):
    if _ORIG_REFRESH:
        _ORIG_REFRESH(self)
    _apply_focused_clean_tools(self)


ToolsPage.__init__ = _tools_init
ToolsPage.refresh = _tools_refresh
ToolsPage.v4611_apply_focused_clean_tools = _apply_focused_clean_tools
