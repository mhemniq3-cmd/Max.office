from __future__ import annotations

from pathlib import Path
import html
import os

from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.theme_manager import apply_theme as theme_apply, current_theme_key as theme_current_key, set_theme_key as theme_set_key, theme_label as theme_display_label, theme_path as theme_qss_path
from ui.main_window_core import *
import ui.ui_patches.v11_sales_safety as _prev_v11_sales_safety
globals().update({k: v for k, v in vars(_prev_v11_sales_safety).items() if not k.startswith('__')})
import ui.ui_patches.v20_gdrive_ui as _prev_v20_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v20_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v21_backup_ui as _prev_v21_backup_ui
globals().update({k: v for k, v in vars(_prev_v21_backup_ui).items() if not k.startswith('__')})

def _tools_load_google_drive_settings_v22(self):
    cfg = self.service.load_google_drive_backup_settings() if hasattr(self.service, 'load_google_drive_backup_settings') else self.service.get_settings()
    if hasattr(self, 'gdrive_enabled'):
        enabled = str(cfg.get('google_drive_backup_enabled', '0')).strip().lower() in ('1', 'true', 'yes', 'on', 'نعم', 'مفعل')
        self.gdrive_enabled.setChecked(enabled)
        self.gdrive_path.setText(str(cfg.get('google_drive_backup_path', '') or ''))
        status = self.service.google_drive_status() if hasattr(self.service, 'google_drive_status') else str(cfg.get('last_google_drive_backup_status', '') or '')
        self.gdrive_status.setText(status)


def _tools_choose_google_drive_folder_v22(self):
    start = self.gdrive_path.text().strip() if hasattr(self, 'gdrive_path') else ''
    folder = QFileDialog.getExistingDirectory(self, 'اختيار مجلد Google Drive', start)
    if folder:
        self.gdrive_path.setText(folder)
        if hasattr(self, 'gdrive_enabled'):
            self.gdrive_enabled.setChecked(True)
        self.save_google_drive_settings(show_message=False)
        self.notify('تم اختيار وحفظ مجلد Google Drive')


def _tools_save_google_drive_settings_v22(self, show_message=True):
    path = self.gdrive_path.text().strip() if hasattr(self, 'gdrive_path') else ''
    enabled = bool(self.gdrive_enabled.isChecked()) if hasattr(self, 'gdrive_enabled') else False
    try:
        if hasattr(self.service, 'save_google_drive_backup_settings'):
            self.service.save_google_drive_backup_settings(enabled, path, self.current_user.get('id') if self.current_user else None)
        else:
            self.service.save_settings({'google_drive_backup_enabled': '1' if enabled else '0', 'google_drive_backup_path': path}, self.current_user.get('id') if self.current_user else None)
        self.load_google_drive_settings()
        self.notify('تم حفظ إعدادات Google Drive')
        if show_message:
            QMessageBox.information(self, 'تم', 'تم حفظ إعدادات Google Drive بنجاح')
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر حفظ إعدادات Google Drive', str(exc))


def _tools_test_google_drive_folder_v22(self):
    path = self.gdrive_path.text().strip() if hasattr(self, 'gdrive_path') else ''
    if not path:
        QMessageBox.warning(self, 'اختر مجلداً', 'اختر مجلد Google Drive أولاً')
        return
    # Save exactly the visible value, then test exactly the same value.
    self.save_google_drive_settings(show_message=False)
    if hasattr(self.service, 'test_google_drive_backup_path'):
        ok, msg = self.service.test_google_drive_backup_path(path)
    else:
        ok, msg = self.service.test_google_drive_backup()
    if hasattr(self, 'gdrive_status'):
        self.load_google_drive_settings()
    QMessageBox.information(self, 'نجح اختبار Google Drive' if ok else 'فشل اختبار Google Drive', msg)


def _tools_backup_v22(self):
    # Persist current UI settings first, so the backup uses the selected folder.
    if hasattr(self, 'gdrive_path'):
        self.save_google_drive_settings(show_message=False)
    try:
        path = self.service.backup_database()
    except Exception as exc:
        QMessageBox.warning(self, 'فشل النسخ الاحتياطي', str(exc)); return
    cfg = self.service.load_google_drive_backup_settings() if hasattr(self.service, 'load_google_drive_backup_settings') else self.service.get_settings()
    gstatus = cfg.get('last_google_drive_backup_status', '') or ''
    if hasattr(self, 'gdrive_status'):
        self.load_google_drive_settings()
    self.notify(f'تم إنشاء نسخة احتياطية: {path}')
    extra = f'\n\nGoogle Drive:\n{gstatus}' if gstatus else ''
    QMessageBox.information(self, 'تم النسخ الاحتياطي', f'تم إنشاء النسخة المحلية:\n{path}{extra}')


ToolsPage.load_google_drive_settings = _tools_load_google_drive_settings_v22
ToolsPage.choose_google_drive_folder = _tools_choose_google_drive_folder_v22
ToolsPage.save_google_drive_settings = _tools_save_google_drive_settings_v22
ToolsPage.test_google_drive_folder = _tools_test_google_drive_folder_v22
ToolsPage.backup = _tools_backup_v22

# ---------------------------------------------------------------------------
# V23 LOCAL BUSINESS UI: final local-use tools (direct printing, expenses,
# cashier box, system health, archive filters, help, and stronger settings).
# ---------------------------------------------------------------------------

