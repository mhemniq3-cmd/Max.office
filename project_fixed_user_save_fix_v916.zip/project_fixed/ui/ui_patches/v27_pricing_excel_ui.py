from __future__ import annotations

from pathlib import Path
import html
import os

from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.theme_manager import apply_theme as theme_apply, current_theme_key as theme_current_key, set_theme_key as theme_set_key, theme_label as theme_display_label, theme_path as theme_qss_path
from ui.main_window_core import *
import ui.ui_patches.v11_sales_safety as _prev_v11_sales_safety
globals().update({k: v for k, v in vars(_prev_v11_sales_safety).items() if not k.startswith('__')})
import ui.ui_patches.v20_gdrive_ui as _prev_v20_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v20_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v21_backup_ui as _prev_v21_backup_ui
globals().update({k: v for k, v in vars(_prev_v21_backup_ui).items() if not k.startswith('__')})
import ui.ui_patches.v22_gdrive_ui as _prev_v22_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v22_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v23_tools_reports as _prev_v23_tools_reports
globals().update({k: v for k, v in vars(_prev_v23_tools_reports).items() if not k.startswith('__')})
import ui.ui_patches.v25_lazy_permissions as _prev_v25_lazy_permissions
globals().update({k: v for k, v in vars(_prev_v25_lazy_permissions).items() if not k.startswith('__')})
import ui.ui_patches.v26_tools_refresh as _prev_v26_tools_refresh
globals().update({k: v for k, v in vars(_prev_v26_tools_refresh).items() if not k.startswith('__')})

def _v27_combo_price_level_id(widget) -> int | None:
    try:
        data = widget.currentData()
        return int(data) if data not in (None, '', 0, '0') else None
    except Exception:
        return None


def _v27_add_sale_price_level_selector(self):
    if hasattr(self, 'price_level'):
        return
    # Just create the price_level combobox as data-only widget (no visual injection)
    # The SaleInvoiceTab already has its own compact layout
    self.price_level = QComboBox()
    self.price_level.setMinimumHeight(34)
    self.price_level.currentIndexChanged.connect(lambda *_: self.refresh_cart())
    self.price_level.hide()  # Hidden, managed by refresh_price_levels
    self.v27_refresh_price_levels()


def _v27_sales_refresh_price_levels(self):
    if not hasattr(self, 'price_level'):
        return
    cur = self.price_level.currentData()
    self.price_level.blockSignals(True)
    self.price_level.clear()
    self.price_level.addItem('تلقائي حسب الكمية والعروض', None)
    try:
        for lvl in self.service.list_price_levels(True):
            if lvl['name'] == 'مفرد':
                continue
            self.price_level.addItem(lvl['name'], lvl['id'])
    except Exception as exc:
        log_exception(exc)
    if cur is not None:
        idx = self.price_level.findData(cur)
        if idx >= 0:
            self.price_level.setCurrentIndex(idx)
    self.price_level.blockSignals(False)


def _v27_sale_cart_item_from_product(self, product: dict, qty: int) -> dict:
    level_id = _v27_combo_price_level_id(getattr(self, 'price_level', None)) if hasattr(self, 'price_level') else None
    try:
        line = self.service.resolve_sale_line(product['id'], qty, level_id)
        promo_text = line.get('promotion_name') or ''
        level_text = line.get('price_level_name') or 'مفرد'
        return {
            'product_id': product['id'],
            'product_name': product['name'],
            'quantity': qty,
            'unit_price': float(line['unit_price']),
            'commission_percent': float(line.get('commission_percent', product.get('commission_percent', 0)) or 0),
            'price_level_id': line.get('price_level_id') or level_id,
            'price_level_name': level_text,
            'promotion_id': line.get('promotion_id'),
            'promotion_name': promo_text,
            'original_unit_price': float(line.get('original_unit_price', product.get('sale_price', 0)) or 0),
            'promotion_discount_amount': float(line.get('promotion_discount_amount', 0) or 0),
            'free_quantity': int(line.get('free_quantity', 0) or 0),
        }
    except Exception:
        return {'product_id': product['id'], 'product_name': product['name'], 'quantity': qty, 'unit_price': float(product['sale_price']), 'commission_percent': float(product.get('commission_percent', 0) or 0), 'price_level_id': level_id}


_orig_sales_init_v27 = SalesPage.__init__
def _v27_sales_init(self, service: AppService, notify, current_user=None):
    _orig_sales_init_v27(self, service, notify, current_user)
    try:
        _v27_add_sale_price_level_selector(self)
    except Exception as exc:
        log_exception(exc)

SalesPage.__init__ = _v27_sales_init
SalesPage.v27_refresh_price_levels = _v27_sales_refresh_price_levels


_orig_sales_refresh_all_v27 = SalesPage.refresh_all
def _v27_sales_refresh_all(self):
    if hasattr(self, 'v27_refresh_price_levels'):
        self.v27_refresh_price_levels()
    return _orig_sales_refresh_all_v27(self)

SalesPage.refresh_all = _v27_sales_refresh_all


def _v27_sales_refresh_products(self):
    self.product_rows = self.service.list_products_for_sale(self.search.text()) if hasattr(self.service, 'list_products_for_sale') else self.service.list_products(self.search.text())
    self.products.setRowCount(len(self.product_rows))
    level_id = _v27_combo_price_level_id(getattr(self, 'price_level', None)) if hasattr(self, 'price_level') else None
    for r, p in enumerate(self.product_rows):
        price_text = money(p['sale_price'])
        try:
            line = self.service.resolve_sale_line(p['id'], 1, level_id)
            if abs(float(line['unit_price']) - float(p['sale_price'])) > 0.0001 or line.get('promotion_name'):
                price_text = f"{money(line['unit_price'])}\n{line.get('promotion_name') or line.get('price_level_name') or ''}"
        except Exception as exc:
            log_exception(exc)
        self.products.put(r, 0, p['name'], p['id']); self.products.put(r, 1, price_text)
        self.products.put(r, 2, p['quantity']); self.products.put(r, 3, p['category'] or '')


def _v27_sales_scan_barcode_add(self):
    code = self.barcode_scan.text().strip()
    if not code:
        return
    p = self.service.get_product_by_barcode(code)
    if not p:
        QMessageBox.warning(self, 'باركود غير موجود', f'لا يوجد منتج بهذا الباركود:\n{code}')
        self.search.setText(code); self.barcode_scan.selectAll(); return
    qty = self.qty.value()
    if p['quantity'] < qty:
        QMessageBox.warning(self, 'مخزون غير كاف', f"المتوفر من {p['name']} هو {p['quantity']}")
        self.barcode_scan.selectAll(); return
    for item in self.cart:
        if item['product_id'] == p['id']:
            if p['quantity'] < item['quantity'] + qty:
                QMessageBox.warning(self, 'مخزون غير كاف', 'الكمية المطلوبة أكبر من المخزون')
                self.barcode_scan.selectAll(); return
            item['quantity'] += qty; self.refresh_cart(); self.barcode_scan.clear(); self.notify(f"تمت إضافة {p['name']} بالباركود"); return
    self.cart.append(_v27_sale_cart_item_from_product(self, p, qty))
    self.refresh_cart(); self.barcode_scan.clear(); self.notify(f"تمت إضافة {p['name']} بالباركود")


def _v27_sales_add_selected_product(self):
    row = self.products.currentRow()
    if row < 0 or row >= len(self.product_rows):
        return
    p = self.product_rows[row]
    qty = self.qty.value()
    if p['quantity'] < qty:
        QMessageBox.warning(self, 'مخزون غير كاف', f"المتوفر من {p['name']} هو {p['quantity']}"); return
    for item in self.cart:
        if item['product_id'] == p['id']:
            if p['quantity'] < item['quantity'] + qty:
                QMessageBox.warning(self, 'مخزون غير كاف', 'الكمية المطلوبة أكبر من المخزون'); return
            item['quantity'] += qty; self.refresh_cart(); return
    self.cart.append(_v27_sale_cart_item_from_product(self, p, qty))
    self.refresh_cart()


def _v27_sales_refresh_cart(self):
    self.cart_table.setRowCount(len(self.cart))
    subtotal = 0.0; commission = 0.0
    level_id = _v27_combo_price_level_id(getattr(self, 'price_level', None)) if hasattr(self, 'price_level') else None
    for item in self.cart:
        try:
            line = self.service.resolve_sale_line(item['product_id'], item['quantity'], item.get('price_level_id') or level_id)
            item.update({
                'unit_price': float(line['unit_price']),
                'commission_percent': float(line.get('commission_percent', item.get('commission_percent', 0)) or 0),
                'price_level_id': line.get('price_level_id') or item.get('price_level_id') or level_id,
                'price_level_name': line.get('price_level_name') or 'مفرد',
                'promotion_id': line.get('promotion_id'),
                'promotion_name': line.get('promotion_name') or '',
                'original_unit_price': float(line.get('original_unit_price', item.get('unit_price', 0)) or 0),
                'promotion_discount_amount': float(line.get('promotion_discount_amount', 0) or 0),
                'free_quantity': int(line.get('free_quantity', 0) or 0),
            })
        except Exception as exc:
            log_exception(exc)
        subtotal += item['quantity'] * item['unit_price']
    discount_amount = self.current_discount_amount() if subtotal else 0.0
    discount_ratio = (discount_amount / subtotal) if subtotal else 0.0
    for r, item in enumerate(self.cart):
        line = item['quantity'] * item['unit_price']
        line_net = max(line - (line * discount_ratio), 0)
        item_comm = line_net * item.get('commission_percent', 0) / 100
        commission += item_comm
        name = item['product_name']
        details = []
        if item.get('price_level_name') and item.get('price_level_name') != 'مفرد':
            details.append(item.get('price_level_name'))
        if item.get('promotion_name'):
            details.append(item.get('promotion_name'))
        if details:
            name += '\n' + ' | '.join(details)
        for c, v in enumerate([name, item['quantity'], money(item['unit_price']), money(line), money(item_comm)]):
            self.cart_table.put(r, c, v)
    total = max(subtotal - discount_amount, 0)
    self.total_label.setText(f'الإجمالي: {money(subtotal)}\nالخصم: {money(discount_amount)}\nالصافي: {money(total)}\nعمولة الموظف: {money(commission)}')

# Disabled: SalesPage uses tabbed architecture, these methods are in SaleInvoiceTab
# SalesPage.refresh_products = _v27_sales_refresh_products
# SalesPage.scan_barcode_add = _v27_sales_scan_barcode_add
# SalesPage.add_selected_product = _v27_sales_add_selected_product
# SalesPage.refresh_cart = _v27_sales_refresh_cart


# Touch POS support for price levels and automatic offers.
_orig_touch_init_v27 = TouchPOSPage.__init__
def _v27_touch_init(self, service: AppService, notify, current_user=None):
    _orig_touch_init_v27(self, service, notify, current_user)
    try:
        self.price_level = QComboBox(); self.price_level.setMinimumHeight(34); self.price_level.currentIndexChanged.connect(lambda *_: (self.refresh_products(), self.refresh_cart()))
        self.price_level.addItem('تلقائي حسب الكمية والعروض', None)
        for lvl in self.service.list_price_levels(True):
            if lvl['name'] != 'مفرد':
                self.price_level.addItem(lvl['name'], lvl['id'])
        box = QFrame(); box.setObjectName('noticeBox'); lay = QVBoxLayout(box); lay.setContentsMargins(8,8,8,8); lay.addWidget(QLabel('مستوى السعر')); lay.addWidget(self.price_level)
        right = self.layout().itemAt(1).widget()
        right.layout().insertWidget(1, box)
    except Exception as exc:
        log_exception(exc)

TouchPOSPage.__init__ = _v27_touch_init


def _v27_touch_refresh_products(self):
    rows = self.service.list_products_for_sale(self.search.text()) if hasattr(self.service, 'list_products_for_sale') else self.service.list_products(self.search.text())
    cat = self.category.currentText()
    if cat and cat != 'كل التصنيفات':
        rows = [p for p in rows if (p['category'] or 'بدون صنف') == cat]
    self.product_rows = rows
    cols = 4
    self.cards.setColumnCount(cols); self.cards.setRowCount((len(rows)+cols-1)//cols)
    level_id = _v27_combo_price_level_id(getattr(self, 'price_level', None)) if hasattr(self, 'price_level') else None
    for r in range(self.cards.rowCount()):
        self.cards.setRowHeight(r, 95)
        for c in range(cols):
            self.cards.setColumnWidth(c, 190); self.cards.setItem(r, c, QTableWidgetItem(''))
    for i, p in enumerate(rows):
        price = p['sale_price']; extra = ''
        try:
            line = self.service.resolve_sale_line(p['id'], 1, level_id)
            price = line['unit_price']; extra = line.get('promotion_name') or line.get('price_level_name') or ''
        except Exception as exc:
            log_exception(exc)
        item = QTableWidgetItem(f"{p['name']}\n{money(price)}\n{extra}\nالمخزون: {p['quantity']}")
        item.setData(Qt.UserRole, i); item.setTextAlignment(Qt.AlignCenter); self.cards.setItem(i//cols, i%cols, item)


def _v27_touch_add_card(self, row, col):
    item = self.cards.item(row, col)
    if not item or item.data(Qt.UserRole) is None:
        return
    p = self.product_rows[item.data(Qt.UserRole)]
    if p['quantity'] <= 0:
        QMessageBox.warning(self, 'نفاد', 'هذا المنتج نافد'); return
    for it in self.cart:
        if it['product_id'] == p['id']:
            if p['quantity'] < it['quantity'] + 1:
                QMessageBox.warning(self, 'مخزون غير كاف', 'الكمية المطلوبة أكبر من المخزون'); return
            it['quantity'] += 1; self.refresh_cart(); return
    self.cart.append(_v27_sale_cart_item_from_product(self, p, 1))
    self.refresh_cart()


def _v27_touch_refresh_cart(self):
    self.cart_table.setRowCount(len(self.cart)); subtotal = 0.0
    level_id = _v27_combo_price_level_id(getattr(self, 'price_level', None)) if hasattr(self, 'price_level') else None
    for item in self.cart:
        try:
            line = self.service.resolve_sale_line(item['product_id'], item['quantity'], item.get('price_level_id') or level_id)
            item.update({'unit_price': float(line['unit_price']), 'promotion_name': line.get('promotion_name') or '', 'price_level_name': line.get('price_level_name') or 'مفرد', 'promotion_discount_amount': float(line.get('promotion_discount_amount', 0) or 0)})
        except Exception as exc:
            log_exception(exc)
    for r, it in enumerate(self.cart):
        line = it['quantity'] * it['unit_price']; subtotal += line
        name = it['product_name']
        if it.get('promotion_name'):
            name += '\n' + it['promotion_name']
        for c, v in enumerate([name, it['quantity'], money(line)]):
            self.cart_table.put(r, c, v)
    discount = float(self.discount.value() or 0)
    self.total.setText(f'الإجمالي: {money(subtotal)}\nالخصم: {money(discount)}\nالصافي: {money(max(subtotal-discount,0))}')

TouchPOSPage.refresh_products = _v27_touch_refresh_products
TouchPOSPage.add_card = _v27_touch_add_card
TouchPOSPage.refresh_cart = _v27_touch_refresh_cart


# Product page Excel shortcuts.
_orig_products_init_v27 = ProductsPage.__init__
def _v27_products_init(self, service: AppService, notify, current_user=None):
    _orig_products_init_v27(self, service, notify, current_user)
    try:
        panel = QFrame(); panel.setObjectName('surface'); panel.setMaximumWidth(230)
        lay = QVBoxLayout(panel); lay.setContentsMargins(10,10,10,10)
        title = QLabel('Excel'); title.setObjectName('sectionTitle')
        exp = QPushButton('⬇ تصدير Excel'); exp.setObjectName('primaryButton'); exp.clicked.connect(self.v27_export_excel)
        imp = QPushButton('⬆ استيراد Excel'); imp.setObjectName('warningButton'); imp.clicked.connect(self.v27_import_excel)
        tmpl = QPushButton('📄 قالب Excel'); tmpl.clicked.connect(self.v27_template_excel)
        note = QLabel('يدعم أسعار الجملة/الخاص والعروض من القالب.'); note.setWordWrap(True); note.setObjectName('noticeBox')
        lay.addWidget(title); lay.addWidget(exp); lay.addWidget(imp); lay.addWidget(tmpl); lay.addWidget(note); lay.addStretch()
        self.layout().addWidget(panel)
    except Exception as exc:
        log_exception(exc)


def _v27_products_export_excel(self):
    path, _ = QFileDialog.getSaveFileName(self, 'تصدير المنتجات Excel', 'products_export.xlsx', 'Excel (*.xlsx)')
    if not path:
        return
    try:
        out = self.service.export_products_xlsx(path)
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر التصدير', str(exc)); return
    QMessageBox.information(self, 'تم', f'تم تصدير المنتجات:\n{out}')


def _v27_products_template_excel(self):
    path, _ = QFileDialog.getSaveFileName(self, 'حفظ قالب Excel', 'products_template.xlsx', 'Excel (*.xlsx)')
    if not path:
        return
    try:
        out = self.service.export_products_template_xlsx(path)
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر إنشاء القالب', str(exc)); return
    QMessageBox.information(self, 'تم', f'تم إنشاء القالب:\n{out}')


def _v27_products_import_excel(self):
    path, _ = QFileDialog.getOpenFileName(self, 'استيراد منتجات من Excel', '', 'Excel (*.xlsx)')
    if not path:
        return
    try:
        result = self.service.import_products_xlsx(path)
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر الاستيراد', str(exc)); return
    self.refresh()
    QMessageBox.information(self, 'تم', f"تم الاستيراد\nإضافة: {result['added']}\nتحديث: {result['updated']}\nتخطي: {result['skipped']}")

ProductsPage.__init__ = _v27_products_init
ProductsPage.v27_export_excel = _v27_products_export_excel
ProductsPage.v27_template_excel = _v27_products_template_excel
ProductsPage.v27_import_excel = _v27_products_import_excel


# Tools tab for promotions and price levels.
def _v27_tools_build_pricing_tab(self):
    if hasattr(self, 'v27_pricing_tab_built'):
        return
    self.v27_pricing_tab_built = True
    tab = QWidget(); root = QVBoxLayout(tab); root.setSpacing(10)
    note = QLabel('إدارة مستويات الأسعار والعروض. يطبق النظام السعر النهائي تلقائياً عند البيع، ثم يظهر مستوى السعر/العرض داخل الفاتورة مع QR.')
    note.setWordWrap(True); note.setObjectName('noticeBox'); root.addWidget(note)
    top = QHBoxLayout()

    level_box = QFrame(); level_box.setObjectName('surface'); lf = QFormLayout(level_box)
    self.v27_level_name = QLineEdit(); self.v27_level_name.setPlaceholderText('مثال: جملة أو VIP')
    self.v27_level_auto = QCheckBox('تطبيق تلقائي حسب الكمية'); self.v27_level_auto.setChecked(True)
    self.v27_level_default = QCheckBox('افتراضي')
    self.v27_level_order = QSpinBox(); self.v27_level_order.setMaximum(9999); self.v27_level_order.setValue(50)
    save_level = QPushButton('حفظ مستوى السعر'); save_level.setObjectName('primaryButton'); save_level.clicked.connect(self.v27_save_price_level)
    lf.addRow('اسم المستوى', self.v27_level_name); lf.addRow('', self.v27_level_auto); lf.addRow('', self.v27_level_default); lf.addRow('الترتيب', self.v27_level_order); lf.addRow('', save_level)

    prod_box = QFrame(); prod_box.setObjectName('surface'); pf = QFormLayout(prod_box)
    self.v27_price_product = QComboBox(); self.v27_price_level = QComboBox()
    self.v27_level_price = QDoubleSpinBox(); self.v27_level_price.setMaximum(999999999); self.v27_level_price.setDecimals(0)
    self.v27_level_min = QSpinBox(); self.v27_level_min.setMaximum(999999); self.v27_level_min.setValue(1)
    save_prod_price = QPushButton('حفظ سعر المنتج لهذا المستوى'); save_prod_price.setObjectName('successButton'); save_prod_price.clicked.connect(self.v27_save_product_price_level)
    pf.addRow('المنتج', self.v27_price_product); pf.addRow('المستوى', self.v27_price_level); pf.addRow('السعر', self.v27_level_price); pf.addRow('الحد الأدنى', self.v27_level_min); pf.addRow('', save_prod_price)

    top.addWidget(level_box); top.addWidget(prod_box); root.addLayout(top)
    self.v27_product_prices_table = Table(['ID','المنتج','المستوى','السعر','الحد','تلقائي'])
    del_price = QPushButton('حذف سعر المستوى المحدد'); del_price.setObjectName('dangerButton'); del_price.clicked.connect(self.v27_delete_product_price_level)
    root.addWidget(self.v27_product_prices_table, 1); root.addWidget(del_price)

    promo_box = QFrame(); promo_box.setObjectName('surface'); pg = QGridLayout(promo_box)
    self.v27_promo_name = QLineEdit(); self.v27_promo_name.setPlaceholderText('مثال: خصم رمضان')
    self.v27_promo_scope = QComboBox(); self.v27_promo_scope.addItem('كل المنتجات','all'); self.v27_promo_scope.addItem('منتج محدد','product'); self.v27_promo_scope.addItem('صنف','category')
    self.v27_promo_product = QComboBox(); self.v27_promo_category = QLineEdit(); self.v27_promo_category.setPlaceholderText('اسم الصنف')
    self.v27_promo_type = QComboBox(); self.v27_promo_type.addItem('نسبة %','percent'); self.v27_promo_type.addItem('مبلغ خصم','amount'); self.v27_promo_type.addItem('سعر ثابت','fixed_price'); self.v27_promo_type.addItem('اشتر X واحصل على Y','buy_x_get_y')
    self.v27_promo_value = QDoubleSpinBox(); self.v27_promo_value.setMaximum(999999999); self.v27_promo_value.setDecimals(2)
    self.v27_promo_buy = QSpinBox(); self.v27_promo_buy.setMaximum(999999); self.v27_promo_free = QSpinBox(); self.v27_promo_free.setMaximum(999999)
    self.v27_promo_min = QSpinBox(); self.v27_promo_min.setMaximum(999999); self.v27_promo_min.setValue(1)
    self.v27_promo_start = QLineEdit(); self.v27_promo_start.setPlaceholderText('YYYY-MM-DD')
    self.v27_promo_end = QLineEdit(); self.v27_promo_end.setPlaceholderText('YYYY-MM-DD')
    self.v27_promo_priority = QSpinBox(); self.v27_promo_priority.setMaximum(9999)
    save_promo = QPushButton('حفظ العرض'); save_promo.setObjectName('primaryButton'); save_promo.clicked.connect(self.v27_save_promotion)
    fields = [
        ('اسم العرض', self.v27_promo_name), ('النطاق', self.v27_promo_scope), ('المنتج', self.v27_promo_product), ('الصنف', self.v27_promo_category),
        ('النوع', self.v27_promo_type), ('القيمة', self.v27_promo_value), ('اشتر X', self.v27_promo_buy), ('مجاني Y', self.v27_promo_free),
        ('أقل كمية', self.v27_promo_min), ('من تاريخ', self.v27_promo_start), ('إلى تاريخ', self.v27_promo_end), ('الأولوية', self.v27_promo_priority),
    ]
    for idx, (label, widget) in enumerate(fields):
        pg.addWidget(QLabel(label), idx//4*2, idx%4); pg.addWidget(widget, idx//4*2+1, idx%4)
    pg.addWidget(save_promo, 6, 0, 1, 4)
    root.addWidget(promo_box)
    self.v27_promotions_table = Table(['ID','العرض','النطاق','النوع','القيمة','الفترة','نشط'])
    del_promo = QPushButton('تعطيل العرض المحدد'); del_promo.setObjectName('dangerButton'); del_promo.clicked.connect(self.v27_deactivate_promotion)
    root.addWidget(self.v27_promotions_table, 1); root.addWidget(del_promo)

    excel_row = QHBoxLayout()
    ex = QPushButton('تصدير منتجات Excel'); ex.setObjectName('primaryButton'); ex.clicked.connect(self.v27_tools_export_excel)
    im = QPushButton('استيراد منتجات Excel'); im.setObjectName('warningButton'); im.clicked.connect(self.v27_tools_import_excel)
    tm = QPushButton('قالب Excel'); tm.clicked.connect(self.v27_tools_template_excel)
    excel_row.addWidget(ex); excel_row.addWidget(im); excel_row.addWidget(tm); root.addLayout(excel_row)
    self.tabs.addTab(tab, 'العروض والأسعار')


def _v27_tools_refresh_pricing(self):
    if not hasattr(self, 'v27_price_product'):
        return
    cur_prod = self.v27_price_product.currentData(); cur_level = self.v27_price_level.currentData(); cur_promo_prod = self.v27_promo_product.currentData()
    self.v27_price_product.clear(); self.v27_promo_product.clear()
    self.v27_promo_product.addItem('بدون', None)
    try:
        for p in self.service.list_products(''):
            label = f"{p['name']} | {p['barcode'] or ''}"
            self.v27_price_product.addItem(label, p['id']); self.v27_promo_product.addItem(label, p['id'])
    except Exception as exc:
        log_exception(exc)
    self.v27_price_level.clear()
    try:
        for lvl in self.service.list_price_levels(True):
            if lvl['name'] != 'مفرد':
                self.v27_price_level.addItem(lvl['name'], lvl['id'])
    except Exception as exc:
        log_exception(exc)
    if cur_prod is not None:
        idx = self.v27_price_product.findData(cur_prod)
        if idx >= 0: self.v27_price_product.setCurrentIndex(idx)
    if cur_promo_prod is not None:
        idx = self.v27_promo_product.findData(cur_promo_prod)
        if idx >= 0: self.v27_promo_product.setCurrentIndex(idx)
    if cur_level is not None:
        idx = self.v27_price_level.findData(cur_level)
        if idx >= 0: self.v27_price_level.setCurrentIndex(idx)
    rows = self.service.list_product_price_levels()
    self.v27_product_prices_table.setRowCount(len(rows))
    for r, row in enumerate(rows):
        vals = [row['id'], row['product_name'], row['level_name'], money(row['price']), row['min_quantity'], 'نعم' if row['auto_apply'] else 'لا']
        for c, v in enumerate(vals): self.v27_product_prices_table.put(r, c, v, row['id'] if c == 0 else None)
    promos = self.service.list_promotions(False)
    self.v27_promotions_table.setRowCount(len(promos))
    for r, p in enumerate(promos):
        scope = 'كل المنتجات' if p['scope_type']=='all' else (p['product_name'] if p['scope_type']=='product' else p['category'])
        period = f"{p['start_date'] or ''} → {p['end_date'] or ''}"
        vals = [p['id'], p['name'], scope, p['promo_type'], p['discount_value'], period, 'نعم' if p['active'] else 'لا']
        for c, v in enumerate(vals): self.v27_promotions_table.put(r, c, v, p['id'] if c == 0 else None)


def _v27_tools_save_price_level(self):
    try:
        self.service.save_price_level({'name': self.v27_level_name.text(), 'auto_apply': self.v27_level_auto.isChecked(), 'is_default': self.v27_level_default.isChecked(), 'sort_order': self.v27_level_order.value()})
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر الحفظ', str(exc)); return
    self.v27_level_name.clear(); self.v27_refresh_pricing(); self.notify('تم حفظ مستوى السعر')


def _v27_tools_save_product_price_level(self):
    try:
        self.service.set_product_price_level(self.v27_price_product.currentData(), self.v27_price_level.currentData(), self.v27_level_price.value(), self.v27_level_min.value())
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر الحفظ', str(exc)); return
    self.v27_refresh_pricing(); self.notify('تم حفظ سعر المستوى للمنتج')


def _v27_tools_delete_product_price_level(self):
    row = self.v27_product_prices_table.currentRow()
    item = self.v27_product_prices_table.item(row, 0) if row >= 0 else None
    if not item: return
    try:
        self.service.delete_product_price_level(item.data(Qt.UserRole))
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر الحذف', str(exc)); return
    self.v27_refresh_pricing(); self.notify('تم حذف سعر المستوى')


def _v27_tools_save_promotion(self):
    try:
        self.service.save_promotion({
            'name': self.v27_promo_name.text(), 'scope_type': self.v27_promo_scope.currentData(), 'product_id': self.v27_promo_product.currentData(), 'category': self.v27_promo_category.text(),
            'promo_type': self.v27_promo_type.currentData(), 'discount_value': self.v27_promo_value.value(), 'buy_qty': self.v27_promo_buy.value(), 'free_qty': self.v27_promo_free.value(),
            'min_quantity': self.v27_promo_min.value(), 'start_date': self.v27_promo_start.text(), 'end_date': self.v27_promo_end.text(), 'priority': self.v27_promo_priority.value(), 'active': 1,
        })
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر حفظ العرض', str(exc)); return
    self.v27_promo_name.clear(); self.v27_refresh_pricing(); self.notify('تم حفظ العرض')


def _v27_tools_deactivate_promotion(self):
    row = self.v27_promotions_table.currentRow()
    item = self.v27_promotions_table.item(row, 0) if row >= 0 else None
    if not item: return
    try:
        self.service.deactivate_promotion(item.data(Qt.UserRole))
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر التعطيل', str(exc)); return
    self.v27_refresh_pricing(); self.notify('تم تعطيل العرض')


def _v27_tools_export_excel(self):
    path, _ = QFileDialog.getSaveFileName(self, 'تصدير المنتجات Excel', 'products_export.xlsx', 'Excel (*.xlsx)')
    if not path: return
    try: out = self.service.export_products_xlsx(path)
    except Exception as exc: QMessageBox.warning(self, 'تعذر التصدير', str(exc)); return
    QMessageBox.information(self, 'تم', f'تم تصدير المنتجات:\n{out}')


def _v27_tools_template_excel(self):
    path, _ = QFileDialog.getSaveFileName(self, 'حفظ قالب Excel', 'products_template.xlsx', 'Excel (*.xlsx)')
    if not path: return
    try: out = self.service.export_products_template_xlsx(path)
    except Exception as exc: QMessageBox.warning(self, 'تعذر إنشاء القالب', str(exc)); return
    QMessageBox.information(self, 'تم', f'تم إنشاء القالب:\n{out}')


def _v27_tools_import_excel(self):
    path, _ = QFileDialog.getOpenFileName(self, 'استيراد منتجات من Excel', '', 'Excel (*.xlsx)')
    if not path: return
    try: result = self.service.import_products_xlsx(path)
    except Exception as exc: QMessageBox.warning(self, 'تعذر الاستيراد', str(exc)); return
    self.v27_refresh_pricing(); QMessageBox.information(self, 'تم', f"تم الاستيراد\nإضافة: {result['added']}\nتحديث: {result['updated']}\nتخطي: {result['skipped']}")


ToolsPage.build_pricing_tab = _v27_tools_build_pricing_tab
ToolsPage.v27_refresh_pricing = _v27_tools_refresh_pricing
ToolsPage.v27_save_price_level = _v27_tools_save_price_level
ToolsPage.v27_save_product_price_level = _v27_tools_save_product_price_level
ToolsPage.v27_delete_product_price_level = _v27_tools_delete_product_price_level
ToolsPage.v27_save_promotion = _v27_tools_save_promotion
ToolsPage.v27_deactivate_promotion = _v27_tools_deactivate_promotion
ToolsPage.v27_tools_export_excel = _v27_tools_export_excel
ToolsPage.v27_tools_template_excel = _v27_tools_template_excel
ToolsPage.v27_tools_import_excel = _v27_tools_import_excel

_orig_tools_init_v27 = ToolsPage.__init__
def _v27_tools_init(self, service: AppService, notify, current_user=None):
    _orig_tools_init_v27(self, service, notify, current_user)
    try:
        self.build_pricing_tab()
    except Exception as exc:
        try: self.notify(f'تعذر بناء تبويب العروض والأسعار: {exc}')
        except Exception as exc:
            log_exception(exc)

ToolsPage.__init__ = _v27_tools_init

_orig_tools_refresh_v27 = ToolsPage.refresh
def _v27_tools_refresh(self):
    result = _orig_tools_refresh_v27(self)
    try:
        self.v27_refresh_pricing()
    except Exception as exc:
        try: self.notify(f'تعذر تحديث العروض والأسعار: {exc}')
        except Exception as exc:
            log_exception(exc)
    return result

ToolsPage.refresh = _v27_tools_refresh

