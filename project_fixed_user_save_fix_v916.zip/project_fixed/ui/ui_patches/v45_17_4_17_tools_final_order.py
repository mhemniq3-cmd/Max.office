from __future__ import annotations

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage

_ORIG_INIT = ToolsPage.__init__
_ORIG_REFRESH = getattr(ToolsPage, 'refresh', None)

GROUPS = [
    ('audit', '📊 الرقابة والسجلات'),
    ('operations', '💰 المبيعات والعمليات'),
    ('inventory', '📦 المخزون والجرد'),
    ('settings', '🛡️ الإعدادات والنسخ الاحتياطي'),
]

GROUP_DESCRIPTIONS = {
    'audit': 'كل ما يتعلق بسجل الحركات، سجل العمليات، التدقيق، التنبيهات، وكشف الاحتيال.',
    'operations': 'أدوات العمل اليومي: المبيعات، الفواتير، الدفعات، العمولات، الأهداف، القسائم والعمليات السريعة.',
    'inventory': 'أدوات المنتجات والمخزون والجرد والفروع والمخازن والباركود.',
    'settings': 'إعدادات الشركة والنظام، المستخدمون والصلاحيات، النسخ الاحتياطي، الطابعة، والمساعدة.',
}


def _is_admin(page: ToolsPage) -> bool:
    try:
        user = getattr(page, 'current_user', None)
        role = str(user['role'] if user and 'role' in user.keys() else '')
        return role in ('مدير', 'admin', 'administrator', 'مالك')
    except Exception:
        return True


def _open_page(page: ToolsPage, key: str):
    try:
        win = page.window()
        if hasattr(win, 'show_page'):
            win.show_page(key)
            return
    except Exception as exc:
        try:
            log_exception(exc)
        except Exception:
            pass
    try:
        page.notify('هذه العملية مرتبطة بزر رئيسي في القائمة الجانبية')
    except Exception:
        pass


def _quick_action_page(page: ToolsPage) -> QWidget:
    tab = QWidget()
    root = QVBoxLayout(tab)
    root.setContentsMargins(18, 18, 18, 18)
    root.setSpacing(12)
    title = QLabel('⚡ العمليات الأكثر استخداماً يومياً')
    title.setObjectName('sectionTitle')
    note = QLabel('اختصارات منظمة لأكثر العمليات تكراراً. تفتح الصفحة المناسبة مباشرة بدون البحث داخل القوائم.')
    note.setObjectName('noticeBox')
    note.setWordWrap(True)
    root.addWidget(title)
    root.addWidget(note)
    grid = QGridLayout()
    grid.setHorizontalSpacing(12)
    grid.setVerticalSpacing(12)
    actions = [
        ('🧾 إنشاء فاتورة جديدة', 'sales', 'فتح صفحة البيع السريع'),
        ('👤 إضافة عميل جديد', 'customers', 'فتح صفحة الزبائن والديون'),
        ('📦 إضافة صنف/منتج جديد', 'products', 'فتح صفحة المنتجات والمخزون'),
        ('💵 تسجيل دفعة نقدية', 'customers', 'فتح صفحة الزبائن لتسجيل دفعة'),
        ('↩ إرجاع مبيعات', 'returns', 'فتح صفحة المرتجعات'),
        ('🔎 البحث الشامل', 'reports', 'فتح صفحة التقارير والبحث'),
    ]
    for i, (text, target, tip) in enumerate(actions):
        btn = QPushButton(text)
        btn.setMinimumHeight(58)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setObjectName('primaryButton' if i == 0 else 'navButton')
        btn.setToolTip(tip)
        btn.clicked.connect(lambda checked=False, k=target: _open_page(page, k))
        grid.addWidget(btn, i // 2, i % 2)
    root.addLayout(grid)
    root.addStretch(1)
    return tab


def _normalize_title(title: str) -> str:
    t = (title or '').strip()
    repl = {
        'سجل العمليات': 'سجل الحركات',
        'نسخ وباركود': 'النسخ الاحتياطي والباركود',
        'تقرير يومي احترافي': 'تقرير يومي احترافي',
        'أرشفة وفلاتر': 'أرشفة وبحث',
    }
    return repl.get(t, t)


def _group_for_title(title: str) -> str:
    t = (title or '').replace('️', '').strip()

    # 1) الرقابة والسجلات: كل ما يخص المتابعة والتدقيق والتنبيهات.
    if any(k in t for k in [
        'سجل الحركات', 'سجل العمليات', 'سجل التدقيق', 'تدقيق', 'Audit',
        'احتيال', 'Fraud', 'حساس', 'تنبيه', 'سلامة', 'أمان الحركات',
        'أرشفة وبحث', 'أرشفة وفلاتر', 'ملاحظات المدير', 'حماية',
    ]):
        return 'audit'

    # 2) المخزون والجرد: قبل العمليات حتى لا تذهب حركة المخزون إلى السجلات العامة.
    if any(k in t for k in [
        'مخزون', 'المخزون', 'منتج', 'منتجات', 'جرد', 'باركود', 'QR',
        'DataMatrix', 'الكمية', 'تسوية المخزون', 'فروع', 'مخازن', 'مستودعات',
        'الفروع والمخازن', 'الأسعار', 'تعديل أسعار',
    ]):
        return 'inventory'

    # 3) المبيعات والعمليات اليومية، وتشمل القسائم والعملاء والموردين لأنها أدوات تشغيل يومي.
    if any(k in t for k in [
        'العمليات السريعة', 'فاتورة', 'فواتير', 'مبيعات', 'مرتجع', 'مرتجعات',
        'إغلاق يومي', 'الإغلاق اليومي', 'شفت', 'صندوق الكاشير', 'عمولات',
        'أهداف', 'مكافآت', 'قائمة جميع الفواتير', 'الفواتير المعلقة',
        'الطباعة المباشرة', 'عروض الأسعار', 'أوامر التوريد', 'تحصيل',
        'قسيمة', 'قسائم', 'كوبون', 'كوبونات', 'العروض', 'خصم', 'الخصومات',
        'عملاء', 'عميل', 'زبائن', 'زبون', 'مورد', 'موردين', 'ديون', 'دفعات',
        'معاملات',
    ]):
        return 'operations'

    # 4) الإعدادات والنسخ الاحتياطي والصلاحيات والمساعدة.
    if any(k in t for k in [
        'إعداد', 'مستخدم', 'مستخدمين', 'المستخدمون', 'صلاحيات', 'نسخ',
        'استعادة', 'Google Drive', 'النظام', 'صحة', 'مساعدة', 'دليل',
        'مظهر', 'ثيم', 'الضريبة', 'الطابعة', 'شركة', 'الشركة',
    ]):
        return 'settings'

    # التقارير والتحليلات توضع مع العمليات لأنها تستخدم يومياً لمراجعة الأداء،
    # أما سجلات الرقابة فتم التقاطها أعلاه بكلمات السجل والتدقيق.
    if any(k in t for k in ['تقرير', 'تقارير', 'تحليلات', 'تحليل', 'لوحة تحكم', 'AI', 'مساعد', 'ذكي', 'توقع', 'أرباح', 'مصروف', 'ملخصات']):
        return 'operations'

    return 'settings'


def _priority(title: str) -> int:
    order = [
        # الرقابة والسجلات
        'مركز سجل الحركات', 'سجل الحركات', 'سجل العمليات', 'سجل التدقيق', 'كشف الاحتيال', 'الحركات الحساسة', 'سلامة التدقيق', 'ملاحظات المدير',
        # المبيعات والعمليات
        'العمليات السريعة', 'قائمة جميع الفواتير', 'الفواتير المعلقة', 'عروض الأسعار', 'أوامر التوريد', 'إدارة الدفعات والتحصيل', 'تقارير المبيعات السريعة',
        'الإغلاق اليومي', 'عمولات الموظفين', 'أهداف الموظفين', 'المرتجعات',
        'إنشاء قسيمة', 'الكوبونات', 'قائمة القسائم', 'توزيع القسائم', 'أداء القسائم', 'تقارير استخدام القسائم', 'إعدادات قواعد الخصم', 'العروض والأسعار', 'لوحة العروض', 'حالة العروض',
        'كشف حساب عميل', 'كشف حساب مورد', 'أرصدة وديون العملاء', 'أرصدة وديون الموردين', 'سجل المعاملات',
        # المخزون والجرد
        'حركة المخزون', 'جرد', 'الفروع والمخازن', 'تنبيهات الكمية', 'باركود', 'تعديل أسعار',
        # الإعدادات
        'إعدادات الشركة', 'إعدادات النظام', 'المستخدمين', 'المستخدمون', 'صلاحيات', 'الضريبة', 'النسخ', 'استعادة', 'Google Drive', 'فحص النظام', 'دليل الاستخدام', 'المظهر',
    ]
    for i, key in enumerate(order):
        if key in title:
            return i
    return 999


def _make_group_page(page: ToolsPage, group_key: str, items: list[tuple[str, QWidget]]) -> QWidget:
    wrap = QWidget()
    wrap.setObjectName(f'v4517417_group_{group_key}')
    lay = QVBoxLayout(wrap)
    lay.setContentsMargins(10, 10, 10, 10)
    lay.setSpacing(10)
    group_title = dict(GROUPS)[group_key]
    header = QLabel(group_title)
    header.setObjectName('sectionTitle')
    lay.addWidget(header)
    desc = GROUP_DESCRIPTIONS.get(group_key, '')
    if desc:
        note = QLabel(desc)
        note.setObjectName('noticeBox')
        note.setWordWrap(True)
        lay.addWidget(note)
    if group_key == 'settings' and not _is_admin(page):
        warning = QLabel('🔒 هذه المجموعة مخصصة للمدير أو المستخدمين ذوي الصلاحيات العالية.')
        warning.setObjectName('noticeBox')
        warning.setWordWrap(True)
        lay.addWidget(warning)
    inner = QTabWidget()
    inner.setObjectName(f'v4517417_inner_{group_key}')
    inner.setDocumentMode(True)
    inner.setMovable(False)
    sorted_items = sorted(items, key=lambda x: (_priority(x[0]), x[0]))
    if group_key == 'operations':
        # Keep quick actions available inside operations without making a separate main group.
        inner.addTab(_quick_action_page(page), 'العمليات السريعة')
    for title, widget in sorted_items:
        normalized = _normalize_title(title)
        # Avoid a duplicate quick-actions tab if another patch already created one.
        if group_key == 'operations' and 'العمليات السريعة' in normalized:
            continue
        inner.addTab(widget, normalized)
    if inner.count() == 0:
        empty = QLabel('لا توجد أدوات في هذه المجموعة حالياً.')
        empty.setObjectName('noticeBox')
        empty.setAlignment(Qt.AlignCenter)
        inner.addTab(empty, 'فارغ')
    lay.addWidget(inner, 1)
    return wrap


def _collect_existing_tabs(tabs: QTabWidget) -> list[tuple[str, QWidget]]:
    items: list[tuple[str, QWidget]] = []
    seen = set()
    while tabs.count():
        widget = tabs.widget(0)
        title = tabs.tabText(0) or 'أداة'
        tabs.removeTab(0)
        if widget is None:
            continue
        # Avoid duplicate legacy tabs with the exact same title and object identity.
        key = (title.strip(), int(widget.winId()) if widget.testAttribute(Qt.WA_WState_Created) else id(widget))
        if key in seen:
            continue
        seen.add(key)
        items.append((title.strip(), widget))
    return items



def _find_inner(page: ToolsPage, group_key: str):
    return page.findChild(QTabWidget, f'v4517417_inner_{group_key}')


def _absorb_stray_tabs(page: ToolsPage):
    """Move tabs created by older refresh patches into the grouped layout."""
    if not getattr(page, 'v4517417_tools_order_applied', False):
        return
    if not hasattr(page, 'tabs') or not isinstance(page.tabs, QTabWidget):
        return
    group_titles = {title for _, title in GROUPS}
    moved = []
    i = 0
    while i < page.tabs.count():
        title = page.tabs.tabText(i) or ''
        if title in group_titles:
            i += 1
            continue
        widget = page.tabs.widget(i)
        page.tabs.removeTab(i)
        if widget is not None:
            moved.append((title, widget))
    for title, widget in moved:
        group = _group_for_title(title)
        inner = _find_inner(page, group)
        if inner is None:
            continue
        # Do not add exact title twice to the same group.
        exists = False
        for j in range(inner.count()):
            if (inner.tabText(j) or '').strip() == _normalize_title(title):
                exists = True
                break
        if not exists:
            inner.addTab(widget, _normalize_title(title))

def _apply_final_tools_order(page: ToolsPage):
    if getattr(page, 'v4517417_tools_order_applied', False):
        _absorb_stray_tabs(page)
        return
    if not hasattr(page, 'tabs') or not isinstance(page.tabs, QTabWidget):
        return
    try:
        existing = _collect_existing_tabs(page.tabs)
        buckets = {k: [] for k, _ in GROUPS}
        for title, widget in existing:
            g = _group_for_title(title)
            buckets.setdefault(g, []).append((title, widget))
        # Rebuild the existing QTabWidget as the master grouped navigator.
        page.tabs.setDocumentMode(True)
        page.tabs.setMovable(False)
        page.tabs.setTabPosition(QTabWidget.North)
        added = 0
        for key, title in GROUPS:
            items = buckets.get(key, [])
            if not items:
                continue
            page.tabs.addTab(_make_group_page(page, key, items), title)
            added += 1
        # Safety guard: if classification unexpectedly produced no useful groups, restore the original tabs.
        if added == 0:
            for title, widget in existing:
                page.tabs.addTab(widget, title or 'أداة')
            return
        page.v4517417_tools_order_applied = True
        page.v4517417_grouped_items = buckets
        # Better field spacing in all reparented pages.
        for widget in page.findChildren(QWidget):
            if isinstance(widget, (QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox)):
                widget.setMinimumHeight(max(widget.minimumHeight(), 34))
            elif isinstance(widget, QPushButton):
                widget.setMinimumHeight(max(widget.minimumHeight(), 34))
                widget.setCursor(Qt.PointingHandCursor)
            elif isinstance(widget, QTableWidget):
                widget.setMinimumHeight(max(widget.minimumHeight(), 260))
                try:
                    widget.horizontalHeader().setStretchLastSection(True)
                except Exception:
                    pass
    except Exception as exc:
        try:
            log_exception(exc)
        except Exception:
            pass
        try:
            page.notify(f'تعذر ترتيب الأدوات النهائي: {exc}')
        except Exception:
            pass


def _tools_init(self, service, notify, current_user=None):
    _ORIG_INIT(self, service, notify, current_user)
    _apply_final_tools_order(self)


def _tools_refresh(self):
    if _ORIG_REFRESH:
        _ORIG_REFRESH(self)
    _apply_final_tools_order(self)


ToolsPage.__init__ = _tools_init
ToolsPage.refresh = _tools_refresh
ToolsPage.v4517417_apply_final_tools_order = _apply_final_tools_order
