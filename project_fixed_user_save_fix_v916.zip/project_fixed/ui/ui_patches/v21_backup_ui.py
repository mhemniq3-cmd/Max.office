from __future__ import annotations

from pathlib import Path
import html
import os

from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.theme_manager import apply_theme as theme_apply, current_theme_key as theme_current_key, set_theme_key as theme_set_key, theme_label as theme_display_label, theme_path as theme_qss_path
from ui.main_window_core import *
import ui.ui_patches.v11_sales_safety as _prev_v11_sales_safety
globals().update({k: v for k, v in vars(_prev_v11_sales_safety).items() if not k.startswith('__')})
import ui.ui_patches.v20_gdrive_ui as _prev_v20_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v20_gdrive_ui).items() if not k.startswith('__')})

def _tools_build_backup_tab_v21(self):
    tab = QWidget()
    outer = QVBoxLayout(tab)
    outer.setContentsMargins(14, 14, 14, 14)
    title = QLabel('🛡 النسخ الاحتياطي والباركود')
    title.setObjectName('sectionTitle')
    outer.addWidget(title)

    subtabs = QTabWidget()
    outer.addWidget(subtabs, 1)

    # Local backup tab
    local = QWidget(); local_l = QVBoxLayout(local); local_l.setContentsMargins(16, 16, 16, 16)
    local_info = QLabel('النسخة المحلية تُحفظ داخل مجلد backups بجانب قاعدة بيانات النظام. يُنصح بإنشاء نسخة قبل أي تحديث أو تعديل كبير.')
    local_info.setObjectName('noticeBox'); local_info.setWordWrap(True)
    local_buttons = QGridLayout(); local_buttons.setSpacing(10)
    local_backup = QPushButton('إنشاء نسخة محلية الآن'); local_backup.setObjectName('primaryButton'); local_backup.clicked.connect(self.backup)
    open_backup = QPushButton('فتح مجلد النسخ المحلية'); open_backup.clicked.connect(self.open_local_backup_folder)
    auto = QPushButton('اختبار النسخ التلقائي اليومي'); auto.setObjectName('warningButton'); auto.clicked.connect(self.test_auto_backup)
    restore = QPushButton('استرجاع نسخة احتياطية'); restore.setObjectName('dangerButton'); restore.clicked.connect(self.restore)
    local_buttons.addWidget(local_backup, 0, 0); local_buttons.addWidget(open_backup, 0, 1)
    local_buttons.addWidget(auto, 1, 0); local_buttons.addWidget(restore, 1, 1)
    local_l.addWidget(local_info); local_l.addLayout(local_buttons); local_l.addStretch(1)
    subtabs.addTab(local, 'النسخ المحلي')

    # Google Drive tab
    gtab = QWidget(); gl = QVBoxLayout(gtab); gl.setContentsMargins(16, 16, 16, 16)
    ginfo = QLabel('هذه الطريقة تعتمد على Google Drive for Desktop. اختر مجلد My Drive أو أي مجلد داخل Google Drive، وسيحفظ النظام النسخ داخل مجلد MaxSalesBackups داخله.')
    ginfo.setObjectName('noticeBox'); ginfo.setWordWrap(True)
    gcard = QFrame(); gcard.setObjectName('surface')
    gf = QFormLayout(gcard)
    self.gdrive_enabled = QCheckBox('تفعيل النسخ إلى Google Drive')
    self.gdrive_path = QLineEdit(); self.gdrive_path.setPlaceholderText('مثال: G:/My Drive أو C:/Users/Max/My Drive')
    browse = QPushButton('اختيار مجلد'); browse.clicked.connect(self.choose_google_drive_folder)
    path_row = QHBoxLayout(); path_row.addWidget(self.gdrive_path, 1); path_row.addWidget(browse)
    self.gdrive_status = QLabel('')
    self.gdrive_status.setObjectName('noticeBox'); self.gdrive_status.setWordWrap(True)
    gf.addRow('', self.gdrive_enabled)
    gf.addRow('مجلد Google Drive', path_row)
    gf.addRow('حالة Google Drive', self.gdrive_status)
    gbtns = QGridLayout(); gbtns.setSpacing(10)
    save_gdrive = QPushButton('حفظ الإعدادات'); save_gdrive.setObjectName('primaryButton'); save_gdrive.clicked.connect(self.save_google_drive_settings)
    test_gdrive = QPushButton('اختبار المجلد'); test_gdrive.setObjectName('warningButton'); test_gdrive.clicked.connect(self.test_google_drive_folder)
    backup_gdrive = QPushButton('نسخ الآن إلى المحلي و Google Drive'); backup_gdrive.setObjectName('successButton'); backup_gdrive.clicked.connect(self.backup)
    open_gdrive = QPushButton('فتح مجلد Google Drive'); open_gdrive.clicked.connect(self.open_google_drive_folder)
    gbtns.addWidget(save_gdrive, 0, 0); gbtns.addWidget(test_gdrive, 0, 1)
    gbtns.addWidget(backup_gdrive, 1, 0); gbtns.addWidget(open_gdrive, 1, 1)
    gl.addWidget(ginfo); gl.addWidget(gcard); gl.addLayout(gbtns); gl.addStretch(1)
    subtabs.addTab(gtab, 'Google Drive')

    # Barcode tab
    btab = QWidget(); bl = QVBoxLayout(btab); bl.setContentsMargins(16, 16, 16, 16)
    binfo = QLabel('قسم الباركود مخصص لطباعة ملصقات جميع المنتجات التي لها باركود أو توليد كود داخلي. إضافة المنتجات بالباركود تتم من صفحة المنتجات.')
    binfo.setObjectName('noticeBox'); binfo.setWordWrap(True)
    labels = QPushButton('طباعة جميع ملصقات الباركود'); labels.setObjectName('primaryButton'); labels.clicked.connect(self.print_labels)
    bl.addWidget(binfo); bl.addWidget(labels); bl.addStretch(1)
    subtabs.addTab(btab, 'الباركود')

    self.tabs.addTab(tab, 'نسخ وباركود')
    self.load_google_drive_settings()


def _tools_load_google_drive_settings_v21(self):
    cfg = self.service.load_google_drive_backup_settings() if hasattr(self.service, 'load_google_drive_backup_settings') else self.service.get_settings()
    if hasattr(self, 'gdrive_enabled'):
        self.gdrive_enabled.setChecked(str(cfg.get('google_drive_backup_enabled','0')).strip().lower() in ('1','true','yes','on','نعم'))
        self.gdrive_path.setText(str(cfg.get('google_drive_backup_path','') or ''))
        status = self.service.google_drive_status() if hasattr(self.service, 'google_drive_status') else str(cfg.get('last_google_drive_backup_status','') or '')
        self.gdrive_status.setText(status)


def _tools_choose_google_drive_folder_v21(self):
    start = self.gdrive_path.text().strip() if hasattr(self, 'gdrive_path') else ''
    folder = QFileDialog.getExistingDirectory(self, 'اختيار مجلد Google Drive', start)
    if folder:
        self.gdrive_path.setText(folder)
        self.save_google_drive_settings(show_message=False)
        self.notify('تم اختيار وحفظ مجلد Google Drive')


def _tools_save_google_drive_settings_v21(self, show_message=True):
    path = self.gdrive_path.text().strip() if hasattr(self, 'gdrive_path') else ''
    enabled = bool(self.gdrive_enabled.isChecked()) if hasattr(self, 'gdrive_enabled') else False
    if hasattr(self.service, 'save_google_drive_backup_settings'):
        self.service.save_google_drive_backup_settings(enabled, path, self.current_user.get('id') if self.current_user else None)
    else:
        self.service.save_settings({'google_drive_backup_enabled': '1' if enabled else '0', 'google_drive_backup_path': path}, self.current_user.get('id') if self.current_user else None)
    self.load_google_drive_settings()
    self.notify('تم حفظ إعدادات Google Drive')
    if show_message:
        QMessageBox.information(self, 'تم', 'تم حفظ إعدادات Google Drive بنجاح')


def _tools_test_google_drive_folder_v21(self):
    path = self.gdrive_path.text().strip() if hasattr(self, 'gdrive_path') else ''
    self.save_google_drive_settings(show_message=False)
    if hasattr(self.service, 'test_google_drive_backup_path'):
        ok, msg = self.service.test_google_drive_backup_path(path)
    else:
        ok, msg = self.service.test_google_drive_backup()
    self.load_google_drive_settings()
    QMessageBox.information(self, 'نجح اختبار Google Drive' if ok else 'فشل اختبار Google Drive', msg)


def _tools_open_path_v21(self, path):
    try:
        p = Path(path).resolve()
        p.mkdir(parents=True, exist_ok=True)
        if sys.platform.startswith('win'):
            _v21_os.startfile(str(p))
        elif sys.platform == 'darwin':
            _v21_subprocess.Popen(['open', str(p)])
        else:
            _v21_subprocess.Popen(['xdg-open', str(p)])
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر فتح المجلد', str(exc))


def _tools_open_local_backup_folder_v21(self):
    self._open_path_v21(self.service.backup_dir())


def _tools_open_google_drive_folder_v21(self):
    folder = self.gdrive_path.text().strip() if hasattr(self, 'gdrive_path') else ''
    if not folder:
        QMessageBox.warning(self, 'اختر مجلداً', 'اختر مجلد Google Drive أولاً')
        return
    target = self.service.google_drive_backup_target_dir(folder) if hasattr(self.service, 'google_drive_backup_target_dir') else Path(folder)
    self._open_path_v21(target)


def _tools_backup_v21(self):
    try:
        path = self.service.backup_database()
    except Exception as exc:
        QMessageBox.warning(self, 'فشل النسخ الاحتياطي', str(exc)); return
    st = self.service.load_google_drive_backup_settings() if hasattr(self.service, 'load_google_drive_backup_settings') else self.service.get_settings()
    gstatus = st.get('last_google_drive_backup_status', '') or ''
    self.notify(f'تم إنشاء نسخة احتياطية: {path}')
    if hasattr(self, 'gdrive_status'):
        self.load_google_drive_settings()
    extra = f'\n\nGoogle Drive:\n{gstatus}' if gstatus else ''
    QMessageBox.information(self, 'تم النسخ الاحتياطي', f'تم إنشاء النسخة المحلية:\n{path}{extra}')


ToolsPage.build_backup_tab = _tools_build_backup_tab_v21
ToolsPage.load_google_drive_settings = _tools_load_google_drive_settings_v21
ToolsPage.choose_google_drive_folder = _tools_choose_google_drive_folder_v21
ToolsPage.save_google_drive_settings = _tools_save_google_drive_settings_v21
ToolsPage.test_google_drive_folder = _tools_test_google_drive_folder_v21
ToolsPage._open_path_v21 = _tools_open_path_v21
ToolsPage.open_local_backup_folder = _tools_open_local_backup_folder_v21
ToolsPage.open_google_drive_folder = _tools_open_google_drive_folder_v21
ToolsPage.backup = _tools_backup_v21

# ================================================================
# V22 BACKUP & BARCODE UI FINAL FIX
# Save and test use the visible folder field directly and update the
# status label immediately. Google Drive settings remain persistent.
# ================================================================


