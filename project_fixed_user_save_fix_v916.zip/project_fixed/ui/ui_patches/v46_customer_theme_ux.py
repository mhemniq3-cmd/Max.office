from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import QColorDialog, QButtonGroup, QRadioButton

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage
from ui.main_window_core import MainWindow
from ui import theme_manager
from services.error_logger import log_exception

_ORIG_TOOLS_INIT_V46 = ToolsPage.__init__
_ORIG_OPEN_APPEARANCE_V46 = getattr(MainWindow, 'v431_open_appearance_dialog', None)


def _project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _preset_label(key: str) -> str:
    return dict(theme_manager.available_brand_presets()).get(key, key)


def _density_label(key: str) -> str:
    return dict(theme_manager.available_density_modes()).get(key, key)


def _apply_runtime_theme(owner, root: Path, mode: str | None = None, brand: dict | None = None):
    if brand is not None:
        theme_manager.save_brand_theme(brand, root)
    saved_mode = theme_manager.current_appearance_mode(root)
    theme_manager.apply_theme(root=root, theme=mode or saved_mode)
    try:
        if hasattr(owner, 'service') and hasattr(owner.service, 'save_settings'):
            owner.service.save_settings({
                'ui_mode': theme_manager.current_appearance_mode(root),
                'ui_brand_theme': theme_manager.current_brand_theme(root),
            })
    except Exception:
        pass


def _make_brand_controls(parent, root: Path):
    current = theme_manager.current_brand_theme(root)
    box = QFrame(); box.setObjectName('surface')
    lay = QVBoxLayout(box); lay.setContentsMargins(14, 14, 14, 14); lay.setSpacing(10)

    title = QLabel('🎨 هوية العميل والخطوط والمسافات')
    title.setObjectName('miniTitle')
    title.setWordWrap(True)
    lay.addWidget(title)

    form = QFormLayout(); form.setLabelAlignment(Qt.AlignRight); form.setFormAlignment(Qt.AlignTop)

    preset = QComboBox(); preset.setObjectName('brandPresetCombo')
    for key, label in theme_manager.available_brand_presets():
        preset.addItem(label, key)
    idx = preset.findData(current.get('preset'))
    if idx >= 0:
        preset.setCurrentIndex(idx)

    primary = QLineEdit(current.get('primary', '#2563eb')); primary.setObjectName('brandColorInput')
    secondary = QLineEdit(current.get('secondary', '#0f766e')); secondary.setObjectName('brandColorInput')
    accent = QLineEdit(current.get('accent', '#06b6d4')); accent.setObjectName('brandColorInput')
    danger = QLineEdit(current.get('danger', '#dc2626')); danger.setObjectName('brandColorInput')
    font = QComboBox(); font.setObjectName('fontFamilyCombo')
    for f in ['Segoe UI, Tahoma, Arial', 'Tahoma, Segoe UI, Arial', 'Arial, Tahoma', 'Cairo, Tahoma, Arial']:
        font.addItem(f, f)
    fidx = font.findData(current.get('font_family'))
    if fidx >= 0:
        font.setCurrentIndex(fidx)

    font_size = QSpinBox(); font_size.setRange(11, 18); font_size.setValue(int(current.get('font_size', 13))); font_size.setSuffix(' px')
    density = QComboBox(); density.setObjectName('densityCombo')
    for key, label in theme_manager.available_density_modes():
        density.addItem(label, key)
    didx = density.findData(current.get('density'))
    if didx >= 0:
        density.setCurrentIndex(didx)
    radius = QSpinBox(); radius.setRange(8, 28); radius.setValue(int(current.get('radius', 16))); radius.setSuffix(' px')

    def color_row(edit: QLineEdit):
        row = QWidget(); row_l = QHBoxLayout(row); row_l.setContentsMargins(0, 0, 0, 0); row_l.setSpacing(6)
        choose = QPushButton('اختيار'); choose.setObjectName('primaryButton')
        def pick():
            color = QColorDialog.getColor(parent=parent)
            if color.isValid():
                edit.setText(color.name())
        choose.clicked.connect(pick)
        row_l.addWidget(choose); row_l.addWidget(edit, 1)
        return row

    form.addRow('قالب سريع:', preset)
    form.addRow('اللون الرئيسي:', color_row(primary))
    form.addRow('اللون الثانوي:', color_row(secondary))
    form.addRow('لون التمييز:', color_row(accent))
    form.addRow('لون التنبيه:', color_row(danger))
    form.addRow('الخط:', font)
    form.addRow('حجم الخط:', font_size)
    form.addRow('كثافة المسافات:', density)
    form.addRow('استدارة البطاقات:', radius)
    lay.addLayout(form)

    preview = QLabel('معاينة فورية: الأزرار، الحقول، الجداول، الشريط الجانبي والبطاقات ستتبع هذه القيم.')
    preview.setObjectName('noticeBox')
    preview.setWordWrap(True)
    lay.addWidget(preview)

    def read_values():
        return {
            'preset': preset.currentData() or 'ocean',
            'primary': primary.text().strip(),
            'secondary': secondary.text().strip(),
            'accent': accent.text().strip(),
            'danger': danger.text().strip(),
            'font_family': font.currentData() or font.currentText(),
            'font_size': font_size.value(),
            'density': density.currentData() or 'comfortable',
            'radius': radius.value(),
        }

    def apply_preset():
        key = preset.currentData() or 'ocean'
        p = theme_manager.PRESETS.get(key, theme_manager.PRESETS['ocean'])
        primary.setText(p['primary']); secondary.setText(p['secondary']); accent.setText(p['accent']); danger.setText(p['danger'])

    preset.currentIndexChanged.connect(apply_preset)
    box.read_brand_values = read_values  # type: ignore[attr-defined]
    return box


def _tools_init_v46(self, service, notify, current_user=None):
    _ORIG_TOOLS_INIT_V46(self, service, notify, current_user)
    try:
        self.build_v46_customer_theme_tab()
    except Exception as exc:
        log_exception(exc, 'build V46 customer theme tab')


def _build_v46_customer_theme_tab(self: ToolsPage):
    tab = QWidget(); root_l = QVBoxLayout(tab); root_l.setContentsMargins(18, 18, 18, 18); root_l.setSpacing(12)
    title = QLabel('✨ تجربة المستخدم والهوية البصرية')
    title.setObjectName('sectionTitle')
    note = QLabel('هذه الصفحة تجعل البرنامج قابلاً للتخصيص حسب هوية العميل: ألوان، خطوط، مسافات، ووضع فاتح/داكن/تلقائي مع تطبيق فوري.')
    note.setObjectName('noticeBox'); note.setWordWrap(True)
    root_l.addWidget(title); root_l.addWidget(note)

    root_path = _project_root()
    brand_box = _make_brand_controls(self, root_path)
    root_l.addWidget(brand_box)

    row = QHBoxLayout(); row.setSpacing(8)
    apply_btn = QPushButton('تطبيق وحفظ الهوية'); apply_btn.setObjectName('primaryButton')
    reset_btn = QPushButton('إرجاع الافتراضي')
    row.addWidget(reset_btn); row.addWidget(apply_btn); row.addStretch(1)
    root_l.addLayout(row)

    help_text = QLabel('نصيحة: استخدم الوضع المضغوط للحواسيب الصغيرة، والمريح للوضع اليومي، والواسع للشاشات الكبيرة أو نقاط البيع اللمسية.')
    help_text.setObjectName('mutedText'); help_text.setWordWrap(True)
    root_l.addWidget(help_text)
    root_l.addStretch(1)

    def apply_brand():
        try:
            values = brand_box.read_brand_values()  # type: ignore[attr-defined]
            saved = theme_manager.save_brand_theme(values, root_path)
            theme_manager.apply_theme(root=root_path)
            try:
                if hasattr(self.service, 'save_settings'):
                    self.service.save_settings({'ui_brand_theme': saved})
            except Exception:
                pass
            self.notify(f"تم تطبيق هوية العميل: {_preset_label(saved['preset'])} / {_density_label(saved['density'])}")
        except Exception as exc:
            log_exception(exc, 'V46 apply customer theme')
            QMessageBox.warning(self, 'تعذر تطبيق الهوية', str(exc))

    def reset_brand():
        try:
            theme_manager.reset_brand_theme(root_path)
            theme_manager.apply_theme(root=root_path)
            self.notify('تمت استعادة الهوية الافتراضية')
        except Exception as exc:
            log_exception(exc, 'V46 reset customer theme')
            QMessageBox.warning(self, 'تعذر الاستعادة', str(exc))

    apply_btn.clicked.connect(apply_brand)
    reset_btn.clicked.connect(reset_brand)
    self.tabs.addTab(tab, 'الهوية البصرية')


def _v46_open_appearance_dialog(self: MainWindow):
    try:
        dlg = QDialog(self)
        dlg.setWindowTitle('المظهر والهوية البصرية')
        dlg.setMinimumWidth(560)
        # Limit height so it fits on small screens
        dlg.setMaximumHeight(700)
        
        main_lay = QVBoxLayout(dlg)
        main_lay.setContentsMargins(0, 0, 0, 0)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("QScrollArea { background: transparent; }")
        
        container = QWidget()
        lay = QVBoxLayout(container)
        lay.setContentsMargins(20, 20, 20, 20)
        lay.setSpacing(12)
        
        title = QLabel('🌓 المظهر والهوية البصرية')
        title.setObjectName('sectionTitle')
        note = QLabel('اختر الوضع الفاتح/الداكن ثم خصص ألوان وهوية العميل. التغيير يطبق فورياً ويحفظ للاستخدام القادم.')
        note.setObjectName('noticeBox'); note.setWordWrap(True)
        lay.addWidget(title); lay.addWidget(note)

        root = _project_root()
        current = theme_manager.current_appearance_mode(root)
        mode_buttons = {}
        group = QButtonGroup(dlg)
        mode_box = QFrame(); mode_box.setObjectName('surface')
        mode_l = QVBoxLayout(mode_box); mode_l.setContentsMargins(14, 14, 14, 14); mode_l.setSpacing(8)
        for mode, label in theme_manager.available_appearance_modes():
            rb = QRadioButton(label); rb.setObjectName('appearanceRadio'); rb.setChecked(mode == current)
            group.addButton(rb); mode_buttons[mode] = rb; mode_l.addWidget(rb)
        status = QLabel(f'الحالي: {dict(theme_manager.available_appearance_modes()).get(current, current)}')
        status.setObjectName('mutedText'); mode_l.addWidget(status)
        lay.addWidget(mode_box)

        brand_box = _make_brand_controls(dlg, root)
        lay.addWidget(brand_box)
        
        scroll.setWidget(container)
        main_lay.addWidget(scroll)

        row = QHBoxLayout(); row.setSpacing(8)
        row.setContentsMargins(20, 10, 20, 20)
        close = QPushButton('إغلاق'); close.clicked.connect(dlg.accept)
        reset = QPushButton('افتراضي')
        apply = QPushButton('تطبيق وحفظ'); apply.setObjectName('primaryButton')
        row.addWidget(close); row.addWidget(reset); row.addWidget(apply)
        main_lay.addLayout(row)

        def selected_mode():
            for m, rb in mode_buttons.items():
                if rb.isChecked():
                    return m
            return current

        def do_apply():
            try:
                mode = theme_manager.set_appearance_mode(selected_mode(), root)
                brand = brand_box.read_brand_values()  # type: ignore[attr-defined]
                saved_brand = theme_manager.save_brand_theme(brand, root)
                theme_manager.apply_theme(root=root, theme=mode)
                status.setText(f"الحالي: {dict(theme_manager.available_appearance_modes()).get(mode, mode)} / {_preset_label(saved_brand['preset'])}")
                self.notify('تم تطبيق المظهر والهوية البصرية')
            except Exception as exc:
                log_exception(exc, 'V46 apply appearance and brand')
                QMessageBox.warning(dlg, 'تعذر التطبيق', str(exc))

        def do_reset():
            try:
                theme_manager.set_appearance_mode('light', root)
                theme_manager.reset_brand_theme(root)
                theme_manager.apply_theme(root=root, theme='light')
                self.notify('تمت استعادة المظهر الافتراضي')
            except Exception as exc:
                log_exception(exc, 'V46 reset appearance and brand')
                QMessageBox.warning(dlg, 'تعذر الاستعادة', str(exc))

        apply.clicked.connect(do_apply)
        reset.clicked.connect(do_reset)
        dlg.exec()
    except Exception as exc:
        log_exception(exc, 'V46 open appearance dialog')
        if _ORIG_OPEN_APPEARANCE_V46:
            return _ORIG_OPEN_APPEARANCE_V46(self)
        QMessageBox.warning(self, 'تعذر فتح المظهر', str(exc))


ToolsPage.__init__ = _tools_init_v46
ToolsPage.build_v46_customer_theme_tab = _build_v46_customer_theme_tab
MainWindow.v431_open_appearance_dialog = _v46_open_appearance_dialog

# V46 markers: customer theme UX dark light brand colors density font scalable spacing الهوية البصرية
