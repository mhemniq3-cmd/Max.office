from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.main_window_core import SalesPage, Table


def _v40_1_small_label(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName('formLabel')
    return label


def _v40_1_form_card(title: str) -> tuple[QFrame, QVBoxLayout]:
    card = QFrame()
    card.setObjectName('innerCard')
    lay = QVBoxLayout(card)
    lay.setContentsMargins(14, 14, 14, 14)
    lay.setSpacing(10)
    ttl = QLabel(title)
    ttl.setObjectName('smallSectionTitle')
    lay.addWidget(ttl)
    return card, lay


def _v40_1_wrap_layout(layout: QLayout) -> QWidget:
    w = QWidget()
    w.setLayout(layout)
    return w


def _v40_1_sales_build(self: SalesPage):
    root = QHBoxLayout(self)
    root.setContentsMargins(6, 6, 6, 6)
    root.setSpacing(14)

    # Left: products + quick sale buttons
    left = QFrame()
    left.setObjectName('surface')
    left_l = QVBoxLayout(left)
    left_l.setContentsMargins(14, 14, 14, 14)
    left_l.setSpacing(10)

    title = QLabel('🛒 البيع السريع')
    title.setObjectName('sectionTitle')
    hint = QLabel('امسح الباركود أو ابحث عن المنتج، أو اضغط أحد أزرار البيع السريع لإضافته مباشرة إلى الفاتورة.')
    hint.setObjectName('noticeBox')
    hint.setWordWrap(True)

    self.barcode_scan = QLineEdit()
    self.barcode_scan.setPlaceholderText('امسح باركود المنتج ثم Enter...')
    self.barcode_scan.returnPressed.connect(self.scan_barcode_add)

    self.search = QLineEdit()
    self.search.setPlaceholderText('بحث بالاسم أو الباركود أو الصنف...')
    self.search.textChanged.connect(self.refresh_products)

    quick_box = QFrame()
    quick_box.setObjectName('noticeBox')
    quick_l = QVBoxLayout(quick_box)
    quick_l.setContentsMargins(10, 10, 10, 10)
    quick_l.setSpacing(8)
    quick_head = QHBoxLayout()
    quick_title = QLabel('⚡ أزرار البيع السريع')
    quick_title.setObjectName('smallSectionTitle')
    self.quick_manage_btn = QPushButton('إدارة')
    self.quick_manage_btn.setObjectName('primaryButton')
    self.quick_manage_btn.setMaximumWidth(90)
    self.quick_manage_btn.clicked.connect(self.manage_quick_sale_buttons)
    quick_head.addWidget(quick_title)
    quick_head.addStretch(1)
    quick_head.addWidget(self.quick_manage_btn)
    self.quick_grid = QGridLayout()
    self.quick_grid.setSpacing(8)
    quick_l.addLayout(quick_head)
    quick_l.addLayout(self.quick_grid)

    self.products = Table(['المنتج', 'السعر/العرض', 'المخزون', 'الصنف'])
    self.products.doubleClicked.connect(self.add_selected_product)

    left_l.addWidget(title)
    left_l.addWidget(hint)
    left_l.addWidget(self.barcode_scan)
    left_l.addWidget(self.search)
    left_l.addWidget(quick_box)
    left_l.addWidget(self.products, 1)

    # Center: cart
    center = QFrame()
    center.setObjectName('surface')
    center_l = QVBoxLayout(center)
    center_l.setContentsMargins(14, 14, 14, 14)
    center_l.setSpacing(10)
    cart_title = QLabel('🧾 الفاتورة الحالية')
    cart_title.setObjectName('sectionTitle')
    self.cart_table = Table(['المنتج', 'كمية', 'سعر', 'إجمالي', 'عمولة'])
    actions = QHBoxLayout()
    actions.setSpacing(10)
    self.remove_btn = QPushButton('🗑 حذف المحدد')
    self.remove_btn.setObjectName('dangerButton')
    self.remove_btn.clicked.connect(self.remove_selected)
    self.clear_btn = QPushButton('مسح السلة')
    self.clear_btn.clicked.connect(self.clear_cart)
    self.preview_btn = QPushButton('👁 معاينة الفاتورة')
    self.preview_btn.setObjectName('primaryButton')
    self.preview_btn.clicked.connect(lambda: self.show_invoice_preview(False))
    actions.addWidget(self.remove_btn)
    actions.addWidget(self.clear_btn)
    actions.addWidget(self.preview_btn)
    center_l.addWidget(cart_title)
    center_l.addWidget(self.cart_table, 1)
    center_l.addLayout(actions)

    # Right: invoice data
    right_scroll = QScrollArea()
    right_scroll.setWidgetResizable(True)
    right_scroll.setFrameShape(QFrame.NoFrame)
    right_scroll.setObjectName('cleanScroll')
    right_scroll.setMinimumWidth(405)
    right_scroll.setMaximumWidth(500)
    right = QFrame()
    right.setObjectName('surface')
    right_l = QVBoxLayout(right)
    right_l.setContentsMargins(16, 16, 16, 16)
    right_l.setSpacing(12)

    user_text = (self.current_user['full_name'] or self.current_user['username']) if self.current_user else '-'
    self.user_label = QLabel(f'المستخدم الحالي: {user_text}')
    self.user_label.setObjectName('noticeBox')
    self.user_label.setWordWrap(True)

    people_card, people_l = _v40_1_form_card('بيانات الفاتورة')
    people_form = QFormLayout()
    people_form.setLabelAlignment(Qt.AlignRight)
    people_form.setVerticalSpacing(12)
    self.employee = QComboBox()
    self.customer_search = QLineEdit()
    self.customer_search.setPlaceholderText('بحث سريع عن الزبون...')
    self.customer_search.textChanged.connect(self.filter_customers)
    self.customer = QComboBox()
    self.customer.currentIndexChanged.connect(self.update_customer_info)
    self.payment = QComboBox()
    self.payment.addItems(['نقدي', 'بطاقة', 'تحويل', 'آجل'])
    self.payment.currentIndexChanged.connect(self.update_customer_info)
    self.price_level = QComboBox()
    self.price_level.setMinimumHeight(38)
    self.price_level.currentIndexChanged.connect(lambda *_: (self.refresh_products(), self.refresh_cart()))
    self.note = QLineEdit()
    self.note.setPlaceholderText('ملاحظة اختيارية')
    for w in (self.employee, self.customer_search, self.customer, self.payment, self.price_level, self.note):
        w.setMinimumHeight(38)

    customer_tools = QHBoxLayout()
    self.add_customer_btn = QPushButton('➕ زبون سريع')
    self.add_customer_btn.setObjectName('primaryButton')
    self.add_customer_btn.clicked.connect(self.add_quick_customer)
    self.fav_customer_btn = QPushButton('⭐ المميزين')
    self.fav_customer_btn.setObjectName('warningButton')
    self.fav_customer_btn.clicked.connect(self.load_favorite_customers)
    customer_tools.addWidget(self.add_customer_btn)
    customer_tools.addWidget(self.fav_customer_btn)

    self.customer_info = QLabel('دين الزبون الحالي: 0 د.ع')
    self.customer_info.setObjectName('noticeBox')
    self.customer_info.setWordWrap(True)

    people_form.addRow('موظف العمولة', self.employee)
    people_form.addRow('بحث الزبون', self.customer_search)
    people_form.addRow('الزبون', self.customer)
    people_form.addRow('', _v40_1_wrap_layout(customer_tools))
    people_form.addRow('', self.customer_info)
    people_form.addRow('طريقة الدفع', self.payment)
    people_form.addRow('مستوى السعر', self.price_level)
    people_form.addRow('ملاحظة', self.note)
    people_l.addLayout(people_form)

    qty_card, qty_l = _v40_1_form_card('الكمية والخصم')
    qty_grid = QGridLayout()
    qty_grid.setHorizontalSpacing(12)
    qty_grid.setVerticalSpacing(10)
    self.qty = QSpinBox()
    self.qty.setRange(1, 99999)
    self.qty.setValue(1)
    self.qty.setMinimumHeight(40)
    self.discount = QDoubleSpinBox()
    self.discount.setRange(0, 999999999)
    self.discount.setDecimals(0)
    self.discount.setMinimumHeight(40)
    self.discount.valueChanged.connect(self.refresh_cart)
    self.discount_type = QComboBox()
    self.discount_type.addItem('مبلغ', 'amount')
    self.discount_type.addItem('نسبة %', 'percent')
    self.discount_type.setMinimumHeight(40)
    self.discount_type.currentIndexChanged.connect(self.refresh_cart)
    qty_grid.addWidget(_v40_1_small_label('الكمية'), 0, 0)
    qty_grid.addWidget(_v40_1_small_label('الخصم'), 0, 1)
    qty_grid.addWidget(self.qty, 1, 0)
    qty_grid.addWidget(self.discount, 1, 1)
    qty_grid.addWidget(_v40_1_small_label('نوع الخصم'), 2, 0)
    qty_grid.addWidget(self.discount_type, 3, 0, 1, 2)
    qty_l.addLayout(qty_grid)

    self.total_label = QLabel('الصافي: 0 د.ع')
    self.total_label.setObjectName('bigTotal')
    self.complete_btn = QPushButton('✅ حفظ البيع وإصدار الفاتورة')
    self.complete_btn.setObjectName('successButton')
    self.complete_btn.clicked.connect(self.complete_sale)
    self.suspend_btn = QPushButton('⏸ تعليق الفاتورة')
    self.suspend_btn.setObjectName('warningButton')
    self.suspend_btn.clicked.connect(self.suspend_current_sale)
    for b in (self.complete_btn, self.suspend_btn):
        b.setMinimumHeight(46)

    note = QLabel('يمكنك استخدام البحث، الباركود، أو أزرار البيع السريع. عاين الفاتورة قبل الطباعة لتقليل الأخطاء.')
    note.setObjectName('noticeBox')
    note.setWordWrap(True)

    right_l.addWidget(QLabel('بيانات البيع'))
    right_l.addWidget(self.user_label)
    right_l.addWidget(people_card)
    right_l.addWidget(qty_card)
    right_l.addWidget(note)
    right_l.addWidget(self.total_label)
    right_l.addWidget(self.complete_btn)
    right_l.addWidget(self.suspend_btn)
    right_l.addStretch()
    right_scroll.setWidget(right)

    root.addWidget(left, 3)
    root.addWidget(center, 4)
    root.addWidget(right_scroll)


_orig_refresh_quick_sale_buttons_v40_1 = SalesPage.refresh_quick_sale_buttons


def _v40_1_refresh_quick_sale_buttons(self: SalesPage):
    """Refresh quick sale buttons safely even if an older layout patch ran."""
    if not hasattr(self, 'quick_grid') or self.quick_grid is None:
        return
    return _orig_refresh_quick_sale_buttons_v40_1(self)


# Disabled: SalesPage now has built-in tabbed interface
# SalesPage.build = _v40_1_sales_build
SalesPage.refresh_quick_sale_buttons = _v40_1_refresh_quick_sale_buttons
