from __future__ import annotations

from pathlib import Path
import html
import os

from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.theme_manager import apply_theme as theme_apply, current_theme_key as theme_current_key, set_theme_key as theme_set_key, theme_label as theme_display_label, theme_path as theme_qss_path
from ui.main_window_core import *
import ui.ui_patches.v11_sales_safety as _prev_v11_sales_safety
globals().update({k: v for k, v in vars(_prev_v11_sales_safety).items() if not k.startswith('__')})
import ui.ui_patches.v20_gdrive_ui as _prev_v20_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v20_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v21_backup_ui as _prev_v21_backup_ui
globals().update({k: v for k, v in vars(_prev_v21_backup_ui).items() if not k.startswith('__')})
import ui.ui_patches.v22_gdrive_ui as _prev_v22_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v22_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v23_tools_reports as _prev_v23_tools_reports
globals().update({k: v for k, v in vars(_prev_v23_tools_reports).items() if not k.startswith('__')})
import ui.ui_patches.v25_lazy_permissions as _prev_v25_lazy_permissions
globals().update({k: v for k, v in vars(_prev_v25_lazy_permissions).items() if not k.startswith('__')})
import ui.ui_patches.v26_tools_refresh as _prev_v26_tools_refresh
globals().update({k: v for k, v in vars(_prev_v26_tools_refresh).items() if not k.startswith('__')})
import ui.ui_patches.v27_pricing_excel_ui as _prev_v27_pricing_excel_ui
globals().update({k: v for k, v in vars(_prev_v27_pricing_excel_ui).items() if not k.startswith('__')})
import ui.ui_patches.v28_professional_ui as _prev_v28_professional_ui
globals().update({k: v for k, v in vars(_prev_v28_professional_ui).items() if not k.startswith('__')})
import ui.ui_patches.v30_layout_cleanup as _prev_v30_layout_cleanup
globals().update({k: v for k, v in vars(_prev_v30_layout_cleanup).items() if not k.startswith('__')})
import ui.ui_patches.v31_goals_help_dates as _prev_v31_goals_help_dates
globals().update({k: v for k, v in vars(_prev_v31_goals_help_dates).items() if not k.startswith('__')})
import ui.ui_patches.v32_multi_theme as _prev_v32_multi_theme
globals().update({k: v for k, v in vars(_prev_v32_multi_theme).items() if not k.startswith('__')})

def _v322_theme_button_refine(self):
    """Make the theme chooser a smaller interactive icon beside backup."""
    try:
        self.theme_button.setText('🎨')
        self.theme_button.setFixedSize(34, 34)
        self.theme_button.setToolTip('تغيير الثيم - بجانب زر النسخة الاحتياطية')
        self.theme_button.setCursor(Qt.PointingHandCursor)
        self.theme_button.setMenu(self.v32_make_theme_menu())
    except Exception as exc:
        log_exception(exc)


def _v322_tools_group_name(tab_title: str) -> str:
    title = tab_title or ''
    if any(x in title for x in ['نسخ', 'إعدادات الشركة', 'إعدادات متقدمة', 'المظهر']):
        return '⚙ النظام والنسخ'
    if any(x in title for x in ['طباعة', 'الفواتير المعلقة', 'إغلاق', 'المصاريف', 'صندوق']):
        return '🧾 البيع والطباعة والصندوق'
    if any(x in title for x in ['المخزون', 'جرد', 'الفروع', 'المخازن']):
        return '📦 المخزون والفروع'
    if any(x in title for x in ['عمولات', 'أهداف', 'العروض', 'الأسعار']):
        return '🎯 الموظفون والعروض'
    if any(x in title for x in ['سجل', 'تدقيق', 'فحص']):
        return '🛡 الرقابة والسجلات'
    if any(x in title for x in ['المساعدة', 'شرح']):
        return '❔ المساعدة'
    return '🧩 خدمات أخرى'


def _v322_reorganize_tools_tabs(self):
    """Group the busy tools page into clear service categories without removing features."""
    try:
        old_tabs = getattr(self, 'tabs', None)
        if not isinstance(old_tabs, QTabWidget) or getattr(self, '_v322_tools_reorganized', False):
            return
        collected = []
        while old_tabs.count() > 0:
            widget = old_tabs.widget(0)
            title = old_tabs.tabText(0)
            icon = old_tabs.tabIcon(0)
            old_tabs.removeTab(0)
            collected.append((title, widget, icon))
        if not collected:
            return

        order = [
            '⚙ النظام والنسخ',
            '🧾 البيع والطباعة والصندوق',
            '📦 المخزون والفروع',
            '🎯 الموظفون والعروض',
            '🛡 الرقابة والسجلات',
            '❔ المساعدة',
            '🧩 خدمات أخرى',
        ]
        groups = {name: [] for name in order}
        for title, widget, icon in collected:
            groups.setdefault(_v322_tools_group_name(title), []).append((title, widget, icon))

        new_tabs = QTabWidget()
        new_tabs.setObjectName('toolsCategoryTabs')
        new_tabs.setDocumentMode(True)
        for group_name in order:
            items = groups.get(group_name) or []
            if not items:
                continue
            page = QWidget()
            page_l = QVBoxLayout(page)
            page_l.setContentsMargins(8, 8, 8, 8)
            page_l.setSpacing(8)
            hint = QLabel('تم ترتيب خدمات الأدوات داخل هذه المجموعة لتقليل التداخل وتسهيل الوصول.')
            hint.setObjectName('noticeBox')
            hint.setWordWrap(True)
            inner = QTabWidget()
            inner.setObjectName('toolsInnerTabs')
            inner.setDocumentMode(True)
            for title, widget, icon in items:
                inner.addTab(widget, icon, title)
            page_l.addWidget(hint)
            page_l.addWidget(inner, 1)
            new_tabs.addTab(page, group_name)

        layout = self.layout()
        if layout is not None:
            idx = layout.indexOf(old_tabs)
            if idx >= 0:
                layout.removeWidget(old_tabs)
                old_tabs.setParent(None)
                layout.insertWidget(idx, new_tabs, 1)
            else:
                layout.addWidget(new_tabs, 1)
        self.tabs = new_tabs
        self._v322_tools_reorganized = True
    except Exception as exc:
        try:
            self.notify('تعذر ترتيب صفحة الأدوات: ' + str(exc))
        except Exception as exc:
            log_exception(exc)


_orig_mainwindow_build_v322 = MainWindow.build

def _v322_mainwindow_build(self):
    _orig_mainwindow_build_v322(self)
    self.v322_theme_button_refine()
    try:
        for lab in self.findChildren(QLabel):
            if lab.objectName() == 'sidebarHint':
                lab.setText('V32.2 - الثيم من أيقونة 🎨 الصغيرة بجانب النسخة الاحتياطية، والأدوات مرتبة بمجموعات.')
    except Exception as exc:
        log_exception(exc)

MainWindow.build = _v322_mainwindow_build
MainWindow.v322_theme_button_refine = _v322_theme_button_refine

_orig_tools_init_v322 = ToolsPage.__init__

def _v322_tools_init(self, service: AppService, notify, current_user=None):
    _orig_tools_init_v322(self, service, notify, current_user)
    self.v322_reorganize_tools_tabs()

ToolsPage.__init__ = _v322_tools_init
ToolsPage.v322_reorganize_tools_tabs = _v322_reorganize_tools_tabs
