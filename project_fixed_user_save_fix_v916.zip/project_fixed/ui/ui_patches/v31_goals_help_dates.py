from __future__ import annotations

from pathlib import Path
import html
import os

from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import *

from database import money
from services.app_service import AppService
from ui.theme_manager import apply_theme as theme_apply, current_theme_key as theme_current_key, set_theme_key as theme_set_key, theme_label as theme_display_label, theme_path as theme_qss_path
from ui.main_window_core import *
import ui.ui_patches.v11_sales_safety as _prev_v11_sales_safety
globals().update({k: v for k, v in vars(_prev_v11_sales_safety).items() if not k.startswith('__')})
import ui.ui_patches.v20_gdrive_ui as _prev_v20_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v20_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v21_backup_ui as _prev_v21_backup_ui
globals().update({k: v for k, v in vars(_prev_v21_backup_ui).items() if not k.startswith('__')})
import ui.ui_patches.v22_gdrive_ui as _prev_v22_gdrive_ui
globals().update({k: v for k, v in vars(_prev_v22_gdrive_ui).items() if not k.startswith('__')})
import ui.ui_patches.v23_tools_reports as _prev_v23_tools_reports
globals().update({k: v for k, v in vars(_prev_v23_tools_reports).items() if not k.startswith('__')})
import ui.ui_patches.v25_lazy_permissions as _prev_v25_lazy_permissions
globals().update({k: v for k, v in vars(_prev_v25_lazy_permissions).items() if not k.startswith('__')})
import ui.ui_patches.v26_tools_refresh as _prev_v26_tools_refresh
globals().update({k: v for k, v in vars(_prev_v26_tools_refresh).items() if not k.startswith('__')})
import ui.ui_patches.v27_pricing_excel_ui as _prev_v27_pricing_excel_ui
globals().update({k: v for k, v in vars(_prev_v27_pricing_excel_ui).items() if not k.startswith('__')})
import ui.ui_patches.v28_professional_ui as _prev_v28_professional_ui
globals().update({k: v for k, v in vars(_prev_v28_professional_ui).items() if not k.startswith('__')})
import ui.ui_patches.v30_layout_cleanup as _prev_v30_layout_cleanup
globals().update({k: v for k, v in vars(_prev_v30_layout_cleanup).items() if not k.startswith('__')})

def _v31_today_text() -> str:
    from datetime import date
    return date.today().isoformat()


def _v31_set_today(widget):
    try:
        if hasattr(widget, 'setText'):
            widget.setText(_v31_today_text())
    except Exception as exc:
        log_exception(exc)


def _v31_goal_duration_label(period: str) -> str:
    return {'يومي': '24 ساعة من وقت الحفظ', 'أسبوعي': '7 أيام من وقت الحفظ', 'شهري': 'شهر كامل من وقت الحفظ', 'ربع سنوي': '3 أشهر من وقت الحفظ', 'سنوي': 'سنة كاملة من وقت الحفظ'}.get(period or '', 'شهر كامل من وقت الحفظ')


_orig_tools_init_v31 = ToolsPage.__init__
def _v31_tools_init(self, service: AppService, notify, current_user=None):
    _orig_tools_init_v31(self, service, notify, current_user)
    today = _v31_today_text()
    # تعبئة كل حقول التاريخ الظاهرة بتاريخ اليوم.
    for name in ('v23_print_date', 'expense_date', 'cashier_date', 'close_date', 'archive_from', 'archive_to', 'v27_promo_start', 'v27_promo_end'):
        if hasattr(self, name):
            _v31_set_today(getattr(self, name))
    # أهداف الموظفين: المستخدم لا يكتب التاريخ؛ النظام يحسب البداية والنهاية تلقائياً.
    if hasattr(self, 'goal_start'):
        self.goal_start.setText('تلقائي: يبدأ من لحظة حفظ الهدف')
        self.goal_start.setReadOnly(True)
        self.goal_start.setToolTip('لا تكتب تاريخاً هنا. اليومي 24 ساعة، الأسبوعي 7 أيام، الشهري شهر كامل، ثم يتوقف تلقائياً.')
    if hasattr(self, 'goal_period'):
        try:
            self.goal_period.currentTextChanged.connect(self.v31_update_goal_auto_hint)
        except Exception as exc:
            log_exception(exc)
    try:
        self.v31_update_goal_auto_hint()
    except Exception as exc:
        log_exception(exc)
    # زر حذف نهائي مستقل بجانب التعطيل.
    if hasattr(self, 'goals_table'):
        try:
            goals_tab = None
            for i in range(self.tabs.count()):
                if self.tabs.tabText(i) == 'أهداف الموظفين':
                    goals_tab = self.tabs.widget(i)
                    break
            if goals_tab is not None and goals_tab.layout() is not None:
                panel = QFrame(); panel.setObjectName('innerCard')
                panel_l = QHBoxLayout(panel); panel_l.setContentsMargins(12, 10, 12, 10); panel_l.setSpacing(10)
                disable_btn = QPushButton('⛔ تعطيل الهدف المحدد')
                disable_btn.setObjectName('warningButton'); disable_btn.clicked.connect(self.delete_goal)
                hard_btn = QPushButton('🗑 حذف الهدف نهائياً')
                hard_btn.setObjectName('dangerButton'); hard_btn.clicked.connect(self.v31_delete_goal_hard)
                info = QLabel('التعطيل يخفي الهدف ويحفظه كسجل. الحذف النهائي يزيله من قاعدة البيانات.')
                info.setObjectName('mutedText'); info.setWordWrap(True)
                panel_l.addWidget(disable_btn); panel_l.addWidget(hard_btn); panel_l.addWidget(info, 1)
                goals_tab.layout().addWidget(panel)
        except Exception as exc:
            log_exception(exc)

ToolsPage.__init__ = _v31_tools_init


def _v31_update_goal_auto_hint(self):
    if not hasattr(self, 'goal_start'):
        return
    period = self.goal_period.currentText() if hasattr(self, 'goal_period') else 'شهري'
    self.goal_start.setText('تلقائي: ' + _v31_goal_duration_label(period))
    self.goal_start.setToolTip('يبدأ الهدف من وقت الضغط على حفظ الهدف، ويتوقف تلقائياً بعد انتهاء الفترة.')


def _v31_set_goal_today(self):
    self.goal_period.setCurrentText('يومي')
    self.v31_update_goal_auto_hint()


def _v31_set_goal_month(self):
    self.goal_period.setCurrentText('شهري')
    self.v31_update_goal_auto_hint()


def _v31_clear_goal_form(self):
    self.goal_target.setValue(0); self.goal_bonus.setValue(0); self.goal_bonus_120.setValue(0); self.goal_bonus_150.setValue(0); self.goal_reward_rate.setValue(0); self.goal_note.clear()
    self.v31_update_goal_auto_hint()


def _v31_save_goal(self):
    try:
        self.service.save_employee_goal(
            self.goal_employee.currentData(), self.goal_period.currentText(), '', self.goal_target.value(), self.goal_bonus.value(),
            self.goal_note.text(), self.goal_type.currentText(), self.goal_scope.currentText(), self.goal_product.currentData(),
            self.goal_reward_type.currentText(), self.goal_reward_rate.value(), self.goal_bonus_120.value(), self.goal_bonus_150.value()
        )
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر الحفظ', str(exc)); return
    self.clear_goal_form(); self.refresh(); self.notify('تم حفظ هدف الموظف بتاريخ ووقت تلقائيين')


def _v31_delete_goal_hard(self):
    goal_id = getattr(self, 'selected_goal_id', None)
    if not goal_id:
        QMessageBox.warning(self, 'اختر هدفاً', 'اختر هدفاً من جدول المتابعة ثم اضغط حذف الهدف نهائياً.'); return
    if QMessageBox.question(self, 'تأكيد الحذف النهائي', 'سيتم حذف الهدف نهائياً من قاعدة البيانات. هل أنت متأكد؟') != QMessageBox.Yes:
        return
    try:
        self.service.delete_employee_goal_hard(goal_id)
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر الحذف', str(exc)); return
    self.selected_goal_id = None; self.refresh(); self.notify('تم حذف الهدف نهائياً')


def _v31_refresh_goals(self):
    # Keep original refresh behavior for other tabs if available.
    try:
        return _orig_tools_refresh_v31(self)
    finally:
        pass

ToolsPage.v31_update_goal_auto_hint = _v31_update_goal_auto_hint
ToolsPage.set_goal_today = _v31_set_goal_today
ToolsPage.set_goal_month = _v31_set_goal_month
ToolsPage.clear_goal_form = _v31_clear_goal_form
ToolsPage.save_goal = _v31_save_goal
ToolsPage.v31_delete_goal_hard = _v31_delete_goal_hard

# Replace the existing active goals table renderer to show automatic end date and remaining time.
_orig_v26_refresh_goals_v31 = globals().get('_v26_refresh_goals')
def _v31_refresh_goals(self):
    try:
        goals = self.service.employee_goal_rows(self.current_user)
        self.goals_table.setColumnCount(10)
        self.goals_table.setHorizontalHeaderLabels(['الموظف','نوع الهدف','الفترة','ينتهي في','الهدف','المحقق','التقدم','المتبقي','المكافأة','الحالة'])
        self.goals_table.setRowCount(len(goals))
        done = 0
        for r, g in enumerate(goals):
            ratio = float(g.get('ratio', 0) or 0)
            if ratio >= 100:
                done += 1
            vals = [
                g.get('employee',''),
                g.get('goal_type','مبيعات'),
                f"{g.get('period_type','')} | بدأ: {str(g.get('period_start',''))[:16]}",
                f"{str(g.get('period_end',''))[:16]} | باقي: {g.get('period_remaining_text','')}",
                format_goal_value(g.get('target_sales',0), g.get('goal_type','')),
                format_goal_value(g.get('achieved',0), g.get('goal_type','')),
                f"{ratio:.1f}%",
                format_goal_value(g.get('remaining',0), g.get('goal_type','')),
                money(g.get('reward_amount',0)),
                g.get('status_text',''),
            ]
            for c, v in enumerate(vals):
                self.goals_table.put(r, c, v, g.get('id') if c == 0 else None)
        if hasattr(self, 'goals_total_card'):
            self.goals_total_card.set_value(str(len(goals)))
        if hasattr(self, 'goals_done_card'):
            self.goals_done_card.set_value(str(done))
    except Exception as exc:
        try:
            QMessageBox.warning(self, 'تعذر تحديث الأهداف', str(exc))
        except Exception as exc:
            log_exception(exc)

# If the V26 refresh function exists, replace it globally and as method hook used by ToolsPage.refresh.
globals()['_v26_refresh_goals'] = _v31_refresh_goals
ToolsPage.v31_refresh_goals = _v31_refresh_goals

# Keep product page clean: remove the extra delete side panel added in V30, and make the built-in product delete button use safe delete.
try:
    _orig_products_no_panel_v31 = _orig_products_init_v30
except Exception:
    _orig_products_no_panel_v31 = ProductsPage.__init__

def _v31_products_init(self, service: AppService, notify, current_user=None):
    _orig_products_no_panel_v31(self, service, notify, current_user)
    try:
        # The original page already has a delete/deactivate button in the product actions card.
        for btn in self.findChildren(QPushButton):
            if 'تعطيل المنتج' in btn.text() or 'حذف المنتج' in btn.text():
                btn.setText('🗑 حذف / تعطيل المنتج')
                btn.setToolTip('يحذف المنتج إذا لم يكن مرتبطاً بحركات، وإلا يتم تعطيله حفاظاً على التقارير.')
                try:
                    btn.clicked.disconnect()
                except Exception as exc:
                    log_exception(exc)
                btn.clicked.connect(self.delete_product)
        # Better table readability.
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
    except Exception as exc:
        log_exception(exc)

ProductsPage.__init__ = _v31_products_init

# Make the sidebar logo more visible by using a larger, two-line Arabic/English brand.
_orig_mainwindow_build_v31 = MainWindow.build
def _v31_mainwindow_build(self):
    _orig_mainwindow_build_v31(self)
    try:
        for lab in self.findChildren(QLabel):
            if lab.objectName() == 'brandMark':
                lab.setText('MAX SALES PRO\nنظام ماكس للمبيعات')
                lab.setMinimumHeight(58)
                lab.setWordWrap(True)
                lab.setAlignment(Qt.AlignCenter)
    except Exception as exc:
        log_exception(exc)
MainWindow.build = _v31_mainwindow_build

# More capable local assistant actions.
def _v31_assistant_help(self):
    self.set_output('''دليل ذكي سريع حسب القسم:\n\n• البيع السريع: امسح الباركود أو ابحث عن المنتج، اختر مستوى السعر، أضف للفاتورة، ثم إتمام البيع.\n• كاشير لمس: استخدمه للشاشات اللمسية؛ الفلاتر أعلى الشاشة، والمنتجات في الشبكة، والفاتورة في الجانب.\n• العروض والأسعار: أنشئ مستويات جملة/VIP، ثم اربط سعرًا خاصًا بكل منتج. العروض تطبق تلقائياً في البيع.\n• المنتجات: احفظ المنتج، عدّل المخزون، اطبع الباركود، أو احذف/عطّل المنتج حسب ارتباطه بالحركات.\n• الزبائن: أضف زبوناً، حدّد حد الدين وأيام الاستحقاق، وسجّل دفعاته.\n• أهداف الموظفين: اختر الفترة فقط؛ النظام يبدأ الهدف الآن ويوقفه تلقائياً بعد 24 ساعة/7 أيام/شهر.\n• النسخ الاحتياطي: من الأدوات أنشئ نسخة محلية أو فعّل النسخ التلقائي.\n\nاكتب في صندوق الملاحظة أو أخبر المدير باسم الزر الذي لا تفهمه، ثم راجع تبويب المساعدة للحصول على شرح تفصيلي لكل زر.''')


def _v31_row_value(row, key, default=''):
    """Safely read a value from dict, sqlite3.Row, or lightweight row-like objects.

    sqlite3.Row supports row['field'] but does not support dict.get().
    The smart risk review used .get() in one fallback path, which caused:
    'sqlite3.Row' object has no attribute 'get'.
    """
    try:
        if row is None:
            return default
        if hasattr(row, 'get'):
            return row.get(key, default)
        return row[key]
    except Exception:
        return default


def _v31_assistant_risk_review(self):
    try:
        alerts = []
        alerts.extend(self.service.ai_anomaly_alerts())
        stock = self.service.ai_stock_forecast()[:8]
        debts = self.service.debt_rows()[:8]
        text = ['مراجعة ذكية مختصرة للمخاطر:']
        text += ['• ' + a for a in alerts[:12]] if alerts else ['• لا توجد مؤشرات تلاعب واضحة حالياً.']
        if stock:
            text.append('\nمنتجات تحتاج متابعة:')
            for r in stock[:6]:
                name = _v31_row_value(r, 'name', 'منتج')
                try:
                    qty = float(_v31_row_value(r, 'quantity', 0) or 0)
                except Exception:
                    qty = 0.0
                risk = _v31_row_value(r, 'risk', '-')
                suggested = _v31_row_value(r, 'suggested', 0)
                text.append(f"• {name} | المتوفر {qty:.0f} | الحالة: {risk} | مقترح شراء: {suggested}")
        if debts:
            text.append('\nديون تحتاج متابعة:')
            for d in debts[:6]:
                raw_balance = _v31_row_value(d, 'balance', 0)
                try:
                    bal = money(raw_balance)
                except Exception:
                    bal = str(raw_balance or '')
                name = _v31_row_value(d, 'name', 'زبون')
                due_date = _v31_row_value(d, 'due_date', '') or '-'
                text.append(f"• {name} | الرصيد: {bal} | الاستحقاق: {due_date}")
        self.set_output('\n'.join(text))
    except Exception as exc:
        log_exception(exc)
        QMessageBox.warning(self, 'تعذر التحليل', 'تعذر إنشاء مراجعة المخاطر الذكية. تم تسجيل التفاصيل في logs/error.log')

_orig_ai_init_v31 = SmartAssistantPage.__init__
def _v31_ai_init(self, service: AppService, notify, current_user=None):
    _orig_ai_init_v31(self, service, notify, current_user)
    try:
        extra = QHBoxLayout()
        b1 = QPushButton('شرح استخدام النظام')
        b1.setObjectName('primaryButton'); b1.clicked.connect(self.v31_help)
        b2 = QPushButton('مراجعة مخاطر ذكية')
        b2.setObjectName('warningButton'); b2.clicked.connect(self.v31_risk_review)
        extra.addWidget(b1); extra.addWidget(b2); extra.addStretch()
        self.layout().insertLayout(2, extra)
    except Exception as exc:
        log_exception(exc)
SmartAssistantPage.__init__ = _v31_ai_init
SmartAssistantPage.v31_help = _v31_assistant_help
SmartAssistantPage.v31_risk_review = _v31_assistant_risk_review

# Detailed help tab: explain every main button and common workflow.
def _v31_build_help_tab(self):
    tab = QWidget(); layout = QVBoxLayout(tab)
    title = QLabel('❔ المساعدة التفصيلية لكل أزرار النظام'); title.setObjectName('miniTitle')
    txt = QTextEdit(); txt.setReadOnly(True)
    txt.setHtml('''<div dir="rtl" style="font-family:Tahoma; font-size:14px; line-height:1.8">
    <h2>دليل ماكس للمبيعات - شرح تفصيلي للأزرار</h2>
    <h3>أزرار الشريط الجانبي</h3>
    <ul>
      <li><b>الرئيسية:</b> تعرض ملخص المبيعات، المخزون، الأهداف والتنبيهات.</li>
      <li><b>البيع السريع:</b> شاشة البيع اليومية بالباركود والبحث ومستويات الأسعار والعروض.</li>
      <li><b>كاشير لمس:</b> شاشة مبسطة للشاشات اللمسية؛ اضغط المنتج لإضافته للفاتورة.</li>
      <li><b>المنتجات والمخزون:</b> إضافة/تعديل/حذف أو تعطيل المنتجات، تعديل المخزون، وطباعة الباركود.</li>
      <li><b>الزبائن والديون:</b> إضافة زبون، تسجيل دفعة، طباعة كشف حساب، وحذف/تعطيل زبون.</li>
      <li><b>الموردون والمشتريات:</b> إدارة الموردين وفواتير الشراء وديون الموردين.</li>
      <li><b>المرتجعات:</b> إرجاع مادة من فاتورة مع سبب وحساب أثرها على المخزون والعمولة.</li>
      <li><b>التقارير:</b> فواتير، أرباح، مبيعات، أرشفة وفلاتر، وتقارير PDF.</li>
      <li><b>المستخدمون:</b> إنشاء مستخدم، صلاحياته، تعطيله أو حذفه إذا لم يكن مرتبطاً بسجلات.</li>
      <li><b>المساعد الذكي:</b> تحليل محلي للمبيعات والمخزون والأرباح والمخاطر بدون إنترنت.</li>
      <li><b>الأدوات:</b> النسخ الاحتياطي، الإعدادات، العروض والأسعار، الأهداف، الطباعة، المصاريف، والمساعدة.</li>
    </ul>
    <h3>البيع السريع</h3>
    <ul>
      <li><b>مسح باركود:</b> ضع المؤشر في خانة الباركود وامسح المنتج؛ يضاف تلقائياً أو يظهر للبحث.</li>
      <li><b>بحث:</b> اكتب جزءًا من الاسم أو الباركود أو الصنف لتصفية المنتجات.</li>
      <li><b>إضافة المنتج:</b> ضغط مزدوج على المنتج أو زر الإضافة يضيفه للفاتورة.</li>
      <li><b>مستوى السعر:</b> اختر مفرد/جملة/VIP؛ النظام يحسب السعر الصحيح تلقائياً.</li>
      <li><b>الخصم:</b> الخصم اليدوي يخضع لصلاحية وحد أقصى. العروض تطبق تلقائياً.</li>
      <li><b>تعليق الفاتورة:</b> يحفظ الفاتورة مؤقتاً للعودة لها لاحقاً.</li>
      <li><b>إتمام البيع:</b> يحفظ الفاتورة، يخصم المخزون، يحسب الربح والعمولة، ويطبع عند الطلب.</li>
    </ul>
    <h3>كاشير لمس</h3>
    <ul>
      <li><b>الفلاتر:</b> استخدم الصنف أو البحث لتقليل شبكة المنتجات.</li>
      <li><b>شبكة المنتجات:</b> اضغط على بطاقة المنتج لإضافته مباشرة.</li>
      <li><b>خيارات الفاتورة:</b> الزبون، طريقة الدفع، مستوى السعر، والخصم مرتبة في جهة واحدة.</li>
    </ul>
    <h3>العروض والأسعار</h3>
    <ul>
      <li><b>حفظ مستوى سعر:</b> أنشئ مستوى مثل جملة أو VIP.</li>
      <li><b>حفظ سعر منتج:</b> اختر المنتج والمستوى واكتب السعر والحد الأدنى للكمية.</li>
      <li><b>حفظ العرض:</b> اختر نطاق العرض: كل المنتجات، صنف، أو منتج محدد؛ ثم نوع الخصم والقيمة.</li>
      <li><b>تعطيل العرض:</b> يوقف العرض دون حذف سجله.</li>
      <li><b>Excel:</b> تصدير المنتجات، استيرادها، أو إنشاء قالب جاهز.</li>
    </ul>
    <h3>أهداف الموظفين</h3>
    <ul>
      <li><b>الفترة:</b> اختر يومي/أسبوعي/شهري فقط؛ لا تكتب تاريخاً.</li>
      <li><b>حفظ الهدف:</b> يبدأ الهدف من لحظة الحفظ. اليومي يتوقف بعد 24 ساعة، الأسبوعي بعد 7 أيام، الشهري بعد شهر.</li>
      <li><b>تعطيل الهدف:</b> يخفي الهدف من المتابعة ويتركه كسجل سابق.</li>
      <li><b>حذف الهدف نهائياً:</b> يزيل الهدف من قاعدة البيانات بعد التأكيد.</li>
    </ul>
    <h3>المنتجات</h3>
    <ul>
      <li><b>حفظ المنتج:</b> يضيف منتجاً جديداً أو يحدث المنتج المحدد.</li>
      <li><b>منتج جديد:</b> يفرغ الحقول لإدخال مادة جديدة.</li>
      <li><b>توليد باركود:</b> ينشئ باركود داخلي للمنتج المحدد.</li>
      <li><b>طباعة ملصقات:</b> ينشئ ملف ملصقات باركود للطباعة.</li>
      <li><b>حذف/تعطيل المنتج:</b> إذا كان المنتج بلا حركات يُحذف، وإلا يُعطل حفاظاً على التقارير.</li>
      <li><b>تعديل كمية المخزون:</b> استخدمه للجرد مع كتابة سبب واضح.</li>
    </ul>
    <h3>الزبائن</h3>
    <ul>
      <li><b>حفظ الزبون:</b> يحفظ الاسم والهاتف والعنوان وحد الدين وأيام الاستحقاق.</li>
      <li><b>تسجيل دفعة:</b> يسجل مبلغاً مدفوعاً من الزبون ويقلل الرصيد.</li>
      <li><b>كشف حساب:</b> يطبع أو يصدر حركة الزبون ورصيده.</li>
      <li><b>حذف الزبون:</b> يحذف الزبون إذا لم يرتبط بفواتير، وإلا يعطله فقط.</li>
    </ul>
    <h3>النسخ الاحتياطي والإعدادات</h3>
    <ul>
      <li><b>نسخة احتياطية:</b> أنشئ نسخة من قاعدة البيانات فوراً.</li>
      <li><b>استرجاع نسخة:</b> يستبدل قاعدة البيانات الحالية بعد التأكيد.</li>
      <li><b>إعدادات الشركة:</b> اسم المحل والهاتف والعنوان والعملة وبيانات الفاتورة.</li>
      <li><b>إعدادات متقدمة:</b> عدد النسخ المحفوظة، النسخ عند الفتح/الإغلاق، وحدود الخصم.</li>
    </ul>
    <h3>التواريخ</h3>
    <p>حقول التاريخ في الأدوات والتقارير تُملأ تلقائياً بتاريخ اليوم. يمكنك تعديلها يدوياً للتقارير فقط إذا أردت فترة مختلفة.</p>
    </div>''')
    layout.addWidget(title); layout.addWidget(txt, 1); self.tabs.addTab(tab, 'المساعدة التفصيلية')

# Replace the previous help tab builder for newly opened Tools pages.
globals()['_v23_build_help_tab'] = _v31_build_help_tab

# Ensure the V31 goals table rendering runs after the resilient V26 tools refresh.
_orig_tools_refresh_v31_final = ToolsPage.refresh

def _v31_tools_refresh_final(self):
    try:
        _orig_tools_refresh_v31_final(self)
    finally:
        if hasattr(self, 'goals_table'):
            try:
                self.v31_refresh_goals()
            except Exception as exc:
                log_exception(exc)
        for name in ('v23_print_date', 'expense_date', 'cashier_date', 'close_date', 'archive_from', 'archive_to'):
            if hasattr(self, name):
                try:
                    w = getattr(self, name)
                    if hasattr(w, 'text') and not w.text().strip():
                        _v31_set_today(w)
                except Exception as exc:
                    log_exception(exc)

ToolsPage.refresh = _v31_tools_refresh_final

# Reports page date fields should also default to today when the report page is opened.
_orig_reports_init_v31 = ReportsPage.__init__
def _v31_reports_init(self, service: AppService, notify=None):
    _orig_reports_init_v31(self, service, notify)
    for name in ('archive_from', 'archive_to'):
        if hasattr(self, name):
            _v31_set_today(getattr(self, name))
ReportsPage.__init__ = _v31_reports_init

# ---------------------------------------------------------------------------
# V32 Multi-theme system: keep Widgets UI, add selectable professional skins.
# ---------------------------------------------------------------------------
from PySide6.QtWidgets import QMenu

_V32_THEMES = {
    'modern_blue': ('ماكس أزرق احترافي', 'style_modern_blue.qss'),
    'dark_pos': ('ماكس ليلي للكاشير', 'style_dark_pos.qss'),
    'luxury_gold': ('ماكس ذهبي فاخر', 'style_luxury_gold.qss'),
    'green_retail': ('ماكس أخضر تجاري', 'style_green_retail.qss'),
    'soft_minimal': ('ماكس بسيط وهادئ', 'style_soft_minimal.qss'),
}
_V32_ALIASES = {'light': 'modern_blue', 'dark': 'dark_pos'}


