from __future__ import annotations

from ui.ui_common import *
from ui.pages.tools_page import ToolsPage


_orig_tools_init_v45 = ToolsPage.__init__


def _v45_tools_init(self: ToolsPage, service: AppService, notify, current_user=None):
    _orig_tools_init_v45(self, service, notify, current_user)
    try:
        self.build_v45_smart_control_tab()
    except Exception as exc:
        log_exception(exc)


ToolsPage.__init__ = _v45_tools_init


def _v45_build_smart_control_tab(self: ToolsPage):
    tab = QWidget()
    layout = QVBoxLayout(tab)
    layout.setContentsMargins(8, 8, 8, 8)
    title = QLabel('🧠 الأرشفة والحماية والتوقعات الذكية')
    title.setObjectName('sectionTitle')
    note = QLabel('هذه الصفحة تجمع أول نسخة عملية من: الأرشفة الإلكترونية، كشف التلاعب، توقع المبيعات، وملخص المالك.')
    note.setObjectName('noticeBox')
    note.setWordWrap(True)

    cards = QGridLayout()
    self.v45_today_sales = MetricCard('مبيعات اليوم', '0')
    self.v45_month_sales = MetricCard('مبيعات الشهر', '0')
    self.v45_security_open = MetricCard('تنبيهات حماية مفتوحة', '0')
    self.v45_low_stock = MetricCard('منتجات منخفضة المخزون', '0')
    cards.addWidget(self.v45_today_sales, 0, 0)
    cards.addWidget(self.v45_month_sales, 0, 1)
    cards.addWidget(self.v45_security_open, 0, 2)
    cards.addWidget(self.v45_low_stock, 0, 3)

    inner = QTabWidget()

    # Archive tab
    archive = QWidget(); a_l = QVBoxLayout(archive)
    search_row = QHBoxLayout()
    self.v45_archive_query = QLineEdit(); self.v45_archive_query.setPlaceholderText('بحث: رقم فاتورة، هاتف، اسم زبون، مبلغ، جزء من الاسم...')
    self.v45_archive_type = QComboBox(); self.v45_archive_type.addItems(['', 'فاتورة بيع', 'فاتورة مورد', 'ملف زبون', 'مستند'])
    self.v45_archive_from = QLineEdit(); self.v45_archive_from.setPlaceholderText('من تاريخ YYYY-MM-DD')
    self.v45_archive_to = QLineEdit(); self.v45_archive_to.setPlaceholderText('إلى تاريخ YYYY-MM-DD')
    btn_search = QPushButton('بحث في الأرشيف'); btn_search.setObjectName('primaryButton'); btn_search.clicked.connect(self.v45_refresh_archive)
    btn_open = QPushButton('عرض نص المستند'); btn_open.clicked.connect(self.v45_open_archive_document)
    search_row.addWidget(btn_open); search_row.addWidget(btn_search); search_row.addWidget(self.v45_archive_to); search_row.addWidget(self.v45_archive_from); search_row.addWidget(self.v45_archive_type); search_row.addWidget(self.v45_archive_query, 1)
    self.v45_archive_table = Table(['النوع', 'الرقم', 'العنوان', 'الزبون/المورد', 'الهاتف', 'المبلغ', 'التاريخ'])
    a_l.addLayout(search_row); a_l.addWidget(self.v45_archive_table, 1)
    inner.addTab(archive, '📂 الأرشيف الذكي')

    # Security tab
    security = QWidget(); s_l = QVBoxLayout(security)
    sec_row = QHBoxLayout()
    btn_sec_refresh = QPushButton('تحديث التنبيهات'); btn_sec_refresh.setObjectName('primaryButton'); btn_sec_refresh.clicked.connect(self.v45_refresh_security)
    btn_sec_resolve = QPushButton('إغلاق التنبيه المحدد'); btn_sec_resolve.setObjectName('warningButton'); btn_sec_resolve.clicked.connect(self.v45_resolve_selected_alert)
    sec_row.addWidget(btn_sec_resolve); sec_row.addWidget(btn_sec_refresh); sec_row.addStretch(1)
    self.v45_security_table = Table(['الوقت', 'الخطورة', 'النوع', 'المستخدم', 'المرجع', 'الحالة', 'التفاصيل'])
    s_l.addLayout(sec_row); s_l.addWidget(self.v45_security_table, 1)
    inner.addTab(security, '🕵️ الحماية')

    # Forecast tab
    forecast = QWidget(); f_l = QVBoxLayout(forecast)
    f_row = QHBoxLayout()
    self.v45_forecast_days_back = QSpinBox(); self.v45_forecast_days_back.setRange(7, 730); self.v45_forecast_days_back.setValue(90)
    self.v45_forecast_days_forward = QSpinBox(); self.v45_forecast_days_forward.setRange(7, 365); self.v45_forecast_days_forward.setValue(30)
    btn_forecast = QPushButton('حساب التوقعات'); btn_forecast.setObjectName('primaryButton'); btn_forecast.clicked.connect(self.v45_refresh_forecast)
    f_row.addWidget(btn_forecast); f_row.addWidget(QLabel('توقع للأيام القادمة')); f_row.addWidget(self.v45_forecast_days_forward); f_row.addWidget(QLabel('تحليل آخر أيام')); f_row.addWidget(self.v45_forecast_days_back); f_row.addStretch(1)
    self.v45_forecast_table = Table(['المنتج', 'المخزون الحالي', 'مباع بالفترة', 'متوسط يومي', 'متوقع', 'كمية مقترحة', 'الحالة'])
    f_l.addLayout(f_row); f_l.addWidget(self.v45_forecast_table, 1)
    inner.addTab(forecast, '🧠 توقع المبيعات')

    layout.addWidget(title); layout.addWidget(note); layout.addLayout(cards); layout.addWidget(inner, 1)
    self.tabs.addTab(tab, '🧠 مركز ذكي')


ToolsPage.build_v45_smart_control_tab = _v45_build_smart_control_tab


def _v45_refresh_owner_cards(self: ToolsPage):
    if not hasattr(self, 'v45_today_sales'):
        return
    try:
        data = self.service.owner_dashboard_snapshot()
        today = data.get('today', {})
        month = data.get('month', {})
        self.v45_today_sales.set_value(money(today.get('sales', 0)))
        self.v45_month_sales.set_value(money(month.get('sales', 0)))
        self.v45_security_open.set_value(str(data.get('open_security_alerts', 0)))
        self.v45_low_stock.set_value(str(data.get('low_stock_products', 0)))
    except Exception as exc:
        log_exception(exc)




ToolsPage.v45_refresh_owner_cards = _v45_refresh_owner_cards

def _v45_refresh_archive(self: ToolsPage):
    if not hasattr(self, 'v45_archive_table'):
        return
    try:
        rows = self.service.search_archive(
            self.v45_archive_query.text(),
            self.v45_archive_type.currentText().strip(),
            self.v45_archive_from.text().strip(),
            self.v45_archive_to.text().strip(),
        )
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر البحث', str(exc)); return
    self.v45_archive_table.setRowCount(len(rows))
    for r, row in enumerate(rows):
        party = row['customer_name'] or row['supplier_name'] or ''
        vals = [row['doc_type'], row['ref_no'], row['title'], party, row['customer_phone'] or '', money(row['amount']), row['doc_date']]
        for c, v in enumerate(vals):
            self.v45_archive_table.put(r, c, v, row['id'] if c == 0 else None)


ToolsPage.v45_refresh_archive = _v45_refresh_archive


def _v45_open_archive_document(self: ToolsPage):
    row = self.v45_archive_table.currentRow() if hasattr(self, 'v45_archive_table') else -1
    item = self.v45_archive_table.item(row, 0) if row >= 0 else None
    archive_id = item.data(Qt.UserRole) if item else None
    if not archive_id:
        QMessageBox.information(self, 'اختر مستنداً', 'اختر مستنداً من جدول الأرشيف أولاً.')
        return
    try:
        doc = self.service.get_archived_document(archive_id)
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر الفتح', str(exc)); return
    dlg = QDialog(self); dlg.setWindowTitle(str(doc['title'])); dlg.setMinimumSize(720, 520)
    l = QVBoxLayout(dlg)
    text = QTextEdit(); text.setReadOnly(True); text.setPlainText(doc['content_text'] or doc['content_json'] or '')
    close = QPushButton('إغلاق'); close.setObjectName('primaryButton'); close.clicked.connect(dlg.accept)
    l.addWidget(text, 1); l.addWidget(close)
    dlg.exec()


ToolsPage.v45_open_archive_document = _v45_open_archive_document


def _v45_refresh_security(self: ToolsPage):
    if not hasattr(self, 'v45_security_table'):
        return
    try:
        rows = self.service.security_alert_rows()
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر تحميل التنبيهات', str(exc)); return
    self.v45_security_table.setRowCount(len(rows))
    for r, row in enumerate(rows):
        ref = ' / '.join(x for x in [row['ref_type'] or '', row['ref_no'] or ''] if x)
        vals = [row['created_at'], row['severity'], row['alert_type'], row['username'] or '', ref, row['status'], row['details'] or '']
        for c, v in enumerate(vals):
            self.v45_security_table.put(r, c, v, row['id'] if c == 0 else None)


ToolsPage.v45_refresh_security = _v45_refresh_security


def _v45_resolve_selected_alert(self: ToolsPage):
    row = self.v45_security_table.currentRow() if hasattr(self, 'v45_security_table') else -1
    item = self.v45_security_table.item(row, 0) if row >= 0 else None
    alert_id = item.data(Qt.UserRole) if item else None
    if not alert_id:
        QMessageBox.information(self, 'اختر تنبيهاً', 'اختر تنبيهاً من جدول الحماية أولاً.')
        return
    try:
        self.service.resolve_security_alert(alert_id, self.current_user.get('id') if self.current_user else None)
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر الإغلاق', str(exc)); return
    self.v45_refresh_security(); self.v45_refresh_owner_cards(); self.notify('تم إغلاق التنبيه')


ToolsPage.v45_resolve_selected_alert = _v45_resolve_selected_alert


def _v45_refresh_forecast(self: ToolsPage):
    if not hasattr(self, 'v45_forecast_table'):
        return
    try:
        rows = self.service.sales_forecast(self.v45_forecast_days_back.value(), self.v45_forecast_days_forward.value())
    except Exception as exc:
        QMessageBox.warning(self, 'تعذر حساب التوقعات', str(exc)); return
    self.v45_forecast_table.setRowCount(len(rows))
    for r, row in enumerate(rows):
        vals = [
            row['name'], row['current_qty'], f"{float(row['sold_qty'] or 0):,.0f}", f"{row['avg_daily']:.2f}",
            f"{row['expected_qty']:.0f}", f"{row['recommended_purchase_qty']:.0f}", row['status_text']
        ]
        for c, v in enumerate(vals):
            self.v45_forecast_table.put(r, c, v)


ToolsPage.v45_refresh_forecast = _v45_refresh_forecast


_orig_tools_refresh_v45 = ToolsPage.refresh


def _v45_tools_refresh(self: ToolsPage):
    _orig_tools_refresh_v45(self)
    if hasattr(self, 'v45_archive_table'):
        getattr(self, 'v45_refresh_owner_cards', lambda: None)()
        self.v45_refresh_archive()
        self.v45_refresh_security()
        self.v45_refresh_forecast()


ToolsPage.refresh = _v45_tools_refresh
