from ui.ui_common import *

from services.cloud_sync import get_cloud_sync_client
from ui.pages.tools_page import ToolsPage


_old_tools_init_v37 = ToolsPage.__init__


def _tools_init_v37(self, service, notify, current_user=None):
    _old_tools_init_v37(self, service, notify, current_user)
    try:
        self.build_cloud_sync_tab()
    except Exception as exc:
        log_exception(exc, 'build cloud sync tab')


def _client(self):
    return get_cloud_sync_client(self.service.db.path)


def _build_cloud_sync_tab(self):
    tab = QWidget()
    layout = QVBoxLayout(tab)
    layout.setContentsMargins(20, 20, 20, 20)
    layout.setSpacing(14)

    title = QLabel('☁️ المزامنة السحابية - لوحة أونلاين')
    title.setObjectName('sectionTitle')
    layout.addWidget(title)

    note = QLabel('هذه الخاصية ترسل ملخصات قراءة فقط إلى سيرفر أونلاين. لا تحتاج فتح جهاز المحل أو الراوتر للإنترنت. لا يتم إرسال كلمات مرور المستخدمين ولا قاعدة البيانات كاملة.')
    note.setObjectName('noticeBox')
    note.setWordWrap(True)
    layout.addWidget(note)

    form_box = QFrame(); form_box.setObjectName('surface')
    form = QFormLayout(form_box)
    form.setContentsMargins(18, 18, 18, 18)
    form.setSpacing(12)

    self.cloud_enabled = QCheckBox('تفعيل المزامنة التلقائية')
    self.cloud_url = QLineEdit(); self.cloud_url.setPlaceholderText('https://your-server.com/api/sync')
    self.cloud_store_id = QLineEdit(); self.cloud_store_id.setPlaceholderText('store-001')
    self.cloud_store_name = QLineEdit(); self.cloud_store_name.setPlaceholderText('اسم المحل')
    self.cloud_api_key = QLineEdit(); self.cloud_api_key.setEchoMode(QLineEdit.Password)
    self.cloud_show_key = QCheckBox('إظهار مفتاح الربط')
    self.cloud_show_key.toggled.connect(lambda checked: self.cloud_api_key.setEchoMode(QLineEdit.Normal if checked else QLineEdit.Password))
    self.cloud_interval = QSpinBox(); self.cloud_interval.setRange(1, 1440); self.cloud_interval.setValue(5)

    form.addRow('التفعيل', self.cloud_enabled)
    form.addRow('رابط استقبال السيرفر', self.cloud_url)
    form.addRow('معرف المحل', self.cloud_store_id)
    form.addRow('اسم المحل', self.cloud_store_name)
    form.addRow('مفتاح الربط API Key', self.cloud_api_key)
    form.addRow('', self.cloud_show_key)
    form.addRow('كل كم دقيقة', self.cloud_interval)
    layout.addWidget(form_box)

    self.cloud_status = QLabel('الحالة: غير مفعلة')
    self.cloud_status.setObjectName('noticeBox')
    self.cloud_status.setWordWrap(True)
    layout.addWidget(self.cloud_status)

    buttons = QHBoxLayout()
    self.cloud_save_btn = QPushButton('حفظ الإعدادات')
    self.cloud_send_btn = QPushButton('إرسال الآن')
    self.cloud_start_btn = QPushButton('تشغيل تلقائي')
    self.cloud_stop_btn = QPushButton('إيقاف تلقائي')
    self.cloud_reset_key_btn = QPushButton('توليد مفتاح جديد')
    self.cloud_send_btn.setObjectName('primaryButton')
    for b in (self.cloud_save_btn, self.cloud_send_btn, self.cloud_start_btn, self.cloud_stop_btn, self.cloud_reset_key_btn):
        b.setMinimumHeight(38)
        buttons.addWidget(b)
    layout.addLayout(buttons)

    server_help = QLabel('ملفات السيرفر موجودة داخل مجلد cloud_dashboard_server. ارفع هذا المجلد على VPS/استضافة Python، ثم ضع رابط /api/sync ومفتاح API هنا.')
    server_help.setWordWrap(True)
    server_help.setObjectName('mutedLabel')
    layout.addWidget(server_help)
    layout.addStretch(1)

    self.cloud_save_btn.clicked.connect(self.cloud_sync_save)
    self.cloud_send_btn.clicked.connect(self.cloud_sync_send_now)
    self.cloud_start_btn.clicked.connect(self.cloud_sync_start)
    self.cloud_stop_btn.clicked.connect(self.cloud_sync_stop)
    self.cloud_reset_key_btn.clicked.connect(self.cloud_sync_reset_key)

    self.tabs.addTab(tab, 'مزامنة سحابية')
    self.cloud_sync_load()


def _cloud_sync_load(self):
    cfg = _client(self).config
    self.cloud_enabled.setChecked(bool(cfg.get('enabled')))
    self.cloud_url.setText(str(cfg.get('server_url') or ''))
    self.cloud_store_id.setText(str(cfg.get('store_id') or ''))
    self.cloud_store_name.setText(str(cfg.get('store_name') or ''))
    self.cloud_api_key.setText(str(cfg.get('api_key') or ''))
    self.cloud_interval.setValue(int(cfg.get('interval_minutes') or 5))
    self.cloud_sync_update_status()


def _cloud_sync_save(self):
    try:
        _client(self).save_config(
            enabled=self.cloud_enabled.isChecked(),
            server_url=self.cloud_url.text().strip(),
            store_id=self.cloud_store_id.text().strip(),
            store_name=self.cloud_store_name.text().strip(),
            api_key=self.cloud_api_key.text().strip(),
            interval_minutes=self.cloud_interval.value(),
        )
        self.notify('تم حفظ إعدادات المزامنة السحابية')
        self.cloud_sync_update_status()
    except Exception as exc:
        log_exception(exc, 'save cloud sync settings')
        QMessageBox.warning(self, 'تعذر الحفظ', str(exc))


def _cloud_sync_update_status(self):
    client = _client(self)
    cfg = client.config
    running = 'تعمل تلقائياً' if client.is_running() else 'متوقفة'
    self.cloud_status.setText(
        f'الحالة: {running}\n'
        f'آخر مزامنة: {cfg.get("last_sync_at") or "-"}\n'
        f'آخر نتيجة: {cfg.get("last_sync_status") or "-"}\n'
        f'السيرفر: {cfg.get("server_url") or "-"}'
    )


def _cloud_sync_send_now(self):
    try:
        self.cloud_sync_save()
        result = _client(self).sync_once()
        self.cloud_sync_update_status()
        if result.get('ok'):
            QMessageBox.information(self, 'تم الإرسال', result.get('message', 'تمت المزامنة'))
        else:
            QMessageBox.warning(self, 'تعذر الإرسال', result.get('message', 'فشلت المزامنة'))
    except Exception as exc:
        log_exception(exc, 'cloud sync send now')
        QMessageBox.warning(self, 'تعذر الإرسال', str(exc))


def _cloud_sync_start(self):
    try:
        self.cloud_sync_save()
        _client(self).start()
        self.cloud_sync_update_status()
        self.notify('تم تشغيل المزامنة السحابية التلقائية')
    except Exception as exc:
        log_exception(exc, 'cloud sync start')
        QMessageBox.warning(self, 'تعذر التشغيل', str(exc))


def _cloud_sync_stop(self):
    try:
        _client(self).stop()
        self.cloud_enabled.setChecked(False)
        self.cloud_sync_update_status()
        self.notify('تم إيقاف المزامنة السحابية')
    except Exception as exc:
        log_exception(exc, 'cloud sync stop')
        QMessageBox.warning(self, 'تعذر الإيقاف', str(exc))


def _cloud_sync_reset_key(self):
    try:
        key = _client(self).reset_api_key()
        self.cloud_api_key.setText(key)
        self.cloud_sync_update_status()
        QMessageBox.information(self, 'مفتاح جديد', f'تم توليد مفتاح ربط جديد:\n{key}\n\nضع نفس المفتاح في إعدادات السيرفر.')
    except Exception as exc:
        log_exception(exc, 'cloud sync reset api key')
        QMessageBox.warning(self, 'تعذر التوليد', str(exc))


ToolsPage.__init__ = _tools_init_v37
ToolsPage.build_cloud_sync_tab = _build_cloud_sync_tab
ToolsPage.cloud_sync_load = _cloud_sync_load
ToolsPage.cloud_sync_save = _cloud_sync_save
ToolsPage.cloud_sync_update_status = _cloud_sync_update_status
ToolsPage.cloud_sync_send_now = _cloud_sync_send_now
ToolsPage.cloud_sync_start = _cloud_sync_start
ToolsPage.cloud_sync_stop = _cloud_sync_stop
ToolsPage.cloud_sync_reset_key = _cloud_sync_reset_key
