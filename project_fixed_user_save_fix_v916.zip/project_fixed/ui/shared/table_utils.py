from __future__ import annotations

from typing import Any


def clear_and_fill_table(table, headers: list[str], rows: list[list[Any]]) -> None:
    """Small shared Qt table helper.

    It is intentionally dependency-light: importing this file does not import
    PySide6 until the function is used by a page.
    """
    try:
        from PySide6.QtWidgets import QTableWidgetItem
    except Exception:  # pragma: no cover - UI dependency may be absent in tests
        return
    table.clear()
    table.setColumnCount(len(headers))
    table.setHorizontalHeaderLabels(headers)
    table.setRowCount(len(rows or []))
    for r, row in enumerate(rows or []):
        for c, value in enumerate(row):
            table.setItem(r, c, QTableWidgetItem(str(value if value is not None else '')))
    try:
        table.resizeColumnsToContents()
    except Exception:
        pass
