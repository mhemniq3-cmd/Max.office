from __future__ import annotations


def show_message(parent, title: str, message: str, kind: str = 'info') -> None:
    try:
        from PySide6.QtWidgets import QMessageBox
        box = QMessageBox(parent)
        box.setWindowTitle(title)
        box.setText(message)
        if kind == 'error':
            box.setIcon(QMessageBox.Critical)
        elif kind == 'warning':
            box.setIcon(QMessageBox.Warning)
        else:
            box.setIcon(QMessageBox.Information)
        box.exec()
    except Exception:
        print(f'{title}: {message}')
