from ui.ui_common import *
from ui.dialogs.auth import LoginDialog, ChangePasswordDialog
from ui.dialogs.access_denied import AccessDeniedDialog
from ui.pages.dashboard_page import DashboardPage
from ui.pages.sales_page import SalesPage
from ui.pages.touch_pos_page import TouchPOSPage
from ui.pages.products_page import ProductsPage
from ui.pages.customers_page import CustomersPage
from ui.pages.suppliers_page import SuppliersPage
from ui.pages.returns_page import ReturnsPage
from ui.pages.reports_page import ReportsPage
from ui.pages.users_page import UsersPage
from ui.pages.smart_assistant_page import SmartAssistantPage
from ui.pages.tools_page import ToolsPage

class MainWindow(QMainWindow):
    def __init__(self, service: AppService, current_user=None):
        super().__init__()
        self.service = service; self.current_user = current_user
        try:
            self.service.set_current_user(current_user)
        except Exception as exc:
            log_exception(exc)
        self.setWindowTitle('ماكس سيلز - نظام المبيعات الحديث')
        self.setMinimumSize(1180, 720); self.resize(1480, 860)
        self.pages: dict[str, QWidget] = {}; self.buttons: dict[str, QPushButton] = {}
        self.build(); self.show_first_allowed_page()
        self.timer = QTimer(self); self.timer.timeout.connect(self.update_clock); self.timer.start(1000); self.update_clock()
        self.alert_timer = QTimer(self); self.alert_timer.timeout.connect(self.update_alert_button); self.alert_timer.start(1200); self.alert_flash = False; self.update_alert_button()
        QTimer.singleShot(1500, self.run_auto_backup_check)

    def user_can(self, key: str) -> bool:
        if not self.current_user: return True
        perm = PAGE_PERMISSION.get(key)
        return bool(self.current_user[perm]) if perm else True

    def build(self):
        root = QWidget(); self.setCentralWidget(root)
        main = QHBoxLayout(root); main.setContentsMargins(0, 0, 0, 0); main.setSpacing(0)
        sidebar = QFrame(); sidebar.setObjectName('sidebar'); sidebar.setFixedWidth(240)
        s_l = QVBoxLayout(sidebar); s_l.setContentsMargins(16, 18, 16, 18); s_l.setSpacing(8)
        brand = QLabel('ماكس سيلز\nنظام المبيعات الحديث')
        brand.setObjectName('brand'); brand.setAlignment(Qt.AlignCenter); s_l.addWidget(brand)
        user_name = (self.current_user['full_name'] or self.current_user['username']) if self.current_user else 'بدون مستخدم'
        user_role = self.current_user['role'] if self.current_user and 'role' in self.current_user.keys() else 'بدون دور'
        user_label = QLabel(f'👤 {user_name}\n🛡 {user_role}')
        user_label.setObjectName('userBadge'); user_label.setAlignment(Qt.AlignCenter); s_l.addWidget(user_label)
        hint_label = QLabel('كل الأزرار ظاهرة؛ المقفل منها يحتاج صلاحية مدير')
        hint_label.setObjectName('sidebarHint'); hint_label.setAlignment(Qt.AlignCenter); s_l.addWidget(hint_label)
        nav_items = [
            ('dashboard', '🏠 الرئيسية'),
            ('sales', '💳 المبيعات'),
            ('touch_pos', '🖥 كاشير لمس'),
            ('products', '📦 المخزون والمنتجات'),
            ('customers', '👤 العملاء والديون'),
            ('suppliers', '🚚 الموردون'),
            ('returns', '↩ المرتجعات'),
            ('reports', '📊 التقارير'),
            ('users', '🔐 المستخدمون'),
            ('ai', '🤖 المساعد الذكي'),
            ('tools', '⚙️ الإعدادات والأدوات'),
        ]
        for key, text in nav_items:
            btn = QPushButton(text); btn.setObjectName('navButton'); btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda checked=False, k=key: self.show_page(k))
            allowed = self.user_can(key)
            btn.setProperty('locked', not allowed)
            btn.setToolTip('خاص بالمدير فقط' if not allowed else 'فتح الصفحة')
            if not allowed and '🔒' not in text:
                btn.setText(f'🔒 {text}')
            self.buttons[key] = btn
            s_l.addWidget(btn)
        s_l.addStretch()
        logout_btn = QPushButton('🚪 تسجيل الخروج')
        logout_btn.setObjectName('dangerButton')
        logout_btn.setCursor(Qt.PointingHandCursor)
        logout_btn.clicked.connect(self.logout)
        s_l.addWidget(logout_btn)

        body = QFrame(); body.setObjectName('body')
        b_l = QVBoxLayout(body); b_l.setContentsMargins(16, 14, 16, 8); b_l.setSpacing(12)
        top = QFrame(); top.setObjectName('topbar')
        t_l = QHBoxLayout(top)
        self.title = QLabel(''); self.title.setObjectName('topTitle')
        self.clock = QLabel(''); self.clock.setObjectName('clock')
        top_user_name = (self.current_user['full_name'] or self.current_user['username']) if self.current_user else 'بدون مستخدم'
        self.top_user = QLabel(f'👤 {top_user_name}')
        self.top_user.setObjectName('topUserLabel')
        refresh = QPushButton('⟳ تحديث'); refresh.setObjectName('primaryButton'); refresh.setCursor(Qt.PointingHandCursor); refresh.clicked.connect(self.refresh_current)
        self.alert_btn = QPushButton('🔔 الإشعارات'); self.alert_btn.setObjectName('alertButton'); self.alert_btn.setCursor(Qt.PointingHandCursor); self.alert_btn.clicked.connect(self.show_alerts_dialog)
        t_l.addWidget(self.clock); t_l.addWidget(self.top_user); t_l.addWidget(refresh); t_l.addWidget(self.alert_btn); t_l.addStretch(); t_l.addWidget(self.title)
        self.stack = QStackedWidget(); self.status = QLabel('جاهز'); self.status.setObjectName('status')
        b_l.addWidget(top); b_l.addWidget(self.stack, 1); b_l.addWidget(self.status)
        self.pages['dashboard'] = DashboardPage(self.service, self.current_user)
        self.pages['sales'] = SalesPage(self.service, self.notify, self.current_user)
        self.pages['touch_pos'] = TouchPOSPage(self.service, self.notify, self.current_user)
        self.pages['products'] = ProductsPage(self.service, self.notify)
        self.pages['customers'] = CustomersPage(self.service, self.notify)
        self.pages['suppliers'] = SuppliersPage(self.service, self.notify, self.current_user)
        self.pages['returns'] = ReturnsPage(self.service, self.notify, self.current_user)
        self.pages['reports'] = ReportsPage(self.service, self.notify)
        self.pages['users'] = UsersPage(self.service, self.notify)
        self.pages['ai'] = SmartAssistantPage(self.service, self.notify, self.current_user)
        self.pages['tools'] = ToolsPage(self.service, self.notify, self.current_user)
        for key, p in self.pages.items():
            self.stack.addWidget(p)
        main.addWidget(sidebar); main.addWidget(body, 1)


    def update_alert_button(self):
        try:
            rows = self.service.low_stock_details()
        except Exception:
            rows = []
        count = len(rows)
        self.alert_flash = not getattr(self, 'alert_flash', False)
        if count:
            self.alert_btn.setText(f'🔔 تنبيه المخزون ({count})')
            self.alert_btn.setProperty('danger', self.alert_flash)
        else:
            self.alert_btn.setText('🔔 الإشعارات')
            self.alert_btn.setProperty('danger', False)
        self.alert_btn.style().unpolish(self.alert_btn); self.alert_btn.style().polish(self.alert_btn)

    def show_alerts_dialog(self):
        rows = self.service.low_stock_details()
        dlg = QDialog(self); dlg.setWindowTitle('إشعارات المخزون'); dlg.setMinimumSize(650, 420)
        layout = QVBoxLayout(dlg)
        title = QLabel('🔔 إشعارات ذكية للمخزون'); title.setObjectName('sectionTitle')
        table = Table(['الباركود','المادة','الصنف','الكمية','حد التنبيه'])
        table.setRowCount(len(rows))
        for r, p in enumerate(rows):
            vals = [p['barcode'] or '', p['name'], p['category'] or '', p['quantity'], p['min_quantity']]
            for c, v in enumerate(vals): table.put(r, c, v)
        msg = QLabel('لا توجد مواد نافدة أو منخفضة المخزون حالياً.' if not rows else 'المواد التالية وصلت إلى حد التنبيه أو نفدت من المخزون.')
        msg.setObjectName('noticeBox'); msg.setWordWrap(True)
        ok = QPushButton('إغلاق'); ok.setObjectName('primaryButton'); ok.clicked.connect(dlg.accept)
        layout.addWidget(title); layout.addWidget(msg); layout.addWidget(table, 1); layout.addWidget(ok)
        dlg.exec()

    def run_auto_backup_check(self):
        ok, msg = self.service.auto_backup_if_due()
        if ok:
            self.notify(f'تم إنشاء نسخة احتياطية تلقائية: {msg}')
        elif msg.startswith('فشل'):
            QMessageBox.warning(self, 'فشل النسخ الاحتياطي التلقائي', msg)

    def show_first_allowed_page(self):
        for key in ['dashboard', 'sales', 'touch_pos', 'products', 'customers', 'suppliers', 'returns', 'reports', 'users', 'ai', 'tools']:
            if self.user_can(key):
                self.show_page(key); return
        QMessageBox.critical(self, 'لا توجد صلاحيات', 'هذا المستخدم لا يملك أي صلاحيات.')

    def show_page(self, key: str):
        titles = {'dashboard': 'الرئيسية', 'sales': 'المبيعات', 'products': 'المخزون والمنتجات', 'touch_pos': 'كاشير لمس', 'customers': 'العملاء والديون', 'suppliers': 'الموردون والمشتريات', 'returns': 'المرتجعات والمواد الراجعة', 'reports': 'التقارير', 'users': 'المستخدمون والصلاحيات', 'ai': 'المساعد الذكي', 'tools': 'الإعدادات والأدوات'}
        if not self.user_can(key):
            self.notify('محاولة دخول لقسم مقفل: هذا الزر خاص بالمدير فقط')
            AccessDeniedDialog(titles.get(key, 'هذه الصفحة'), self.current_user, self).exec()
            return
        self.stack.setCurrentWidget(self.pages[key]); self.title.setText(titles[key])
        for k, b in self.buttons.items():
            b.setProperty('active', k == key); b.style().unpolish(b); b.style().polish(b)
        self.refresh_current()

    def refresh_current(self):
        page = self.stack.currentWidget()
        if hasattr(page, 'refresh'): page.refresh()  # type: ignore[attr-defined]
        if isinstance(page, SalesPage): page.refresh_all()
        self.notify('تم التحديث')

    def notify(self, text: str): self.status.setText(text)

    def update_clock(self):
        from datetime import datetime
        self.clock.setText(datetime.now().strftime('%Y-%m-%d   %H:%M:%S'))

    def logout(self):
        if QMessageBox.question(self, 'تسجيل الخروج', 'هل تريد تسجيل الخروج من النظام؟') != QMessageBox.Yes:
            return
        self.service.db.close()
        QApplication.quit()

    def closeEvent(self, event):
        try:
            self.service.db.close()
        except Exception as exc:
            log_exception(exc)
        event.accept()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setApplicationName('ماكس للمبيعات')
    app.setLayoutDirection(Qt.RightToLeft)
    style_path = PROJECT_ROOT / 'assets' / 'style.qss'
    if style_path.exists(): app.setStyleSheet(style_path.read_text(encoding='utf-8'))
    from database import Database
    db = Database(); service = AppService(db)
    login = LoginDialog(service)
    if login.exec() != QDialog.Accepted:
        raise SystemExit(0)
    service.set_current_user(login.user)
    if service.must_change_password(login.user):
        change = ChangePasswordDialog(service, login.user)
        if change.exec() != QDialog.Accepted:
            raise SystemExit(0)
        login.user = db.one('SELECT * FROM users WHERE id=?', (login.user['id'],))
        service.set_current_user(login.user)
    window = MainWindow(service, login.user)
    window.show()
    raise SystemExit(app.exec())
