from __future__ import annotations

import sys
from pathlib import Path

try:
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QApplication, QDialog, QMessageBox
except ModuleNotFoundError as exc:
    print('\nلم يتم العثور على مكتبة PySide6 أو إحدى مكتبات Qt الأساسية.')
    print('ثبت المتطلبات من داخل مجلد المشروع بالأمر:')
    print('python -m pip install -r requirements.txt\n')
    raise SystemExit(1) from exc

try:
    from PySide6 import QtCharts as _QtCharts  # noqa: F401
    QTCHARTS_AVAILABLE = True
except Exception:
    QTCHARTS_AVAILABLE = False

try:
    import qdarkstyle  # type: ignore
except Exception:
    qdarkstyle = None

from database import Database
from services.app_service import AppService
from ui.main_window import ChangePasswordDialog, LoginDialog, MainWindow
from ui.theme_manager import apply_theme
from services.error_logger import install_global_exception_hook
from services.data.migrations.runner import run_migrations

# V32.3: theme loading moved to ui.theme_manager. Kept markers for checks: ui_theme.txt style_dark.qss modern_blue style_modern_blue.qss luxury_gold style_luxury_gold.qss


def load_style(app: QApplication) -> None:
    # qdarkstyle اختياري. عدم توفره لا يمنع تشغيل النظام.
    apply_theme(app, Path(__file__).parent)


def main() -> int:
    install_global_exception_hook()
    try:
        run_migrations()  # ensure native schema before opening UI/services
    except Exception as exc:
        message = f"تعذر تهيئة قاعدة البيانات: {exc}"
        print(message)
        try:
            QMessageBox.critical(None, "خطأ في تهيئة النظام", message)
        except Exception:
            pass
        return 1
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    app.setApplicationName('ماكس للمبيعات')
    app.setLayoutDirection(Qt.RightToLeft)
    load_style(app)
    if not QTCHARTS_AVAILABLE:
        print('تنبيه: QtCharts غير متوفر. سيعمل النظام، وقد يتم تعطيل بعض الرسوم البيانية فقط.')
    try:
        db = Database()
    except Exception as exc:
        message = str(exc) or 'تعذر فتح قاعدة البيانات'
        try:
            QMessageBox.critical(None, 'خطأ في قاعدة البيانات', message)
        except Exception:
            print(message)
        return 1
    service = AppService(db)
    login = LoginDialog(service)
    if login.exec() != QDialog.Accepted:
        db.close()
        return 0
    service.set_current_user(login.user)
    if service.must_change_password(login.user):
        change = ChangePasswordDialog(service, login.user)
        if change.exec() != QDialog.Accepted:
            db.close()
            return 0
        login.user = db.one('SELECT * FROM users WHERE id=?', (login.user['id'],))
        service.set_current_user(login.user)
    window = MainWindow(service, login.user)
    window.show()
    return app.exec()


if __name__ == '__main__':
    raise SystemExit(main())
