import os

from database import Database
from services.app_service import AppService


def make_service(tmp_path):
    db_path = tmp_path / "role_templates.db"
    db = Database(db_path)
    service = AppService(db)
    admin = db.one("SELECT id FROM users WHERE username='admin'")
    db.execute("UPDATE users SET must_change_password=0, can_users=1, role='مدير' WHERE id=?", (admin['id'],))
    service.current_user_id = admin['id']
    return service


def test_role_templates_have_secure_discount_limits(tmp_path):
    service = make_service(tmp_path)
    cashier = service.role_template('كاشير')
    sales = service.role_template('موظف مبيعات')
    manager = service.role_template('مدير')
    assert cashier['max_discount_percent'] == 10.0
    assert cashier['can_discount_below_cost'] == 0
    assert sales['max_discount_percent'] == 15.0
    assert sales['can_discount_below_cost'] == 0
    assert manager['max_discount_percent'] == 100.0
    assert manager['can_discount_below_cost'] == 1


def test_save_user_persists_max_discount_and_below_cost_permission(tmp_path):
    service = make_service(tmp_path)
    data = {
        'username': 'cashier_secure',
        'full_name': 'كاشير آمن',
        'password': 'Strong123!',
        'role': 'كاشير',
    }
    data.update(service.role_template('كاشير')['permissions'])
    data['max_discount_percent'] = 10
    data['can_discount_below_cost'] = 0
    service.save_user(data)
    row = service.db.one("SELECT role, can_discount, max_discount_percent, can_discount_below_cost, can_discount_limit FROM users WHERE username='cashier_secure'")
    assert row['role'] == 'كاشير'
    assert row['can_discount'] == 1
    assert row['max_discount_percent'] == 10
    assert row['can_discount_below_cost'] == 0
    assert row['can_discount_limit'] == 0
