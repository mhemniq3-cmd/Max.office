from __future__ import annotations

import sqlite3
from decimal import Decimal

import pytest

from database import password_hash
from services.domain.persistence import sales_finance_writes as sfw
import services.service_patches.v46_15_manager_approval  # noqa: F401 - installs policy patch


class DummyDB:
    def __init__(self, conn):
        self.conn = conn

    def one(self, sql, params=()):
        return self.conn.execute(sql, params).fetchone()

    def execute(self, sql, params=()):
        cur = self.conn.execute(sql, params)
        self.conn.commit()
        return cur


class Service:
    def __init__(self, conn):
        self.db = DummyDB(conn)

    def _effective_user(self, user_id=None):
        return self.db.conn.execute("SELECT * FROM users WHERE id=? AND active=1", (user_id or 1,)).fetchone()

    def is_admin_user(self, user):
        return str(user["role"] or "").strip().lower() in {"مدير", "admin", "administrator"}

    def require_any_permission(self, permissions, user_id=None, action=""):
        user = self._effective_user(user_id or 1)
        if not user:
            raise PermissionError("لا توجد جلسة")
        if self.is_admin_user(user) or any(bool(user[p]) for p in permissions):
            return user
        raise PermissionError(action)

    def require_permission(self, permission, user_id=None, action=""):
        user = self._effective_user(user_id or 1)
        if not user or not bool(user[permission]):
            raise PermissionError(action)
        return user

    def get_settings(self):
        return {"tax_percent": "0"}

    def log(self, action, details="", user_id=None, username=""):
        self.db.conn.execute(
            "INSERT INTO activity_logs(user_id, username, action, details, created_at) VALUES (?, ?, ?, ?, datetime('now'))",
            (user_id, username, action, details),
        )
        self.db.conn.commit()


# Attach the patch method to the dummy service for tests.
Service.verify_manager_approval = services.service_patches.v46_15_manager_approval._verify_manager_approval_v46_15


def make_conn():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE users (
            id INTEGER PRIMARY KEY, username TEXT, password_hash TEXT, role TEXT, active INTEGER DEFAULT 1,
            must_change_password INTEGER DEFAULT 0, can_sales INTEGER DEFAULT 1,
            can_touch_pos INTEGER DEFAULT 1, can_discount INTEGER DEFAULT 1,
            can_discount_limit INTEGER DEFAULT 0, can_discount_below_cost INTEGER DEFAULT 0,
            max_discount_percent REAL DEFAULT 10
        );
        CREATE TABLE employees (id INTEGER PRIMARY KEY, active INTEGER NOT NULL DEFAULT 1, name TEXT);
        CREATE TABLE products (id INTEGER PRIMARY KEY, name TEXT, quantity INTEGER, min_quantity INTEGER DEFAULT 0, cost_price REAL, sale_price REAL, commission_percent REAL, active INTEGER DEFAULT 1, barcode TEXT);
        CREATE TABLE sales (id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT, user_id INTEGER, employee_id INTEGER, customer_id INTEGER, subtotal REAL, discount_amount REAL, total REAL, total_commission REAL, total_profit REAL, payment_method TEXT, discount_type TEXT, tax_amount REAL, note TEXT, created_at TEXT);
        CREATE TABLE sale_items (id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER, product_id INTEGER, product_name TEXT, quantity INTEGER, cost_price REAL, unit_price REAL, line_total REAL, commission_percent REAL, commission_amount REAL, profit_amount REAL, discount_amount REAL DEFAULT 0, tax_amount REAL DEFAULT 0);
        CREATE TABLE inventory_movements (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, movement_type TEXT, quantity_change INTEGER, old_quantity INTEGER, new_quantity INTEGER, ref_type TEXT, ref_no TEXT, user_id INTEGER, note TEXT, created_at TEXT);
        CREATE TABLE activity_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, username TEXT, action TEXT, details TEXT, created_at TEXT);
        """
    )
    conn.execute("INSERT INTO users(id, username, password_hash, role, can_discount, can_discount_limit, can_discount_below_cost, max_discount_percent) VALUES (1, 'cashier', ?, 'كاشير', 1, 0, 0, 10)", (password_hash("Cashier123!"),))
    conn.execute("INSERT INTO users(id, username, password_hash, role, can_discount, can_discount_limit, can_discount_below_cost, max_discount_percent) VALUES (2, 'manager', ?, 'مدير', 1, 1, 1, 100)", (password_hash("Manager123!"),))
    conn.execute("INSERT INTO employees(id, active, name) VALUES (1, 1, 'موظف')")
    conn.execute("INSERT INTO products(id, name, quantity, min_quantity, cost_price, sale_price, commission_percent, active, barcode) VALUES (1, 'منتج', 10, 1, 3000, 5000, 0, 1, 'P1')")
    conn.commit()
    return conn


def test_manager_approval_context_allows_below_cost_sale_once():
    conn = make_conn()
    service = Service(conn)
    cart = [{"product_id": 1, "quantity": 1, "unit_price": Decimal("5000")}]
    with pytest.raises(PermissionError):
        sfw.complete_sale_native(service, cart, 1, None, "نقدي", Decimal("4500"), "", user_id=1)

    approval = service.verify_manager_approval("manager", "Manager123!", 1, "عرض خاص")
    service._manager_sale_approval_context_v46_15 = approval
    invoice = sfw.complete_sale_native(service, cart, 1, None, "نقدي", Decimal("4500"), "موافقة مدير", user_id=1)
    row = conn.execute("SELECT total, total_profit FROM sales WHERE invoice_no=?", (invoice,)).fetchone()
    assert row["total"] == 500.0
    assert row["total_profit"] == -2500.0


def test_wrong_manager_credentials_are_rejected():
    conn = make_conn()
    service = Service(conn)
    with pytest.raises(PermissionError, match="بيانات المدير"):
        service.verify_manager_approval("manager", "wrong", 1, "عرض خاص")
