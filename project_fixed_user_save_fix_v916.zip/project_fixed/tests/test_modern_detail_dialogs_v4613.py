from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_modern_detail_dialog_patch_is_loaded():
    init = (ROOT / 'ui/ui_patches/__init__.py').read_text(encoding='utf-8')
    assert 'v46_13_modern_detail_dialogs' in init


def test_modern_detail_dialog_has_clean_interactive_sections():
    text = (ROOT / 'ui/ui_patches/v46_13_modern_detail_dialogs.py').read_text(encoding='utf-8')
    for phrase in ['تفاصيل العملية', 'تفاصيل التقرير', 'المواد', 'حركات مرتبطة', 'التدقيق والملاحظات', 'حفظ / طباعة HTML', 'نسخ التفاصيل']:
        assert phrase in text
    assert 'ReportsPage.v4613_show_report_details' in text
    assert 'ToolsPage.v4613_show_modern_movement_details' in text
