from __future__ import annotations

import sqlite3
from decimal import Decimal
from pathlib import Path

import pytest

from services.core_bridge import architecture_status, native_persistence_status
from services.data.migrations.runner import run_smart_migrations
from services.data.models import PersistResult, ProductItem, SaleContext
from services.data.queries import require_columns, table_columns

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_migrations_are_idempotent_and_add_only():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    first = run_smart_migrations(conn, version="test_v1")
    second = run_smart_migrations(conn, version="test_v1")
    assert first
    assert second == []
    assert require_columns(conn, "sales", {"invoice_no", "employee_id", "total"})
    assert require_columns(conn, "sale_items", {"sale_id", "product_id", "line_total"})
    assert require_columns(conn, "payments", {"source_table", "source_id", "customer_id"})
    assert "description" in table_columns(conn, "schema_migrations")


def test_persist_result_defaults_to_native_engine():
    assert PersistResult(operation="x").engine == "domain_native"


def test_validated_product_and_sale_context_reject_bad_values():
    with pytest.raises(ValueError):
        ProductItem(product_id=1, name="bad", quantity=0, unit_price=Decimal("1"))
    item = ProductItem(product_id=1, name="ok", quantity=2, unit_price=Decimal("3.12"))
    sale = SaleContext(invoice_number="INV-1", customer_id=1, items=[item], paid_amount=Decimal("1"))
    assert sale.total_amount == Decimal("6.24")
    assert sale.remaining_amount == Decimal("5.24")


def test_core_status_is_native_only():
    status = architecture_status()
    assert status["storage_engine"] == "removed"
    native = native_persistence_status()
    assert native["storage_engine"] == "native-only"
    assert native["native_persistence_mode"] == "on"


def test_release_tree_has_safe_cleanup_policy():
    cleanup_files = list((PROJECT_ROOT / "services" / "service_patches").glob("*cleanup*.py"))
    assert cleanup_files
    text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in cleanup_files)
    assert "candidate_tables" in text
    assert "removed_tables': []" in text or 'removed_tables": []' in text
