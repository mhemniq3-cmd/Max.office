from __future__ import annotations

from pathlib import Path

from database import Database, now_text
from services.app_service import AppService


def test_partial_return_reduces_sales_total_and_profit(tmp_path: Path):
    db = Database(tmp_path / "stage27_return.db")
    service = AppService(db)
    db.execute("UPDATE users SET must_change_password=0 WHERE username='admin'")
    user = db.one("SELECT id FROM users WHERE username='admin'")
    user_id = int(user["id"])

    employee_id = db.execute(
        "INSERT INTO employees(name, active, created_at) VALUES (?, 1, ?)",
        ("موظف", now_text()),
    ).lastrowid
    product_id = db.execute(
        """
        INSERT INTO products(barcode, name, quantity, min_quantity, cost_price, sale_price, commission_percent, active, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)
        """,
        ("P-STAGE27", "مادة اختبار", 10, 1, 3500, 7000, 0, now_text()),
    ).lastrowid

    invoice = service.complete_sale(
        [{"product_id": product_id, "product_name": "مادة اختبار", "quantity": 3, "unit_price": 7000, "cost_price": 3500, "commission_percent": 0}],
        employee_id,
        None,
        "نقدي",
        0,
        "",
        user_id,
    )
    sale = db.one("SELECT id, total, total_profit FROM sales WHERE invoice_no=?", (invoice,))
    assert float(sale["total"]) == 21000.0
    assert float(sale["total_profit"]) == 10500.0

    item = db.one("SELECT id FROM sale_items WHERE sale_id=?", (sale["id"],))
    service.return_item(int(item["id"]), 1, "اختبار إرجاع قطعة", user_id, "نقدي")

    updated = db.one("SELECT total, total_profit FROM sales WHERE id=?", (sale["id"],))
    assert float(updated["total"]) == 14000.0
    assert float(updated["total_profit"]) == 7000.0

    dashboard = service.dashboard()
    assert float(dashboard["sales"]) == 14000.0
    assert float(dashboard["profit"]) == 7000.0
    assert float(dashboard["returns_amount"]) == 7000.0

    listed = service.list_sales(1)[0]
    assert float(listed["total"]) == 14000.0
    assert float(listed["total_profit"]) == 7000.0
