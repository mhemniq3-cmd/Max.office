from pathlib import Path


def test_modern_sales_screen_is_real_implementation():
    text = Path('ui/screens/sales_screen.py').read_text(encoding='utf-8')
    assert 'class SalesScreen' in text
    assert 'QTableWidget' in text
    assert 'save_sale' in text
    assert '_ModernPlaceholder' not in text
    assert 'removed_storage_engine' not in text


def test_core_bridge_exports_modern_ui_facade():
    text = Path('services/core_bridge.py').read_text(encoding='utf-8')
    assert 'class CoreBridge' in text
    assert 'def get_records' in text
    assert 'def execute_sale_process' in text
    assert 'removed_storage_engine' not in text
