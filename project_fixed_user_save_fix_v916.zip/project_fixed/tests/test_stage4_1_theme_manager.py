from pathlib import Path

from ui import theme_manager


def test_brand_theme_normalization_rejects_invalid_values(tmp_path: Path):
    data = theme_manager.normalize_brand_theme({
        'primary': 'red',
        'secondary': '#123456',
        'font_size': 99,
        'density': 'tiny',
        'radius': 99,
    })
    assert data['primary'] == theme_manager.DEFAULT_BRAND_THEME['primary']
    assert data['secondary'] == '#123456'
    assert data['font_size'] == 18
    assert data['density'] == 'comfortable'
    assert data['radius'] == 28


def test_brand_theme_save_load_and_reset(tmp_path: Path):
    saved = theme_manager.save_brand_theme({
        'preset': 'emerald',
        'primary': '#111111',
        'density': 'compact',
        'font_size': 12,
    }, tmp_path)
    assert saved['preset'] == 'emerald'
    assert saved['primary'] == '#111111'
    loaded = theme_manager.current_brand_theme(tmp_path)
    assert loaded['density'] == 'compact'
    assert loaded['font_size'] == 12
    reset = theme_manager.reset_brand_theme(tmp_path)
    assert reset['preset'] == 'ocean'


def test_dynamic_qss_contains_customer_tokens(tmp_path: Path):
    theme_manager.save_brand_theme({'primary': '#111111', 'accent': '#222222', 'density': 'spacious'}, tmp_path)
    qss = theme_manager.brand_qss(theme_manager.current_brand_theme(tmp_path), dark=False)
    assert '#111111' in qss
    assert '#222222' in qss
    assert 'min-height: 36px' in qss
