from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_currency_formatter_and_ui_usage():
    calculations = (ROOT / 'services/domain/calculations.py').read_text(encoding='utf-8')
    sales = (ROOT / 'ui/screens/sales_screen.py').read_text(encoding='utf-8')
    reports = (ROOT / 'ui/screens/reports_screen.py').read_text(encoding='utf-8')
    data_screen = (ROOT / 'ui/screens/_data_screen.py').read_text(encoding='utf-8')
    assert 'def format_currency' in calculations
    assert 'format_currency' in sales
    assert 'format_currency' in reports
    assert 'format_currency' in data_screen
    assert '{:,.2f}' in calculations or ':,.2f' in calculations


def test_delete_confirmation_and_logger_bootstrap():
    sales = (ROOT / 'ui/screens/sales_screen.py').read_text(encoding='utf-8')
    data_logger = (ROOT / 'services/data/logger.py').read_text(encoding='utf-8')
    error_logger = (ROOT / 'services/error_logger.py').read_text(encoding='utf-8')
    assert 'QMessageBox.question' in sales
    assert 'تأكيد الحذف' in sales
    assert 'mkdir(parents=True, exist_ok=True)' in data_logger
    assert 'mkdir(parents=True, exist_ok=True)' in error_logger


def test_icons_distribution_folder_exists():
    assets = ROOT / 'ui/assets'
    icons = assets / 'icons'
    assert (assets / 'icon.png').exists()
    assert (assets / 'app_icon.ico').exists()
    for name in ['sale', 'report', 'stock_low', 'delete', 'customer', 'inventory', 'settings']:
        for size in [16, 24, 32]:
            assert (icons / f'{name}_{size}.png').exists()


def test_qss_table_readability_rules():
    qss = (ROOT / 'ui/themes/modern_style.qss').read_text(encoding='utf-8')
    assert 'Stage 26 table readability fixes' in qss
    assert 'QToolTip' in qss
    assert 'min-height: 30px' in qss
