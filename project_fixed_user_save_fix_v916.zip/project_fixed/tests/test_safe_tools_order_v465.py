from __future__ import annotations

import importlib.util
from pathlib import Path


def _load_patch_module_without_importing_qt():
    path = Path('ui/ui_patches/v45_17_4_17_tools_final_order.py')
    text = path.read_text(encoding='utf-8')
    assert "('audit', '📊 الرقابة والسجلات')" in text
    assert "('operations', '💰 المبيعات والعمليات')" in text
    assert "('inventory', '📦 المخزون والجرد')" in text
    assert "('settings', '🛡️ الإعدادات والنسخ الاحتياطي')" in text
    return text


def test_tools_main_groups_are_four_safe_business_sections():
    text = _load_patch_module_without_importing_qt()
    assert "('quick'," not in text
    assert "('vouchers'," not in text
    assert "('parties'," not in text
    assert "('reports'," not in text


def test_safe_tools_order_has_empty_group_fallback():
    text = _load_patch_module_without_importing_qt()
    assert 'Safety guard' in text
    assert 'if added == 0' in text
    assert "page.tabs.addTab(widget, title or 'أداة')" in text


def test_quick_actions_are_kept_inside_operations():
    text = _load_patch_module_without_importing_qt()
    assert "if group_key == 'operations'" in text
    assert "inner.addTab(_quick_action_page(page), 'العمليات السريعة')" in text
