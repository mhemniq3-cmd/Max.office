from __future__ import annotations

from pathlib import Path

from database import Database, now_text
from services.app_service import AppService


def _svc(tmp_path: Path) -> AppService:
    db = Database(tmp_path / 'movement_v463.db')
    service = AppService(db)
    service.ensure_unified_movement_schema()
    return service


def _insert(service: AppService, key: str, record_id: int, action: str = 'بيع') -> int:
    return int(service.db.execute(
        """
        INSERT INTO unified_movement_log(event_key,event_time,user_name,module,action,record_type,record_id,description,severity,source_table,source_id,is_sensitive,is_read)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (key, now_text(), 'مستخدم اختبار', 'المبيعات', action, 'sale', record_id, 'تفاصيل اختبار', 'عادي', 'sales', record_id, 0, 0),
    ).lastrowid)


def test_movement_filters_users_record_types_and_related_rows(tmp_path: Path):
    service = _svc(tmp_path)
    first = _insert(service, 'rel-1', 77, 'بيع')
    second = _insert(service, 'rel-2', 77, 'تعديل')

    assert 'مستخدم اختبار' in service.movement_active_users()
    assert 'sale' in service.movement_record_types()
    related = service.related_unified_movements(first)
    assert any(int(row['id']) == second for row in related)


def test_manager_note_history_preserves_multiple_entries(tmp_path: Path):
    service = _svc(tmp_path)
    movement_id = _insert(service, 'note-1', 88)

    service.add_movement_manager_note(movement_id, 'الملاحظة الأولى')
    service.add_movement_manager_note(movement_id, 'الملاحظة الثانية')

    details = service.get_unified_movement_details(movement_id)
    history = details['manager_notes_history']
    assert len(history) == 2
    assert 'الملاحظة الأولى' in history[0]
    assert 'الملاحظة الثانية' in history[1]


def test_cached_movement_list_is_cleared_by_mark_read(tmp_path: Path):
    service = _svc(tmp_path)
    movement_id = _insert(service, 'cache-1', 99)

    before = service.list_unified_movements(100, record_type='sale')
    assert any(int(row['id']) == movement_id and int(row['is_read']) == 0 for row in before)

    service.mark_movements_read([movement_id])
    after = service.list_unified_movements(100, record_type='sale')
    assert any(int(row['id']) == movement_id and int(row['is_read']) == 1 for row in after)
