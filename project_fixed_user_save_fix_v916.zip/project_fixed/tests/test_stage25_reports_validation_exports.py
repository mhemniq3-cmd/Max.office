from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_reports_screen_has_filters_and_exports_without_sql():
    text = read("ui/screens/reports_screen.py")
    assert "QDateEdit" in text
    assert "export_csv" in text
    assert "export_html" in text
    assert "get_records" in text
    assert "get_connection" not in text
    assert "conn.execute" not in text


def test_sales_screen_has_live_search_and_validation():
    text = read("ui/screens/sales_screen.py")
    assert "textChanged.connect" in text
    assert "_validate_before_save" in text
    assert "product_id" in text and "quantity" in text and "unit_price" in text
    assert "get_connection" not in text
    assert "conn.execute" not in text


def test_ui_assets_and_table_polish_exist():
    assert (ROOT / "ui/assets/icon.png").exists()
    assert (ROOT / "ui/assets/stock_low.png").exists()
    qss = read("ui/themes/modern_style.qss")
    assert "Stage 25 reporting/table polish" in qss
    assert "white-space: normal" in qss
