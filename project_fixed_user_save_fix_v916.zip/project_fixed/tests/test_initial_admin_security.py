from __future__ import annotations

from db.database_core import Database, verify_password


def test_new_database_does_not_seed_admin_admin(tmp_path, monkeypatch):
    monkeypatch.delenv('MAX_SALES_INITIAL_ADMIN_PASSWORD', raising=False)
    monkeypatch.delenv('MAX_SALES_ADMIN_PASSWORD', raising=False)
    handoff = tmp_path / 'settings' / 'initial_admin_password.txt'
    monkeypatch.setenv('MAX_SALES_INITIAL_ADMIN_PASSWORD_FILE', str(handoff))

    db_path = tmp_path / 'max_sales_test.db'
    with Database(db_path) as db:
        row = db.one("SELECT username, password_hash, must_change_password FROM users WHERE username='admin'")
        assert row is not None
        assert row['must_change_password'] == 1
        assert not verify_password('admin', row['password_hash'])

    assert handoff.exists()
    assert 'admin' in handoff.read_text(encoding='utf-8')


def test_initial_admin_password_can_be_provided_by_env(tmp_path, monkeypatch):
    monkeypatch.setenv('MAX_SALES_INITIAL_ADMIN_PASSWORD', 'SecureAdmin123!')
    db_path = tmp_path / 'max_sales_env.db'
    with Database(db_path) as db:
        row = db.one("SELECT password_hash, must_change_password FROM users WHERE username='admin'")
        assert row['must_change_password'] == 1
        assert verify_password('SecureAdmin123!', row['password_hash'])


def test_existing_handoff_file_is_used_for_first_database(tmp_path, monkeypatch):
    monkeypatch.delenv('MAX_SALES_INITIAL_ADMIN_PASSWORD', raising=False)
    monkeypatch.delenv('MAX_SALES_ADMIN_PASSWORD', raising=False)
    handoff = tmp_path / 'settings' / 'initial_admin_password.txt'
    handoff.parent.mkdir(parents=True)
    handoff.write_text('كلمة مرور المدير المؤقتة لأول تشغيل فقط:\nAdmin12345!\n', encoding='utf-8')
    monkeypatch.setenv('MAX_SALES_INITIAL_ADMIN_PASSWORD_FILE', str(handoff))

    db_path = tmp_path / 'max_sales_existing_handoff.db'
    with Database(db_path) as db:
        row = db.one("SELECT password_hash FROM users WHERE username='admin'")
        assert row is not None
        assert verify_password('Admin12345!', row['password_hash'])
