from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_pyproject_version_is_final():
    text = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert 'version = "1.0.0"' in text


def test_native_adapter_name_is_used():
    assert (ROOT / "services" / "service_patches" / "native_sales_finance_adapters.py").exists()
    assert not any((ROOT / "services" / "service_patches").glob("v*_sales_finance_adapters.py"))
    init = (ROOT / "services" / "service_patches" / "__init__.py").read_text(encoding="utf-8")
    assert "native_sales_finance_adapters" in init
    assert "native_sales_finance_adapters" in init
