from services.domain.operations_core import normalize_date_format, normalize_record_dates


class DummyService:
    pass


SVC = DummyService()


def test_normalize_common_date_formats():
    assert normalize_date_format(SVC, '31/12/2026') == '2026-12-31'
    assert normalize_date_format(SVC, '2026/12/31') == '2026-12-31'
    assert normalize_date_format(SVC, '2026-12-31 22:10:00') == '2026-12-31'


def test_normalize_record_dates_only_date_fields():
    row = {'invoice_date': '15/05/2026', 'name': 'فاتورة', 'amount': 10}
    normalized = normalize_record_dates(SVC, row)
    assert normalized['invoice_date'] == '2026-05-15'
    assert normalized['name'] == 'فاتورة'
    assert normalized['amount'] == 10
