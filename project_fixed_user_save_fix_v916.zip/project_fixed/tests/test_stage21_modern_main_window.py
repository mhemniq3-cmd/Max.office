from pathlib import Path


def test_modern_main_window_entrypoint_exists_and_preserves_legacy_exports():
    text = Path('ui/main_window.py').read_text(encoding='utf-8')
    assert 'class ModernMainWindow' in text
    assert 'def run_modern_ui' in text
    assert 'from ui.main_window_core import *' in text
    assert 'from services.core_bridge import CoreBridge' in text


def test_modern_screens_use_pyside6_not_pyqt5():
    screen_text = Path('ui/screens/sales_screen.py').read_text(encoding='utf-8')
    main_text = Path('ui/main_window.py').read_text(encoding='utf-8')
    assert 'PySide6' in screen_text
    assert 'PySide6' in main_text
    assert 'PyQt5' not in screen_text
    assert 'QRegExp' not in screen_text
