from __future__ import annotations

import pytest
import sqlite3
from decimal import Decimal
from pathlib import Path

from services.domain.persistence.sales_finance_writes import complete_sale_native, update_sale_native, delete_sale_native

ROOT = Path(__file__).resolve().parents[1]


class DummyDB:
    def __init__(self, conn):
        self.conn = conn


class DummyService:
    def __init__(self, conn):
        self.db = DummyDB(conn)

    def require_any_permission(self, *args, **kwargs):
        return {"id": 1}

    def require_permission(self, *args, **kwargs):
        return {"id": 1, "username": "tester"}

    def get_settings(self):
        return {"tax_percent": "10"}

    def log(self, *args, **kwargs):
        pass


def make_conn():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE employees (id INTEGER PRIMARY KEY, active INTEGER NOT NULL DEFAULT 1, name TEXT);
        CREATE TABLE products (id INTEGER PRIMARY KEY, name TEXT, quantity INTEGER, min_quantity INTEGER DEFAULT 0, cost_price REAL, sale_price REAL, commission_percent REAL, active INTEGER DEFAULT 1, barcode TEXT);
        CREATE TABLE sales (id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT, user_id INTEGER, employee_id INTEGER, customer_id INTEGER, subtotal REAL, discount_amount REAL, total REAL, total_commission REAL, total_profit REAL, payment_method TEXT, discount_type TEXT, tax_amount REAL, note TEXT, created_at TEXT);
        CREATE TABLE sale_items (id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER, product_id INTEGER, product_name TEXT, quantity INTEGER, cost_price REAL, unit_price REAL, line_total REAL, commission_percent REAL, commission_amount REAL, profit_amount REAL, discount_amount REAL DEFAULT 0, tax_amount REAL DEFAULT 0);
        CREATE TABLE inventory_movements (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, movement_type TEXT, quantity_change INTEGER, old_quantity INTEGER, new_quantity INTEGER, ref_type TEXT, ref_no TEXT, note TEXT, user_id INTEGER, created_at TEXT);
        """
    )
    conn.execute("INSERT INTO employees(id, active, name) VALUES (1, 1, 'موظف')")
    conn.execute("INSERT INTO products(id, name, quantity, min_quantity, cost_price, sale_price, commission_percent, active, barcode) VALUES (1, 'منتج', 10, 1, 50, 100, 0, 1, 'P1')")
    conn.commit()
    return conn


def test_update_and_delete_sale_restore_stock_before_writing_new_quantities():
    conn = make_conn()
    service = DummyService(conn)
    invoice = complete_sale_native(service, [{"product_id": 1, "quantity": 1, "unit_price": Decimal("100"), "item_discount": Decimal("10")}], 1, None, "نقدي", Decimal("5"), "")
    sale = conn.execute("SELECT id, subtotal, discount_amount, tax_amount, total FROM sales WHERE invoice_no=?", (invoice,)).fetchone()
    assert conn.execute("SELECT quantity FROM products WHERE id=1").fetchone()[0] == 9
    assert sale["subtotal"] == 100.0
    assert sale["discount_amount"] == 15.0
    assert sale["tax_amount"] == 8.5
    assert sale["total"] == 93.5

    update_sale_native(service, sale["id"], [{"product_id": 1, "quantity": 2, "unit_price": Decimal("100"), "item_discount": Decimal("0")}], 1, None, "نقدي", Decimal("0"), "", reason="تعديل لغايات الاختبار")
    assert conn.execute("SELECT quantity FROM products WHERE id=1").fetchone()[0] == 8

    delete_sale_native(service, sale["id"], "اختبار")
    assert conn.execute("SELECT quantity FROM products WHERE id=1").fetchone()[0] == 10
    assert conn.execute("SELECT COUNT(*) FROM sales").fetchone()[0] == 0
    assert conn.execute("SELECT COUNT(*) FROM sale_items").fetchone()[0] == 0


def test_sales_native_business_rules_and_permissions():
    conn = make_conn()
    service = DummyService(conn)

    # 1. Test update_sale_native throws ValueError when reason is empty or missing
    invoice = complete_sale_native(service, [{"product_id": 1, "quantity": 1, "unit_price": Decimal("100"), "item_discount": Decimal("0")}], 1, None, "نقدي", Decimal("0"), "")
    sale = conn.execute("SELECT id FROM sales WHERE invoice_no=?", (invoice,)).fetchone()
    
    with pytest.raises(ValueError, match="سبب تعديل الفاتورة مطلوب"):
        update_sale_native(service, sale["id"], [{"product_id": 1, "quantity": 1, "unit_price": Decimal("100"), "item_discount": Decimal("0")}], 1, None, "نقدي", Decimal("0"), "", reason="")

    # 2. Test delete_sale_native throws ValueError when reason is empty or missing
    with pytest.raises(ValueError, match="سبب حذف الفاتورة مطلوب"):
        delete_sale_native(service, sale["id"], "")

    # 3. Test price edit permission (can_price_edit) enforcement
    class MockService(DummyService):
        def __init__(self, conn):
            super().__init__(conn)
            self.forbidden_permissions = set()

        def require_permission(self, permission, *args, **kwargs):
            if permission in self.forbidden_permissions:
                raise PermissionError(f"Missing {permission}")
            return {"id": 1, "username": "tester"}

        def require_any_permission(self, permissions, *args, **kwargs):
            if any(p in self.forbidden_permissions for p in permissions):
                raise PermissionError(f"Missing {permissions}")
            return {"id": 1}

    mock_service = MockService(conn)
    mock_service.forbidden_permissions.add("can_price_edit")

    # Try complete sale with modified price (product original sale_price is 100, we try to sell at 90)
    with pytest.raises(PermissionError, match="Missing can_price_edit"):
        complete_sale_native(mock_service, [{"product_id": 1, "quantity": 1, "unit_price": Decimal("90"), "item_discount": Decimal("0")}], 1, None, "نقدي", Decimal("0"), "")

    # Try update sale with modified price
    mock_service.forbidden_permissions.clear()
    invoice_ok = complete_sale_native(mock_service, [{"product_id": 1, "quantity": 1, "unit_price": Decimal("100"), "item_discount": Decimal("0")}], 1, None, "نقدي", Decimal("0"), "")
    sale_ok = conn.execute("SELECT id FROM sales WHERE invoice_no=?", (invoice_ok,)).fetchone()
    
    mock_service.forbidden_permissions.add("can_price_edit")
    with pytest.raises(PermissionError, match="Missing can_price_edit"):
        update_sale_native(mock_service, sale_ok["id"], [{"product_id": 1, "quantity": 1, "unit_price": Decimal("90"), "item_discount": Decimal("0")}], 1, None, "نقدي", Decimal("0"), "", reason="تعديل السعر")

    # 4. Test discount permission (can_discount) enforcement
    # Item-level discount
    mock_service.forbidden_permissions.clear()
    mock_service.forbidden_permissions.add("can_discount")
    with pytest.raises(PermissionError, match="Missing can_discount"):
        complete_sale_native(mock_service, [{"product_id": 1, "quantity": 1, "unit_price": Decimal("100"), "item_discount": Decimal("10")}], 1, None, "نقدي", Decimal("0"), "")

    # Global discount
    with pytest.raises(PermissionError, match="Missing can_discount"):
        complete_sale_native(mock_service, [{"product_id": 1, "quantity": 1, "unit_price": Decimal("100"), "item_discount": Decimal("0")}], 1, None, "نقدي", Decimal("10"), "")

    # 5. Test delete sale manager permission restriction (must have returns, audit, or users)
    mock_service.forbidden_permissions.clear()
    mock_service.forbidden_permissions.add("can_returns")
    mock_service.forbidden_permissions.add("can_audit")
    mock_service.forbidden_permissions.add("can_users")
    
    with pytest.raises(PermissionError, match="Missing"):
        delete_sale_native(mock_service, sale_ok["id"], "حذف للتجربة")


def test_stage24_ui_and_config_cleanups_are_present():
    sales_screen = (ROOT / "ui/screens/sales_screen.py").read_text(encoding="utf-8")
    assert "item_discount" in sales_screen
    assert "get_connection" not in sales_screen
    assert "SELECT " not in sales_screen.upper()
    assert "float(" not in sales_screen

    qss = (ROOT / "ui/themes/modern_style.qss").read_text(encoding="utf-8")
    assert "Stage 24 table readability fixes" in qss
    assert "text-align: right" in qss

    config = (ROOT / "config.py").read_text(encoding="utf-8")
    assert "BASE_DIR" in config
    assert "MAX_SALES_PRINTER_NAME" in config
    assert "MAX_SALES_PRINTER_PORT" in config
