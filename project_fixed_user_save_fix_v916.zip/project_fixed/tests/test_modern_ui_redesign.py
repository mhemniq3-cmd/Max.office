from pathlib import Path


def test_modern_ui_styles_and_screens_exist():
    root = Path(__file__).resolve().parents[1]
    assert (root / "ui/themes/modern_style.qss").exists()
    assert (root / "assets/style_modern_clean.qss").exists()
    for name in ["sales_screen.py", "inventory_screen.py", "customers_screen.py", "reports_screen.py", "settings_screen.py"]:
        assert (root / "ui/screens" / name).exists()


def test_theme_manager_uses_modern_clean_style():
    root = Path(__file__).resolve().parents[1]
    text = (root / "ui/theme_manager.py").read_text(encoding="utf-8")
    assert "style_modern_clean.qss" in text
    assert "Tajawal" in text


def test_main_window_has_modern_arabic_labels():
    root = Path(__file__).resolve().parents[1]
    text = (root / "ui/main_window_core.py").read_text(encoding="utf-8")
    assert "ماكس سيلز" in text
    assert "المبيعات" in text
    assert "المخزون والمنتجات" in text
    assert "الإعدادات والأدوات" in text
