from decimal import Decimal

import pytest

from services.domain import sales_finance as sf


class DummyService:
    pass


SVC = DummyService()


def test_calculate_discount_percent_and_cap():
    assert sf.calculate_discount(SVC, 100, 10, 'percent') == 10.0
    assert sf.calculate_discount(SVC, 100, 500, 'amount') == 100.0


def test_calculate_tax_exclusive_and_included():
    assert sf.calculate_tax_amount(SVC, 100, 5) == 5.0
    assert sf.calculate_tax_amount(SVC, 105, 5, tax_included=True) == 5.0


def test_calculate_item_total_zero_quantity():
    row = sf.calculate_item_total(SVC, 0, 25, tax_percent=15, discount=100)
    assert row['gross_total'] == 0.0
    assert row['net_total'] == 0.0


def test_invoice_totals_with_global_discount_shipping_and_tax():
    totals = sf.calculate_invoice_totals(
        SVC,
        items=[{'product_id': 1, 'quantity': 2, 'price': 10, 'tax_percent': 5}],
        global_discount=10,
        global_discount_type='percent',
        shipping=1,
    )
    assert totals['sub_total'] == 20.0
    assert totals['total_discount'] == 2.0
    assert totals['total_tax'] == 1.0
    assert totals['net_total'] == 20.0


def test_invoice_totals_decimal_matches_float_keys():
    totals = sf.calculate_invoice_totals_decimal(SVC, [{'quantity': 3, 'price': '1.333'}])
    assert isinstance(totals['net_total'], Decimal)
    assert totals['net_total'] == Decimal('3.99')


def test_profit_hidden_when_user_cannot_view_cost():
    result = sf.calculate_invoice_profit(
        SVC,
        [{'quantity': 2, 'selling_price': 10, 'cost_price': 6}],
        can_view_cost=False,
    )
    assert 'cost_total' not in result
    assert result['profit'] == 8.0


def test_remaining_and_credit_impact():
    assert sf.calculate_remaining_amount(SVC, 100, 40)['remaining_amount'] == 60.0
    impact = sf.calculate_credit_impact(SVC, current_balance=50, invoice_total=100, payment_amount=30)
    assert impact['balance_after'] == 120.0


def test_return_values_apply_discount_and_tax():
    result = sf.calculate_return_values(
        SVC,
        original_item_price=100,
        return_quantity=1,
        original_tax=5,
        original_discount=10,
        discount_type='percent',
    )
    assert result['gross_total'] == 100.0
    assert result['discount_amount'] == 10.0
    assert result['tax_amount'] == 4.5
    assert result['net_total'] == 94.5


def test_pure_functions_reject_db_like_objects():
    class FakeConnection:
        pass

    with pytest.raises(TypeError):
        sf.calculate_invoice_totals(SVC, FakeConnection())
