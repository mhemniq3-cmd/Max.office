import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import pytest

try:
    import shiboken6
    from PySide6.QtWidgets import QApplication, QCheckBox
except Exception:  # pragma: no cover
    shiboken6 = None
    QApplication = None
    QCheckBox = None


@pytest.mark.skipif(QApplication is None or shiboken6 is None, reason='PySide6 not available')
def test_users_page_live_checks_drops_deleted_checkbox():
    from ui.pages.users_page import UsersPage

    app = QApplication.instance() or QApplication([])
    page = object.__new__(UsersPage)
    live = QCheckBox('live')
    dead = QCheckBox('dead')
    page.checks = {'live': live, 'dead': dead}
    shiboken6.delete(dead)

    result = UsersPage._live_checks(page)

    assert result == {'live': live}
    assert 'dead' not in page.checks
