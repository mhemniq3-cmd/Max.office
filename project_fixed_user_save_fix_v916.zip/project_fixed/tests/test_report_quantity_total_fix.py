from __future__ import annotations

from pathlib import Path

from database import Database, now_text
from services.app_service import AppService


def _base_service(tmp_path: Path):
    db = Database(tmp_path / "report_quantity_total_fix.db")
    service = AppService(db)
    db.execute("UPDATE users SET must_change_password=0 WHERE username='admin'")
    user_id = int(db.one("SELECT id FROM users WHERE username='admin'")["id"])
    employee_id = db.execute(
        "INSERT INTO employees(name, active, created_at) VALUES (?, 1, ?)",
        ("موظف", now_text()),
    ).lastrowid
    product_id = db.execute(
        """
        INSERT INTO products(barcode, name, quantity, min_quantity, cost_price, sale_price, commission_percent, active, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)
        """,
        ("P-QTY-FIX", "قطعة", 20, 1, 3000, 5000, 0, now_text()),
    ).lastrowid
    return db, service, user_id, employee_id, product_id


def test_reports_show_quantity_times_unit_price_for_multi_quantity_sale(tmp_path: Path):
    db, service, user_id, employee_id, product_id = _base_service(tmp_path)
    invoice = service.complete_sale(
        [{"product_id": product_id, "product_name": "قطعة", "quantity": 3, "unit_price": 5000, "cost_price": 3000, "commission_percent": 0}],
        employee_id,
        None,
        "نقدي",
        0,
        "",
        user_id,
    )
    sale = db.one("SELECT id, subtotal, total FROM sales WHERE invoice_no=?", (invoice,))
    item = db.one("SELECT quantity, unit_price, line_total FROM sale_items WHERE sale_id=?", (sale["id"],))
    assert float(item["line_total"]) == 15000.0
    assert float(sale["subtotal"]) == 15000.0
    assert float(sale["total"]) == 15000.0
    assert float(service.dashboard()["sales"]) == 15000.0
    assert float(service.management_report("top_products")[0]["total"]) == 15000.0


def test_report_guard_repairs_legacy_line_total_equal_to_unit_price(tmp_path: Path):
    db, service, user_id, employee_id, product_id = _base_service(tmp_path)
    invoice = service.complete_sale(
        [{"product_id": product_id, "product_name": "قطعة", "quantity": 3, "unit_price": 5000, "cost_price": 3000, "commission_percent": 0}],
        employee_id,
        None,
        "نقدي",
        0,
        "",
        user_id,
    )
    sale = db.one("SELECT id FROM sales WHERE invoice_no=?", (invoice,))
    db.execute("UPDATE sale_items SET line_total=unit_price WHERE sale_id=?", (sale["id"],))
    db.execute("UPDATE sales SET subtotal=5000, total=5000 WHERE id=?", (sale["id"],))

    listed = service.list_sales(1)[0]
    item = db.one("SELECT line_total FROM sale_items WHERE sale_id=?", (sale["id"],))
    stored_sale = db.one("SELECT subtotal, total FROM sales WHERE id=?", (sale["id"],))

    assert float(item["line_total"]) == 15000.0
    assert float(stored_sale["subtotal"]) == 15000.0
    assert float(stored_sale["total"]) == 15000.0
    assert float(listed["total"]) == 15000.0
    assert float(service.management_report("top_products")[0]["total"]) == 15000.0
