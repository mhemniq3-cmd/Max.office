from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_sales_screen_passes_stock_event_fields_without_direct_sql():
    text = read("ui/screens/sales_screen.py")
    assert "get_connection" not in text
    assert "SELECT " not in text.upper()
    assert "Decimal" in text
    assert "float(" not in text
    assert '"product_id": item.get("product_id")' in text
    assert '"quantity": _as_int(item.get("quantity"), 1)' in text
    assert '"unit_price": _as_decimal(item.get("unit_price"))' in text
    assert "self.setLayoutDirection(Qt.RightToLeft)" in text


def test_sale_adapter_enriches_event_preview_with_cart_items():
    text = read("services/service_patches/native_sales_finance_adapters.py")
    assert "event_items" in text
    assert '"product_id"' in text
    assert '"quantity"' in text
    assert '"unit_price"' in text
    assert '"cart_items": event_items' in text


def test_native_writer_emits_low_stock_event_after_inventory_update():
    text = read("services/domain/persistence/sales_finance_writes.py")
    assert "events.ON_STOCK_LOW" in text
    assert '"old_quantity"' in text
    assert '"new_quantity"' in text
    assert '"invoice_no"' in text


def test_modern_screens_are_not_placeholders_and_are_rtl():
    for rel in [
        "ui/screens/inventory_screen.py",
        "ui/screens/customers_screen.py",
        "ui/screens/reports_screen.py",
        "ui/screens/settings_screen.py",
    ]:
        text = read(rel)
        assert "_ModernPlaceholder" not in text
    assert "self.setLayoutDirection(Qt.RightToLeft)" in read("ui/screens/_data_screen.py")
    assert "self.setLayoutDirection(Qt.RightToLeft)" in read("ui/screens/reports_screen.py")
    assert "self.setLayoutDirection(Qt.RightToLeft)" in read("ui/screens/settings_screen.py")


def test_modern_qss_has_required_design_tokens():
    text = read("ui/themes/modern_style.qss")
    for token in ["#165DFF", "#00B42A", "#FF7D00", "#F2F3F5", "Tajawal"]:
        assert token in text
    assert "QTableWidget" in text
    assert "QLineEdit" in text
    assert "QPushButton#NavButton" in text
