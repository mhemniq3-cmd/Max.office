from __future__ import annotations

from pathlib import Path

from database import Database, now_text
from services.app_service import AppService


def _svc(tmp_path: Path) -> AppService:
    db = Database(tmp_path / 'movement_v4612.db')
    service = AppService(db)
    service.ensure_unified_movement_schema()
    return service


def test_movement_rows_show_sale_item_employee_quantity_and_total(tmp_path: Path):
    service = _svc(tmp_path)
    user_id = service.db.execute("INSERT INTO users(username,password_hash,role,full_name,active,created_at) VALUES(?,?,?,?,?,?)", ('seller1', 'x', 'كاشير', 'أحمد البائع', 1, now_text())).lastrowid
    emp_id = service.db.execute("INSERT INTO employees(name,phone,active,created_at) VALUES(?,?,?,?)", ('علي الموظف', '', 1, now_text())).lastrowid
    sale_id = service.db.execute(
        """
        INSERT INTO sales(invoice_no,user_id,employee_id,subtotal,discount_amount,total,total_commission,total_profit,payment_method,discount_type,tax_amount,status,note,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        ('INV-4612', user_id, emp_id, 15000, 0, 15000, 0, 3000, 'نقدي', 'amount', 0, 'completed', '', now_text()),
    ).lastrowid
    service.db.execute("INSERT INTO products(name,cost_price,sale_price,quantity,created_at) VALUES(?,?,?,?,?)", ('مادة اختبار', 2000, 5000, 10, now_text()))
    product_id = service.db.one("SELECT id FROM products WHERE name=?", ('مادة اختبار',))['id']
    service.db.execute(
        "INSERT INTO sale_items(sale_id,product_id,product_name,quantity,cost_price,unit_price,line_total,commission_percent,commission_amount,profit_amount) VALUES(?,?,?,?,?,?,?,?,?,?)",
        (sale_id, product_id, 'مادة اختبار', 3, 2000, 5000, 15000, 0, 0, 9000),
    )
    service.db.execute(
        """
        INSERT INTO unified_movement_log(event_key,event_time,user_name,module,action,record_type,record_id,description,severity,source_table,source_id,is_sensitive,is_read)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        ('v4612-sale', now_text(), 'seller1', 'المبيعات', 'عملية بيع', 'sale', str(sale_id), 'فاتورة INV-4612', 'عادي', 'sales', str(sale_id), 0, 0),
    )

    rows = service.list_unified_movements(50, term='INV-4612')
    row = next(r for r in rows if str(r.get('invoice_no')) == 'INV-4612')
    assert row['product_names'] == 'مادة اختبار'
    assert row['seller_or_employee'] == 'علي الموظف'
    assert row['sold_quantity'] == 3
    assert float(row['sale_total']) == 15000


def test_movement_details_window_payload_contains_items_and_related(tmp_path: Path):
    service = _svc(tmp_path)
    emp_id = service.db.execute("INSERT INTO employees(name,phone,active,created_at) VALUES(?,?,?,?)", ('موظف التفاصيل', '', 1, now_text())).lastrowid
    sale_id = service.db.execute(
        """
        INSERT INTO sales(invoice_no,employee_id,subtotal,discount_amount,total,total_commission,total_profit,payment_method,discount_type,tax_amount,status,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        ('INV-DETAIL', emp_id, 10000, 0, 10000, 0, 1000, 'نقدي', 'amount', 0, 'completed', now_text()),
    ).lastrowid
    product_id = service.db.execute("INSERT INTO products(name,cost_price,sale_price,quantity,created_at) VALUES(?,?,?,?,?)", ('مادة التفاصيل', 1000, 5000, 5, now_text())).lastrowid
    service.db.execute(
        "INSERT INTO sale_items(sale_id,product_id,product_name,quantity,cost_price,unit_price,line_total,commission_percent,commission_amount,profit_amount) VALUES(?,?,?,?,?,?,?,?,?,?)",
        (sale_id, product_id, 'مادة التفاصيل', 2, 1000, 5000, 10000, 0, 0, 8000),
    )
    first = service.db.execute(
        "INSERT INTO unified_movement_log(event_key,event_time,user_name,module,action,record_type,record_id,description,severity,source_table,source_id,is_sensitive,is_read) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        ('v4612-detail-1', now_text(), 'admin', 'المبيعات', 'بيع', 'sale', str(sale_id), 'فاتورة INV-DETAIL', 'عادي', 'sales', str(sale_id), 0, 0),
    ).lastrowid
    service.db.execute(
        "INSERT INTO unified_movement_log(event_key,event_time,user_name,module,action,record_type,record_id,description,severity,source_table,source_id,is_sensitive,is_read) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        ('v4612-detail-2', now_text(), 'admin', 'المبيعات', 'تدقيق بيع', 'sale', str(sale_id), 'تدقيق فاتورة INV-DETAIL', 'حساس', 'audit_logs', str(sale_id), 1, 0),
    )

    details = service.get_unified_movement_details(first)
    assert details['invoice_no'] == 'INV-DETAIL'
    assert details['sale']['invoice_no'] == 'INV-DETAIL'
    assert details['items'][0]['product_name'] == 'مادة التفاصيل'
    assert details['sold_quantity'] == 2
    assert any(r['action'] == 'تدقيق بيع' for r in details['related_movements'])
