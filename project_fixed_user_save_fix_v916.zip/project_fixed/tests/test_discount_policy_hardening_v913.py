from __future__ import annotations

import sqlite3
from decimal import Decimal
import pytest

from services.domain.persistence.sales_finance_writes import complete_sale_native


class DummyDB:
    def __init__(self, conn):
        self.conn = conn


class Service:
    def __init__(self, conn):
        self.db = DummyDB(conn)

    def _effective_user(self, user_id=None):
        return self.db.conn.execute("SELECT * FROM users WHERE id=? AND active=1", (user_id or 1,)).fetchone()

    def require_any_permission(self, permissions, user_id=None, action=""):
        user = self._effective_user(user_id or 1)
        if not user:
            raise PermissionError("لا توجد جلسة")
        if any(bool(user[p]) for p in permissions):
            return user
        raise PermissionError(action)

    def require_permission(self, permission, user_id=None, action=""):
        user = self._effective_user(user_id or 1)
        if not user or not bool(user[permission]):
            raise PermissionError(action)
        return user

    def get_settings(self):
        return {"tax_percent": "0"}

    def log(self, *args, **kwargs):
        pass


def make_conn(can_discount=1, can_discount_limit=0, role="كاشير"):
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE users (
            id INTEGER PRIMARY KEY, username TEXT, role TEXT, active INTEGER DEFAULT 1,
            must_change_password INTEGER DEFAULT 0, can_sales INTEGER DEFAULT 1,
            can_touch_pos INTEGER DEFAULT 1, can_discount INTEGER DEFAULT 0,
            can_discount_limit INTEGER DEFAULT 0
        );
        CREATE TABLE employees (id INTEGER PRIMARY KEY, active INTEGER NOT NULL DEFAULT 1, name TEXT);
        CREATE TABLE products (id INTEGER PRIMARY KEY, name TEXT, quantity INTEGER, min_quantity INTEGER DEFAULT 0, cost_price REAL, sale_price REAL, commission_percent REAL, active INTEGER DEFAULT 1, barcode TEXT);
        CREATE TABLE sales (id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT, user_id INTEGER, employee_id INTEGER, customer_id INTEGER, subtotal REAL, discount_amount REAL, total REAL, total_commission REAL, total_profit REAL, payment_method TEXT, discount_type TEXT, tax_amount REAL, note TEXT, created_at TEXT);
        CREATE TABLE sale_items (id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER, product_id INTEGER, product_name TEXT, quantity INTEGER, cost_price REAL, unit_price REAL, line_total REAL, commission_percent REAL, commission_amount REAL, profit_amount REAL, discount_amount REAL DEFAULT 0, tax_amount REAL DEFAULT 0);
        CREATE TABLE inventory_movements (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, movement_type TEXT, quantity_change INTEGER, old_quantity INTEGER, new_quantity INTEGER, ref_type TEXT, ref_no TEXT, note TEXT, user_id INTEGER, created_at TEXT);
        """
    )
    conn.execute("INSERT INTO users(id, username, role, can_discount, can_discount_limit) VALUES (1, 'cashier', ?, ?, ?)", (role, can_discount, can_discount_limit))
    conn.execute("INSERT INTO employees(id, active, name) VALUES (1, 1, 'موظف')")
    conn.execute("INSERT INTO products(id, name, quantity, min_quantity, cost_price, sale_price, commission_percent, active, barcode) VALUES (1, 'منتج', 10, 1, 3000, 5000, 0, 1, 'P1')")
    conn.commit()
    return conn


def test_cashier_cannot_discount_below_cost_even_if_discount_enabled():
    conn = make_conn(can_discount=1, can_discount_limit=0, role="كاشير")
    service = Service(conn)
    with pytest.raises(PermissionError, match="أقل من تكلفة الشراء"):
        complete_sale_native(service, [{"product_id": 1, "quantity": 1, "unit_price": Decimal("5000")}], 1, None, "نقدي", Decimal("4500"), "", user_id=1)
    assert conn.execute("SELECT COUNT(*) FROM sales").fetchone()[0] == 0
    assert conn.execute("SELECT quantity FROM products WHERE id=1").fetchone()[0] == 10


def test_cashier_cannot_exceed_role_discount_percent():
    conn = make_conn(can_discount=1, can_discount_limit=0, role="كاشير")
    service = Service(conn)
    with pytest.raises(PermissionError, match="أكبر من الحد"):
        complete_sale_native(service, [{"product_id": 1, "quantity": 1, "unit_price": Decimal("5000")}], 1, None, "نقدي", Decimal("1000"), "", user_id=1)


def test_discount_disabled_user_cannot_discount_at_all():
    conn = make_conn(can_discount=0, can_discount_limit=0, role="كاشير")
    service = Service(conn)
    with pytest.raises(PermissionError, match="إعطاء خصم"):
        complete_sale_native(service, [{"product_id": 1, "quantity": 1, "unit_price": Decimal("5000")}], 1, None, "نقدي", Decimal("100"), "", user_id=1)


def test_manager_can_discount_below_cost_when_explicitly_allowed():
    conn = make_conn(can_discount=1, can_discount_limit=1, role="مدير")
    service = Service(conn)
    invoice = complete_sale_native(service, [{"product_id": 1, "quantity": 1, "unit_price": Decimal("5000")}], 1, None, "نقدي", Decimal("4500"), "", user_id=1)
    row = conn.execute("SELECT total, total_profit FROM sales WHERE invoice_no=?", (invoice,)).fetchone()
    assert row["total"] == 500.0
    assert row["total_profit"] == -2500.0
