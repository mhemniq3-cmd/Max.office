from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_modern_main_window_instantiates_core_bridge():
    text = (ROOT / 'ui' / 'main_window.py').read_text(encoding='utf-8')
    assert 'self.bridge = CoreBridge()' in text
    assert 'self.bridge = CoreBridge  #' not in text


def test_sales_screen_has_no_direct_database_sql_and_uses_decimal():
    text = (ROOT / 'ui' / 'screens' / 'sales_screen.py').read_text(encoding='utf-8')
    assert 'get_connection' not in text
    assert 'SELECT ' not in text.upper()
    assert 'float(' not in text
    assert 'from decimal import Decimal' in text
    assert '_as_decimal' in text


def test_main_runs_migrations_before_database_open():
    text = (ROOT / 'main.py').read_text(encoding='utf-8')
    assert 'from services.data.migrations.runner import run_migrations' in text
    assert 'run_migrations()  # ensure native schema before opening UI/services' in text
    assert text.index('run_migrations()') < text.index('db = Database()')


def test_database_path_is_unified_to_database_directory():
    assert 'database" / "max_sales.db"' in (ROOT / 'services' / 'data' / 'connections.py').read_text(encoding='utf-8')
    assert "PROJECT_ROOT / 'database'" in (ROOT / 'db' / 'database_core.py').read_text(encoding='utf-8')
    assert "'max_sales.db'" in (ROOT / 'db' / 'database_core.py').read_text(encoding='utf-8')
