@echo off
cd /d "%~dp0"
python show_admin_password.py
pause
