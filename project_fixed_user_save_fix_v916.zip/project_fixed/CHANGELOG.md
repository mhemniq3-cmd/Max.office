
## v1.0.0 - Stage 24 Inventory, Discounts, and Portable Config

- Fixed stock restoration when updating or deleting sale invoices.
- Added item-level discount support and tax calculation after item/global discounts.
- Added ON_STOCK_CHANGED events for sale update/delete flows.
- Improved modern Arabic table alignment and readability.
- Added portable config.py path resolution and printer/log environment settings.
- Added regression tests for inventory restoration, item discounts, UI separation, and portable config.

# Changelog

## Max Sales v1.0.0 Stable Release - Clean Architecture Edition

- تثبيت مسار الحفظ Native-only للمبيعات والدفعات.
- إزالة الاعتماد على `removed_storage_engine`.
- تثبيت متغير البيئة `MAX_SALES_NATIVE_PERSISTENCE=on`.
- تنظيف التوثيق والتغليف من مراجع مراحل التطوير القديمة.
- تحديث رقم الحزمة إلى `1.0.0`.
- إعادة تسمية محول المبيعات/المالية إلى `native_sales_finance_adapters.py`.
- الإبقاء على `service_patches` كإضافات ميزات مستقرة فقط، وليس كمسار تخزين بديل.

## v1.0.0 - Stage 20 Modern Sales Screen

- استبدال شاشة البيع المؤقتة داخل `ui/screens/sales_screen.py` بشاشة فعلية حديثة.
- إضافة دعم البحث عن المنتجات، سلة المشتريات، تعديل الكميات، الخصم، وحفظ الفاتورة.
- إضافة واجهة `CoreBridge` خفيفة لدعم الشاشات الجديدة عند التشغيل المستقل بدون أي مسار legacy.
- إضافة اختبارات لضمان عدم رجوع شاشة البيع إلى placeholder أو legacy storage.

## Stage 22 - Critical UI Runtime Hardening

- Corrected the modern UI bridge lifecycle to instantiate `CoreBridge()`.
- Removed direct database/SQL access from the modern sales screen.
- Switched modern sales screen totals and payload values to `Decimal`.
- Ensured smart migrations run before the main database/service startup.
- Unified the default database path to `database/max_sales.db`.

## v1.0.0 - Stage 25 Reports, Validation & Export Polish
- Added working date filters to the modern reports screen.
- Added CSV/Excel-compatible and HTML export from reports.
- Added live product search in the modern sales screen.
- Added UI-level validation before sale save.
- Polished table readability and added default icon assets.

## v1.0.0 - Stage 26 Final UI Polish

- Added shared currency formatting with thousands separators.
- Applied readable money display to sales, reports, and generic data tables.
- Added delete confirmation for cart item removal.
- Added complete UI assets/icons distribution folder with PNG and ICO assets.
- Ensured logs folder is created automatically by logger bootstrap modules.
- Improved table QSS readability, row height, and tooltips.

## v1.0.0 Stage 27 - Return Financial Reconciliation

- Fixed partial returns so invoice totals and profits are reconciled after every return.
- Added final reporting reconciliation before dashboard, sales lists, summaries, and management reports.
- Added a regression test for: cost 3,500, sale 7,000, sell 3 pieces, return 1 piece => sales 14,000 and profit 7,000.

## v1.0.1 - Readiness and First-Run Security Polish

- Removed the fixed `admin/admin` seed from brand-new databases.
- Added generated one-time first-run admin password handoff at `settings/initial_admin_password.txt`.
- Added `MAX_SALES_INITIAL_ADMIN_PASSWORD` support for controlled deployments.
- Added `tests/conftest.py` and pytest `pythonpath` settings so `pytest` and `python -m pytest` both resolve project imports consistently.
- Added `run_tests.bat` for Windows users.
- Added `PATCHES_CONSOLIDATION.md` to document the safe consolidation boundary for patch modules.
