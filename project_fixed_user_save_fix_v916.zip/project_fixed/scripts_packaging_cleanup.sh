#!/usr/bin/env bash
set -e
find . -type d -name __pycache__ -prune -exec rm -rf {} +
rm -f logs/error.log
find backups -type f \( -name '*.db' -o -name '*.sqlite' -o -name '*.sqlite3' -o -name '*.maxbak' \) -delete 2>/dev/null || true
find exports -type f \( -name '*.html' -o -name '*.csv' -o -name '*.xlsx' -o -name '*.pdf' \) -delete 2>/dev/null || true
find . -type f \( -name '*_old.*' -o -name '*_temp.*' -o -name '*debug*' \) -delete 2>/dev/null || true
