"""Compatibility facade for database layer.

New code should import domain-specific helpers from db/* when possible.
Existing modules may continue to use `from database import Database, money, ...`.
"""
from db.database_core import *
